# SDK Client 3.23.9 / build 59 — Alpaca Super Fast

Super Fast opt-in: até três cartas expostas do mesmo tipo por ciclo, via eventos
originais do jogo. Exige snapshot completo, ACK individual e efeito confirmado.
Falha 500, resposta incerta ou perda de contexto bloqueiam novas ações; não
fabrica pacotes, não libera cartas cobertas e não altera estoque do servidor.

Corrige leitura e Raio X das reservas elevadas pelo poder quando há geometria
verificada; células nulas de storage_blocks são aceitas conservadoramente.
Mission priority e fallback para o planejador normal são preservados.

Menu Alpaca → engrenagem → Super Fast (desativado por padrão). Habilitar Auto
separadamente. Normal, Turbo, planejamento e poderes continuam disponíveis.
Bilhar e Cartas mantêm os módulos anteriores sem mudança de algoritmo.

Leia Analysis/V3_23_9-super-fast.md e Validation/V3_23_9-validation.json.
Fontes e workflow são pareados por SHA-256; compilação Apple, assinatura e teste
físico são etapas separadas. Não há garantia de vitória ou de latência no aparelho.

## Histórico preservado — não descreve o estado atual

# SDK Client 3.23.8 — build 58 — auditoria de autenticação

Leia **Analysis/V3_23_8-authentication.md**: componentes, fluxo, credenciais,
evidência binária, achados corrigidos e limites. O SDKtools não possui login/licença
próprios; reutiliza a sessão original. Não foram extraídos tokens reais.

Mudanças: os dois testes manuais exigem WSS/TLS confirmado; se faltar, bloqueiam
sem envio. Isso não altera conexões, login/heartbeat ou regras do próprio WePlay.
A CI agora compila com token read-only; publicação em job separado somente por
execução manual na branch padrão. PRs não publicam Releases; secret_url fica
restrito à branch padrão revisada. Não executa fontes SDK no job de publicação.

Incluído editor de prévia offline `scripts/game_request_preview.py`: valida/edita
parâmetros dos métodos conhecidos sem credenciais, UID/RID, pacote ou rede.
Não possui modo send; mudar formato não transforma recusa 500 em autorização.

Base 3.23.7/build57, ZIP SHA-256
`09231bd4086885eec610cebd8527d6107dabce0fa6cf3fa8844f99e3a3988b34`.
Bilhar/Cartas e os 18 JS/Lua não envolvidos permanecem byte a byte iguais à base.
Fontes/workflow precisam subir juntos. Compilação Apple, assinatura e teste no
iPhone não foram executados; nenhuma chamada ao servidor do jogo foi feita.
Contagens exatas em Validation/V3_23_8-validation.json.

## Histórico abaixo — não representa versão/build/validação atuais

# SDK Client 3.23.7 — build 57

Novo botão manual **Alpaca → engrenagem → Testar Penetrate (estoque 0)**. Exige
Auto OFF, Raio X ON, mesa própria estável e uma linha real de Penetrate com estoque
numérico exatamente zero. Estoque positivo, linha ausente ou ID não verificado
bloqueiam sem envio. Cada clique autoriza no máximo uma chamada original
`Socket.UseProp`; não cria poder, não muda estoque e não repete automaticamente.

O menu separa pedido observado, resposta correspondente e efeito confirmado.
`200` sem efeito não libera outra tentativa Penetrate; `500` permanece recusa
conhecida mesmo se a recuperação demorar. Corrigida a classificação indevida de
recusa já observada como ausência de resposta. A recusa do servidor não foi
contornada. O botão **Exportar relatório do teste** continua somente leitura,
com o tipo de tentativa e diagnóstico fechado da última leitura acrescentados.

Leia **Analysis/V3_23_7-penetrate-zero.md** para condições, protocolo, evidência e
teste no aparelho. Base: 3.23.6/build 56, fontes ZIP SHA-256
`f465f1d08652abe557d8c56f122e02f3040a3c25548771cbed2e4279b8c6a36e`.
Bilhar/Cartas e 17 recursos JS/Lua não envolvidos continuam byte a byte iguais.

**Estado desta entrega:** fontes + workflow pareados, testes portáteis registrados
em Validation/V3_23_7-validation.json. Não há compilação Apple, assinatura, teste
no iPhone ou aceitação real do servidor comprovados nesta versão. GitHub Actions
não foi iniciado por este agente; última tentativa autenticada retornou HTTP 401.
Subir o ZIP na raiz e o workflow em .github/workflows/compilar.yml juntos e executar
o commit novo. Não misturar ZIP e workflow de versões diferentes.

## Histórico 3.23.6 e anteriores — não representa o build atual

# SDK Client 3.23.6 — build 56

Corrige o acesso ao diagnóstico: **Alpaca → engrenagem → Exportar relatório do teste**. Exportação nativa somente leitura do último estado observado, disponível inclusive durante pendência/incerteza ou sem partida. Não envia outra tentativa, não consulta WebKit e não libera travas. JSON pequeno com campos fechados e até 24 eventos, para salvar em Arquivos ou compartilhar. Veja Analysis/V3_23_6-covered-report.md.

Base imediata: fontes imutáveis 3.23.5/build55, SHA-256 db81ba1afe8ead5f117f004a6c632df338fa853ef5f26c81686edb1b16e9b7f4. Nenhuma mudança no protocolo ou tentativa de corrigir a recusa 500. Todos os recursos JS/Lua são preservados. Atualizar/reiniciar não recupera o resultado antigo em memória nem a mensagem do servidor que não foi exportada.

Fontes e workflow pareados; **nenhum IPA 3.23.6 foi compilado ou testado fisicamente por este agente**. Resultados locais estão em Validation/V3_23_6-validation.json; macOS/Foundation e build Apple permanecem etapas próprias.

Validação local da 3.23.6: **780 JavaScript aprovados; 112 Python aprovados e 4 ignorados por dependência de compilador**, zero falhas. Inclui 5 contratos do novo botão e 4 do exportador passivo. Fixture Foundation do serializer, gravação e API de produção está ligado à CI macOS, mas não executou no Windows.

## Histórico 3.23.5 / build55 — não é o estado de build da versão atual

# SDK Client 3.23.5 — build 55

3.23.5 acrescenta o botão manual **Testar 1 carta coberta** nos ajustes compactos do Alpaca. Não há ativação automática nem chave persistente do experimento: cada clique solicita uma única tentativa, com **Auto desligado**, Raio X atual e mesa própria estável. Usa o evento original da carta; bloqueia autoplay, poderes e outra tentativa enquanto acompanha o envelope real e a Promise original correspondentes; depois exige dois snapshots completos consistentes por pelo menos 80 ms. Timeout ou envio incerto não dispara retry. ACK 200 é aceitação protocolar, não garantia de efeito nem prova de que o servidor permite todas as cartas cobertas. Ver `Analysis/V3_23_5-covered-card.md`.

Base imutável desta entrega: **3.23.4/build 54**, commit `bc14dc64c299f2ce8fac676677f300ce088f0a98`, fontes SHA-256 `951df789de4791dcd920512d15eddc4b97ac89fbeefadfec33857135f8efa3ae`. Retomada do Alpaca, Raio X dos quatro cantos, Bilhar e Cartas são preservados. Testes portáteis, build Apple, assinatura e execução física são etapas distintas; editar fontes não comprova execução no aparelho.

Validação local **3.23.5**: **780 testes JavaScript aprovados**; Python **103 aprovados e 4 ignorados por dependência de compilador**, zero falhas. O workflow e o ZIP passam juntos pelo preflight com manifesto/hash. **Compilação Apple e IPA desta versão ainda não produzidos:** GitHub recusou autenticação (HTTP 401). Nenhuma instalação ou aceitação real do servidor foi testada no iPhone. Consulte `Validation/V3_23_5-validation.json` para o registro desta versão.

3.23.4 corrige a retomada do Alpaca: respeita travas globais durante HotTime e modos temporários, reconcilia ações pendentes consumidas com a mesa atual e preserva dicas de trio independentes. Ao assistir aliados, as dicas ficam ocultas; voltam ao retornar à própria mesa. Ver `Analysis/V3_23_4-alpaca-resume.md`.

Histórico do redesenho 3.23.0: partiu de main `634e9734c39d1e5ed79b115ae75b0ceba5874332`, SDKtools 3.22.1/build 49, atendendo ao feedback sobre menu grande, texto cortado e tarjas sobre a partida. A base imediata atual é a 3.23.4 indicada acima.

3.23.3 redesenha o Raio X: até quatro ícones por card exposto, dois nos cantos superiores e dois nos inferiores. Silhueta preta atrás do ícone e contorno no número substituem placas, fundos e contador sobre o centro. A profundidade agora vai de uma a quatro camadas; uma preferência antiga de cinco é limitada a quatro. Ícones e números se ajustam juntos ao tamanho do card e seguem sua transformação. Ver `Analysis/V3_23_3-xray-corners.md`.

A base 3.23.2 corrige o bloqueio de comandos quando o próprio Bilhar é hospedado em um controlador apresentado pelo app. Menu e runtime usam a mesma verificação: a tela da frente deve conter o jogo, estar estável e receber o toque. Chat, janelas sobrepostas e troca de jogo continuam bloqueando ações. O aviso distingue jogo ausente de bloqueio temporário. Ver `Analysis/V3_23_2-billiards-host.md`.

O popup UIKit tem até **288 × 380 pt (altura limitada também a 82% da área segura)**, com altura ajustada ao conteúdo e à área segura. Exibe uma aba por vez: Alpaca, Cartas ou Bilhar. A aba do jogo identificado recebe destaque laranja; as outras ficam escurecidas e seus comandos permanecem bloqueados. Consultar uma aba não muda a identidade do jogo. Ao trocar de minijogo, a aba correspondente é selecionada automaticamente.

Usa logos e ícones locais SDK, Syne nas abas, Geist nos controles e Martian Mono na versão. Fontes do popup têm escala limitada para evitar que ultrapassem os controles. Alvos de toque têm pelo menos 44 pt e conteúdo adicional rola dentro do painel. O ícone flutuante de 44 × 44 pt pode ser arrastado e acompanha a área segura. O popup recolhe esse ícone enquanto aberto e tem botão próprio para minimizar.

Alpaca apresenta Auto, Raio X e uma barra de ícones para três poderes, confirmação e armazém. A engrenagem abre Turbo, planejamento e uso de poderes do estoque. A profundidade aparece com o Raio X ativo. Cartas tem marcadores; Bilhar tem Guia, Mira e Auto. Ícones possuem nomes traduzidos para VoiceOver. Indicações de consumo de estoque e pausa após toque manual continuam acessíveis.

O globo abre uma lista pequena English/Português dentro do popup. A preferência salva em `SDKClient.language` permanece; mudar idioma atualiza as views existentes sem reiniciar módulos, apresentar outro controlador ou emitir comandos. O catálogo tipado cobre os rótulos curtos e mensagens de todos os módulos. Website e YouTube são somente ícones discretos, desabilitados e identificados como Em breve na acessibilidade; destinos futuros continuam em `Brand/client-links.json`. Não há Instagram, Discord ou Telegram.

Minimizado, o estado aparece somente em texto verde, sem fundo, junto ao símbolo: Auto, Raio X, Cartas, Guia ou Mira; Auto e Raio X podem aparecer juntos. Avisos completos ficam dentro do popup. A tarja detalhada do Bilhar também foi removida; o estado é apresentado uma única vez. O texto não recebe toques nem bloqueia a partida.

Esta revisão corrige a suspensão sob chat, teclado e emojis e os bloqueios de Mira/Auto do Bilhar; consulte Analysis/V3_23_1-chat-billiards.md. Novos comandos exigem contexto visível e correto. Respostas já enviadas são aceitas apenas no mesmo host e documento, mesmo sob uma janela temporária. Erros reais, timeouts e ações incertas mantêm suas proteções. Sair do jogo correspondente interrompe os recursos; reabrir o menu pausa a automação do Bilhar. A janela permanece não principal e deixa toques fora do popup passarem ao jogo. Ferramentas internas não têm botões de debug, captura ou exportação no menu do cliente.

Validação histórica do redesenho **3.23.0**, não contagem desta entrega: 691 testes JavaScript; catálogo bilíngue e cobertura das bindings; prévia HTML em seis tamanhos, quatro contextos e dois idiomas (48 casos), incluindo controles bloqueados, preferência persistida, ajustes e indicadores sem tarja. STCompactMenuLayout.h é usado pelo layout UIKit e por testes C de limites e estados ligados à CI. A prévia é referência de design, não execução UIKit. Build iPhoneOS, integração no IPA, assinatura, instalação e teste físico são etapas separadas; os resultados da 3.23.5 estão no início deste documento.

O workflow compila exclusivamente SDKtools_Fontes.zip com manifesto SHA-256. ZIP, versão/build, manifesto, tamanho e hash do workflow são atualizados juntos. Um IPA só pode ser entregue depois da compilação e integração concluídas; este pacote 3.23.5 contém fontes e workflow pareados, não um IPA novo.

3.23.1: identidade passiva separada da autorização de comandos; chat suspende ações e retoma com novo preparo; Bilhar confirma frames em cadência lenta sem estender o TTL de desenho e não interpreta o botão de configurações habilitado como janela aberta.

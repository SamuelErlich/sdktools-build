// Production export helpers; private fixture files, no game or LAN side effects.
#import <Foundation/Foundation.h>
#import "license_gate_stub.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
@interface STRecorder:NSObject
@property BOOL lanSharingEnabled;
@property (nonatomic,strong) NSURL *lanExportURL;
@property (nonatomic,copy) NSString *lanExportID;
@property (nonatomic,copy) NSString *lanExportState;
@property NSUInteger lanExportBytes;
@property NSUInteger lanExportGeneration;
@end
@implementation STRecorder
#include "lan_export.inc"
@end
int main(void){@autoreleasepool{
    STRecorder *r=[STRecorder new];r.lanSharingEnabled=YES;r.lanExportGeneration=7;r.lanExportState=@"collecting";
    [r lanFinishExport:nil generation:6];assert([r.lanExportState isEqual:@"collecting"]);
    [r lanFinishExport:nil generation:7];assert([r.lanExportState isEqual:@"error"]);
    NSURL *documents=[NSFileManager.defaultManager URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:NULL];
    NSURL *folder=[documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES];
    assert([NSFileManager.defaultManager createDirectoryAtURL:folder withIntermediateDirectories:YES attributes:nil error:NULL]);
    NSURL *file=[folder URLByAppendingPathComponent:[NSString stringWithFormat:@"fixture-%@.json",NSUUID.UUID.UUIDString]];
    NSMutableData *bytes=[NSMutableData dataWithLength:300000];memset(bytes.mutableBytes,65,bytes.length);assert([bytes writeToURL:file atomically:YES]);
    [r lanFinishExport:file generation:7];assert([r.lanExportState isEqual:@"ready"]&&r.lanExportBytes==300000&&r.lanExportID.length==36);
    NSString *identifier=r.lanExportID;
    NSDictionary *first=[r lanDownloadChunk:@{@"exportID":identifier,@"offset":@0}],*last=[r lanDownloadChunk:@{@"exportID":identifier,@"offset":@262144}];
    assert([first[@"data"] length]==262144&&[last[@"data"] length]==37856);
    NSMutableData *joined=[first[@"data"] mutableCopy];[joined appendData:last[@"data"]];assert([joined isEqual:bytes]);
    assert((![[r lanDownloadChunk:@{@"exportID":@"wrong",@"offset":@0}][@"ok"] boolValue]));
    assert((![[r lanDownloadChunk:@{@"exportID":identifier,@"offset":@300000}][@"ok"] boolValue]));
    STTestLicenseAuthorized=NO;
    assert((![[r lanDownloadChunk:@{@"exportID":identifier,@"offset":@0}][@"ok"] boolValue]));
    r.lanExportState=@"collecting";[r lanFinishExport:file generation:7];
    assert([r.lanExportState isEqual:@"collecting"] && [NSFileManager.defaultManager fileExistsAtPath:file.path]);
    STTestLicenseAuthorized=YES;
    NSURL *outside=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"outside-%@.json",NSUUID.UUID.UUIDString]]];
    assert([bytes writeToURL:outside atomically:YES]);[r lanFinishExport:outside generation:7];assert([r.lanExportState isEqual:@"error"]);
    r.lanSharingEnabled=NO;[r lanFinishExport:file generation:7];assert([r.lanExportState isEqual:@"error"]);
    [NSFileManager.defaultManager removeItemAtURL:file error:NULL];[NSFileManager.defaultManager removeItemAtURL:outside error:NULL];
    puts("LAN production export generation/path/chunks: passed");
}return 0;}

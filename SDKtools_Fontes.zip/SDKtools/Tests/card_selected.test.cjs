'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {fixture}=require('./card_selected_fixture.cjs');
const {graphic,plain}=require('./card_hints_fixture.cjs');
const empty=()=>({id:0,type:0,color:0,num:0});
function known(f){const b=f.read()[0];assert.equal(b?.source,'select_give_card');assert.equal(b.color,2);assert.equal(f.reader.valid(b,f.first.nodes[0].c.node),true);return b;}
function noSelected(f){assert.ok(f.read().every(x=>!x||x.source!=='select_give_card'));}
test('actual state Play accepts an observed blue 9 in the unique hidden hand',()=>{const f=fixture();known(f);assert.equal(f.reader.stats().selectedKnown,1);});
test('renderer shows the hidden selected face with source counters and outer ring',()=>{
 const f=fixture(),before=JSON.stringify(f.store),r=f.overlay.tick();assert.equal(r.selectedShown,1);assert.equal(r.rootShown,1);assert.equal(r.unknown,0);
 assert.deepEqual(plain(graphic(f).fillColor),{r:17,g:135,b:255,a:255});assert.ok(graphic(f).commands.filter(x=>x[0]==='circle').length>=3);
 assert.equal(JSON.stringify(f.store),before);assert.equal(f.first.nodes[0].component.cardInfo.type,0);assert.equal(f.first.nodes[0].c.back.active,true);f.overlay.clear();
});
test('cleared selected field and cloned Store preserve a fact, not the old model object',()=>{
 const f=fixture();known(f);f.store.select_give_card=empty();f.cloneStore();f.setTime(1000);known(f);assert.notEqual(f.store.gamers[0],f.first.hand.gamer);
});
test('only exposed cards are colored, not every unknown card in that hand',()=>{
 const f=fixture({cards:[{id:98,type:0,color:0,num:0},{id:46,type:0,color:0,num:0}]}),r=f.read();assert.equal(r[0].color,2);assert.notEqual(r[1]?.source,'select_give_card');
});
test('plain Back without a selected observation never gains a color',()=>{const f=fixture({selected:empty()});noSelected(f);assert.equal(f.reader.stats().selectedRetained,0);});
test('selected card outside all hands cannot be used as a guessed hand color',()=>{const f=fixture();f.store.select_give_card.id=25;noSelected(f);});
test('duplicate IDs across hands reject the observation',()=>{const f=fixture();f.addHand('owner-1',[{id:98,type:0,color:0,num:0}]);noSelected(f);});
test('duplicate owners reject the observation',()=>{const f=fixture();f.addHand('owner-3',[{id:50,type:0,color:0,num:0}]);noSelected(f);});
test('ID also in discarded cards is rejected',()=>{const f=fixture();f.store.discard_cards=[{id:98,type:1,color:2,num:9}];noSelected(f);});
test('incomplete UI hand is not associated solely by one matching ID',()=>{
 const f=fixture();f.store.gamers[0].cards.push({id:46,type:0,color:0,num:0});noSelected(f);assert.equal(f.reader.stats().selectedRetained,1);
});
test('wrong UI hand owner cannot receive the color',()=>{const f=fixture();f.first.hand.uid='other';noSelected(f);});
test('wrong retained gamer owner cannot receive the color',()=>{const f=fixture();f.first.hand.gamer.uid='other';noSelected(f);});
test('UI residual color is not promoted through the selected path',()=>{const f=fixture();f.first.nodes[0].component.cardInfo.color=4;noSelected(f);});
test('node reuse and new unknown ID cannot inherit the selected face',()=>{
 const f=fixture();known(f);f.store.select_give_card=empty();f.first.nodes[0].component.cardInfo={id:46,type:0,color:0,num:0};f.store.gamers[0].cards=[{id:46,type:0,color:0,num:0}];f.setTime(100);noSelected(f);
});
test('removal and reinsertion in the same round never resurrect a retired fact',()=>{
 const f=fixture();known(f);const cards=f.store.gamers[0].cards;f.store.gamers[0].cards=[];noSelected(f);f.store.gamers[0].cards=cards;noSelected(f);assert.equal(f.reader.stats().selectedRetained,0);
});
test('owner transfer retires even if stale selected field remains nonzero',()=>{
 const f=fixture();known(f);f.store.gamers[0].uid='new-owner';f.first.hand.uid='new-owner';f.first.hand.gamer.uid='new-owner';noSelected(f);
 f.store.gamers[0].uid='owner-3';f.first.hand.uid='owner-3';f.first.hand.gamer.uid='owner-3';noSelected(f);
});
test('conflicting face retires the ID for this round',()=>{const f=fixture();known(f);f.store.select_give_card.color=4;noSelected(f);f.store.select_give_card.color=2;noSelected(f);});
test('new round clears all retained facts',()=>{const f=fixture();known(f);f.store.select_give_card=empty();f.store.start_time++;noSelected(f);});
test('socket replacement clears all retained facts',()=>{const f=fixture();known(f);f.store.select_give_card=empty();f.socket.socket={};noSelected(f);});
test('missing socket never creates a selected fact',()=>{const f=fixture();f.socket.socket=null;noSelected(f);});
test('round token absent or zero does not authorize a selected fact',()=>{for(const v of [undefined,0,NaN,'']){const f=fixture();f.store.start_time=v;noSelected(f);}});
test('Ended and Destroy clear observations',()=>{for(const state of [7,8]){const f=fixture();known(f);f.store.state=state;noSelected(f);}});
test('large read gaps and clock reversal discard retained information',()=>{for(const t of [1600,-1]){const f=fixture();known(f);f.store.select_give_card=empty();f.setTime(t);noSelected(f);}});
test('120 second age cap cannot be renewed by an unchanging selected field',()=>{
 const f=fixture();known(f);for(let t=1000;t<=120000;t+=1000){f.setTime(t);known(f);}f.setTime(120001);noSelected(f);
});
test('invalid selected fields and accessor data are not coerced or invoked',()=>{
 for(const face of [{id:98,type:1,color:0,num:9},{id:98,type:1,color:2,num:0},{id:98,type:3,color:2,num:9},{id:98,type:99,color:2,num:0},{id:true,type:1,color:2,num:9}]){const f=fixture({selected:face});noSelected(f);}
 let reads=0;const s={id:98,type:1,num:9};Object.defineProperty(s,'color',{get(){reads++;return 2;}});noSelected(fixture({selected:s}));assert.equal(reads,0);
});
test('special selected types retain special zero, never the current table color',()=>{
 for(const type of [4,6,10]){const f=fixture({selected:{id:98,type,color:0,num:0}});f.store.color=4;const b=f.read()[0];assert.equal(b?.source,'select_give_card');assert.equal(b.color,0);}
});
test('changed Store during geometry cannot publish a selected marker',()=>{
 const f=fixture(),c=f.first.nodes[0].c,original=c.node.convertToWorldSpaceAR.bind(c.node);let done=false;
 c.node.convertToWorldSpaceAR=p=>{if(!done){done=true;f.cloneStore();}return original(p);};assert.equal(f.overlay.tick().selectedShown,0);assert.equal(f.hints().length,0);
});
test('changed socket during geometry cannot publish a selected marker',()=>{
 const f=fixture(),c=f.first.nodes[0].c,original=c.node.convertToWorldSpaceAR.bind(c.node);let done=false;
 c.node.convertToWorldSpaceAR=p=>{if(!done){done=true;f.socket.socket={};}return original(p);};assert.equal(f.overlay.tick().selectedShown,0);
});
test('clear and scene replacement discard facts',()=>{
 const f=fixture();known(f);f.store.select_give_card=empty();f.reader.clear();noSelected(f);
 const g=fixture();known(g);g.store.select_give_card=empty();g.newScene();noSelected(g);
});
test('does not send, play, sync, rewrite cards or invoke gameplay methods',()=>{
 const f=fixture();for(const name of ['send','play','sync','endLookOver'])f.socket[name]=()=>{throw Error('gameplay call');};
 Object.freeze(f.store.select_give_card);Object.freeze(f.store.gamers[0].cards[0]);Object.freeze(f.store.gamers[0].cards);Object.freeze(f.store.gamers[0]);Object.freeze(f.store.gamers);Object.freeze(f.store);
 known(f);assert.deepEqual(f.calls,['Card','GameStore','Socket']);
});

#include "../Sources/SDKtools/STClientGamePolicy.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    STClientGame games[]={STClientGameNone,STClientGameAlpaca,STClientGameCards,STClientGameBilliards};
    unsigned checks=0;
    for (unsigned active=0;active<4;active++) for(unsigned requested=0;requested<4;requested++) {
        assert(STClientCanModify(games[active],games[requested])==(active==requested && active!=0)); checks++;
        assert(STClientCanToggle(games[active],games[requested],true)); checks++;
        assert(STClientCanToggle(games[active],games[requested],false)==STClientCanModify(games[active],games[requested])); checks++;
    }
    /* Lobby, closing/loading and an unsupported identity must stay locked. */
    for(unsigned i=1;i<4;i++) { assert(!STClientCanModify((STClientGame)9999,games[i])); checks++; }
    printf("%u client game policy checks passed\n",checks); return 0;
}

"""Portable native-wiring checks; UIKit/Foundation execution requires macOS."""
import ast
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]

class AlpacaWinContracts(unittest.TestCase):
    def read(self,path):
        return (ROOT/path).read_text(encoding='utf-8')

    def test_foundation_harness_declares_and_exercises_new_production_dependencies(self):
        harness=self.read('Tests/covered_recorder_test.m')
        extractor=self.read('scripts/test_autoplay_bridge.sh')
        self.assertIn('observation_end=source.index(\'- (void)setXrayEnabled:\'',extractor)
        for declaration in ['@property BOOL winAnalysisEnabled;', '@property(nonatomic,getter=isRecording) BOOL recording;',
                            '@property BOOL sourceExportBusy;', '@property(nonatomic,copy) NSDictionary *autoplayReadingDiagnostic;',
                            '@property NSTimeInterval lanReadingAt;', 'static NSTimeInterval STNow(void)', '@interface UIApplication : NSObject']:
            self.assertIn(declaration,harness)
        for exercise in ['[r setWinAnalysisEnabled:YES]', 'r.autoplayTimer.timeInterval>=0.2', 'UIApplicationStateInactive',
                         'STTestLicenseAuthorized=NO', 'testNow+=2', 'safeForecast()', 'r.autoplayResponsePending=YES']:
            self.assertIn(exercise,harness)

    def test_factory_resource_is_required_and_size_bounded(self):
        web=self.read('Sources/SDKtools/STWebProbe.m')
        bridge=self.read('Sources/SDKtools/STAutoplayBridge.inc')
        self.assertIn('_winScript = source;',web)
        self.assertIn('!self.winScript.length',bridge)
        self.assertIn('self.hotTimeScript, self.winScript,',bridge)
        self.assertIn('Resources/alpaca_win.js',self.read('scripts/build_framework.sh'))
        tree=ast.parse(self.read('scripts/integrate_ipa.py'))
        self.assertIn('alpaca_win.js',[n.value for n in ast.walk(tree) if isinstance(n,ast.Constant)])
        self.assertLess((ROOT/'Resources/alpaca_win.js').stat().st_size,65536)
        self.assertLess((ROOT/'Resources/autoplay_tool.js').stat().st_size,65536)

    def test_passive_timer_does_not_arm_play_or_change_game_permissions(self):
        recorder=self.read('Sources/SDKtools/STAutoplayRecorder.inc')
        setter=recorder.split('- (void)setWinAnalysisEnabled:',1)[1].split('- (NSString *)winAnalysisStatusText',1)[0]
        self.assertIn('STLicenseAllowsFeatures()',setter)
        self.assertIn('UIApplicationStateActive',setter)
        self.assertIn('ensureAutoplayTimer',setter)
        self.assertNotIn('startAutoplay',setter)
        self.assertNotIn('autoplayEnabled=',setter)
        self.assertIn('!self.winAnalysisEnabled && !self.lanSharingEnabled',recorder)
        self.assertIn('interval=MAX(interval,0.2)',recorder)
        self.assertIn('if(!strongSelf.xrayEnabled && !strongSelf.winAnalysisEnabled && ![strongSelf autoplayHasPendingObservation])',recorder)
        self.assertIn('self.autoplayEvaluationMayAct=actionAllowed || experimental;',recorder)
        bridge=self.read('Sources/SDKtools/STAutoplayBridge.inc')
        self.assertEqual(bridge.count('winAnalysisEnabled:%@'),2)
        self.assertIn('STLicenseAllowsFeatures() ? @"true" : @"false"',bridge)

    def test_ui_starts_on_verified_game_and_keeps_hud_touch_through(self):
        ui=self.read('Sources/SDKtools/STOverlay.m')
        self.assertIn('[r setWinAnalysisEnabled:authorized && self.activeGame==STClientGameAlpaca]',ui)
        self.assertIn('self.winAnalysisHUD.userInteractionEnabled=NO',ui)
        self.assertIn('STSetLabelText(self.winAnalysisHUD,r.winAnalysisStatusText)',ui)
        hits=ui.split('- (BOOL)acceptsPoint:(CGPoint)point {',1)[1].split('- (void)togglePanel',1)[0]
        self.assertNotIn('winAnalysisHUD',hits)
        self.assertIn('[self setWinAnalysisEnabled:NO]',self.read('Sources/SDKtools/STRecorder.m'))
        self.assertIn('fresh&&[phase[@"counts"][@"tray"] unsignedIntegerValue]<7',self.read('Sources/SDKtools/STLANRecorder.inc'))

    def test_closed_forecast_crosses_evaluation_and_last_reading_boundaries(self):
        sanitizer=self.read('Sources/SDKtools/STAutoplaySanitizer.inc')
        self.assertEqual(sanitizer.count('STWPSanitizeWinAnalysis(value[@"winAnalysis"])'),2)
        helper=sanitizer.split('static NSDictionary *STWPSanitizeWinAnalysis',1)[1].split('static NSDictionary *STWPSanitizeAutoplay(',1)[0]
        self.assertNotIn('addEntriesFromDictionary',helper)
        self.assertIn('(n==0 && !impossible)',helper)
        self.assertIn('(n==100 && !exact)',helper)
        self.assertIn('CFBooleanGetTypeID()',helper)
        self.assertIn('@"winAnalysis"',self.read('Sources/SDKtools/STAutoplayRecorder.inc'))

    def test_copy_explains_unknown_and_the_local_model_in_both_languages(self):
        rows=json.loads(self.read('Resources/Brand/menu-localizations.json'))['entries']
        aliases={v for r in rows for v in r.values()}
        for text in ['Win local: — · aguardando mesa completa e estável','comprovado no modelo',
                     'estimativa','sem poderes/ajuda','sem espaço para trio','%lu pares expostos']:
            self.assertIn(text,aliases)
        producer=self.read('Sources/SDKtools/STAutoplayRecorder.inc').split('- (NSString *)winAnalysisStatusText',1)[1].split('- (void)setXrayEnabled',1)[0]
        self.assertIn('p>0 && p<1',producer)
        self.assertIn('p>99 && p<100',producer)
        self.assertIn('STNow()-self.lanReadingAt>1.0',producer)

if __name__=='__main__':
    unittest.main()

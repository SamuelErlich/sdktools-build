"""Behavioral tests for the conservative integrator, using synthetic binaries."""
import hashlib
import json
from pathlib import Path
import plistlib
import stat
import struct
import sys
import tempfile
import unittest
import warnings
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from macho import parse, inject, MachOError, dylib_command, INSTALL_NAME, LOAD_PATH
from integrate_ipa import integrate, checked_entries, preflight_zip, IntegrationError


def binary(filetype=2, *, platform=2, cryptid=0, first=1024, signature=True, padding_byte=0, custom=None):
    segment = bytearray(struct.pack('<II16s4Q4I', 0x19, 152, b'__TEXT', 0x100000000, 4096, 0, 4096, 7, 5, 1, 0))
    segment += struct.pack('<16s16sQQ8I', b'__text', b'__TEXT', 0x100000000 + first, 64, first, 2, 0, 0, 0x80000400, 0, 0, 0)
    commands = [bytes(segment), struct.pack('<6I',0x32,24,platform,0xF0000,0x120000,0), struct.pack('<II16s',0x1B,24,b'uuid-16-bytes-123'), struct.pack('<6I',0x2C,24,first,64,cryptid,0), dylib_command('/usr/lib/libSystem.B.dylib')]
    if filetype == 6:
        name = bytearray(dylib_command(INSTALL_NAME)); struct.pack_into('<I',name,0,0xD);commands.append(bytes(name))
    else:
        commands.append(struct.pack('<IIQQ',0x80000028,24,first,0))
    if signature:
        commands.append(struct.pack('<4I',0x1D,16,4000,96))
    if custom: commands.append(custom)
    encoded=b''.join(commands)
    header=struct.pack('<8I',0xFEEDFACF,0x100000C,0,filetype,len(commands),len(encoded),0,0)
    data=bytearray(header+encoded+bytes(4096-32-len(encoded)))
    data[first:first+64]=b'\x1f\x20\x03\xd5'*16
    data[4000:]=b'S'*96
    if padding_byte: data[32+len(encoded)]=padding_byte
    return bytes(data)


def make_fixture(root):
    app=binary()
    info={'CFBundleIdentifier':'com.example.test','CFBundleShortVersionString':'1.0','CFBundleVersion':'1','CFBundleExecutable':'Demo','MinimumOSVersion':'15.0'}
    ipa=root/'base.ipa'
    with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('Payload/Demo.app/Info.plist',plistlib.dumps(info))
        z.writestr('Payload/Demo.app/Demo',app)
        z.writestr('Payload/Demo.app/data.txt',b'unchanged data')
        z.writestr('Payload/Demo.app/_CodeSignature/CodeResources',b'obsolete')
        z.writestr('Payload/Demo.app/embedded.mobileprovision',b'obsolete')
    identity={'ipa_sha256':hashlib.sha256(ipa.read_bytes()).hexdigest(),'ipa_bytes':ipa.stat().st_size,'app_path':'Payload/Demo.app','bundle_id':'com.example.test','version':'1.0','build':'1','minimum_ios':'15.0','executable':'Demo','executable_sha256':hashlib.sha256(app).hexdigest()}
    config=root/'identity.json';config.write_text(json.dumps(identity))
    framework=root/'SDKtools.framework';framework.mkdir()
    (framework/'SDKtools').write_bytes(binary(6))
    for resource in ('scene_probe.js', 'return_tool.js', 'autoplay_tool.js', 'autoplay_planner.js'):
        (framework/resource).write_text('(function(){return function(){return {};};}())')
    (framework/'Info.plist').write_bytes(plistlib.dumps({'CFBundleExecutable':'SDKtools','CFBundlePackageType':'FMWK','CFBundleSupportedPlatforms':['iPhoneOS'],'MinimumOSVersion':'15.0','CFBundleVersion':'9','CFBundleShortVersionString':'2.7','SDKToolsTargetBundleIdentifier':identity['bundle_id'],'SDKToolsTargetVersion':identity['version'],'SDKToolsTargetBuild':identity['build'],'SDKToolsTargetExecutable':identity['executable']}))
    return ipa,framework,config


class MachOTests(unittest.TestCase):
    def test_append_preserves_code_and_dependency_ordinals(self):
        data=binary();before=parse(data)
        out,report=inject(data);after=parse(out)
        self.assertEqual(after.dependencies,before.dependencies+(LOAD_PATH,))
        self.assertEqual(out[1024:],data[1024:])
        self.assertEqual(before.of_type(0x19),after.of_type(0x19))
        self.assertEqual(after.of_type(0x1D),())
        self.assertEqual(report['removed_signature_commands'],1)
        self.assertEqual(hashlib.sha256(data).hexdigest(),report['before_sha256'])

    def test_preserve_all_non_signature_commands(self):
        before=parse(binary());after=parse(inject(before.data)[0])
        self.assertEqual(after.commands[:-1],tuple(c for c in before.commands if struct.unpack_from('<I',c)[0]!=0x1D))

    def test_no_signature_still_injects(self):
        self.assertEqual(inject(binary(signature=False))[1]['removed_signature_commands'],0)

    def test_reject_insufficient_padding(self):
        with self.assertRaises(MachOError): inject(binary(first=400))

    def test_reject_nonzero_padding(self):
        with self.assertRaises(MachOError): inject(binary(padding_byte=1))

    def test_reject_simulator_arm64(self):
        with self.assertRaisesRegex(MachOError,'iPhoneOS'): parse(binary(platform=7))

    def test_reject_encrypted(self):
        with self.assertRaisesRegex(MachOError,'cifragem'): inject(binary(cryptid=1))

    def test_reject_unknown_command(self):
        with self.assertRaisesRegex(MachOError,'não suportado'): inject(binary(custom=struct.pack('<II',0x777,8)))

    def test_reject_repeated_integration(self):
        with self.assertRaisesRegex(MachOError,'já está integrado'): inject(inject(binary())[0])

    def test_reject_truncated_commands(self):
        with self.assertRaises(MachOError): parse(binary()[:100])

    def test_reject_bad_command_size(self):
        data=bytearray(binary());struct.pack_into('<I',data,36,9)
        with self.assertRaises(MachOError): parse(data)

    def test_reject_payload_overlapping_commands(self):
        data=bytearray(binary());struct.pack_into('<I',data,32+72+48,64)
        with self.assertRaises(MachOError): parse(data)

    def test_reject_hidden_linkedit_in_slack(self):
        data=binary(custom=struct.pack('<4I',0x26,16,512,8))
        m=parse(data);self.assertEqual(m.first_payload,512)
        # The command addition must not overwrite even zero LINKEDIT payload.
        commands=list(m.commands)
        # Demand a path whose command crosses that payload boundary.
        from macho import rebuild
        with self.assertRaises(MachOError): rebuild(m,commands+[dylib_command('/'+('a'*200))])


class ArchiveTests(unittest.TestCase):
    def make_zip(self,root,names):
        path=root/'test.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(path,'w') as z:
                for name in names: z.writestr(name,b'x')
        return path

    def test_reject_traversal(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['../escape'])
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_case_collision(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['a','A'])
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_file_directory_conflict(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['a','a/b'])
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_symlink(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'test.zip'
            with zipfile.ZipFile(path,'w') as z:
                entry=zipfile.ZipInfo('link');entry.create_system=3;entry.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(entry,b'other')
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_truncated_zip(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['a']);path.write_bytes(path.read_bytes()[:-5])
            with self.assertRaises(IntegrationError): preflight_zip(path)


class IntegrationTests(unittest.TestCase):
    def test_roundtrip_preserves_base_and_all_data(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);original=ipa.read_bytes();output=root/'new.ipa'
            result=integrate(ipa,framework,identity,output)
            self.assertEqual(ipa.read_bytes(),original)
            self.assertTrue(result['signing_required']);self.assertFalse(result['runtime_tested'])
            with zipfile.ZipFile(output) as z:
                self.assertEqual(z.read('Payload/Demo.app/data.txt'),b'unchanged data')
                self.assertNotIn('Payload/Demo.app/embedded.mobileprovision',z.namelist())
                self.assertEqual(parse(z.read('Payload/Demo.app/Demo')).dependencies[-1],LOAD_PATH)
                self.assertEqual(parse(z.read('Payload/Demo.app/Frameworks/SDKtools.framework/SDKtools')).of_type(0x1D),())
                self.assertTrue((z.getinfo('Payload/Demo.app/Demo').external_attr>>16)&0o111)
            self.assertTrue(output.with_suffix('.manifest.json').is_file())

    def test_existing_output_never_replaced(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);output=root/'new.ipa';output.write_bytes(b'original')
            with self.assertRaises(IntegrationError): integrate(ipa,framework,identity,output)
            self.assertEqual(output.read_bytes(),b'original')

    def test_wrong_base_hash_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);ipa.write_bytes(ipa.read_bytes()+b'x')
            with self.assertRaises(IntegrationError): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_simulator_framework_rejected_without_output(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);(framework/'SDKtools').write_bytes(binary(6,platform=7))
            with self.assertRaises(MachOError): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_older_framework_version_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            plist=framework/'Info.plist';info=plistlib.loads(plist.read_bytes())
            info['CFBundleShortVersionString']='2.6';info['CFBundleVersion']='8'
            plist.write_bytes(plistlib.dumps(info))
            with self.assertRaisesRegex(IntegrationError,'2.7'): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_required_tool_resource_missing_rejected_without_output(self):
        for resource in ('scene_probe.js', 'return_tool.js', 'autoplay_tool.js', 'autoplay_planner.js'):
            with self.subTest(resource=resource), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root)
                (framework/resource).unlink()
                with self.assertRaisesRegex(IntegrationError,'Recurso obrigatório'):
                    integrate(ipa,framework,identity,root/'new.ipa')
                self.assertFalse((root/'new.ipa').exists())

    def test_oversized_tool_resource_rejected_without_output(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            (framework/'return_tool.js').write_bytes(b'x' * 65537)
            with self.assertRaisesRegex(IntegrationError,'Recurso obrigatório'):
                integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_framework_for_other_host_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            plist=framework/'Info.plist';info=plistlib.loads(plist.read_bytes())
            info['SDKToolsTargetBundleIdentifier']='com.example.other'
            plist.write_bytes(plistlib.dumps(info))
            with self.assertRaisesRegex(IntegrationError,'outra base'): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_missing_host_identity_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            plist=framework/'Info.plist';info=plistlib.loads(plist.read_bytes())
            del info['SDKToolsTargetExecutable']
            plist.write_bytes(plistlib.dumps(info))
            with self.assertRaisesRegex(IntegrationError,'sem identidade'): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_manifest_publication_failure_rolls_back_ipa(self):
        from unittest.mock import patch
        import integrate_ipa
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);output=root/'new.ipa';original_publish=integrate_ipa.publish
            def publish_once(source,target):
                if target.suffix=='.json': raise OSError('synthetic publish failure')
                original_publish(source,target)
            with patch.object(integrate_ipa,'publish',side_effect=publish_once), self.assertRaises(OSError): integrate(ipa,framework,identity,output)
            self.assertFalse(output.exists());self.assertFalse(output.with_suffix('.manifest.json').exists())


if __name__=='__main__':
    unittest.main()

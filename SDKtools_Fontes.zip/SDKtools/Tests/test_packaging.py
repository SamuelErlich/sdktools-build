"""Behavioral tests for the conservative integrator, using synthetic binaries."""
import hashlib
import json
from pathlib import Path
import plistlib
import shutil
import stat
import struct
import sys
import tempfile
import unittest
import warnings
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from macho import parse, inject, MachOError, dylib_command, INSTALL_NAME, LOAD_PATH
from integrate_ipa import integrate, checked_entries, preflight_zip, framework_files, validate_localization_catalog, IntegrationError


def binary(filetype=2, *, platform=2, cryptid=0, first=1024, signature=True, padding_byte=0, custom=None):
    segment = bytearray(struct.pack('<II16s4Q4I', 0x19, 152, b'__TEXT', 0x100000000, 4096, 0, 4096, 7, 5, 1, 0))
    segment += struct.pack('<16s16sQQ8I', b'__text', b'__TEXT', 0x100000000 + first, 64, first, 2, 0, 0, 0x80000400, 0, 0, 0)
    commands = [bytes(segment), struct.pack('<6I',0x32,24,platform,0xF0000,0x120000,0), struct.pack('<II16s',0x1B,24,b'uuid-16-bytes-123'), struct.pack('<6I',0x2C,24,first,64,cryptid,0), dylib_command('/usr/lib/libSystem.B.dylib')]
    if filetype == 6:
        name = bytearray(dylib_command(INSTALL_NAME)); struct.pack_into('<I',name,0,0xD);commands.append(bytes(name))
    else:
        commands.append(struct.pack('<IIQQ',0x80000028,24,first,0))
    if signature:
        commands.append(struct.pack('<4I',0x1D,16,4000,96))
    if custom: commands.append(custom)
    encoded=b''.join(commands)
    header=struct.pack('<8I',0xFEEDFACF,0x100000C,0,filetype,len(commands),len(encoded),0,0)
    data=bytearray(header+encoded+bytes(4096-32-len(encoded)))
    data[first:first+64]=b'\x1f\x20\x03\xd5'*16
    data[4000:]=b'S'*96
    if padding_byte: data[32+len(encoded)]=padding_byte
    return bytes(data)


def make_fixture(root):
    app=binary()
    info={'CFBundleIdentifier':'com.example.test','CFBundleShortVersionString':'1.0','CFBundleVersion':'1','CFBundleExecutable':'Demo','MinimumOSVersion':'15.0'}
    ipa=root/'base.ipa'
    with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('Payload/Demo.app/Info.plist',plistlib.dumps(info))
        z.writestr('Payload/Demo.app/Demo',app)
        z.writestr('Payload/Demo.app/data.txt',b'unchanged data')
        z.writestr('Payload/Demo.app/_CodeSignature/CodeResources',b'obsolete')
        z.writestr('Payload/Demo.app/embedded.mobileprovision',b'obsolete')
    identity={'ipa_sha256':hashlib.sha256(ipa.read_bytes()).hexdigest(),'ipa_bytes':ipa.stat().st_size,'app_path':'Payload/Demo.app','bundle_id':'com.example.test','version':'1.0','build':'1','minimum_ios':'15.0','executable':'Demo','executable_sha256':hashlib.sha256(app).hexdigest()}
    config=root/'identity.json';config.write_text(json.dumps(identity))
    framework=root/'SDKtools.framework';framework.mkdir()
    (framework/'SDKtools').write_bytes(binary(6))
    for resource in ('scene_probe.js', 'return_tool.js', 'autoplay_tool.js', 'autoplay_planner.js', 'autoplay_extended.js', 'autoplay_coop.js', 'autoplay_powers.js', 'alpaca_covered.js', 'alpaca_snapshot.js', 'alpaca_fast.js', 'alpaca_global.js', 'alpaca_global_runtime.js', 'alpaca_hottime.js', 'alpaca_win.js', 'xray_overlay.js', 'warehouse_tool.js', 'warehouse_test.js', 'card_hints.js', 'card_probe.js', 'card_flow.js', 'card_root.js', 'card_early.js', 'card_sampler.js'):
        (framework/resource).write_text('(function(){return function(){return {};};}())')
    (framework/'billiards_probe.lua').write_text('return "{}"')
    (framework/'billiards_strategy.lua').write_text('return {}')
    (framework/'billiards_context.lua').write_text('return "{}"')
    shutil.copytree(Path(__file__).resolve().parents[1]/'Resources/Brand',framework/'Brand')
    shutil.copytree(Path(__file__).resolve().parents[1]/'Resources/LAN',framework/'LAN')
    (framework/'Info.plist').write_bytes(plistlib.dumps({'CFBundleExecutable':'SDKtools','CFBundlePackageType':'FMWK','CFBundleSupportedPlatforms':['iPhoneOS'],'MinimumOSVersion':'15.0','CFBundleVersion':'87','CFBundleShortVersionString':'4.0.12','SDKToolsTargetBundleIdentifier':identity['bundle_id'],'SDKToolsTargetVersion':identity['version'],'SDKToolsTargetBuild':identity['build'],'SDKToolsTargetExecutable':identity['executable']}))
    return ipa,framework,config


class MachOTests(unittest.TestCase):
    def test_append_preserves_code_and_dependency_ordinals(self):
        data=binary();before=parse(data)
        out,report=inject(data);after=parse(out)
        self.assertEqual(after.dependencies,before.dependencies+(LOAD_PATH,))
        self.assertEqual(out[1024:],data[1024:])
        self.assertEqual(before.of_type(0x19),after.of_type(0x19))
        self.assertEqual(after.of_type(0x1D),())
        self.assertEqual(report['removed_signature_commands'],1)
        self.assertEqual(hashlib.sha256(data).hexdigest(),report['before_sha256'])

    def test_preserve_all_non_signature_commands(self):
        before=parse(binary());after=parse(inject(before.data)[0])
        self.assertEqual(after.commands[:-1],tuple(c for c in before.commands if struct.unpack_from('<I',c)[0]!=0x1D))

    def test_no_signature_still_injects(self):
        self.assertEqual(inject(binary(signature=False))[1]['removed_signature_commands'],0)

    def test_reject_insufficient_padding(self):
        with self.assertRaises(MachOError): inject(binary(first=400))

    def test_reject_nonzero_padding(self):
        with self.assertRaises(MachOError): inject(binary(padding_byte=1))

    def test_reject_simulator_arm64(self):
        with self.assertRaisesRegex(MachOError,'iPhoneOS'): parse(binary(platform=7))

    def test_reject_encrypted(self):
        with self.assertRaisesRegex(MachOError,'cifragem'): inject(binary(cryptid=1))

    def test_reject_unknown_command(self):
        with self.assertRaisesRegex(MachOError,'não suportado'): inject(binary(custom=struct.pack('<II',0x777,8)))

    def test_reject_repeated_integration(self):
        with self.assertRaisesRegex(MachOError,'já está integrado'): inject(inject(binary())[0])

    def test_reject_truncated_commands(self):
        with self.assertRaises(MachOError): parse(binary()[:100])

    def test_reject_bad_command_size(self):
        data=bytearray(binary());struct.pack_into('<I',data,36,9)
        with self.assertRaises(MachOError): parse(data)

    def test_reject_payload_overlapping_commands(self):
        data=bytearray(binary());struct.pack_into('<I',data,32+72+48,64)
        with self.assertRaises(MachOError): parse(data)

    def test_reject_hidden_linkedit_in_slack(self):
        data=binary(custom=struct.pack('<4I',0x26,16,512,8))
        m=parse(data);self.assertEqual(m.first_payload,512)
        # The command addition must not overwrite even zero LINKEDIT payload.
        commands=list(m.commands)
        # Demand a path whose command crosses that payload boundary.
        from macho import rebuild
        with self.assertRaises(MachOError): rebuild(m,commands+[dylib_command('/'+('a'*200))])

    def test_twolevel_hints_in_zero_padding_cannot_be_overwritten(self):
        # A zero-valued hint still occupies real file bytes, not header padding.
        data=binary(custom=struct.pack('<4I',0x16,16,400,4))
        self.assertEqual(data[400:416],bytes(16))
        self.assertEqual(parse(data).first_payload,400)
        with self.assertRaisesRegex(MachOError,'espaço legítimo'):
            inject(data)

    def test_twolevel_hints_after_header_are_preserved(self):
        data=bytearray(binary(custom=struct.pack('<4I',0x16,16,2048,4)))
        data[2048:2064]=bytes(range(16))
        out,_=inject(bytes(data))
        self.assertEqual(out[2048:2064],data[2048:2064])
        self.assertEqual(parse(out).of_type(0x16),parse(data).of_type(0x16))

    def test_reject_invalid_twolevel_hints_ranges_and_command(self):
        for command in (struct.pack('<II',0x16,8),
                        struct.pack('<4I',0x16,16,4092,2),
                        struct.pack('<4I',0x16,16,300,1),
                        struct.pack('<4I',0x16,16,1024,0xFFFFFFFF)):
            with self.subTest(command=command.hex()), self.assertRaises(MachOError):
                parse(binary(custom=command))


class ArchiveTests(unittest.TestCase):
    def make_zip(self,root,names):
        path=root/'test.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(path,'w') as z:
                for name in names: z.writestr(name,b'x')
        return path

    def test_reject_traversal(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['../escape'])
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_case_collision(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['a','A'])
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_implicit_parent_aliases(self):
        for names in (['Payload/Demo.app/Frameworks/a','Payload/Demo.app/frameworks/b'],
                      ['Payload/Café.app/a','Payload/Cafe\u0301.app/b']):
            for ordered in (names,list(reversed(names))):
                with self.subTest(names=ordered), tempfile.TemporaryDirectory() as t:
                    path=self.make_zip(Path(t),ordered)
                    with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError):
                        checked_entries(z)

    def test_accept_consistent_implicit_and_explicit_parents(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'test.zip'
            with zipfile.ZipFile(path,'w') as z:
                z.writestr('Payload/Demo.app/a',b'a')
                z.writestr('Payload/Demo.app/',b'')
                z.writestr('Payload/Demo.app/b',b'b')
            with zipfile.ZipFile(path) as z:
                self.assertEqual(len(checked_entries(z)),3)

    def test_reject_repeated_directory_separator(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'test.zip'
            with zipfile.ZipFile(path,'w') as z:
                z.writestr('Payload/Demo.app//',b'')
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError):
                checked_entries(z)

    def test_reject_file_directory_conflict(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['a','a/b'])
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_symlink(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'test.zip'
            with zipfile.ZipFile(path,'w') as z:
                entry=zipfile.ZipInfo('link');entry.create_system=3;entry.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(entry,b'other')
            with zipfile.ZipFile(path) as z, self.assertRaises(IntegrationError): checked_entries(z)

    def test_reject_truncated_zip(self):
        with tempfile.TemporaryDirectory() as t:
            path=self.make_zip(Path(t),['a']);path.write_bytes(path.read_bytes()[:-5])
            with self.assertRaises(IntegrationError): preflight_zip(path)


class LocalizationPackageTests(unittest.TestCase):
    @staticmethod
    def catalog(rows, **overrides):
        return json.dumps({'schemaVersion':1,'languages':['en','pt'],'entries':rows,**overrides}).encode('utf-8')

    def test_catalog_bounds_match_native_utf16_reader(self):
        valid_rows=[{'en':f'English {i}','pt':f'Português {i}'} for i in range(1024)]
        validate_localization_catalog(self.catalog(valid_rows))
        with self.assertRaises(IntegrationError):
            validate_localization_catalog(self.catalog(valid_rows+[{'en':'Extra','pt':'Outra'}]))
        for text,accepted in [('a'*2048,True),('a'*2049,False),('🙂'*1024,True),('🙂'*1025,False),('\ud800',False)]:
            with self.subTest(length=len(text),accepted=accepted):
                data=self.catalog([{'en':text,'pt':text}])
                if accepted: validate_localization_catalog(data)
                else:
                    with self.assertRaises(IntegrationError): validate_localization_catalog(data)
        data=self.catalog([{'en':'Language','pt':'Idioma'}])
        padded=data+b' '*(1024*1024-len(data))
        validate_localization_catalog(padded)
        for invalid in (b'',padded+b' '):
            with self.assertRaises(IntegrationError): validate_localization_catalog(invalid)

    def test_catalog_aliases_source_and_format_contract(self):
        formats='%@ / %ld / %llu / %02u / %08.2f / %%'
        valid=[{'en':'English '+formats,'pt':'Português '+formats,'source':'Source '+formats}]
        validate_localization_catalog(self.catalog(valid))
        validate_localization_catalog(self.catalog([{'en':'Status','pt':'Estado','source':'ready_state'}]))
        invalid_rows=[
            [{'en':'A','pt':'Mesmo'},{'en':'B','pt':'Mesmo'}],
            [{'en':'A','pt':'B','source':'C'},{'en':'C','pt':'D'}],
            [{'en':'A','pt':'B','source':None}],
            [{'en':'A','pt':'B','source':''}],
            [{'en':'A','pt':'B','source':3}],
            [{'en':'%ld balls','pt':'%u bolas'}],
            [{'en':'%@ %ld','pt':'%ld %@'}],
            [{'en':'%@ balls','pt':'%@ bolas','source':'balls'}],
            [{'en':'%02u balls','pt':'%u bolas'}],
            [{'en':'100%% ready','pt':'100% pronto'}],
            [{'en':'%@%@','pt':'%@%@'}],
            [{'en':'%ld','pt':'%ld'}],
        ]
        for specifier in ('%n','%q','%2$@','%*d','%lf','%'):
            invalid_rows.append([{'en':specifier,'pt':specifier}])
        for index,rows in enumerate(invalid_rows):
            with self.subTest(case=index), self.assertRaises(IntegrationError):
                validate_localization_catalog(self.catalog(rows))

    def test_catalog_rejects_ambiguous_json_and_boolean_schema(self):
        invalid=[
            b'{"schemaVersion":1,"schemaVersion":1,"languages":["en","pt"],"entries":[{"en":"A","pt":"B"}]}',
            b'{"schemaVersion":1,"languages":["en","pt"],"entries":[{"en":"A","en":"C","pt":"B"}]}',
            b'{"schemaVersion":NaN,"languages":["en","pt"],"entries":[{"en":"A","pt":"B"}]}',
            self.catalog([{'en':'A','pt':'B'}],schemaVersion=True),
        ]
        for index,data in enumerate(invalid):
            with self.subTest(case=index), self.assertRaises(IntegrationError):
                validate_localization_catalog(data)


class IntegrationTests(unittest.TestCase):
    def test_injected_sampler_resource_is_mandatory(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            ipa, framework, identity=make_fixture(root)
            (framework/'card_sampler.js').unlink()
            with self.assertRaisesRegex(IntegrationError, r'card_sampler\.js'):
                integrate(ipa, framework, identity, root/'new.ipa')

    def test_missing_brand_font_logo_and_context_are_rejected(self):
        for resource in ('Brand/logo@3x.png','Brand/Fonts/Syne-Bold.ttf','billiards_context.lua','Brand/menu-localizations.json'):
            with self.subTest(resource=resource), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root)
                (framework/resource).unlink()
                with self.assertRaises(IntegrationError): integrate(ipa,framework,identity,root/'new.ipa')

    def test_production_language_catalog_roundtrip_preserves_utf8_and_bytes(self):
        expected=(Path(__file__).resolve().parents[1]/'Resources/Brand/menu-localizations.json').read_bytes()
        for nested in (False, True):
            with self.subTest(nested=nested), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root)
                if nested:
                    (framework/'Resources').mkdir()
                    shutil.move(str(framework/'Brand'),str(framework/'Resources/Brand'))
                output=root/'new.ipa'
                result=integrate(ipa,framework,identity,output)
                prefix='Payload/Demo.app/Frameworks/SDKtools.framework/' + ('Resources/' if nested else '')
                with zipfile.ZipFile(output) as archive:
                    actual=archive.read(prefix+'Brand/menu-localizations.json')
                self.assertEqual(actual,expected)
                self.assertEqual(json.loads(actual.decode('utf-8'))['languages'],['en','pt'])
                self.assertTrue(result['signing_required'])

    def test_invalid_language_catalog_rejected_before_publication(self):
        rows=[{'en':'Language','pt':'Idioma'}]
        malformed=[b'\xff',b'{',b'null',b'[]',b'{}',
                   json.dumps({'schemaVersion':2,'languages':['en','pt'],'entries':rows}).encode(),
                   json.dumps({'schemaVersion':1,'languages':['en'],'entries':rows}).encode(),
                   json.dumps({'schemaVersion':1,'languages':['en','pt'],'entries':[]}).encode(),
                   json.dumps({'schemaVersion':1,'languages':['en','pt'],'entries':[{'en':'Language'}]}).encode(),
                   json.dumps({'schemaVersion':1,'languages':['en','pt'],'entries':[{'en':'Language','pt':''}]}).encode(),
                   json.dumps({'schemaVersion':1,'languages':['en','pt'],'entries':[{'en':'Language','pt':7}]}).encode()]
        for index,data in enumerate(malformed):
            with self.subTest(case=index), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root)
                (framework/'Brand/menu-localizations.json').write_bytes(data)
                output=root/'new.ipa'
                with self.assertRaisesRegex(IntegrationError,'[Cc]atálogo de idiomas'):
                    integrate(ipa,framework,identity,output)
                self.assertFalse(output.exists())
                self.assertFalse(output.with_suffix('.manifest.json').exists())

    def test_duplicate_language_catalog_rejected_before_publication(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            nested=framework/'Resources/Brand';nested.mkdir(parents=True)
            shutil.copyfile(framework/'Brand/menu-localizations.json',nested/'menu-localizations.json')
            output=root/'new.ipa'
            with self.assertRaisesRegex(IntegrationError,'menu-localizations.json'):
                integrate(ipa,framework,identity,output)
            self.assertFalse(output.exists())
            self.assertFalse(output.with_suffix('.manifest.json').exists())

    def test_current_production_resources_roundtrip_unchanged(self):
        resources=Path(__file__).resolve().parents[1]/'Resources'
        production={p.name:p.read_bytes() for p in resources.iterdir() if p.suffix in ('.js','.lua')}
        self.assertEqual(len(production),26)
        self.assertGreater(len(production['billiards_probe.lua']),65536)
        for nested in (False,True):
            with self.subTest(nested=nested), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root);original=ipa.read_bytes()
                folder=framework/'Resources' if nested else framework
                folder.mkdir(exist_ok=True)
                for name,data in production.items():
                    (framework/name).unlink()
                    (folder/name).write_bytes(data)
                output=root/'new.ipa';integrate(ipa,framework,identity,output)
                self.assertEqual(ipa.read_bytes(),original)
                with zipfile.ZipFile(output) as z:
                    prefix='Payload/Demo.app/Frameworks/SDKtools.framework/' + ('Resources/' if nested else '')
                    for name,data in production.items():self.assertEqual(z.read(prefix+name),data)
                self.assertTrue(output.with_suffix('.manifest.json').is_file())

    def test_resource_size_boundaries_match_native_readers(self):
        for name,limit in [('billiards_probe.lua',131072),('return_tool.js',65536),('alpaca_covered.js',65536),('alpaca_snapshot.js',65536),('alpaca_fast.js',65536),('alpaca_global.js',65536),('alpaca_global_runtime.js',65536),('alpaca_hottime.js',65536),('alpaca_win.js',65536)]:
            for size in (0,65536,65537,131072,131073):
                with self.subTest(resource=name,size=size), tempfile.TemporaryDirectory() as t:
                    root=Path(t);ipa,framework,identity=make_fixture(root)
                    (framework/name).write_bytes(b'x'*size)
                    if 0<size<=limit:
                        files,_=framework_files(framework)
                        self.assertEqual(files[name],b'x'*size)
                    else:
                        output=root/'new.ipa'
                        with self.assertRaisesRegex(IntegrationError,'Recurso obrigatório vazio ou excessivo'):
                            integrate(ipa,framework,identity,output)
                        self.assertFalse(output.exists())
                        self.assertFalse(output.with_suffix('.manifest.json').exists())

    def test_duplicate_required_resource_rejected_without_output(self):
        for name in ('billiards_probe.lua','return_tool.js','alpaca_covered.js','alpaca_snapshot.js','alpaca_hottime.js'):
            with self.subTest(resource=name), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root)
                nested=framework/'Resources';nested.mkdir();(nested/name).write_bytes((framework/name).read_bytes())
                output=root/'new.ipa'
                with self.assertRaisesRegex(IntegrationError,'Recurso obrigatório ausente ou duplicado'):
                    integrate(ipa,framework,identity,output)
                self.assertFalse(output.exists());self.assertFalse(output.with_suffix('.manifest.json').exists())

    def test_non_utf8_lua_rejected_without_output(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            (framework/'billiards_probe.lua').write_bytes(b'x'*70000+b'\xff')
            output=root/'new.ipa'
            with self.assertRaisesRegex(IntegrationError,'Recurso não é UTF-8: billiards_probe.lua'):
                integrate(ipa,framework,identity,output)
            self.assertFalse(output.exists());self.assertFalse(output.with_suffix('.manifest.json').exists())

    def test_roundtrip_preserves_base_and_all_data(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);original=ipa.read_bytes();output=root/'new.ipa'
            result=integrate(ipa,framework,identity,output)
            self.assertEqual(ipa.read_bytes(),original)
            self.assertTrue(result['signing_required']);self.assertFalse(result['runtime_tested'])
            with zipfile.ZipFile(output) as z:
                self.assertEqual(z.read('Payload/Demo.app/data.txt'),b'unchanged data')
                self.assertNotIn('Payload/Demo.app/embedded.mobileprovision',z.namelist())
                self.assertEqual(parse(z.read('Payload/Demo.app/Demo')).dependencies[-1],LOAD_PATH)
                self.assertEqual(parse(z.read('Payload/Demo.app/Frameworks/SDKtools.framework/SDKtools')).of_type(0x1D),())
                self.assertTrue((z.getinfo('Payload/Demo.app/Demo').external_attr>>16)&0o111)
            self.assertTrue(output.with_suffix('.manifest.json').is_file())

    def test_existing_output_never_replaced(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);output=root/'new.ipa';output.write_bytes(b'original')
            with self.assertRaises(IntegrationError): integrate(ipa,framework,identity,output)
            self.assertEqual(output.read_bytes(),b'original')

    def test_wrong_base_hash_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);ipa.write_bytes(ipa.read_bytes()+b'x')
            with self.assertRaises(IntegrationError): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_simulator_framework_rejected_without_output(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);(framework/'SDKtools').write_bytes(binary(6,platform=7))
            with self.assertRaises(MachOError): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_older_framework_version_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            plist=framework/'Info.plist';info=plistlib.loads(plist.read_bytes())
            info['CFBundleShortVersionString']='3.19.4';info['CFBundleVersion']='40'
            plist.write_bytes(plistlib.dumps(info))
            with self.assertRaisesRegex(IntegrationError,r'4\.0\.12'): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_required_tool_resource_missing_rejected_without_output(self):
        for resource in ('scene_probe.js', 'return_tool.js', 'autoplay_tool.js', 'autoplay_planner.js', 'autoplay_extended.js', 'autoplay_coop.js', 'autoplay_powers.js', 'alpaca_covered.js', 'alpaca_snapshot.js', 'alpaca_fast.js', 'alpaca_global.js', 'alpaca_global_runtime.js', 'alpaca_hottime.js', 'alpaca_win.js', 'xray_overlay.js', 'warehouse_tool.js', 'warehouse_test.js', 'card_hints.js', 'card_probe.js', 'card_flow.js', 'card_root.js', 'card_early.js', 'billiards_probe.lua', 'billiards_strategy.lua'):
            with self.subTest(resource=resource), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root)
                (framework/resource).unlink()
                with self.assertRaisesRegex(IntegrationError,'Recurso obrigatório'):
                    integrate(ipa,framework,identity,root/'new.ipa')
                self.assertFalse((root/'new.ipa').exists())

    def test_strategy_lua_size_limit_and_utf8_are_enforced(self):
        for data in (b'', b'x'*32769, b'\xff'):
            with self.subTest(size=len(data)), tempfile.TemporaryDirectory() as t:
                root=Path(t);ipa,framework,identity=make_fixture(root)
                (framework/'billiards_strategy.lua').write_bytes(data)
                with self.assertRaises(IntegrationError): integrate(ipa,framework,identity,root/'new.ipa')
                self.assertFalse((root/'new.ipa').exists())

    def test_oversized_tool_resource_rejected_without_output(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            (framework/'return_tool.js').write_bytes(b'x' * 65537)
            with self.assertRaisesRegex(IntegrationError,'Recurso obrigatório'):
                integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_framework_for_other_host_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            plist=framework/'Info.plist';info=plistlib.loads(plist.read_bytes())
            info['SDKToolsTargetBundleIdentifier']='com.example.other'
            plist.write_bytes(plistlib.dumps(info))
            with self.assertRaisesRegex(IntegrationError,'outra base'): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_missing_host_identity_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root)
            plist=framework/'Info.plist';info=plistlib.loads(plist.read_bytes())
            del info['SDKToolsTargetExecutable']
            plist.write_bytes(plistlib.dumps(info))
            with self.assertRaisesRegex(IntegrationError,'sem identidade'): integrate(ipa,framework,identity,root/'new.ipa')
            self.assertFalse((root/'new.ipa').exists())

    def test_manifest_publication_failure_rolls_back_ipa(self):
        from unittest.mock import patch
        import integrate_ipa
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);ipa,framework,identity=make_fixture(root);output=root/'new.ipa';original_publish=integrate_ipa.publish
            def publish_once(source,target):
                if target.suffix=='.json': raise OSError('synthetic publish failure')
                original_publish(source,target)
            with patch.object(integrate_ipa,'publish',side_effect=publish_once), self.assertRaises(OSError): integrate(ipa,framework,identity,output)
            self.assertFalse(output.exists());self.assertFalse(output.with_suffix('.manifest.json').exists())


if __name__=='__main__':
    unittest.main()

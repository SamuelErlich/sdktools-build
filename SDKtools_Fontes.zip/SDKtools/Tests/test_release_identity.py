"""Keep exported report identities in sync with the framework being built."""
from pathlib import Path
import plistlib
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ReleaseIdentityTests(unittest.TestCase):
    def setUp(self):
        self.info = plistlib.loads((ROOT / 'Resources/Info.plist').read_bytes())

    def test_every_report_identifies_the_current_framework(self):
        versions = []
        builds = []
        for path in sorted((ROOT / 'Sources/SDKtools').iterdir()):
            if path.suffix not in ('.m', '.inc'):
                continue
            text = path.read_text()
            versions.extend((path.name, v) for v in re.findall(r'@"toolVersion"\s*:\s*@"([^"]+)"', text))
            builds.extend((path.name, v) for v in re.findall(r'@"frameworkBuild"\s*:\s*@"([^"]+)"', text))
        self.assertGreaterEqual(len(versions), 6, 'report metadata scan must cover all exporters')
        self.assertGreaterEqual(len(builds), 2)
        for name, version in versions:
            with self.subTest(exporter=name):
                self.assertEqual(version, self.info['CFBundleShortVersionString'])
        for name, build in builds:
            with self.subTest(exporter=name):
                self.assertEqual(build, self.info['CFBundleVersion'])

    def test_display_linker_and_integrator_use_the_current_release(self):
        version = self.info['CFBundleShortVersionString']
        build = self.info['CFBundleVersion']
        overlay = (ROOT / 'Sources/SDKtools/STOverlay.m').read_text()
        self.assertIn('UILabel *version=[self label:@"' + version + '"', overlay)
        linker = (ROOT / 'scripts/build_framework.sh').read_text()
        self.assertEqual(re.findall(r'-current_version\s+(?:-Xlinker\s+)?(\S+)', linker), [version])
        integrator = (ROOT / 'scripts/integrate_ipa.py').read_text()
        self.assertIn("info.get('CFBundleShortVersionString') == '" + version + "'", integrator)
        self.assertIn("info.get('CFBundleVersion') == '" + build + "'", integrator)


if __name__ == '__main__':
    unittest.main()

#import "../Sources/SDKtools/STAutoplaySanitizer.inc"
#import <dispatch/dispatch.h>
#include <assert.h>
typedef NS_ENUM(NSInteger,UIApplicationState) { UIApplicationStateActive,UIApplicationStateInactive };
@interface UIApplication : NSObject
@property UIApplicationState applicationState;
+ (instancetype)sharedApplication;
@end
@implementation UIApplication
+ (instancetype)sharedApplication { static id app; if (!app) app=[self new]; return app; }
@end
@interface WKWebView : NSObject
@property(nonatomic,strong) NSObject *window;
@property(nonatomic) BOOL hidden;
@property(nonatomic) double alpha;
@property(nonatomic) NSUInteger submissions;
@property(nonatomic,copy) NSString *lastScript;
@property(nonatomic,copy) void (^completion)(id,NSError *);
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id,NSError *))completion;
- (void)complete:(id)value error:(NSError *)error;
@end
@implementation WKWebView
- (instancetype)init { if ((self=[super init])) { _window=[NSObject new]; _alpha=1; } return self; }
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id,NSError *))completion {
    self.submissions++;self.lastScript=script;self.completion=completion;
}
- (void)complete:(id)value error:(NSError *)error {
    void (^callback)(id,NSError *)=self.completion; self.completion=nil; callback(value,error);
}
@end
@interface STWPContext : NSObject
@property(nonatomic,weak) WKWebView *webView;
@property(nonatomic,copy) NSString *namespaceKey;
@property(nonatomic,copy) NSString *webViewID;
@property(nonatomic,copy) NSString *contextID;
@end
@implementation STWPContext @end
@interface STWebProbe : NSObject
@property BOOL inFlight;
@property BOOL cleaning;
@property BOOL acting;
@property BOOL autoplayActing;
@property NSUInteger requestSerial;
@property(nonatomic,copy) NSString *autoplayScript;
@property(nonatomic,copy) NSString *coveredScript;
@property(nonatomic,copy) NSString *plannerScript;
@property(nonatomic,copy) NSString *extendedScript;
@property(nonatomic,copy) NSString *autopowersScript;
@property(nonatomic,copy) NSString *returnScript;
@property(nonatomic,copy) NSString *xrayScript;
@property(nonatomic,strong) NSMutableArray *visualCleanupQueue;
@property(nonatomic,strong) NSMutableArray *cleanupQueue;
@property(nonatomic,strong) NSMapTable *autoplayContexts;
- (void)drainVisualCleanup;
- (void)hideAutoplayVisuals;
@end
@implementation STWebProbe
- (instancetype)init { if ((self=[super init])) {
    _coveredScript=_autoplayScript=_plannerScript=_extendedScript=_autopowersScript=_returnScript=@"function(){}";
    _autoplayContexts=[NSMapTable weakToStrongObjectsMapTable];
    _visualCleanupQueue=[NSMutableArray array]; _cleanupQueue=[NSMutableArray array];
} return self; }
- (void)count:(NSString *)key { (void)key; }
- (void)drainCleanup { [self drainVisualCleanup]; }
#include "../Sources/SDKtools/STAutoplayBridge.inc"
@end
static NSUInteger checks;
#define CHECK(c) do { checks++; assert(c); } while (0)
static NSString *candidate(WKWebView *view) {
    NSRegularExpression *re=[NSRegularExpression regularExpressionWithPattern:@"documentID:'([A-Fa-f0-9-]+)'" options:0 error:NULL];
    NSTextCheckingResult *m=[re firstMatchInString:view.lastScript options:0 range:NSMakeRange(0,view.lastScript.length)];
    return m?[view.lastScript substringWithRange:[m rangeAtIndex:1]]:@"";
}
static NSMutableDictionary *result(NSString *document) {
    return [@{@"version":@1,@"status":@"original_event_dispatched",@"reason":@"awaiting_original_result",
        @"dispatched":@YES,@"awaitingBoardChange":@YES,@"cardsRead":@12,@"confirmedMoves":@0,
        @"runtimeDocumentID":document} mutableCopy];
}
int main(void) { @autoreleasepool {
    STWebProbe *probe=[STWebProbe new];WKWebView *view=[WKWebView new];
    __block BOOL action=YES,identity=YES;
    __block NSDictionary *last;
    BOOL (^submit)(void)=^{ return [probe performAutoplayStepInWebView:view resumeGeneration:1 allowAction:YES coveredAttempt:NO
        turboEnabled:NO extendedPlanning:NO powersEnabled:NO xrayEnabled:YES xrayDepth:5
        validateContext:^BOOL { return action; } validateObservation:^BOOL { return identity; }
        update:^(NSDictionary *r){ last=r; }]; };
    CHECK(submit());NSString *document=candidate(view);CHECK(document.length==36);
    CHECK([view.lastScript containsString:@"xrayDepth:4,"]); // old saved value is clamped at the native boundary
    CHECK([view.lastScript containsString:@"coveredAttempt:false"]);
    CHECK([view.lastScript containsString:@"allowAction:true"]);
    action=NO; // Chat opens after submission but before WebKit callback.
    [view complete:result(document) error:nil];
    CHECK([last[@"status"] isEqual:@"original_event_dispatched"] && [last[@"dispatched"] boolValue]);
    CHECK(![last[@"physicalPending"] boolValue] && !probe.inFlight);
    CHECK(!submit());CHECK(view.submissions==1); // no new input while chat blocks
    action=YES;CHECK(submit());
    identity=NO;[view complete:result(document) error:nil];
    CHECK([last[@"reason"] isEqual:@"native_context_changed"]); // real context loss
    identity=YES;CHECK(submit());
    [view complete:result(@"foreign-document") error:nil];
    CHECK([last[@"reason"] isEqual:@"runtime_context_unverified"]);
    CHECK(submit());action=NO;
    [view complete:result(document) error:[NSError errorWithDomain:@"test" code:1 userInfo:nil]];
    CHECK([last[@"reason"] isEqual:@"evaluation_failed_after_submission"]); // chat cannot hide errors
    action=YES;CHECK(submit());
    NSMutableDictionary *invalid=result(document);invalid[@"version"]=@YES;
    [view complete:invalid error:nil];CHECK([last[@"status"] isEqual:@"dispatch_uncertain"]);
    CHECK(submit());
    NSDate *deadline=[NSDate dateWithTimeIntervalSinceNow:2.3];
    while (![last[@"physicalPending"] boolValue] && deadline.timeIntervalSinceNow>0)
        [NSRunLoop.mainRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.01]];
    CHECK([last[@"reason"] isEqual:@"evaluation_timeout"] && probe.inFlight);
    CHECK(!submit()); // timed-out request keeps exclusive physical lock
    [view complete:result(document) error:nil];
    CHECK([last[@"afterTimeout"] boolValue] && !probe.inFlight);
    action=YES;identity=YES;
    CHECK([probe performAutoplayStepInWebView:view resumeGeneration:1 allowAction:YES coveredAttempt:YES
        turboEnabled:NO extendedPlanning:NO powersEnabled:NO xrayEnabled:YES xrayDepth:4
        validateContext:^BOOL {return YES;} validateObservation:^BOOL {return YES;}
        update:^(NSDictionary *r){last=r;}]);
    CHECK([view.lastScript containsString:@"coveredAttempt:true"]);
    CHECK([view.lastScript containsString:@"allowAction:false"]); // experimental intent can never also run normal Auto
    [view complete:result(document) error:nil];
    printf("Autoplay production callback lifecycle: %lu checks passed\n",(unsigned long)checks);
} return 0; }

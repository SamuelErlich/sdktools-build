#import "../Sources/SDKtools/STAutoplaySanitizer.inc"
#include "../Sources/SDKtools/STNativeActionPolicy.h"
#import <dispatch/dispatch.h>
#include <assert.h>
typedef NS_ENUM(NSInteger,UIApplicationState) { UIApplicationStateActive,UIApplicationStateInactive };
@interface UIApplication : NSObject
@property UIApplicationState applicationState;
+ (instancetype)sharedApplication;
@end
@implementation UIApplication
+ (instancetype)sharedApplication { static id app; if (!app) app=[self new]; return app; }
@end
@interface WKWebView : NSObject
@property(nonatomic,strong) NSObject *window;
@property(nonatomic) BOOL hidden;
@property(nonatomic) double alpha;
@property(nonatomic) NSUInteger submissions;
@property(nonatomic) BOOL throwOnSubmission;
@property(nonatomic,copy) NSString *lastScript;
@property(nonatomic,copy) void (^completion)(id,NSError *);
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id,NSError *))completion;
- (void)complete:(id)value error:(NSError *)error;
@end
@implementation WKWebView
- (instancetype)init { if ((self=[super init])) { _window=[NSObject new]; _alpha=1; } return self; }
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id,NSError *))completion {
    self.submissions++;self.lastScript=script;self.completion=completion;
    if (self.throwOnSubmission) @throw [NSException exceptionWithName:@"FixtureSubmission" reason:nil userInfo:nil];
}
- (void)complete:(id)value error:(NSError *)error {
    void (^callback)(id,NSError *)=self.completion; self.completion=nil; callback(value,error);
}
@end
@interface STWPContext : NSObject
@property(nonatomic,weak) WKWebView *webView;
@property(nonatomic,copy) NSString *namespaceKey;
@property(nonatomic,copy) NSString *webViewID;
@property(nonatomic,copy) NSString *contextID;
@end
@implementation STWPContext @end
@interface STWebProbe : NSObject
@property BOOL inFlight;
@property BOOL cleaning;
@property BOOL acting;
@property BOOL autoplayActing;
@property NSUInteger requestSerial;
@property(nonatomic,copy) NSString *autoplayScript;
@property(nonatomic,copy) NSString *coveredScript;
@property(nonatomic,copy) NSString *phaseSnapshotScript;
@property(nonatomic,copy) NSString *fastScript;
@property(nonatomic,copy) NSString *hotTimeScript;
@property(nonatomic,copy) NSString *plannerScript;
@property(nonatomic,copy) NSString *extendedScript;
@property(nonatomic,copy) NSString *cooperativeScript;
@property(nonatomic,copy) NSString *autopowersScript;
@property(nonatomic,copy) NSString *returnScript;
@property(nonatomic,copy) NSString *xrayScript;
@property(nonatomic,strong) NSMutableArray *visualCleanupQueue;
@property(nonatomic,strong) NSMutableArray *cleanupQueue;
@property(nonatomic,strong) NSMapTable *autoplayContexts;
- (void)drainVisualCleanup;
- (void)hideAutoplayVisuals;
@end
@implementation STWebProbe
- (instancetype)init { if ((self=[super init])) {
    _hotTimeScript=_fastScript=_phaseSnapshotScript=_coveredScript=_autoplayScript=_plannerScript=_extendedScript=_cooperativeScript=_autopowersScript=_returnScript=@"function(){}";
    _autoplayContexts=[NSMapTable weakToStrongObjectsMapTable];
    _visualCleanupQueue=[NSMutableArray array]; _cleanupQueue=[NSMutableArray array];
} return self; }
- (void)count:(NSString *)key { (void)key; }
- (void)drainCleanup { [self drainVisualCleanup]; }
#include "../Sources/SDKtools/STAutoplayBridge.inc"
@end
static NSUInteger checks;
#define CHECK(c) do { checks++; assert(c); } while (0)
static NSString *candidate(WKWebView *view) {
    NSRegularExpression *re=[NSRegularExpression regularExpressionWithPattern:@"documentID:'([A-Fa-f0-9-]+)'" options:0 error:NULL];
    NSTextCheckingResult *m=[re firstMatchInString:view.lastScript options:0 range:NSMakeRange(0,view.lastScript.length)];
    return m?[view.lastScript substringWithRange:[m rangeAtIndex:1]]:@"";
}
static NSMutableDictionary *result(NSString *document) {
    return [@{@"version":@1,@"status":@"original_event_dispatched",@"reason":@"awaiting_original_result",
        @"dispatched":@YES,@"awaitingBoardChange":@YES,@"cardsRead":@12,@"confirmedMoves":@0,
        @"runtimeDocumentID":document} mutableCopy];
}
int main(void) { @autoreleasepool {
    STWebProbe *probe=[STWebProbe new];WKWebView *view=[WKWebView new];
    __block BOOL action=YES,identity=YES,autoArmed=YES;
    __block NSUInteger batchSize=3;
    __block NSDictionary *last;
    BOOL (^submit)(void)=^{ return [probe performAutoplayStepInWebView:view resumeGeneration:1 allowAction:YES coveredAttempt:NO penetrateAttempt:NO
        turboEnabled:NO superFastEnabled:YES cardsPerBatch:batchSize extendedPlanning:NO powersEnabled:NO xrayEnabled:YES xrayDepth:5
        validateContext:^BOOL { return action; } validateObservation:^BOOL { return identity; }
        update:^(NSDictionary *r){ last=r;
            BOOL failed=[r[@"status"] isEqual:@"dispatch_uncertain"] || [r[@"status"] isEqual:@"error"];
            if (STNativeAutoplayShouldPause(failed,[r[@"physicalPending"] boolValue],[r[@"reason"] isEqual:@"evaluation_timeout"])) autoArmed=NO;
        }]; };
    probe.hotTimeScript=nil;
    CHECK(!submit());CHECK(view.submissions==0 && [last[@"reason"] isEqual:@"action_script_missing"]);
    probe.hotTimeScript=@"function(){return 'hot-time-guard';}";
    CHECK(submit());NSString *document=candidate(view);CHECK(document.length==36);
    CHECK([view.lastScript containsString:probe.hotTimeScript]);
    NSUInteger bootstrapLength=view.lastScript.length;
    CHECK([view.lastScript containsString:@"xrayDepth:4,"]); // old saved value is clamped at the native boundary
    CHECK([view.lastScript containsString:@"coveredAttempt:false"]);
    CHECK([view.lastScript containsString:@"allowAction:true"]);
    CHECK([view.lastScript containsString:@"superFastEnabled:true"]);
    CHECK([view.lastScript containsString:@"cardsPerBatch:3,"]);
    action=NO; // Chat opens after submission but before WebKit callback.
    [view complete:result(document) error:nil];
    CHECK([last[@"status"] isEqual:@"original_event_dispatched"] && [last[@"dispatched"] boolValue]);
    CHECK(![last[@"physicalPending"] boolValue] && !probe.inFlight);
    CHECK(!submit());CHECK(view.submissions==1); // no new input while chat blocks
    action=YES;batchSize=2;CHECK(submit());
    CHECK([view.lastScript containsString:@"cardsPerBatch:2,"]);
    CHECK(view.lastScript.length<2000 && view.lastScript.length<bootstrapLength);
    CHECK(![view.lastScript containsString:@"runtime:("]);
    CHECK([view.lastScript containsString:document]);
    identity=NO;[view complete:result(document) error:nil];
    CHECK([last[@"reason"] isEqual:@"native_context_changed"]); // real context loss
    identity=YES;batchSize=0;CHECK(submit());
    CHECK([view.lastScript containsString:@"cardsPerBatch:1,"]);
    batchSize=3;
    [view complete:result(@"foreign-document") error:nil];
    CHECK([last[@"reason"] isEqual:@"runtime_context_unverified"]);
    CHECK(submit());action=NO;
    [view complete:result(document) error:[NSError errorWithDomain:@"test" code:1 userInfo:nil]];
    CHECK([last[@"reason"] isEqual:@"evaluation_failed_after_submission"]); // chat cannot hide errors
    action=YES;CHECK(submit());
    NSMutableDictionary *invalid=result(document);invalid[@"version"]=@YES;
    [view complete:invalid error:nil];CHECK([last[@"status"] isEqual:@"dispatch_uncertain"]);
    autoArmed=YES;CHECK(submit());
    NSDate *deadline=[NSDate dateWithTimeIntervalSinceNow:2.3];
    while (![last[@"physicalPending"] boolValue] && deadline.timeIntervalSinceNow>0)
        [NSRunLoop.mainRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.01]];
    CHECK([last[@"reason"] isEqual:@"evaluation_timeout"] && probe.inFlight);
    CHECK(autoArmed); // Intermediate delay must not permanently cancel the user's Play intent.
    CHECK(!submit()); // timed-out request keeps exclusive physical lock
    [view complete:result(document) error:nil];
    CHECK([last[@"afterTimeout"] boolValue] && !probe.inFlight);
    CHECK(autoArmed); // The valid late callback can continue through normal pending reconciliation.
    action=YES;identity=YES;
    CHECK([probe performAutoplayStepInWebView:view resumeGeneration:1 allowAction:YES coveredAttempt:YES penetrateAttempt:NO
        turboEnabled:NO superFastEnabled:NO cardsPerBatch:2 extendedPlanning:NO powersEnabled:NO xrayEnabled:YES xrayDepth:4
        validateContext:^BOOL {return YES;} validateObservation:^BOOL {return YES;}
        update:^(NSDictionary *r){last=r;}]);
    CHECK([view.lastScript containsString:@"coveredAttempt:true"]);
    CHECK([view.lastScript containsString:@"superFastEnabled:false,cardsPerBatch:2,"]);
    CHECK([view.lastScript containsString:@"allowAction:false"]); // experimental intent can never also run normal Auto
    [view complete:result(document) error:nil];
    CHECK([probe performAutoplayStepInWebView:view resumeGeneration:1 allowAction:YES coveredAttempt:NO penetrateAttempt:YES
        turboEnabled:NO superFastEnabled:NO cardsPerBatch:2 extendedPlanning:NO powersEnabled:NO xrayEnabled:YES xrayDepth:4
        validateContext:^BOOL {return YES;} validateObservation:^BOOL {return YES;}
        update:^(NSDictionary *r){last=r;}]);
    CHECK([view.lastScript containsString:@"penetrateAttempt:true"] && [view.lastScript containsString:@"coveredAttempt:false"]);
    CHECK([view.lastScript containsString:@"allowAction:false"]);
    [view complete:result(document) error:nil];
    // A read-only X-ray evaluation can finish after the user arms Play. It
    // retains physical exclusivity on timeout, but must not claim a sent card.
    BOOL (^readOnly)(void)=^{return [probe performAutoplayStepInWebView:view resumeGeneration:2 allowAction:NO coveredAttempt:NO penetrateAttempt:NO
        turboEnabled:NO superFastEnabled:NO cardsPerBatch:2 extendedPlanning:NO powersEnabled:YES xrayEnabled:YES xrayDepth:4
        validateContext:^BOOL{return YES;} validateObservation:^BOOL{return YES;}
        update:^(NSDictionary *r){last=r;}];};
    CHECK(readOnly());last=nil;
    NSDate *readDeadline=[NSDate dateWithTimeIntervalSinceNow:2.3];
    while (![last[@"physicalPending"] boolValue] && readDeadline.timeIntervalSinceNow>0)
        [NSRunLoop.mainRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.01]];
    CHECK(probe.inFlight && [last[@"physicalPending"] boolValue]);
    CHECK([last[@"status"] isEqual:@"watching"] && ![last[@"dispatched"] boolValue]);
    CHECK(!readOnly()); // Queuing Play intent must not queue another JS evaluation.
    NSMutableDictionary *readRow=result(document);readRow[@"status"]=@"watching";readRow[@"dispatched"]=@NO;readRow[@"awaitingBoardChange"]=@NO;
    [view complete:readRow error:nil];CHECK(!probe.inFlight);
    CHECK(readOnly());[view complete:nil error:[NSError errorWithDomain:@"read-only" code:1 userInfo:nil]];
    CHECK([last[@"status"] isEqual:@"blocked"] && ![last[@"physicalPending"] boolValue]);
    // No-error nil/malformed callbacks are still read failures, not evidence
    // that this read-only evaluation might have issued a card.
    CHECK(readOnly());[view complete:nil error:nil];
    CHECK([last[@"status"] isEqual:@"blocked"] && [last[@"dispatchOutcomeKnown"] boolValue]);
    CHECK([last[@"reason"] isEqual:@"runtime_context_unverified"] && !probe.inFlight);
    CHECK(readOnly());NSMutableDictionary *badRead=result(document);badRead[@"version"]=@YES;
    [view complete:badRead error:nil];
    CHECK([last[@"status"] isEqual:@"blocked"] && [last[@"reason"] isEqual:@"invalid_result"]);
    CHECK(submit());[view complete:nil error:nil];
    CHECK([last[@"status"] isEqual:@"dispatch_uncertain"] && ![last[@"dispatchOutcomeKnown"] boolValue]);

    // A host traversal can throw through a validation block. Before submission
    // reject without evaluating; after submission retain action uncertainty.
    NSUInteger priorSubmissions=view.submissions;
    CHECK(![probe performAutoplayStepInWebView:view resumeGeneration:2 allowAction:YES coveredAttempt:NO penetrateAttempt:NO
        turboEnabled:NO superFastEnabled:NO cardsPerBatch:2 extendedPlanning:NO powersEnabled:NO xrayEnabled:YES xrayDepth:4
        validateContext:^BOOL {@throw [NSException exceptionWithName:@"FixturePreflight" reason:nil userInfo:nil];return NO;}
        validateObservation:^BOOL {return YES;} update:^(NSDictionary *r){last=r;}]);
    CHECK(view.submissions==priorSubmissions && !probe.inFlight && [last[@"reason"] isEqual:@"native_context_unavailable"]);
    for (NSUInteger mayAct=0;mayAct<2;mayAct++) {
        CHECK([probe performAutoplayStepInWebView:view resumeGeneration:2 allowAction:mayAct coveredAttempt:NO penetrateAttempt:NO
            turboEnabled:NO superFastEnabled:NO cardsPerBatch:2 extendedPlanning:NO powersEnabled:NO xrayEnabled:YES xrayDepth:4
            validateContext:^BOOL {return YES;}
            validateObservation:^BOOL {@throw [NSException exceptionWithName:@"FixtureObservation" reason:nil userInfo:nil];return NO;}
            update:^(NSDictionary *r){last=r;}]);
        [view complete:result(document) error:nil];
        CHECK([last[@"status"] isEqual:(mayAct?@"dispatch_uncertain":@"blocked")]);
        CHECK([last[@"reason"] isEqual:@"native_context_changed"] && !probe.inFlight);
    }
    view.throwOnSubmission=YES;CHECK(readOnly());
    CHECK(probe.inFlight && [last[@"physicalPending"] boolValue] && [last[@"status"] isEqual:@"watching"]);
    CHECK(!readOnly()); // Throwing evaluation still owns the physical lock.
    view.throwOnSubmission=NO;[view complete:readRow error:nil];CHECK(!probe.inFlight);
    printf("Autoplay production callback lifecycle: %lu checks passed\n",(unsigned long)checks);
} return 0; }

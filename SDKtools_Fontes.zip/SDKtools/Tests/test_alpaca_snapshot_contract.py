"""Source-only contracts; no build, packaging, server or device calls."""
from pathlib import Path
import ast
import re
import unittest
ROOT=Path(__file__).resolve().parents[1]
class PhaseSnapshotContracts(unittest.TestCase):
    def test_resource_loading_and_fail_closed_native_bridge(self):
        web=(ROOT/'Sources/SDKtools/STWebProbe.m').read_text(encoding='utf-8')
        bridge=(ROOT/'Sources/SDKtools/STAutoplayBridge.inc').read_text(encoding='utf-8')
        self.assertIn('@"alpaca_snapshot"',web)
        self.assertIn('_phaseSnapshotScript = source;',web)
        self.assertIn('!self.phaseSnapshotScript.length',bridge)
        self.assertIn('self.coveredScript, self.phaseSnapshotScript,',bridge)
        self.assertIn('self.cooperativeScript, self.plannerScript, self.hotTimeScript,',bridge)
        self.assertIn('requirePhaseSnapshot:true',bridge)
        template=re.search(r'NSString \*wrapped[\s\S]*?@"([^"\n]+)"',bridge).group(1)
        self.assertEqual(len(re.findall(r'%@|%ld|%lu',template)),29)
    def test_required_resource_contracts_are_source_only_and_consistent(self):
        self.assertIn('Resources/alpaca_snapshot.js',(ROOT/'scripts/build_framework.sh').read_text(encoding='utf-8'))
        tree=ast.parse((ROOT/'scripts/integrate_ipa.py').read_text(encoding='utf-8'))
        constants=[node.value for node in ast.walk(tree) if isinstance(node,ast.Constant)]
        self.assertIn('alpaca_snapshot.js',constants)
        ast.parse((ROOT/'Tests/test_packaging.py').read_text(encoding='utf-8'))
        self.assertLess((ROOT/'Resources/alpaca_snapshot.js').stat().st_size,65536)
        self.assertLess((ROOT/'Resources/autoplay_tool.js').stat().st_size,65536)
    def test_native_summary_stays_closed_and_never_projects_full_cards(self):
        sanitizer=(ROOT/'Sources/SDKtools/STAutoplaySanitizer.inc').read_text(encoding='utf-8')
        helper=sanitizer.split('static NSDictionary *STWPSanitizePhaseSnapshotSummary',1)[1].split('static NSString *STWPAutoReason',1)[0]
        for key in ['revision','scope','complete','serverConfirmed','counts','allRulesRecognized']:
            self.assertIn('@"'+key+'"',helper)
        self.assertIn('value[@"serverConfirmed"]!=(__bridge id)kCFBooleanFalse',helper)
        self.assertNotIn('@"cards"',helper)
        self.assertNotIn('@"inventory"',helper)
        self.assertIn('STWPSanitizePhaseSnapshotSummary(value[@"phaseSnapshotSummary"])',sanitizer)
        recorder=(ROOT/'Sources/SDKtools/STAutoplayRecorder.inc').read_text(encoding='utf-8')
        self.assertIn('@"cardRuleDetail", @"animationDetail", @"phaseSnapshotSummary"',recorder)
    def test_reader_never_installs_transport_observers_or_writes_game_state(self):
        source=(ROOT/'Resources/alpaca_snapshot.js').read_text(encoding='utf-8')
        self.assertNotRegex(source,r'\.(send|TouchBlock|UseProp|emit|addEventListener|removeEventListener)\s*\(')
        self.assertNotRegex(source,r'Object\.(defineProperty|assign)\s*\(\s*(store|socket)\b')
        self.assertIn('serverConfirmed:false',source)
        self.assertIn('STABLE_MS=80',source)
        self.assertIn('var witness=collect(s,env)',source)
if __name__=='__main__': unittest.main()

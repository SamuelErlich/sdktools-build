#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STGameSourceExporter.h"
#include <stdio.h>
static NSUInteger checks,failures;
static void Check(BOOL test,NSString *message){checks++;if(!test){failures++;fprintf(stderr,"FAIL %s\n",message.UTF8String);}}
static NSURL *RunStorage(NSURL *cache,NSURL *documents,NSURL *entry,NSURL *nativeResource,NSURL *out,NSError **error) {
    __block NSURL *result=nil;__block NSError *failure=nil;
    dispatch_semaphore_t semaphore=dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
        result=[STGameSourceExporter writeSourcesFromCachesURL:cache documentsURL:documents entryURL:entry verifiedNativeResourceURL:nativeResource destinationDirectory:out error:&failure];
        dispatch_semaphore_signal(semaphore);
    });
    dispatch_semaphore_wait(semaphore,DISPATCH_TIME_FOREVER);if(error)*error=failure;return result;
}
static NSURL *RunNative(NSURL *cache,NSURL *entry,NSURL *nativeResource,NSURL *out,NSError **error) {return RunStorage(cache,nil,entry,nativeResource,out,error);}
static NSURL *Run(NSURL *cache,NSURL *entry,NSURL *out,NSError **error) {return RunNative(cache,entry,nil,out,error);}
static NSURL *RunGame(NSURL *cache,NSURL *documents,NSURL *entry,NSInteger gameType,NSURL *nativeResource,NSURL *out,NSError **error) {
    __block NSURL *result=nil;__block NSError *failure=nil;
    dispatch_semaphore_t semaphore=dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
        result=[STGameSourceExporter writeSourcesFromCachesURL:cache documentsURL:documents entryURL:entry observedGameType:gameType verifiedNativeResourceURL:nativeResource destinationDirectory:out error:&failure];
        dispatch_semaphore_signal(semaphore);
    });
    dispatch_semaphore_wait(semaphore,DISPATCH_TIME_FOREVER);if(error)*error=failure;return result;
}
static NSDictionary *ReadExport(NSURL *URL) {
    NSData *data=URL?[NSData dataWithContentsOfURL:URL]:nil;
    return data?[NSJSONSerialization JSONObjectWithData:data options:0 error:nil]:nil;
}
static NSURL *CreatePackage(NSURL *cache,NSString *folder) {
    NSFileManager *manager=[NSFileManager new];
    NSURL *root=[cache URLByAppendingPathComponent:[NSString stringWithFormat:@"littleGame/%@/game_res/web-mobile",folder] isDirectory:YES];
    Check([manager createDirectoryAtURL:root withIntermediateDirectories:YES attributes:nil error:nil],@"create alternate package fixture");
    NSURL *entry=[root URLByAppendingPathComponent:@"index.html"];
    Check([@"<script src='project.js'></script>" writeToURL:entry atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create alternate entry");
    Check([@"function UseProp(){}\n" writeToURL:[root URLByAppendingPathComponent:@"project.js"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create alternate JS");
    return entry;
}
int main(void){@autoreleasepool {
    Check(NSDocumentDirectory==9&&NSCachesDirectory==13,@"native assembly argument 9 means Documents, never Caches");
    NSFileManager *manager=[NSFileManager new];
    NSURL *base=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"sdktools-source-foundation-" stringByAppendingString:NSUUID.UUID.UUIDString]] isDirectory:YES];
    NSURL *cache=[base URLByAppendingPathComponent:@"Caches" isDirectory:YES];
    NSURL *root=[cache URLByAppendingPathComponent:@"littleGame/60_game/game_res/web-mobile" isDirectory:YES];
    NSURL *out=[base URLByAppendingPathComponent:@"Output" isDirectory:YES];
    Check([manager createDirectoryAtURL:root withIntermediateDirectories:YES attributes:nil error:nil],@"create exact game cache fixture");
    Check([manager createDirectoryAtURL:out withIntermediateDirectories:YES attributes:nil error:nil],@"create output fixture");
    NSURL *entry=[root URLByAppendingPathComponent:@"index.html"];
    Check([@"<script src='project.js'></script>" writeToURL:entry atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create entry document");
    Check([@"function UseProp(){}\n" writeToURL:[root URLByAppendingPathComponent:@"project.js"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create source fixture");
    Check([@"DO_NOT_EXPORT_RUNTIME_SECRET" writeToURL:[root URLByAppendingPathComponent:@"runtime.json"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create excluded data fixture");
    NSError *error=nil;NSURL *file=Run(cache,entry,out,&error);Check(file!=nil&&error==nil,@"actual production exporter succeeds in background");
    NSData *bytes=[NSData dataWithContentsOfURL:file];NSDictionary *json=bytes?[NSJSONSerialization JSONObjectWithData:bytes options:0 error:nil]:nil;
    Check([json[@"format"] isEqual:@"SDKtools.GameSources"],@"source-bundle format identified");
    Check([json[@"files"] count]==1,@"only JavaScript included");
    NSDictionary *source=[json[@"files"] firstObject];
    Check([source[@"path"] isEqual:@"project.js"],@"only relative path exported");
    Check([source[@"source"] isEqual:@"function UseProp(){}\n"],@"complete unchanged source retained");
    Check([source[@"sha256"] isEqual:@"f177011e631fe70c53b5c9c5700e59f187c9a28c0074fc1e5ecea8589953732d"],@"SHA256 computed over exact source bytes");
    Check([source[@"keywordMatches"][@"UseProp"][@"utf8ByteOffsets"] isEqual:@[@9]],@"keyword location measured in UTF8 bytes");
    Check(![json[@"metadata"][@"loadedRuntimeEquivalenceProven"] boolValue]&&![json[@"metadata"][@"atomicWholeBundleSnapshot"] boolValue],@"disk evidence never claims current runtime equivalence");
    NSString *serialized=[[NSString alloc]initWithData:bytes encoding:NSUTF8StringEncoding];
    Check(![serialized containsString:@"DO_NOT_EXPORT_RUNTIME_SECRET"]&&![serialized containsString:base.path],@"non-source data and absolute sandbox paths excluded");
    Check(![STGameSourceExporter writeSourcesFromCachesURL:cache entryURL:entry destinationDirectory:out error:&error],@"main-thread filesystem scan rejected");
    Check(!Run(cache,[NSURL URLWithString:@"https://example.invalid/index.html"],out,&error),@"remote document rejected without network");
    Check(!Run(cache,[root URLByAppendingPathComponent:@"another.html"],out,&error),@"different entry rejected");
    NSURL *parameterized=[NSURL URLWithString:[entry.absoluteString stringByAppendingString:@"?session=PRIVATE_URL_TOKEN#PRIVATE_FRAGMENT"]];
    NSDictionary *withParameters=ReadExport(Run(cache,parameterized,out,&error));
    Check([withParameters[@"files"] count]==1,@"query and fragment do not alter the exact local source path");
    NSString *parameterJSON=[[NSString alloc]initWithData:[NSJSONSerialization dataWithJSONObject:withParameters?:@{} options:0 error:nil] encoding:NSUTF8StringEncoding];
    Check(![parameterJSON containsString:@"PRIVATE_URL_TOKEN"]&&![parameterJSON containsString:@"PRIVATE_FRAGMENT"],@"URL query and fragment contents never exported");
    Check([withParameters[@"metadata"][@"pathDiagnostic"][@"hasQuery"] boolValue]&&[withParameters[@"metadata"][@"pathDiagnostic"][@"hasFragment"] boolValue],@"parameter presence diagnostics retained without values");
    NSURL *developerEntry=CreatePackage(cache,@"dev_60_game");
    Check(Run(cache,developerEntry,out,&error)!=nil,@"known native dev game60 path accepted");
    NSURL *variantEntry=CreatePackage(cache,@"runtime60_package");
    NSURL *variantResource=variantEntry.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent;
    Check(!Run(cache,variantEntry,out,&error),@"unknown folder alone never establishes game identity");
    NSDictionary *nativeExport=ReadExport(RunNative(cache,variantEntry,variantResource,out,&error));
    Check([nativeExport[@"files"] count]==1,@"current document must match original native game60 resource exactly");
    Check([nativeExport[@"metadata"][@"rootSelection"] isEqual:@"original_game60_native_resource_and_current_document"],@"native root provenance recorded");
    Check(!RunNative(cache,entry,variantResource,out,&error),@"native resource mismatch rejected even for fallback folder");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"native_resource_mismatch"],@"mismatch has structured diagnostic");
    Check(!RunNative(cache,entry,[base URLByAppendingPathComponent:@"outside/game_res"],out,&error),@"native path outside OS cache rejected");
    NSURL *otherEntry=CreatePackage(cache,@"61_game");
    Check(!Run(cache,otherEntry,out,&error),@"different game folder rejected");
    NSData *diagnosticData=[NSJSONSerialization dataWithJSONObject:error.userInfo[STGameSourcePathDiagnosticKey]?:@{} options:0 error:nil];
    NSString *diagnosticText=[[NSString alloc]initWithData:diagnosticData encoding:NSUTF8StringEncoding];
    Check(![diagnosticText containsString:base.path]&&![diagnosticText containsString:@"61_game"],@"diagnostic never reveals sandbox or arbitrary folder names");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"pathShape"] containsObject:@"<other>"],@"unknown path segments explicitly redacted");
    NSURL *documents=[base URLByAppendingPathComponent:@"Documents" isDirectory:YES];
    NSURL *documentsEntry=CreatePackage(documents,@"60_game");
    NSURL *documentsResource=documentsEntry.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent;
    Check(!RunNative(cache,documentsEntry,documentsResource,out,&error),@"reproduces V2.9: valid Documents package cannot match Caches-only anchor");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"unsafe_or_outside_storage_path"],@"outside-root failure is explicit");
    NSDictionary *documentsExport=ReadExport(RunStorage(cache,documents,documentsEntry,documentsResource,out,&error));
    Check([documentsExport[@"files"] count]==1&&error==nil,@"original native game60 Documents package exports complete source");
    NSDictionary *documentsDiagnostic=documentsExport[@"metadata"][@"pathDiagnostic"];
    Check([documentsDiagnostic[@"storageRoot"] isEqual:@"Documents"]&&[documentsDiagnostic[@"insideDocuments"] boolValue]&&[documentsDiagnostic[@"nativeResourceInsideDocuments"] boolValue],@"Documents source provenance recorded");
    Check(![documentsDiagnostic[@"insideCaches"] boolValue]&&![documentsDiagnostic[@"nativeResourceInsideCaches"] boolValue],@"Documents not incorrectly reported as Caches");
    Check([documentsExport[@"metadata"][@"rootScope"] isEqual:@"verified_current_game_package_under_Documents/littleGame"],@"metadata records narrow Documents package scope");
    NSURL *cardsEntry=CreatePackage(documents,@"2007_game");
    NSURL *cardsRoot=cardsEntry.URLByDeletingLastPathComponent;
    NSString *cardsSource=@"function drawCard(card) { return card; }\n";
    Check([cardsSource writeToURL:[cardsRoot URLByAppendingPathComponent:@"project.js"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create non-executed game2007 source fixture");
    NSDictionary *cardsExport=ReadExport(RunGame(cache,documents,cardsEntry,2007,nil,out,&error));
    Check(error==nil&&[cardsExport[@"files"] count]==1&&[[cardsExport[@"files"] firstObject][@"source"] isEqual:cardsSource],@"native-observed game2007 exact Documents package exports unchanged source");
    Check([cardsExport[@"metadata"][@"gameID"] isEqual:@2007]&&[cardsExport[@"metadata"][@"pathDiagnostic"][@"observedGameType"] isEqual:@2007],@"game2007 identity never rewritten as game60");
    Check([cardsExport[@"metadata"][@"rootSelection"] isEqual:@"current_document_game2007_exact_folder_policy"]&&![cardsExport[@"metadata"][@"pathDiagnostic"][@"nativeResourceProvided"] boolValue],@"game2007 provenance uses current document with no native getter");
    Check(![cardsExport[@"metadata"][@"runtimeStateRead"] boolValue]&&![cardsExport[@"metadata"][@"hiddenCardIdentityProven"] boolValue]&&[cardsExport[@"metadata"][@"keywordMatchesAreStringOccurrencesOnly"] boolValue],@"static export never claims opponent state from source strings");
    Check([[[cardsExport[@"files"] firstObject][@"keywordMatches"] allKeys] containsObject:@"card"],@"source-only card keyword offsets included for later inspection");
    Check(!RunGame(cache,documents,documentsEntry,2007,nil,out,&error),@"game2007 context rejects Alpaca source folder");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"different_game_folder"],@"cross-game path rejection explicit");
    Check(!RunGame(cache,documents,cardsEntry,60,nil,out,&error),@"game60 context rejects game2007 folder");
    Check(!RunGame(cache,documents,cardsEntry,60,cardsRoot.URLByDeletingLastPathComponent,out,&error),@"game60 getter claim cannot admit known game2007 folder");
    Check(!RunStorage(cache,documents,cardsEntry,nil,out,&error),@"legacy exporter remains exclusively game60");
    Check(!RunGame(cache,documents,cardsEntry,2007,cardsRoot.URLByDeletingLastPathComponent,out,&error),@"unverified game2007 native getter path is refused");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"native_getter_unverified_for_game"],@"unverified getter refusal diagnosed");
    Check(!RunGame(cache,documents,cardsEntry,2008,nil,out,&error),@"unknown native game ID cannot adopt supported folder");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"unsupported_game_type"],@"unsupported native game ID diagnostic");
    NSURL *cardsDevEntry=CreatePackage(cache,@"dev_2007_game");
    Check(RunGame(cache,documents,cardsDevEntry,2007,nil,out,&error)!=nil,@"exact game2007 development spelling works under Caches");
    NSURL *cardsUnknownEntry=CreatePackage(documents,@"runtime2007_package");
    Check(!RunGame(cache,documents,cardsUnknownEntry,2007,nil,out,&error),@"unexpected local game2007 layout does not trigger sibling discovery");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"pathShape"] containsObject:@"<other>"],@"unrecognized game2007 folder remains redacted");
    NSURL *cardsParameters=[NSURL URLWithString:[cardsEntry.absoluteString stringByAppendingString:@"?token=CARD_TOKEN_PRIVATE#CARD_PRIVATE_FRAGMENT"]];
    NSDictionary *cardsParameterized=ReadExport(RunGame(cache,documents,cardsParameters,2007,nil,out,&error));
    NSString *cardsJSON=[[NSString alloc]initWithData:[NSJSONSerialization dataWithJSONObject:cardsParameterized?:@{} options:0 error:nil] encoding:NSUTF8StringEncoding];
    Check([cardsParameterized[@"files"] count]==1&&![cardsJSON containsString:@"CARD_TOKEN_PRIVATE"]&&![cardsJSON containsString:@"CARD_PRIVATE_FRAGMENT"]&&![cardsJSON containsString:base.path],@"game2007 URL parameters and absolute paths remain excluded");
    Check(!RunGame(cache,documents,[NSURL URLWithString:@"https://example.invalid/littleGame/2007_game/game_res/web-mobile/index.html"],2007,nil,out,&error),@"remote game2007 source is never fetched");
    NSURL *unusualRoot=[base URLByAppendingPathComponent:@"ApplicationSupport" isDirectory:YES];
    NSURL *cardsOutsideEntry=CreatePackage(unusualRoot,@"2007_game");
    Check(!RunGame(cache,documents,cardsOutsideEntry,2007,nil,out,&error),@"game2007 exact spelling outside the two OS anchors is rejected");
    NSURL *cardsDevFolder=cardsDevEntry.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent;
    Check([manager removeItemAtURL:cardsDevFolder error:nil]&&[manager createSymbolicLinkAtPath:cardsDevFolder.path withDestinationPath:cardsRoot.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent.path error:nil],@"replace game2007 development folder with a link fixture");
    Check(!RunGame(cache,documents,cardsDevEntry,2007,nil,out,&error),@"even exact game2007 spelling cannot follow package symlink");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"package_unavailable_or_linked"],@"game2007 linked package refusal recorded");
    Check(RunStorage(cache,documents,entry,root.URLByDeletingLastPathComponent,out,&error)!=nil,@"known Caches package still works with both OS anchors");
    Check(!RunStorage(cache,documents,documentsEntry,root.URLByDeletingLastPathComponent,out,&error),@"same relative game folder across different storage roots is not a match");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"native_resource_mismatch"],@"cross-root native mismatch diagnostic");
    NSURL *otherRoot=[base URLByAppendingPathComponent:@"Library/Application Support" isDirectory:YES];
    NSURL *outsideEntry=CreatePackage(otherRoot,@"60_game");
    Check(!RunStorage(cache,documents,outsideEntry,outsideEntry.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent,out,&error),@"native agreement never grants access to unrelated sandbox roots");
    NSURL *documentsWithParameters=[NSURL URLWithString:[documentsEntry.absoluteString stringByAppendingString:@"?token=DOCUMENTS_PRIVATE_TOKEN#PRIVATE_SECTION"]];
    NSDictionary *parameterDocuments=ReadExport(RunStorage(cache,documents,documentsWithParameters,documentsResource,out,&error));
    NSString *documentsJSON=[[NSString alloc]initWithData:[NSJSONSerialization dataWithJSONObject:parameterDocuments?:@{} options:0 error:nil] encoding:NSUTF8StringEncoding];
    Check([parameterDocuments[@"files"] count]==1&&![documentsJSON containsString:@"DOCUMENTS_PRIVATE_TOKEN"]&&![documentsJSON containsString:@"PRIVATE_SECTION"]&&![documentsJSON containsString:base.path],@"Documents query fragment and absolute sandbox path remain private");
    NSURL *documentsAlias=[base URLByAppendingPathComponent:@"DocumentsAlias" isDirectory:YES];
    Check([manager createSymbolicLinkAtPath:documentsAlias.path withDestinationPath:documents.path error:nil],@"create trusted Documents anchor alias");
    Check(RunStorage(cache,documentsAlias,documentsEntry,documentsResource,out,&error)!=nil,@"trusted OS Documents alias canonicalized once");
    NSURL *documentChildLink=[documents URLByAppendingPathComponent:@"littleGame/linked60_game" isDirectory:YES];
    Check([manager createSymbolicLinkAtPath:documentChildLink.path withDestinationPath:documentsResource.URLByDeletingLastPathComponent.path error:nil],@"create child link in Documents fixture");
    NSURL *linkedResource=[documentChildLink URLByAppendingPathComponent:@"game_res" isDirectory:YES];
    Check(!RunStorage(cache,documents,[linkedResource URLByAppendingPathComponent:@"web-mobile/index.html"],linkedResource,out,&error),@"Documents child symlink remains rejected even with native agreement");
    NSURL *documentsSibling=[NSURL fileURLWithPath:[documents.path stringByAppendingString:@"-impostor/littleGame/60_game/game_res/web-mobile/index.html"]];
    Check(!RunStorage(cache,documents,documentsSibling,nil,out,&error),@"Documents prefix impostor rejected");
    NSArray<NSString *> *unsafeSuffixes=@[
        @"littleGame/60_game/../60_game/game_res/web-mobile/index.html",
        @"littleGame/60_game/%2e%2e/60_game/game_res/web-mobile/index.html",
        @"littleGame%2f60_game/game_res/web-mobile/index.html",
        @"littleGame%5c60_game/game_res/web-mobile/index.html",
        @"littleGame/60_game/game_res/web-mobile/index.html.evil",
        @"littleGame/60_game/game_res/web-mobile/index.html%00.js"
    ];
    for(NSString *unsafe in unsafeSuffixes) {
        NSURL *bad=[NSURL URLWithString:[cache.absoluteString stringByAppendingString:unsafe]];
        Check(!Run(cache,bad,out,&error),@"hostile document path rejected without normalization");
    }
    NSURL *sibling=[NSURL fileURLWithPath:[cache.path stringByAppendingString:@"-impostor/littleGame/60_game/game_res/web-mobile/index.html"]];
    Check(!Run(cache,sibling,out,&error),@"cache prefix impostor rejected");
    NSURL *remoteHost=[NSURL URLWithString:[@"file://example.invalid" stringByAppendingString:entry.path]];
    Check(!Run(cache,remoteHost,out,&error),@"nonlocal file authority rejected");
    NSURL *localhost=[NSURL URLWithString:[entry.absoluteString stringByReplacingOccurrencesOfString:@"file:///" withString:@"file://localhost/"]];
    Check(Run(cache,localhost,out,&error)!=nil,@"local file authority accepted without network access");
    NSURL *aliasedCache=[base URLByAppendingPathComponent:@"CachesAlias" isDirectory:YES];
    Check([manager createSymbolicLinkAtPath:aliasedCache.path withDestinationPath:cache.path error:nil],@"create OS cache anchor alias fixture");
    Check(Run(aliasedCache,entry,out,&error)!=nil,@"trusted OS cache alias canonicalized once");
    NSURL *aliasGame=[cache URLByAppendingPathComponent:@"littleGame/alias60_game" isDirectory:YES];
    NSURL *gameFolder=root.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent;
    Check([manager createSymbolicLinkAtPath:aliasGame.path withDestinationPath:gameFolder.path error:nil],@"create child link fixture");
    NSURL *aliasResource=[aliasGame URLByAppendingPathComponent:@"game_res" isDirectory:YES];
    NSURL *aliasEntry=[aliasResource URLByAppendingPathComponent:@"web-mobile/index.html"];
    Check(!RunNative(cache,aliasEntry,aliasResource,out,&error),@"native-matched child symlink still rejected by descriptor policy");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"package_unavailable_or_linked"],@"child link failure carries redacted diagnostic");
    [manager removeItemAtURL:[root URLByAppendingPathComponent:@"project.js"] error:nil];
    Check(!Run(cache,entry,out,&error),@"no-JS source bundle rejected rather than empty success");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"no_complete_javascript"]&&[error.userInfo[STGameSourcePathDiagnosticKey][@"includedFiles"] integerValue]==0,@"empty-source failure records useful bounded diagnostic");
    Check([manager removeItemAtURL:base error:nil],@"remove fixture");
    printf("Game source exporter Foundation: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
}}

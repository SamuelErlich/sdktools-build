#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STGameSourceExporter.h"
#include <stdio.h>
static NSUInteger checks,failures;
static void Check(BOOL test,NSString *message){checks++;if(!test){failures++;fprintf(stderr,"FAIL %s\n",message.UTF8String);}}
static NSURL *RunNative(NSURL *cache,NSURL *entry,NSURL *nativeResource,NSURL *out,NSError **error) {
    __block NSURL *result=nil;__block NSError *failure=nil;
    dispatch_semaphore_t semaphore=dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
        result=[STGameSourceExporter writeSourcesFromCachesURL:cache entryURL:entry verifiedNativeResourceURL:nativeResource destinationDirectory:out error:&failure];
        dispatch_semaphore_signal(semaphore);
    });
    dispatch_semaphore_wait(semaphore,DISPATCH_TIME_FOREVER);if(error)*error=failure;return result;
}
static NSURL *Run(NSURL *cache,NSURL *entry,NSURL *out,NSError **error) {return RunNative(cache,entry,nil,out,error);}
static NSDictionary *ReadExport(NSURL *URL) {
    NSData *data=URL?[NSData dataWithContentsOfURL:URL]:nil;
    return data?[NSJSONSerialization JSONObjectWithData:data options:0 error:nil]:nil;
}
static NSURL *CreatePackage(NSURL *cache,NSString *folder) {
    NSFileManager *manager=[NSFileManager new];
    NSURL *root=[cache URLByAppendingPathComponent:[NSString stringWithFormat:@"littleGame/%@/game_res/web-mobile",folder] isDirectory:YES];
    Check([manager createDirectoryAtURL:root withIntermediateDirectories:YES attributes:nil error:nil],@"create alternate package fixture");
    NSURL *entry=[root URLByAppendingPathComponent:@"index.html"];
    Check([@"<script src='project.js'></script>" writeToURL:entry atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create alternate entry");
    Check([@"function UseProp(){}\n" writeToURL:[root URLByAppendingPathComponent:@"project.js"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create alternate JS");
    return entry;
}
int main(void){@autoreleasepool {
    NSFileManager *manager=[NSFileManager new];
    NSURL *base=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"sdktools-source-foundation-" stringByAppendingString:NSUUID.UUID.UUIDString]] isDirectory:YES];
    NSURL *cache=[base URLByAppendingPathComponent:@"Caches" isDirectory:YES];
    NSURL *root=[cache URLByAppendingPathComponent:@"littleGame/60_game/game_res/web-mobile" isDirectory:YES];
    NSURL *out=[base URLByAppendingPathComponent:@"Output" isDirectory:YES];
    Check([manager createDirectoryAtURL:root withIntermediateDirectories:YES attributes:nil error:nil],@"create exact game cache fixture");
    Check([manager createDirectoryAtURL:out withIntermediateDirectories:YES attributes:nil error:nil],@"create output fixture");
    NSURL *entry=[root URLByAppendingPathComponent:@"index.html"];
    Check([@"<script src='project.js'></script>" writeToURL:entry atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create entry document");
    Check([@"function UseProp(){}\n" writeToURL:[root URLByAppendingPathComponent:@"project.js"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create source fixture");
    Check([@"DO_NOT_EXPORT_RUNTIME_SECRET" writeToURL:[root URLByAppendingPathComponent:@"runtime.json"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create excluded data fixture");
    NSError *error=nil;NSURL *file=Run(cache,entry,out,&error);Check(file!=nil&&error==nil,@"actual production exporter succeeds in background");
    NSData *bytes=[NSData dataWithContentsOfURL:file];NSDictionary *json=bytes?[NSJSONSerialization JSONObjectWithData:bytes options:0 error:nil]:nil;
    Check([json[@"format"] isEqual:@"SDKtools.GameSources"],@"source-bundle format identified");
    Check([json[@"files"] count]==1,@"only JavaScript included");
    NSDictionary *source=[json[@"files"] firstObject];
    Check([source[@"path"] isEqual:@"project.js"],@"only relative path exported");
    Check([source[@"source"] isEqual:@"function UseProp(){}\n"],@"complete unchanged source retained");
    Check([source[@"sha256"] isEqual:@"f177011e631fe70c53b5c9c5700e59f187c9a28c0074fc1e5ecea8589953732d"],@"SHA256 computed over exact source bytes");
    Check([source[@"keywordMatches"][@"UseProp"][@"utf8ByteOffsets"] isEqual:@[@9]],@"keyword location measured in UTF8 bytes");
    Check(![json[@"metadata"][@"loadedRuntimeEquivalenceProven"] boolValue]&&![json[@"metadata"][@"atomicWholeBundleSnapshot"] boolValue],@"disk evidence never claims current runtime equivalence");
    NSString *serialized=[[NSString alloc]initWithData:bytes encoding:NSUTF8StringEncoding];
    Check(![serialized containsString:@"DO_NOT_EXPORT_RUNTIME_SECRET"]&&![serialized containsString:base.path],@"non-source data and absolute sandbox paths excluded");
    Check(![STGameSourceExporter writeSourcesFromCachesURL:cache entryURL:entry destinationDirectory:out error:&error],@"main-thread filesystem scan rejected");
    Check(!Run(cache,[NSURL URLWithString:@"https://example.invalid/index.html"],out,&error),@"remote document rejected without network");
    Check(!Run(cache,[root URLByAppendingPathComponent:@"another.html"],out,&error),@"different entry rejected");
    NSURL *parameterized=[NSURL URLWithString:[entry.absoluteString stringByAppendingString:@"?session=PRIVATE_URL_TOKEN#PRIVATE_FRAGMENT"]];
    NSDictionary *withParameters=ReadExport(Run(cache,parameterized,out,&error));
    Check([withParameters[@"files"] count]==1,@"query and fragment do not alter the exact local source path");
    NSString *parameterJSON=[[NSString alloc]initWithData:[NSJSONSerialization dataWithJSONObject:withParameters?:@{} options:0 error:nil] encoding:NSUTF8StringEncoding];
    Check(![parameterJSON containsString:@"PRIVATE_URL_TOKEN"]&&![parameterJSON containsString:@"PRIVATE_FRAGMENT"],@"URL query and fragment contents never exported");
    Check([withParameters[@"metadata"][@"pathDiagnostic"][@"hasQuery"] boolValue]&&[withParameters[@"metadata"][@"pathDiagnostic"][@"hasFragment"] boolValue],@"parameter presence diagnostics retained without values");
    NSURL *developerEntry=CreatePackage(cache,@"dev_60_game");
    Check(Run(cache,developerEntry,out,&error)!=nil,@"known native dev game60 path accepted");
    NSURL *variantEntry=CreatePackage(cache,@"runtime60_package");
    NSURL *variantResource=variantEntry.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent;
    Check(!Run(cache,variantEntry,out,&error),@"unknown folder alone never establishes game identity");
    NSDictionary *nativeExport=ReadExport(RunNative(cache,variantEntry,variantResource,out,&error));
    Check([nativeExport[@"files"] count]==1,@"current document must match original native game60 resource exactly");
    Check([nativeExport[@"metadata"][@"rootSelection"] isEqual:@"original_game60_native_resource_and_current_document"],@"native root provenance recorded");
    Check(!RunNative(cache,entry,variantResource,out,&error),@"native resource mismatch rejected even for fallback folder");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"native_resource_mismatch"],@"mismatch has structured diagnostic");
    Check(!RunNative(cache,entry,[base URLByAppendingPathComponent:@"outside/game_res"],out,&error),@"native path outside OS cache rejected");
    NSURL *otherEntry=CreatePackage(cache,@"61_game");
    Check(!Run(cache,otherEntry,out,&error),@"different game folder rejected");
    NSData *diagnosticData=[NSJSONSerialization dataWithJSONObject:error.userInfo[STGameSourcePathDiagnosticKey]?:@{} options:0 error:nil];
    NSString *diagnosticText=[[NSString alloc]initWithData:diagnosticData encoding:NSUTF8StringEncoding];
    Check(![diagnosticText containsString:base.path]&&![diagnosticText containsString:@"61_game"],@"diagnostic never reveals sandbox or arbitrary folder names");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"pathShape"] containsObject:@"<other>"],@"unknown path segments explicitly redacted");
    NSArray<NSString *> *unsafeSuffixes=@[
        @"littleGame/60_game/../60_game/game_res/web-mobile/index.html",
        @"littleGame/60_game/%2e%2e/60_game/game_res/web-mobile/index.html",
        @"littleGame%2f60_game/game_res/web-mobile/index.html",
        @"littleGame%5c60_game/game_res/web-mobile/index.html",
        @"littleGame/60_game/game_res/web-mobile/index.html.evil",
        @"littleGame/60_game/game_res/web-mobile/index.html%00.js"
    ];
    for(NSString *unsafe in unsafeSuffixes) {
        NSURL *bad=[NSURL URLWithString:[cache.absoluteString stringByAppendingString:unsafe]];
        Check(!Run(cache,bad,out,&error),@"hostile document path rejected without normalization");
    }
    NSURL *sibling=[NSURL fileURLWithPath:[cache.path stringByAppendingString:@"-impostor/littleGame/60_game/game_res/web-mobile/index.html"]];
    Check(!Run(cache,sibling,out,&error),@"cache prefix impostor rejected");
    NSURL *remoteHost=[NSURL URLWithString:[@"file://example.invalid" stringByAppendingString:entry.path]];
    Check(!Run(cache,remoteHost,out,&error),@"nonlocal file authority rejected");
    NSURL *localhost=[NSURL URLWithString:[entry.absoluteString stringByReplacingOccurrencesOfString:@"file:///" withString:@"file://localhost/"]];
    Check(Run(cache,localhost,out,&error)!=nil,@"local file authority accepted without network access");
    NSURL *aliasedCache=[base URLByAppendingPathComponent:@"CachesAlias" isDirectory:YES];
    Check([manager createSymbolicLinkAtPath:aliasedCache.path withDestinationPath:cache.path error:nil],@"create OS cache anchor alias fixture");
    Check(Run(aliasedCache,entry,out,&error)!=nil,@"trusted OS cache alias canonicalized once");
    NSURL *aliasGame=[cache URLByAppendingPathComponent:@"littleGame/alias60_game" isDirectory:YES];
    NSURL *gameFolder=root.URLByDeletingLastPathComponent.URLByDeletingLastPathComponent;
    Check([manager createSymbolicLinkAtPath:aliasGame.path withDestinationPath:gameFolder.path error:nil],@"create child link fixture");
    NSURL *aliasResource=[aliasGame URLByAppendingPathComponent:@"game_res" isDirectory:YES];
    NSURL *aliasEntry=[aliasResource URLByAppendingPathComponent:@"web-mobile/index.html"];
    Check(!RunNative(cache,aliasEntry,aliasResource,out,&error),@"native-matched child symlink still rejected by descriptor policy");
    Check([error.userInfo[STGameSourcePathDiagnosticKey][@"classification"] isEqual:@"package_unavailable_or_linked"],@"child link failure carries redacted diagnostic");
    [manager removeItemAtURL:[root URLByAppendingPathComponent:@"project.js"] error:nil];
    Check(!Run(cache,entry,out,&error),@"no-JS source bundle rejected rather than empty success");
    Check([manager removeItemAtURL:base error:nil],@"remove fixture");
    printf("Game source exporter Foundation: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
}}

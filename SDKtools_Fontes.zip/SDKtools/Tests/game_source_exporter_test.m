#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STGameSourceExporter.h"
#include <stdio.h>
static NSUInteger checks,failures;
static void Check(BOOL test,NSString *message){checks++;if(!test){failures++;fprintf(stderr,"FAIL %s\n",message.UTF8String);}}
static NSURL *Run(NSURL *cache,NSURL *entry,NSURL *out,NSError **error) {
    __block NSURL *result=nil;__block NSError *failure=nil;
    dispatch_semaphore_t semaphore=dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
        result=[STGameSourceExporter writeSourcesFromCachesURL:cache entryURL:entry destinationDirectory:out error:&failure];
        dispatch_semaphore_signal(semaphore);
    });
    dispatch_semaphore_wait(semaphore,DISPATCH_TIME_FOREVER);if(error)*error=failure;return result;
}
int main(void){@autoreleasepool {
    NSFileManager *manager=[NSFileManager new];
    NSURL *base=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"sdktools-source-foundation-" stringByAppendingString:NSUUID.UUID.UUIDString]] isDirectory:YES];
    NSURL *cache=[base URLByAppendingPathComponent:@"Caches" isDirectory:YES];
    NSURL *root=[cache URLByAppendingPathComponent:@"littleGame/60_game/game_res/web-mobile" isDirectory:YES];
    NSURL *out=[base URLByAppendingPathComponent:@"Output" isDirectory:YES];
    Check([manager createDirectoryAtURL:root withIntermediateDirectories:YES attributes:nil error:nil],@"create exact game cache fixture");
    Check([manager createDirectoryAtURL:out withIntermediateDirectories:YES attributes:nil error:nil],@"create output fixture");
    NSURL *entry=[root URLByAppendingPathComponent:@"index.html"];
    Check([@"<script src='project.js'></script>" writeToURL:entry atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create entry document");
    Check([@"function UseProp(){}\n" writeToURL:[root URLByAppendingPathComponent:@"project.js"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create source fixture");
    Check([@"DO_NOT_EXPORT_RUNTIME_SECRET" writeToURL:[root URLByAppendingPathComponent:@"runtime.json"] atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create excluded data fixture");
    NSError *error=nil;NSURL *file=Run(cache,entry,out,&error);Check(file!=nil&&error==nil,@"actual production exporter succeeds in background");
    NSData *bytes=[NSData dataWithContentsOfURL:file];NSDictionary *json=bytes?[NSJSONSerialization JSONObjectWithData:bytes options:0 error:nil]:nil;
    Check([json[@"format"] isEqual:@"SDKtools.GameSources"],@"source-bundle format identified");
    Check([json[@"files"] count]==1,@"only JavaScript included");
    NSDictionary *source=[json[@"files"] firstObject];
    Check([source[@"path"] isEqual:@"project.js"],@"only relative path exported");
    Check([source[@"source"] isEqual:@"function UseProp(){}\n"],@"complete unchanged source retained");
    Check([source[@"sha256"] isEqual:@"f177011e631fe70c53b5c9c5700e59f187c9a28c0074fc1e5ecea8589953732d"],@"SHA256 computed over exact source bytes");
    Check([source[@"keywordMatches"][@"UseProp"][@"utf8ByteOffsets"] isEqual:@[@9]],@"keyword location measured in UTF8 bytes");
    Check(![json[@"metadata"][@"loadedRuntimeEquivalenceProven"] boolValue]&&![json[@"metadata"][@"atomicWholeBundleSnapshot"] boolValue],@"disk evidence never claims current runtime equivalence");
    NSString *serialized=[[NSString alloc]initWithData:bytes encoding:NSUTF8StringEncoding];
    Check(![serialized containsString:@"DO_NOT_EXPORT_RUNTIME_SECRET"]&&![serialized containsString:base.path],@"non-source data and absolute sandbox paths excluded");
    Check(![STGameSourceExporter writeSourcesFromCachesURL:cache entryURL:entry destinationDirectory:out error:&error],@"main-thread filesystem scan rejected");
    Check(!Run(cache,[NSURL URLWithString:@"https://example.invalid/index.html"],out,&error),@"remote document rejected without network");
    Check(!Run(cache,[root URLByAppendingPathComponent:@"another.html"],out,&error),@"different entry rejected");
    Check(!Run(cache,[NSURL URLWithString:[entry.absoluteString stringByAppendingString:@"?unverified=1"]],out,&error),@"unverified query document rejected");
    [manager removeItemAtURL:[root URLByAppendingPathComponent:@"project.js"] error:nil];
    Check(!Run(cache,entry,out,&error),@"no-JS source bundle rejected rather than empty success");
    Check([manager removeItemAtURL:base error:nil],@"remove fixture");
    printf("Game source exporter Foundation: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
}}

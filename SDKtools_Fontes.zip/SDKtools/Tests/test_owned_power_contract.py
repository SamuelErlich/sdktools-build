"""Portable wiring invariants; device execution remains a separate stage."""
from pathlib import Path
import json
import unittest
ROOT=Path(__file__).resolve().parents[1]
class OwnedPowerContracts(unittest.TestCase):
    def read(self,name):return (ROOT/name).read_text(encoding='utf-8')
    def test_observer_is_passed_without_new_native_action_permission(self):
        source=self.read('Resources/autoplay_tool.js')
        self.assertIn('powers=makePowers(originalPower,makeCovered,win);',source)
        self.assertLess(len(source.encode()),65536)
        powers=self.read('Resources/autoplay_powers.js')
        self.assertIn("{kind:'penetrate_owned'}",powers)
        self.assertNotIn("kind:'penetrate_zero'",powers)
        self.assertIn('options.allowAction!==true',powers)
        self.assertIn('options.powersEnabled!==true',powers)
        self.assertIn('spentSinceMove',powers)
        self.assertNotRegex(powers,r'\.(?:send|TouchBlock|sync)\s*\(')
    def test_kind_requires_positive_stock_and_never_replaces_zero_contract(self):
        source=self.read('Resources/alpaca_covered.js')
        self.assertIn("if(kind==='penetrate_owned'){if(count<1)",source)
        self.assertIn("else if(count!==0)throw Error('penetrate_stock_not_zero')",source)
        self.assertIn('consistent(s,{store:store,rawID:c.rawID})',source)
        self.assertIn("hand.length>=7",source)
        self.assertIn("responseOutcome=j.code===200?'accepted':'rejected'",source)
    def test_primary_source_hash_and_explicit_unknown_are_preserved(self):
        evidence=json.loads(self.read('Analysis/V4_0_11-owned-powers-evidence.json'))
        self.assertFalse(evidence['gameServerContacted'])
        self.assertEqual(evidence['sources'][0]['sha256'],'cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6')
        self.assertIn('unproven',evidence['serverSelectionForBomb'])
        self.assertIn('Bomb(4) stays blocked',self.read('Resources/autoplay_powers.js'))
    def test_native_boundary_and_translated_ui(self):
        sanitizer=self.read('Sources/SDKtools/STAutoplaySanitizer.inc')
        self.assertIn('STWPAutoCount(powers[@"type"], 5)',sanitizer)
        self.assertIn('CFBooleanGetTypeID()',sanitizer)
        self.assertIn('@"power_rejected"',sanitizer)
        rows=json.loads(self.read('Resources/Brand/menu-localizations.json'))['entries']
        self.assertTrue(any('Penetrate: trio confirmado' in row['pt'] for row in rows))
        self.assertTrue(any('Bomb conserved' in row['en'] for row in rows))
if __name__=='__main__':unittest.main()

'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_early.js'),'utf8');
function fixture(options={}){
  let time=0,scene=null,nextTimer=0;const timers=new Map(),listeners=new Map(),messages=[],loads=[],deferred=[],requests=[];
  const clone=v=>JSON.parse(JSON.stringify(v));
  const document={hidden:false,visibilityState:'visible',addEventListener(n,f){listeners.set('doc:'+n,f);},removeEventListener(n,f){if(listeners.get('doc:'+n)===f)listeners.delete('doc:'+n);}};
  const spriteCalls=[];
  const skin={setCardBg(type,color,sprite){spriteCalls.push({type,color,sprite});if(options.asyncSkin)return new Promise(resolve=>deferred.push(()=>{sprite.frame=color;resolve();}));sprite.frame=color;return undefined;},setCardType(color,type,num,sprite){sprite.frame=color;return 'same-return';}};
  class Card{constructor(){this._node={_parent:{},active:true};this.bgSprite={};this.typeSprite={};this.backSprite={};}setup(card){this.cardInfo=card;if(card.type!==0){skin.setCardBg(card.type,card.color,this.bgSprite);skin.setCardType(card.color,card.type,card.num,this.typeSprite);}return card;}}
  class HandArea{setup(gamer){this.gamer=gamer;return gamer;}}
  class Game{}
  class Store{constructor(){this.gamers=[];this.state=2;}sync(value){Object.assign(this,value);return value;}updatePushMessage(value){Object.assign(this,value);return value;}}
  const store=new Store();
  class Socket{
    constructor(){this.packetId=1;this.responseMap={};this.pushHandler=null;}
    establish(){this.socket={onmessage:this.onMessage.bind(this)};return this.socket;}
    resisterPushHandler(handler){this.pushHandler=handler;return 17;}
    sync(){return this.send('CMD_SYNC');}
    send(command,param){const id=this.packetId++;const promise=new Promise((resolve,reject)=>{this.responseMap[id]={resolve,reject};});requests.push({id,command,param,promise});return promise;}
    onMessage({data}){const packet=JSON.parse(data);if(packet.body_encoding)throw Error('unexpected compressed fixture');if(packet.packet_id){const r=this.responseMap[packet.packet_id];delete this.responseMap[packet.packet_id];if(packet.code===200)r.resolve(packet.message);else r.reject(packet.message);}else if(this.pushHandler)return this.pushHandler(packet.event,packet.message);}
  }
  const socket=new Socket();
  if(options.connected)socket.establish();
  const modules={Card:{default:Card},HandArea:{default:HandArea},game:{default:Game},GameStore:{default:store},Socket:{default:socket},CardSkinManager:{default:skin}};
  // A prepopulated CommonJS cache represents the already executed main entries.
  const cache=Object.fromEntries(Object.entries(modules).map(([key,exports])=>[key,{exports}]));
  function __require(name){loads.push(name);if(cache[name])return cache[name].exports;if(modules[name]){const entry={exports:{}};modules[name].call(entry.exports,__require,entry);return entry.exports;}throw new Error('Cannot find module '+name);}
  const cc={ENGINE_VERSION:options.engine||'2.4.5',isValid:o=>!!o&&!o.destroyed,js:{getClassByName:n=>({Card,HandArea,game:Game}[n])},Director:{EVENT_BEFORE_SCENE_LAUNCH:'before-scene'},director:{getScene:()=>scene,on(n,f){listeners.set('cc:'+n,f);},off(n,f){if(listeners.get('cc:'+n)===f)listeners.delete('cc:'+n);}}};
  const context={document,cc,performance:{now:()=>time},crypto:{getRandomValues:a=>{a.forEach((_,i)=>a[i]=i+1);return a;}},webkit:{messageHandlers:{early:{postMessage(message){messages.push(clone(message));if(options.rejectBridge)return Promise.reject(Error('denied'));if(options.hangBridge)return new Promise(()=>{});return Promise.resolve({active:options.active!==false});}}}},setInterval(fn){const id=++nextTimer;timers.set(id,fn);return id;},clearInterval(id){timers.delete(id);},addEventListener(n,f){listeners.set(n,f);},removeEventListener(n,f){if(listeners.get(n)===f)listeners.delete(n);}};
  context.window=context;context.top=options.subframe?{}:context;if(options.late)context.__require=__require;
  if(options.accessor)Object.defineProperty(context,'__require',{configurable:true,get:options.accessor});
  if(options.noEngine)delete context.cc;
  if(options.beforeStart)options.beforeStart({context,store,socket,Card,HandArea,skin,cc,modules});
  const runtime=vm.runInNewContext(source,context)({handlerName:'early',token:'0123456789abcdef0123456789abcdef'});
  const flush=async()=>{await Promise.resolve();await Promise.resolve();};
  return {runtime,context,document,cc,Card,HandArea,store,socket,skin,modules,messages,loads,requests,deferred,spriteCalls,listeners,
    async load(){context.__require=__require;await flush();},async advance(ms=250){time+=ms;for(const fn of [...timers.values()])fn();await flush();},flush,
    async drain(){await flush();await this.advance();return messages.flatMap(m=>m.observation.events);},
    deliver(value,id=requests.at(-1).id){return (socket.socket?socket.socket.onmessage:socket.onMessage.bind(socket))({data:JSON.stringify({packet_id:id,code:200,message:value})});},
    async scene(){const fn=listeners.get('cc:before-scene');if(fn)fn();scene={};await flush();},
    snapshot:()=>clone(runtime.snapshot()),timerCount:()=>timers.size,events:()=>messages.flatMap(m=>m.observation.events),emit(name){const fn=listeners.get(name);if(fn)fn();}};
}
module.exports={fixture};

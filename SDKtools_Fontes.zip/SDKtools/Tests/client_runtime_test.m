#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <dispatch/dispatch.h>
#include <math.h>
#include <assert.h>
#include "STBilliardsLivePolicy.h"

// Synthetic UIKit boundary. The production bookkeeping and automation methods
// below are extracted verbatim; this is not a live UIKit/device test.
static double clockNow=10;
static double CACurrentMediaTime(void) { return clockNow; }
static NSString *const UIKeyboardWillShowNotification=@"keyboard_show";
static NSString *const UIKeyboardDidHideNotification=@"keyboard_hide";
static NSString *const UIApplicationDidEnterBackgroundNotification=@"background";
typedef NS_ENUM(NSInteger,UITouchPhase) { UITouchPhaseBegan,UITouchPhaseMoved,UITouchPhaseStationary,UITouchPhaseEnded,UITouchPhaseCancelled };
typedef NS_ENUM(NSInteger,UIEventType) { UIEventTypeTouches,UIEventTypeOther };
@interface UIWindow : NSObject @end
@implementation UIWindow @end
@interface STOverlayWindow : UIWindow @end
@implementation STOverlayWindow @end
@interface UITouch : NSObject
@property(nonatomic) UITouchPhase phase;
@property(nonatomic,strong) UIWindow *window;
@end
@implementation UITouch @end
@interface UIEvent : NSObject
@property(nonatomic) UIEventType type;
@property(nonatomic,copy) NSSet<UITouch *> *allTouches;
@end
@implementation UIEvent @end
#include "interaction.inc"

static NSUInteger checks;
#define CHECK(c) do { checks++; if (!(c)) { NSLog(@"FAIL line %d: %s",__LINE__,#c); abort(); } } while (0)
static NSUInteger actionCalls,suspendCalls,stopCalls,armCalls;
static NSString *responsePhase=@"planning";
static NSDictionary *context;
@interface STRecorder : NSObject
+ (instancetype)shared;
- (BOOL)ensureEventObservation;
@end
@implementation STRecorder
+ (instancetype)shared { static id shared; if (!shared) shared=[self new]; return shared; }
- (BOOL)ensureEventObservation { return YES; }
@end
@interface STBilliardsLuaBridge : NSObject
+ (NSDictionary *)executeCommand:(NSString *)command error:(NSError **)error;
@end
@implementation STBilliardsLuaBridge
+ (NSDictionary *)executeCommand:(NSString *)command error:(NSError **)error {
    (void)error;
    if ([command isEqual:@"stop"]) { stopCalls++; return @{}; }
    if ([command isEqual:@"suspend"]) { suspendCalls++; return @{@"reason":@"interaction_suspended"}; }
    if ([command hasPrefix:@"arm_"]) {
        armCalls++; NSMutableDictionary *arm=[context mutableCopy];
        arm[@"automation"]=@{@"reason":@"automation_armed"}; return arm;
    }
    CHECK(([@[@"aim",@"autoplay"] containsObject:command])); actionCalls++;
    return @{@"automation":@{@"schemaVersion":@1,@"phase":responsePhase,@"reason":@"stabilizing"}};
}
@end
static NSNotificationName const STBilliardsRuntimeDidChangeNotification=@"runtime";
#include "shot_helpers.h"
@interface STBilliardsRuntime : NSObject
@property(nonatomic) BOOL enabled;
@property(nonatomic) BOOL automationNeedsFreshInput;
@property(nonatomic) BOOL automationEverEnabled;
@property(nonatomic) BOOL automationEverAutoplay;
@property(nonatomic) NSUInteger automationMode;
@property(nonatomic) uint64_t automationFrame;
@property(nonatomic) double startedAt;
@property(nonatomic) NSRect acceptedGameRect;
@property(nonatomic,copy) NSDictionary *automationContext;
@property(nonatomic,copy) NSDictionary *lastAutomation;
@property(nonatomic,strong) NSMutableArray *automationHistory;
@property(nonatomic,copy) NSString *statusText;
- (void)suspendForInteraction;
- (void)pauseAutomationWithReason:(NSString *)reason;
- (void)runAutomationForSnapshot:(NSDictionary *)snapshot;
@end
@implementation STBilliardsRuntime
@synthesize automationMode=_automationMode;
- (void)publishStatus:(NSString *)text { self.statusText=text; }
#include "automation.inc"
@end
static NSDictionary *snapshot(NSUInteger frame) {
    NSMutableDictionary *s=[context mutableCopy]; s[@"frameNumber"]=@(frame); return s;
}
int main(void) { @autoreleasepool {
    CHECK(!STClientInteractionBlocked());
    UIWindow *host=[UIWindow new]; STOverlayWindow *sdk=[STOverlayWindow new];
    UITouch *touch=[UITouch new];touch.window=sdk;touch.phase=UITouchPhaseBegan;
    UIEvent *event=[UIEvent new];event.type=UIEventTypeTouches;event.allTouches=[NSSet setWithObject:touch];
    CHECK(!STClientObserveInputEvent(event));CHECK(!STClientInteractionBlocked());
    touch.window=host;CHECK(STClientObserveInputEvent(event));CHECK(STClientInteractionBlocked());
    clockNow+=2;CHECK(STClientInteractionBlocked()); // held touches do not time out
    touch.phase=UITouchPhaseEnded;CHECK(!STClientObserveInputEvent(event));CHECK(STClientInteractionBlocked());
    clockNow+=.36;CHECK(!STClientInteractionBlocked());
    context=@{@"scene":@{@"name":@"BilliardInGame",@"handle":@41},@"sessionId":@700,
        @"cameraInstanceId":@(-101),@"screen":@{@"width":@1170,@"height":@2532},@"frameNumber":@1};
    STBilliardsRuntime *runtime=[STBilliardsRuntime new];runtime.enabled=YES;
    runtime.automationHistory=[NSMutableArray array];runtime.acceptedGameRect=NSMakeRect(0,0,390,844);
    runtime.automationMode=2;CHECK(runtime.automationMode==2 && armCalls==1);
    [runtime runAutomationForSnapshot:snapshot(2)];CHECK(actionCalls==1);
    [[NSNotificationCenter defaultCenter] postNotificationName:UIKeyboardWillShowNotification object:nil];
    [runtime runAutomationForSnapshot:snapshot(3)];
    CHECK(STClientInteractionBlocked());CHECK(runtime.automationMode==2);CHECK(actionCalls==1);
    clockNow+=5;[runtime runAutomationForSnapshot:snapshot(4)];CHECK(actionCalls==1);
    [[NSNotificationCenter defaultCenter] postNotificationName:UIKeyboardDidHideNotification object:nil];
    [runtime runAutomationForSnapshot:snapshot(5)];CHECK(actionCalls==1);
    clockNow+=.36;[runtime runAutomationForSnapshot:snapshot(6)];
    CHECK(runtime.automationMode==2);CHECK(suspendCalls==1 && actionCalls==2 && armCalls==1);
    [runtime runAutomationForSnapshot:snapshot(6)];CHECK(actionCalls==2); // duplicate frame
    // Keyboard-induced screen resize is not a new match. Still require a valid viewport.
    NSMutableDictionary *resized=[snapshot(7) mutableCopy];resized[@"screen"]=@{@"width":@780,@"height":@1688};
    [runtime runAutomationForSnapshot:resized];CHECK(actionCalls==3 && runtime.automationMode==2);
    resized[@"screen"]=@{@"width":@780,@"height":@800};resized[@"frameNumber"]=@8;
    [runtime runAutomationForSnapshot:resized];CHECK(actionCalls==3 && runtime.automationMode==2);
    [runtime runAutomationForSnapshot:snapshot(9)];CHECK(suspendCalls==2 && actionCalls==4);
    // Chat touch preserves opt-in; every resume invalidates prepared input once.
    touch.phase=UITouchPhaseBegan; if (STClientObserveInputEvent(event)) [runtime suspendForInteraction];
    [runtime runAutomationForSnapshot:snapshot(10)];CHECK(actionCalls==4 && runtime.automationMode==2);
    touch.phase=UITouchPhaseCancelled;STClientObserveInputEvent(event);clockNow+=.36;
    [runtime runAutomationForSnapshot:snapshot(11)];CHECK(suspendCalls==3 && actionCalls==5 && armCalls==1);
    NSMutableDictionary *changed=[snapshot(12) mutableCopy];changed[@"sessionId"]=@701;
    [runtime runAutomationForSnapshot:changed];CHECK(runtime.automationMode==0 && actionCalls==5);
    runtime.automationMode=1;responsePhase=@"uncertain";NSUInteger stops=stopCalls;
    [runtime runAutomationForSnapshot:snapshot(13)];CHECK(runtime.automationMode==0 && actionCalls==6);
    CHECK(stopCalls==stops); // preserve terminal Lua latch
    [runtime runAutomationForSnapshot:snapshot(14)];CHECK(actionCalls==6);
    [[NSNotificationCenter defaultCenter] postNotificationName:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationDidEnterBackgroundNotification object:nil];
    CHECK(!STClientInteractionBlocked());
    printf("Client interaction and production automation: %lu checks passed\n",(unsigned long)checks);
} return 0; }

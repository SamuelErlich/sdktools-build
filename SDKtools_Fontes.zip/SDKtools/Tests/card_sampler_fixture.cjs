'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {fixture}=require('./card_selected_fixture.cjs');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_sampler.js'),'utf8');
function setup({integrated=false,...options}={}){
 const f=fixture({selected:{id:0,type:0,color:0,num:0},...options,samplerSource:integrated?source:null});
 class HandArea{}class Game{}
 f.cc.js={getClassByName:name=>({Card:f.Card,HandArea,game:Game})[name]};
 const modules={Card:f.Card,HandArea,game:Game,GameStore:f.store,Socket:f.socket};
 f.win.__require=name=>({default:modules[name]});
 const intervals=new Map();let nextTimer=0;
 f.win.setInterval=(fn,ms)=>{intervals.set(++nextTimer,{fn,ms});return nextTimer;};
 f.win.clearInterval=id=>intervals.delete(id);
 f.store.sync=function(payload){Object.assign(this,payload);};
 f.store.updatePushMessage=function(payload){Object.assign(this,payload);};
 f.Card.prototype.setup=function(info){this.cardInfo=info;};
 for(const hand of f.hands)for(const x of hand.nodes)x.component.node=x.c.node;
 const sampler=integrated?null:vm.runInContext(source,f.context)();
 return Object.assign(f,{sampler,intervals,fireTimers:()=>[...intervals.values()].forEach(t=>t.fn()),modules});
}
module.exports={setup,source};

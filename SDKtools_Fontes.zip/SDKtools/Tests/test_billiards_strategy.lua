local strategyPath,probePath,fixturePath,geometryPath=...
assert(_VERSION=="Lua 5.3")
local function read(p) local f=assert(io.open(p,"rb"));local s=f:read("*a");f:close();return s end
local source=read(strategyPath)
-- Supply only the standard numeric/table functions to the pure module.
local M=assert(load(source,"@billiards_strategy","t",{math=math,type=type,ipairs=ipairs,table=table}))()
local checks=0
local function check(ok,message) assert(ok,message);checks=checks+1 end
local function clone(v) if type(v)~="table" then return v end;local o={};for k,x in pairs(v) do o[k]=clone(x) end;return o end
local function base()
 local s={white={x=0,z=0},balls={{tag=1,number=0,active=true,potted=false,world={x=0,z=0}},
  {tag=2,number=1,active=true,potted=false,world={x=0,z=1}}},
  radius=.165,mass=.45,inertia=.0049005,dt=.02,drag=.5,angularDrag=.5,mu=1,stopSquared=.008,
  maximum=750,reference=750,deadzone=.08,phase=7,group=1,gain=1,
  bounds={xmin=-5.5,xmax=5.5,zmin=-2.5,zmax=2.5},
  pockets={{x=-5.735,z=-2.815,index=1},{x=0,z=-2.815,index=2},{x=5.735,z=-2.815,index=3},
   {x=-5.735,z=2.815,index=4},{x=0,z=2.815,index=5},{x=5.735,z=2.815,index=6}}}
 return s
end
local s=base();local plans,reason=M.plan(s)
check(plans and reason=="ready","direct plans required")
check(plans[1].target==2 and plans[1].kind=="direct","nearest direct selected")
check(plans[1].power>s.maximum*s.deadzone and plans[1].power<=s.maximum,"power bounded by live slider/deadzone")
check(math.abs(plans[1].angle)<.001,"atan2 direction convention")
check(M.launch(750,750,.45)==.031*750/.45,"impulse divided by mass, not dt")
check(M.launch(375,750,.45)<M.launch(750,750,.45)/2,"nonlinear power")
check(M.flight(4,0,s)>M.flight(2,0,s),"range monotonic")
local v,x,t=M.flight(4,0,s,nil,.1)
check(v<4 and x>0 and math.abs(t-.1)<1e-6,"free-flight calibration sampling")
for _,key in ipairs({"mass","inertia","radius","maximum","reference","dt","drag","angularDrag","mu","stopSquared","group","phase"}) do
 local q=base();q[key]=0/0;check(M.plan(q)==nil,"invalid profile rejected: "..key)
end
local q=base();q.group=2;q.balls[3]={tag=10,number=9,active=true,potted=false,world={x=2,z=1}}
local p=M.plan(q);check(p and p[1].target==10,"wrong group not targeted")
q=base();q.balls[3]={tag=9,number=8,active=true,potted=false,world={x=1,z=1}}
p=M.plan(q);check(p and p[1].target~=9,"8 ball protected until group cleared")
q=base();q.balls[2].active=false;q.balls[2].potted=true;q.balls[3]={tag=9,number=8,active=true,potted=false,world={x=0,z=1}}
p=M.plan(q);check(p and p[1].target==9,"8 ball eligible after own group cleared")
q=base();q.phase=3;p=M.plan(q);check(p and p[1].kind=="break" and p[1].power==q.maximum,"break uses live slider maximum")
q=base();q.maximum=90;p=M.plan(q);check(not p or p[1].power<=90,"break max separate from power reference")
-- Seek a bank with blockers on the direct route, exercising mirror geometry.
local bank
for z=-1.5,1.5,.25 do
 q=base();q.balls[2].world={x=2,z=z}
 q.balls[3]={tag=10,number=9,active=true,potted=false,world={x=3.8,z=1.9}}
 p=M.plan(q)
 if p then for _,c in ipairs(p) do if c.kind=="bank" then bank=c end end end
end
check(bank and bank.bank and bank.power>0,"one-rail candidates computed")
-- Reuse the original observer's synthetic environment prefix, not game Lua.
local fixture=read(fixturePath)
local prefix=assert(fixture:match("^(.-)local function clone"))
local test=[=[
local strategyPath=...
local geometry=assert(loadfile(select(5,...)))()
local function read(p) local f=assert(io.open(p,"rb"));local s=f:read("*a");f:close();return s end
probe=assert(load("local SDK321Planner=(function()\n"..read(strategyPath).."\nend)()\n"..read(probePath),"@combined","t",_G))
local checks,shots,aims=0,0,0
local function check(v,m) assert(v,m);checks=checks+1 end
white.transform.position=v(0,0,0);target.transform.position=v(0,0,1)
-- Real frame keeps all sixteen identities, including potted/inactive balls.
for tag=3,16 do local b=ball(tag,0);b.ballActive=false;b.poted=true;frame.balls[tag]=b end
frame.roundId=1;frame.selfColor=1;frame.frameStateLogic.frameState=7;frame.frameStateLogic.turnData.turnCount=1
frame.gameDataLogic={gameInfoData={},gameId="1234"};frame.gameView.frameLogic=frame;frame.gameView.powerSld.touchable=true
frame.gameView.settingItem={touchable=true} -- enabled launcher, no settings dialog
frame.updateCueDir=function(self,angle)
 aims=aims+1;local r=math.rad(angle);self.curDir=v(math.sin(r),0,math.cos(r))
 self.auxiliaryLine.auxData.cueEndPos=v(self.curDir.x*1.67,0,self.curDir.z*1.67)
end
frame.updatePower=function(self,p) self.gameView.powerSld.value=p end
frame.gameView.updateSliderUI=function() end
frame.gameView.onPowerRelease=function()
 shots=shots+1;frame.ballsInMovement=true;frame.canShot=false;white.rigidbody.velocity=v(0,0,4)
end
local pots,colliders={},{}
local places={}
for _,p in ipairs(geometry.pockets) do places[#places+1]={p.name,p.x,p.z} end
for i,a in ipairs(places) do
 local c=environmentCollider(700+i,a[1],"Pot"..i,true)
 c.transform.name=a[1];c.transform.tag="Pot"..i;c.transform.position=v(a[2],0,a[3]);pots[i]=c.transform;colliders[i]=c
end
pots[7]={name="PotsRollBalls",tag="Untagged",position=v(0,-2,0)}
CS.UnityEngine.GameObject={Find=function(name)
 check(name=="Table/Pots","fixed read-only geometry lookup")
 return {scene=currentScene,transform={childCount=geometry.childCount,GetChild=function(_,i) return pots[i+1] end}}
end}
local function circle(origin,dir,cx,cz,r)
 local dx,dz=origin.x-cx,origin.z-cz;local b=dx*dir.x+dz*dir.z
 local c=dx*dx+dz*dz-r*r;local h=b*b-c
 if h<0 then return end
 local d=-b-math.sqrt(h);if d<0 then return end;return d
end
CS.UnityEngine.Physics.SphereCastAll=function(origin,radius,dir,distance,mask,trigger)
 check(distance==20 and mask==524289 and trigger==2,"live query contract")
 if dir.y==-1 then return hits({hit(surface,.5,v(0,1,0))}) end
 local out={}
 for _,b in ipairs(frame.balls) do
  if b.ballActive and not b.poted then
   local pos=b.transform.position;local d=circle(origin,dir,pos.x,pos.z,.33)
   if d then out[#out+1]=hit(b.collider,d) end
  end
 end
 for i,p in ipairs(pots) do if i<=6 then
  local d=circle(origin,dir,p.position.x,p.position.z,.4)
  if d then out[#out+1]=hit(colliders[i],d) end
 end end
 return hits(out)
end
surface.sharedMaterial={dynamicFriction=1,staticFriction=1,bounciness=0,frictionCombine=3,bounceCombine=1}
local function tick(command,dt)
 CS.UnityEngine.Time.time=CS.UnityEngine.Time.time+(dt or .2);CS.UnityEngine.Time.frameCount=CS.UnityEngine.Time.frameCount+12
 return probe(command)
end
local function is(s,phase) return s:find('"phase":"'..phase..'"',1,true)~=nil end
local denied=tick("autoplay")
check(is(denied,"uncertain") and shots==0,"no actions before explicit arm")
tick("stop");tick("arm_aim");
tick("sample");tick("aim");tick("sample");local a=tick("aim")
check(is(a,"aimed"),"aim reaches original input controls: "..a)
check(aims==1,"touchable settings launcher must not block Aim")
local bounds=__SDKtoolsBilliards315.control321.prepared.physics.bounds
check(math.abs(bounds.zmax-2.5162204864408996)<.000001,"rail uses corner, not protruding middle pocket")
check(math.abs(bounds.zmin+2.5344104440431647)<.000001,"opposite rail uses original AI corner inset")
for _=1,8 do tick("aim") end
check(shots==0 and aims==1,"aim-only never releases, no repeated input churn")
frame.balls[3].poted=false;a=tick("aim")
check(a:find('table_ball_state_unresolved',1,true) and shots==0,"inactive unpotted ball cannot count as cleared")
frame.balls[3].poted=true
a=tick("autoplay")
check(a:find('explicit_arm_required',1,true) and shots==0,"Aim permission cannot authorize an automatic release")
tick("stop");tick("arm_auto");tick("sample");tick("autoplay");tick("sample");a=tick("autoplay")
check(is(a,"aimed"),"auto prepares")
local lease=__SDKtoolsBilliards315.controlMode321
local session=__SDKtoolsBilliards315.session
tick("suspend")
check(__SDKtoolsBilliards315.control321.prepared==nil,"chat discards prepared release")
check(__SDKtoolsBilliards315.controlMode321==lease and __SDKtoolsBilliards315.session==session,"chat retains explicit match lease")
a=tick("autoplay",.4)
check(is(a,"planning") and shots==0,"resume stabilizes a fresh board before releasing")
a=tick("autoplay");check(is(a,"aimed") and shots==0,"resume recomputes aim")
a=tick("autoplay",.4);check(is(a,"submitted") and shots==1,"single original release")
local pending=__SDKtoolsBilliards315.control321.pending
tick("suspend")
check(__SDKtoolsBilliards315.control321.pending==pending,"chat preserves pending shot identity")
for _=1,6 do tick("autoplay") end
check(shots==1,"motion never duplicates release")
frame.ballsInMovement=false;frame.canShot=true;white.rigidbody.velocity=v(0,0,0)
for _=1,8 do tick("autoplay") end
check(shots==1,"same round cannot release again")
tick("stop");tick("arm_auto");tick("autoplay");tick("autoplay");tick("autoplay",.4)
check(shots==1,"stop/start cannot erase submitted-turn latch")
frame.roundId=2;frame.frameStateLogic.turnData.turnCount=2
tick("stop");tick("arm_auto");frame.isServer=false;frame.frameStateLogic.turnData.myTurn=false
for _=1,4 do tick("autoplay") end
check(shots==1,"other player's turn: zero shots")
frame.isServer=true;frame.frameStateLogic.turnData.myTurn=true;modal=true
for _=1,4 do tick("autoplay") end
check(shots==1,"cue modal: zero shots")
modal=false;frame.gameView.powerSld.touchable=false
for _=1,4 do tick("autoplay") end
check(shots==1,"disabled slider: zero shots")
frame.gameView.powerSld.touchable=true;tick("stop");tick("arm_auto")
frame.gameView.onPowerRelease=function() shots=shots+1;error("uncertain original release") end
tick("autoplay");tick("autoplay");a=tick("autoplay",.4)
check(shots==2 and is(a,"uncertain"),"release exception latches uncertainty")
for _=1,5 do tick("autoplay") end
check(shots==2,"exception not retried")
tick("stop");tick("arm_auto");tick("autoplay");tick("autoplay");tick("autoplay",.4)
check(shots==2,"exception latch survives re-arm")
frame.roundId=3;frame.frameStateLogic.turnData.turnCount=3;tick("stop");tick("arm_auto");tick("autoplay")
frame.frameStateLogic.frameState=10;frame.started=false;a=tick("autoplay")
check(is(a,"ended"),"game over is terminal")
frame.started=true;frame.frameStateLogic.frameState=7;frame.roundId=0;frame.frameStateLogic.turnData.turnCount=0
for _=1,5 do tick("autoplay") end
check(shots==2,"new match cannot auto-rearm")
tick("stop");tick("arm_auto");tick("autoplay");camera.GetInstanceID=function() return 999 end;a=tick("autoplay")
check(is(a,"ended"),"camera/scene context changes terminate action")
camera.GetInstanceID=function() return 501 end
tick("stop");frame.gameDataLogic.gameId="1235";frame.roundId=1;frame.frameStateLogic.turnData.turnCount=1
frame.ballsInMovement=false;frame.canShot=true;white.rigidbody.velocity=v(0,0,0)
white.transform.position=v(0,0,0)
tick("arm_auto")
tick("autoplay");frame.gameDataLogic.gameId="1236";a=tick("autoplay")
check(is(a,"ended") and a:find('match_changed',1,true),"in-place game info reuse cannot start another match")
tick("stop");tick("arm_auto");frame.gameDataLogic.gameId=nil;a=tick("autoplay")
check(a:find('match_identity_unavailable',1,true) and shots==2,"unknown match identity cannot act")
frame.gameDataLogic.gameId="1237";tick("stop");tick("arm_auto")
-- Calibrate three distinct, measured short flights. Supply the actual numeric
-- travel AND velocity; a network teleport or zero-displacement velocity is not
-- allowed to count as calibration.
local strategy=assert(load(read(strategyPath),"@numeric_strategy","t",_G))()
frame.gameView.onPowerRelease=function()
 shots=shots+1;frame.ballsInMovement=true;frame.canShot=false
 local c=__SDKtoolsBilliards315.control321;local pending=c.pending
 local p=pending.physics;local speed=strategy.launch(pending.plan.power,p.reference,p.mass)
 local surface=.0008*speed*p.mass*p.radius/p.inertia
 local observed,travel=strategy.flight(speed,surface,p,nil,.06)
 local d=pending.plan.direction
 white.rigidbody.velocity=v(d.x*observed,0,d.z*observed)
 white.transform.position=v(pending.origin.x+d.x*travel,0,pending.origin.z+d.z*travel)
end
for round=1,3 do
 frame.roundId=round;frame.frameStateLogic.turnData.turnCount=round
 frame.canShot=true;frame.ballsInMovement=false;white.rigidbody.velocity=v(0,0,0);white.transform.position=v(0,0,0)
 tick("autoplay");tick("autoplay");tick("autoplay",.4);a=tick("autoplay",.06)
end
check(__SDKtoolsBilliards315.control321.calibrationSamples==3,"three qualified real-flight samples update calibration")
check(math.abs(__SDKtoolsBilliards315.control321.gain-1)<.001,"perfect measured flight keeps unit gain")
check(shots==5,"three rounds, exactly three releases")
tick("stop");frame.gameDataLogic.gameId="1239";frame.roundId=1;frame.frameStateLogic.turnData.turnCount=1
frame.ballsInMovement=false;frame.canShot=true;white.rigidbody.velocity=v(0,0,0);white.transform.position=v(0,0,0)
tick("arm_auto");surface.sharedMaterial.dynamicFriction=.5;tick("autoplay");a=tick("autoplay")
check(a:find('live_table_material_mismatch',1,true) and shots==5,"unexpected live floor friction blocks auto")
surface.sharedMaterial.dynamicFriction=1
-- Changing the live route after aim must not release a cached solution.
tick("stop");frame.gameDataLogic.gameId="1238";frame.roundId=1;frame.frameStateLogic.turnData.turnCount=1
frame.ballsInMovement=false;frame.canShot=true;white.rigidbody.velocity=v(0,0,0);white.transform.position=v(0,0,0)
tick("arm_auto");tick("autoplay");tick("autoplay")
CS.UnityEngine.Physics.SphereCastAll=function(origin,radius,dir)
 if dir.y==-1 then return hits({hit(surface,.5,v(0,1,0))}) end
 return hits({hit(unknown,.1)})
end
a=tick("autoplay",.4)
check(is(a,"uncertain") and shots==5,"fresh route validation rejects new obstruction")
__SDKtoolsBilliards315.controlMode321=nil
a=tick("autoplay")
check(is(a,"uncertain") and shots==5,"lost VM permission cannot silently rearm")
return checks
]=]
-- Prefix declares local caseName/probePath from varargs; append a separate arg.
local combined=prefix.."\n"..test
-- test vararg is strategyPath, while prefix's second arg must remain probePath.
combined=combined:gsub("local strategyPath=%.%.%.","local strategyPath=select(4,...)",1)
local n=assert(load(combined,"@automation_mocks","t",_G))("automation321",probePath,"",strategyPath,geometryPath)
checks=checks+n
return '{"passed":'..checks..',"engine":"Lua 5.3","deviceTested":false}'

const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_global_runtime.js'),'utf8');
const coreSource=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_global.js'),'utf8');
const clone=v=>JSON.parse(JSON.stringify(v));
function create(config={}){const core=vm.runInNewContext(coreSource,{performance:{now:()=>0}})(config),factory=vm.runInNewContext(source);let legacy=0;
 const wrapped=factory(input=>{legacy++;return {legacy:true,input};},core);return {wrapped,solo:wrapped.solo,core,get legacy(){return legacy;}};}
function fixture(board=[1,1,1],hand=[],stock=[]){
 const store={mode:1,uid:7,rid:8,start_time:9,state:2,isWatcher:false,isHotTiming:false,isAddingCommonBlock:false,isUsingPenetrateProp:false,isCanTouchBlock:true,
  gamers:[{uid:7,state:1}],pile_blocks:[],hand_blocks:[],storage_blocks:[],props_blocks:stock.map(v=>({id:v.type+'-7',type:v.type,count:v.count}))};
 const s={root:{},board:{},reserve:{},trayNode:{},gameLayer:{},playState:{store,uid:7,rid:8,start:9,game:{},layer:{}},capacity:7,cards:[],tray:[],refs:new Map(),signature:'board-1'};
 function add(spec,zone){spec=typeof spec==='number'?{type:spec}:spec;const index=s.refs.size+1,id='c'+index,row=spec.row===undefined?100+index*32:spec.row,col=spec.col===undefined?70:spec.col,layer=spec.layer||0;
  const rawID=layer+'-'+row+'-'+col,info={id:rawID,type:spec.type,state:['board','tray','reserve'].indexOf(zone),layer,row,col};
  if(zone==='reserve')info.storage_info={layer:spec.storageLayer||0,index:spec.storageIndex||0};
  const blockedBy=(spec.blockedBy||[]).slice(),c={id,rawID,type:'type:'+spec.type,zone,order:zone==='tray'?s.tray.length:s.cards.length,layer,gridRow:row,gridCol:col,blockedBy,
   available:zone!=='tray'&&blockedBy.length===0,selectable:true,masked:!!blockedBy.length,metadata:{specialType:0,lock:0,ruleIssue:null,canTouch:zone!=='tray'&&blockedBy.length===0,block:{blockInfo:info}}};
  if(zone==='reserve')Object.assign(c,{storageVerified:true,storageLayer:info.storage_info.layer,storageIndex:info.storage_info.index});
  s.refs.set(id,c);s[zone==='tray'?'tray':'cards'].push(c);store[['pile_blocks','hand_blocks','storage_blocks'][info.state]].push(info);return c;}
 board.forEach(c=>add(c,c.zone||'board'));hand.forEach(c=>add(c,'tray'));
 function sync(){
  store.pile_blocks=s.cards.filter(c=>c.zone==='board').map(c=>c.metadata.block.blockInfo);store.storage_blocks=s.cards.filter(c=>c.zone==='reserve').map(c=>c.metadata.block.blockInfo);store.hand_blocks=s.tray.map(c=>c.metadata.block.blockInfo);
  s.refs=new Map(s.cards.concat(s.tray).map(c=>[c.id,c]));
  const old=s.phaseSnapshot,phaseCard=c=>({id:c.id,type:c.type,zone:c.zone,order:c.zone==='tray'?s.tray.indexOf(c):c.order,blockedBy:c.blockedBy.slice().sort(),available:c.available,
   selectable:c.selectable,specialType:c.metadata.specialType,lock:c.metadata.lock,canTouch:c.metadata.canTouch,
   ...(c.zone==='board'?{layer:c.layer,row:c.gridRow,col:c.gridCol}:{}),...(c.zone==='reserve'?{storageVerified:c.storageVerified,storageLayer:c.storageLayer,storageIndex:c.storageIndex,masked:c.masked}:{})});
  s.phaseSnapshot={schema:'SDKtools.AlpacaPhaseSnapshot.v1',scope:old?old.scope:1,revision:old?old.revision+1:1,complete:true,serverConfirmed:false,mode:store.mode,capacity:7,matchSize:3,
   cards:s.cards.map(phaseCard),tray:s.tray.map(phaseCard),inventory:store.props_blocks.map(v=>({type:v.type,count:v.count,recognized:v.type<=5})),sharedSlots:[],
   rules:{allRecognized:true,modeRecognized:true,ordinaryMatch:'triple',trayPolicy:'group_insert_then_match',ordinaryGeometry:'alpaca_2_4_4',reservePolicy:'verified_storage_columns',unknownSpecialTypes:[]}};
  s.signature='board-'+s.phaseSnapshot.revision;return s;
 }
 function perform(action){
  if(action.kind==='power'&&action.powerType===1){const c=s.tray.find(c=>c.id===action.id);assert.ok(c);s.tray.splice(s.tray.indexOf(c),1);c.zone='board';c.metadata.block.blockInfo.state=0;
   c.blockedBy=s.cards.filter(v=>v.zone==='board'&&v.layer>c.metadata.block.blockInfo.layer&&Math.abs(v.gridRow-c.gridRow)<16&&Math.abs(v.gridCol-c.gridCol)<20).map(v=>v.id);c.available=!c.blockedBy.length;c.masked=!!c.blockedBy.length;c.metadata.canTouch=c.available;s.cards.push(c);
  }else{
   const c=s.cards.find(c=>c.id===action.id);assert.ok(c);s.cards.splice(s.cards.indexOf(c),1);c.zone='tray';c.metadata.block.blockInfo.state=1;c.available=false;c.metadata.canTouch=false;c.blockedBy=[];
   let at=-1;for(let i=0;i<s.tray.length;i++){if(i+1===s.tray.length||s.tray[i].type===c.type&&s.tray[i+1].type!==c.type){at=i+1;break;}}s.tray.splice(at,0,c);
   const same=s.tray.filter(v=>v.type===c.type);if(same.length===3)s.tray=s.tray.filter(v=>v.type!==c.type);
  }
  if(action.kind==='power')store.props_blocks.find(p=>p.type===action.powerType).count--;
  s.cards.forEach(c=>{c.blockedBy=c.blockedBy.filter(id=>s.cards.some(v=>v.id===id));c.available=!c.blockedBy.length;c.masked=!!c.blockedBy.length;c.metadata.canTouch=c.available;});sync();
 }
 sync();return {store,s,sync,perform};
}
function finish(rt,p,options={powersEnabled:true}){let d;for(let i=0;i<10000;i++){d=rt.solo.plan(p.s,options);if(d.status!=='searching')return clone(d);}assert.fail('whole-phase search did not terminate');}
function penFixture(){return fixture([{type:1,blockedBy:['c2'],row:48,layer:0},{type:2,row:48,layer:1},2,2,...[3,4,5,6].flatMap(type=>[type,type])],[1,1,3,4,5,6],[{type:3,count:1}]);}
function preparePenFixture(){return fixture([1,{type:1,blockedBy:['c3'],row:48,layer:0},{type:2,row:48,layer:1},2,2,...[3,4,5,6].flatMap(type=>[type,type])],[1,3,4,5,6],[{type:3,count:1}]);}
test('legacy calls delegate without guessing SOLO from hand size or player count',()=>{const rt=create(),p=fixture();assert.equal(rt.wrapped({cards:[]}).legacy,true);assert.equal(rt.legacy,1);assert.equal(rt.solo.applies(p.s),true);
 p.store.mode=0;assert.equal(rt.solo.applies(p.s),false);delete p.store.mode;assert.equal(rt.solo.applies(p.s),false);let reads=0;Object.defineProperty(p.store,'mode',{get(){reads++;return 1;}});assert.equal(rt.solo.applies(p.s),false);assert.equal(reads,0);});
test('whole-clear certificate dispatches only first trio and retains its entire proof privately',()=>{const rt=create(),p=fixture([1,1,1,2,2,2]),before=JSON.stringify(p.store),d=finish(rt,p);
 assert.equal(d.status,'move');assert.equal(d.proofKind,'global_solo');assert.equal(d.sequence.length,3);assert.equal(d.globalRoute.length,6);assert.equal(d.globalClaim.complete,true);assert.equal(d.fastBatch,false);
 assert.deepEqual(d.actions,d.sequence);assert.equal(rt.solo.validateRoute(p.s,d).cardID,d.cardID);assert.equal(rt.solo.prescribed(p.s,d),null);assert.equal(JSON.stringify(p.store),before);
 const diag=clone(rt.solo.diagnostic());assert.equal(diag.status,'proved');assert.equal(diag.complete,true);assert.equal(diag.plannedCleared,6);assert.equal(diag.scope,'current_phase');assert.doesNotMatch(JSON.stringify(diag),/"(?:cardID|targetID|uid|rid|route|signature|stock)"\s*:/);});
test('full route may require one preparatory normal card then owned hidden-card trio',()=>{const rt=create(),p=preparePenFixture(),d=finish(rt,p);
 assert.equal(d.status,'move');assert.equal(d.globalClaim.complete,true);assert.equal(d.sequence.length,1);assert.deepEqual(d.tripleCardIDs,[]);assert.equal(d.matchedType,null);
 assert.equal(d.globalRoute[1].kind,'power');assert.equal(d.globalRoute[1].powerType,3);assert.ok(rt.solo.validateRoute(p.s,d));
 assert.equal(rt.solo.advance('card',d.cardID),true);p.perform(d.globalRoute[0]);const next=finish(rt,p);
 assert.equal(next.status,'power');assert.equal(next.action.powerType,3);assert.equal(next.globalClaim.complete,true);assert.equal(next.stats.expanded,0,'replayed full tail, not local fallback');
 assert.deepEqual(clone(rt.solo.prescribed(p.s,next)),{type:3,targetID:next.action.id,signature:p.s.signature});});
test('owned Penetrate is prescribed only with positive stock and full replayed route',()=>{const rt=create(),p=penFixture(),d=finish(rt,p);assert.equal(d.status,'power');assert.equal(d.action.powerType,3);
 const action=clone(rt.solo.prescribed(p.s,d));assert.equal(action.type,3);assert.equal(action.targetID,'c1');assert.equal(rt.solo.validateRoute(p.s,d),null);
 assert.equal(rt.solo.advance('power',action.targetID),true);p.perform(d.action);const next=finish(rt,p);assert.equal(next.status,'move');assert.equal(next.stats.expanded,0);assert.equal(next.globalClaim.complete,true);
 assert.equal(p.store.props_blocks[0].count,0);assert.equal(p.s.cards.length+p.s.tray.length,15);});
test('Powers OFF models no power consumption even though the verified stock remains positive',()=>{const rt=create(),p=penFixture(),stock=JSON.stringify(p.store.props_blocks),d=finish(rt,p,{powersEnabled:false});
 assert.equal(d.status,'blocked');assert.equal(rt.solo.prescribed(p.s,d),null);assert.equal(rt.solo.diagnostic().powerUses,0);assert.equal(JSON.stringify(p.store.props_blocks),stock);});
test('initial board Withdraw derives the exact last-card geometry and remains a revalidated power',()=>{const rt=create(),p=fixture([1,1,...[2,3,4,5,6].flatMap(t=>[t,t])],[1,2,3,4,5,6],[{type:1,count:1}]),last=p.s.tray.at(-1);
 p.store.last_block={id:last.rawID,state:0};p.sync();const d=finish(rt,p);assert.equal(d.status,'power');assert.equal(d.action.powerType,1);assert.equal(d.action.id,last.id);assert.equal(d.globalClaim.complete,true);
 assert.equal(rt.solo.prescribed(p.s,d).targetID,last.id);assert.equal(rt.solo.advance('power',last.id),true);p.perform(d.action);assert.equal(finish(rt,p).globalClaim.complete,true);
});
test('a reserve-origin last card is not invented as a deterministic board Withdraw',()=>{const rt=create(),p=fixture([1,1,...[2,3,4,5,6].flatMap(t=>[t,t])],[1,2,3,4,5,6],[{type:1,count:1}]);p.store.last_block={id:p.s.tray.at(-1).rawID,state:2};p.sync();const d=finish(rt,p);assert.equal(d.status,'blocked');assert.equal(rt.solo.prescribed(p.s,d),null);});
for(const [name,mutate] of [
 ['wrong first card',d=>d.cardID='c999'],['shortened prefix',d=>{d.sequence=d.sequence.slice(0,1);d.actions=d.sequence.slice();}],
 ['different actions',d=>d.actions.reverse()],['forged complete claim',d=>d.globalClaim.complete=false],['forged cleared count',d=>d.globalClaim.cleared--],
 ['forged proof token',d=>d.globalBinding++],['forged route tail',d=>d.globalRoute.pop()],['foreign proof kind',d=>d.proofKind='local_trio'],['wrong trio marker',d=>d.tripleCardIDs=['c1','c2','c999']]
])test('normal proof cannot be replaced by '+name,()=>{const rt=create(),p=fixture([1,1,1,2,2,2]),d=finish(rt,p);mutate(d);assert.equal(rt.solo.validateRoute(p.s,d),null);});
for(const [name,mutate] of [
 ['wrong target',d=>d.action.id='c2'],['wrong power type',d=>d.action.powerType=4],['forged route',d=>d.globalRoute[0].id='c2'],['normal status',d=>d.status='move']
])test('power proof cannot be replaced by '+name,()=>{const rt=create(),p=penFixture(),d=finish(rt,p);mutate(d);assert.equal(rt.solo.prescribed(p.s,d),null);});
for(const [name,mutate] of [
 ['player',p=>p.store.uid++],['room',p=>p.store.rid++],['round',p=>p.store.start_time++],['scene',p=>p.s.root={}],['phase scope',p=>p.s.phaseSnapshot.scope++],
 ['revision',p=>p.s.phaseSnapshot.revision++],['stock',p=>p.store.props_blocks[0].count=0],['card Store type',p=>p.store.pile_blocks[0].type=999]
])test('fresh proof validation refuses changed '+name,()=>{const rt=create(),p=penFixture(),d=finish(rt,p);mutate(p);assert.equal(rt.solo.prescribed(p.s,d),null);});
for(const [name,mutate] of [
 ['missing coherent phase',p=>p.s.phaseSnapshot=null],['unverified phase',p=>p.s.phaseSnapshot.complete=false],['unknown rules',p=>p.s.phaseSnapshot.rules.allRecognized=false],
 ['wrong tray policy',p=>p.s.phaseSnapshot.rules.trayPolicy='unordered'],['invented shared card',p=>p.s.phaseSnapshot.sharedSlots=[{}]],
 ['missing card',p=>p.s.phaseSnapshot.cards.pop()],['duplicate card',p=>p.s.phaseSnapshot.cards[1].id=p.s.phaseSnapshot.cards[0].id],
 ['unknown special',p=>p.store.pile_blocks[0].special_info={type:44,lock_state:0}],['missing store census',p=>p.store.pile_blocks=[]],
 ['duplicate stock type',p=>{p.store.props_blocks.push({id:'other',type:3,count:1});p.s.phaseSnapshot.inventory.push({type:3,count:1,recognized:true});}],
 ['negative stock',p=>{p.store.props_blocks[0].count=-1;p.s.phaseSnapshot.inventory[0].count=-1;}],
 ['unverified reserve',p=>{const c=p.s.cards[0];c.zone='reserve';c.storageVerified=false;p.sync();}],['pending full hand',p=>{while(p.s.tray.length<7){const c=p.s.cards.pop();c.zone='tray';c.metadata.block.blockInfo.state=1;c.available=false;c.metadata.canTouch=false;c.blockedBy=[];p.s.tray.push(c);}p.sync();}]
])test('unsafe census blocks global planning: '+name,()=>{const rt=create(),p=penFixture();mutate(p);const d=finish(rt,p);assert.equal(d.status,'blocked');assert.equal(rt.solo.diagnostic().complete,false);assert.equal(rt.solo.prescribed(p.s,d),null);});
test('bounded search reports searching without an action then refuses a best path with no proved trio',()=>{const rt=create({maxStates:2,sliceNodes:1}),p=fixture([1,1,1,2,2,2]);const first=rt.solo.plan(p.s,{powersEnabled:true});
 assert.equal(first.status,'searching');assert.equal(first.sequence.length,0);assert.equal(rt.solo.diagnostic().optimal,false);const d=finish(rt,p);
 assert.equal(d.status,'blocked');assert.equal(d.stats.completeSearch,false);assert.equal(rt.solo.diagnostic().optimal,false);assert.equal(rt.solo.diagnostic().complete,false);});
test('proved partial progress is not relabeled as complete or guaranteed future success',()=>{const rt=create(),p=fixture([1,1,1,2]),d=finish(rt,p);assert.equal(d.status,'move');assert.equal(d.globalClaim.complete,false);assert.equal(d.globalClaim.cleared,3);assert.equal(d.globalClaim.remaining,1);
 assert.equal(rt.solo.diagnostic().status,'partial');assert.equal(rt.solo.diagnostic().complete,false);assert.ok(rt.solo.validateRoute(p.s,d));assert.equal(rt.solo.advance('card',d.cardID),false,'partial plans never carry an unproved full tail');});
test('carried full tail is invalidated by policy changes and cannot bypass Powers OFF',()=>{const rt=create(),p=preparePenFixture(),d=finish(rt,p);assert.equal(rt.solo.advance('card',d.cardID),true);p.perform(d.globalRoute[0]);
 const off=finish(rt,p,{powersEnabled:false});assert.equal(off.status,'blocked');assert.equal(rt.solo.prescribed(p.s,off),null);});
test('advance validates the first certified action and does not create a retry or a physical latch',()=>{const rt=create(),p=fixture([1,1,1]),d=finish(rt,p);assert.equal(rt.solo.advance('card','c999'),false);assert.equal(rt.solo.validateRoute(p.s,d),null);
 const next=finish(rt,p);assert.equal(next.cardID,d.cardID);assert.equal(rt.solo.advance('power',next.cardID),false);rt.solo.invalidate();assert.equal(rt.solo.diagnostic().reason,'awaiting_snapshot');assert.equal(rt.solo.prescribed(p.s,next),null);});
test('returned proof and closed diagnostics do not mutate the private certificate or real stock',()=>{const rt=create(),p=penFixture(),d=finish(rt,p),stock=JSON.stringify(p.store.props_blocks);const diag=rt.solo.diagnostic();diag.complete=false;diag.powerUses=999;
 assert.equal(rt.solo.diagnostic().complete,true);d.globalRoute[0].id='forged';assert.equal(rt.solo.prescribed(p.s,d),null);assert.equal(JSON.stringify(p.store.props_blocks),stock);
 const again=finish(rt,p);assert.equal(again.action.id,'c1');assert.ok(rt.solo.prescribed(p.s,again));});
test('resource is bounded and contains no transport, action invocation, hooks or injected timer',()=>{assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setTimeout|setInterval)\s*\(|new\s+Function/);
 assert.doesNotMatch(source,/\.(?:send|UseProp|TouchBlock|touchBlock|emit|addEventListener|sync)\s*\(/);assert.doesNotMatch(source,/Math\.random/);});

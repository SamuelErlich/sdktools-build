"""Static UI wiring contracts for the read-only covered-card test report."""
import json
from pathlib import Path
import re
import unittest
ROOT=Path(__file__).resolve().parents[1]

class CoveredReportMenuTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=(ROOT/'Sources/SDKtools/STOverlay.m').read_text(encoding='utf-8')
        start=cls.source.index('- (void)exportCoveredReport {')
        cls.action=cls.source[start:cls.source.index('\n- (void)toggleAutoplay {',start)]
        cls.rows=json.loads((ROOT/'Resources/Brand/menu-localizations.json').read_text(encoding='utf-8'))['entries']

    def test_one_report_button_below_experiment_status_in_advanced_scrolling_stack(self):
        source=self.source
        self.assertEqual(source.count('[self button:@"Export test report"'),1)
        status=source.index('[advanced addArrangedSubview:self.coveredAttemptLabel]')
        button=source.index('self.coveredReportButton=[self button:@"Export test report"')
        caption=source.index('[advanced addArrangedSubview:coveredReportCaption]')
        end=source.index('self.advancedContainer.hidden=YES; [alpaca addArrangedSubview:self.advancedContainer]')
        self.assertLess(status,button); self.assertLess(button,caption); self.assertLess(caption,end)
        self.assertIn('action:@selector(exportCoveredReport)',source[button:caption])
        self.assertIn('STLocalizeAccessibilityHint(self.coveredReportButton,',source[button:caption])
        # Reuse the existing 44 pt native button helper and contentLayoutGuide scrolling.
        helper=source[source.index('- (UIButton *)button:'):source.index('- (UIButton *)iconButton:')]
        self.assertIn('constraintEqualToConstant:44',helper)
        self.assertIn('self.panelScroll.contentLayoutGuide',source)

    def test_export_eligibility_is_not_gated_by_gameplay_or_pending_state(self):
        match=re.search(r'self\.coveredReportButton\.enabled=([^;]+);',self.source)
        self.assertIsNotNone(match)
        eligibility=match[1]
        for required in ('UIApplicationStateActive','presentedViewController','pendingPreview','view.window'):
            self.assertIn(required,eligibility)
        for forbidden in ('busy','alpaca','coveredAttemptPending','autoplayEnabled','recording','xrayEnabled','sourceExportBusy'):
            self.assertNotIn(forbidden,eligibility)
        self.assertNotRegex(self.source,r'coveredReportButton\.hidden\s*=')
        self.assertNotIn('clientAllowsGame',self.action)

    def test_export_only_writes_current_snapshot_without_actions_or_collecting(self):
        self.assertEqual(self.action.count('writeCoveredAttemptReportWithError:'),1)
        for forbidden in ('writeReportWithError:','exportReport]','stopAll','stopWithReason:','pauseAutoplay',
                          'setXrayEnabled:','reset','clear','evaluateJavaScript','performCoveredAttempt',
                          'sampleWebView','STFindReturnActionWebView','clientAllowsGame','coveredAttemptPending='):
            self.assertNotIn(forbidden,self.action)
        self.assertIn('UIApplicationStateActive',self.action)
        self.assertIn('self.controller.presentedViewController || self.pendingPreview',self.action)

    def test_share_sheet_uses_exact_saved_url_and_ipad_anchor_and_never_deletes_it(self):
        action=self.action
        self.assertIn('initWithActivityItems:@[url] applicationActivities:nil',action)
        self.assertIn('UIButton *anchor=self.controller.coveredReportButton',action)
        self.assertIn('popoverPresentationController.sourceView=anchor',action)
        self.assertIn('popoverPresentationController.sourceRect=anchor.bounds',action)
        self.assertIn('completionWithItemsHandler',action)
        for forbidden in ('removeItem','unlink','pendingSourceExport','presentPendingPreview','delete'):
            self.assertNotIn(forbidden,action)

    def test_penetrate_is_one_explicit_button_sharing_the_existing_write_gate(self):
        source=self.source
        self.assertEqual(source.count('[self button:@"Test Penetrate (0 stock)"'),1)
        self.assertIn('action:@selector(testPenetrateZero)',source)
        self.assertIn('self.penetrateZeroButton.enabled=self.coveredAttemptButton.enabled;',source)
        start=source.index('- (void)testPenetrateZero {')
        method=source[start:source.index('- (void)exportCoveredReport {',start)]
        self.assertEqual(method.count('performPenetrateZeroAttempt'),1)
        for forbidden in ('performCoveredAttempt','setTimeout','TouchBlock','UseProp','setPowersEnabled','startAutoplay'):
            self.assertNotIn(forbidden,method)
        self.assertIn('Penetrate test requested. Checking the game state.',method)
        aliases={value for row in self.rows for value in row.values()}
        self.assertIn('Testar Penetrate (estoque 0)',aliases)
        self.assertIn('Experimental. Estoque 0 não garante poder grátis nem ativação; o SDK não edita o estoque.',aliases)

    def test_native_manual_commands_share_one_latch_and_no_timer_queues_an_intent(self):
        source=(ROOT/'Sources/SDKtools/STAutoplayRecorder.inc').read_text(encoding='utf-8')
        self.assertIn('- (BOOL)performPenetrateZeroAttempt { return [self performAlpacaExperimentPenetrate:YES]; }',source)
        self.assertIn('- (BOOL)performCoveredAttempt { return [self performAlpacaExperimentPenetrate:NO]; }',source)
        self.assertIn('- (void)autoplayTick { [self autoplayTickWithCoveredAttempt:NO penetrateAttempt:NO]; }',source)
        self.assertIn('self.coveredAttemptRequiresProtocol=YES;',source)
        self.assertIn('self.coveredAttemptPending || self.coveredAttemptContextLost || self.autoplayEnabled || !self.xrayEnabled',source)
        self.assertIn('allowAction:actionAllowed coveredAttempt:coveredAttempt penetrateAttempt:penetrateAttempt',source)

    def test_report_ui_copy_is_bilingual_and_not_game_source_export(self):
        aliases={value for row in self.rows for value in row.values()}
        for literal in re.findall(r'@"([^"\n]+)"',self.action):
            self.assertIn(literal,aliases)
        title=next(row for row in self.rows if row['en']=='Export test report')
        self.assertEqual(title['pt'],'Exportar relatório do teste')
        self.assertIn('Exporta o estado já observado; não envia outra tentativa.',aliases)
        for row in self.rows:
            if row['en'].startswith(('Export test report','Test report','Exports only the observed state')):
                self.assertNotRegex(row['pt'],r'(?i)código do jogo')

if __name__=='__main__':
    unittest.main()

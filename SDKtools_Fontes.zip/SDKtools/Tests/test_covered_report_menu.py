"""Internal experiments remain collector APIs, outside the customer menu."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class CoveredReportMenuTests(unittest.TestCase):
    def test_internal_experiments_are_absent_from_customer_menu(self):
        source=(ROOT/'Sources/SDKtools/STOverlay.m').read_text(encoding='utf-8')
        controller=source.split('@implementation STOverlayController',1)[1].split('@implementation STOverlay\n',1)[0]
        for selector in ('testCoveredCard','testPenetrateZero','exportCoveredReport','exportGameSources'):
            self.assertNotIn('@selector('+selector+')',controller)
        for stale in ('advancedContainer','coveredReportButton','penetrateZeroButton','coveredAttemptButton'):
            self.assertNotIn(stale,source)
    def test_collector_and_browser_keep_diagnostic_exports(self):
        header=(ROOT/'Sources/SDKtools/STRecorder.h').read_text(encoding='utf-8')
        self.assertIn('writeCoveredAttemptReportWithError:',header)
        panel=(ROOT/'Resources/LAN/panel.html').read_text(encoding='utf-8')
        self.assertIn('id="report-export"',panel)
        self.assertIn('id="sources-export"',panel)
    def test_native_manual_commands_share_one_latch_and_no_timer_queues_an_intent(self):
        source=(ROOT/'Sources/SDKtools/STAutoplayRecorder.inc').read_text(encoding='utf-8')
        self.assertIn('- (BOOL)performPenetrateZeroAttempt { return [self performAlpacaExperimentPenetrate:YES]; }',source)
        self.assertIn('- (BOOL)performCoveredAttempt { return [self performAlpacaExperimentPenetrate:NO]; }',source)
        self.assertIn('- (void)autoplayTick { [self autoplayTickWithCoveredAttempt:NO penetrateAttempt:NO]; }',source)
        self.assertIn('self.coveredAttemptRequiresProtocol=YES;',source)
        self.assertIn('self.coveredAttemptPending || self.coveredAttemptContextLost || self.autoplayEnabled || !self.xrayEnabled',source)
        self.assertIn('allowAction:actionAllowed coveredAttempt:coveredAttempt penetrateAttempt:penetrateAttempt',source)


if __name__=='__main__':unittest.main()

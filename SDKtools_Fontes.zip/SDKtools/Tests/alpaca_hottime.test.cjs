const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_hottime.js'),'utf8'),clone=v=>JSON.parse(JSON.stringify(v));
function fixture(value=.7){
 let progressReads=0,progressWrites=0;
 class Component {constructor(node,name){this.node=node;this.className=name;this.isValid=true;this.enabledInHierarchy=true;node._components.push(this);}}
 class ProgressBar extends Component {constructor(node){super(node,'cc.ProgressBar');this['_N$progress']=value;}
  get progress(){progressReads++;throw Error('must not execute progress getter');}set progress(v){progressWrites++;throw Error('must not write progress');}}
 const records=new Map();
 function node(parent=null){const n={parent,isValid:true,active:true,activeInHierarchy:true,opacity:255,_components:[]};records.set(n,parent);return n;}
 const root=node(),gameNode=node(root),layerNode=node(gameNode),handNode=node(layerNode),tray=node(handNode),barNode=node(handNode);
 const game=new Component(gameNode,'Game'),layer=new Component(layerNode,'GameLayer'),hand=new Component(handNode,'HandArea'),bar=new ProgressBar(barNode);
 game.GameLayer=layer;layer.HandArea=hand;hand.AreaNode=tray;hand.HotTimeProgressBar=bar;
 const cc={Component,ProgressBar,js:{getClassName:c=>c.className},director:{getScene:()=>root}},window={cc},document={visibilityState:'visible'};
 const s={cc,root,gameLayer:layerNode,trayNode:tray,records,playState:{game,layer}},guard=vm.runInNewContext('('+source+')()',{window,document});
 return {s,cc,window,document,game,layer,hand,bar,node,guard,reads:()=>progressReads,writes:()=>progressWrites,inspect:()=>clone(guard.inspect(s)),diag:()=>clone(guard.diagnostic())};
}
const unavailable={version:1,status:'protected',reason:'diamond_charge_unavailable',chargePercent:null,trioChargePercent:null,thresholdPercent:null};
test('original engine accessor backing yields actual percentage without invoking getter or setter',()=>{
 const p=fixture(.72),d=p.inspect();assert.deepEqual(d,{...unavailable,reason:'diamond_charge_unverified',chargePercent:72});
 assert.equal(p.reads(),0);assert.equal(p.writes(),0);assert.equal(p.bar['_N$progress'],.72);
});
test('all diamonds remain protected even at zero or full charge; other card types stay independent',()=>{
 for(const value of [0,.01,.5,.9,.99,1,undefined,NaN]){const p=fixture(value);p.inspect();
  for(const state of [p.s,null,{}]){assert.equal(p.guard.allows(state,{type:'type:1'}),false);
   for(const type of ['type:0','type:2','type:10','type:999'])assert.equal(p.guard.allows(state,{type}),true);}}
});
test('zero and full bar are observed without claiming a trio gain or threshold',()=>{
 for(const value of [0,1]){const p=fixture(value);assert.equal(p.inspect().chargePercent,value*100);assert.equal(p.diag().thresholdPercent,null);assert.equal(p.diag().trioChargePercent,null);}
});
for(const value of [NaN,Infinity,-Infinity,-.001,1.001,'0.7',true,null,undefined])test('malformed backing value stays unavailable: '+String(value),()=>{
 const p=fixture();p.bar['_N$progress']=value;assert.deepEqual(p.inspect(),unavailable);assert.equal(p.reads(),0);
});
for(const [name,mutate] of [
 ['missing play state',p=>p.s.playState=null],['foreign current scene',p=>p.cc.director.getScene=()=>({})],['foreign window engine',p=>p.window.cc={}],
 ['hidden document',p=>p.document.visibilityState='hidden'],['wrong game type',p=>p.game.className='OtherGame'],['replaced game layer',p=>p.game.GameLayer={}],
 ['wrong layer node',p=>p.s.gameLayer=p.s.root],['wrong HandArea type',p=>p.hand.className='OtherHandArea'],['foreign tray',p=>p.hand.AreaNode=p.node(p.s.root)],
 ['foreign HandArea ancestry',p=>{p.hand.node.parent=p.s.root;p.s.records.set(p.hand.node,p.s.root);}],
 ['foreign bar ancestry',p=>{p.bar.node.parent=p.s.root;p.s.records.set(p.bar.node,p.s.root);}],['stale parent records',p=>p.bar.node.parent=p.s.root],
 ['unrecorded bar',p=>p.s.records.delete(p.bar.node)],['hidden bar',p=>p.bar.node.active=false],['inactive bar ancestry',p=>p.hand.node.activeInHierarchy=false],
 ['transparent ancestor',p=>p.hand.node.opacity=0],['disabled bar component',p=>p.bar.enabledInHierarchy=false],['destroyed bar',p=>p.bar.isValid=false],
 ['unbound bar',p=>p.bar.node._components=[]],['duplicate bar binding',p=>p.bar.node._components.push(p.bar)],
 ['second progress component',p=>new p.cc.ProgressBar(p.bar.node)],['wrong ProgressBar class',p=>p.bar.className='FakeProgressBar'],
 ['fake ProgressBar',p=>{p.hand.HotTimeProgressBar={node:p.bar.node,isValid:true,enabledInHierarchy:true,className:'cc.ProgressBar','_N$progress':.7};}],
 ['inherited backing value',p=>{delete p.bar['_N$progress'];Object.defineProperty(p.cc.ProgressBar.prototype,'_N$progress',{value:.7});}]
])test('invalid binding clears charge: '+name,()=>{const p=fixture();assert.equal(p.inspect().chargePercent,70);mutate(p);assert.deepEqual(p.inspect(),unavailable);assert.equal(p.guard.allows(p.s,{type:'type:1'}),false);});
test('custom own accessors are rejected without being called',()=>{
 for(const target of ['backing','hand','bar','components']){const p=fixture();let reads=0;const [o,k]=target==='backing'?[p.bar,'_N$progress']:target==='hand'?[p.layer,'HandArea']:target==='bar'?[p.hand,'HotTimeProgressBar']:[p.bar.node,'_components'];
  Object.defineProperty(o,k,{get(){reads++;throw Error('forbidden');}});assert.deepEqual(p.inspect(),unavailable);assert.equal(reads,0);}
});
test('reset and failed reads discard previous percentage; diagnostic objects cannot mutate state',()=>{
 const p=fixture();const d=p.guard.inspect(p.s);assert.equal(Object.isFrozen(d),true);d.chargePercent=99;assert.equal(p.diag().chargePercent,70);
 p.guard.reset();assert.deepEqual(p.diag(),unavailable);p.inspect();assert.deepEqual(clone(p.guard.inspect(null)),unavailable);
});
test('known Cocos public inherited accessors remain compatible',()=>{
 const p=fixture();for(const c of [p.game,p.layer,p.hand,p.bar]){const proto=Object.create(Object.getPrototypeOf(c));
  for(const k of ['node','isValid','enabledInHierarchy']){const value=c[k];delete c[k];Object.defineProperty(proto,k,{get:()=>value});}Object.setPrototypeOf(c,proto);}
 assert.equal(p.inspect().chargePercent,70);assert.equal(p.reads(),0);
});
test('observer has no transport, timers, action calls, hooks, progress write or dynamic execution',()=>{
 assert.ok(Buffer.byteLength(source)<8192);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|setTimeout|setInterval|eval)\s*\(|new\s+Function/);
 assert.doesNotMatch(source,/\.(?:send|TouchBlock|UseProp|ChooseCommonBlock|UseCommonBlock|touchBlock|emit|addEventListener|updateHotTimeProgress)\s*\(/);
 assert.doesNotMatch(source,/\.progress\s*=|\[['_"]_N\$progress['_"]\]\s*=/);
});

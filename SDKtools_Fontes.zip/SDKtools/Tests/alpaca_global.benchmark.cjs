/* Reproducible synthetic model benchmark, NOT a captured WePlay table.
 * Run: node --expose-gc Tests/alpaca_global.benchmark.cjs
 * No timing assertions: hardware, VM scheduling and GC change these numbers.
 * Branch fixtures have a separately replayable, deliberately constructed full
 * solution. Failure to find it within 60k states is not impossibility proof.
 */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{performance}=require('node:perf_hooks');
function fixture(n,kind){
 if(!Number.isInteger(n)||n<3||n>510||n%3)throw Error('fixture size must be a multiple of three');
 const cards=[];let seed=0x51a,rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
 for(let i=0;i<n;i++){
  const g=Math.floor(i/3),blockedBy=[];
  if(kind==='chain'&&g)blockedBy.push('c'+(3*(g-1)),'c'+(3*(g-1)+1),'c'+(3*(g-1)+2));
  if(kind==='branch'||kind==='branch-shuffled')for(let h=Math.max(0,g-8);h<g;h++)if(rand()<.22)blockedBy.push('c'+(3*h+Math.floor(rand()*3)));
  cards.push({id:'c'+i,type:'t'+(g%19),zone:'board',available:!blockedBy.length,selectable:true,specialType:0,blockedBy});
 }
 if(kind==='branch-shuffled')for(let i=cards.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));[cards[i],cards[j]]=[cards[j],cards[i]];}
 return {mode:1,snapshotVerified:true,signature:'synthetic-'+n+'-'+kind,capacity:7,matchSize:3,cards,tray:[],inventory:[]};
}
function constructedRoute(n){return Array.from({length:n},(_,i)=>({kind:'card',id:'c'+i}));}
function benchmark(){
 const source=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_global.js'),'utf8'),make=vm.runInNewContext(source,{performance}),cases=[];
 for(const[n,kind]of[[228,'flat'],[228,'chain'],[228,'branch'],[228,'branch-shuffled'],[510,'flat'],[510,'branch']]){
  if(global.gc)global.gc();const startHeap=process.memoryUsage().heapUsed,input=fixture(n,kind),solver=make(),witness=solver.replay(input,constructedRoute(n));
  if(!witness.valid||!witness.complete)throw Error('constructed full witness is invalid');
  let peakHeap=startHeap,r,calls=0,times=[],start=performance.now();
  do{const t=performance.now();r=solver.plan(input);times.push(performance.now()-t);calls++;peakHeap=Math.max(peakHeap,process.memoryUsage().heapUsed);}while(r.status==='searching');
  const elapsed=performance.now()-start,proof=solver.replay(input,r.route),sorted=times.slice().sort((a,b)=>a-b);
  cases.push({cards:n,kind,constructedWitnessComplete:true,status:r.status,complete:r.complete,optimal:r.optimal,exhaustive:r.exhaustive,
   cleared:r.bestCleared,total:r.totalCards,reason:r.reason,states:r.states,calls,elapsedMs:+elapsed.toFixed(2),
   meanCallMs:+(times.reduce((a,b)=>a+b,0)/times.length).toFixed(2),p95CallMs:+sorted[Math.floor(.95*(sorted.length-1))].toFixed(2),
   maxCallMs:+Math.max(...times).toFixed(2),peakHeapGrowthMiB:+((peakHeap-startHeap)/1048576).toFixed(2),routeReplayValid:proof.valid,routeReplayComplete:proof.complete});
 }
 return {schema:'SDKtools.SyntheticGlobalBenchmark.v1',scope:'pure Node/V8 synthetic DAG, not game or iPhone evidence',node:process.version,
  sourceSHA256:require('node:crypto').createHash('sha256').update(source).digest('hex'),limits:{maxStates:60000,sliceNodes:96,searchLoopMs:3},
  note:'Wall call includes preparation and replay; 3ms is not a hard end-to-end deadline. Optimal means clearance in the modeled rules, not minimum stock cost.',cases};
}
if(require.main===module)process.stdout.write(JSON.stringify(benchmark(),null,2)+'\n');
module.exports={fixture,constructedRoute,benchmark};

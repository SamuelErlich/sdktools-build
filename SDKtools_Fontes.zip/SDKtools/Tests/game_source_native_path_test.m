#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <stdio.h>
#include <string.h>
#include "../Sources/SDKtools/STGameSourceNativePath.inc"

static NSUInteger checks,failures,sharedCalls,pathCalls;
static long long observedGame=-1;
static id fixtureManager;
static NSString *scenario;
static void Check(BOOL value,NSString *message) {
    checks++;if(!value){failures++;fprintf(stderr,"FAIL %s: %s\n",scenario.UTF8String,message.UTF8String);}
}
static id FixtureShared(__unused id receiver,__unused SEL selector) {
    sharedCalls++;
    if([scenario isEqualToString:@"wrong_object"])return [NSObject new];
    return fixtureManager;
}
static id FixturePath(__unused id receiver,__unused SEL selector,long long game) {
    pathCalls++;observedGame=game;
    if([scenario isEqualToString:@"getter_exception"])@throw [NSException exceptionWithName:@"FixtureReadError" reason:@"test" userInfo:nil];
    if([scenario isEqualToString:@"malformed_path"])return @"relative/package/game_res";
    if([scenario isEqualToString:@"nonstring_path"])return @42;
    if([scenario isEqualToString:@"valid_cache"])return @"/var/mobile/Containers/Data/Application/FIXTURE/Library/Caches/littleGame/runtime60_package/game_res";
    return @"/var/mobile/Containers/Data/Application/FIXTURE/Documents/littleGame/runtime60_package/game_res";
}
static void RegisterFixture(void) {
    Class manager=objc_allocateClassPair(NSObject.class,"WPDownloadManager",0);
    Check(manager!=Nil,@"fixture class allocated in clean subprocess");
    if(!manager)return;
    const char *sharedABI=[scenario isEqualToString:@"wrong_shared_abi"]?"q16@0:8":"@16@0:8";
    const char *pathABI=[scenario isEqualToString:@"wrong_path_abi"]?"@24@0:8@16":"@24@0:8q16";
    Check(class_addMethod(object_getClass(manager),sel_registerName("sharedManager"),(IMP)FixtureShared,sharedABI),@"fixture class getter installed");
    Check(class_addMethod(manager,sel_registerName("gameResDownloadPath:"),(IMP)FixturePath,pathABI),@"fixture resource getter installed");
    objc_registerClassPair(manager);fixtureManager=[[manager alloc]init];
}
static int RunScenario(void) {
    if(![scenario isEqualToString:@"missing_class"])RegisterFixture();
    __block NSString *status=nil;__block NSURL *URL=nil;
    if([scenario isEqualToString:@"background"]) {
        dispatch_semaphore_t semaphore=dispatch_semaphore_create(0);
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
            URL=STGameSourceNativeResourceURL(&status);dispatch_semaphore_signal(semaphore);
        });
        dispatch_semaphore_wait(semaphore,DISPATCH_TIME_FOREVER);
    } else if([scenario isEqualToString:@"unverified_game2007"]) URL=STGameSourceNativeResourceURLForGame(2007,&status);
    else URL=STGameSourceNativeResourceURL(&status);
    Check(status.length>0,@"status always explains the native path attempt");
    NSDictionary *expectedStatus=@{@"missing_class":@"native_class_unavailable",@"wrong_shared_abi":@"native_singleton_abi_mismatch",
        @"wrong_path_abi":@"native_getter_abi_mismatch",@"wrong_object":@"native_instance_mismatch",@"valid":@"native_path_ready",@"valid_cache":@"native_path_ready",
        @"malformed_path":@"native_path_invalid",@"nonstring_path":@"native_path_invalid",@"background":@"native_wrong_thread",@"getter_exception":@"native_read_exception",
        @"unverified_game2007":@"native_getter_unverified_for_game"};
    Check([status isEqualToString:expectedStatus[scenario]],@"structured status identifies the exact rejected contract");
    if([scenario isEqualToString:@"valid"]||[scenario isEqualToString:@"valid_cache"]) {
        Check(URL.isFileURL,@"valid original getter yields a local file URL");
        NSString *expectedPath=[scenario isEqualToString:@"valid_cache"]?@"/var/mobile/Containers/Data/Application/FIXTURE/Library/Caches/littleGame/runtime60_package/game_res":@"/var/mobile/Containers/Data/Application/FIXTURE/Documents/littleGame/runtime60_package/game_res";
        Check([URL.path isEqualToString:expectedPath],@"exact original resource path retained for scoped exporter validation");
        Check(sharedCalls==1&&pathCalls==1,@"each verified original getter called once");
        Check(observedGame==60,@"resource getter receives signed 64-bit game ID 60");
    } else {
        Check(URL==nil,@"unsupported native contract cannot supply an export root");
        if([scenario isEqualToString:@"missing_class"]||[scenario isEqualToString:@"wrong_shared_abi"]||[scenario isEqualToString:@"background"]||[scenario isEqualToString:@"unverified_game2007"])
            Check(sharedCalls==0&&pathCalls==0,@"invalid class, thread or shared ABI prevents all invocation");
        if([scenario isEqualToString:@"wrong_path_abi"]||[scenario isEqualToString:@"wrong_object"])
            Check(pathCalls==0,@"unverified receiver or path ABI never invoked");
        if([scenario isEqualToString:@"malformed_path"]||[scenario isEqualToString:@"nonstring_path"]||[scenario isEqualToString:@"getter_exception"])
            Check(pathCalls==1&&observedGame==60,@"bad result rejected after one correct game60 getter call");
    }
    printf("Native source path %s: %lu checks, %lu failures\n",scenario.UTF8String,(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
}
int main(int argc,const char *argv[]) {@autoreleasepool {
    if(argc==2){scenario=[NSString stringWithUTF8String:argv[1]];return RunScenario();}
    // Each ABI fixture needs an independent Objective-C class registry. No
    // replacement of a live application method is performed by these tests.
    scenario=@"subprocess_runner";
    NSURL *executable=[NSURL fileURLWithPath:[NSProcessInfo processInfo].arguments[0]];
    for(NSString *name in @[@"missing_class",@"wrong_shared_abi",@"wrong_path_abi",@"wrong_object",@"valid",@"valid_cache",@"malformed_path",@"nonstring_path",@"background",@"getter_exception",@"unverified_game2007"]) {
        NSTask *task=[NSTask new];task.executableURL=executable;task.arguments=@[name];
        NSError *error=nil;BOOL launched=[task launchAndReturnError:&error];
        Check(launched,[NSString stringWithFormat:@"launch %@",name]);
        if(launched){[task waitUntilExit];Check(task.terminationStatus==0,[NSString stringWithFormat:@"native contract %@",name]);}
    }
    printf("Native source path runner: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
}}

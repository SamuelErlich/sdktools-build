#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STLocalization.h"
#import <dispatch/dispatch.h>
#include <assert.h>
static NSUInteger checks;
static void equal(NSString *actual,NSString *expected) {
    if (![actual isEqual:expected]) { NSLog(@"Expected %@, got %@",expected,actual); abort(); }
    checks++;
}
static STLocalizationCatalog *catalogWithRoot(id root) {
    NSData *data=[NSJSONSerialization dataWithJSONObject:root options:NSJSONWritingFragmentsAllowed error:NULL];
    assert(data);
    return [[STLocalizationCatalog alloc] initWithData:data];
}
static NSDictionary *rootWithRows(NSArray *rows) {
    return @{@"schemaVersion":@1,@"languages":@[@"en",@"pt"],@"entries":rows};
}
static void rejectsRows(NSArray *rows) { assert(!catalogWithRoot(rootWithRows(rows))); checks++; }
static void parserContracts(void) {
    STLocalizationCatalog *typed=catalogWithRoot(rootWithRows(@[
        @{@"en":@"Count %lu",@"pt":@"Total %lu",@"source":@"raw_count=%lu"},
        @{@"en":@"Delta %ld",@"pt":@"Diferença %ld"},
        @{@"en":@"Power %.2f",@"pt":@"Força %.2f"},
        @{@"en":@"Charge %02u%%",@"pt":@"Carga %02u%%"},
        @{@"en":@"State: %@.",@"pt":@"Estado: %@."},
        @{@"en":@"Ready",@"pt":@"Pronto"},
        @{@"en":@"2",@"pt":@"dois"}
    ]));
    assert(typed);
    equal([typed text:@"Count 2" language:@"pt"],@"Total 2"); // Never translate a numeric capture as an alias.
    equal([typed text:@"raw_count=2" language:@"pt"],@"Total 2");
    equal([typed text:@"Count -2" language:@"pt"],@"Count -2");
    equal([typed text:@"Count 1.5" language:@"pt"],@"Count 1.5");
    equal([typed text:@"Delta -3" language:@"pt"],@"Diferença -3");
    equal([typed text:@"Delta +3" language:@"pt"],@"Diferença +3");
    equal([typed text:@"Delta 3.5" language:@"pt"],@"Delta 3.5");
    equal([typed text:@"Power -0.25" language:@"pt"],@"Força -0.25");
    equal([typed text:@"Power +0,25" language:@"pt"],@"Força +0,25");
    equal([typed text:@"Charge 02%" language:@"pt"],@"Carga 02%");
    equal([typed text:@"Estado: Pronto." language:@"en"],@"State: Ready.");
    equal([typed text:@"State: ." language:@"pt"],@"Estado: .");
    equal([typed text:@"State: unknown text." language:@"pt"],@"Estado: unknown text.");
    equal([typed text:@"Total 2" language:@"invalid"],@"Count 2");
    NSString *longInput=[@"x" stringByPaddingToLength:8193 withString:@"x" startingAtIndex:0];
    equal([typed text:longInput language:@"pt"],longInput);
    for (NSArray *rows in @[
        @[], @[@1], @[@{@"en":@"Ready"}], @[@{@"en":@"Ready",@"pt":@""}],
        @[@{@"en":@"Ready",@"pt":NSNull.null}],
        @[@{@"en":@"Count %lu",@"pt":@"Total %@"}],
        @[@{@"en":@"Count %lu",@"pt":@"Total %ld"}],
        @[@{@"en":@"Power %.2f",@"pt":@"Força %.3f"}],
        @[@{@"en":@"Value %d %@",@"pt":@"Valor %@ %d"}],
        @[@{@"en":@"Count %lu",@"pt":@"Total %lu",@"source":@"raw %d"}],
        @[@{@"en":@"Value %n",@"pt":@"Valor %n"}],
        @[@{@"en":@"Value %2$@",@"pt":@"Valor %2$@"}],
        @[@{@"en":@"Value %*d",@"pt":@"Valor %*d"}],
        @[@{@"en":@"Value %l@",@"pt":@"Valor %l@"}],
        @[@{@"en":@"Value %",@"pt":@"Valor %"}],
        @[@{@"en":@"%@",@"pt":@"%@"}],
        @[@{@"en":@"%@%@",@"pt":@"%@%@"}],
        @[@{@"en":@"Ready",@"pt":@"Pronto"},@{@"en":@"Ready",@"pt":@"Outro"}],
        @[@{@"en":@"Ready",@"pt":@"Pronto"},@{@"en":@"Other",@"pt":@"Outro",@"source":@"Pronto"}],
        @[@{@"en":[@"x" stringByPaddingToLength:2049 withString:@"x" startingAtIndex:0],@"pt":@"texto"}]
    ]) rejectsRows(rows);
    NSArray *validRows=@[@{@"en":@"Ready",@"pt":@"Pronto"}];
    for (id schema in @[@YES,@2,@"1",NSNull.null]) {
        NSMutableDictionary *bad=[rootWithRows(validRows) mutableCopy]; bad[@"schemaVersion"]=schema;
        assert(!catalogWithRoot(bad)); checks++;
    }
    for (id languages in @[@[@"pt",@"en"],@[@"en"],@"en",NSNull.null]) {
        NSMutableDictionary *bad=[rootWithRows(validRows) mutableCopy]; bad[@"languages"]=languages;
        assert(!catalogWithRoot(bad)); checks++;
    }
    NSMutableArray *oversized=[NSMutableArray array];
    for (NSUInteger i=0;i<1025;i++) [oversized addObject:validRows.firstObject];
    rejectsRows(oversized);
    assert(![[STLocalizationCatalog alloc] initWithData:[NSData data]]); checks++;
    assert(![[STLocalizationCatalog alloc] initWithData:[NSMutableData dataWithLength:1024*1024+1]]); checks++;
}
int main(int argc,const char **argv) { @autoreleasepool {
    assert(argc==2);
    NSData *data=[NSData dataWithContentsOfFile:[NSString stringWithUTF8String:argv[1]]];
    STLocalizationCatalog *catalog=[[STLocalizationCatalog alloc] initWithData:data];
    assert(catalog && catalog.entryCount>=290);
    NSDictionary *root=[NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    for (NSDictionary *row in root[@"entries"]) for (NSString *source in row[@"source"]?@[row[@"en"],row[@"pt"],row[@"source"]]:@[row[@"en"],row[@"pt"]]) {
        equal([catalog text:source language:@"en"],row[@"en"]);
        equal([catalog text:source language:@"pt"],row[@"pt"]);
    }
    equal([catalog text:@"Cards is open. Your controls are ready." language:@"pt"],@"Minijogo aberto: Cartas. Controles prontos.");
    equal([catalog text:@"Depth · 5 layers" language:@"pt"],@"Profundidade · 5 camadas");
    equal([catalog text:@"Profundidade · 1 camada" language:@"en"],@"Depth · 1 layer");
    equal([catalog text:@"Auto calculando o próximo trio · missão primeiro 2/6 · plano ampliado · Turbo · poderes habilitados · 31 cartas · 12 jogadas" language:@"en"],
          @"Autoplay calculating the next trio · mission first 2/6 · extended plan · Turbo · powers enabled · 31 cards · 12 moves");
    equal([catalog text:@"Auto lendo a mesa · lote: até 3 · 20 cartas · 2 jogadas" language:@"en"],
          @"Autoplay reading the board · batch: up to 3 · 20 cards · 2 moves");
    equal([catalog text:@"lote: até 2 · lote em curso: 3 enviadas" language:@"en"],
          @"batch: up to 2 · current batch: 3 sent");
    equal([catalog text:@"lote: até 2 · lote indisponível: 1 por vez" language:@"en"],
          @"batch: up to 2 · batch unavailable: 1 at a time");
    equal([catalog text:@"batch: up to 3 · current batch: 2 sent" language:@"pt"],
          @"lote: até 3 · lote em curso: 2 enviadas");
    equal([catalog text:@"Mãos atuais: 7 cartas · 3 faces confirmadas · 4 desconhecidas · 2 marcadores parciais (não é o total de cartas)" language:@"en"],
          @"Current hands: 7 cards · 3 confirmed faces · 4 unknown cards · 2 partial markers (not the total card count)");
    equal([catalog text:@"Marcadores parciais: 2 cores · 1 especiais · 4 sem cor confirmada · 3 sem marcador · 2 via select_give_card · total das mãos indisponível" language:@"en"],
          @"Partial markers: 2 colors · 1 special cards · 4 without a confirmed color · 3 without a marker · 2 via select_give_card · hand totals unavailable");
    equal([catalog text:@"Parada estimada · 4 bolas" language:@"en"],@"Estimated stop · 4 balls");
    equal([catalog text:@"Auto · Mira pronta · bola 8 → 2 · força 0.75\nTacadas 3 · calibração 2/3 · 01:09" language:@"en"],
          @"Auto · Aim ready · ball 8 → 2 · power 0.75\nShots 3 · calibration 2/3 · 01:09");
    equal([catalog text:@"Mira pronta · aim_only_no_shot" language:@"en"],@"Aim ready · Aim adjusted without shooting");
    equal([catalog text:@"Mira pronta · aim_only_no_shot" language:@"pt"],@"Mira pronta · Mira ajustada sem tacada");
    equal([catalog text:@"future_internal_reason" language:@"pt"],@"Informação de estado indisponível.");
    equal([catalog text:@"Forged hot. Played cold." language:@"pt"],@"Forged hot. Played cold.");
    equal([catalog text:@"unrecognized game text 123" language:@"pt"],@"unrecognized game text 123");
    equal([catalog text:@"31 cards" language:@"pt"],@"31 cartas");
    equal([catalog text:@"31 cartas · 12 jogadas" language:@"en"],@"31 cards · 12 moves");
    equal([catalog text:@"31 cards · 12 moves" language:@"pt"],@"31 cartas · 12 jogadas");
    equal([catalog text:@"Camadas abaixo: 5" language:@"en"],@"Layers below: 5");
    equal([catalog text:@"Layers below: 5" language:@"pt"],@"Camadas abaixo: 5");
    equal(STLanguageFromPreferences(@[@"pt-BR"],nil),@"pt");
    equal(STLanguageFromPreferences(@[@"pt_PT"],nil),@"pt");
    equal(STLanguageFromPreferences(@[@"en-US"],nil),@"en");
    equal(STLanguageFromPreferences(@[@"fr",@"pt"],nil),@"pt");
    equal(STLanguageFromPreferences(@[@"fr"],nil),@"en");
    equal(STLanguageFromPreferences(@[@"pt"],@"en"),@"en");
    equal(STLanguageFromPreferences(@[@"en"],@"pt"),@"pt");
    equal(STLanguageFromPreferences(@[@"pt"],@"invalid"),@"pt");
    id old=[NSUserDefaults.standardUserDefaults objectForKey:@"SDKClient.language"];
    assert(STSetLanguage(@"en")); __block NSUInteger notifications=0;
    id observer=[NSNotificationCenter.defaultCenter addObserverForName:STLanguageDidChangeNotification object:nil queue:nil usingBlock:^(__unused NSNotification *note){ notifications++; }];
    assert(STSetLanguage(@"pt")); assert(STSetLanguage(@"pt")); assert(!STSetLanguage(@"fr"));
    equal(STCurrentLanguage(),@"pt"); equal([NSUserDefaults.standardUserDefaults stringForKey:@"SDKClient.language"],@"pt"); assert(notifications==1);
    assert(STSetLanguage(@"en")); equal(STCurrentLanguage(),@"en"); assert(notifications==2);
    __block BOOL backgroundAccepted=YES;
    dispatch_group_t workers=dispatch_group_create();
    dispatch_group_async(workers,dispatch_get_global_queue(QOS_CLASS_DEFAULT,0),^{
        backgroundAccepted=STSetLanguage(@"pt");
        for (NSUInteger i=0;i<100;i++) assert([STCurrentLanguage() isEqual:@"en"]);
    });
    dispatch_group_wait(workers,DISPATCH_TIME_FOREVER);
    assert(!backgroundAccepted && notifications==2); equal(STCurrentLanguage(),@"en");
    [NSNotificationCenter.defaultCenter removeObserver:observer];
    if(old)[NSUserDefaults.standardUserDefaults setObject:old forKey:@"SDKClient.language"];else[NSUserDefaults.standardUserDefaults removeObjectForKey:@"SDKClient.language"];
    assert(![[STLocalizationCatalog alloc] initWithData:[@"{}" dataUsingEncoding:NSUTF8StringEncoding]]);
    parserContracts();
    printf("%lu production localization checks passed\n",(unsigned long)checks);
} return 0; }

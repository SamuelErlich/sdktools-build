const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const read=n=>fs.readFileSync(path.join(__dirname,'../Resources/',n+'.js'),'utf8');
function create(clock=()=>0){const context=vm.createContext({Date:{now:clock}});return vm.runInContext('('+read('autoplay_extended')+')(('+read('autoplay_planner')+'))',context);}
const card=(id,type,blockedBy=[],extra={})=>({id,type,blockedBy,zone:'board',available:!blockedBy.length,...extra});
const state=(cards,tray=[],extra={})=>({cards,tray:tray.map((type,i)=>({id:'tray'+i,type})),capacity:7,matchSize:3,extendedPlanning:true,...extra});
function finish(input,fn=create()){for(let i=0;i<200;i++){const out=fn(input);if(out.status!=='searching')return JSON.parse(JSON.stringify(out));}throw Error('not bounded');}
function replay(input,out){
 const left=new Map(input.cards.map(c=>[c.id,c])),hand=input.tray.slice();let trios=0;
 for(const id of out.sequence){const c=left.get(id);assert.ok(c);assert.notEqual(c.locked,true);assert.notEqual(c.selectable,false);
  assert.ok(c.available||c.blockedBy.length);assert.ok(c.blockedBy.every(b=>!left.has(b)));left.delete(id);hand.push(c);assert.ok(hand.length<=7);
  const match=hand.filter(h=>h.type===c.type);if(match.length===3){trios++;for(const m of match)hand.splice(hand.indexOf(m),1);}
  assert.ok(hand.length<7);
 }
 assert.equal(trios,1);assert.equal(out.proofKind,'local_trio');assert.equal(out.cardID,out.sequence[0]);
 assert.deepEqual(out.sequence,out.actions);assert.equal(out.tripleCardIDs.length,3);
}
test('off uses exactly the original planner result without multi-trio claims',()=>{
 const input=state(['a','a','a'].map((t,i)=>card('c'+i,t)),[],{extendedPlanning:false}),out=finish(input);
 assert.equal(out.status,'move');assert.equal(out.stats.goal,'next_trio');assert.equal(out.stats.lookaheadDepth,undefined);replay(input,out);
});
test('cooperative assisted phase enables bounded lookahead at original 75 percent',()=>{
 const cards=Array.from({length:60},(_,i)=>card('c'+i,'t'+Math.floor(i/3)));
 const early=finish(state(cards,[],{cooperative:true,extendedPlanning:false,phaseSnapshot:{progressPercent:74}}));
 assert.equal(early.stats.goal,'next_trio');
 const assisted=finish(state(cards,[],{cooperative:true,extendedPlanning:false,phaseSnapshot:{progressPercent:75}}));
 assert.equal(assisted.stats.goal,'multi_trio');assert.ok(assisted.stats.lookaheadNodes<=12000);replay(state(cards),assisted);
});
test('lookahead explores and compares several triples but publishes only the independently replayable first trio',()=>{
 const input=state(Array.from({length:12},(_,i)=>card('c'+i,'abcd'[Math.floor(i/3)]))),out=finish(input);
 assert.equal(out.status,'move');assert.equal(out.stats.goal,'multi_trio');assert.ok(out.stats.lookaheadTriples>=3);
 assert.ok(out.stats.lookaheadDepth>=6);assert.ok(out.stats.lookaheadDepth<=18);assert.ok(out.stats.lookaheadNodes<=12000);
 assert.equal(out.stats.completeSearch,false);assert.equal(out.stats.completeSolution,false);replay(input,out);
});
test('mission-first baseline is never downgraded by lookahead',()=>{
 const input=state(['a','a','a','m','m','m','b','b','b'].map((t,i)=>card('c'+i,t)),[],{mission:{type:'m',current:0,total:3}}),out=finish(input);
 assert.equal(out.matchedType,'m');assert.equal(out.stats.missionStatus,'priority');replay(input,out);
});
test('search cache invalidates on observed board, mission and state generation changes',()=>{
 const plan=create(),a=state(['a','a','a','b','b','b'].map((t,i)=>card('c'+i,t)),[],{stateKey:'one'});
 assert.equal(finish(a,plan).status,'move');const b=state([card('locked','a',[],{locked:true})],[],{stateKey:'two'});
 assert.notEqual(finish(b,plan).status,'move');assert.equal(finish(a,plan).status,'move');
});
test('malformed cyclic dependency and unsupported rules are still rejected by the original validator',()=>{
 for(const input of [state([card('a','a',['b']),card('b','a',['a'])]),state([card('a','a')],[],{capacity:99})])
  assert.equal(finish(input).status,'invalid_state');
});
test('512-card bounded lookahead yields across slices and eventually returns a safe fallback',()=>{
 const input=state(Array.from({length:512},(_,i)=>card('c'+i,'t'+Math.floor(i/3)))),plan=create();let result,calls=0;
 do{result=plan(input);calls++;}while(result.status==='searching'&&calls<100);
 assert.equal(result.status,'move');assert.ok(calls<=26);assert.ok(result.stats.lookaheadNodes<=12000);replay(input,JSON.parse(JSON.stringify(result)));
});
test('time budget cannot authorize an unproved card',()=>{
 let t=0;const plan=create(()=>t++),input=state(Array.from({length:15},(_,i)=>card('c'+i,'t'+Math.floor(i/3))));
 for(let i=0;i<10;i++){const out=plan(input);if(out.status==='move')replay(input,JSON.parse(JSON.stringify(out)));else assert.equal(out.status,'searching');}
});
test('deterministic generated DAGs never publish a covered, locked or tray-overflow first route',()=>{
 let seed=20261017;const random=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;};let proved=0;
 for(let k=0;k<80;k++){
  const cards=[];for(let i=0;i<15;i++){const blockers=i&&random(4)===0?['c'+random(i)]:[];cards.push(card('c'+i,'t'+random(4),blockers,{locked:random(15)===0}));}
  const input=state(cards),out=finish(input);if(out.status==='move'){replay(input,out);proved++;}
 }
 assert.ok(proved>40);
});
test('resources add no timers, transport, remote code execution or captured-module execution',()=>{
 for(const name of ['autoplay_extended','autoplay_powers']){const source=read(name);assert.ok(Buffer.byteLength(source)<65536);
  assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout)\s*\(/);assert.doesNotMatch(source,/new\s+Function\b/);}
});

const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_win.js'),'utf8');
const factory=vm.runInNewContext(source);
test('forked counterfactual analysis cannot mutate the visible Win session',()=>{
 const original=factory(),before=finish(fixture(['a','a','a']),original),other=original.fork();
 assert.notEqual(other,original);assert.equal(finish(fixture(['b']),other).winPercent,0);
 assert.equal(JSON.stringify(original.current()),JSON.stringify(before));other.invalidate();assert.equal(original.current().winPercent,100);
});
function fixture(types, tray=[]){
 return {signature:'board',capacity:7,cards:types.map((type,i)=>({id:'c'+i,type,zone:'board',available:true,selectable:true,blockedBy:[],metadata:{specialType:0}})),
  tray:tray.map((type,i)=>({id:'t'+i,type,zone:'tray',metadata:{specialType:0}}))};
}
function finish(s,analyzer=factory()){
 let r;for(let i=0;i<20000;i++){r=analyzer.observe(s,true);if(r.status!=='searching')return r;}assert.fail('analysis failed to terminate');
}
function cover(s,below,above){s.cards[below].blockedBy.push('c'+above);s.cards[below].available=false;}
test('exact 100% means every legal local continuation clears the known board',()=>{
 const s=fixture(['a','a','a']),before=JSON.stringify(s),r=finish(s);
 assert.equal(r.status,'exact');assert.equal(r.winPercent,100);assert.equal(r.searchComplete,true);assert.equal(r.bestCaptures,3);
 assert.equal(r.bestClearedCards,3);assert.equal(r.remainingAtStop,0);assert.equal(r.stopReason,'clear');assert.equal(r.visiblePairs,1);
 assert.equal(JSON.stringify(s),before);
});
test('a visible pair is not a trio: unmatched totals prove 0%, not a win',()=>{
 const r=finish(fixture(['a','a']));assert.equal(r.winPercent,0);assert.equal(r.impossible,true);assert.equal(r.visiblePairs,1);
 assert.equal(r.bestCaptures,2);assert.equal(r.remainingAtStop,2);assert.equal(r.stopTrayCount,2);assert.equal(r.stopReason,'unmatched_cards');
});
test('no trio reachable before the seventh slot: 0% with a balanced inventory',()=>{
 const s=fixture(['a','b','c','d','e','f','g','a','a','b','b','c','c','d','d','e','e','f','f','g','g']);
 // Every possible matching card depends on all seven distinct exposed cards.
 for(let i=7;i<s.cards.length;i++)for(let j=0;j<7;j++)cover(s,i,j);
 const r=finish(s);assert.equal(r.status,'exact');assert.equal(r.winPercent,0);assert.equal(r.impossible,true);
 assert.equal(r.reason,'all_routes_evaluated');
 assert.equal(r.bestCaptures,6);assert.equal(r.bestClearedCards,0);assert.equal(r.stopTrayCount,6);assert.equal(r.stopReason,'capacity');
});
test('removing a blocker exposes a same-type card without clicking anything',()=>{
 const s=fixture(['a','a','a']);cover(s,0,1);cover(s,1,2);
 const r=finish(s);assert.equal(r.winPercent,100);assert.equal(r.exposedCards,1);assert.equal(r.visiblePairs,0);assert.equal(r.bestCaptures,3);
});
test('existing tray pair closes a trio even in the last slot',()=>{
 const s=fixture(['a','b','b','c','c'],['a','a','b','c']);
 const r=finish(s);assert.equal(r.status,'exact');assert.ok(r.winPercent>0);assert.equal(r.bestClearedCards,9);
 const full=finish(fixture(['a'],['a','b','c','d','e','f','g']));assert.equal(full.winPercent,0);assert.equal(full.bestCaptures,0);assert.equal(full.stopTrayCount,7);
});
test('all seven known loaded slots already empty is local completion only',()=>{
 const r=finish(fixture([]));assert.equal(r.winPercent,100);assert.equal(r.totalCards,0);assert.equal(r.stopReason,'clear');
});
for(const [name,mutate] of [
 ['unknown type',s=>s.cards[0].type='unknown'],['duplicate ID',s=>s.cards[0].id=s.cards[1].id],
 ['missing blocker',s=>{s.cards[0].blockedBy=['absent'];s.cards[0].available=false;}],
 ['cyclic graph',s=>{cover(s,0,1);cover(s,1,0);}],['unreadable control',s=>s.cards[0].available=false],
 ['special rule',s=>s.cards[0].metadata.specialType=1],['locked card',s=>s.cards[0].selectable=false],
 ['unknown reserve order',s=>s.cards[0].zone='reserve'],['unsettled tray',s=>s.tray=fixture([],['a','a','a']).tray],
 ['oversized board',s=>s.cards=fixture(Array(513).fill('a')).cards]
])test('incomplete/unsupported observation has no percentage: '+name,()=>{
 const s=fixture(['a','a','a']);mutate(s);const r=finish(s);assert.equal(r.status,'unavailable');assert.equal(r.winPercent,undefined);
});
test('verified reserve uses the original dependency chain, not exposed controls alone',()=>{
 const s=fixture(['a','a','a']);s.cards.forEach(c=>{c.zone='reserve';c.storageVerified=true;});cover(s,0,1);cover(s,1,2);
 const r=finish(s);assert.equal(r.exposedCards,1);assert.equal(r.winPercent,100);
});
test('invalidated/unstable/changed observations never leak the old percentage',()=>{
 const a=factory(),s=fixture(['a','a','a']);assert.equal(finish(s,a).winPercent,100);
 a.invalidate();assert.equal(a.current().status,'unavailable');assert.equal(a.current().winPercent,undefined);
 assert.equal(a.observe(s,false).status,'unavailable');assert.equal(finish(s,a).winPercent,100);
 s.cards[0].metadata.specialType=1;assert.equal(a.observe(s,true).status,'unavailable');
 delete s.cards[0].metadata;s.cards.pop();assert.equal(finish(s,a).winPercent,0);
});
test('large boards resume in bounded slices, cache, and do not turn sampling into certainty',()=>{
 const s=fixture(Array(60).fill('a')),a=factory(),first=a.observe(s,true);assert.equal(first.status,'searching');
 const r=finish(s,a);assert.equal(r.status,'estimated');assert.equal(r.samples,128);assert.equal(r.wins,128);
 assert.ok(r.winPercent>99&&r.winPercent<100);assert.equal(r.searchComplete,false);assert.equal(r.impossible,false);
 assert.deepEqual(a.observe(s,true),r);assert.equal(r.bestCaptures,60);assert.equal(r.bestClearedCards,60);
});
test('zero sampled wins still cannot claim zero chance',()=>{
 const s=fixture(Array.from({length:24},(_,i)=>'t'+(i%8)));
 for(let i=7;i<24;i++)for(let j=0;j<7;j++)cover(s,i,j);
 const r=finish(s);assert.equal(r.status,'estimated');assert.equal(r.wins,0);assert.ok(r.winPercent>0&&r.winPercent<1);assert.equal(r.impossible,false);
});
test('sampled local impossibility can be proven by type counts, while stall point stays simulated',()=>{
 const r=finish(fixture(Array(25).fill('a')));assert.equal(r.winPercent,0);assert.equal(r.impossible,true);assert.equal(r.searchComplete,false);
 assert.equal(r.bestClearedCards,24);assert.equal(r.remainingAtStop,1);
});
test('512-card graph respects limits and keeps sample estimates strictly inside endpoints',()=>{
 const s=fixture(Array(510).fill('a'));const r=finish(s);assert.equal(r.samples,128);assert.ok(r.winPercent<100);assert.equal(r.bestClearedCards,510);
});
// Independent small-state enumerator checks exact probabilities, including
// mixed wins/losses, transpositions, capacity and cross-type cover chains.
function reference(s){
 const memo=new Map();
 function recurse(gone,bar){
  const stamp=[...gone].sort((a,b)=>a-b).join(',');if(memo.has(stamp))return memo.get(stamp);
  let opts=[];for(let i=0;i<s.cards.length;i++){const c=s.cards[i];if(gone.has(i)||c.blockedBy.some(id=>!gone.has(Number(id.slice(1)))))continue;
   const same=bar.filter(t=>t===c.type).length;if(same===2||bar.length+1<7)opts.push({i,weight:same===2?6:same===1?3:1});}
  if(!opts.length)return gone.size===s.cards.length&&bar.length===0?1:0;
  let sum=0,total=0;for(const o of opts){let next=bar.concat(s.cards[o.i].type);if(next.filter(t=>t===s.cards[o.i].type).length===3)next=next.filter(t=>t!==s.cards[o.i].type);
   sum+=o.weight*recurse(new Set([...gone,o.i]),next);total+=o.weight;}memo.set(stamp,sum/total);return sum/total;
 }return recurse(new Set(),s.tray.map(c=>c.type))*100;
}
test('exact outcome probability agrees with independent enumeration',()=>{
 let seed=5,rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296),mixed=0;
 for(let trial=0;trial<30;trial++){
  const s=fixture(['a','a','a','b','b','b','c','c','c','d','d','d']);
  for(let i=0;i<12;i++)for(let j=i+1;j<12;j++)if(rand()<.2)cover(s,i,j);
  const r=finish(s),expected=reference(s);assert.equal(r.status,'exact');assert.ok(Math.abs(r.winPercent-expected)<1e-8,`${r.winPercent} != ${expected}`);
  if(expected>0&&expected<100)mixed++;
 }assert.ok(mixed>0,'fixtures exercise a partial probability');
});

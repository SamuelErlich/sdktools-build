"""Native HotTime bridge composition, resource and diagnostic contracts."""
import json
from pathlib import Path
import re
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]


class HotTimeNativeContracts(unittest.TestCase):
    def read(self, name):
        return (ROOT / name).read_text(encoding="utf-8")

    def test_real_bootstrap_passes_ninth_factory_and_hot_path_reuses_it(self):
        bridge = self.read("Sources/SDKtools/STAutoplayBridge.inc")
        bootstrap = re.search(r'NSString \*wrapped[\s\S]*?@"([^"\n]+)"', bridge).group(1)
        hot = re.search(r'// Hot path:[\s\S]*?@"([^"\n]+)"', bridge).group(1)
        adapter = """function () {
            const a = Array.from(arguments);
            if (a.length !== 9 || a[8]() !== 'hot-time-guard') throw Error('missing ninth guard');
            if (a[0] !== 'extended-plan' || a[7] !== 'cooperative-plan') throw Error('factory order');
            window.factoryCalls = (window.factoryCalls || 0) + 1;
            return function (o) { return {guard:a[8](),cardsPerBatch:o.cardsPerBatch}; };
        }"""
        options = ["true", "false", "false", "false", "true", "3", "false", "false", "false", "4", "1"]
        args = ["test-namespace", "test-document", adapter,
                "function(p){return 'extended-'+p;}", "'plan'", "null", "null", "null", "null", "null", "null",
                "function(p){return 'cooperative-'+p;}", "'plan'", "function(){return 'hot-time-guard';}"] + options

        def expand(template, values):
            self.assertEqual(len(re.findall(r"%@|%ld|%lu", template)), len(values))
            iterator = iter(values)
            return re.sub(r"%@|%ld|%lu", lambda _: next(iterator), template)

        boot_js = expand(bootstrap, args)
        options[5] = "2"
        hot_js = expand(hot, ["test-namespace", "test-document"] + options)
        script = """const vm=require('node:vm'),assert=require('node:assert/strict');
            const context={window:{}};
            const first=vm.runInNewContext(BOOT,context);
            const next=vm.runInNewContext(HOT,context);
            assert.equal(first.guard,'hot-time-guard');assert.equal(first.cardsPerBatch,3);
            assert.equal(next.guard,'hot-time-guard');assert.equal(next.cardsPerBatch,2);
            assert.equal(context.window.factoryCalls,1);
            assert.equal(next.runtimeDocumentID,'test-document');
        """.replace("BOOT", json.dumps(boot_js)).replace("HOT", json.dumps(hot_js))
        subprocess.run(["node", "-e", script], check=True, capture_output=True, text=True)

    def test_guard_is_required_by_native_loader_and_packaging(self):
        web = self.read("Sources/SDKtools/STWebProbe.m")
        bridge = self.read("Sources/SDKtools/STAutoplayBridge.inc")
        self.assertIn('@"alpaca_hottime"', web)
        self.assertIn('_hotTimeScript = source;', web)
        self.assertIn('!self.hotTimeScript.length', bridge)
        self.assertIn('self.cooperativeScript, self.plannerScript, self.hotTimeScript,', bridge)
        self.assertIn('Resources/alpaca_hottime.js', self.read('scripts/build_framework.sh'))
        self.assertIn("'alpaca_hottime.js'", self.read('scripts/integrate_ipa.py'))

    def test_closed_hot_time_diagnostic_reaches_report_and_lan(self):
        sanitizer = self.read('Sources/SDKtools/STAutoplaySanitizer.inc')
        self.assertEqual(sanitizer.count('STWPSanitizeHotTime(value[@"hotTime"])'), 2)
        self.assertIn('@"cooperative", @"hotTime"', self.read('Sources/SDKtools/STAutoplayRecorder.inc'))
        lan = self.read('Sources/SDKtools/STLANRecorder.inc')
        self.assertIn('STWPSanitizeHotTime(self.autoplayReadingDiagnostic[@"hotTime"])', lan)
        self.assertIn('@"hotTime":hotTime ?: @{}', lan)
        self.assertIn('@"lastObservation":STWPSanitizeAutoplayReading(reading)', self.read('Sources/SDKtools/STCoveredCardReport.inc'))

    def test_obsolete_protection_copy_is_removed(self):
        rows = json.loads(self.read('Resources/Brand/menu-localizations.json'))['entries']
        self.assertFalse(any(row['en'].startswith('Autoplay: diamonds protected;') for row in rows))

    def test_obsolete_supply_veto_reasons_are_not_action_outcomes(self):
        sanitizer = self.read('Sources/SDKtools/STAutoplaySanitizer.inc')
        cooperative = sanitizer.split('static NSDictionary *STWPSanitizeCooperative', 1)[1].split('static NSDictionary *STWPSanitizeAutoplay', 1)[0]
        for reason in ('diamond_charge_unverified', 'diamond_charge_unavailable'):
            self.assertNotIn(reason, cooperative)


if __name__ == '__main__':
    unittest.main()

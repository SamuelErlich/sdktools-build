#import "../Sources/SDKtools/STCardEarlySanitizer.inc"
#include <stdio.h>
static NSUInteger checks, failures;
static void Check(BOOL ok, NSString *why) { checks++; if (!ok) { failures++; fprintf(stderr, "FAIL: %s\n", why.UTF8String); } }
int main(void) { @autoreleasepool {
    NSMutableDictionary *card = [@{@"zone":@"hand", @"index":@0, @"slot":@0, @"objectID":@"ec1", @"id":@31, @"type":@0, @"color":@0, @"num":@0, @"uid":@"PRIVATE"} mutableCopy];
    NSMutableDictionary *event = [@{@"sequence":@1, @"stage":@"socket_decoded_response", @"callID":@1, @"elapsedMs":@10, @"round":@1, @"cards":@[card], @"truncated":@NO, @"secret":@"PRIVATE", @"command":@"CMD_SYNC"} mutableCopy];
    NSMutableDictionary *raw = [@{@"version":@1, @"status":@"ready", @"reason":@"observing", @"events":@[event], @"elapsedMs":@10, @"milestones":@{@"beforeSocket":@YES, @"token":@"PRIVATE"}, @"counters":@{@"decodedResponses":@1, @"cookie":@"PRIVATE"}, @"gaps":@[@"initial_sync_unproven", @"PRIVATE"], @"url":@"PRIVATE"} mutableCopy];
    NSDictionary *safe = STESanitizeObservation(raw), *saved = safe[@"events"][0][@"cards"][0];
    Check([saved[@"present"] isEqual:@15] && [saved[@"color"] isEqual:@0], @"zeros preserved with presence");
    Check([saved[@"colorState"] isEqual:@"unknown"], @"hidden cards remain unknown");
    Check([safe[@"events"][0][@"command"] isEqual:@"CMD_SYNC"], @"allowlisted command retained");
    NSData *json = STEBoundedJSON(safe, 65536);
    Check(json && ![[[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding] containsString:@"PRIVATE"], @"no arbitrary strings at any level");
    Check([safe[@"gaps"] count] == 1, @"only known gaps exported");
    for (id bad in @[@YES, @0, @2, @"1", NSNull.null]) { raw[@"version"] = bad; Check(STESanitizeObservation(raw) == nil, @"strict schema version"); }
    raw[@"version"] = @1;
    for (id bad in @[@YES, @(-1), @5, @"3", @(NAN)]) { card[@"color"] = bad; NSDictionary *c = STESanitizeObservation(raw)[@"events"][0][@"cards"][0]; Check(!c[@"color"] && [c[@"present"] isEqual:@11], @"bad colors omitted, not invented"); }
    card[@"color"] = @3; card[@"colorState"] = @"known";
    Check([STESanitizeObservation(raw)[@"events"][0][@"cards"][0][@"colorState"] isEqual:@"candidate"], @"masked nonzero color cannot claim known");
    card[@"type"] = @6; card[@"color"] = @0;
    Check([STESanitizeObservation(raw)[@"events"][0][@"cards"][0][@"colorState"] isEqual:@"special"], @"special zero kept distinct");
    card[@"type"] = @1; card[@"color"] = @2; card[@"slot"] = @8;
    Check([STESanitizeObservation(raw)[@"events"][0][@"cards"] count] == 0, @"bad hand slot rejected"); card[@"slot"] = @0;
    event[@"nodeID"] = @"en4"; event[@"objectID"] = @"ec1"; event[@"bindingValid"] = @NO; event[@"bindingGeneration"] = @2;
    safe = STESanitizeObservation(raw);
    Check([safe[@"events"][0][@"nodeID"] isEqual:@"en4"] && [safe[@"events"][0][@"objectID"] isEqual:@"ec1"], @"local aliases retained");
    Check([safe[@"events"][0][@"bindingValid"] isEqual:@NO], @"invalid reused binding preserved");
    event[@"nodeID"] = @"player123"; event[@"objectID"] = @"UID";
    Check(!STESanitizeObservation(raw)[@"events"][0][@"nodeID"] && !STESanitizeObservation(raw)[@"events"][0][@"objectID"], @"arbitrary identifiers removed");
    event[@"sideChannelCandidates"] = @[@{@"id":@31, @"slot":@0, @"index":@0, @"type":@1, @"color":@2, @"source":@"selected", @"relation":@"same_response_id_only", @"confidence":@"candidate", @"objectID":@"ec2", @"handObjectID":@"ec1", @"uid":@"PRIVATE"}];
    NSDictionary *candidate = STESanitizeObservation(raw)[@"events"][0][@"sideChannelCandidates"][0];
    Check([candidate[@"confidence"] isEqual:@"candidate"] && !candidate[@"uid"], @"cooccurrence remains candidate, strips identity");
    event[@"sideChannelCandidates"] = @[@{@"id":@31, @"slot":@0, @"index":@0, @"type":@1, @"color":@2, @"source":@"selected", @"relation":@"same_response_id_only", @"confidence":@"confirmed"}];
    Check([STESanitizeObservation(raw)[@"events"][0][@"sideChannelCandidates"] count] == 0, @"unjustified candidate promotion rejected");
    event[@"stage"] = @"eval_payload";
    Check([STESanitizeObservation(raw)[@"events"] count] == 0, @"unknown stage rejected"); event[@"stage"] = @"skin_bg_input";
    [event removeObjectForKey:@"elapsedMs"];
    Check([STESanitizeObservation(raw)[@"events"] count] == 0, @"untimed event rejected"); event[@"elapsedMs"] = @100;
    NSMutableArray *cards = [NSMutableArray array]; for (NSUInteger i=0;i<300;i++) [cards addObject:card]; event[@"cards"] = cards;
    safe = STESanitizeObservation(raw);
    Check([safe[@"events"][0][@"cards"] count] == 256 && [safe[@"events"][0][@"truncated"] boolValue], @"card limit recorded");
    NSMutableArray *events = [NSMutableArray array]; for (NSUInteger i=0;i<100;i++) [events addObject:event]; raw[@"events"] = events;
    safe = STESanitizeObservation(raw);
    Check([safe[@"nativeOmittedEvents"] unsignedIntegerValue] > 0 && STEBoundedJSON(safe,65536), @"large batch bounded with omissions");
    Check(STEDocumentID(@"0123456789abcdef01234567") && !STEDocumentID(@"PRIVATE") && !STEDocumentID(@"0123456789ABCDEFF"), @"document nonce shape strict");
    id deep = @{}; for (NSUInteger i=0;i<14;i++) deep=@{@"next":deep};
    Check(!STEBoundedJSON(deep,65536), @"depth bomb rejected before serialization");
    Check(!STEBoundedJSON(@{@"x":@(INFINITY)},65536), @"nonfinite JSON rejected");
    NSMutableArray *normal = [NSMutableArray array]; for (NSUInteger i=0;i<2000;i++) [normal addObject:@{@"a":@1,@"b":@2,@"c":@3,@"d":@4,@"e":@5,@"f":@6,@"g":@7,@"h":@8}];
    Check(STEBoundedJSON(@{@"events":normal},4*1024*1024)!=nil, @"full report may exceed batch node budget");
    printf("card early sanitizer: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

#import "../Sources/SDKtools/STCardInvestigationSanitizer.inc"
#import "../Sources/SDKtools/STCardFlowSanitizer.inc"
#import "../Sources/SDKtools/STCardFlowBridge.inc"
#include <stdio.h>
static NSUInteger checks, failures;
static void Check(BOOL ok, NSString *why) { checks++; if (!ok) { failures++; fprintf(stderr, "FAIL: %s\n", why.UTF8String); } }
int main(void) { @autoreleasepool {
    NSMutableDictionary *card = [@{@"zone": @"hand", @"index": @0, @"slot": @0, @"objectID": @"fo1", @"id": @64, @"type": @0, @"color": @0, @"num": @0, @"present": @0, @"uid": @"PRIVATE"} mutableCopy];
    NSMutableDictionary *event = [@{@"sequence": @1, @"stage": @"socket_sync_result", @"callID": @1, @"elapsedMs": @10, @"round": @1, @"cards": @[card], @"truncated": @NO, @"secret": @"PRIVATE"} mutableCopy];
    NSMutableDictionary *raw = [@{@"version": @1, @"status": @"ready", @"reason": @"observing", @"started": @YES, @"events": @[event], @"dropped": @0, @"errors": @0, @"queued": @0, @"lastSequence": @1, @"url": @"PRIVATE"} mutableCopy];
    NSDictionary *safe = STWPSanitizeCardFlow(raw), *saved = safe[@"events"][0][@"cards"][0];
    Check([saved[@"color"] isEqual:@0] && [saved[@"present"] isEqual:@15], @"observed zero preserved, presence recomputed");
    Check([saved[@"objectID"] isEqual:@"fo1"], @"local flow alias preserved");
    Check(![[[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:safe options:0 error:nil] encoding:NSUTF8StringEncoding] containsString:@"PRIVATE"], @"private data not forwarded at any level");
    for (id bad in @[@YES, @3, @"1", NSNull.null]) { raw[@"version"] = bad; Check([STWPSanitizeCardFlow(raw)[@"reason"] isEqual:@"invalid_flow_result"], @"strict version type"); }
    raw[@"version"] = @1;
    for (id bad in @[@YES, @(-1), @5, @"3", @(NAN)]) { card[@"color"] = bad; NSDictionary *c = STWPSanitizeCardFlow(raw)[@"events"][0][@"cards"][0]; Check(!c[@"color"] && [c[@"present"] isEqual:@11], @"invalid color omitted, not invented zero"); }
    card[@"color"] = @3; card[@"slot"] = @8;
    Check([STWPSanitizeCardFlow(raw)[@"events"][0][@"cards"] count] == 0, @"invalid hand slot omitted"); card[@"slot"] = @0;
    event[@"stage"] = @"arbitrary PRIVATE";
    Check([STWPSanitizeCardFlow(raw)[@"events"] count] == 0, @"unknown stage omitted"); event[@"stage"] = @"store_input";
    NSMutableArray *many = [NSMutableArray array]; for (NSUInteger i = 0; i < 300; i++) [many addObject:card]; event[@"cards"] = many;
    safe = STWPSanitizeCardFlow(raw); Check([safe[@"events"][0][@"cards"] count] == 256 && [safe[@"events"][0][@"truncated"] boolValue], @"card bound marked");
    NSMutableArray *events = [NSMutableArray array]; for (NSUInteger i = 0; i < 100; i++) [events addObject:event]; raw[@"events"] = events;
    safe = STWPSanitizeCardFlow(raw); Check([safe[@"nativeOmittedEvents"] unsignedIntegerValue] > 0, @"native omissions explicit");
    Check([NSJSONSerialization dataWithJSONObject:safe options:0 error:nil].length <= 65536, @"native serialized byte bound");
    Check([STWPCardFlowSceneScript(@"function(){}", nil) containsString:@"flow_script_missing"], @"resource fallback defined");
    raw[@"version"] = @2; raw[@"events"] = @[event]; event[@"cards"] = @[card]; event[@"stage"] = @"socket_decoded_response";
    raw[@"decoderStatus"] = @"ready"; raw[@"decoderReason"] = @"resolver_boundary"; raw[@"decodedResponses"] = @4; raw[@"decoderMissed"] = @0;
    event[@"observedState"] = @3; event[@"afterGameOver"] = @NO;
    event[@"resultFields"] = @[@{@"path": @"rank_infos", @"presence": @"array", @"count": @0, @"uid": @"PRIVATE"}, @{@"path": @"game_over_rank_infos_cards", @"presence": @"array", @"group": @1, @"count": @7}];
    card[@"zone"] = @"result_rank"; card[@"group"] = @1;
    safe = STWPSanitizeCardFlow(raw); saved = safe[@"events"][0];
    Check([safe[@"version"] isEqual:@2] && [safe[@"decodedResponses"] isEqual:@4], @"version two decoder coverage retained");
    Check([saved[@"stage"] isEqual:@"socket_decoded_response"] && [saved[@"afterGameOver"] isEqual:@NO], @"earlier boundary and phase retained");
    Check([saved[@"resultFields"][0][@"count"] isEqual:@0] && !saved[@"resultFields"][0][@"uid"], @"empty array distinct, private identifiers removed");
    Check([saved[@"cards"][0][@"group"] isEqual:@1], @"result group preserved independently of slot");
    [card removeObjectForKey:@"group"];
    Check([STWPSanitizeCardFlow(raw)[@"events"][0][@"cards"] count] == 0, @"ungrouped result card rejected");
    event[@"resultFields"] = @[@{@"path": @"PRIVATE", @"presence": @"array"}];
    Check([STWPSanitizeCardFlow(raw)[@"events"][0][@"resultFields"] count] == 0, @"unknown result path rejected");
    printf("card flow sanitizer: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures); return failures ? 1 : 0;
} }

#include "../Sources/SDKtools/STBilliardsNumericPolicy.h"
#include <inttypes.h>
#include <stdio.h>
#include <stddef.h>

static unsigned checks, failures;
static void Check(bool condition, const char *label) {
    checks++;
    if (!condition) { failures++; fprintf(stderr,"FAIL %s\n",label); }
}

int main(void) {
    const int64_t signedValid[] = {INT32_MIN,-101,-1,0,1,INT32_MAX};
    for (size_t i=0;i<sizeof(signedValid)/sizeof(*signedValid);i++) {
        int64_t out=77;
        Check(STBLReadSignedInteger(signedValid[i],INT32_MIN,INT32_MAX,&out) &&
              out==signedValid[i],"signed Unity identity preserved");
        out=77;
        Check(STBLReadFloatingInteger((double)signedValid[i],INT32_MIN,INT32_MAX,&out) &&
              out==signedValid[i],"integral floating Unity identity preserved");
    }
    const int64_t signedInvalid[] = {INT64_MIN,(int64_t)INT32_MIN-1,(int64_t)INT32_MAX+1,INT64_MAX};
    for (size_t i=0;i<sizeof(signedInvalid)/sizeof(*signedInvalid);i++) {
        int64_t out=77;
        Check(!STBLReadSignedInteger(signedInvalid[i],INT32_MIN,INT32_MAX,&out) &&
              out==77,"out-of-range signed identity rejected without changing output");
    }
    const uint64_t unsignedInvalid[] = {
        (uint64_t)INT32_MAX+1,UINT32_MAX,(uint64_t)INT64_MAX,
        (uint64_t)INT64_MAX+1,UINT64_MAX,UINT64_MAX-100
    };
    for (size_t i=0;i<sizeof(unsignedInvalid)/sizeof(*unsignedInvalid);i++) {
        int64_t out=77;
        Check(!STBLReadUnsignedInteger(unsignedInvalid[i],INT32_MIN,INT32_MAX,&out) &&
              out==77,"unsigned overflow cannot impersonate negative Unity identity");
    }
    const uint64_t unsignedValid[] = {0,1,20,1003,INT32_MAX};
    for (size_t i=0;i<sizeof(unsignedValid)/sizeof(*unsignedValid);i++) {
        int64_t out=-77;
        Check(STBLReadUnsignedInteger(unsignedValid[i],INT32_MIN,INT32_MAX,&out) &&
              out==(int64_t)unsignedValid[i],"in-range unsigned identity preserved");
    }
    const double floatingInvalid[] = {
        NAN,INFINITY,-INFINITY,1.5,-1.5,
        (double)INT32_MIN-1,(double)INT32_MAX+1,
        nextafter((double)INT32_MIN,-INFINITY),nextafter((double)INT32_MAX,INFINITY),
        0x1p63,-0x1p64,0x1p64
    };
    for (size_t i=0;i<sizeof(floatingInvalid)/sizeof(*floatingInvalid);i++) {
        int64_t out=77;
        Check(!STBLReadFloatingInteger(floatingInvalid[i],INT32_MIN,INT32_MAX,&out) &&
              out==77,"fractional nonfinite or overflowing floating identity rejected");
    }
    int64_t out=77;
    Check(STBLReadSignedInteger(INT64_MIN,INT64_MIN,INT64_MAX,&out) && out==INT64_MIN,"int64 minimum exact");
    Check(STBLReadSignedInteger(INT64_MAX,INT64_MIN,INT64_MAX,&out) && out==INT64_MAX,"int64 maximum exact");
    Check(STBLReadUnsignedInteger(INT64_MAX,INT64_MIN,INT64_MAX,&out) && out==INT64_MAX,"unsigned int64 maximum exact");
    out=77;
    Check(!STBLReadUnsignedInteger((uint64_t)INT64_MAX+1,INT64_MIN,INT64_MAX,&out) && out==77,"unsigned int64 overflow blocked before cast");
    Check(!STBLReadFloatingInteger((double)INT64_MAX,INT64_MIN,INT64_MAX,&out) && out==77,"double-rounded int64 maximum is out of range");
    Check(STBLReadFloatingInteger(-0x1p63,INT64_MIN,INT64_MAX,&out) && out==INT64_MIN,"floating exact int64 minimum accepted");
    Check(STBLReadFloatingInteger(nextafter(0x1p63,0),INT64_MIN,INT64_MAX,&out) &&
          out==INT64_MAX-1023,"largest double below int64 upper boundary accepted");
    out=77;
    Check(!STBLReadFloatingInteger(nextafter(-0x1p63,-INFINITY),INT64_MIN,INT64_MAX,&out) && out==77,"double below int64 minimum rejected");
    Check(!STBLReadUnsignedInteger(0,1,INT32_MAX,&out) && out==77,"positive identity lower bound enforced");
    Check(!STBLReadUnsignedInteger(0,INT32_MIN,-1,&out) && out==77,"unsigned rejected for negative-only interval");
    Check(!STBLReadSignedInteger(0,1,0,&out) && out==77,"invalid signed bounds rejected");
    Check(!STBLReadUnsignedInteger(0,1,0,&out) && out==77,"invalid unsigned bounds rejected");
    Check(!STBLReadFloatingInteger(0,1,0,&out) && out==77,"invalid floating bounds rejected");
    Check(STBLReadSignedInteger(-1,INT32_MIN,INT32_MAX,NULL),"signed null output accepted");
    Check(STBLReadUnsignedInteger(20,20,20,NULL),"unsigned null output accepted");
    Check(STBLReadFloatingInteger(1003,1003,1003,NULL),"floating null output accepted");
    printf("Billiards numeric policy: %u checks, %u failures\n",checks,failures);
    return failures?1:0;
}

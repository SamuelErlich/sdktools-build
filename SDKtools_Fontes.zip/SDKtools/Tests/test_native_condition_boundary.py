"""Catch the exact CI control-condition boundary regression without Apple SDK.

This checks only a narrow grammar error, NOT Objective-C compilation or typing.
Foundation tests execute the production covered coordinator on macOS as well.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
NON_CODE = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|@?"(?:\\[\s\S]|[^"\\])*"|'
                      r"'(?:\\[\s\S]|[^'\\])*'")


def escaped_condition_operators(source):
    code = NON_CODE.sub(lambda m: re.sub(r'[^\n]', ' ', m.group()), source)
    findings = []
    for match in re.finditer(r'\b(?:if|while|switch)\s*\(', code):
        # A preprocessor directive has its own grammar, not a control statement.
        line_start = code.rfind('\n', 0, match.start()) + 1
        if code[line_start:match.start()].lstrip().startswith('#'):
            continue
        depth = 1
        index = match.end()
        while index < len(code) and depth:
            depth += (code[index] == '(') - (code[index] == ')')
            index += 1
        suffix = code[index:].lstrip()
        if depth or suffix.startswith(('&&', '||')):
            findings.append(code.count('\n', 0, match.start()) + 1)
    return findings


class NativeConditionBoundaryTests(unittest.TestCase):
    def test_exact_ci_failure_is_rejected_but_valid_nested_conditions_are_not(self):
        broken = ('if (!self.coveredAttemptPending || self.coveredAttemptContextLost) '
                  '&& (!self.autoplayFastPending || self.autoplayFastContextLost) return;')
        self.assertEqual(escaped_condition_operators(broken), [1])
        self.assertEqual(escaped_condition_operators('if (a)\n || b return;'), [1])
        self.assertEqual(escaped_condition_operators('if (a && (b || f(c))) return;'), [])
        self.assertEqual(escaped_condition_operators('if (a) return b && c;'), [])
        self.assertEqual(escaped_condition_operators('// if (a) && b\n@"if (a) && b";'), [])
        self.assertEqual(escaped_condition_operators('#if (A) && (B)\n#endif'), [])

    def test_native_sources_do_not_continue_condition_after_closing_parenthesis(self):
        paths = sorted(p for p in (ROOT/'Sources').rglob('*') if p.suffix in {'.h','.m','.inc'})
        self.assertGreater(len(paths), 20)
        findings = [f'{p.relative_to(ROOT)}:{line}' for p in paths
                    for line in escaped_condition_operators(p.read_text(encoding='utf-8'))]
        self.assertEqual(findings, [])

    def test_covered_loss_method_has_no_dependency_on_fast_latch(self):
        source = (ROOT/'Sources/SDKtools/STAutoplayRecorder.inc').read_text(encoding='utf-8')
        method = source.split('- (void)markCoveredContextLost {',1)[1].split('\n}',1)[0]
        self.assertNotIn('autoplayFast', method)
        self.assertIn('self.coveredAttemptPending', method)
        self.assertIn('self.coveredAttemptContextLost', method)


if __name__ == '__main__':
    unittest.main()

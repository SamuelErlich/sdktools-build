/* Production adapter + controller + exact core integration. All Cocos controls,
 * original events and protocol peers below are explicit synthetic fixtures.
 * No recovered client module is evaluated and no network/device is contacted. */
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const suite=path.join(__dirname,'autoplay_tool.test.cjs');
const fixtureContext=vm.createContext({require:name=>name==='node:test'?()=>{}:require(name),
  __dirname,console});
vm.runInContext(fs.readFileSync(suite,'utf8')+
  '\nObject.assign(globalThis,{makeFixture,attachLiveStore,setup,move,removeCards,powerFixture});',
  fixtureContext,{timeout:5000});
const fixtures=fixtureContext;
const options={requirePhaseSnapshot:true,cooperativePlanning:true,powersEnabled:false,
  cardsPerBatch:1,superFastEnabled:false,xrayEnabled:false};

function recomputeGeometry(p){
  const cards=p.f.cards.filter(c=>c.node.parent===p.f.board);
  for(const card of cards){const a=card.receiver.blockInfo,blocked=cards.some(other=>{
    const b=other.receiver.blockInfo;return b.layer>a.layer&&Math.abs(b.row-a.row)<16&&Math.abs(b.col-a.col)<20;
  });
    card.mask.active=card.mask.activeInHierarchy=blocked;
    card.receiver.canTouch=!blocked;card.button.interactable=!blocked;
  }
  p.f.tray.children.forEach((n,i)=>{n.x=-240+80*i;n.y=0;});
  for(const [field,container]of[['pile_blocks',p.f.board],['hand_blocks',p.f.tray],['storage_blocks',p.f.reserve]])
    p.m.store[field]=container.children.map(n=>({...p.f.cards.find(c=>c.node===n).receiver.blockInfo}));
}
function create(records){
  const f=fixtures.makeFixture(records),m=fixtures.attachLiveStore(f);
  Object.assign(m.store,{mode:1,total_num:f.cards.length,props_blocks:[],common_blocks:[],task_info:null});
  const socket={uid:10,rid:20,socket:{readyState:1},responseMap:{}};
  f.loader=name=>({default:name==='GameStore'?m.store:name==='Socket'?socket:null});
  const p={f,m,socket};recomputeGeometry(p);
  p.rt=fixtures.setup(f,{globalFactory:true,phaseFactory:true,coveredFactory:true});return p;
}
function exposed(type,i){return {zone:'board',type,x:-160+160*i,y:0,layer:0};}
function ticks(p,n=20,opts=options){let r;for(let i=0;i<n;i++){p.rt.advance(100);r=p.rt.tick(opts);}return r;}
function until(p,accept,opts=options,limit=500){
  let r;for(let i=0;i<limit;i++){p.rt.advance(100);r=p.rt.tick(opts);if(accept(r))return r;}
  assert.fail('expected state was not reached: '+JSON.stringify(r));
}
function dispatched(p,opts=options){return until(p,r=>r.dispatched===true,opts);}
function applyPick(p,call){
  const card=p.f.cards.find(c=>c.event===call.event);assert.ok(card,'registered original event identifies its own component');
  assert.ok(card.node.parent===p.f.board||card.node.parent===p.f.reserve,'a dispatched identity is not replayed');
  assert.equal(card.receiver.canTouch,true,'ordinary original event cannot select a covered card');
  assert.equal(card.mask.active,false);
  const old=p.f.tray.children.slice(),type=card.receiver.blockInfo.type;let at=old.length;
  for(let i=0;i<old.length;i++){
    const a=p.f.cards.find(c=>c.node===old[i]).receiver.blockInfo.type;
    const b=i+1<old.length?p.f.cards.find(c=>c.node===old[i+1]).receiver.blockInfo.type:null;
    if(i+1===old.length){at=i+1;break;}if(a===type&&b!==type){at=i+1;break;}
  }
  fixtures.move(p.f,card,p.f.tray);
  p.f.tray.children.splice(p.f.tray.children.indexOf(card.node),1);
  p.f.tray.children.splice(at,0,card.node);
  const trio=p.f.cards.filter(c=>c.node.parent===p.f.tray&&c.receiver.blockInfo.type===type);
  assert.ok(p.f.tray.children.length<=7);
  if(trio.length===3)fixtures.removeCards(p.f,trio);
  assert.ok(p.f.tray.children.length<7,'a nonmatching seventh card is not progress');
  recomputeGeometry(p);return card;
}
function trap18(){
  const tuples=[['D',0,24,32],['A',0,12,0],['B',0,48,32],['F',0,0,0],['F',1,0,32],['D',1,12,0],
    ['C',1,36,32],['C',1,0,0],['F',2,24,32],['E',2,12,0],['A',2,48,32],['E',2,24,0],
    ['C',3,12,32],['A',3,12,0],['B',3,48,32],['E',3,36,0],['B',4,0,32],['D',4,36,0]];
  return create(tuples.map(([type,layer,row,col])=>({zone:'board',type,layer,x:5*row-240,y:315-4.5*col})));
}

test('production SOLO plans the entire geometric trap before any original event',()=>{
  const p=trap18();let sawSearching=false;
  const r=until(p,result=>{
    if(result.globalPlan?.status==='searching'){
      sawSearching=true;assert.equal(result.dispatched,false);assert.equal(p.f.calls.length,0);
      assert.equal(result.globalPlan.complete,false);
    }
    return result.dispatched;
  });
  assert.equal(sawSearching,true,'real bounded core must suspend without executing a speculative prefix');
  assert.equal(r.globalPlan.complete,true,JSON.stringify(r));assert.equal(r.globalPlan.plannedCleared,18);
  assert.equal(r.globalPlan.remaining,0);assert.equal(r.globalPlan.scope,'current_phase');
  assert.equal(p.f.calls.length,1);assert.equal(p.f.calls[0].event.handler,'touchBlock');
  assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);
});

test('all 18 original events follow revalidated complete routes and stable exact effects',()=>{
  const p=trap18(),picked=[];
  for(let n=0;n<18;n++){
    const r=dispatched(p);assert.equal(p.f.calls.length,n+1,'one physical action at a time');
    assert.equal(r.globalPlan.complete,true,'each emitted card belongs to a full known-board continuation');
    assert.equal(r.confirmedMoves,n);assert.equal(r.awaitingBoardChange,true);
    const held=ticks(p,3);assert.equal(held.awaitingBoardChange,true);assert.equal(p.f.calls.length,n+1,'no retry before observed effect');
    picked.push(p.f.cards.indexOf(applyPick(p,p.f.calls[n])));
    const confirmed=until(p,s=>s.reason==='board_change_confirmed');
    assert.equal(confirmed.confirmedMoves,n+1);assert.equal(p.f.calls.length,n+1);
  }
  assert.notDeepEqual(picked.slice(0,5),[13,9,17,15,11],'known losing local-first-trio prefix must not be emitted');
  assert.equal(p.f.board.children.length,0);assert.equal(p.f.tray.children.length,0);
  const done=ticks(p,5);assert.equal(done.reason,'board_clear');assert.equal(done.dispatched,false);
  assert.equal(p.f.calls.length,18);assert.equal(done.confirmedMoves,18);
});

test('SOLO without a useful trio never waits for an unavailable teammate warehouse',()=>{
  const p=create([exposed('A',0)]),r=ticks(p,15);
  assert.equal(r.phaseSnapshotSummary.complete,true,JSON.stringify(r));
  assert.notEqual(r.reason,'waiting_supply');assert.equal(r.dispatched,false);
  assert.equal(r.globalPlan.status,'blocked');assert.equal(p.f.calls.length,0);
});

test('a freshly changed face invalidates an already prepared whole-board certificate',()=>{
  const p=create(['A','A','A'].map(exposed));
  const planned=until(p,r=>r.reason==='plan_ready');assert.equal(planned.globalPlan.complete,true);
  assert.equal(p.f.calls.length,0);
  p.f.cards[2].receiver.blockInfo.type=2;recomputeGeometry(p);
  const r=ticks(p,20);assert.equal(r.dispatched,false);assert.equal(p.f.calls.length,0);
  assert.equal(r.globalPlan.complete,false);assert.notEqual(r.reason,'waiting_supply');
});

test('SOLO-to-team transition never displays the old whole-board SOLO proof',()=>{
  const p=create(['A','A','A'].map(exposed));
  const proved=until(p,r=>r.reason==='plan_ready');assert.equal(proved.globalPlan.complete,true);
  assert.equal(proved.globalPlan.plannedCleared,3);assert.equal(p.f.calls.length,0);
  p.m.store.mode=0;
  for(let i=0;i<12;i++){
    p.rt.advance(100);const current=p.rt.tick({...options,allowAction:false});
    assert.equal(current.globalPlan,undefined,'team HUD must not inherit a SOLO100% certificate');
    assert.equal(current.dispatched,false);assert.equal(p.f.calls.length,0);
  }
});

test('incomplete Store/scene census hides a previously proved100% route immediately',()=>{
  const p=create(['A','A','A'].map(exposed));
  const proved=until(p,r=>r.reason==='plan_ready');assert.equal(proved.globalPlan.complete,true);
  assert.equal(proved.globalPlan.remaining,0);assert.equal(p.f.calls.length,0);
  p.m.store.pile_blocks.push({...p.m.store.pile_blocks[0],id:'not-yet-rendered-server-card'});
  for(let i=0;i<12;i++){
    p.rt.advance(100);const current=p.rt.tick(options);
    assert.equal(current.phaseSnapshotSummary.complete,false);
    assert.equal(current.globalPlan,undefined,'old100% must disappear before a fresh full census can be acquired');
    assert.equal(current.dispatched,false);assert.equal(p.f.calls.length,0);
  }
  recomputeGeometry(p);p.rt.advance(100);
  const reacquiring=p.rt.tick(options);
  assert.equal(reacquiring.globalPlan,undefined,'restoring data still requires the fresh phase stability window');
  assert.equal(reacquiring.dispatched,false);
});

for(const [name,mutate]of[
  ['unknown special',p=>{p.f.cards[0].receiver.blockInfo.special_info={type:73,lock_state:0};recomputeGeometry(p);}],
  ['uncensused Store card',p=>{p.m.store.pile_blocks.push({...p.m.store.pile_blocks[0],id:'extra-server-card'});}],
  ['stale Store type',p=>{p.m.store.pile_blocks[0].type=99;}],
  ['missing Store array',p=>{delete p.m.store.pile_blocks;}],
  ['duplicate stock type',p=>{p.m.store.props_blocks=[{id:'3-10',type:3,count:1},{id:'other',type:3,count:1}];}],
  ['external mode',p=>{p.m.store.isUsingPenetrateProp=true;}]
])test('full production chain fails closed for '+name,()=>{
  const p=create(['A','A','A'].map(exposed));mutate(p);const r=ticks(p,20);
  assert.equal(r.dispatched,false);assert.equal(p.f.calls.length,0);assert.notEqual(r.reason,'waiting_supply');
  assert.notEqual(r.globalPlan?.complete,true);
});

test('read-only observation never emits a card despite a provable full route',()=>{
  const p=trap18(),r=ticks(p,30,{...options,allowAction:false});
  assert.equal(r.dispatched,false);assert.equal(p.f.calls.length,0);assert.equal(r.reason,'action_disabled');
});

test('phase-wide census is not falsely equated with the server cumulative total_num',()=>{
  const p=create(['A','A','A'].map(exposed));p.m.store.total_num=999;
  const r=dispatched(p);assert.equal(r.phaseSnapshotSummary.complete,true);
  assert.equal(r.globalPlan.totalCards,3);assert.equal(r.globalPlan.scope,'current_phase');
  assert.equal(r.globalPlan.complete,true);assert.equal(r.globalPlan.plannedCleared,3);
});

function powerBoard(){
  const p=fixtures.powerFixture({counts:[0,0,0],boardTypes:['A','B','C','X','X','X'],handTypes:['A','A','B','B','C','C']});
  const coordinates=[[0,45,70],[0,48,70],[0,51,70],[1,48,70],[1,16,70],[1,80,70]];
  p.f.cards.slice(0,6).forEach((c,i)=>{const [layer,row,col]=coordinates[i];
    Object.assign(c.receiver.blockInfo,{id:`${layer}-${row}-${col}`,layer,row,col});
    c.node.x=5*row-240;c.node.y=315-4.5*col;
  });
  const stock={id:'3-7',type:3,count:1};p.m.store.props_blocks.push(stock);
  Object.assign(p.m.store,{mode:1,total_num:12,common_blocks:[],task_info:null});
  recomputeGeometry(p);const wire=[],listeners=new Map();
  const ws={readyState:1,url:'wss://fixture.invalid/ws',send(raw){wire.push(JSON.parse(raw));},
    addEventListener(name,fn){if(!listeners.has(name))listeners.set(name,new Set());listeners.get(name).add(fn);},
    removeEventListener(name,fn){listeners.get(name)?.delete(fn);}};
  Object.assign(p.socket,{socket:ws,packetId:1,responseMap:{},async send(command,param={}){
    param.uid=this.uid;param.rid=this.rid;return new Promise((resolve,reject)=>{
      this.responseMap[this.packetId]={resolve,reject};
      this.socket.send(JSON.stringify({packet_id:this.packetId,command,param}));this.packetId++;
    });
  },UseProp(id,target){return this.send('CMD_USE_PROP',{prop_id:id,block_id:target});},onMessage(event){
    const data=JSON.parse(event.data),entry=this.responseMap[data.packet_id];
    if(entry)(data.code===200?entry.resolve:entry.reject)(data.data);
  }});
  p.rt=fixtures.setup(p.f,{globalFactory:true,phaseFactory:true,coveredFactory:true});
  return {...p,stock,wire,reply(code=200){
    const event={isTrusted:true,target:ws,data:JSON.stringify({packet_id:1,code,data:{}})};
    p.socket.onMessage(event);for(const fn of [...(listeners.get('message')||[])])fn(event);
  },consume(){
    assert.equal(wire.length,1);const target=p.f.cards.find(c=>c.receiver.blockInfo.id===wire[0].param.block_id);
    assert.ok(target);const pair=p.f.cards.filter(c=>c.node.parent===p.f.tray&&c.receiver.blockInfo.type===target.receiver.blockInfo.type);
    assert.equal(pair.length,2);stock.count--;fixtures.removeCards(p.f,pair.concat(target));recomputeGeometry(p);
  }};
}
async function flush(){for(let i=0;i<8;i++)await Promise.resolve();}
test('Powers OFF cannot spend even a unit that would unlock an exact full solution',()=>{
  const p=powerBoard(),r=ticks(p,30);
  assert.equal(p.stock.count,1);assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0);
  assert.equal(r.dispatched,false);assert.equal(r.globalPlan.complete,false);assert.notEqual(r.reason,'waiting_supply');
});
test('SOLO cannot fall back to uncertified Storage, Shuffle, Bomb or Remove rescue',()=>{
  const p=powerBoard();p.stock.count=0;
  p.infos[0].count=p.props[0].num=1;p.infos[2].count=p.props[2].num=1;
  p.m.store.props_blocks.push({id:'4-7',type:4,count:2},{id:'5-7',type:5,count:1});
  const before=JSON.stringify(p.m.store.props_blocks),r=ticks(p,30,{...options,powersEnabled:true});
  assert.equal(r.phaseSnapshotSummary.complete,true,JSON.stringify(r));assert.equal(r.globalPlan.complete,false);
  assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0,'no legacy popup or card event may escape the global certificate');
  assert.equal(JSON.stringify(p.m.store.props_blocks),before);assert.notEqual(r.reason,'waiting_supply');
});
test('pause and preference invalidation cannot release an uncertain physical original action',()=>{
  const p=create(['A','A','A'].map(exposed));dispatched(p);assert.equal(p.f.calls.length,1);
  p.rt.tick({...options,powersEnabled:true,resumeGeneration:2});p.rt.tick({command:'pause'});
  p.rt.advance(16000);const held=p.rt.tick({...options,allowAction:false,resumeGeneration:3});
  assert.equal(held.awaitingBoardChange,true);assert.equal(held.confirmedMoves,0);assert.equal(p.f.calls.length,1);
  applyPick(p,p.f.calls[0]);const done=until(p,r=>r.reason==='board_change_confirmed',
    {...options,allowAction:false,resumeGeneration:3});
  assert.equal(done.confirmedMoves,1);assert.equal(done.awaitingBoardChange,false);assert.equal(p.f.calls.length,1);
});
test('owned Penetrate optimistic effect without its original ACK remains latched and is never resent',()=>{
  const p=powerBoard(),opts={...options,powersEnabled:true};dispatched(p,opts);p.consume();
  let r=ticks(p,10,opts);assert.equal(r.awaitingBoardChange,true);assert.equal(r.powers.confirmed,0);
  p.rt.advance(16000);r=p.rt.tick({...opts,allowAction:false});
  assert.equal(r.awaitingBoardChange,true);assert.equal(r.powers.confirmed,0);assert.equal(p.wire.length,1);
  assert.equal(p.f.calls.length,0);assert.equal(p.stock.count,0);
});
test('full-phase owned Penetrate dispatch waits for ACK, Promise, stock and the exact trio effect',async()=>{
  const p=powerBoard(),opts={...options,powersEnabled:true},first=dispatched(p,opts);
  assert.equal(first.reason,'power_requested');assert.equal(first.globalPlan.complete,true,JSON.stringify(first));
  assert.equal(first.globalPlan.totalCards,12);assert.equal(first.globalPlan.powerUses,1);
  assert.equal(p.wire.length,1);assert.equal(p.wire[0].command,'CMD_USE_PROP');assert.equal(p.wire[0].param.prop_id,'3-7');
  assert.equal(p.f.calls.length,0,'no synthetic covered normal callback');assert.equal(p.stock.count,1);
  p.reply();await flush();let held=ticks(p,5,opts);
  assert.equal(held.awaitingBoardChange,true);assert.equal(held.powers.confirmed,0);assert.equal(p.wire.length,1);
  p.consume();const confirmed=until(p,r=>r.reason==='power_effect_confirmed',opts);
  assert.equal(confirmed.powers.confirmed,1);assert.equal(confirmed.awaitingBoardChange,false);assert.equal(p.stock.count,0);
  for(let i=0;i<5;i++){
    const r=dispatched(p,opts);assert.equal(r.globalPlan.complete,true,JSON.stringify(r));
    assert.equal(p.f.calls.length,i+1);applyPick(p,p.f.calls[i]);
    until(p,r=>r.reason==='board_change_confirmed',opts);
  }
  assert.equal(p.f.board.children.length,0);assert.equal(p.f.tray.children.length,0);
  assert.equal(p.wire.length,1);assert.equal(ticks(p,5,opts).reason,'board_clear');
});


const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const read=n=>fs.readFileSync(path.join(__dirname,'../Resources',n),'utf8');
const fastFactory=vm.runInNewContext(read('alpaca_fast.js'));
const coopFactory=vm.runInNewContext(read('autoplay_coop.js'));
function fixture(types=['a','a','a','b','b','b']){
 const cards=types.map((type,i)=>({id:'c'+i,rawID:'raw'+i,type,zone:'board',available:true,masked:false,selectable:true,order:i,metadata:{specialType:0},blockedBy:[]}));
 return {capacity:7,cards,tray:[],refs:new Map(cards.map(c=>[c.id,c])),missionKey:'fixture'};
}
for(const types of [['a','a','a','b','b','b'],Array(6).fill('a')])test('six mode proves two full exposed trios, without changing cards or tray: '+types.join(''),()=>{
 const s=fixture(types),before=JSON.stringify(s),fast=fastFactory(),route=fast.plan(s,null,6);
 assert.equal(route?.proofKind,'two_trios');assert.equal(route.sequence.length,6);
 assert.equal(fast.prefix(s,route.sequence.map(id=>s.refs.get(id)),6).length,6);
 const proof=coopFactory(()=>null).validateRoute(s,route,true);
 assert.equal(proof?.sequence.length,6);assert.equal(JSON.stringify(s),before);
 assert.equal(fast.prefix(s,route.sequence.map(id=>s.refs.get(id)),3).length,0);
});
for(const [name,mutate] of [
 ['occupied tray',s=>s.tray.push({id:'t',type:'z'})],
 ['missing second trio',s=>s.cards[5].type='z'],
 ['covered card',s=>{s.cards[5].blockedBy=['c0'];s.cards[5].available=false;}],
 ['masked card',s=>s.cards[5].masked=true],
 ['locked card',s=>s.cards[5].selectable=false],
 ['special card',s=>s.cards[5].metadata.specialType=1],
 ['duplicate original ID',s=>s.cards[5].rawID=s.cards[4].rawID],
 ['wrong capacity',s=>s.capacity=8]
])test('six route and independent proof refuse '+name,()=>{
 const s=fixture(),fast=fastFactory(),route={proofKind:'two_trios',sequence:s.cards.map(c=>c.id),tripleCardIDs:['c0','c1','c2'],matchedType:'a',missionKey:s.missionKey};mutate(s);
 assert.equal(fast.prefix(s,s.cards,6).length,0);assert.equal(coopFactory(()=>null).validateRoute(s,route,true),null);
 const candidate=fast.plan(s,null,6);assert.notEqual(candidate?.proofKind,'two_trios');
});
test('six mode falls back to existing trio proof when only a smaller safe route is available',()=>{
 const s=fixture(['a','a','a','b','b']),route=fastFactory().plan(s,null,6);
 assert.equal(route.proofKind,'local_trio');assert.equal(route.sequence.length,3);
});

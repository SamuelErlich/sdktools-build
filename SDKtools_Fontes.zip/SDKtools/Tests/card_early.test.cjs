'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {fixture}=require('./card_early_fixture.cjs');

test('hello is immediate without engine, scene or cards and observer installs at loader assignment',async()=>{
  const f=fixture({noEngine:true});assert.equal(f.messages[0].kind,'hello');assert.equal(f.messages[0].documentID.length,24);assert.equal(f.loads.length,0);
  f.context.cc=f.cc;await f.load();assert.equal(f.snapshot().status,'ready');assert.equal(f.requests.length,0);assert.equal(f.snapshot().milestones.beforeSocket,true);assert.equal(f.snapshot().milestones.beforeScene,true);assert.equal(f.snapshot().milestones.beforeFirstSync,true);assert.deepEqual(f.loads,['Card','HandArea','game','GameStore','Socket','CardSkinManager']);f.runtime.stop();
});
test('first sync is observed at resolver before Store receives it, bound onMessage calls wrapped original',async()=>{
  const f=fixture();await f.load();await f.scene();f.socket.establish();const p=f.socket.sync();const value={gamers:[{uid:'SECRET-UID',cards:[{id:12,type:0,color:0,num:0}]}]};f.deliver(value);const resolved=await p;assert.equal(resolved.gamers[0].cards[0].id,12);f.store.sync(resolved);
  const events=await f.drain();const decoded=events.find(e=>e.stage==='socket_decoded_response');assert.equal(decoded.cards[0].id,12);assert.equal(decoded.command,'CMD_SYNC');assert.equal(decoded.connectionGeneration,1);assert.ok(events.find(e=>e.stage==='onmessage_entry'));assert.ok(events.find(e=>e.stage==='before_scene'));assert.ok(decoded.sequence<events.find(e=>e.stage==='store_input').sequence);assert.equal(f.snapshot().milestones.hasInitialSync,true);assert.ok(!JSON.stringify(f.messages).includes('SECRET'));f.runtime.stop();
});
test('original promise, arguments, this, result and thrown identity are preserved',async()=>{
  const error={code:'original'};let actualThis,actualArgs;
  const f=fixture({beforeStart({Card}){Card.prototype.setup=function(){actualThis=this;actualArgs=arguments;throw error;};}});await f.load();
  const p=f.socket.send('CMD_PLAY_CARD',{private:true});assert.equal(p,f.requests[0].promise);f.deliver({cards:[]});await p;
  const card=new f.Card(),data={id:1};assert.throws(()=>card.setup(data,9),x=>x===error);assert.equal(actualThis,card);assert.equal(actualArgs[0],data);assert.equal(actualArgs[1],9);f.runtime.stop();
});
test('wrong engine and absent class registry never load exports',async()=>{
  const wrong=fixture({engine:'3.8.0'});await wrong.load();assert.equal(wrong.loads.length,0);assert.equal(wrong.snapshot().reason,'unsupported_engine');assert.equal(wrong.timerCount(),0);
  const missing=fixture({beforeStart({cc}){delete cc.js;}});await missing.load();assert.equal(missing.loads.length,0);assert.ok(missing.snapshot().gaps.includes('missing_module_registry'));missing.runtime.stop();
});
test('existing accessor is never executed or replaced',async()=>{
  let reads=0;const getter=()=>{reads++;throw Error('no');};const f=fixture({accessor:getter});await f.flush();assert.equal(reads,0);assert.equal(Object.getOwnPropertyDescriptor(f.context,'__require').get,getter);assert.equal(f.snapshot().reason,'loader_accessor');
});
test('late attach reports incomplete startup and keeps existing bound callback intact',async()=>{
  let oldCallback;const f=fixture({late:true,connected:true,beforeStart({socket}){oldCallback=socket.socket.onmessage;}});await f.flush();assert.equal(f.socket.socket.onmessage,oldCallback);assert.equal(f.snapshot().milestones.lateAttach,true);assert.equal(f.snapshot().milestones.beforeFirstSync,false);assert.ok(f.snapshot().gaps.includes('preexisting_socket'));
  const p=f.socket.sync();f.deliver({cards:[{id:2,type:1,color:4,num:1}]});await p;const events=await f.drain();assert.ok(events.some(e=>e.stage==='socket_decoded_response'));assert.ok(!events.some(e=>e.stage==='onmessage_entry'));assert.equal(f.snapshot().milestones.hasInitialSync,false);f.runtime.stop();
});
test('reconnection and registered push replacement preserve callback behavior',async()=>{
  const f=fixture();await f.load();f.socket.establish();f.socket.establish();let called=0;function push(event,value){called++;value.cards[0].color=0;return 41;}
  assert.equal(f.socket.resisterPushHandler(push),17);const value={cards:[{id:9,type:1,color:3,num:2}]};assert.equal(f.socket.pushHandler(5,value),41);
  const event=(await f.drain()).find(e=>e.stage==='push_input');assert.equal(event.cards[0].color,3);assert.equal(event.connectionGeneration,2);assert.equal(called,1);assert.equal(f.snapshot().status,'ready');f.runtime.stop();assert.equal(f.socket.pushHandler,push);
});
test('stopping restores owned methods and assigned loader, never a later replacement',async()=>{
  const f=fixture();const old=f.socket.sync,cardSetup=f.Card.prototype.setup;await f.load();const loader=f.context.__require;
  const replacement=function(){return 'new';};f.socket.sync=replacement;f.runtime.stop();assert.equal(f.socket.sync,replacement);assert.equal(f.Card.prototype.setup,cardSetup);assert.equal(f.context.__require,loader);assert.equal(typeof Object.getOwnPropertyDescriptor(f.context,'__require').value,'function');assert.equal(f.timerCount(),0);assert.notEqual(f.socket.sync,old);
});
test('method replacement ends collection with coverage reason',async()=>{
  const f=fixture();await f.load();f.socket.onMessage=function(){};await f.advance();assert.equal(f.snapshot().reason,'method_replaced');assert.equal(f.timerCount(),0);
});
test('in-place handler mutation cannot change an already captured color',async()=>{
  const f=fixture({beforeStart({store}){store.sync=function(value){value.gamers[0].cards[0].color=0;this.gamers=value.gamers;return value;};}});await f.load();
  const value={gamers:[{uid:'do-not-export',cards:[{id:3,type:1,color:4,num:8}]}]};f.store.sync(value);const events=await f.drain();assert.equal(events.find(e=>e.stage==='store_input').cards[0].color,4);assert.equal(events.find(e=>e.stage==='store_after').cards[0].color,0);f.runtime.stop();
});
test('asynchronous skin completion marks reused nodes stale and retains original arguments',async()=>{
  const f=fixture({asyncSkin:true});await f.load();const component=new f.Card();const a={id:7,type:1,color:2,num:3},b={id:8,type:1,color:4,num:6};component.setup(a);component.setup(b);f.deferred[0]();await f.flush();
  const events=await f.drain(),done=events.find(e=>e.stage==='skin_bg_complete');assert.equal(done.cards[0].id,7);assert.equal(done.cards[0].color,2);assert.equal(done.bindingGeneration,1);assert.equal(done.bindingValid,false);assert.equal(done.cards[0].objectID,events.find(e=>e.stage==='card_setup_input').cards[0].objectID);assert.equal(f.snapshot().counters.staleBindings,1);f.runtime.stop();
});
test('async same object mutation also invalidates binding',async()=>{
  const f=fixture({asyncSkin:true});await f.load();const card={id:7,type:1,color:2,num:3},component=new f.Card();component.setup(card);card.color=3;f.deferred[0]();await f.flush();const e=(await f.drain()).find(e=>e.stage==='skin_bg_complete');assert.equal(e.bindingValid,false);assert.equal(e.cards[0].color,2);f.runtime.stop();
});
test('selected side field produces only same-response candidate without upgrading masked card',async()=>{
  const f=fixture();await f.load();f.socket.establish();const p=f.socket.sync();f.deliver({state:2,gamers:[{uid:'SECRET',cards:[{id:69,type:0,color:0,num:0}]}],select_give_card:{id:69,type:1,color:1,num:7}});await p;
  const e=(await f.drain()).find(e=>e.stage==='socket_decoded_response');assert.equal(e.cards.find(c=>c.zone==='hand').colorState,'unknown');assert.equal(e.sideChannelCandidates.length,1);assert.equal(e.sideChannelCandidates[0].confidence,'candidate');assert.notEqual(e.sideChannelCandidates[0].objectID,e.sideChannelCandidates[0].handObjectID);f.runtime.stop();
});
test('duplicate hand IDs and missing current payload never produce a candidate',async()=>{
  const f=fixture();await f.load();f.store.gamers=[{uid:'A',cards:[{id:65,type:0,color:0,num:0}]}];f.store.sync({gamers:[{cards:[{id:65,type:0,color:0},{id:65,type:1,color:2}]}],select_give_card:{id:65,type:1,color:1,num:8}});f.store.updatePushMessage({select_give_card:{id:65,type:1,color:1,num:8}});const events=await f.drain();assert.ok(events.every(e=>e.sideChannelCandidates.length===0));f.runtime.stop();
});
test('special/unknown/candidate classes remain distinct and turn color is separate',async()=>{
  const f=fixture();await f.load();f.socket.resisterPushHandler(()=>{});f.socket.pushHandler(6,{color:4,cards:[{type:0,color:0},{type:0,color:3},{type:4,color:0},{color:2}]});const e=(await f.drain()).find(e=>e.stage==='push_input');assert.equal(e.selectedColor,4);assert.deepEqual(e.cards.map(c=>c.colorState),['unknown','candidate','special','candidate']);f.runtime.stop();
});
test('truncation and privacy budgets are enforced on huge nested penalties',async()=>{
  const f=fixture();await f.load();f.socket.resisterPushHandler(()=>{});f.socket.pushHandler(7,{secret:'PRIVATE',punish_list:Array.from({length:100},()=>({uid:'PRIVATE',cards:Array.from({length:1000},(_,id)=>({id,type:1,color:3,num:7,secret:'PRIVATE'}))}))});
  const e=(await f.drain()).find(e=>e.stage==='push_input');assert.equal(e.truncated,true);assert.ok(e.cards.length<=256);assert.ok(JSON.stringify(e).length<=32768);assert.ok(f.messages.every(m=>JSON.stringify(m).length<=65536));assert.ok(!JSON.stringify(f.messages).includes('PRIVATE'));f.runtime.stop();
});
test('lease timeout, denied reply, visibility and pagehide restore observers',async()=>{
  const timeout=fixture({hangBridge:true});await timeout.load();await timeout.advance(3000);assert.equal(timeout.snapshot().reason,'bridge_timeout');assert.equal(timeout.timerCount(),0);
  const denied=fixture({active:false});await denied.flush();assert.equal(denied.snapshot().reason,'bridge_rejected');assert.equal(denied.timerCount(),0);
  const hidden=fixture();await hidden.load();hidden.document.hidden=true;hidden.emit('doc:visibilitychange');assert.equal(hidden.snapshot().reason,'hidden_document');
  const page=fixture();await page.load();page.emit('pagehide');assert.equal(page.snapshot().reason,'pagehide');
});
test('capture lasts at most ninety seconds with accepted heartbeats and ends cleanly',async()=>{
  const f=fixture();await f.load();for(let t=0;t<90000;t+=1000)await f.advance(1000);assert.equal(f.snapshot().reason,'duration_limit');assert.equal(f.timerCount(),0);assert.equal(f.messages.at(-1).kind,'end');assert.ok(f.messages.at(-1).observation.elapsedMs>=90000);
});
test('subframes do not send hello, install loader accessor, or timers',()=>{
  const f=fixture({subframe:true});assert.equal(f.messages.length,0);assert.equal(f.timerCount(),0);assert.equal(Object.getOwnPropertyDescriptor(f.context,'__require'),undefined);
});

test('unacknowledged shared-controller document never calls loader or patches game methods',async()=>{
  const f=fixture({hangBridge:true});const original=f.socket.onMessage;await f.load();assert.equal(f.loads.length,0);assert.equal(f.socket.onMessage,original);assert.equal(f.snapshot().milestones.modulesReady,false);f.runtime.stop();
});
test('event limit ends instrumentation and exports an honest dropped count',async()=>{
  const f=fixture();await f.load();for(let i=0;i<2200;i++)f.store.updatePushMessage({cards:[{id:i%100,type:0,color:0,num:0}]});await f.flush();const snapshot=f.snapshot();assert.equal(snapshot.reason,'event_limit');assert.equal(snapshot.counters.totalEvents,4096);assert.ok(snapshot.counters.dropped>0);assert.equal(f.timerCount(),0);assert.ok(snapshot.counters.totalBytes<=4194304);assert.ok(f.messages.every(m=>JSON.stringify(m).length<=65536));
});
test('byte limit is enforced before unbounded payload retention',async()=>{
  const f=fixture();await f.load();f.socket.resisterPushHandler(()=>{});const payload={cards:Array.from({length:256},(_,id)=>({id,type:1,color:3,num:7}))};
  for(let i=0;i<300&&f.snapshot().status!=='stopped';i++){f.socket.pushHandler(5,payload);await f.advance(250);}
  const s=f.snapshot();assert.equal(s.reason,'byte_limit');assert.ok(s.counters.totalBytes<=4194304);assert.ok(s.counters.totalEvents<4096);assert.ok(f.messages.every(m=>JSON.stringify(m).length<=65536));
});
test('non-gameplay replies and arbitrary callback errors never export private fields',async()=>{
  const f=fixture();await f.load();f.socket.establish();for(const command of ['CMD_REGISTER','CMD_QUICK_TEXT','CMD_HEART_BEAT']){const p=f.socket.send(command);f.deliver({secret:'SECRET',cards:[{id:3,type:1,color:4}]});await p;}
  const events=await f.drain();assert.ok(!events.some(e=>e.stage==='socket_decoded_response'));assert.ok(!JSON.stringify(f.messages).includes('SECRET'));f.runtime.stop();
});
test('second successful sync cannot masquerade as the missing first sync',async()=>{
  const f=fixture({beforeStart({socket}){const send=socket.send;socket.send=function(){const p=send.apply(this,arguments);if(this.packetId===2)Object.defineProperty(this.responseMap[1],'resolve',{writable:false,configurable:false});return p;};}});await f.load();f.socket.establish();
  const first=f.socket.sync();f.deliver({cards:[]});await first;const second=f.socket.sync();f.deliver({cards:[]});await second;const events=await f.drain();assert.equal(events.filter(e=>e.stage==='socket_decoded_response').length,1);assert.equal(f.snapshot().milestones.hasInitialSync,false);assert.ok(f.snapshot().gaps.includes('initial_sync_unproven'));f.runtime.stop();
});
test('rejected first sync remains missing even after later successful responses',async()=>{
  const f=fixture();await f.load();f.socket.establish();const first=f.socket.sync();const rejected=assert.rejects(first,()=>true);f.socket.socket.onmessage({data:JSON.stringify({packet_id:1,code:500,message:'PRIVATE'})});await rejected;
  const second=f.socket.sync();f.deliver({cards:[]});await second;await f.drain();assert.equal(f.snapshot().milestones.hasInitialSync,false);assert.equal(f.snapshot().counters.decoderMissed,0);f.runtime.stop();
});
test('visual slots require exact unique current hand object identity rather than matching ID',async()=>{
  const f=fixture();await f.load();const exact={id:7,type:1,color:2,num:3},copy={...exact};f.store.gamers=[{cards:[]},{cards:[{id:1},exact]}];const component=new f.Card();component.setup(exact);component.setup(copy);const events=await f.drain(),inputs=events.filter(e=>e.stage==='card_setup_input');assert.equal(inputs[0].cards[0].slot,1);assert.equal(inputs[0].cards[0].index,1);assert.equal(inputs[1].cards[0].slot,undefined);const skin=events.filter(e=>e.stage==='skin_bg_input');assert.equal(skin[0].cards[0].slot,1);assert.equal(skin[1].cards[0].slot,undefined);f.runtime.stop();
});

'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {fixture}=require('./card_selected_fixture.cjs');
const {plain}=require('./card_hints_fixture.cjs');
const empty=()=>({id:0,type:0,color:0,num:0});
const back=id=>({id,type:0,color:0,num:0});
const number=(id,color,num=3)=>({id,type:1,color,num});
function summary(f){f.read();const s=f.reader.handSummary();assert.ok(s);return plain(s.map(({handNode,...row})=>row));}
function unavailable(f){assert.equal(f.reader.handSummary(),null);const s=f.reader.stats();assert.equal(s.handsStatus,'unavailable');assert.deepEqual(plain(s.handCounts),[]);assert.deepEqual([s.handTotal,s.handKnown,s.handUnknown],[0,0,0]);}
function invariant(s){for(const h of s){assert.equal(h.total,h.known+h.unknown);assert.equal(h.known,h.colors.reduce((a,b)=>a+b,0));assert.equal(h.special,h.colors[0]);assert.ok(h.selected<=h.known);}}

test('Free team current hands count model membership, not scene marker nodes',()=>{
 const f=fixture({selected:empty(),cards:[number(1,1),number(2,2),{id:3,type:6,color:0,num:0}]}),h=f.addHand('owner-1',[back(4),back(5),back(6),back(7)]);
 f.store.mode=3;f.store.bet_level=4;f.store.game_mode_type=1;f.store.discard_cards=[number(40,4),number(41,3)];
 // A dense fan/temporary center animation can have fewer visible hand nodes.
 h.nodes[0].c.node.removeFromParent();h.nodes[1].c.node.x=h.nodes[2].c.node.x;
 const s=summary(f);assert.deepEqual(s,[
  {slot:0,total:3,known:3,unknown:0,special:1,colors:[1,1,1,0,0],selected:0},
  {slot:1,total:4,known:0,unknown:4,special:0,colors:[0,0,0,0,0],selected:0}
 ]);invariant(s);const stats=f.reader.stats();assert.deepEqual([stats.handTotal,stats.handKnown,stats.handUnknown],[7,3,4]);
});
test('all supported match modes and Free bet level retain the same truthful counts',()=>{
 for(const mode of [2,3,5,6]){const f=fixture({selected:empty(),cards:[number(1,4),back(2)]});f.store.mode=mode;f.store.bet_level=4;assert.equal(summary(f)[0].total,2);}
});
test('special cards have their own bucket rather than inheriting table color',()=>{
 const f=fixture({selected:empty(),cards:[{id:1,type:4,color:0,num:0},{id:2,type:6,color:3,num:0},{id:3,type:10,color:4,num:0},number(4,1),number(5,2),number(6,3),number(7,4)]});
 f.store.color=3;const s=summary(f);assert.deepEqual(s[0].colors,[3,1,1,1,1]);assert.equal(s[0].known,7);assert.equal(s[0].special,3);invariant(s);
});
test('malformed/residual face fields stay unknown without shrinking a valid hand',()=>{
 const f=fixture({selected:empty(),cards:[{id:1,type:0,color:4,num:0},{id:2,type:1,color:0,num:3},{id:3,type:1,color:2,num:0},{id:4,type:2,color:1,num:7}]});
 const s=summary(f);assert.equal(s[0].total,4);assert.equal(s[0].known,0);assert.equal(s[0].unknown,4);invariant(s);
});
test('an observed selected fact counts even if the current UI hand is incomplete',()=>{
 const f=fixture();f.store.gamers[0].cards.push(back(46));const s=summary(f);assert.equal(s[0].total,2);assert.equal(s[0].known,1);assert.equal(s[0].unknown,1);assert.equal(s[0].selected,1);assert.deepEqual(s[0].colors,[0,0,1,0,0]);assert.equal(f.reader.stats().selectedKnown,0);
});
test('a selected card that never enters a current hand cannot color any hand count',()=>{
 const f=fixture({selected:number(25,4),cards:[back(98)]}),s=summary(f);assert.equal(s[0].known,0);assert.equal(s[0].selected,0);assert.equal(s[0].unknown,1);
});
test('raw faces and selected facts are counted once each, not once per source',()=>{
 const f=fixture({selected:number(98,2,9),cards:[number(98,2,9)]}),s=summary(f);assert.equal(s[0].known,1);assert.equal(s[0].selected,0);assert.deepEqual(s[0].colors,[0,0,1,0,0]);
});
test('cloned Store sync is fresh on the next begin but stale within one read',()=>{
 const f=fixture();summary(f);f.store.select_give_card=empty();f.cloneStore();unavailable(f);const s=summary(f);assert.equal(s[0].selected,1);assert.equal(s[0].known,1);assert.equal(f.reader.handSummary()[0].handNode,f.first.node);
});
test('zero-card gamer is valid when another real Card loads the Store snapshot',()=>{
 const f=fixture({selected:empty(),cards:[]});f.addHand('other',[back(2)]);const s=summary(f);assert.equal(s.length,2);assert.deepEqual(s[0],{slot:0,total:0,known:0,unknown:0,special:0,colors:[0,0,0,0,0],selected:0});assert.equal(f.reader.handSummary()[0].handNode,null);invariant(s);
});
test('missing a coherent HandArea anchor never erases model totals',()=>{
 const f=fixture({selected:empty(),cards:[number(1,1),back(2)]});f.first.hand.uid='wrong-ui-owner';const s=summary(f);assert.equal(s[0].total,2);assert.equal(s[0].known,1);assert.equal(f.reader.handSummary()[0].handNode,null);
});
test('only optional internal handSummary geometry contains nodes; stats contains no UID/ID/node',()=>{
 const f=fixture();summary(f);assert.equal(f.reader.handSummary()[0].handNode,f.first.node);const stats=f.reader.stats(),wire=JSON.stringify(stats);
 assert.ok(!wire.includes('owner-3'));assert.ok(!wire.includes('handNode'));assert.ok(!wire.includes('"uid"'));assert.ok(!wire.includes('"id"'));assert.equal(stats.handsStatus,'ready');
 assert.deepEqual(plain(stats.handCounts),[{slot:0,total:1,known:1,unknown:0,special:0,colors:[0,0,1,0,0],selected:1}]);
 // A caller cannot mutate the next result through an exported array.
 stats.handCounts[0].colors[2]=200;assert.equal(f.reader.stats().handCounts[0].colors[2],1);
});
test('mutation of Store array/gamer/card/UID/round/state invalidates the whole same-frame summary',()=>{
 const changes=[f=>{f.store.gamers=[...f.store.gamers];},f=>{f.store.gamers[0]={...f.store.gamers[0]};},f=>{f.store.gamers[0].cards=[...f.store.gamers[0].cards];},f=>{f.store.gamers[0].cards[0]={...f.store.gamers[0].cards[0]};},f=>{f.store.gamers[0].cards.push(back(12));},f=>{f.store.gamers[0].cards[0].color=4;},f=>{f.store.gamers[0].uid='new-owner';},f=>{f.store.start_time++;},f=>{f.store.state=4;},f=>{f.newScene();},f=>{f.win.cc={};}];
 for(const change of changes){const f=fixture();summary(f);change(f);unavailable(f);}
});
test('duplicate or invalid UIDs do not produce apparently valid zeros',()=>{
 for(const value of [undefined,null,0,-1,NaN,true,'','x'.repeat(129)]){const f=fixture();f.store.gamers[0].uid=value;f.read();unavailable(f);}
 const f=fixture();f.addHand('owner-3',[back(46)]);f.read();unavailable(f);
});
test('duplicate, zero, missing, coerced and out-of-range card IDs invalidate counts',()=>{
 for(const value of [undefined,null,0,-1,65536,NaN,true,'98']){const f=fixture();f.store.gamers[0].cards[0].id=value;f.read();unavailable(f);}
 const f=fixture();f.addHand('other',[back(98)]);f.read();unavailable(f);
});
test('sparse/missing card rows are invalid, not silently omitted from total',()=>{
 for(const mutate of [cards=>{delete cards[0];},cards=>{cards[0]=null;},cards=>{cards[0]=false;}]){const f=fixture();mutate(f.store.gamers[0].cards);f.read();unavailable(f);}
});
test('8 hands / 256 cards limits reject oversized snapshots',()=>{
 const f=fixture();for(let n=0;n<8;n++)f.addHand('other-'+n,[back(200+n)]);f.read();unavailable(f);
 const g=fixture();g.store.gamers[0].cards=Array.from({length:257},(_,i)=>back(i+1));g.read();unavailable(g);
});
test('no gamers is unavailable, unlike a valid gamer with an empty hand',()=>{const f=fixture();f.store.gamers=[];f.read();unavailable(f);});
test('inactive/invalid rounds never publish current hand counts',()=>{
 for(const token of [undefined,null,0,NaN,'']){const f=fixture();f.store.start_time=token;f.read();unavailable(f);}
 for(const state of [undefined,0,1,7,8,12,'3']){const f=fixture({state});f.store.state=state;f.read();unavailable(f);}
 for(const state of [2,3,4,5,6,9,10,11]){const f=fixture({state});assert.equal(summary(f)[0].total,1);}
});
test('removed/currently discarded selected cards no longer contribute retained color',()=>{
 const f=fixture();summary(f);f.store.select_give_card=empty();f.store.gamers[0].cards=[];const s=summary(f);assert.equal(s[0].total,0);assert.equal(s[0].selected,0);
 const g=fixture();summary(g);g.store.discard_cards.push(number(98,2,9));assert.equal(g.reader.handSummary()[0].known,0);assert.equal(g.reader.handSummary()[0].selected,0);
});
test('socket change or expired facts cannot remain in known hand counts',()=>{
 const f=fixture();summary(f);f.socket.socket={};assert.equal(f.reader.handSummary()[0].known,0);
 const g=fixture();summary(g);g.store.select_give_card=empty();g.setTime(1600);assert.equal(g.reader.handSummary()[0].known,0);
});
test('accessor face data is not invoked or counted as a confirmed color',()=>{
 const f=fixture({selected:empty(),cards:[number(1,2)]});let reads=0;Object.defineProperty(f.store.gamers[0].cards[0],'color',{get(){reads++;return 2;}});const s=summary(f);assert.equal(reads,0);assert.equal(s[0].total,1);assert.equal(s[0].unknown,1);
});
test('clear returns unavailable rather than a stale last valid hand list',()=>{const f=fixture();summary(f);f.reader.clear();unavailable(f);});

#import "license_gate_stub.h"
BOOL STTestLicenseAuthorized=YES;
BOOL STLicenseAllowsFeatures(void) { return STTestLicenseAuthorized; }

'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {setup,attachCard}=require('./card_hints_fixture.cjs');
const rootSource=fs.readFileSync(path.join(__dirname,'../Resources/card_root.js'),'utf8');
function fixture({selected={id:98,type:1,color:2,num:9},cards=[{id:98,type:0,color:0,num:0}],state=3,samplerSource=null}={}){
 const f=setup({rootSource,samplerSource});class Card{}Card.prototype.__classname__='Card';
 const socket={socket:{}},store={gamers:[],state,start_time:123,discard_cards:[],select_give_card:selected};
 const hands=[];
 function addHand(uid,infos){
  const node=new f.cc.Node('HandArea'),items=new f.cc.Node('Items');f.initial.canvas.addChild(node);node.addChild(items);
  const uiGamer={uid,cards:infos.map(c=>({...c}))},gamer={uid,cards:infos.map(c=>({...c}))};
  const hand={__classname__:'HandArea',itemsNode:items,gamer:uiGamer,uid};node._components.push(hand);
  const nodes=uiGamer.cards.map((info,index)=>{
   const c=f.card({face:false,parent:items,x:index*250});const component=attachCard(f,c,info);Object.setPrototypeOf(component,Card.prototype);
   return {c,component};
  });store.gamers.push(gamer);const result={uid,node,items,hand,uiGamer,gamer,nodes};hands.push(result);return result;
 }
 const first=addHand('owner-3',cards);const calls=[];
 f.win.__require=name=>{calls.push(name);return {default:{Card,GameStore:store,Socket:socket}[name]};};
 const reader=vm.runInContext(rootSource,f.context)();let time=0;f.win.performance.now=()=>time;
 function read(){reader.begin(f.cc,f.cc.director.getScene());return hands.flatMap(h=>h.nodes.map(x=>reader.resolve(x.c.node,x.component)));}
 function setTime(t){time=t;}
 function cloneStore(){store.gamers=store.gamers.map(g=>({...g,cards:g.cards.map(c=>({...c}))}));}
 return Object.assign(f,{store,socket,Card,hands,first,addHand,calls,reader,read,setTime,cloneStore});
}
module.exports={fixture,rootSource};

// Offline signed responses and an in-memory Keychain; no account/network writes.
#define ST_KEYAUTH_PUBLIC_KEY "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
#import "../Sources/SDKtools/STLicenseManager.m"
#import <objc/runtime.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static unsigned checks=0;
#define CHECK(value) do {assert(value);checks++;} while(0)
static NSMutableArray *pending;
static NSDictionary *fixtures;
typedef void (^STTestReply)(NSData *,NSHTTPURLResponse *,NSError *);
@interface STLicenseManagerTest : STLicenseManager
@property(nonatomic,strong) NSMutableDictionary *storage;
@property(nonatomic,copy) NSString *failWriteAccount;
@property(nonatomic,copy) NSString *failReadAccount;
@property(nonatomic) BOOL failDelete;
@property(nonatomic) NSTimeInterval wall;
@property(nonatomic) NSTimeInterval up;
@end
@implementation STLicenseManagerTest
- (instancetype)init {if((self=[super init])){_storage=[NSMutableDictionary dictionary];_wall=1700000000;_up=1000;}return self;}
- (NSTimeInterval)wallTime {return self.wall;}
- (NSTimeInterval)uptime {return self.up;}
- (NSData *)readSecret:(NSString *)account status:(OSStatus *)status {
    if([account isEqual:self.failReadAccount]){*status=errSecInteractionNotAllowed;return nil;}
    NSData *data=self.storage[account];*status=data?errSecSuccess:errSecItemNotFound;return data;
}
- (OSStatus)writeSecret:(NSData *)data account:(NSString *)account {
    if([account isEqual:self.failWriteAccount])return errSecInteractionNotAllowed;
    self.storage[account]=[data copy];return errSecSuccess;
}
- (OSStatus)deleteSecret:(NSString *)account {
    if(self.failDelete)return errSecInteractionNotAllowed;[self.storage removeObjectForKey:account];return errSecSuccess;
}
@end
@implementation STKeyAuthRequest (OfflineTests)
- (void)fixtureSend:(NSURLRequest *)request {
    CHECK([request.URL.absoluteString isEqual:@"https://keyauth.win/api/1.3/"]);
    CHECK([request.HTTPMethod isEqual:@"POST"] && !request.HTTPShouldHandleCookies);
    NSURLComponents *form=[NSURLComponents new];form.percentEncodedQuery=[[NSString alloc] initWithData:request.HTTPBody encoding:NSUTF8StringEncoding];
    NSMutableDictionary *fields=[NSMutableDictionary dictionary];for(NSURLQueryItem *item in form.queryItems)fields[item.name]=item.value;
    CHECK([fields[@"name"] isEqual:@"Weplaysdk"] && [fields[@"ownerid"] isEqual:@"Jdh0dfFTTT"]);
    [pending addObject:@{@"fields":fields,@"reply":[self.completion copy]}];
}
@end
static NSHTTPURLResponse *Response(NSDictionary *fixture) {
    return [[NSHTTPURLResponse alloc] initWithURL:[NSURL URLWithString:@"https://keyauth.win/api/1.3/"] statusCode:200 HTTPVersion:@"HTTP/1.1"
        headerFields:@{@"x-signature-ed25519":fixture[@"signature"],@"x-signature-timestamp":fixture[@"timestamp"]}];
}
static NSDictionary *Take(void){CHECK(pending.count>0);NSDictionary *row=pending.firstObject;[pending removeObjectAtIndex:0];return row;}
static void Deliver(NSDictionary *row,NSString *name) {
    NSDictionary *fixture=fixtures[name];CHECK(fixture!=nil);STTestReply reply=row[@"reply"];
    reply([[NSData alloc] initWithBase64EncodedString:fixture[@"bodyBase64"] options:0],Response(fixture),nil);
}
static void Reply(NSString *name){Deliver(Take(),name);}
static void Activate(STLicenseManagerTest *manager,NSString *key) {
    [manager activateKey:key];CHECK(manager.busy && !manager.authorized);
    if([pending.firstObject[@"fields"][@"type"] isEqual:@"init"]){CHECK([pending.firstObject[@"fields"][@"ver"] isEqual:@"1.0"]);Reply(@"init");}
    CHECK([pending.firstObject[@"fields"][@"key"] isEqual:key]);Reply(@"license");CHECK(manager.authorized&&!manager.busy&&manager.savedKeyAvailable);
}
int main(int argc,const char **argv){@autoreleasepool{
    CHECK(argc==2);NSData *fixtureData=[NSData dataWithContentsOfFile:[NSString stringWithUTF8String:argv[1]]];
    fixtures=[NSJSONSerialization JSONObjectWithData:fixtureData options:0 error:nil][@"cases"];CHECK(fixtures.count>=10);pending=[NSMutableArray array];
    method_exchangeImplementations(class_getInstanceMethod(STKeyAuthRequest.class,@selector(send:)),class_getInstanceMethod(STKeyAuthRequest.class,@selector(fixtureSend:)));
    STLicenseManagerTest *m=[STLicenseManagerTest new];[m start];
    CHECK(!m.authorized&&!m.busy&&!m.savedKeyAvailable&&pending.count==0);CHECK(m.storage[@"installation"]!=nil);
    NSString *device=m.deviceID;Activate(m,@"fixture+&=%license");
    CHECK([m.storage[@"license"] isEqual:[@"fixture+&=%license" dataUsingEncoding:NSUTF8StringEncoding]]);
    CHECK(m.storage.count==2 && m.expiry.timeIntervalSince1970==1700003600);
    NSMutableDictionary *saved=m.storage;[m.timer invalidate];m=nil;
    m=[STLicenseManagerTest new];m.storage=saved;[m start];CHECK(m.busy&&!m.authorized&&m.savedKeyAvailable);Reply(@"init");
    CHECK([pending.firstObject[@"fields"][@"key"] isEqual:@"fixture+&=%license"]);CHECK([pending.firstObject[@"fields"][@"hwid"] isEqual:device]);
    Reply(@"license");CHECK(m.authorized);
    m.up+=30;m.wall+=30;[m resume];CHECK([pending.firstObject[@"fields"][@"type"] isEqual:@"check"]);Reply(@"check");CHECK(m.authorized);
    m.up+=91;CHECK(!m.authorized);m.up-=91;
    m.up+=3600;m.wall-=3600;CHECK(!m.authorized); // Wall-clock rollback cannot extend the monotonic expiry.
    [m.timer invalidate];pending=[NSMutableArray array];

    for(NSString *bad in @[@"denied",@"expired",@"bad_expiry",@"bad_subscriptions",@"too_many",@"number_success",@"wrong_owner"]){
        m=[STLicenseManagerTest new];[m activateKey:@"fixture-key"];Reply(@"init");Reply(bad);
        CHECK(!m.authorized&&!m.busy&&!m.savedKeyAvailable&&!m.storage[@"license"]);
        CHECK([m.statusKey rangeOfString:@"fixture"].location==NSNotFound);
    }
    m=[STLicenseManagerTest new];[m activateKey:@"fixture-key"];Reply(@"invalid_session");CHECK(!m.authorized&&!m.busy&&pending.count==0);

    m=[STLicenseManagerTest new];Activate(m,@"fixture-key");m.up+=30;m.wall+=30;[m resume];
    NSDictionary *network=Take();((STTestReply)network[@"reply"])(nil,nil,[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorTimedOut userInfo:nil]);
    CHECK(!m.authorized&&!m.busy&&m.savedKeyAvailable&&m.storage[@"license"]!=nil);
    CHECK([m.statusKey isEqual:@"License service unavailable. Retry."]);[m resume];CHECK([pending.firstObject[@"fields"][@"key"] isEqual:@"fixture-key"]);Reply(@"license");CHECK(m.authorized);
    [m.timer invalidate];

    m=[STLicenseManagerTest new];[m activateKey:@"fixture-key"];NSDictionary *old=Take();[m forgetKey];Deliver(old,@"init");
    CHECK(!m.authorized&&!m.busy&&!m.savedKeyAvailable&&pending.count==0&&m.storage[@"installation"]!=nil);
    NSString *stable=m.deviceID;Activate(m,@"fixture-key");[m forgetKey];Activate(m,@"fixture-key");CHECK([m.deviceID isEqual:stable]);[m.timer invalidate];
    m=[STLicenseManagerTest new];[m activateKey:@"fixture-key"];old=Take();[m activateKey:@"bad\nkey"];Deliver(old,@"init");
    CHECK(!m.authorized&&!m.busy&&pending.count==0);
    m=[STLicenseManagerTest new];[m activateKey:@"old-key"];old=Take();[m activateKey:@"new-key"];NSDictionary *fresh=Take();
    Deliver(old,@"init");CHECK(pending.count==0&&m.busy);Deliver(fresh,@"init");
    CHECK([pending.firstObject[@"fields"][@"key"] isEqual:@"new-key"]);Reply(@"license");CHECK(m.authorized);[m.timer invalidate];

    m=[STLicenseManagerTest new];m.failWriteAccount=@"installation";[m start];CHECK(!m.deviceID&&!m.busy&&pending.count==0);
    m.failWriteAccount=nil;Activate(m,@"fixture-key");CHECK(m.storage[@"installation"]!=nil);[m.timer invalidate];
    m=[STLicenseManagerTest new];m.storage[@"installation"]=[@"not-a-uuid" dataUsingEncoding:NSUTF8StringEncoding];[m start];
    CHECK(m.deviceID==nil&&!m.authorized);[m activateKey:@"fixture-key"];CHECK(pending.count==0&&m.deviceID==nil&&!m.authorized);
    m=[STLicenseManagerTest new];m.failWriteAccount=@"license";[m activateKey:@"fixture-key"];Reply(@"init");Reply(@"license");CHECK(!m.authorized&&!m.savedKeyAvailable&&!m.storage[@"license"]);
    m=[STLicenseManagerTest new];m.storage=[saved mutableCopy];m.failReadAccount=@"license";[m start];CHECK(!m.authorized&&!m.busy);
    m.failReadAccount=nil;[m resume];Reply(@"init");Reply(@"license");CHECK(m.authorized);[m.timer invalidate];
    m.failDelete=YES;[m forgetKey];CHECK(!m.authorized&&!m.busy&&m.savedKeyAvailable&&m.storage[@"license"]!=nil);CHECK([m.statusKey isEqual:@"Secure storage unavailable"]);

    m=[STLicenseManagerTest new];Activate(m,@"fixture-key");m.up+=30;m.wall+=30;m.expiresUptime=m.up+5;m.expiry=[NSDate dateWithTimeIntervalSince1970:m.wall+5];
    [m resume];CHECK(m.busy&&m.timer!=nil);__block NSUInteger expiredNotices=0;
    id observer=[NSNotificationCenter.defaultCenter addObserverForName:STLicenseDidChangeNotification object:m queue:nil usingBlock:^(__unused NSNotification *n){if(!m.authorized)expiredNotices++;}];
    m.up+=6;m.wall+=6;[m.timer fire];CHECK(!m.authorized&&m.busy&&expiredNotices>0);[NSNotificationCenter.defaultCenter removeObserver:observer];
    [m forgetKey];Deliver(Take(),@"check");CHECK(!m.authorized&&pending.count==0);

    m=[STLicenseManagerTest new];NSDictionary *good=fixtures[@"license"];NSData *body=[[NSData alloc] initWithBase64EncodedString:good[@"bodyBase64"] options:0];
    CHECK([m verifiedBody:body response:Response(good)]!=nil);
    m.wall+=121;CHECK(![m verifiedBody:body response:Response(good)]);m.wall-=242;CHECK(![m verifiedBody:body response:Response(good)]);m.wall=1700000000;
    NSMutableData *tampered=[body mutableCopy];((uint8_t *)tampered.mutableBytes)[0]^=1;CHECK(![m verifiedBody:tampered response:Response(good)]);
    NSHTTPURLResponse *unsignedResponse=[[NSHTTPURLResponse alloc] initWithURL:[NSURL URLWithString:@"https://keyauth.win/api/1.3/"] statusCode:200 HTTPVersion:nil headerFields:@{}];
    CHECK(![m verifiedBody:body response:unsignedResponse]);
    NSDictionary *wrongHeaders=@{@"signature":[@"00" stringByPaddingToLength:128 withString:@"0" startingAtIndex:0],@"timestamp":@"1700000000"};
    CHECK(![m verifiedBody:body response:Response(wrongHeaders)]);

    STKeyAuthRequest *request=[STKeyAuthRequest new];__block BOOL redirectCalled=NO;
    [request URLSession:nil task:nil willPerformHTTPRedirection:unsignedResponse newRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://fixture.invalid/"]]
        completionHandler:^(NSURLRequest *r){CHECK(r==nil);redirectCalled=YES;}];CHECK(redirectCalled);
    request.data=[NSMutableData data];__block NSUInteger completions=0;request.completion=^(NSData *d,NSHTTPURLResponse *r,NSError *e){(void)d;(void)r;CHECK(e!=nil);completions++;};
    [request URLSession:nil dataTask:nil didReceiveData:[NSData dataWithBytesNoCopy:calloc(1,65537) length:65537 freeWhenDone:YES]];
    [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.05]];
    CHECK(completions==1);[request cancel];CHECK(completions==1);
    printf("KeyAuth manager: %u signed-response, storage, lifecycle and transport checks passed\n",checks);
}return 0;}

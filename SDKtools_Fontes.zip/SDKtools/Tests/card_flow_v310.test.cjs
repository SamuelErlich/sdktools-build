'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {fixture}=require('./card_flow_fixture.cjs');

function network(){
  const f=fixture(),s=f.socket;
  Object.assign(s,{packetId:1,responseMap:{},sent:[]});
  s.send=function(command,param){const id=this.packetId++;const promise=new Promise((resolve,reject)=>{this.responseMap[id]={resolve,reject};});this.sent.push({id,command,param,promise});return promise;};
  s.sync=function(){return this.send('CMD_SYNC');};
  s.onMessage=function({data}){const packet=JSON.parse(data);if(packet.body_encoding)throw Error('fixture expects decoded JSON');if(packet.packet_id)this.responseMap[packet.packet_id].resolve(packet.message);else this.pushHandler(packet.event,packet.message);};
  f.deliver=(value,id=s.sent.at(-1).id)=>s.onMessage({data:JSON.stringify({packet_id:id,message:value})});
  return f;
}
const commands=['CMD_SYNC','CMD_ENTER_GAME','CMD_PLAY_CARD','CMD_SELECT_COLOR','CMD_DOUBT','CMD_CHOOSE_GAMER','CMD_END_LOOK_OVER','CMD_GIVE_CARD','CMD_UNO','CMD_CATCH','CMD_CANCEL_AUTO'];

test('eleven original gameplay replies captured without sending any new requests',async()=>{
  const f=network();assert.equal(f.tick().version,3);assert.equal(f.socket.sent.length,0);
  for(const command of commands){
    const param={secret:'PRIVATE'},p=f.socket.send(command,param);
    assert.equal(p,f.socket.sent.at(-1).promise);assert.equal(f.socket.sent.at(-1).param,param);
    f.deliver({cards:[{id:20,type:1,color:3,num:8}],secret:'PRIVATE'});
    const o=f.tick();assert.equal(o.events.length,1);assert.equal(o.events[0].command,command);
    assert.equal(o.events[0].cards[0].colorState,'known');assert.equal(o.events[0].colorCounts.known,1);
    assert.ok(!JSON.stringify(o).includes('PRIVATE'));await p;
  }
  assert.equal(f.socket.sent.length,commands.length);f.runtime.clear();
});
test('authentication chat heartbeat and unknown replies are excluded',async()=>{
  const f=network();f.tick();
  for(const command of ['CMD_REGISTER','CMD_HEART_BEAT','CMD_QUICK_TEXT','CMD_FREE_TASK_AWARD','PRIVATE','CMD_CREATE_GAME']){
    const p=f.socket.send(command);f.deliver({cards:[{id:1,type:1,color:2}],secret:'PRIVATE'});await p;
  }
  const o=f.tick();assert.equal(o.decodedResponses,0);assert.equal(o.events.length,0);f.runtime.clear();
});
test('nested penalty cards copied before handler mutation with correct grouping and local slot',()=>{
  const f=fixture();f.store.gamers=[{uid:'A',cards:[]},{uid:'B',cards:[]}];
  f.socket.pushHandler=function(event,p){p.punish.cards[0].color=0;p.punish_list[0].cards[0].type=0;return p;};f.tick();
  const p={punish:{uid:'B',cards:[{id:1,type:1,color:2}]},punish_list:[{uid:'A',cards:[{id:2,type:3,color:4}]},{uid:'B',cards:[]}],secret:'PRIVATE'};
  assert.equal(f.socket.pushHandler(7,p),p);const e=f.tick().events[0];
  assert.deepEqual(e.cards.map(c=>[c.zone,c.slot,c.group,c.id,c.colorState]),[['punish',1,undefined,1,'known'],['punish_list',0,0,2,'known']]);
  assert.equal(e.cards[0].color,2);assert.equal(e.cards[1].type,3);
  assert.equal(e.payloadFields.find(x=>x.path==='punish_list_cards'&&x.group===1).count,0);
  assert.ok(!JSON.stringify(e).includes('uid'));assert.ok(!JSON.stringify(e).includes('PRIVATE'));f.runtime.clear();
});
test('empty absent null and accessors in nested fields are distinguished without invoking getters',()=>{
  const f=fixture();f.tick();let reads=0;const p={punish:{},punish_list:[{cards:[]}],look_over_cards:null};
  Object.defineProperty(p.punish,'cards',{get(){reads++;throw Error('must not execute');}});
  f.socket.pushHandler(7,p);const e=f.tick().events[0],field=k=>e.payloadFields.find(x=>x.path===k);
  assert.equal(reads,0);assert.equal(field('punish_cards').presence,'accessor');assert.equal(field('cards').presence,'absent');assert.equal(field('look_over_cards').presence,'null');assert.equal(field('punish_list_cards').count,0);f.runtime.clear();
});
test('color-only classification never promotes a masked or untyped color to known',()=>{
  const f=fixture();f.tick();const cards=[{type:0,color:0},{type:0,color:3},{color:2},{type:1,color:2},{type:4,color:0},{type:6,color:4},{type:10},{type:1,color:0},{type:1,color:'2'},{type:3,color:1}];
  f.socket.pushHandler(5,{cards});const e=f.tick().events[0];
  assert.deepEqual(e.cards.map(c=>c.colorState),['unknown','candidate','candidate','known','special','special','unavailable','unavailable','unavailable','known']);
  assert.deepEqual(e.colorCounts,{known:2,special:2,unknown:1,candidate:2,unavailable:3});
  assert.ok(e.cards.every(c=>!('num' in c)));assert.deepEqual(cards[1],{type:0,color:3});f.runtime.clear();
});
test('turn color remains separate from every hidden card color',()=>{
  const f=fixture();f.tick();f.socket.pushHandler(6,{color:4,card_type:6,cards:[{id:7,type:0,color:0,num:0}]});
  const e=f.tick().events[0];assert.equal(e.selectedColor,4);assert.equal(e.eventCardType,6);assert.equal(e.cards[0].color,0);assert.equal(e.cards[0].colorState,'unknown');f.runtime.clear();
});
test('visual card color is not mislabeled as turn color',()=>{
  const f=fixture();f.tick();f.component.setup({id:10,type:1,color:3,num:2});
  const events=f.tick().events.filter(e=>e.stage.startsWith('card_setup_'));
  assert.equal(events.length,2);assert.ok(events.every(e=>!('selectedColor' in e)));
  assert.ok(events.every(e=>e.cards[0].color===3));f.runtime.clear();
});
test('duplicate or unknown UID never produces a guessed penalty slot',()=>{
  const f=fixture();f.store.gamers=[{uid:'SAME',cards:[]},{uid:'SAME',cards:[]}];f.tick();
  f.socket.pushHandler(7,{punish:{uid:'SAME',cards:[{id:1}]},punish_list:[{uid:'UNKNOWN',cards:[{id:2}]}]});
  assert.ok(f.tick().events[0].cards.every(c=>!('slot' in c)));f.runtime.clear();
});
test('current payload player order takes precedence over previous Store order',()=>{
  const f=fixture();f.store.gamers=[{uid:'A',cards:[]},{uid:'B',cards:[]}];f.tick();
  f.socket.pushHandler(7,{gamers:[{uid:'B',cards:[]},{uid:'A',cards:[]}],punish:{uid:'B',cards:[{id:1}]}});
  assert.equal(f.tick().events[0].cards[0].slot,0);f.runtime.clear();
});
test('nested groups share the existing card and JSON budgets and counts match retained cards',()=>{
  const f=fixture();f.tick();f.socket.pushHandler(7,{punish_list:Array.from({length:12},()=>({cards:Array.from({length:300},(_,id)=>({id,type:1,color:2,num:3}))}))});
  const e=f.tick().events[0];assert.equal(e.truncated,true);assert.ok(e.cards.length<=256);assert.ok(JSON.stringify(e).length<=32768);assert.ok(e.payloadFields.length<=16);
  assert.equal(e.payloadFields.find(x=>x.path==='punish_list').count,12);assert.equal(Object.values(e.colorCounts).reduce((a,b)=>a+b,0),e.cards.length);f.runtime.clear();
});
test('non-sync resolver restored on scene change and no stale response captured',async()=>{
  const f=network();f.tick();const p=f.socket.send('CMD_PLAY_CARD'),entry=f.socket.responseMap[1],wrapper=entry.resolve;
  f.changeScene();f.advance(400);assert.notEqual(entry.resolve,wrapper);f.deliver({cards:[{id:10,type:1,color:4}]});await p;
  assert.equal(f.tick().events.length,0);f.runtime.clear();
});
test('current unknown card does not inherit the same ID color from earlier events or rounds',()=>{
  const f=fixture();f.tick();f.socket.pushHandler(5,{start_time:1,cards:[{id:10,type:5,color:1}]});f.socket.pushHandler(2,{start_time:2,cards:[{id:10,type:0,color:0}]});
  const e=f.tick().events;assert.equal(e[0].cards[0].colorState,'known');assert.equal(e[1].cards[0].colorState,'unknown');assert.notEqual(e[0].round,e[1].round);f.runtime.clear();
});
test('post-game result colors carry ending phase and stay separate from live hand observations',()=>{
  const f=fixture();f.tick();f.socket.pushHandler(12,{rank_infos:[{cards:[{id:1,type:1,color:3}]}]});
  const e=f.tick().events[0];assert.equal(e.afterGameOver,true);assert.equal(e.cards[0].zone,'result_rank');assert.equal(e.cards[0].colorState,'known');f.runtime.clear();
});

#import "../Sources/SDKtools/STCardSamplerMenu.h"
#import "../Sources/SDKtools/STCardFeaturePolicy.h"
// macOS/Foundation harness executing the exact production bridge and sanitizer.
// Only UIKit/WebKit surfaces are replaced; physical completions stay manual.
#import "../Sources/SDKtools/STCardHintsSanitizer.inc"
#import <dispatch/dispatch.h>
#include <stdio.h>

typedef NS_ENUM(NSInteger, UIApplicationState) { UIApplicationStateActive, UIApplicationStateInactive };
@interface UIApplication : NSObject
@property UIApplicationState applicationState;
+ (instancetype)sharedApplication;
@end
@implementation UIApplication
+ (instancetype)sharedApplication { static UIApplication *app; static dispatch_once_t once; dispatch_once(&once, ^{ app = [UIApplication new]; }); return app; }
@end

@interface WKWebView : NSObject
@property (nonatomic, strong) NSObject *window;
@property (nonatomic) BOOL hidden;
@property (nonatomic) double alpha;
@property (nonatomic) BOOL throwsOnSubmission;
@property (nonatomic) NSUInteger submissions;
@property (nonatomic, copy) NSString *lastScript;
@property (nonatomic, copy) void (^completion)(id, NSError *);
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id, NSError *))completion;
- (void)complete:(id)result error:(NSError *)error;
@end
@implementation WKWebView
- (instancetype)init { if ((self = [super init])) { _window = [NSObject new]; _alpha = 1; } return self; }
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id, NSError *))completion {
    self.submissions++; self.lastScript = script;
    if (self.throwsOnSubmission) @throw [NSException exceptionWithName:@"MockSubmission" reason:nil userInfo:nil];
    self.completion = completion;
}
- (void)complete:(id)result error:(NSError *)error {
    void (^callback)(id, NSError *) = self.completion; self.completion = nil;
    if (callback) callback(result, error);
}
@end

@interface STWPContext : NSObject
@property (nonatomic, weak) WKWebView *webView;
@property (nonatomic, copy) NSString *namespaceKey;
@property (nonatomic, copy) NSString *contextID;
@property (nonatomic, copy) NSString *webViewID;
@property (nonatomic) NSUInteger visualSessionGeneration;
@property (nonatomic) BOOL retireAfterCleanup;
@end
@implementation STWPContext
@end

@interface STWebProbe : NSObject
@property BOOL inFlight;
@property BOOL cleaning;
@property BOOL acting;
@property BOOL autoplayActing;
@property BOOL cardHintsActing;
@property NSUInteger requestSerial;
@property (nonatomic, copy) NSString *cardHintsScript;
@property (nonatomic, copy) NSString *cardRootScript;
@property (nonatomic, copy) NSString *cardSamplerScript;
@property (nonatomic, strong) NSMutableArray *cleanupQueue;
@property (nonatomic, strong) NSMutableArray *visualCleanupQueue;
@property (nonatomic, strong) NSMutableArray<STWPContext *> *cardHintsCleanupQueue;
@property (nonatomic, strong) NSMapTable<WKWebView *, STWPContext *> *cardHintsContexts;
@property (nonatomic, strong) NSMutableDictionary *counters;
- (void)count:(NSString *)key;
- (void)drainCleanup;
- (void)drainCardHintsCleanup;
- (void)hideCardHints;
- (BOOL)performCardHintsInWebView:(WKWebView *)webView sessionGeneration:(NSUInteger)sessionGeneration
    validateContext:(BOOL (^)(void))validateContext update:(void (^)(NSDictionary<NSString *, id> *result))update;
@end
@implementation STWebProbe
- (instancetype)init {
    if ((self = [super init])) {
        _cardRootScript = @"function(){return {};}";
        _cardSamplerScript = @"function(){return {};}";
        _cardHintsScript = @"function(){return {tick:function(){},clear:function(){},owns:function(){}};}";
        _cardHintsContexts = [NSMapTable weakToStrongObjectsMapTable];
        _cardHintsCleanupQueue = [NSMutableArray array];
        _cleanupQueue = [NSMutableArray array]; _visualCleanupQueue = [NSMutableArray array];
        _counters = [NSMutableDictionary dictionary];
    } return self;
}
- (void)count:(NSString *)key { self.counters[key] = @([self.counters[key] unsignedIntegerValue] + 1); }
- (void)drainCleanup { if (!self.inFlight) [self drainCardHintsCleanup]; }
#include "../Sources/SDKtools/STCardHintsBridge.inc"
@end

static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *message) {
    checks++; if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSMutableDictionary *Result(NSString *documentID) {
    return [@{@"version": @1, @"status": @"ready", @"reason": @"hints_ready", @"shown": @3,
        @"unknown": @2, @"unavailable": @1, @"runtimeDocumentID": documentID ?: @""} mutableCopy];
}
static NSString *Candidate(WKWebView *view) {
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"documentID:'([A-Fa-f0-9-]+)'" options:0 error:nil];
    NSTextCheckingResult *match = [regex firstMatchInString:view.lastScript options:0 range:NSMakeRange(0, view.lastScript.length)];
    return match ? [view.lastScript substringWithRange:[match rangeAtIndex:1]] : @"";
}
static void RunUntil(BOOL (^done)(void), NSTimeInterval seconds) {
    NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:seconds];
    while (!done() && deadline.timeIntervalSinceNow > 0)
        [[NSRunLoop mainRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
}
int main(void) { @autoreleasepool {
    NSMutableDictionary *data = Result(@"document");
    data[@"privateFace"] = @"never-export"; data[@"physicalPending"] = @YES; data[@"readOnly"] = @NO;
    NSDictionary *safe = STWPSanitizeCardHints(data);
    Check([safe[@"shown"] isEqual:@3] && [safe[@"unknown"] isEqual:@2] && [safe[@"unavailable"] isEqual:@1], @"observed counts retained");
    Check(!safe[@"privateFace"] && !safe[@"runtimeDocumentID"] && ![safe[@"physicalPending"] boolValue] && [safe[@"readOnly"] boolValue], @"page cannot export faces or own native lock");
    for (NSString *key in @[@"shown", @"unknown", @"unavailable"]) {
        for (id bad in @[@YES, @(-1), @0.25, @257, @(NAN), @(INFINITY), @"3", NSNull.null]) {
            NSMutableDictionary *row = Result(nil); row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"status"] isEqual:@"error"], @"invalid count rejected");
        }
        NSMutableDictionary *row = Result(nil); [row removeObjectForKey:key];
        Check([STWPSanitizeCardHints(row)[@"status"] isEqual:@"error"], @"missing count rejected");
    }
    Check([safe[@"unknownShown"] isEqual:@0] && [safe[@"special"] isEqual:@0] && [safe[@"candidates"] isEqual:@0], @"old v1 results receive zero color extensions");
    NSMutableDictionary *colors = Result(nil);
    colors[@"unknownShown"] = @2; colors[@"special"] = @1; colors[@"candidates"] = @1;
    Check([STWPSanitizeCardHints(colors)[@"unknownShown"] isEqual:@2], @"color extensions retained");
    for (NSString *key in @[@"unknownShown", @"special", @"candidates"]) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @"1", NSNull.null]) {
            NSMutableDictionary *row = [colors mutableCopy]; row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"invalid color extension rejected");
        }
        NSMutableDictionary *row = [colors mutableCopy]; row[key] = @4;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"inconsistent color count rejected");
    }
    NSMutableDictionary *overflow = [colors mutableCopy]; overflow[@"shown"] = @256;
    Check([STWPSanitizeCardHints(overflow)[@"reason"] isEqual:@"invalid_result"], @"total marker count bounded");
    for (id invalid in @[@YES, @0, @2, @"1"]) {
        NSMutableDictionary *row = Result(nil); row[@"version"] = invalid;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"version cannot be coerced");
    }
    data[@"reason"] = @"arbitrary-user-text";
    Check([STWPSanitizeCardHints(data)[@"reason"] isEqual:@"unrecognized_reason"], @"reason allowlist enforced");
    for (NSString *reason in @[@"hints_ready", @"hidden_faces_unknown", @"no_verified_cards", @"scene_unavailable",
        @"unsupported_engine", @"hidden_document", @"layout_limited", @"read_budget", @"renderer_unavailable",
        @"invalid_card_layout", @"stale_scene", @"lease_expired", @"document_changed", @"namespace_conflict"]) {
        data[@"reason"] = reason;
        Check([STWPSanitizeCardHints(data)[@"reason"] isEqual:reason], @"known bounded reason retained");
    }


    // Current-hand census is independent of partial rendered-node counters.
    Check([safe[@"handsStatus"] isEqual:@"unavailable"] && [safe[@"handCounts"] count] == 0 &&
        [safe[@"handTotal"] isEqual:@0] && [safe[@"handKnown"] isEqual:@0] && [safe[@"handUnknown"] isEqual:@0],
        @"legacy renderer cannot manufacture a current-hand total from markers");
    NSMutableDictionary *handsResult = Result(nil);
    NSMutableDictionary *firstHand = [@{@"slot": @0, @"total": @4, @"known": @2, @"unknown": @2, @"special": @1,
        @"colors": @[@1, @1, @0, @0, @0], @"selected": @1, @"uid": @"PRIVATE", @"cardID": @98} mutableCopy];
    NSDictionary *secondHand = @{@"slot": @2, @"total": @3, @"known": @1, @"unknown": @2, @"special": @0,
        @"colors": @[@0, @0, @1, @0, @0], @"selected": @0};
    [handsResult addEntriesFromDictionary:@{@"handsStatus": @"ready", @"handCounts": @[firstHand, secondHand],
        @"handTotal": @7, @"handKnown": @3, @"handUnknown": @4}];
    NSDictionary *safeHands = STWPSanitizeCardHints(handsResult);
    Check([safeHands[@"status"] isEqual:@"ready"] && [safeHands[@"handTotal"] isEqual:@7] &&
        [safeHands[@"handKnown"] isEqual:@3] && [safeHands[@"handUnknown"] isEqual:@4] &&
        [safeHands[@"shown"] isEqual:@3], @"current hands stay independent of partial visible markers");
    NSDictionary *safeFirst = [safeHands[@"handCounts"] firstObject];
    Check(safeFirst.count == 7 && !safeFirst[@"uid"] && !safeFirst[@"cardID"] &&
        [safeFirst[@"colors"] isEqual:@[@1, @1, @0, @0, @0]], @"hand boundary rebuilds an ID-free numeric whitelist");
    firstHand[@"total"] = @256;
    Check([safeFirst[@"total"] isEqual:@4], @"sanitized hand counters do not retain mutable page dictionaries");
    firstHand[@"total"] = @4;
    NSMutableArray *mutableHandColors = [firstHand[@"colors"] mutableCopy]; firstHand[@"colors"] = mutableHandColors;
    NSDictionary *isolatedHands = STWPSanitizeCardHints(handsResult); mutableHandColors[0] = @99;
    Check([[[isolatedHands[@"handCounts"] firstObject][@"colors"] firstObject] isEqual:@1],
        @"sanitized color arrays are rebuilt rather than retaining mutable page arrays");
    firstHand[@"colors"] = @[@1, @1, @0, @0, @0];
    for (NSString *key in @[@"handsStatus", @"handCounts", @"handTotal", @"handKnown", @"handUnknown"]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; [row removeObjectForKey:key];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"partial hand schema is rejected, not treated as legacy");
    }
    for (id bad in @[@YES, @1, @"root_ready", @"PRIVATE", NSNull.null]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handsStatus"] = bad;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand status is a closed enum");
    }
    for (NSString *key in @[@"handTotal", @"handKnown", @"handUnknown"]) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @(NAN), @(INFINITY), @"1", NSNull.null]) {
            NSMutableDictionary *row = [handsResult mutableCopy]; row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand totals are bounded integers without coercion");
        }
        NSMutableDictionary *row = [handsResult mutableCopy]; row[key] = @0;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"reported hand totals must equal their rows");
    }
    for (id bad in @[@YES, @0, @{}, NSNull.null]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = bad;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand counts must be an array");
    }
    for (id bad in @[@YES, @0, @[], NSNull.null]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[bad];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand rows must be dictionaries");
    }
    for (NSString *key in @[@"slot", @"total", @"known", @"unknown", @"special", @"colors", @"selected"]) {
        NSMutableDictionary *hand = [firstHand mutableCopy]; [hand removeObjectForKey:key];
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"every current-hand field is required");
    }
    for (NSString *key in @[@"slot", @"total", @"known", @"unknown", @"special", @"selected"]) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @(NAN), @(INFINITY), @"1", NSNull.null]) {
            NSMutableDictionary *hand = [firstHand mutableCopy]; hand[key] = bad;
            NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand row counters are bounded integers without coercion");
        }
    }
    NSMutableDictionary *slotEight = [firstHand mutableCopy]; slotEight[@"slot"] = @8;
    NSMutableDictionary *invalidHands = [handsResult mutableCopy]; invalidHands[@"handCounts"] = @[slotEight, secondHand];
    Check([STWPSanitizeCardHints(invalidHands)[@"reason"] isEqual:@"invalid_result"], @"slot eight is outside the zero-to-seven contract");
    NSMutableDictionary *duplicate = [secondHand mutableCopy]; duplicate[@"slot"] = @0;
    invalidHands[@"handCounts"] = @[firstHand, duplicate];
    Check([STWPSanitizeCardHints(invalidHands)[@"reason"] isEqual:@"invalid_result"], @"duplicate slots cannot double-count a hand");
    invalidHands[@"handCounts"] = @[firstHand, secondHand, firstHand, secondHand, firstHand, secondHand, firstHand, secondHand, firstHand];
    Check([STWPSanitizeCardHints(invalidHands)[@"reason"] isEqual:@"invalid_result"], @"more than eight rows is rejected before traversal");
    for (id bad in @[@YES, @0, @{}, NSNull.null, @[@0, @0, @0, @0], @[@0, @0, @0, @0, @0, @0]]) {
        NSMutableDictionary *hand = [firstHand mutableCopy]; hand[@"colors"] = bad;
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"colors is exactly five counters");
    }
    for (NSUInteger index = 0; index < 5; index++) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @(NAN), @(INFINITY), @"1", NSNull.null]) {
            NSMutableArray *colors = [firstHand[@"colors"] mutableCopy]; colors[index] = bad;
            NSMutableDictionary *hand = [firstHand mutableCopy]; hand[@"colors"] = colors;
            NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"each color count rejects invalid numeric representations");
        }
    }
    for (NSDictionary *mismatch in @[@{@"total": @5}, @{@"known": @3}, @{@"unknown": @3},
        @{@"special": @0}, @{@"selected": @3}, @{@"colors": @[@1, @0, @0, @0, @0]}]) {
        NSMutableDictionary *hand = [firstHand mutableCopy]; [hand addEntriesFromDictionary:mismatch];
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand partitions, color sum, special and selected invariants are enforced");
    }
    NSMutableDictionary *zeroHands = Result(nil);
    [zeroHands addEntriesFromDictionary:@{@"handsStatus": @"unavailable", @"handCounts": @[], @"handTotal": @0, @"handKnown": @0, @"handUnknown": @0}];
    Check([STWPSanitizeCardHints(zeroHands)[@"status"] isEqual:@"ready"], @"explicit unavailable census is valid only as empty and zero");
    NSDictionary *emptyHand = @{@"slot": @0, @"total": @0, @"known": @0, @"unknown": @0, @"special": @0,
        @"colors": @[@0, @0, @0, @0, @0], @"selected": @0};
    zeroHands[@"handCounts"] = @[emptyHand];
    Check([STWPSanitizeCardHints(zeroHands)[@"reason"] isEqual:@"invalid_result"], @"unavailable cannot smuggle even a zero-count hand");
    zeroHands[@"handsStatus"] = @"ready";
    NSMutableArray *eightHands = [NSMutableArray array];
    for (NSUInteger slot = 0; slot < 8; slot++) {
        NSMutableDictionary *hand = [emptyHand mutableCopy]; hand[@"slot"] = @(slot); [eightHands addObject:hand];
    }
    zeroHands[@"handCounts"] = eightHands;
    Check([STWPSanitizeCardHints(zeroHands)[@"handCounts"] count] == 8, @"eight unique zero-count hands are accepted");
    NSMutableDictionary *fullHand = [emptyHand mutableCopy]; fullHand[@"total"] = @256; fullHand[@"unknown"] = @256;
    zeroHands[@"handCounts"] = @[fullHand]; zeroHands[@"handTotal"] = @256; zeroHands[@"handUnknown"] = @256;
    Check([STWPSanitizeCardHints(zeroHands)[@"handTotal"] isEqual:@256], @"bounded current-hand census accepts the exact total limit");
    fullHand[@"unknown"] = @0; fullHand[@"known"] = @256; fullHand[@"special"] = @256;
    fullHand[@"selected"] = @256; fullHand[@"colors"] = @[@256, @0, @0, @0, @0];
    zeroHands[@"handKnown"] = @256; zeroHands[@"handUnknown"] = @0;
    Check([STWPSanitizeCardHints(zeroHands)[@"handKnown"] isEqual:@256], @"all-known special and selected counters accept their inclusive upper limit");
    fullHand[@"unknown"] = @256; fullHand[@"known"] = @0; fullHand[@"special"] = @0;
    fullHand[@"selected"] = @0; fullHand[@"colors"] = @[@0, @0, @0, @0, @0];
    zeroHands[@"handKnown"] = @0; zeroHands[@"handUnknown"] = @256;
    NSMutableDictionary *extraHand = [emptyHand mutableCopy]; extraHand[@"slot"] = @1; extraHand[@"total"] = @1; extraHand[@"unknown"] = @1;
    zeroHands[@"handCounts"] = @[fullHand, extraHand];
    Check([STWPSanitizeCardHints(zeroHands)[@"reason"] isEqual:@"invalid_result"], @"sum of individually valid hand rows cannot exceed 256");
    NSDictionary *invalidReset = STWPSanitizeCardHints(zeroHands);
    Check([invalidReset[@"handsStatus"] isEqual:@"unavailable"] && [invalidReset[@"handCounts"] count] == 0 &&
        [invalidReset[@"handTotal"] isEqual:@0], @"malformed census returns no stale or partial hand counts");

    #include "card_sampler_native_cases.inc"

    STWebProbe *probe = [STWebProbe new]; WKWebView *view = [WKWebView new];
    STWebProbe *missingSampler = [STWebProbe new]; missingSampler.cardSamplerScript = nil;
    __block NSDictionary *missingSamplerResult;
    Check(![missingSampler performCardHintsInWebView:view sessionGeneration:1 validateContext:^BOOL { return YES; }
        update:^(NSDictionary *value) { missingSamplerResult = value; }] && [missingSamplerResult[@"reason"] isEqual:@"renderer_script_missing"], @"missing sampler resource is not silently ignored");
    STWebProbe *missingRoot = [STWebProbe new]; missingRoot.cardRootScript = nil;
    __block NSDictionary *missingResult;
    Check(![missingRoot performCardHintsInWebView:view sessionGeneration:1 validateContext:^BOOL { return YES; }
        update:^(NSDictionary *r) { missingResult = r; }] && view.submissions == 0 &&
        [missingResult[@"reason"] isEqual:@"renderer_script_missing"], @"missing root script cannot dispatch an incomplete injection");
    NSMutableDictionary *rootResult = Result(nil);
    rootResult[@"rootStatus"] = @"root_ready"; rootResult[@"rootBound"] = @3;
    rootResult[@"rootKnown"] = @2; rootResult[@"rootUnknown"] = @1; rootResult[@"rootShown"] = @1; rootResult[@"rootUnbound"] = @0;
    rootResult[@"rootReferences"] = @"PRIVATE";
    NSDictionary *safeRoot = STWPSanitizeCardHints(rootResult);
    Check([safeRoot[@"rootShown"] isEqual:@1] && !safeRoot[@"rootReferences"], @"only root counters cross native boundary");
    rootResult[@"rootKnown"] = @4;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"root totals must agree");
    rootResult[@"rootKnown"] = @2; rootResult[@"rootShown"] = @3;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"drawn root count cannot exceed verified root colors");
    rootResult[@"rootShown"] = @YES;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"root counter cannot be a coerced boolean");
    NSMutableDictionary *selectedResult = Result(nil);
    [selectedResult addEntriesFromDictionary:@{@"rootStatus":@"root_ready",@"rootBound":@1,@"rootKnown":@1,@"rootUnknown":@0,@"rootUnbound":@0,@"rootShown":@1,
        @"selectedKnown":@1,@"selectedRetained":@1,@"selectedRejected":@0,@"selectedShown":@1,@"selectedCardID":@98}];
    NSDictionary *selectedSafe=STWPSanitizeCardHints(selectedResult);
    Check([selectedSafe[@"selectedShown"] isEqual:@1] && !selectedSafe[@"selectedCardID"], @"only selected source counts cross boundary");
    for (NSString *key in @[@"selectedKnown",@"selectedRetained",@"selectedRejected",@"selectedShown"]) {
        for (id bad in @[@YES,@(-1),@0.5,@257,@"1",NSNull.null]) {
            NSMutableDictionary *row=[selectedResult mutableCopy]; row[key]=bad;
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"selected counters are bounded integers");
        }
    }
    for (NSString *key in @[@"selectedKnown",@"selectedShown"]) {
        NSMutableDictionary *row=[selectedResult mutableCopy]; row[key]=@2;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"selected counters cannot exceed current root proof");
    }
    NSMutableArray *updates = [NSMutableArray array];
    BOOL (^valid)(void) = ^{ return YES; };
    BOOL accepted = [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { [updates addObject:r]; }];
    Check(accepted && probe.inFlight && probe.cardHintsActing && view.submissions == 1, @"one physical request is held");
    NSString *candidate = Candidate(view);
    Check(candidate.length == 36, @"runtime document candidate is native UUID");
    __block NSDictionary *blocked;
    Check(![probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { blocked = r; }], @"second request rejected while pending");
    Check([blocked[@"reason"] isEqual:@"physical_operation_pending"] && view.submissions == 1, @"rejection sends no second evaluation");
    RunUntil(^BOOL(void) { return updates.count > 0; }, 3.0);
    Check([updates.lastObject[@"reason"] isEqual:@"evaluation_timeout"] && [updates.lastObject[@"physicalPending"] boolValue] && probe.inFlight, @"timeout reports but does not unlock");
    [probe hideCardHints];
    Check(probe.cardHintsCleanupQueue.count == 1 && view.submissions == 1, @"clear is queued behind timed-out physical operation");
    [view complete:Result(candidate) error:nil];
    Check(updates.count == 2 && [updates.lastObject[@"afterTimeout"] boolValue] && ![updates.lastObject[@"physicalPending"] boolValue], @"late callback completes exactly once after timeout");
    Check(probe.inFlight && probe.cleaning && view.submissions == 2 && [view.lastScript containsString:@"s.runtime.clear()"], @"cleanup starts only after original callback");
    [view complete:@YES error:nil];
    Check(!probe.inFlight && !probe.cleaning, @"cleanup callback releases the physical lock");
    Check([[probe.cardHintsContexts objectForKey:view].contextID isEqual:candidate], @"clear preserves document identity");

    __block BOOL contextValid = YES;
    [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:^{ return contextValid; } update:^(NSDictionary *r) { blocked = r; }];
    Check([view.lastScript containsString:@"if(true)return fail('document_changed')"], @"reloaded document cannot silently create a fresh runtime");
    contextValid = NO;
    [view complete:Result(candidate) error:nil];
    Check([blocked[@"reason"] isEqual:@"native_context_changed"] && [blocked[@"shown"] isEqual:@0], @"late result after context loss exposes no stale counts");
    contextValid = YES;
    [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { blocked = r; }];
    [view complete:Result(@"unissued-document") error:nil];
    Check([blocked[@"reason"] isEqual:@"runtime_context_unverified"], @"foreign document result rejected");
    [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { blocked = r; }];
    NSMutableDictionary *changed = Result(candidate); changed[@"status"] = @"blocked"; changed[@"reason"] = @"document_changed";
    [view complete:changed error:nil];
    Check([blocked[@"reason"] isEqual:@"document_changed"], @"document-loss marker remains distinguishable");

    NSUInteger before = view.submissions;
    Check(![probe performCardHintsInWebView:view sessionGeneration:2 validateContext:valid update:^(NSDictionary *r) { blocked = r; }], @"fresh activation clears the prior generation first");
    Check(view.submissions == before + 1 && probe.cleaning && [blocked[@"reason"] isEqual:@"cleanup_pending"], @"generation cleanup is serialized");
    [view complete:@YES error:nil];
    [probe performCardHintsInWebView:view sessionGeneration:2 validateContext:valid update:^(NSDictionary *r) { blocked = r; }];
    NSString *second = Candidate(view);
    Check(![second isEqual:candidate], @"fresh explicit session gets independent document candidate");
    [view complete:Result(second) error:nil];
    Check([blocked[@"status"] isEqual:@"ready"], @"fresh activation can read after cleanup");

    probe.inFlight = YES; probe.acting = YES; before = view.submissions;
    Check(![probe performCardHintsInWebView:view sessionGeneration:2 validateContext:valid update:^(NSDictionary *r) { blocked = r; }], @"original action owns the same physical lock");
    Check(view.submissions == before, @"hints never overlap an original game action");
    probe.inFlight = NO; probe.acting = NO;
    view.throwsOnSubmission = YES;
    [probe hideCardHints];
    Check(probe.inFlight && probe.cleaning, @"throwing cleanup does not invent cancellation acknowledgment");
    printf("Card hints bridge: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

#import "../Sources/SDKtools/STCardFeaturePolicy.h"
// macOS/Foundation harness executing the exact production bridge and sanitizer.
// Only UIKit/WebKit surfaces are replaced; physical completions stay manual.
#import "../Sources/SDKtools/STCardHintsSanitizer.inc"
#import <dispatch/dispatch.h>
#include <stdio.h>

typedef NS_ENUM(NSInteger, UIApplicationState) { UIApplicationStateActive, UIApplicationStateInactive };
@interface UIApplication : NSObject
@property UIApplicationState applicationState;
+ (instancetype)sharedApplication;
@end
@implementation UIApplication
+ (instancetype)sharedApplication { static UIApplication *app; static dispatch_once_t once; dispatch_once(&once, ^{ app = [UIApplication new]; }); return app; }
@end

@interface WKWebView : NSObject
@property (nonatomic, strong) NSObject *window;
@property (nonatomic) BOOL hidden;
@property (nonatomic) double alpha;
@property (nonatomic) BOOL throwsOnSubmission;
@property (nonatomic) NSUInteger submissions;
@property (nonatomic, copy) NSString *lastScript;
@property (nonatomic, copy) void (^completion)(id, NSError *);
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id, NSError *))completion;
- (void)complete:(id)result error:(NSError *)error;
@end
@implementation WKWebView
- (instancetype)init { if ((self = [super init])) { _window = [NSObject new]; _alpha = 1; } return self; }
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id, NSError *))completion {
    self.submissions++; self.lastScript = script;
    if (self.throwsOnSubmission) @throw [NSException exceptionWithName:@"MockSubmission" reason:nil userInfo:nil];
    self.completion = completion;
}
- (void)complete:(id)result error:(NSError *)error {
    void (^callback)(id, NSError *) = self.completion; self.completion = nil;
    if (callback) callback(result, error);
}
@end

@interface STWPContext : NSObject
@property (nonatomic, weak) WKWebView *webView;
@property (nonatomic, copy) NSString *namespaceKey;
@property (nonatomic, copy) NSString *contextID;
@property (nonatomic, copy) NSString *webViewID;
@property (nonatomic) NSUInteger visualSessionGeneration;
@property (nonatomic) BOOL retireAfterCleanup;
@end
@implementation STWPContext
@end

@interface STWebProbe : NSObject
@property BOOL inFlight;
@property BOOL cleaning;
@property BOOL acting;
@property BOOL autoplayActing;
@property BOOL cardHintsActing;
@property NSUInteger requestSerial;
@property (nonatomic, copy) NSString *cardHintsScript;
@property (nonatomic, copy) NSString *cardRootScript;
@property (nonatomic, strong) NSMutableArray *cleanupQueue;
@property (nonatomic, strong) NSMutableArray *visualCleanupQueue;
@property (nonatomic, strong) NSMutableArray<STWPContext *> *cardHintsCleanupQueue;
@property (nonatomic, strong) NSMapTable<WKWebView *, STWPContext *> *cardHintsContexts;
@property (nonatomic, strong) NSMutableDictionary *counters;
- (void)count:(NSString *)key;
- (void)drainCleanup;
- (void)drainCardHintsCleanup;
- (void)hideCardHints;
- (BOOL)performCardHintsInWebView:(WKWebView *)webView sessionGeneration:(NSUInteger)sessionGeneration
    validateContext:(BOOL (^)(void))validateContext update:(void (^)(NSDictionary<NSString *, id> *result))update;
@end
@implementation STWebProbe
- (instancetype)init {
    if ((self = [super init])) {
        _cardRootScript = @"function(){return {};}";
        _cardHintsScript = @"function(){return {tick:function(){},clear:function(){},owns:function(){}};}";
        _cardHintsContexts = [NSMapTable weakToStrongObjectsMapTable];
        _cardHintsCleanupQueue = [NSMutableArray array];
        _cleanupQueue = [NSMutableArray array]; _visualCleanupQueue = [NSMutableArray array];
        _counters = [NSMutableDictionary dictionary];
    } return self;
}
- (void)count:(NSString *)key { self.counters[key] = @([self.counters[key] unsignedIntegerValue] + 1); }
- (void)drainCleanup { if (!self.inFlight) [self drainCardHintsCleanup]; }
#include "../Sources/SDKtools/STCardHintsBridge.inc"
@end

static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *message) {
    checks++; if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSMutableDictionary *Result(NSString *documentID) {
    return [@{@"version": @1, @"status": @"ready", @"reason": @"hints_ready", @"shown": @3,
        @"unknown": @2, @"unavailable": @1, @"runtimeDocumentID": documentID ?: @""} mutableCopy];
}
static NSString *Candidate(WKWebView *view) {
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"documentID:'([A-Fa-f0-9-]+)'" options:0 error:nil];
    NSTextCheckingResult *match = [regex firstMatchInString:view.lastScript options:0 range:NSMakeRange(0, view.lastScript.length)];
    return match ? [view.lastScript substringWithRange:[match rangeAtIndex:1]] : @"";
}
static void RunUntil(BOOL (^done)(void), NSTimeInterval seconds) {
    NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:seconds];
    while (!done() && deadline.timeIntervalSinceNow > 0)
        [[NSRunLoop mainRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
}
int main(void) { @autoreleasepool {
    NSMutableDictionary *data = Result(@"document");
    data[@"privateFace"] = @"never-export"; data[@"physicalPending"] = @YES; data[@"readOnly"] = @NO;
    NSDictionary *safe = STWPSanitizeCardHints(data);
    Check([safe[@"shown"] isEqual:@3] && [safe[@"unknown"] isEqual:@2] && [safe[@"unavailable"] isEqual:@1], @"observed counts retained");
    Check(!safe[@"privateFace"] && !safe[@"runtimeDocumentID"] && ![safe[@"physicalPending"] boolValue] && [safe[@"readOnly"] boolValue], @"page cannot export faces or own native lock");
    for (NSString *key in @[@"shown", @"unknown", @"unavailable"]) {
        for (id bad in @[@YES, @(-1), @0.25, @257, @(NAN), @(INFINITY), @"3", NSNull.null]) {
            NSMutableDictionary *row = Result(nil); row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"status"] isEqual:@"error"], @"invalid count rejected");
        }
        NSMutableDictionary *row = Result(nil); [row removeObjectForKey:key];
        Check([STWPSanitizeCardHints(row)[@"status"] isEqual:@"error"], @"missing count rejected");
    }
    Check([safe[@"unknownShown"] isEqual:@0] && [safe[@"special"] isEqual:@0] && [safe[@"candidates"] isEqual:@0], @"old v1 results receive zero color extensions");
    NSMutableDictionary *colors = Result(nil);
    colors[@"unknownShown"] = @2; colors[@"special"] = @1; colors[@"candidates"] = @1;
    Check([STWPSanitizeCardHints(colors)[@"unknownShown"] isEqual:@2], @"color extensions retained");
    for (NSString *key in @[@"unknownShown", @"special", @"candidates"]) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @"1", NSNull.null]) {
            NSMutableDictionary *row = [colors mutableCopy]; row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"invalid color extension rejected");
        }
        NSMutableDictionary *row = [colors mutableCopy]; row[key] = @4;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"inconsistent color count rejected");
    }
    NSMutableDictionary *overflow = [colors mutableCopy]; overflow[@"shown"] = @256;
    Check([STWPSanitizeCardHints(overflow)[@"reason"] isEqual:@"invalid_result"], @"total marker count bounded");
    for (id invalid in @[@YES, @0, @2, @"1"]) {
        NSMutableDictionary *row = Result(nil); row[@"version"] = invalid;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"version cannot be coerced");
    }
    data[@"reason"] = @"arbitrary-user-text";
    Check([STWPSanitizeCardHints(data)[@"reason"] isEqual:@"unrecognized_reason"], @"reason allowlist enforced");
    for (NSString *reason in @[@"hints_ready", @"hidden_faces_unknown", @"no_verified_cards", @"scene_unavailable",
        @"unsupported_engine", @"hidden_document", @"layout_limited", @"read_budget", @"renderer_unavailable",
        @"invalid_card_layout", @"stale_scene", @"lease_expired", @"document_changed", @"namespace_conflict"]) {
        data[@"reason"] = reason;
        Check([STWPSanitizeCardHints(data)[@"reason"] isEqual:reason], @"known bounded reason retained");
    }

    STWebProbe *probe = [STWebProbe new]; WKWebView *view = [WKWebView new];
    STWebProbe *missingRoot = [STWebProbe new]; missingRoot.cardRootScript = nil;
    __block NSDictionary *missingResult;
    Check(![missingRoot performCardHintsInWebView:view sessionGeneration:1 validateContext:^BOOL { return YES; }
        update:^(NSDictionary *r) { missingResult = r; }] && view.submissions == 0 &&
        [missingResult[@"reason"] isEqual:@"renderer_script_missing"], @"missing root script cannot dispatch an incomplete injection");
    NSMutableDictionary *rootResult = Result(nil);
    rootResult[@"rootStatus"] = @"root_ready"; rootResult[@"rootBound"] = @3;
    rootResult[@"rootKnown"] = @2; rootResult[@"rootUnknown"] = @1; rootResult[@"rootShown"] = @1; rootResult[@"rootUnbound"] = @0;
    rootResult[@"rootReferences"] = @"PRIVATE";
    NSDictionary *safeRoot = STWPSanitizeCardHints(rootResult);
    Check([safeRoot[@"rootShown"] isEqual:@1] && !safeRoot[@"rootReferences"], @"only root counters cross native boundary");
    rootResult[@"rootKnown"] = @4;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"root totals must agree");
    rootResult[@"rootKnown"] = @2; rootResult[@"rootShown"] = @3;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"drawn root count cannot exceed verified root colors");
    rootResult[@"rootShown"] = @YES;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"root counter cannot be a coerced boolean");
    NSMutableArray *updates = [NSMutableArray array];
    BOOL (^valid)(void) = ^{ return YES; };
    BOOL accepted = [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { [updates addObject:r]; }];
    Check(accepted && probe.inFlight && probe.cardHintsActing && view.submissions == 1, @"one physical request is held");
    NSString *candidate = Candidate(view);
    Check(candidate.length == 36, @"runtime document candidate is native UUID");
    __block NSDictionary *blocked;
    Check(![probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { blocked = r; }], @"second request rejected while pending");
    Check([blocked[@"reason"] isEqual:@"physical_operation_pending"] && view.submissions == 1, @"rejection sends no second evaluation");
    RunUntil(^BOOL(void) { return updates.count > 0; }, 3.0);
    Check([updates.lastObject[@"reason"] isEqual:@"evaluation_timeout"] && [updates.lastObject[@"physicalPending"] boolValue] && probe.inFlight, @"timeout reports but does not unlock");
    [probe hideCardHints];
    Check(probe.cardHintsCleanupQueue.count == 1 && view.submissions == 1, @"clear is queued behind timed-out physical operation");
    [view complete:Result(candidate) error:nil];
    Check(updates.count == 2 && [updates.lastObject[@"afterTimeout"] boolValue] && ![updates.lastObject[@"physicalPending"] boolValue], @"late callback completes exactly once after timeout");
    Check(probe.inFlight && probe.cleaning && view.submissions == 2 && [view.lastScript containsString:@"s.runtime.clear()"], @"cleanup starts only after original callback");
    [view complete:@YES error:nil];
    Check(!probe.inFlight && !probe.cleaning, @"cleanup callback releases the physical lock");
    Check([[probe.cardHintsContexts objectForKey:view].contextID isEqual:candidate], @"clear preserves document identity");

    __block BOOL contextValid = YES;
    [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:^{ return contextValid; } update:^(NSDictionary *r) { blocked = r; }];
    Check([view.lastScript containsString:@"if(true)return fail('document_changed')"], @"reloaded document cannot silently create a fresh runtime");
    contextValid = NO;
    [view complete:Result(candidate) error:nil];
    Check([blocked[@"reason"] isEqual:@"native_context_changed"] && [blocked[@"shown"] isEqual:@0], @"late result after context loss exposes no stale counts");
    contextValid = YES;
    [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { blocked = r; }];
    [view complete:Result(@"unissued-document") error:nil];
    Check([blocked[@"reason"] isEqual:@"runtime_context_unverified"], @"foreign document result rejected");
    [probe performCardHintsInWebView:view sessionGeneration:1 validateContext:valid update:^(NSDictionary *r) { blocked = r; }];
    NSMutableDictionary *changed = Result(candidate); changed[@"status"] = @"blocked"; changed[@"reason"] = @"document_changed";
    [view complete:changed error:nil];
    Check([blocked[@"reason"] isEqual:@"document_changed"], @"document-loss marker remains distinguishable");

    NSUInteger before = view.submissions;
    Check(![probe performCardHintsInWebView:view sessionGeneration:2 validateContext:valid update:^(NSDictionary *r) { blocked = r; }], @"fresh activation clears the prior generation first");
    Check(view.submissions == before + 1 && probe.cleaning && [blocked[@"reason"] isEqual:@"cleanup_pending"], @"generation cleanup is serialized");
    [view complete:@YES error:nil];
    [probe performCardHintsInWebView:view sessionGeneration:2 validateContext:valid update:^(NSDictionary *r) { blocked = r; }];
    NSString *second = Candidate(view);
    Check(![second isEqual:candidate], @"fresh explicit session gets independent document candidate");
    [view complete:Result(second) error:nil];
    Check([blocked[@"status"] isEqual:@"ready"], @"fresh activation can read after cleanup");

    probe.inFlight = YES; probe.acting = YES; before = view.submissions;
    Check(![probe performCardHintsInWebView:view sessionGeneration:2 validateContext:valid update:^(NSDictionary *r) { blocked = r; }], @"original action owns the same physical lock");
    Check(view.submissions == before, @"hints never overlap an original game action");
    probe.inFlight = NO; probe.acting = NO;
    view.throwsOnSubmission = YES;
    [probe hideCardHints];
    Check(probe.inFlight && probe.cleaning, @"throwing cleanup does not invent cancellation acknowledgment");
    printf("Card hints bridge: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

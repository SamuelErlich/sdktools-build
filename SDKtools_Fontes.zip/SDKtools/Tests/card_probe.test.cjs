const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_probe.js'),'utf8');
const BASE_NAME=String.fromCharCode(65,18,178,215,49),ALT_BACK_NAME=String.fromCharCode(67,37,243,108,163);
function setup(){
 let time=0,nextRAF=0,currentRoot;const created=[],scheduled=new Map();
 class Color{constructor(r=255,g=255,b=255,a=255){Object.assign(this,{r,g,b,a});}}
 class Node{
  constructor(name){Object.assign(this,{name,x:0,y:0,width:10,height:10,scaleX:1,scaleY:1,angle:0,anchorX:.5,anchorY:.5,zIndex:0,active:true,isValid:true,opacity:255,color:new Color(),children:[],parent:null,comps:[],group:'default'});this._components=this.comps;created.push(this);}
  get activeInHierarchy(){return this.parent?this.active&&this.parent.activeInHierarchy:true;}
  addChild(n){if(n.parent)n.removeFromParent();n.parent=this;this.children.push(n);}
  removeFromParent(){if(this.parent){this.parent.children.splice(this.parent.children.indexOf(this),1);this.parent=null;}}
  destroy(){this.isValid=false;this.children.forEach(c=>c.destroy());}
  addComponent(C){const c=new C();c.node=this;this.comps.push(c);return c;}
  getComponent(C){return this.comps.find(c=>c instanceof C)||null;}
  convertToWorldSpaceAR(p){let n=this,x=p.x,y=p.y;while(n){const a=n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=x*n.scaleX,yy=y*n.scaleY;x=c*xx-s*yy+n.x;y=s*xx+c*yy+n.y;n=n.parent;}return{x,y};}
  convertToNodeSpaceAR(p){const chain=[];let n=this,x=p.x,y=p.y;while(n){chain.push(n);n=n.parent;}for(n of chain.reverse()){x-=n.x;y-=n.y;const a=-n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=c*x-s*y,yy=s*x+c*y;x=xx/n.scaleX;y=yy/n.scaleY;}return{x,y};}
 }
 class Sprite{constructor(){this.enabled=true;this.type=0;this.trim=true;}get enabledInHierarchy(){return this.enabled&&this.node.activeInHierarchy;}}Sprite.prototype.__classname__='cc.Sprite';Sprite.Type={SIMPLE:0};Sprite.SizeMode={CUSTOM:0};
 class Graphics{constructor(){this.commands=[];this.clears=0;}clear(){this.commands=[];this.clears++;}moveTo(x,y){this.commands.push(['M',x,y]);}lineTo(x,y){this.commands.push(['L',x,y]);}close(){this.commands.push(['Z']);}fill(){this.commands.push(['fill']);}stroke(){this.commands.push(['stroke']);}}
 const cc={Node,Sprite,Graphics,Color,ENGINE_VERSION:'2.4.5',v2:(x,y)=>({x,y}),director:{getScene:()=>currentRoot},Canvas:{instance:{node:null}}};
 const doc={hidden:false,visibilityState:'visible',querySelector:()=>({getBoundingClientRect:()=>({width:390,height:693.16})})};
 const win={cc,CocosEngine:'2.4.5',performance:{now:()=>time},requestAnimationFrame:fn=>{scheduled.set(++nextRAF,fn);return nextRAF;},cancelAnimationFrame:id=>scheduled.delete(id)};
 const context={window:win,document:doc,Map,WeakMap,Set,WeakSet,Date};vm.createContext(context);
 const probe=vm.runInContext(source,context)();
 function newScene(){const scene=new Node('Scene');scene.active=false;const canvas=new Node('Canvas');canvas.width=1500;canvas.height=2666;scene.addChild(canvas);currentRoot=scene;cc.Canvas.instance.node=canvas;return {scene,canvas};}
 const initial=newScene();
 function frame(name,rect){const texture={loaded:true};return{name,getRect:()=>({x:rect[0],y:rect[1],width:rect[2],height:rect[3]}),getTexture:()=>texture};}
 function art(name,parent,w,h,fr){const n=new Node(name);n.width=w;n.height=h;parent.addChild(n);const sp=n.addComponent(Sprite);sp.spriteFrame=fr;return n;}
 function card({x=0,y=-850,face=true,alternateBack=false,parent=cc.Canvas.instance.node}={}){
  const n=new Node('Card');Object.assign(n,{width:224,height:295,x,y,scaleX:.8,scaleY:.8});parent.addChild(n);
  const shadow=new Node('Shadow');shadow.active=false;n.addChild(shadow);
  const base=art('Base',n,216,286,frame(BASE_NAME,[909,212,216,286]));
  const front=new Node('Front');front.width=224;front.height=295;front.active=face;n.addChild(front);
  const color=art('Color',front,210,280,frame('frontColor',[1590,212,210,280]));
  const decoration=new Node('Decoration');decoration.active=false;front.addChild(decoration);
  const symbol=art('Symbol',front,175,209,frame('frontSymbol',[1834,228,175,209]));
  const extra=new Node('Extra');extra.active=false;front.addChild(extra);
  const back=art('Back',n,224,295,alternateBack?frame(ALT_BACK_NAME,[1138,212,210,280]):frame('',[1357,208,224,295]));back.active=!face;
  return{node:n,base,front,color,symbol,back};
 }
 function hints(){const l=cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Faces');return l?l.children.filter(n=>n.name==='SDKtools Visible Card'):[];}
 function layer(){return cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Faces');}
 function advance(ms){time+=ms;const q=[...scheduled.values()];scheduled.clear();q.forEach(fn=>fn(time));}
 return{cc,doc,win,context,probe,frame,card,hints,layer,advance,created,scheduled,initial,newScene,now:()=>time};
}
function plain(v){return JSON.parse(JSON.stringify(v));}


function attach(f,c,values,name='CardController'){
 const component={__classname__:name,node:c.node,...values};c.node._components.push(component);return component;
}
function field(record,name){return record.components.flatMap(c=>c.fields).find(f=>f.name===name);}
function frameNodes(record){return record.nodes.filter(n=>n.frame);}

test('captures the verified card own active and inactive branches without assigning identity',()=>{
 const f=setup(),c=f.card({face:false});const r=f.probe();assert.equal(r.status,'ready');assert.equal(r.reason,'captured');assert.equal(r.cards.length,1);
 const card=r.cards[0];assert.equal(card.identityVerified,false);assert.equal(card.frontActive,false);assert.equal(card.backActive,true);
 const front=card.nodes.filter(n=>n.branch==='front');assert.ok(front.some(n=>n.frame && n.activeInHierarchy===false));assert.ok(front.every(n=>n.identityVerified===false));
 assert.ok(frameNodes(card).some(n=>n.frame.frameID.startsWith('cpf')));assert.match(card.nodeID,/^cpn\d+$/);assert.equal(card.local.width,224);
});
test('captures only proven card roots, including a structurally inactive scene root',()=>{
 const f=setup();assert.equal(f.initial.scene.active,false);f.card();const other=new f.cc.Node('Card');other.width=224;other.height=295;f.initial.canvas.addChild(other);
 const r=f.probe();assert.equal(r.cards.length,1);assert.equal(r.truncated,false);
});
test('empty name hash on a non-card texture never establishes a back',()=>{
 const f=setup(),c=f.card({face:false});c.back.getComponent(f.cc.Sprite).spriteFrame=f.frame('',[0,0,1090,1090]);assert.equal(f.probe().cards.length,0);
});
test('IDs are stable within scene and use a dedicated namespace',()=>{
 const f=setup();f.card();let a=f.probe();f.advance(500);let b=f.probe();assert.equal(a.cards[0].nodeID,b.cards[0].nodeID);assert.equal(a.sceneEpoch,b.sceneEpoch);assert.equal(b.sampleIndex,a.sampleIndex+1);assert.equal(b.elapsedMs,500);
 assert.equal(a.cards[0].nodes.find(n=>n.frame).frame.frameID,b.cards[0].nodes.find(n=>n.frame).frame.frameID);assert.match(a.cards[0].nodes.find(n=>n.frame).frame.textureID,/^cpt\d+$/);
});
test('new scene resets object IDs and sequence under a new sceneEpoch',()=>{
 const f=setup();f.card();const a=f.probe();f.newScene();f.card();const b=f.probe();assert.equal(b.sceneEpoch,a.sceneEpoch+1);assert.equal(b.sampleIndex,1);assert.equal(b.cards[0].nodeID,a.cards[0].nodeID);
});
test('worldOrigin preserves the observed parent transform for cross-probe alignment',()=>{
 const f=setup();Object.assign(f.initial.canvas,{x:40,y:80,scaleX:2,scaleY:3});f.card({x:10,y:20});
 const card=f.probe().cards[0];assert.deepEqual(plain(card.worldOrigin),{x:60,y:140});assert.equal(card.local.x,10);assert.equal(card.local.y,20);
});
test('missing or invalid geometry is omitted without fabricating zero coordinates',()=>{
 const f=setup(),c=f.card();Object.assign(c.node,{x:NaN,y:Infinity,scaleX:undefined,scaleY:101,angle:36001,zIndex:-32769});
 let card=f.probe().cards[0];assert.deepEqual(plain(card.local),{width:224,height:295});assert.equal(card.worldOrigin,undefined);
 c.node.convertToWorldSpaceAR=()=>({x:0,y:100001});card=f.probe().cards[0];assert.equal(card.worldOrigin,undefined);
 c.node.convertToWorldSpaceAR=()=>{throw Error('not available');};card=f.probe().cards[0];assert.equal(card.worldOrigin,undefined);
 c.node.convertToWorldSpaceAR=null;card=f.probe().cards[0];assert.equal(card.worldOrigin,undefined);
});
test('records primitive and one-level CardInfo fields using own descriptors',()=>{
 const f=setup(),c=f.card();attach(f,c,{cardType:3,cardValue:11,isSelected:true,cardInfo:{color:2,value:9,isRevealed:false,playerID:123456},cardData:{color:4,cardInfo:{value:88}}});
 const r=f.probe(),card=r.cards[0];assert.equal(field(card,'cardType').value,3);assert.equal(field(card,'isSelected').value,true);
 const info=field(card,'cardInfo');assert.equal(info.kind,'object');assert.match(info.objectID,/^cpo\d+$/);assert.equal(info.fields.find(f=>f.name==='value').value,9);assert.ok(!info.fields.some(f=>f.name==='playerID'));
 assert.equal(field(card,'cardData').fields.find(f=>f.name==='cardInfo').kind,'other');
});
test('game getters are described but never invoked, including nested state',()=>{
 const f=setup(),c=f.card();let calls=0;const state={color:1};Object.defineProperty(state,'cardValue',{enumerable:true,get(){calls++;throw Error('no');}});const comp=attach(f,c,{cardInfo:state});Object.defineProperty(comp,'cardValue',{get(){calls++;throw Error('no');}});
 const record=f.probe().cards[0];assert.equal(calls,0);assert.equal(field(record,'cardValue').kind,'accessor_skipped');assert.equal(field(record,'cardInfo').fields.find(f=>f.name==='cardValue').kind,'accessor_skipped');
});
test('string values, private identifiers, URLs, tokens and unrelated fields never leak',()=>{
 const f=setup(),c=f.card();attach(f,c,{cardText:'PRIVATE-CARD-TEXT',cardURL:'https://secret.invalid',playerID:42,userID:18,cardToken:'PRIVATE-TOKEN',cardOwner:88,accountCardValue:9,other:'PRIVATE-OTHER',cardValue:7,cardInfo:{value:3,userName:'PRIVATE-NAME',cardEmail:'PRIVATE-EMAIL'}});
 const r=f.probe(),text=JSON.stringify(r);assert.doesNotMatch(text,/PRIVATE|secret\.invalid|playerID|userID|cardToken|cardOwner|accountCardValue|cardEmail/);assert.equal(field(r.cards[0],'cardText').kind,'string_omitted');assert.equal(field(r.cards[0],'cardValue').value,7);
});
test('seat and player indices are permitted only as small integer positions',()=>{
 const f=setup(),c=f.card();attach(f,c,{seatIndex:2,playerIndex:7,_playerIndex:8888,_seatIndex:1.2});const r=f.probe().cards[0];assert.equal(field(r,'seatIndex').value,2);assert.equal(field(r,'playerIndex').value,7);assert.equal(field(r,'_playerIndex'),undefined);assert.equal(field(r,'_seatIndex'),undefined);
});
test('reference fields link only to frames, nodes and components inside this card record',()=>{
 const f=setup(),c=f.card(),stranger=new f.cc.Node('not part of card');attach(f,c,{frontNode:c.front,cardFrame:c.symbol.getComponent(f.cc.Sprite).spriteFrame,frontSprite:c.symbol.getComponent(f.cc.Sprite),cardObject:stranger});
 const record=f.probe().cards[0];assert.equal(field(record,'frontNode').kind,'node_ref');assert.match(field(record,'frontNode').ref,/^cpn/);assert.equal(field(record,'cardFrame').kind,'frame_ref');assert.match(field(record,'cardFrame').ref,/^cpf/);assert.equal(field(record,'frontSprite').kind,'component_ref');assert.match(field(record,'frontSprite').ref,/^cpc/);assert.equal(field(record,'cardObject').kind,'other');
});
test('functions and arrays are not executed or dumped',()=>{
 const f=setup(),c=f.card();let calls=0;attach(f,c,{cardValue:()=>{calls++;},cardList:[{userID:'PRIVATE'},9],cardString:'PRIVATE'});const r=f.probe().cards[0];assert.equal(calls,0);assert.equal(field(r,'cardValue').kind,'function_omitted');assert.equal(field(r,'cardList').kind,'array_omitted');assert.equal(field(r,'cardList').length,2);assert.doesNotMatch(JSON.stringify(r),/PRIVATE/);
});
test('reveal transitions preserve source object binding but never promote identityVerified',()=>{
 const f=setup(),c=f.card({face:false});attach(f,c,{cardInfo:{color:1,value:3}});const a=f.probe();c.front.active=true;c.back.active=false;c.symbol.getComponent(f.cc.Sprite).spriteFrame=f.frame('newly-revealed',[10,10,175,209]);f.advance(500);const b=f.probe();
 assert.equal(a.cards[0].nodeID,b.cards[0].nodeID);assert.equal(a.cards[0].frontActive,false);assert.equal(b.cards[0].frontActive,true);assert.equal(b.cards[0].identityVerified,false);
 const oldFrame=a.cards[0].nodes.find(n=>n.path.join('.')==='2.2').frame.frameID,newFrame=b.cards[0].nodes.find(n=>n.path.join('.')==='2.2').frame.frameID;assert.notEqual(oldFrame,newFrame);
});
test('prioritizes script components over stock rendering components under limits',()=>{
 const f=setup(),c=f.card();for(let i=0;i<6;i++)c.node._components.push({__classname__:'cc.Label',cardValue:i});attach(f,c,{cardInfo:{value:8}},'CardDataController');const r=f.probe().cards[0];assert.ok(r.components.some(c=>c.className==='CardDataController'&&c.fields.some(f=>f.name==='cardInfo')));
});
test('bounded branch traversal includes inactive descendants only within verified cards',()=>{
 const f=setup(),c=f.card({face:false});for(let i=0;i<30;i++){const n=new f.cc.Node('part');n.active=false;c.front.addChild(n);}const external=new f.cc.Node('unrelated');external.active=false;f.initial.canvas.addChild(external);Object.defineProperty(external,'children',{get(){throw Error('unrelated inactive traversal');}});
 const r=f.probe();assert.equal(r.cards.length,1);assert.ok(r.cards[0].nodes.length<=16);assert.ok(r.truncationReasons.includes('branch_limit'));
});
test('payload stays bounded and rotates sampled cards instead of always dropping the same tail',()=>{
 const f=setup();for(let i=0;i<40;i++){const c=f.card({x:i});const values={};for(let k=0;k<12;k++)values['cardValue'+k]=k;attach(f,c,values);}
 const first=f.probe();assert.ok(JSON.stringify(first).length<=49152);assert.ok(first.truncationReasons.includes('payload_limit'));const firstIDs=new Set(first.cards.map(c=>c.nodeID));
 const second=f.probe();assert.ok(second.cards.some(c=>!firstIDs.has(c.nodeID)));assert.ok(JSON.stringify(second).length<=49152);
});
test('component fields are bounded and truncation is explicit',()=>{
 const f=setup(),c=f.card(),values={};for(let i=0;i<30;i++)values['cardValue'+i]=i;attach(f,c,values);const r=f.probe();assert.ok(r.truncationReasons.includes('field_limit'));assert.ok(r.cards[0].components.every(c=>c.fields.length<=12));
});
test('engine visibility and missing-scene gates expose no card data',()=>{
 const f=setup();f.card();f.cc.ENGINE_VERSION='2.4.4';assert.equal(f.probe().reason,'unsupported_engine');f.cc.ENGINE_VERSION='2.4.5';f.doc.hidden=true;assert.equal(f.probe().reason,'hidden_document');f.doc.hidden=false;f.cc.director.getScene=()=>null;assert.equal(f.probe().reason,'scene_unavailable');
});
test('probe does not mutate the scene, namespace, renderer or scheduling state',()=>{
 const f=setup(),c=f.card(),keys=Object.keys(f.win),before=f.created.length,children=c.node.children.slice();f.probe();assert.equal(f.created.length,before);assert.deepEqual(c.node.children,children);assert.deepEqual(Object.keys(f.win),keys);assert.equal(f.scheduled.size,0);
 assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(|\.emit\s*\(|\.on\s*\(|addComponent\s*\(|assetManager|__require|window\.[A-Za-z_$]+\s*=/);assert.ok(Buffer.byteLength(source)<65536);
});

function attachRealCard(f,c,info){return attach(f,c,{cardInfo:info,skinNode:c.front,bgSprite:c.color.getComponent(f.cc.Sprite),typeSprite:c.symbol.getComponent(f.cc.Sprite),backSprite:c.back.getComponent(f.cc.Sprite)},'Card');}
test('captures local id only in structurally verified Card.cardInfo along with type color and num',()=>{
 const f=setup(),c=f.card({face:false});attachRealCard(f,c,{id:321,type:0,color:1,num:3});const card=f.probe().cards[0],info=field(card,'cardInfo');
 assert.equal(info.fields.find(f=>f.name==='id').value,321);assert.equal(info.fields.find(f=>f.name==='type').value,0);assert.equal(info.fields.find(f=>f.name==='color').value,1);assert.equal(info.fields.find(f=>f.name==='num').value,3);assert.equal(card.identityVerified,false);
});
test('id is excluded at root, other classes, other nested objects and mismatched structural references',()=>{
 for(const scenario of ['class','refs','field','root']){const f=setup(),c=f.card(),component=attachRealCard(f,c,{id:321,type:1,color:1,num:3});
  if(scenario==='class')component.__classname__='CardController';if(scenario==='refs')component.typeSprite=null;if(scenario==='field'){component.cardData=component.cardInfo;delete component.cardInfo;}if(scenario==='root'){component.id=321;delete component.cardInfo;}
  const card=f.probe().cards[0];assert.doesNotMatch(JSON.stringify(card.components),/"name":"id"/);
 }
});
test('local card ids reject out-of-range, negative, fractional, string, boolean and accessor values',()=>{
 for(const id of [-1,65536,1.5,'321',true,NaN]){const f=setup(),c=f.card();attachRealCard(f,c,{id,type:1,color:1,num:3});assert.ok(!field(f.probe().cards[0],'cardInfo').fields.some(f=>f.name==='id'));}
 const f=setup(),c=f.card(),info={type:1,color:1,num:3};let calls=0;Object.defineProperty(info,'id',{get(){calls++;throw Error('id getter');}});attachRealCard(f,c,info);assert.ok(!field(f.probe().cards[0],'cardInfo').fields.some(f=>f.name==='id'));assert.equal(calls,0);
});

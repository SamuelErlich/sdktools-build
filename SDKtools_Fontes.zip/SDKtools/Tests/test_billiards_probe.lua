-- Executed in an isolated stock Lua 5.3 state by test_billiards_probe.py.
-- No game resources/binaries are executed. Mocks model observer contracts only.
local caseName, probePath, capturedSource = ...
assert(_VERSION == "Lua 5.3", "Lua 5.3 required")
local probe = assert(loadfile(probePath))
-- Fault-inject smaller LOCAL budgets to exercise each fail-closed branch without
-- relying on pathological billiard layouts. Production defaults stay unchanged.
if caseName:match("^chain_budget_") then
    local file=assert(io.open(probePath,"r"));local source=file:read("*a");file:close()
    local count
    if caseName=="chain_budget_query" then
        source,count=source:gsub("16, 96, 96, 48", "16, 96, 2, 48",1)
    elseif caseName=="chain_budget_segment" then
        source,count=source:gsub("16, 96, 96, 48", "16, 96, 96, 2",1)
    elseif caseName=="chain_budget_event" then
        source,count=source:gsub("MAX_EVENTS, HORIZON = 64, 40", "MAX_EVENTS, HORIZON = 1, 40",1)
    end
    assert(count==1,"budget injection did not match production declaration")
    probe=assert(load(source,"@bounded_probe_fixture","t",_G))
end
local function v(x,y,z) return {x=x,y=y,z=z} end
local currentScene = {name="BilliardInGame",handle=41,isLoaded=true}
local queries, mode, modal, throwQuery, liveFrame = 0, "bank", false, false, nil
local queryOrigins, customHits = {}, nil
local function object(id,name,tag)
    return {name=name,tag=tag,layer=0,scene=currentScene,activeInHierarchy=true,GetInstanceID=function() return id end}
end
local function ball(tag,z)
    local go=object(100+tag,"Ball(Clone)","Ball")
    local tr={gameObject=go,position=v(0,0,z),lossyScale=v(.33,.33,.33)}
    go.transform=tr
    local col={transform=tr,gameObject=go,enabled=true,isTrigger=false,radius=.5,
        GetInstanceID=function() return 200+tag end}
    return {ballTag=tag,ballNum=tag-1,ballActive=true,poted=false,gameObject=go,transform=tr,
        collider=col,rigidbody={velocity=v(0,0,0),angularVelocity=v(0,0,0)},ballInMovement=false}
end
local white,target=ball(1,0),ball(2,2)
target.transform.position.x=3
local targetHitCollider=target.collider
local function environmentCollider(id,name,tag,trigger)
    local go=object(id,name,tag)
    local tr={gameObject=go};go.transform=tr
    return {transform=tr,gameObject=go,isTrigger=trigger,GetInstanceID=function() return id+1000 end}
end
local cushion=environmentCollider(301,"bumpers","bumper",false)
local pocket=environmentCollider(302,"potUpCenter","Pot2",true)
local unknown=environmentCollider(303,"unexpected","Unexpected",false)
local foreignBall=environmentCollider(304,"Ball(Clone)","Ball",false)
local surface=environmentCollider(305,"canvas","Untagged",false)
pocket.gameObject.layer=19;surface.gameObject.layer=19
local camgo=object(401,"MainCamera","MainCamera")
local camera={gameObject=camgo,isActiveAndEnabled=true,orthographic=true,
    transform={right=v(1,0,0)},GetInstanceID=function() return 501 end,
    WorldToScreenPoint=function(_,p) return v(540+p.x*100,960+p.z*100,9.1) end}
local frame={balls={white,target},started=true,canShot=true,isServer=true,offlineMode=false,
    frameStateLogic={turnData={myTurn=true}},ballsInMovement=false,
    auxiliaryLine={auxData={shown=true,cueStartPos=v(0,0,0),cueEndPos=v(0,0,1.67)}},
    curDir=v(0,0,1),gameView={cueCom={visible=true},cueTouchable=true},
    uiLogic={isUIShow=function() return modal end},moveBallScript={ballInHand=false},
    tutorialView={cue={visible=true},cueTouchable=true}}
liveFrame=frame
_G.Enum={Billiard={GameType=1003,Logic={
    frame={Name="Game/BiFrameLogic",PkgName="Billiard"},
    tutorial={Name="Game/BiTutorialLogic",PkgName="Billiard"}}}}
_G.Const={Billiard={GameType=1003,BALL_RADIUS=.165,UIName={CuePositionDialogPanel="BiCuePositionDialogPanel"}}}
_G.Core={logicMgr={get=function(_,descriptor) return liveFrame end}}
local function hit(col,distance,normal) return {collider=col,distance=distance,normal=normal or v(0,0,-1)} end
local function hits(items)
    local a={Length=#items};for i,h in ipairs(items) do a[i-1]=h end;return a
end
_G.CS={UnityEngine={
    SceneManagement={SceneManager={GetActiveScene=function() return currentScene end}},
    Vector3=v,Camera={main=camera},Screen={width=1080,height=1920},Time={frameCount=100},
    QueryTriggerInteraction={Collide=2},
    Physics={queriesHitTriggers=true,SphereCastAll=function(origin,radius,direction,distance,mask,triggerPolicy)
        queries=queries+1
        assert(mask==524289 and math.abs(radius-.165)<1e-6 and distance==20,"invalid query contract")
        queryOrigins[#queryOrigins+1]={origin=v(origin.x,origin.y,origin.z),direction=direction}
        if CS.UnityEngine.Physics.queriesHitTriggers==false then assert(triggerPolicy==2) end
        local function filtered(items)
            local kept={}
            for _,item in ipairs(items) do
                local layer=item.collider.gameObject and item.collider.gameObject.layer or 0
                if math.floor(mask/2^layer)%2==1 and
                    (not item.collider.isTrigger or triggerPolicy==2 or CS.UnityEngine.Physics.queriesHitTriggers) then
                    kept[#kept+1]=item
                end
            end
            return hits(kept)
        end
        if throwQuery then error("controlled query failure") end
        if customHits then return filtered(customHits(origin,radius,direction,distance,queries)) end
        if mode=="open" then return hits({}) end
        if mode=="pocket" then return filtered({hit(pocket,2),hit(cushion,4),hit(surface,.001,v(0,1,0))}) end
        if mode=="unknown" then return filtered({hit(unknown,1),hit(cushion,2)}) end
        if mode=="unmapped" then return filtered({hit(foreignBall,1),hit(cushion,2)}) end
        if mode=="hit_limit" then return {Length=97} end
        if mode=="nan_hit" then return filtered({hit(cushion,0/0)}) end
        if mode=="bad_normal" then return filtered({hit(cushion,1,v(0,1,0))}) end
        if mode=="ball" or mode=="cut" or mode=="open_branch" or mode=="chain" then
            if mode=="open_branch" and queries==2 then return hits({}) end
            -- Native ball colliders deliberately remain at obsolete locations;
            -- the observer must ignore them for all synthetic moving balls.
            -- A fixed pocket plane, not eight units from every new origin.
            -- The latter placed the third-ball endpoint at z=12 (screen y=2160)
            -- outside the 1920px viewport and correctly failed native guards.
            local pocketDistance=5
            if mode=="chain" then
                assert(direction.z>0,"chain fixture must approach its pocket")
                pocketDistance=(8-origin.z)/direction.z
                assert(pocketDistance>=0 and pocketDistance<=distance,"invalid fixture pocket distance")
            end
            local items={hit(pocket,pocketDistance),
                hit(targetHitCollider,.02),hit(white.collider,.01)}
            return filtered(items)
        end
        -- Deliberately unsorted. Own and canvas colliders must not block paths.
        return filtered({hit(unknown,15),hit(cushion,2,v(0,0,-direction.z)),
            hit(white.collider,.01),hit(surface,.001,v(0,1,0))})
    end}
}}
local function clone(a,seen)
    if type(a)~="table" then return a end
    seen=seen or {};if seen[a] then return seen[a] end
    local b={};seen[a]=b
    for k,vv in pairs(a) do b[k]=clone(vv,seen) end
    return b
end
local function equal(a,b,seen)
    if type(a)~=type(b) then return false end
    if type(a)~="table" then return a==b or (type(a)=="number" and a~=a and b~=b) end
    seen=seen or {};if seen[a] then return seen[a]==b end;seen[a]=b
    for k,vv in pairs(a) do if not equal(vv,b[k],seen) then return false end end
    for k in pairs(b) do if a[k]==nil then return false end end
    return true
end
local function run(command)
    local original={frame=frame,enum=rawget(_G,"Enum"),constants=rawget(_G,"Const"),
        core=rawget(_G,"Core"),engine=rawget(_G,"CS")}
    local before=clone(original)
    local keys={};for k in pairs(_G) do keys[k]=true end
    local value=probe(command or "sample")
    assert(equal(original,before),"observer modified game/mock state")
    for k in pairs(_G) do assert(keys[k] or k=="__SDKtoolsBilliards315","unexpected global write: "..k) end
    assert(type(value)=="string" and #value<=65536,"bounded JSON return required")
    assert(queries<=96,"query budget exceeded")
    return value
end
if caseName=="loaded_modules" or caseName:match("^resolver_") then
    local originalEnum,originalConst,originalCore=Enum,Const,Core
    local enum,constants=originalEnum.Billiard,originalConst.Billiard
    local manager=originalCore.logicMgr
    local effects={require=0,initializers=0,index=0,manager=0}
    local realGetmetatable=getmetatable
    local function forbiddenIndex()
        effects.index=effects.index+1;error("DO_NOT_EXPORT_PRIVATE_INDEX")
    end
    require=function() effects.require=effects.require+1;error("require must not run") end
    local init=assert(load("return function(mark) return function() "..
        "mark.initializers=mark.initializers+1;return Enum, Const end end","fixture","t",_G))()(effects)
    package.loaded={
        ["Billiard/Lua/Const/Enum"]=enum,["Billiard/Lua/Const/Const"]=constants,
        ["Billiard/Lua/Const/Init"]=init}
    local loaded=package.loaded
    rawset(_G,"Enum",nil);rawset(_G,"Const",nil)
    setmetatable(_G,{__index=forbiddenIndex})
    frame.Destroyed=false
    manager.get=function(self,descriptor)
        effects.manager=effects.manager+1
        assert(rawequal(self,manager),"wrong manager receiver")
        local expected=currentScene.name=="BilliardTutorial" and enum.Logic.tutorial or enum.Logic.frame
        assert(rawequal(descriptor,expected),"descriptor was synthesized or copied")
        if caseName=="resolver_frame_throw" then error("DO_NOT_EXPORT_PRIVATE_FRAME_ERROR") end
        if caseName=="resolver_frame_nil" then return nil end
        if caseName=="resolver_frame_wrong" then return false end
        return frame
    end
    local getter=manager.get
    if caseName=="loaded_modules" or caseName=="resolver_cached_unload" then
        -- Captured V3.16 layout: same root _ENV, functional global lookup, cached modules.
    elseif caseName=="resolver_tutorial" then currentScene.name="BilliardTutorial"
    elseif caseName=="resolver_partial_enum" then rawset(_G,"Enum",originalEnum)
    elseif caseName=="resolver_partial_const" then rawset(_G,"Const",originalConst)
    elseif caseName=="resolver_global_preferred" then
        rawset(_G,"Enum",originalEnum);rawset(_G,"Const",originalConst)
        loaded["Billiard/Lua/Const/Enum"]={GameType=2007}
        loaded["Billiard/Lua/Const/Const"]={GameType=2007}
    elseif caseName=="resolver_namespace_wrong" then rawset(_G,"Enum",false)
    elseif caseName=="resolver_global_module_wrong" then rawset(_G,"Enum",{Billiard=false})
    elseif caseName=="resolver_partial_conflict_enum" then rawset(_G,"Enum",clone(originalEnum))
    elseif caseName=="resolver_partial_conflict_const" then rawset(_G,"Const",clone(originalConst))
    elseif caseName=="resolver_wrong_game_type" then enum.GameType=2007
    elseif caseName=="resolver_string_game_type" then constants.GameType="1003"
    elseif caseName=="resolver_nonfinite_game_type" then enum.GameType=0/0
    elseif caseName=="resolver_module_wrong" then loaded["Billiard/Lua/Const/Const"]=false
    elseif caseName=="resolver_missing_module" then loaded["Billiard/Lua/Const/Const"]=nil
    elseif caseName=="resolver_no_canonical" then
        loaded["Billiard/Lua/Const/Enum"],loaded["Billiard/Lua/Const/Const"]=nil,nil
        loaded["billiard/lua/const/enum"],loaded["billiard/lua/const/const"]=enum,constants
    elseif caseName=="resolver_package_proxy" then package=setmetatable({},{__index=forbiddenIndex})
    elseif caseName=="resolver_loaded_proxy" then
        loaded["Billiard/Lua/Const/Enum"],loaded["Billiard/Lua/Const/Const"]=nil,nil
        setmetatable(loaded,{__index=forbiddenIndex})
    elseif caseName=="resolver_game_type_proxy" then
        enum.GameType=nil;setmetatable(enum,{__index=forbiddenIndex})
    elseif caseName=="resolver_descriptor_missing" then enum.Logic.frame=nil
    elseif caseName=="resolver_descriptor_invalid_name" then enum.Logic.frame.Name="DO_NOT_EXPORT_PRIVATE_NAME"
    elseif caseName=="resolver_descriptor_invalid_package" then enum.Logic.frame.PkgName="DO_NOT_EXPORT_PRIVATE_PKG"
    elseif caseName=="resolver_descriptor_wrong_scene" then enum.Logic.frame.Name="Game/BiTutorialLogic"
    elseif caseName=="resolver_descriptor_wrong_type" then enum.Logic.frame="DO_NOT_EXPORT_PRIVATE_DESCRIPTOR"
    elseif caseName=="resolver_descriptor_proxy" then
        enum.Logic.frame=nil;setmetatable(enum.Logic,{__index=forbiddenIndex})
    elseif caseName=="resolver_descriptor_field_proxy" then
        enum.Logic.frame.Name=nil;setmetatable(enum.Logic.frame,{__index=forbiddenIndex})
    elseif caseName=="resolver_global_namespace_proxy" then
        rawset(_G,"Enum",setmetatable({},{__index=forbiddenIndex}))
    elseif caseName=="resolver_manager_nil" then originalCore.logicMgr=nil
    elseif caseName=="resolver_manager_wrong" then originalCore.logicMgr="DO_NOT_EXPORT_PRIVATE_MANAGER"
    elseif caseName=="resolver_manager_proxy" then
        originalCore.logicMgr=nil;setmetatable(originalCore,{__index=forbiddenIndex})
    elseif caseName=="resolver_manager_table" then
        originalCore.logicMgr=nil;setmetatable(originalCore,{__index={logicMgr=manager}})
    elseif caseName=="resolver_getter_missing" then manager.get=nil
    elseif caseName=="resolver_getter_wrong" then manager.get=false
    elseif caseName=="resolver_getter_blocked" then manager.get=nil;setmetatable(manager,{__index=forbiddenIndex})
    elseif caseName=="resolver_getter_protected" then
        manager.get=nil;setmetatable(manager,{__index={get=getter},__metatable="protected fixture"})
    elseif caseName=="resolver_getter_cycle" then manager.get=nil;setmetatable(manager,{__index=manager})
    elseif caseName=="resolver_getter_depth_limit" or caseName=="resolver_getter_depth_four" then
        manager.get=nil
        local cursor=manager
        for _=1,(caseName=="resolver_getter_depth_four" and 4 or 5) do
            local child={};setmetatable(cursor,{__index=child});cursor=child
        end
        cursor.get=getter
    elseif caseName=="resolver_getter_error" then
        manager.get=nil;getmetatable=function(value)
            if rawequal(value,manager) then error("DO_NOT_EXPORT_PRIVATE_META_ERROR") end
            return realGetmetatable(value)
        end
    elseif caseName=="resolver_getter_table" then manager.get=nil;setmetatable(manager,{__index={get=getter}})
    elseif caseName=="resolver_frame_throw" or caseName=="resolver_frame_nil" or caseName=="resolver_frame_wrong" then
        -- Controlled return values are handled by the one protected getter above.
    elseif caseName=="resolver_frame_destroyed" then frame.Destroyed=true
    elseif caseName=="resolver_camera_gate" then camera.orthographic=false
    elseif caseName=="resolver_moving_gate" then white.rigidbody.velocity.z=.003
    elseif caseName=="resolver_scene_gate" then currentScene.name="CrazyAlpaca"
    else error("unknown resolver case: "..caseName) end
    local first
    if caseName=="resolver_cached_unload" then
        first=run()
        assert(effects.manager==1,"initial cached lookup did not reach getter")
        queries,effects.manager=0,0
        loaded["Billiard/Lua/Const/Enum"],loaded["Billiard/Lua/Const/Const"]=nil,nil
    end
    local cachedBefore=clone(loaded)
    local value=run()
    assert(equal(loaded,cachedBefore),"resolver modified cached module state")
    assert(effects.require==0 and effects.initializers==0 and effects.index==0,
        "resolver invoked loader, initializer or functional lookup")
    assert(effects.manager<=1,"resolver invoked getter more than once")
    assert(effects.manager==(value:find('"frameCallAttempted":true',1,true) and 1 or 0),
        "getter call telemetry does not match observed calls")
    assert(not value:find("DO_NOT_EXPORT",1,true),"private value/error leaked")
    assert(not value:find("0x[%da-fA-F]+"),"address leaked")
    for key,item in pairs(__SDKtoolsBilliards315) do
        if type(item)=="table" then assert(key=="frameRef","resolver retained module references") end
    end
    return first and first.."\n"..value or value
end
if caseName:match("^env_") then
    local originalEnum,originalConst,originalCore=Enum,Const,Core
    local realGetmetatable=getmetatable
    local effects={require=0,initializers=0,index=0,manager=0}
    package.loaded={}
    local loaded=package.loaded
    require=function() effects.require=effects.require+1;error("require must not run") end
    originalCore.logicMgr.get=function() effects.manager=effects.manager+1;error("manager must not run") end
    rawset(_G,"Enum",nil);rawset(_G,"Const",nil)
    local function makeModule(env)
        return assert(load("return function() return Enum, Const end", "fixture", "t",env))()
    end
    local function altEnvironment()
        return {Enum=originalEnum,Const=originalConst,Core=originalCore}
    end
    if caseName=="env_raw_absent" then
        originalCore.logicMgr.get=function() effects.manager=effects.manager+1;return nil end
        loaded["Billiard/Lua/Const/Enum"]=originalEnum.Billiard
        loaded["Billiard/Lua/Const/Const"]=originalConst.Billiard
        loaded["Billiard/Lua/Const/Init"]=makeModule(_G)
    elseif caseName=="env_raw_other" then
        rawset(_G,"Enum",false);rawset(_G,"Const","DO_NOT_EXPORT_PRIVATE_VALUE")
        rawset(_G,"BiLogic",42)
    elseif caseName=="env_metatable_table" then
        setmetatable(_G,{__index={Enum=originalEnum,Const=originalConst}})
    elseif caseName=="env_function_blocked" then
        setmetatable(_G,{__index=function() effects.index=effects.index+1;error("index must not run") end})
    elseif caseName=="env_protected" then
        setmetatable(_G,{__index={Enum=originalEnum},__metatable="protected fixture"})
    elseif caseName=="env_cycle" then
        local inherited={};setmetatable(inherited,{__index=_G})
        setmetatable(_G,{__index=inherited})
    elseif caseName=="env_depth_limit" then
        local inherited=_G
        for _=1,5 do local nextTable={};setmetatable(inherited,{__index=nextTable});inherited=nextTable end
        inherited.Enum=originalEnum
    elseif caseName=="env_metatable_error" then
        getmetatable=function(value)
            if rawequal(value,_G) then error("DO_NOT_EXPORT_PRIVATE_ERROR") end
            return realGetmetatable(value)
        end
    elseif caseName=="env_distinct" then
        loaded["Billiard/Lua/Const/Init"]=makeModule(altEnvironment())
    elseif caseName=="env_alias" then
        local env=altEnvironment()
        loaded["Billiard/Lua/Const/Init"]=makeModule(env)
        loaded["billiard/lua/const/init"]=makeModule(env)
    elseif caseName=="env_nested_index_blocked" then
        local env=altEnvironment()
        env.Core={logicMgr=setmetatable({}, {__index=function()
            effects.index=effects.index+1;error("manager proxy must not run")
        end})}
        loaded["Billiard/Lua/Const/Init"]=makeModule(env)
    elseif caseName=="env_invalid_game_type" then
        local env=altEnvironment()
        env.Enum={Billiard={GameType="1003",Logic={frame="BiFrameLogic",tutorial="BiTutorial"}}}
        env.Const={Billiard={GameType=0/0}}
        loaded["Billiard/Lua/Const/Init"]=makeModule(env)
        loaded["Billiard/Lua/Const/Enum"]={GameType=2147483648}
    elseif caseName=="env_no_debug" then
        loaded["Billiard/Lua/Const/Init"]=makeModule(altEnvironment())
        rawset(_G,"debug",nil)
    elseif caseName=="env_debug_error" then
        loaded["Billiard/Lua/Const/Init"]=makeModule(altEnvironment())
        debug={getupvalue=function() error("DO_NOT_EXPORT_PRIVATE_ERROR") end}
    elseif caseName=="env_no_env" then
        loaded["Billiard/Lua/Const/Init"]=function() effects.initializers=effects.initializers+1 end
    elseif caseName=="env_non_table_env" then
        local fn=makeModule(false)
        loaded["Billiard/Lua/Const/Init"]=fn
    elseif caseName=="env_upvalue_limit" then
        local names={};for i=1,16 do names[i]="a"..i end
        local source="local "..table.concat(names,",")..";return function() return "..
            table.concat(names,",")..",Enum end"
        loaded["Billiard/Lua/Const/Init"]=assert(load(source,"fixture","t",altEnvironment()))()
    elseif caseName=="env_environment_limit" then
        for i=1,12 do loaded["Billiard/Lua/Fixture"..i]=makeModule(altEnvironment()) end
    elseif caseName=="env_scan_limit" then
        for i=1,600 do loaded["Billiard/Lua/Fixture"..i]={GameType=1003} end
    elseif caseName=="env_unknown_module" then
        loaded["Billiard/Lua/PreviouslyUnknown"]=makeModule(altEnvironment())
        loaded["Billiard.Lua.Dotted"]=originalEnum.Billiard
        loaded["OtherGame/Lua/Init"]=function() error("foreign module executed") end
        loaded["Billiard/../secret"]=true
        loaded["Billiard/Lua/secret\nvalue"]=true
        loaded["Billiard/"..string.rep("x",100)]=true
    elseif caseName=="env_loaded_proxy_blocked" then
        package=setmetatable({}, {__index=function() effects.index=effects.index+1;error("loader invoked") end})
    elseif caseName=="env_sequence" then
        loaded["Billiard/Lua/Const/Init"]=makeModule(altEnvironment())
    else error("unknown environment case: "..caseName) end
    local value=run()
    if caseName=="env_sequence" then value=value.."\n"..run() end
    assert(queries==0 and effects.require==0 and effects.initializers==0 and effects.index==0,
        "diagnostic invoked gameplay/loader code")
    assert(effects.manager==(caseName=="env_raw_absent" and 1 or 0),"unexpected getter call count")
    assert(not value:find("DO_NOT_EXPORT",1,true),"private value/error leaked")
    assert(not value:find("0x[%da-fA-F]+"),"address leaked")
    -- The only persistent additions are scalar metadata. No loaded module or
    -- discovered environment is retained across sampling invocations.
    for key,item in pairs(__SDKtoolsBilliards315) do
        if type(item)=="table" then assert(key=="frameRef","environment retained in observer state") end
    end
    return value
end
local function place(tag,x,z)
    local item=tag==1 and white or tag==2 and target or ball(tag,z)
    item.transform.position=v(x,0,z);frame.balls[tag]=item
    return item
end
local function aim(x,z)
    local n=math.sqrt(x*x+z*z);frame.curDir=v(x/n,0,z/n)
    frame.auxiliaryLine.auxData.cueStartPos=clone(white.transform.position)
    frame.auxiliaryLine.auxData.cueEndPos=v(white.transform.position.x+x/n,0,white.transform.position.z+z/n)
end
local function boxHits(origin,radius,direction,_,count)
    local items={hit(surface,.001,v(0,1,0)),hit(white.collider,.0001),hit(targetHitCollider,.0002)}
    local planes={{"x",4-radius,v(-1,0,0)},{"x",-4+radius,v(1,0,0)},
        {"z",6-radius,v(0,0,-1)},{"z",-6+radius,v(0,0,1)}}
    for _,plane in ipairs(planes) do
        local axis,coordinate,normal=plane[1],plane[2],plane[3]
        if math.abs(direction[axis])>1e-9 then
            local t=(coordinate-origin[axis])/direction[axis]
            if t>=0 and t<=20 then items[#items+1]=hit(cushion,t,normal) end
        end
    end
    return items
end
if caseName=="chain_three_balls" or caseName:match("^chain_budget_") then
    mode="chain";place(2,0,2);place(3,0,4);return run()
elseif caseName=="chain_bank_then_ball" then
    customHits=boxHits;place(2,2.451,3.5);aim(.3,1)
    local value=run()
    local second=queryOrigins[2]
    assert(second.origin.z<5.835 and second.origin.z>5.834,
        "post-rail query must move inward without changing trajectory origin")
    return value
elseif caseName=="chain_touching" then
    mode="chain";place(2,0,.33);place(3,0,.66);return run()
elseif caseName=="chain_simultaneous" then
    mode="chain";place(2,-.2,2);place(3,.2,2);return run()
elseif caseName=="chain_corner" then
    aim(1,1)
    customHits=function() return {hit(cushion,2,v(-1,0,0)),hit(cushion,2,v(0,0,-1))} end
    return run()
elseif caseName=="chain_overlap" then
    mode="chain";place(2,0,.2);return run()
elseif caseName=="chain_moving_collision" then
    customHits=boxHits;place(2,.2,2);place(3,-.7,2.9);place(4,1.3,3.5);return run()
elseif caseName=="chain_zero_cushion" then
    customHits=function() return {hit(cushion,0,v(0,0,-1))} end;return run()
elseif caseName=="chain_zero_pocket" then
    customHits=function() return {hit(pocket,0)} end;return run()
elseif caseName=="chain_partial_overlap" or caseName=="chain_partial_unknown" then
    mode="chain";place(2,0,2)
    customHits=function(_,_,_,_,count)
        return count==1 and {hit(pocket,8)} or
            {caseName=="chain_partial_unknown" and hit(unknown,2) or hit(cushion,0,v(0,0,-1))}
    end
    return run()
elseif caseName=="chain_horizon" then
    customHits=boxHits;place(2,3,2);aim(.123,1);return run()
elseif caseName=="chain_real_capture" then
    -- Real captured table geometry, with mock empty rails. This validates the
    -- first ball contacts only, not a real-shot outcome or later bank dynamics.
    local captured=assert(load(capturedSource,"@captured_geometry","t",{}))()
    frame.balls={}
    for _,item in ipairs(captured.balls) do place(item.tag,item.world.x,item.world.z) end
    aim(captured.cue.direction.x,captured.cue.direction.z)
    customHits=function() return {hit(white.collider,.01),hit(targetHitCollider,.02)} end
    return run()
end
if caseName=="bank" then return run()
elseif caseName=="ball" then mode="ball";target.transform.position.x=0;return run()
elseif caseName=="child_collider" then
    mode="ball";target.transform.position.x=0
    local childGO=object(700,"BallMesh","Untagged")
    targetHitCollider={GetInstanceID=function() return 701 end,isTrigger=false,
        transform={gameObject=childGO,parent=target.transform}}
    return run()
elseif caseName=="unknown_trigger_policy" then CS.UnityEngine.Physics.queriesHitTriggers=nil;return run()
elseif caseName=="foreign_hit_scene" then mode="pocket";pocket.gameObject.scene={handle=999};return run()
elseif caseName=="cut" then mode="cut";target.transform.position.x=.2;return run()
elseif caseName=="open_branch" then mode="open_branch";target.transform.position.x=.2;return run()
elseif caseName=="open" then mode="open";return run()
elseif caseName=="pocket" then mode="pocket";return run()
elseif caseName=="explicit_triggers" then mode="pocket";CS.UnityEngine.Physics.queriesHitTriggers=false;return run()
elseif caseName=="unknown" or caseName=="unmapped" or caseName=="hit_limit" or caseName=="nan_hit" or caseName=="bad_normal" then mode=caseName;return run()
elseif caseName=="moving" then white.rigidbody.velocity.z=.003;local s=run();assert(queries==0);return s
elseif caseName=="angular" then white.rigidbody.angularVelocity.y=.21;local s=run();assert(queries==0);return s
elseif caseName=="moving_flag" then frame.ballsInMovement=true;local s=run();assert(queries==0);return s
elseif caseName=="not_turn" then frame.isServer=false;local s=run();assert(queries==0);return s
elseif caseName=="contradictory_turn" then frame.frameStateLogic.turnData.myTurn=false;local s=run();assert(queries==0);return s
elseif caseName=="foreign_scene" then currentScene.name="CrazyAlpaca";local s=run();assert(queries==0);return s
elseif caseName=="scene_not_loaded" then currentScene.isLoaded=false;local s=run();assert(queries==0);return s
elseif caseName=="wrong_type" then Const.Billiard.GameType=2007;local s=run();assert(queries==0);return s
elseif caseName=="modal" then modal=true;local s=run();assert(queries==0);return s
elseif caseName=="hand" then frame.moveBallScript.ballInHand=true;local s=run();assert(queries==0);return s
elseif caseName=="hidden" then frame.gameView.cueCom.visible=false;local s=run();assert(queries==0);return s
elseif caseName=="stale_aim" then frame.auxiliaryLine.auxData.cueStartPos.x=.1;local s=run();assert(queries==0);return s
elseif caseName=="stale_angle" then frame.curDir=v(1,0,0);local s=run();assert(queries==0);return s
elseif caseName=="duplicate_tag" then target.ballTag=1;target.ballNum=0;local s=run();assert(queries==0);return s
elseif caseName=="reused_object" then target.gameObject=white.gameObject;target.collider=white.collider;local s=run();assert(queries==0);return s
elseif caseName=="potted" then target.poted=true;target.ballActive=false;target.gameObject=nil;target.collider=nil;return run()
elseif caseName=="bad_position" then white.transform.position.x=0/0;local s=run();assert(queries==0);return s
elseif caseName=="camera_scene" then camera.gameObject.scene={handle=42};local s=run();assert(queries==0);return s
elseif caseName=="query_error" then throwQuery=true;return run()
elseif caseName=="destroyed_ball" then white.gameObject.GetInstanceID=function() error("destroyed") end;local s=run();assert(queries==0);return s
elseif caseName=="too_many_balls" then frame.balls[17]=ball(17,3);local s=run();assert(queries==0);return s
elseif caseName=="zero_direction" then frame.curDir=v(0,0,0);local s=run();assert(queries==0);return s
elseif caseName=="tutorial" then currentScene.name="BilliardTutorial";frame.isServer=false;return run()
elseif caseName=="unsupported_command" then local s=run("write");assert(queries==0);return s
elseif caseName=="stop" then local first=run();queries=0;local second=run("stop");assert(queries==0);return first.."\n"..second
elseif caseName=="sessions" then
    local values={run()};queries=0;CS.UnityEngine.Time.frameCount=101;values[#values+1]=run()
    queries=0;liveFrame=clone(frame);values[#values+1]=run()
    queries=0;camera.GetInstanceID=function() return 502 end;values[#values+1]=run()
    queries=0;currentScene.handle=42;values[#values+1]=run()
    return table.concat(values,"\n")
elseif caseName=="weak_state" then
    local s=run();assert(getmetatable(__SDKtoolsBilliards315.frameRef).__mode=="v")
    for _,value in pairs(__SDKtoolsBilliards315) do assert(value~=frame,"strong frame reference") end
    return s
end
error("unknown test case: "..tostring(caseName))

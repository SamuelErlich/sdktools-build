"""License UI source contracts; UIKit behavior still needs an iPhone build."""
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class LicenseUIContracts(unittest.TestCase):
    def test_pending_source_share_requires_current_license(self):
        source=(ROOT/'Sources/SDKtools/STOverlay.m').read_text(encoding='utf-8')
        method=source.split('- (void)presentPendingSourceExport {',1)[1].split('\n- (',1)[0]
        self.assertIn('!STLicenseManager.shared.authorized',method)
        self.assertLess(method.index('!STLicenseManager.shared.authorized'),method.index('UIActivityViewController'))
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / "Sources/SDKtools/STOverlay.m").read_text(encoding="utf-8")
        cls.controller = cls.source.split("@implementation STOverlayController", 1)[1].split("@implementation STOverlay\n", 1)[0]

    def controller_method(self, signature):
        return self.controller.split(signature + " {", 1)[1].split("\n- (", 1)[0]

    def test_key_entry_is_secure_explicit_and_cleared_before_submission(self):
        self.assertIn("self.licenseKeyField.secureTextEntry=YES", self.controller)
        activate = self.controller_method("- (void)activateLicense")
        self.assertLess(activate.index('self.licenseKeyField.text=@""'), activate.index("activateKey:key"))
        self.assertIn("resignFirstResponder", activate)
        self.assertNotIn("UIPasteboard", activate)
        self.assertNotIn("NSUserDefaults", activate)
        self.assertIn("textFieldDidEndEditing:", self.controller)
        self.assertIn("licenseInputHostWindow", self.controller)

    def test_input_rejects_oversize_and_non_ascii_before_replacement(self):
        edit = self.controller_method("- (BOOL)textField:(UITextField *)field shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)replacement")
        self.assertIn("value.length>256", edit)
        self.assertIn("c<0x21 || c>0x7e", edit)
        self.assertIn("range.length>field.text.length-range.location", edit)

    def test_saved_key_has_retry_and_replace_without_key_display(self):
        update = self.controller_method("- (void)updateLicenseUI")
        self.assertIn("license.savedKeyAvailable", update)
        self.assertIn("self.licenseKeyField.hidden=license.savedKeyAvailable", update)
        self.assertIn("self.licenseRetryButton.hidden=!license.savedKeyAvailable", update)
        self.assertIn("[STLicenseManager.shared resume]", self.controller_method("- (void)retryLicense"))
        self.assertIn("[STLicenseManager.shared forgetKey]", self.controller_method("- (void)changeLicense"))
        self.assertNotIn("savedKey]", update)

    def test_unlicensed_menu_hides_gameplay_and_preserves_compact_layout(self):
        update = self.controller_method("- (void)updateLicenseUI")
        self.assertIn("self.licenseContainer.hidden=authorized", update)
        self.assertIn("self.gameTabs.hidden=!authorized", update)
        self.assertIn("self.lanButton.hidden=!authorized", update)
        self.assertIn("self.licenseFooterButton.hidden=!authorized", update)
        self.assertIn("self.moduleBodies[i].hidden=!authorized || !selected", self.controller)
        self.assertIn("BOOL showDock=STLicenseManager.shared.authorized &&", self.controller)
        self.assertIn("STCompactMenuFit(safe.size.width,safe.size.height,content.height)", self.controller)

    def test_lifecycle_and_fresh_action_check_use_manager(self):
        self.assertIn("name:STLicenseDidChangeNotification", self.source)
        self.assertIn("[STLicenseManager.shared start]", self.source)
        active = self.source.split("- (void)becameActive:", 1)[1].split("\n- (", 1)[0]
        self.assertIn("[STLicenseManager.shared resume]", active)
        allows = self.source.split("- (BOOL)clientAllowsGame:", 1)[1].split("\n- (", 1)[0]
        self.assertLess(allows.index("!STLicenseManager.shared.authorized"), allows.index("STClientCanModify"))

    def test_revocation_stops_owned_replaykit_without_resetting_game_latches(self):
        changed = self.source.split("- (void)licenseChanged:", 1)[1].split("\n- (", 1)[0]
        self.assertIn("!STLicenseManager.shared.authorized && self.ownsReplayKit", changed)
        self.assertIn("self.videoState==STVideoStarting)self.stopWhenStarted=YES", changed)
        self.assertIn("self.videoState==STVideoRecording)[self stopVideo]", changed)
        self.assertNotIn("stopAllWithReason", changed)
        video = self.source.split("- (void)toggleVideo {", 1)[1].split("\n- (", 1)[0]
        self.assertLess(video.index("[self stopVideo]"), video.index("!STLicenseManager.shared.authorized"))

    def test_all_new_license_copy_is_bilingual(self):
        rows = json.loads((ROOT / "Resources/Brand/menu-localizations.json").read_text(encoding="utf-8"))["entries"]
        by_english = {row["en"]: row["pt"] for row in rows}
        for text in ("Activate SDK Client", "License key", "Activate", "Try again", "Change license", "License active", "Valid until %@"):
            self.assertIn(text, by_english)
            self.assertTrue(by_english[text])


if __name__ == "__main__":
    unittest.main()

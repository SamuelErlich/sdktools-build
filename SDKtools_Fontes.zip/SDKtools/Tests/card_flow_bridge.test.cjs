'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const bridge=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STCardFlowBridge.inc'),'utf8');
const body=bridge.match(/return \[NSString stringWithFormat:([\s\S]*?), sceneScript,/)[1];
const template=[...body.matchAll(/@"((?:\\.|[^"\\])*)"/g)].map(x=>JSON.parse('"'+x[1]+'"')).join('');
const outer=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STCardInvestigationBridge.inc'),'utf8');
const outerBody=outer.match(/return \[NSString stringWithFormat:([\s\S]*?)\n\s*namespaceKey/)[1];
const outerTemplate=[...outerBody.matchAll(/@"((?:\\.|[^"\\])*)"/g)].map(x=>JSON.parse('"'+x[1]+'"')).join('');
const actual=fs.readFileSync(path.join(__dirname,'../Resources/card_flow.js'),'utf8');
function format(t,args){let n=0;const out=t.replace(/%@/g,()=>args[n++]);assert.equal(n,args.length);return out;}
function sample(ctx,expected='',scene='(function(){return function(){return {version:2,status:"cocos2_scene_captured"};};}())',flow=actual){
  const composed=format(template,[scene,flow]);return vm.runInContext(format(outerTemplate,['__sdk',expected,composed,'function(){return function(){return {version:1,status:"ready",reason:"captured",cards:[]};};}','doc1']),ctx);
}
test('production composition and outer bridge return serializable independent flow diagnostics',()=>{
  const ctx=vm.createContext({window:{performance:{now:()=>0}},document:{}});const result=sample(ctx);assert.equal(result.contextID,'doc1');assert.equal(result.cardFlow.reason,'unsupported_engine');assert.equal(result.cardInvestigation.status,'ready');assert.doesNotThrow(()=>JSON.stringify(result));assert.equal(sample(ctx,'doc1').contextID,'doc1');
});
test('namespace cleanup runs clear once and removes the SDK namespace',()=>{
  const ctx=vm.createContext({window:{},cleared:0});sample(ctx,'',undefined,'function(){return {tick:function(){return {version:1,events:[]};},clear:function(){cleared++;}};}');
  const source=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STWebProbe.m'),'utf8');const raw=source.match(/NSString \*cleanup = \[NSString stringWithFormat:@"((?:\\.|[^"\\])*)", context.namespaceKey/)[1];
  const cleanup=JSON.parse('"'+raw+'"').replace('%@','__sdk');vm.runInContext(cleanup,ctx);vm.runInContext(cleanup,ctx);assert.equal(ctx.cleared,1);assert.equal(ctx.window.__sdk,undefined);
});
test('scene failure preserves collected flow instead of discarding it',()=>{
  const ctx=vm.createContext({window:{performance:{now:()=>0}},document:{}});const result=sample(ctx,'','(function(){return function(){throw 0;};}())');assert.equal(result.status,'invalid_probe_result');assert.equal(result.cardFlow.reason,'unsupported_engine');
});
test('document mismatch prevents initializing a second flow observer',()=>{
  const ctx=vm.createContext({window:{performance:{now:()=>0}},document:{}});sample(ctx);ctx.window={};assert.equal(sample(ctx,'doc1').status,'probe_document_changed');assert.equal(ctx.window.__sdk,undefined);
});
test('missing resource has a bounded diagnostic and callable cleanup',()=>{
  const fallback=bridge.match(/NSString \*fallback = @"([^"\n]+)"/)[1];const ctx=vm.createContext({window:{}});const result=sample(ctx,'',undefined,fallback);assert.equal(result.cardFlow.reason,'flow_script_missing');assert.doesNotThrow(()=>ctx.window.__sdk.capture.clear());
});

test('ready production runtime exports upstream and visual records through the real native formatter',()=>{
  const {fixture}=require('./card_flow_fixture.cjs');const f=fixture();const ctx=f.context;
  const first=sample(ctx);assert.equal(first.cardFlow.status,'ready');assert.equal(first.cardFlow.events[0].cards[0].id,64);
  const payload={gamers:[{cards:[{id:64,type:1,color:3,num:3}]}]};f.store.sync(payload);f.component.setup(payload.gamers[0].cards[0]);
  const second=sample(ctx,'doc1');assert.deepEqual(Array.from(second.cardFlow.events,x=>x.stage),['store_input','store_after','card_setup_input','card_setup_after']);assert.equal(second.cardFlow.events[3].cards[0].color,3);
  ctx.window.__sdk.capture.clear();assert.ok(!Object.hasOwn(f.store,'sync'));
});

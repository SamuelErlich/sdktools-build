const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/return_tool.js'), 'utf8');

function node(children = [], extra = {}) {
  const value = {isValid: true, active: true, activeInHierarchy: true, opacity: 255,
    x: 0, y: 0, width: 20, height: 20, children, parent: null, ...extra};
  for (const child of children) child.parent = value;
  return value;
}
function fixture(options = {}) {
  const calls = [], direct = [];
  function Component() {}
  function Sprite() {}
  function Button() {}
  function EventHandler() {}
  EventHandler.prototype.emit = function (params) { calls.push({receiver: this, params}); };
  Component.EventHandler = EventHandler;
  const names = ['\u0000w\u00cc\u0081r', options.shuffle ? '\u0000w\u00cc\u0081p' : '\u0000w\u00cc\u0081s', options.variant ? '\u0000w\u00cc\u0081v' : '\u0000w\u00cc\u0081q'];
  const icons = [], frames = [], sprites = [];
  const items = names.map((name, i) => {
    // Synthetic names reproduce the tags captured in the two V2.3 reports;
    // atlas placement is intentionally unrelated to the first capture.
    const frame = {name, getRect: () => ({x: 19 + i * 29, y: 963, width: 120, height: 135})};
    const sprite = {spriteFrame: frame, enabled: true, enabledInHierarchy: true};
    const icon = node([], {width: 80, height: 90, getComponent: type => type === Sprite ? sprite : null});
    icons.push(icon); frames.push(frame); sprites.push(sprite);
    return node([icon], {width: 80, height: 90, x: [-106, 0, 106][i]});
  });
  const row = node(items, {width: 292, height: 90});
  const target = items[1], icon = icons[1];
  const prop = {isValid: true, node: target, onUseProp: () => direct.push('unexpected direct call')};
  target.getComponents = type => type === Component ? [prop] : [];
  const event = new EventHandler();
  Object.assign(event, {target, component: null, handler: 'onUseProp', customEventData: ''});
  const button = {isValid: true, node: icon, enabled: true, enabledInHierarchy: true, interactable: true, clickEvents: [event]};
  icon.getComponent = type => type === Sprite ? sprites[1] : type === Button ? button : null;
  const parent = node([row]);
  const root = node([parent], {active: false});
  const cc = {ENGINE_VERSION: '2.4.4', Sprite, Button, Component,
    js: {getClassName: value => value === prop ? 'Prop' : 'Other'}, director: {getScene: () => root}};
  return {cc, root, parent, row, items, icons, frames, sprites, target, icon, prop, button, event, EventHandler, calls, direct};
}
function setup(f, overrides = {}) {
  const win = {cc: f.cc}; win.top = win;
  const context = vm.createContext({window: win, document: {visibilityState: 'visible', readyState: 'complete'},
    performance: {now: () => 0}, ...overrides});
  const before = Object.keys(context.window);
  vm.runInContext('var action = ' + source, context, {timeout: 200});
  assert.deepEqual(Object.keys(context.window), before);
  return {context, run: () => JSON.parse(JSON.stringify(vm.runInContext('action()', context, {timeout: 500})))};
}
function run(f, overrides) { return setup(f, overrides).run(); }
function blocked(f, reason, overrides) {
  const result = run(f, overrides);
  assert.equal(result.status, 'no_action'); assert.equal(result.dispatched, false);
  if (reason) assert.equal(result.reason, reason);
  assert.equal(result.popupConfirmationRequired, false); assert.equal(f.calls.length, 0); assert.equal(f.direct.length, 0);
  return result;
}

test('opens only the exact registered event once with the original button argument', () => {
  const f = fixture(), result = run(f);
  assert.equal(result.status, 'original_event_dispatched'); assert.equal(result.dispatched, true);
  assert.equal(result.popupConfirmationRequired, true);
  assert.equal(f.calls.length, 1); assert.equal(f.calls[0].receiver, f.event);
  assert.equal(f.calls[0].params.length, 1); assert.equal(f.calls[0].params[0], f.button);
  assert.equal(f.direct.length, 0);
});
test('supports both observed right icon tags and moving atlas x/y positions', () => {
  for (const variant of [false, true]) {
    const f = fixture({variant});
    f.frames.forEach((frame, i) => frame.getRect = () => ({x: 7400 - i * 240, y: 17, width: 120, height: 135}));
    assert.equal(run(f).status, 'original_event_dispatched'); assert.equal(f.calls.length, 1);
  }
});
test('V2.6 opens either observed central-power popup once and still requires manual confirmation', () => {
  for (const shuffle of [false, true]) {
    const f = fixture({shuffle}), result = run(f);
    assert.equal(result.status, 'original_event_dispatched');
    assert.equal(result.popupConfirmationRequired, true);
    assert.equal(f.calls.length, 1); assert.equal(f.calls[0].receiver, f.event);
    assert.equal(f.event.handler, 'onUseProp'); assert.equal(f.direct.length, 0);
  }
});
test('no cached object identities or automatic replay survive a single invocation', () => {
  const f = fixture(), {run: invoke} = setup(f);
  assert.equal(invoke().status, 'original_event_dispatched');
  f.button.interactable = false;
  assert.equal(invoke().status, 'no_action'); assert.equal(f.calls.length, 1);
});
test('requires exact engine version, visible ready main document and usable scene', () => {
  for (const version of ['2.4.5', '3.8.0', null]) { const f = fixture(); f.cc.ENGINE_VERSION = version; blocked(f, 'engine_version'); }
  for (const doc of [{visibilityState: 'hidden', readyState: 'complete'}, {visibilityState: 'visible', readyState: 'loading'}]) blocked(fixture(), 'document_unavailable', {document: doc});
  const f = fixture(); blocked(f, 'context_unavailable', {window: {cc: f.cc, top: {}}});
  const invalid = fixture(); invalid.root.isValid = false; blocked(invalid, 'context_unavailable');
});
test('accepts the recorder CocosEngine fallback only for the exact supported version', () => {
  for (const primary of [undefined, null]) {
    const f = fixture(); f.cc.ENGINE_VERSION = primary;
    const {context, run: invoke} = setup(f); context.window.CocosEngine = '2.4.4';
    assert.equal(invoke().status, 'original_event_dispatched'); assert.equal(f.calls.length, 1);
  }
  for (const version of ['2.4.5', '3.8.0', '', null, 2.44]) {
    const f = fixture(); delete f.cc.ENGINE_VERSION;
    const {context, run: invoke} = setup(f); context.window.CocosEngine = version;
    const result = invoke(); assert.equal(result.status, 'no_action'); assert.equal(result.reason, 'engine_version'); assert.equal(f.calls.length, 0);
  }
});
test('rejects conflicting public engine version strings and accepts agreeing strings', () => {
  for (const [primary, fallback] of [['2.4.4', '2.4.5'], ['2.4.5', '2.4.4']]) {
    const f = fixture(); f.cc.ENGINE_VERSION = primary;
    const {context, run: invoke} = setup(f); context.window.CocosEngine = fallback;
    assert.equal(invoke().reason, 'engine_version'); assert.equal(f.calls.length, 0);
  }
  const f = fixture(), {context, run: invoke} = setup(f); context.window.CocosEngine = '2.4.4';
  assert.equal(invoke().status, 'original_event_dispatched');
});
test('revalidates public fallback version before dispatch', () => {
  const f = fixture(); delete f.cc.ENGINE_VERSION;
  const {context, run: invoke} = setup(f); context.window.CocosEngine = '2.4.4';
  f.target.getComponents = () => {context.window.CocosEngine = '2.4.5'; return [f.prop];};
  assert.equal(invoke().reason, 'context_changed'); assert.equal(f.calls.length, 0);
});
test('allows only the structural root active exception', () => {
  const good = fixture(); assert.equal(run(good).status, 'original_event_dispatched');
  for (const key of ['active', 'activeInHierarchy']) { const f = fixture(); f.parent[key] = false; blocked(f, 'fingerprint_mismatch'); }
});
test('hidden or invalid ancestors, controls and sibling evidence cannot dispatch', () => {
  for (const select of [f => f.parent, f => f.row, f => f.items[0], f => f.icons[2]]) {
    for (const [key, value] of [['opacity', 0], ['active', false], ['activeInHierarchy', false], ['isValid', false]]) {
      const f = fixture(); select(f)[key] = value; blocked(f, 'fingerprint_mismatch');
    }
  }
});
test('requires booleans rather than truthy flags on the original button', () => {
  for (const key of ['enabled', 'enabledInHierarchy', 'interactable']) {
    for (const value of [false, 1, 'true', undefined, null]) {
      const f = fixture(); f.button[key] = value; blocked(f, 'disabled_control');
    }
  }
});
test('requires original button identity and validity', () => {
  for (const value of [false, undefined, 1]) { const f = fixture(); f.button.isValid = value; blocked(f, 'button_unavailable'); }
  const f = fixture(); f.button.node = f.target; blocked(f, 'button_unavailable');
});
test('rejects a missing, wrong-sized or differently tagged sprite', () => {
  let f = fixture(); f.frames[0].name = 'unrelated'; blocked(f, 'fingerprint_mismatch');
  f = fixture(); f.frames[2].getRect = () => ({width: 120, height: 136}); blocked(f, 'fingerprint_mismatch');
  f = fixture(); f.icons[1].getComponent = () => null; blocked(f, 'fingerprint_mismatch');
  f = fixture(); f.sprites[0].enabled = false; blocked(f, 'fingerprint_mismatch');
});
test('rejects a reordered, incomplete or shifted control row', () => {
  let f = fixture(); f.items[0].x = -105; blocked(f, 'fingerprint_mismatch');
  f = fixture(); f.row.children.reverse(); blocked(f, 'fingerprint_mismatch');
  f = fixture(); f.row.children.pop(); blocked(f, 'fingerprint_mismatch');
  f = fixture(); f.row.width = 291; blocked(f, 'fingerprint_mismatch');
});
test('two complete matching control rows are ambiguous even when one button is disabled', () => {
  const f = fixture(), second = fixture();
  // Both rows must use the same engine classes for a genuine ambiguity.
  second.icons.forEach((icon, i) => { icon.getComponent = type => type === f.cc.Sprite ? second.sprites[i] : null; });
  second.row.parent = f.parent; f.parent.children.push(second.row); second.button.enabled = false;
  blocked(f, 'ambiguous_control');
});
test('visible confirmation geometry anywhere in the complete scene blocks stacking', () => {
  const f = fixture(), modal = node([], {width: 240, height: 102});
  modal.parent = f.root; f.root.children.push(modal); blocked(f, 'modal_visible');
});
test('inactive or transparent confirmation geometry does not block a visible row', () => {
  for (const extra of [{active: false}, {opacity: 0}]) {
    const f = fixture(), modal = node([], {width: 240, height: 102, ...extra});
    modal.parent = f.root; f.root.children.push(modal);
    assert.equal(run(f).status, 'original_event_dispatched');
  }
});
test('only one Prop component with a current onUseProp method is acceptable', () => {
  let f = fixture(); f.target.getComponents = () => []; blocked(f, 'handler_ambiguous');
  f = fixture(); f.target.getComponents = () => [f.prop, f.prop]; blocked(f, 'handler_ambiguous');
  f = fixture(); f.prop.onUseProp = null; blocked(f, 'handler_unavailable');
  f = fixture(); f.prop.node = f.root; blocked(f, 'handler_unavailable');
  f = fixture(); f.prop.isValid = false; blocked(f, 'handler_unavailable');
});
test('does not read private identifiers, storage, arbitrary handlers or call game code directly', () => {
  const f = fixture();
  for (const key of ['_componentId', 'component', '_compId', 'getComponentName']) Object.defineProperty(f.event, key, {get() {throw Error('private');}});
  for (const key of ['stock', 'coins', '_components']) Object.defineProperty(f.target, key, {get() {throw Error('private');}});
  assert.equal(run(f).status, 'original_event_dispatched'); assert.equal(f.direct.length, 0);
});
test('rejects missing, extra, retargeted or altered registered click events', () => {
  const mutations = [f => f.button.clickEvents = [], f => f.button.clickEvents.push(f.event),
    f => f.event.target = f.root, f => f.event.handler = 'confirm', f => f.event.customEventData = '1',
    f => f.event.customEventData = null];
  for (const mutate of mutations) { const f = fixture(); mutate(f); blocked(f, 'event_mismatch'); }
});
test('requires original EventHandler prototype and exact prototype emitter', () => {
  let f = fixture(); f.button.clickEvents = [{...f.event, emit: f.EventHandler.prototype.emit}]; blocked(f, 'event_mismatch');
  f = fixture(); f.event.emit = () => f.calls.push('wrong'); blocked(f, 'event_mismatch');
  f = fixture(); f.EventHandler.prototype.emit = undefined; blocked(f, 'event_unavailable');
});
test('does not dispatch before scanning siblings beyond an early valid control', () => {
  const f = fixture(), malformed = node(); malformed.parent = f.root;
  Object.defineProperty(malformed, 'children', {get() {throw Error('SENSITIVE VALUE');}});
  f.root.children.push(malformed);
  const result = blocked(f, 'read_error'); assert.ok(!JSON.stringify(result).includes('SENSITIVE'));
});
test('enforces child, total-node, depth and component budgets before dispatch', () => {
  let f = fixture(); f.root.children = Array.from({length: 513}, () => node()); f.root.children.forEach(n => n.parent = f.root); blocked(f, 'scan_limit');
  f = fixture(); const layers = Array.from({length: 9}, () => node(Array.from({length: 500}, () => node()))); layers.forEach(n => n.parent = f.root); f.root.children.push(...layers); blocked(f, 'scan_limit');
  f = fixture(); let deep = node(); for (let i = 0; i < 25; i++) deep = node([deep]); deep.parent = f.root; f.root.children.push(deep); blocked(f, 'scan_limit');
  f = fixture(); f.target.getComponents = () => Array(33).fill(f.prop); blocked(f, 'scan_limit');
});
test('cooperative time budget blocks action on incomplete scene inspection', () => {
  let time = 0; blocked(fixture(), 'time_budget', {performance: {now: () => time += 1}});
});
test('cycles, repeated references and inconsistent parent links cannot dispatch', () => {
  let f = fixture(); f.root.children.push(f.parent); blocked(f, 'invalid_scene');
  f = fixture(); f.parent.children.push(f.root); blocked(f, 'invalid_scene');
  f = fixture(); f.row.parent = f.root; blocked(f, 'invalid_scene');
});
test('scene and document changes between discovery and dispatch reject action', () => {
  let f = fixture(), reads = 0; f.cc.director.getScene = () => ++reads === 1 ? f.root : node(); blocked(f, 'context_changed');
  f = fixture(); const doc = {visibilityState: 'visible', readyState: 'complete'};
  f.target.getComponents = () => {doc.visibilityState = 'hidden'; return [f.prop];}; blocked(f, 'context_changed', {document: doc});
});
test('revalidates current event and button identities immediately before dispatch', () => {
  const f = fixture(), original = f.target.getComponents; let reads = 0;
  f.target.getComponents = type => {if (++reads === 2) f.button.clickEvents = [Object.assign(new f.EventHandler(), f.event)]; return original(type);};
  blocked(f, 'context_changed');
});
test('an exception from the original event is an uncertain send and is never retried', () => {
  const f = fixture(); f.EventHandler.prototype.emit = function () {f.calls.push('attempt'); throw Error('secret game message');};
  const result = run(f);
  assert.equal(result.status, 'dispatch_uncertain'); assert.equal(result.dispatched, null); assert.equal(result.reason, 'event_exception');
  assert.equal(f.calls.length, 1); assert.equal(f.direct.length, 0); assert.ok(!JSON.stringify(result).includes('secret'));
});
test('no mutation of scene, inventory or event metadata is performed by the tool', () => {
  const f = fixture();
  for (const item of [...f.items, ...f.icons, ...f.sprites, ...f.frames, f.row, f.parent, f.root, f.prop, f.button, f.event]) Object.freeze(item);
  assert.equal(run(f).status, 'original_event_dispatched'); assert.equal(f.calls.length, 1);
});

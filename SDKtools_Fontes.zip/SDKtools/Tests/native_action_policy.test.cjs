const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');

test('intermediate WebKit timeout preserves Auto intent until the exclusive callback finishes',()=>{
 const policy=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STNativeActionPolicy.h'),'utf8');
 // Execute the production boolean-only C expression; these operators have identical JS semantics.
 const match=policy.match(/bool STNativeAutoplayShouldPause\(bool failed, bool physicalPending, bool evaluationTimeout\)\s*\{\s*return ([\w\s!&|()]+);\s*\}/);
 assert.ok(match,'production pause policy must distinguish an intermediate timeout from a final failure');
 const pause=new Function('failed','physicalPending','evaluationTimeout','return '+match[1]);
 const cases=[
  [true,true,true,false],  // Timeout notification; physical lock still prevents another evaluation.
  [true,false,true,true], // Final unknown outcome must pause.
  [true,true,false,true], // Submission/context/other failure still pauses.
  [true,false,false,true],
  [false,true,true,false],
  [false,false,true,false],
  [false,true,false,false],
  [false,false,false,false]
 ];
 for(const [failed,pending,timeout,expected] of cases)assert.equal(pause(failed,pending,timeout),expected);
 const recorder=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STAutoplayRecorder.inc'),'utf8');
 assert.match(recorder,/STNativeAutoplayShouldPause\(failed,\s*\[result\[@"physicalPending"\] boolValue\],\s*\[resultReason isEqual:@"evaluation_timeout"\]\)/);
});

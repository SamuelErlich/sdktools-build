#include "../Sources/SDKtools/STCompactMenuLayout.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void) {
    unsigned checks=0;
    // Actual safe-area sizes: small iPhone, portrait, notched landscape,
    // tablet and narrow multitasking. Long notices/settings must scroll.
    const double viewports[][2]={{304,532},{354,714},{374,750},{734,353},{1008,728},{224,304}};
    const double contentHeights[]={40,120,186,260,500,2000};
    for(unsigned v=0;v<sizeof(viewports)/sizeof(viewports[0]);v++) {
        for(unsigned c=0;c<sizeof(contentHeights)/sizeof(contentHeights[0]);c++) {
            STCompactMenuSize s=STCompactMenuFit(viewports[v][0],viewports[v][1],contentHeights[c]);
            assert(s.width>0 && s.width<=288 && s.width<=viewports[v][0]); checks++;
            assert(s.height>152 && s.height<=380 && s.height<=viewports[v][1]); checks++;
            assert(s.width*s.height<viewports[v][0]*viewports[v][1]*0.86); checks++;
        }
    }
    assert(STCompactMenuFit(354,714,186).height==338);checks++;
    assert(STCompactMenuFit(354,714,2000).height==380);checks++;
    assert(STCompactMenuFit(0,0,2000).height==0);checks++;
    assert(strcmp(STCompactMenuTag(true,false,false,false,0),"Auto")==0);checks++;
    assert(strcmp(STCompactMenuTag(true,true,false,false,0),"Auto · Xray")==0);checks++;
    assert(strcmp(STCompactMenuTag(false,false,false,true,2),"Auto")==0);checks++;
    assert(strcmp(STCompactMenuTag(false,false,false,true,1),"Aim")==0);checks++;
    assert(strcmp(STCompactMenuTag(false,false,false,false,0),"")==0);checks++;
    for(unsigned flags=0;flags<16;flags++)for(int mode=0;mode<3;mode++) {
        const char *tag=STCompactMenuTag(flags&1,flags&2,flags&4,flags&8,mode);
        assert(strlen(tag)<=12 && !strchr(tag,'\n') && !strstr(tag,"SDK"));checks++;
    }
    printf("Compact menu: %u bounds and gameplay-indicator checks passed\n",checks);
    return 0;
}

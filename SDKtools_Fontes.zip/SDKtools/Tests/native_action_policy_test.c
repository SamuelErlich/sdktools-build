#include "../Sources/SDKtools/STNativeActionPolicy.h"
#include <stdio.h>
static unsigned checks, failures;
#define CHECK(test) do { checks++; if (!(test)) { failures++; fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#test); } } while(0)
static void batchCallback(STNativeBatchResultFacts facts, bool reportedPending, bool *pending, bool *lost) {
    facts.contextLost=*lost;
    switch (STNativeBatchEvaluateResult(facts)) {
        case STNativeBatchPreserve: break;
        case STNativeBatchClearProvisional: *pending=false; break;
        case STNativeBatchContextLost: *pending=true;*lost=true;break;
        case STNativeBatchReconcile: *pending=reportedPending;break;
    }
}
static void testBatchCallbacks(void) {
    /* Simulate a slow first evaluation followed by a final callback which
     * blocked before dispatch. The timeout must not permanently poison Play. */
    bool pending=true,lost=false;
    STNativeBatchResultFacts first={.physicalPending=true,.mayDispatch=true};
    batchCallback(first,false,&pending,&lost);
    CHECK(pending && !lost);
    first.physicalPending=false;first.hasDiagnostic=true;first.diagnosticIdle=true;
    batchCallback(first,false,&pending,&lost);
    CHECK(!pending && !lost);

    /* Same delay while observing an actual batch; preserve its evidence and
     * accept the late confirmation without silently restarting any action. */
    pending=true;lost=false;
    STNativeBatchResultFacts observation={.physicalPending=true,.wasPending=true};
    batchCallback(observation,false,&pending,&lost);
    CHECK(pending && !lost);
    observation.physicalPending=false;observation.hasDiagnostic=true;
    batchCallback(observation,false,&pending,&lost);
    CHECK(!pending && !lost);

    /* A final callback is different: absent diagnostics, an idle replacement
     * runtime or a different document cannot erase a previously sent batch. */
    const STNativeBatchResultFacts missing[]={
        {.wasPending=true},
        {.wasPending=true,.hasDiagnostic=true,.diagnosticIdle=true},
        {.wasPending=true,.hasDiagnostic=true,.wrongDocument=true}
    };
    for (unsigned i=0;i<sizeof(missing)/sizeof(missing[0]);i++) {
        pending=true;lost=false;batchCallback(missing[i],false,&pending,&lost);
        CHECK(pending && lost);
        batchCallback(observation,false,&pending,&lost);
        CHECK(pending && lost); /* Late unrelated evidence cannot unbind it. */
    }
    pending=true;lost=false;
    STNativeBatchResultFacts refused={.mayDispatch=true,.refusedBeforeSubmission=true};
    batchCallback(refused,false,&pending,&lost);CHECK(!pending && !lost);
    pending=true;refused.wasPending=true;
    batchCallback(refused,false,&pending,&lost);CHECK(pending && !lost);
    CHECK(STNativeBatchEvaluateResult((STNativeBatchResultFacts){0})==STNativeBatchPreserve);
}
int main(void) {
    testBatchCallbacks();
    CHECK(!STNativeAutoplayShouldPause(true,true,true));
    CHECK(STNativeAutoplayShouldPause(true,false,true));
    CHECK(STNativeAutoplayShouldPause(true,true,false));
    CHECK(STNativeAutoplayShouldPause(true,false,false));
    CHECK(!STNativeAutoplayShouldPause(false,true,true));
    CHECK(!STNativeAutoplayShouldPause(false,false,true));
    CHECK(!STNativeAutoplayShouldPause(false,true,false));
    CHECK(!STNativeAutoplayShouldPause(false,false,false));
    STNativeActionFacts game = {.applicationActive=true,.supportedApplication=true,.scanComplete=true,
        .candidateVisible=true,.windowUsable=true,.hostIsKeyWindow=false,.hostWindowLevel=0};
    CHECK(STNativeActionEvaluate(game)==STNativeActionReady); /* Captured visible non-key host. */
    game.hostIsKeyWindow=true; CHECK(STNativeActionEvaluate(game)==STNativeActionReady);
    for (unsigned key=0;key<2;key++) {
        game.hostIsKeyWindow=key;
        STNativeActionFacts f=game; f.nativeModalVisible=true; CHECK(STNativeActionEvaluate(f)==STNativeActionModal);
        f=game;f.controllerPresenting=true;CHECK(STNativeActionEvaluate(f)==STNativeActionPresenting);
        f=game;f.controllerDismissing=true;CHECK(STNativeActionEvaluate(f)==STNativeActionDismissing);
        f=game;f.webViewLoading=true;CHECK(STNativeActionEvaluate(f)==STNativeActionLoading);
        f=game;f.nativeObscured=true;CHECK(STNativeActionEvaluate(f)==STNativeActionObscured);
        f=game;f.ambiguousWindowOverlap=true;CHECK(STNativeActionEvaluate(f)==STNativeActionWindowOverlap);
        f=game;f.ambiguousWebView=true;CHECK(STNativeActionEvaluate(f)==STNativeActionAmbiguous);
        f=game;f.applicationActive=false;CHECK(STNativeActionEvaluate(f)==STNativeActionInactive);
        f=game;f.supportedApplication=false;CHECK(STNativeActionEvaluate(f)==STNativeActionUnsupported);
        f=game;f.scanComplete=false;CHECK(STNativeActionEvaluate(f)==STNativeActionScanLimit);
        f=game;f.candidateVisible=false;CHECK(STNativeActionEvaluate(f)==STNativeActionUnavailable);
        f=game;f.windowUsable=false;CHECK(STNativeActionEvaluate(f)==STNativeActionUnavailable);
    }
    game.hostWindowLevel=5;CHECK(STNativeActionEvaluate(game)==STNativeActionReady);
    game.hostWindowLevel=NAN;CHECK(STNativeActionEvaluate(game)==STNativeActionUnavailable);
    CHECK(STNativeActionRetryable(STNativeActionPresenting));
    CHECK(STNativeActionRetryable(STNativeActionDismissing));
    CHECK(STNativeActionRetryable(STNativeActionLoading));
    CHECK(STNativeActionRetryable(STNativeActionModal));
    CHECK(STNativeActionRetryable(STNativeActionObscured));
    CHECK(STNativeActionRetryable(STNativeActionUnavailable));
    CHECK(!STNativeActionRetryable(STNativeActionInactive));
    CHECK(!STNativeActionRetryable(STNativeActionUnsupported));
    CHECK(!STNativeActionRetryable(STNativeActionScanLimit));
    printf("Native action policy: %u checks, %u failures\n",checks,failures);
    return failures?1:0;
}

#include "../Sources/SDKtools/STNativeActionPolicy.h"
#include <stdio.h>
static unsigned checks, failures;
#define CHECK(test) do { checks++; if (!(test)) { failures++; fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#test); } } while(0)
int main(void) {
    STNativeActionFacts game = {.applicationActive=true,.supportedApplication=true,.scanComplete=true,
        .candidateVisible=true,.windowUsable=true,.hostIsKeyWindow=false,.hostWindowLevel=0};
    CHECK(STNativeActionEvaluate(game)==STNativeActionReady); /* Captured visible non-key host. */
    game.hostIsKeyWindow=true; CHECK(STNativeActionEvaluate(game)==STNativeActionReady);
    for (unsigned key=0;key<2;key++) {
        game.hostIsKeyWindow=key;
        STNativeActionFacts f=game; f.nativeModalVisible=true; CHECK(STNativeActionEvaluate(f)==STNativeActionModal);
        f=game;f.controllerPresenting=true;CHECK(STNativeActionEvaluate(f)==STNativeActionPresenting);
        f=game;f.controllerDismissing=true;CHECK(STNativeActionEvaluate(f)==STNativeActionDismissing);
        f=game;f.webViewLoading=true;CHECK(STNativeActionEvaluate(f)==STNativeActionLoading);
        f=game;f.nativeObscured=true;CHECK(STNativeActionEvaluate(f)==STNativeActionObscured);
        f=game;f.ambiguousWindowOverlap=true;CHECK(STNativeActionEvaluate(f)==STNativeActionWindowOverlap);
        f=game;f.ambiguousWebView=true;CHECK(STNativeActionEvaluate(f)==STNativeActionAmbiguous);
        f=game;f.applicationActive=false;CHECK(STNativeActionEvaluate(f)==STNativeActionInactive);
        f=game;f.supportedApplication=false;CHECK(STNativeActionEvaluate(f)==STNativeActionUnsupported);
        f=game;f.scanComplete=false;CHECK(STNativeActionEvaluate(f)==STNativeActionScanLimit);
        f=game;f.candidateVisible=false;CHECK(STNativeActionEvaluate(f)==STNativeActionUnavailable);
        f=game;f.windowUsable=false;CHECK(STNativeActionEvaluate(f)==STNativeActionUnavailable);
    }
    game.hostWindowLevel=5;CHECK(STNativeActionEvaluate(game)==STNativeActionReady);
    game.hostWindowLevel=NAN;CHECK(STNativeActionEvaluate(game)==STNativeActionUnavailable);
    CHECK(STNativeActionRetryable(STNativeActionPresenting));
    CHECK(STNativeActionRetryable(STNativeActionDismissing));
    CHECK(STNativeActionRetryable(STNativeActionLoading));
    CHECK(STNativeActionRetryable(STNativeActionModal));
    CHECK(STNativeActionRetryable(STNativeActionObscured));
    CHECK(STNativeActionRetryable(STNativeActionUnavailable));
    CHECK(!STNativeActionRetryable(STNativeActionInactive));
    CHECK(!STNativeActionRetryable(STNativeActionUnsupported));
    CHECK(!STNativeActionRetryable(STNativeActionScanLimit));
    printf("Native action policy: %u checks, %u failures\n",checks,failures);
    return failures?1:0;
}

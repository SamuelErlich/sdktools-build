// Execute the production V3.13 class, including direct calls to its old API.
// No UIKit/WebKit substitutes: the disabled class only depends on Foundation.
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import "../Sources/SDKtools/STCardFeaturePolicy.h"
#import "../Sources/SDKtools/STCardEarlyCapture.h"
#include <stdio.h>

#if ST_CARD_GAME_FEATURE_ENABLED
#error This test must exercise the paused production policy.
#endif

static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *reason) {
    checks++;
    if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", reason.UTF8String); }
}
int main(void) { @autoreleasepool {
    STCardEarlyCapture *capture = STCardEarlyCapture.shared;
    Check(capture == STCardEarlyCapture.shared, @"old singleton API remains compatible");
    Check(!capture.active && !capture.requested, @"construction never requests capture");
    for (NSUInteger i = 0; i < 3; i++) {
        Check(![capture arm], @"direct arm cannot start a capture");
        Check(!capture.active && !capture.requested, @"repeated arm cannot retain active state");
        [capture stopWithReason:@"user"];
        Check(!capture.active && !capture.requested, @"cleanup is idempotent and cannot reactivate");
    }
    NSDictionary *report = capture.snapshotReport;
    Check([report[@"status"] isEqual:@"disabled"] && [report[@"reason"] isEqual:@"feature_disabled"],
        @"report distinguishes disabled feature from a failed observation");
    Check(![report[@"active"] boolValue] && ![report[@"requested"] boolValue] && [report[@"samples"] count] == 0,
        @"report cannot claim a measurement occurred");
    Check(![report[@"native"][@"hooksInstalled"] boolValue] && ![report[@"native"][@"scriptInstalled"] boolValue],
        @"no native hook or user script is reported");
    for (NSString *name in @[@"tick", @"installHooks", @"checkpoint:beforeLoad:", @"prepareWebView:controller:",
        @"receive:generation:reply:", @"backgrounded:", @"setActive:", @"setRequested:"]) {
        Check(class_getInstanceMethod(capture.class, NSSelectorFromString(name)) == NULL,
            [@"paused class does not compile activation selector " stringByAppendingString:name]);
    }
    printf("Disabled early capture: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

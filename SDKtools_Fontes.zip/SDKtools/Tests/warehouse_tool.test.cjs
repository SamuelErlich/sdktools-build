const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/warehouse_tool.js'), 'utf8');

function node(children = [], extra = {}) {
  const n = {isValid: true, active: true, activeInHierarchy: true, opacity: 255,
    x: 0, y: 0, width: 20, height: 20, scaleX: 1, scaleY: 1, angle: 0, children, parent: null, ...extra};
  for (const c of children) c.parent = n;
  return n;
}
function fixture(owner = 2) {
  const calls = [], direct = [], names = new Map();
  function Component() {} function Button() {} function Sprite() {} function EventHandler() {}
  EventHandler.prototype.emit = function (params) { calls.push({event: this, params}); };
  Component.EventHandler = EventHandler;
  const items = [0, 1, 2].map(i => node([], {width: 84, height: 94, x: -88 + i * 88}));
  const row = node(items, {width: 260, height: 94, y: 8});
  const panel = node([node(), row], {width: 272, height: 126});
  const layer = node([panel]), root = node([layer], {active: false});
  const store = {isValid: true, node: layer}; names.set(store, 'CommonStore');
  const frame = {name: '\u442d\u2c08', getRect: () => ({x: 417, y: 2, width: 272, height: 126})};
  const sprite = {enabled: true, enabledInHierarchy: true, spriteFrame: frame};
  panel.getComponent = type => type === Sprite ? sprite : null;
  const receivers = [], buttons = [], events = [];
  for (const [i, n] of items.entries()) {
    const receiver = {node: n, isValid: true, isSelf: i === owner, isEmpty: true,
      commonBlock: {block: null, lock_state: 0}, commonStore: store,
      onBtnClick() { direct.push('must use registered event'); }};
    const event = new EventHandler(); Object.assign(event, {target: n, component: 'CommonStoreItem', handler: 'onBtnClick', customEventData: ''});
    const button = {node: n, isValid: true, enabled: true, enabledInHierarchy: true, interactable: true, clickEvents: [event]};
    names.set(receiver, 'CommonStoreItem');
    n.getComponents = type => type === Component ? [receiver] : [];
    n.getComponent = type => type === Button ? button : type === 'CommonStoreItem' ? receiver : null;
    receivers.push(receiver); buttons.push(button); events.push(event);
  }
  const cc = {ENGINE_VERSION: '2.4.4', Component, Button, Sprite, director: {getScene: () => root}, js: {getClassName: c => names.get(c) || 'Other'}};
  return {cc, root, layer, panel, row, items, store, frame, sprite, names, receivers, buttons, events, calls, direct, EventHandler, owner};
}
function setup(f, overrides = {}) {
  const win = {cc: f.cc}; win.top = win;
  const context = vm.createContext({window: win, document: {visibilityState: 'visible', readyState: 'complete'}, performance: {now: () => 0}, ...overrides});
  const keys = Object.keys(win);
  vm.runInContext('var invoke = ' + source, context, {timeout: 200});
  assert.deepEqual(Object.keys(win), keys);
  return {context, run(options) {
    context.options = options;
    return JSON.parse(JSON.stringify(vm.runInContext('invoke(options)', context, {timeout: 200})));
  }};
}
function blocked(f, reason, overrides) {
  const r = setup(f, overrides).run();
  assert.equal(r.status, 'no_action'); assert.equal(r.dispatched, false); assert.equal(r.effectConfirmed, false);
  assert.equal(r.reason, reason); assert.equal(f.calls.length, 0); assert.equal(f.direct.length, 0);
  return r;
}

test('opens the unique live own slot through its original registered event once', () => {
  for (const owner of [0, 1, 2]) {
    const f = fixture(owner), r = setup(f).run({command: 'open'});
    assert.equal(r.status, 'original_event_dispatched'); assert.equal(r.dispatched, true);
    assert.equal(r.reason, 'original_warehouse_requested'); assert.equal(r.effectConfirmed, false);
    assert.equal(r.ownerOnly, true); assert.equal(r.serverManaged, true);
    assert.equal(f.calls.length, 1); assert.equal(f.calls[0].event, f.events[owner]); assert.equal(f.calls[0].params.length, 0); assert.equal(f.direct.length, 0);
  }
});
test('root active flag exception and dynamic atlas placement do not block verified row', () => {
  const f = fixture(); f.frame.getRect = () => ({x: 2000, y: 9000, width: 272, height: 126});
  assert.equal(setup(f).run().status, 'original_event_dispatched');
});
test('absent or empty block ID matches the original setup emptiness rule', () => {
  for (const block of [undefined, null, {id: ''}]) {
    const f = fixture(); f.receivers[2].commonBlock.block = block;
    assert.equal(setup(f).run().status, 'original_event_dispatched');
  }
});
test('never opens a foreign, unknown or ambiguous owner', () => {
  const absent = fixture(-1); blocked(absent, 'owner_unknown');
  const duplicate = fixture(); duplicate.receivers[0].isSelf = true; blocked(duplicate, 'owner_ambiguous');
  for (const isSelf of [undefined, 'true', 1, null]) { const f = fixture(); f.receivers[2].isSelf = isSelf; blocked(f, 'owner_unknown'); }
});
test('locked and occupied own slots retain original restrictions without mutations', () => {
  for (const lock of [1, 2, 3]) { const f = fixture(); f.receivers[2].commonBlock.lock_state = lock; blocked(f, 'own_slot_locked'); assert.equal(f.receivers[2].commonBlock.lock_state, lock); }
  const f = fixture(); f.receivers[2].isEmpty = false; f.receivers[2].commonBlock.block = {id: 'synthetic-card'};
  blocked(f, 'own_slot_occupied'); assert.equal(f.receivers[2].commonBlock.block.id, 'synthetic-card');
});
test('rejects missing, coercible and inconsistent slot state', () => {
  for (const lock of [undefined, null, '0', -1, 0.5, 4, Infinity]) {
    const f = fixture(); f.receivers[2].commonBlock.lock_state = lock; blocked(f, 'slot_state_unavailable');
  }
  for (const empty of [undefined, null, 1, 'true']) { const f = fixture(); f.receivers[2].isEmpty = empty; blocked(f, 'slot_state_unavailable'); }
  const absent = fixture(); absent.receivers[2].commonBlock = null; blocked(absent, 'slot_state_unavailable');
  const inconsistent = fixture(); inconsistent.receivers[2].commonBlock.block = {id: 'occupied'}; blocked(inconsistent, 'slot_state_changed');
});
test('visible card in otherwise empty slot is a transition, never an open request', () => {
  const f = fixture(), card = node([], {width: 80, height: 90}); f.items[2].children.push(card); card.parent = f.items[2];
  blocked(f, 'slot_state_changed');
});
test('requires current visible main document and exact engine version', () => {
  for (const version of [undefined, '2.4.3', '3.8.0', 2.44]) { const f = fixture(); f.cc.ENGINE_VERSION = version; blocked(f, 'engine_version'); }
  for (const document of [{visibilityState: 'hidden', readyState: 'complete'}, {visibilityState: 'visible', readyState: 'loading'}]) blocked(fixture(), 'document_unavailable', {document});
  const f = fixture(); blocked(f, 'context_unavailable', {window: {cc: f.cc, top: {}}});
});
test('accepts matching CocosEngine fallback and rejects conflict', () => {
  const f = fixture(); delete f.cc.ENGINE_VERSION;
  const s = setup(f); s.context.window.CocosEngine = '2.4.4'; assert.equal(s.run().status, 'original_event_dispatched');
  const g = fixture(), t = setup(g); t.context.window.CocosEngine = '2.4.5'; assert.equal(t.run().reason, 'engine_version'); assert.equal(g.calls.length, 0);
});
test('rejects other commands and invalid options', () => {
  for (const options of [null, [], 'open', {command: 'close'}, {command: 'all'}, {command: false}]) {
    const f = fixture(); assert.equal(setup(f).run(options).reason, 'invalid_options'); assert.equal(f.calls.length, 0);
  }
});
test('requires complete exact observed warehouse geometry and panel identity', () => {
  for (const change of [f => f.row.width = 259, f => f.row.y = 7, f => f.items[0].x = -87,
    f => f.items[1].height = 95, f => f.items[1].scaleX = 0.9, f => f.frame.name = 'unrelated',
    f => f.frame.getRect = () => ({width: 272, height: 125}), f => f.panel.children.reverse(),
    f => f.sprite.enabled = false, f => f.row.children.pop()]) {
    const f = fixture(); change(f); blocked(f, 'fingerprint_mismatch');
  }
});
test('hidden ancestors, slots and panel cannot dispatch', () => {
  for (const target of ['layer', 'panel', 'row']) {
    for (const [key, value] of [['active', false], ['activeInHierarchy', false], ['opacity', 0], ['isValid', false]]) {
      const f = fixture(); f[target][key] = value; blocked(f, 'fingerprint_mismatch');
    }
  }
  const f = fixture(); f.items[0].active = false; blocked(f, 'fingerprint_mismatch');
});
test('rejects unrelated parent store and mismatched store across slots', () => {
  for (const change of [f => f.store.node = f.root, f => f.store.isValid = false, f => f.names.set(f.store, 'Other'),
    f => f.receivers[0].commonStore = {...f.store}]) {
    const f = fixture(); change(f); blocked(f, 'store_unavailable');
  }
});
test('requires exact original handler, zero arity and unique component resolution', () => {
  const wrong = fixture(); wrong.names.set(wrong.receivers[0], 'Other'); blocked(wrong, 'handler_ambiguous');
  const arity = fixture(); arity.receivers[0].onBtnClick = function (event) {}; blocked(arity, 'handler_unavailable');
  const invalid = fixture(); invalid.receivers[0].isValid = false; blocked(invalid, 'handler_unavailable');
  const duplicate = fixture(); duplicate.items[0].getComponents = () => [duplicate.receivers[0], {onBtnClick() {}}]; blocked(duplicate, 'handler_ambiguous');
});
test('requires native button enabled booleans and original identity', () => {
  for (const key of ['enabled', 'enabledInHierarchy', 'interactable']) {
    for (const value of [false, undefined, 1, 'true']) { const f = fixture(); f.buttons[2][key] = value; blocked(f, 'disabled_control'); }
  }
  const f = fixture(); f.buttons[2].node = f.items[0]; blocked(f, 'button_unavailable');
});
test('does not substitute direct callbacks for missing or mismatched events', () => {
  for (const change of [f => f.buttons[2].clickEvents = [], f => f.events[2].handler = 'showAddBlock',
    f => f.events[2].target = f.items[0], f => f.events[2].customEventData = '1',
    f => f.events[2].component = 'Other', f => f.events[2].emit = function () {},
    f => f.buttons[2].clickEvents = [{...f.events[2]}]]) {
    const f = fixture(); change(f); blocked(f, 'event_mismatch');
  }
});
test('original power modal and known enabled alert block stacking', () => {
  const f = fixture(), modal = node([], {width: 240, height: 102}); modal.parent = f.root; f.root.children.push(modal); blocked(f, 'modal_visible');
  const g = fixture(), alert = {enabled: true, enabledInHierarchy: true}; g.names.set(alert, 'KnownAlert'); g.layer.getComponents = () => [alert]; blocked(g, 'modal_visible');
});
test('an active original CommonStore cover means the selector is already open', () => {
  const f = fixture(), cover = node(), event = new f.EventHandler();
  Object.assign(event, {target: f.layer, handler: 'onCoverClick'});
  const button = {node: cover, enabled: true, enabledInHierarchy: true, clickEvents: [event]};
  cover.getComponent = type => type === f.cc.Button ? button : null;
  cover.parent = f.layer; f.layer.children.push(cover);
  blocked(f, 'selection_already_open');
});
test('inactive original cover in the normal warehouse does not block opening', () => {
  const f = fixture(), cover = node([], {active: false}), event = new f.EventHandler();
  Object.assign(event, {target: f.layer, handler: 'onCoverClick'});
  const button = {node: cover, enabled: true, enabledInHierarchy: true, clickEvents: [event]};
  cover.getComponent = type => type === f.cc.Button ? button : null;
  cover.parent = f.layer; f.layer.children.push(cover);
  assert.equal(setup(f).run().status, 'original_event_dispatched'); assert.equal(f.calls.length, 1);
});
test('two visible complete warehouse rows are rejected even if only one has a valid own slot', () => {
  const f = fixture(), other = fixture();
  other.panel.getComponent = type => type === f.cc.Sprite ? other.sprite : null;
  other.layer.parent = f.root; f.root.children.push(other.layer);
  blocked(f, 'ambiguous_control');
});
test('rechecks ownership and lock just before the original event', () => {
  for (const [field, value, expected] of [['isSelf', false, 'owner_unknown'], ['lock_state', 1, 'own_slot_locked']]) {
    const f = fixture(), object = field === 'lock_state' ? f.receivers[2].commonBlock : f.receivers[2];
    const original = f.frame.getRect; let reads = 0;
    f.frame.getRect = () => {if (++reads === 2) object[field] = value; return original();};
    const r = setup(f).run(); assert.equal(r.status, 'no_action'); assert.equal(r.reason, expected); assert.equal(f.calls.length, 0);
  }
});
test('runtime state is inspected through data descriptors without invoking getters', () => {
  for (const [path, key, reason] of [['receiver', 'isSelf', 'owner_unknown'], ['receiver', 'isEmpty', 'slot_state_unavailable'],
    ['receiver', 'commonStore', 'store_unavailable'], ['receiver', 'commonBlock', 'slot_state_unavailable'], ['block', 'lock_state', 'slot_state_unavailable']]) {
    const f = fixture(), target = path === 'receiver' ? f.receivers[2] : f.receivers[2].commonBlock;
    let reads = 0; Object.defineProperty(target, key, {get() {reads++; throw Error('must not invoke');}});
    blocked(f, reason); assert.equal(reads, 0);
  }
});
test('scene and engine version changes invalidate dispatch', () => {
  const f = fixture(), s = setup(f); let calls = 0;
  f.cc.director.getScene = () => ++calls === 1 ? f.root : node(); assert.equal(s.run().reason, 'context_changed'); assert.equal(f.calls.length, 0);
  const g = fixture(), original = g.frame.getRect; g.frame.getRect = () => {g.cc.ENGINE_VERSION = '2.4.5'; return original();}; blocked(g, 'context_changed');
});
test('a changed zero-argument receiver method invalidates the original request', () => {
  const f = fixture(), original = f.frame.getRect; let reads = 0;
  f.frame.getRect = () => {if (++reads === 2) f.receivers[2].onBtnClick = function changed() {}; return original();};
  blocked(f, 'context_changed');
});
test('bounded traversal and malformed scene cannot authorize a partial observation', () => {
  const repeated = fixture(); repeated.root.children.push(repeated.layer); blocked(repeated, 'invalid_scene');
  const many = fixture(); many.layer.children = Array.from({length: 513}, () => node()); blocked(many, 'scan_limit');
  const malformed = fixture(); malformed.layer.children = null; blocked(malformed, 'invalid_scene');
  const budget = fixture(); let now = 0; blocked(budget, 'time_budget', {performance: {now: () => now += 1}});
});
test('throwing original event remains uncertain and is never retried by the action', () => {
  const f = fixture(); f.EventHandler.prototype.emit = function () {f.calls.push({event: this}); throw Error('after dispatch');};
  const r = setup(f).run(); assert.equal(r.status, 'dispatch_uncertain'); assert.equal(r.reason, 'event_exception'); assert.equal(r.dispatched, null); assert.equal(f.calls.length, 1);
});
test('dispatch does not bypass the original spectator callback or falsely claim opening', () => {
  const f = fixture(); let opened = 0, spectator = true;
  // Synthetic callback model; captured source is never evaluated.
  f.EventHandler.prototype.emit = function () {f.calls.push({event: this}); if (!spectator) opened++;};
  const r = setup(f).run(); assert.equal(r.status, 'original_event_dispatched'); assert.equal(r.effectConfirmed, false); assert.equal(opened, 0);
});
test('no identities or requests are cached across explicit invocations', () => {
  const f = fixture(), s = setup(f); assert.equal(s.run().status, 'original_event_dispatched');
  f.receivers[2].commonBlock.lock_state = 1; assert.equal(s.run().reason, 'own_slot_locked'); assert.equal(f.calls.length, 1);
});

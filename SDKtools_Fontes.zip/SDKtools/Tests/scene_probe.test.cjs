const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(process.env.SDKTOOLS_PROBE_SOURCE || path.join(__dirname, '../Resources/scene_probe.js'), 'utf8');
function setup(cc, extra = {}) {
  const document = { readyState: 'complete', querySelectorAll: (selector) => selector === 'canvas' ? [{ width: 900, height: 1800,
    getBoundingClientRect: () => ({ x: 0, y: 12, width: 450, height: 900 }) }] : [] };
  const context = vm.createContext({ window: { cc, innerWidth: 450, innerHeight: 900, devicePixelRatio: 2 }, document,
    performance: { now: () => 0 }, ...extra });
  const before = Object.keys(context.window);
  vm.runInContext('var sdktoolsTestCapture = ' + source, context, { timeout: 100 });
  assert.deepEqual(Object.keys(context.window), before, 'resource factory must not install globals itself');
  return { context, capture: (options) => {
    context.sdktoolsTestOptions = options;
    return JSON.parse(JSON.stringify(vm.runInContext('sdktoolsTestCapture(sdktoolsTestOptions)', context, { timeout: 500 })));
  } };
}
function run(cc, extra) { return setup(cc, extra).capture(); }
function node(name, children = [], overrides = {}) { return { name, isValid: true, active: true, activeInHierarchy: true,
  x: 12, y: 24, z: 0, width: 40, height: 60, anchorX: .5, anchorY: .5, scaleX: 1, scaleY: 1, angle: 0, opacity: 255,
  children, getComponent: () => null, ...overrides }; }
function engine(scene) { return { ENGINE_VERSION: '2.4.5', director: { getScene: () => scene }, Sprite: function(){},
  v2: (x, y) => ({x, y}) }; }
function validParents(result) {
  result.sceneNodes.forEach((row, index) => {
    assert.equal(row.index, index);
    if (row.parent === null) { assert.equal(row.depth, 0); assert.equal(row.parentID, null); }
    else { assert.ok(row.parent < index); assert.equal(row.parentID, result.sceneNodes[row.parent].nodeID);
      assert.equal(row.depth, result.sceneNodes[row.parent].depth + 1); }
  });
}
function frame(name = 'frame', texture = {}, rect = {x: 2, y: 232, width: 120, height: 135}) {
  return { name, getRect: () => rect, getTexture: () => texture };
}
function spriteNode(publicFrame, overrides = {}) {
  return node('other', [], { getComponent: type => type && type.name === 'Sprite' ? { spriteFrame: publicFrame } : null, ...overrides });
}
test('DOM-only observation remains useful without exposed Cocos', () => {
  const result = run(undefined); assert.equal(result.status, 'cocos_not_exposed');
  assert.equal(result.dom.canvasCount, 1); assert.equal(result.dom.canvases[0].cssRect.width, 450);
  assert.equal(result.sceneNodes.length, 0); assert.equal(result.version, 2);
});
test('unsupported engine does not call scene API', () => {
  let called = false;
  const result = run({ ENGINE_VERSION: '3.8.8', director: { getScene: () => { called = true; throw Error(); } } });
  assert.equal(result.status, 'cocos_version_unsupported'); assert.equal(called, false);
});
test('active geometry, parent references and world origin do not imply card identity', () => {
  const result = run(engine(node('Canvas', [node('Card_1', [], { convertToWorldSpaceAR: () => ({x: 375, y: 887.594}) })])));
  assert.equal(result.sceneNodes[1].category, 'card'); assert.equal(result.sceneNodes[1].parent, 0);
  assert.deepEqual(result.sceneNodes[1].worldOrigin, {x: 375, y: 887.594});
  assert.equal(result.cocos.occlusionResolved, false); assert.equal(result.cocos.cardRulesKnown, false);
  assert.equal(result.cocos.identityScope, 'probe_closure_object_identity_not_card_identity'); validParents(result);
});
test('private fields, text, URLs, storage and prototype hooks are never read', () => {
  const n = node('username_SECRET_ABC');
  for (const key of ['password', 'text', 'token', 'url', '_components', '_uuid', 'cards', 'cardType'])
    Object.defineProperty(n, key, {get: () => {throw Error('Forbidden read of ' + key);}});
  const w = {cc: engine(n), innerWidth: 450, innerHeight: 900, devicePixelRatio: 2};
  for (const key of ['localStorage', 'sessionStorage', 'fetch']) Object.defineProperty(w, key, { get: () => {throw Error('Forbidden global');} });
  const result = run(null, {window: w}); assert.ok(!JSON.stringify(result).includes('SECRET_ABC'));
  assert.equal(result.cocos.stats.readErrors, 0);
});
test('reconstructed broad board reaches descendant faces of 144 pieces beyond the old 64-child cap', () => {
  // Geometry and parent shape reconstructed from the Asia capture, not an
  // assertion that the US app has the same card types or complete scene model.
  const texture = {}, frames = [frame('cheese', texture), frame('rounded', texture, {x: 368, y: 232, width: 120, height: 135})];
  const pieces = Array.from({length: 144}, (_, i) => node('other', [node('other', [spriteNode(frames[i % 2])])],
    {width: 80, height: 90, x: (i % 7) * 70, y: Math.floor(i / 7) * 80}));
  const board = node('other', pieces, {width: 560, height: 720, y: 76});
  const decoration = Array.from({length: 120}, () => node('other'));
  const result = run(engine(node('Canvas', [...decoration, board])));
  assert.equal(result.sceneNodes.filter(n => n.sprite).length, 144);
  assert.equal(result.sceneNodes[1].prioritizationHint, 'board_geometry');
  assert.equal(result.sceneNodes[1].childCountReal, 144); assert.equal(result.sceneNodes[1].childrenQueued, 144);
  assert.equal(result.sceneNodes[2].siblingIndex, 0);
  assert.equal(result.sceneNodes[4].sprite.atlasRect.width, 120);
  assert.equal(result.cocos.truncated, false); validParents(result);
});
test('a bounded partial dense board retains complete early piece subtrees instead of only their roots', () => {
  const pieces = Array.from({length: 400}, () => node('other', [node('other', [spriteNode(frame()), spriteNode(frame())])], {width: 80, height: 90}));
  const result = run(engine(node('Canvas', [node('other', pieces, {width: 560, height: 720})])));
  assert.equal(result.sceneNodes.length, 1536); assert.ok(result.sceneNodes.filter(n => n.sprite).length > 700);
  assert.ok(result.cocos.truncationReasons.includes('node_limit')); validParents(result);
});
test('child limit reports real child count and does not pretend it captured all children', () => {
  const result = run(engine(node('Canvas', Array.from({length: 600}, () => node('other')))));
  assert.equal(result.sceneNodes[0].childCountReal, 600); assert.equal(result.sceneNodes[0].childrenQueued, 512);
  assert.equal(result.sceneNodes.length, 513); assert.ok(result.cocos.truncationReasons.includes('child_limit'));
});
test('cycle and repeated references terminate without invalid parent indices', () => {
  const root = node('Canvas'), a = node('Card'); root.children = [a, a]; a.children.push(root);
  const result = run(engine(root)); assert.equal(result.sceneNodes.length, 2);
  assert.equal(result.cocos.stats.skippedRepeated, 2); validParents(result);
});
test('inactive subtree is omitted even if a child incorrectly claims to be active', () => {
  const hidden = node('CardHidden', [node('CardHiddenChild')]); hidden.activeInHierarchy = false;
  const result = run(engine(node('Canvas', [hidden]))); assert.equal(result.sceneNodes.length, 1);
  assert.equal(result.cocos.stats.skippedInactive, 1);
});
test('non-finite and excessive geometry become null', () => {
  const result = run(engine(node('Card', [], {x: Infinity, y: NaN, width: 1e20})));
  assert.equal(result.sceneNodes[0].local.x, null); assert.equal(result.sceneNodes[0].local.y, null);
  assert.equal(result.sceneNodes[0].local.width, null);
});
test('sprite identities refer to objects without reading texture filenames or private data', () => {
  const texture = {};
  for (const key of ['url', 'nativeUrl', 'name', '_uuid', '_image']) Object.defineProperty(texture, key, {get: () => {throw Error('private');}});
  const shared = frame('PRIVATE_FRAME_ABC', texture), differentFrame = frame('PRIVATE_FRAME_ABC', texture);
  const result = run(engine(node('Canvas', [spriteNode(shared), spriteNode(shared), spriteNode(differentFrame)])));
  const [a, b, c] = result.sceneNodes.slice(1).map(n => n.sprite);
  assert.equal(a.frameID, b.frameID); assert.notEqual(a.frameID, c.frameID); assert.equal(a.textureID, c.textureID);
  assert.match(a.frameNameTag, /^[a-f0-9]{8}$/); assert.ok(!JSON.stringify(result).includes('PRIVATE_FRAME_ABC'));
  assert.equal(result.cocos.stats.readErrors, 0);
});
test('node IDs survive sibling reordering while indices and sibling indices describe current order', () => {
  const a = node('other', [], {x: 1}), b = node('other', [], {x: 2}), root = node('Canvas', [a, b]);
  const {capture} = setup(engine(root)), first = capture(); root.children.reverse(); const second = capture();
  assert.equal(first.sceneNodes[1].nodeID, second.sceneNodes[2].nodeID);
  assert.equal(first.sceneNodes[2].nodeID, second.sceneNodes[1].nodeID);
  assert.equal(second.sceneNodes[1].siblingIndex, 0); validParents(second);
});
test('new scene objects receive new IDs within a retained closure', () => {
  let scene = node('Canvas', [node('Card')]); const cc = engine(scene); cc.director.getScene = () => scene;
  const {capture} = setup(cc), first = capture(); scene = node('Canvas', [node('Card')]); const second = capture();
  const oldIDs = new Set(first.sceneNodes.map(n => n.nodeID)); assert.ok(second.sceneNodes.every(n => !oldIDs.has(n.nodeID)));
});
test('new factory has separate identity state, requiring the native context ID for joins', () => {
  const cc = engine(node('Canvas', [node('Card')])); const first = setup(cc), second = setup(cc);
  assert.equal(first.capture().sceneNodes[0].nodeID, 'n1'); assert.equal(second.capture().sceneNodes[0].nodeID, 'n1');
  assert.equal(Object.keys(first.context.window).some(k => /sdktools/i.test(k)), false);
});
test('protected engine global returns a bounded error without exposing exception text', () => {
  const window = {}; Object.defineProperty(window, 'cc', {get: () => {throw Error('secret-token');}});
  const result = run(null, {window}); assert.equal(result.status, 'capture_error');
  assert.ok(result.cocos.truncationReasons.includes('read_error')); assert.ok(!JSON.stringify(result).includes('secret-token'));
});
test('one protected public node property does not abort unrelated siblings', () => {
  const a = node('Card'); Object.defineProperty(a, 'width', {get: () => {throw Error('secret');}});
  const result = run(engine(node('Canvas', [a, node('Card')]))); assert.equal(result.sceneNodes.length, 3);
  assert.ok(result.cocos.truncationReasons.includes('read_error')); assert.ok(!JSON.stringify(result).includes('secret'));
});
test('soft time budget is checked while inspecting broad children and reports truncation', () => {
  let time = 0; const result = run(engine(node('Canvas', Array.from({length: 400}, () => node('other')))),
    {performance: {now: () => time++}});
  assert.ok(result.cocos.truncationReasons.includes('time_budget'));
  assert.ok(result.cocos.stats.inspectedChildren < 400); assert.ok(result.sceneNodes.length < 1536); validParents(result);
});
test('depth limit is explicit and parent references remain intact', () => {
  const root = node('Canvas'); let cursor = root;
  for (let i = 0; i < 30; i++) {const child = node('other'); cursor.children.push(child); cursor = child;}
  const result = run(engine(root)); assert.equal(result.sceneNodes.length, 25);
  assert.ok(result.cocos.truncationReasons.includes('depth_limit')); validParents(result);
});
test('queue bound is enforced for repeatedly broad subtrees', () => {
  const root = node('Canvas'); let cursor = root;
  for (let depth = 0; depth < 9; depth++) { cursor.children = Array.from({length: 512}, () => node('other')); cursor = cursor.children[0]; }
  const result = run(engine(root)); assert.ok(result.cocos.stats.queuePeak <= 4096);
  assert.ok(result.cocos.truncationReasons.includes('queue_limit')); validParents(result);
});
test('visit cap bounds invalid and repeated entries independently of output node count', () => {
  const invalid = {isValid: false};
  const result = run(engine(node('Canvas', Array.from({length: 9}, () => node('other', Array(512).fill(invalid))))));
  assert.equal(result.cocos.stats.visitedNodes, 4096); assert.ok(result.cocos.truncationReasons.includes('visit_limit'));
  assert.ok(result.sceneNodes.length < 11);
});
test('frozen scene, children, frames and texture remain untouched', () => {
  const texture = Object.freeze({}), sf = Object.freeze(frame('frame', texture));
  const child = spriteNode(sf); Object.freeze(child.children); Object.freeze(child);
  const root = node('Canvas', [child]); Object.freeze(root.children); Object.freeze(root);
  const result = run(engine(root)); assert.equal(result.status, 'cocos2_scene_captured');
  assert.equal(result.cocos.stats.readErrors, 0); assert.equal(root.children[0], child);
});
test('scene API errors and missing scene have distinct statuses', () => {
  const cc = engine(null); assert.equal(run(cc).status, 'no_scene');
  cc.director.getScene = () => {throw Error('secret');}; const result = run(cc);
  assert.equal(result.status, 'capture_error'); assert.ok(!JSON.stringify(result).includes('secret'));
});

test('director scene root inactive flags do not discard its active descendants', () => {
  // Regression of the US report: visitedNodes=1, skippedInactive=1, zero rows.
  // This reconstructs the rejected root condition, not the unrecorded game tree.
  for (const [active, activeInHierarchy] of [[false, true], [true, false], [false, false]]) {
    const root = node('Scene', [spriteNode(frame())], {active, activeInHierarchy});
    const cc = engine(root); cc.ENGINE_VERSION = '2.4.4';
    const result = run(cc);
    assert.equal(result.sceneNodes.length, 2);
    assert.equal(result.status, 'cocos2_scene_captured');
    assert.equal(result.cocos.stats.skippedInactive, 0);
    assert.equal(result.cocos.stats.inspectedChildren, 1);
    assert.equal(result.cocos.sceneRoot.active, active);
    assert.equal(result.cocos.sceneRoot.activeInHierarchy, activeInHierarchy);
    assert.equal(result.cocos.sceneRoot.childCountReal, 1);
    assert.equal(result.cocos.sceneRoot.nodeID, result.sceneNodes[0].nodeID);
    assert.equal(result.sceneNodes[0].structuralOnly, true);
    assert.equal(result.sceneNodes[0].isSceneRoot, true);
    assert.equal(result.cocos.visibilityVerified, false);
    assert.equal(result.cocos.activeNodesOnly, false);
    assert.equal(result.cocos.inactiveDescendantsSkipped, true);
    assert.equal(result.cocos.descendantNodeCount, 1);
    assert.equal(result.cocos.spriteNodeCount, 1);
    validParents(result);
  }
});
test('inactive root exception does not traverse inactive non-root subtrees', () => {
  const hidden = node('CardHidden', [spriteNode(frame('unread'))], {active: false});
  const hiddenHierarchy = node('CardHidden', [spriteNode(frame('unread2'))], {activeInHierarchy: false});
  const result = run(engine(node('Scene', [hidden, hiddenHierarchy, spriteNode(frame('visible'))], {active: false})));
  assert.equal(result.sceneNodes.length, 2);
  assert.equal(result.cocos.stats.skippedInactive, 2);
  assert.equal(result.cocos.descendantNodeCount, 1);
  assert.equal(result.cocos.spriteNodeCount, 1);
  validParents(result);
});
test('unknown root and descendant flags are null, not a false assertion', () => {
  const child = node('Card', [], {active: undefined, activeInHierarchy: undefined});
  const root = node('Scene', [child], {active: undefined, activeInHierarchy: undefined, isValid: undefined});
  const result = run(engine(root));
  assert.equal(result.cocos.sceneRoot.active, null);
  assert.equal(result.cocos.sceneRoot.activeInHierarchy, null);
  assert.equal(result.cocos.sceneRoot.isValid, null);
  assert.equal(result.sceneNodes[1].active, null);
  assert.equal(result.sceneNodes[1].activeInHierarchy, null);
  assert.equal(result.cocos.visibilityVerified, false);
  assert.equal(result.cocos.descendantNodeCount, 1);
});
test('root-only observation is explicitly empty and excludes root sprites', () => {
  const root = spriteNode(frame('root_not_a_card'), {active: false});
  for (const key of ['getComponent', 'convertToWorldSpaceAR'])
    Object.defineProperty(root, key, {get() {throw Error('structural root must not invoke render methods');}});
  const result = run(engine(root));
  assert.equal(result.status, 'cocos2_scene_observed_empty');
  assert.equal(result.sceneNodes.length, 1);
  assert.equal(result.sceneNodes[0].structuralOnly, true);
  assert.equal(result.sceneNodes[0].sprite, undefined);
  assert.equal(result.cocos.descendantNodeCount, 0);
  assert.equal(result.cocos.spriteNodeCount, 0);
  assert.equal(result.cocos.truncated, false);
});
test('invalid root and incomplete empty observation have distinct diagnostic statuses', () => {
  const invalid = run(engine(node('Scene', [node('Card')], {isValid: false})));
  assert.equal(invalid.status, 'scene_root_invalid');
  assert.equal(invalid.cocos.sceneRoot.isValid, false);
  assert.equal(invalid.sceneNodes.length, 0);
  assert.equal(invalid.cocos.stats.skippedInvalid, 1);
  const root = node('Scene', [], {active: false});
  Object.defineProperty(root, 'children', {get() {throw Error('do not expose this');}});
  const incomplete = run(engine(root));
  assert.equal(incomplete.status, 'cocos2_scene_observed_incomplete');
  assert.equal(incomplete.cocos.stats.readErrors, 1);
  assert.ok(incomplete.cocos.truncationReasons.includes('read_error'));
  assert.equal(incomplete.cocos.descendantNodeCount, 0);
  assert.ok(!JSON.stringify(incomplete).includes('do not expose this'));
});
test('inactive frozen root and descendant objects stay unmodified across captures', () => {
  const texture = Object.freeze({}), sf = Object.freeze(frame('frame', texture));
  const child = spriteNode(sf); Object.freeze(child.children); Object.freeze(child);
  const hidden = node('CardHidden', [spriteNode(frame())], {active: false});
  Object.freeze(hidden.children); Object.freeze(hidden);
  const root = node('Scene', [child, hidden], {active: false, activeInHierarchy: false});
  Object.freeze(root.children); Object.freeze(root);
  const cc = engine(root); Object.freeze(cc.director); Object.freeze(cc);
  const before = [root, child, hidden, sf, texture].map(o => Object.getOwnPropertyDescriptors(o));
  const {capture} = setup(cc), first = capture(), second = capture();
  assert.equal(first.cocos.descendantNodeCount, 1);
  assert.equal(first.cocos.spriteNodeCount, 1);
  assert.equal(first.cocos.stats.readErrors, 0);
  assert.equal(first.cocos.stats.skippedInactive, 1);
  assert.equal(first.sceneNodes[1].nodeID, second.sceneNodes[1].nodeID);
  assert.deepEqual([root, child, hidden, sf, texture].map(o => Object.getOwnPropertyDescriptors(o)), before);
});

test('US dense-board reconstruction captures all 225 piece subtrees within bounded capacity', () => {
  // Reconstruct the measured 225 direct children, including three active sprite
  // layers and three inactive extras per piece. This is a coverage regression,
  // not a claim that an iPhone can always traverse this tree inside 10 ms.
  const texture = {}, frames = [frame('base', texture), frame('face', texture), frame('mask', texture)];
  const pieces = Array.from({length: 225}, () => node('other', [
    ...frames.map(f => spriteNode(f)),
    ...Array.from({length: 3}, () => node('other', [], {active: false}))
  ], {width: 80, height: 90}));
  const board = node('other', pieces, {width: 560, height: 720});
  const root = node('Scene', [board, ...Array.from({length: 80}, () => node('other'))],
    {active: false, activeInHierarchy: true});
  const result = run(engine(root)), boardRow = result.sceneNodes[1];
  assert.equal(result.sceneNodes.length, 982);
  assert.equal(result.sceneNodes.filter(n => n.parentID === boardRow.nodeID).length, 225);
  assert.equal(result.cocos.spriteNodeCount, 675);
  assert.equal(result.cocos.stats.skippedInactive, 675);
  assert.equal(result.cocos.stats.visitedNodes, 1657);
  assert.equal(result.cocos.stats.frameMetadataReads, 3);
  assert.equal(result.cocos.stats.frameMetadataCacheHits, 672);
  assert.equal(result.cocos.truncated, false);
  assert.equal(result.cocos.stats.remainingQueued, 0);
  validParents(result);
});

test('shared frame metadata is read once per capture and refreshed on the next capture', () => {
  let nameReads = 0, rectReads = 0, textureReads = 0;
  let currentName = 'first', currentRect = {x: 2, y: 232, width: 120, height: 135}, currentTexture = {};
  const shared = {
    get name() { nameReads++; return currentName; },
    getRect() { rectReads++; return currentRect; },
    getTexture() { textureReads++; return currentTexture; }
  };
  const root = node('Scene', Array.from({length: 100}, () => spriteNode(shared)));
  const {capture} = setup(engine(root)), first = capture();
  assert.deepEqual([nameReads, rectReads, textureReads], [1, 1, 1]);
  assert.equal(first.cocos.stats.frameMetadataReads, 1);
  assert.equal(first.cocos.stats.frameMetadataCacheHits, 99);
  currentName = 'changed'; currentRect.x = 99; currentTexture = {};
  const second = capture();
  assert.deepEqual([nameReads, rectReads, textureReads], [2, 2, 2]);
  assert.equal(second.cocos.stats.frameMetadataReads, 1);
  assert.equal(second.cocos.stats.frameMetadataCacheHits, 99);
  const a = first.sceneNodes[1].sprite, b = second.sceneNodes[1].sprite;
  assert.equal(a.frameID, b.frameID);
  assert.notEqual(a.frameNameTag, b.frameNameTag);
  assert.notEqual(a.textureID, b.textureID);
  assert.equal(a.atlasRect.x, 2); assert.equal(b.atlasRect.x, 99);
  assert.ok(second.sceneNodes.slice(1).every(n => n.sprite.atlasRect.x === 99));
});

test('a failed shared frame getter is bounded to one attempt per capture and retried later', () => {
  let attempts = 0, broken = true;
  const shared = frame();
  shared.getRect = () => { attempts++; if (broken) throw Error('secret'); return {x: 1, y: 2, width: 3, height: 4}; };
  const {capture} = setup(engine(node('Scene', Array.from({length: 100}, () => spriteNode(shared)))));
  const first = capture();
  assert.equal(attempts, 1); assert.equal(first.cocos.stats.readErrors, 1);
  assert.ok(first.cocos.truncationReasons.includes('read_error'));
  assert.equal(first.cocos.spriteNodeCount, 100);
  assert.ok(first.sceneNodes.slice(1).every(n => n.sprite.textureID && !n.sprite.atlasRect));
  assert.ok(!JSON.stringify(first).includes('secret'));
  broken = false; const second = capture();
  assert.equal(attempts, 2); assert.equal(second.cocos.stats.readErrors, 0);
  assert.equal(second.cocos.truncated, false);
  assert.ok(second.sceneNodes.slice(1).every(n => n.sprite.atlasRect.width === 3));
});

function traceEngine(scene) {
  const cc = engine(scene);
  cc.Button = function Button() {};
  cc.Component = function Component() {};
  cc.js = {getClassName: component => component.className};
  return cc;
}
function attachButton(cc, n, button, components = []) {
  const getSprite = n.getComponent;
  n.getComponent = type => type === cc.Button ? button : getSprite(type);
  n.getComponents = type => {assert.equal(type, cc.Component); return components;};
  return n;
}
test('control tracing is strict opt-in and default capture never reads new metadata APIs', () => {
  const n = node('other', [], {width: 240, height: 102});
  let buttonAPIReads = 0, componentAPIReads = 0;
  Object.defineProperty(n, 'getComponents', {get() {componentAPIReads++; throw Error('metadata must not be read');}});
  const cc = engine(node('Scene', [n]));
  Object.defineProperty(cc, 'Button', {get() {buttonAPIReads++; return null;}});
  const {capture} = setup(cc);
  for (const options of [undefined, null, {}, {traceControls: false}, {traceControls: 1}, {traceControls: 'true'}]) {
    const result = capture(options);
    assert.equal(result.controlTrace, undefined);
    assert.ok(result.sceneNodes.every(row => row.control === undefined));
    assert.equal(result.cocos.stats.readErrors, 0);
  }
  assert.equal(buttonAPIReads, 0); assert.equal(componentAPIReads, 0);
  const result = capture({traceControls: true});
  assert.equal(result.controlTrace.enabled, true);
  assert.ok(buttonAPIReads > 0); assert.ok(componentAPIReads > 0);
  assert.ok(result.controlTrace.truncationReasons.includes('read_error'));
});
test('trace observes disabled Button components on category-other nodes without invoking handlers', () => {
  let calls = 0;
  const receiver = {undo: function (sender, data) { calls++; }};
  const target = node('other', [], {getComponent: name => name === 'PropController' ? receiver : null});
  const event = Object.freeze({target, component: 'PropController', handler: 'undo', customEventData: 'SECRET_payload_123'});
  const button = Object.freeze({enabled: false, enabledInHierarchy: false, interactable: false, clickEvents: Object.freeze([event])});
  const item = node('anonymous', [], {width: 240, height: 102}), cc = traceEngine(node('Scene', [item]));
  attachButton(cc, item, button, [Object.freeze({className: 'cc.Button'}), Object.freeze({className: 'PropController'})]);
  const tracked = [target, receiver, event, button, item];
  const before = tracked.map(Object.getOwnPropertyDescriptors);
  const result = setup(cc).capture({traceControls: true}), control = result.sceneNodes[1].control;
  assert.equal(result.sceneNodes[1].category, 'other');
  assert.deepEqual(control.componentTypes, ['cc.Button', 'PropController']);
  assert.equal(control.geometryHint, 'confirm_geometry'); assert.equal(control.semanticHint, 'none');
  assert.deepEqual([control.button.enabled, control.button.enabledInHierarchy, control.button.interactable], [false, false, false]);
  const e = control.button.events[0];
  assert.equal(e.handlerResolved, true); assert.equal(e.handlerArity, 2); assert.equal(e.targetValid, true);
  assert.equal(e.resolvedComponent, 'PropController'); assert.equal(e.resolution, 'configured_component');
  assert.match(e.targetNodeID, /^n[1-9][0-9]*$/);
  assert.deepEqual(e.customData, {present: true, type: 'string', length: 18});
  assert.ok(!JSON.stringify(result).includes('SECRET_payload_123')); assert.equal(calls, 0);
  assert.deepEqual(tracked.map(Object.getOwnPropertyDescriptors), before);
});
test('trace redacts custom data objects and unsafe identifiers without inspecting object fields', () => {
  let reads = 0, resolves = 0;
  const secret = {};
  for (const key of ['token', 'length', 'toString', 'toJSON']) Object.defineProperty(secret, key, {get() { reads++; throw Error('private'); }});
  const target = node('other', [], {getComponent() {resolves++; throw Error('must not resolve invalid identifier');}});
  const events = [
    {target, component: 'path/SECRET_component', handler: 'fn', customEventData: secret},
    {target, component: 'A'.repeat(97), handler: 'fn', customEventData: null},
    {target, component: 'Safe', handler: 'SECRET handler', customEventData: undefined},
    {target, component: null, handler: null, customEventData: 777},
    {target, component: 'Controller', handler: 'undo\n', customEventData: undefined},
  ];
  const item = node('other'), cc = traceEngine(node('Scene', [item]));
  attachButton(cc, item, {clickEvents: events});
  const result = setup(cc).capture({traceControls: true});
  const metadata = result.sceneNodes[1].control.button.events;
  assert.equal(reads, 0); assert.equal(resolves, 0);
  assert.deepEqual(metadata.map(e => e.customData.type), ['object', 'null', 'undefined', 'number', 'undefined']);
  assert.deepEqual(metadata.map(e => e.customData.length), [null, null, null, null, null]);
  assert.equal(metadata[4].handler, null);
  assert.equal(metadata[2].customData.present, false);
  assert.ok(metadata.every(e => e.handlerResolved === false && e.handlerArity === null));
  const encoded = JSON.stringify(result);
  assert.ok(!encoded.includes('SECRET')); assert.ok(!encoded.includes('777')); assert.ok(!encoded.includes('A'.repeat(97)));
});
test('trace bounds controls, components and events while keeping observed counts explicit', () => {
  const items = Array.from({length: 70}, () => node('other', [], {width: 240, height: 102}));
  const cc = traceEngine(node('Scene', items));
  const components = Array.from({length: 20}, (_, i) => ({className: 'Controller' + i}));
  for (const item of items) attachButton(cc, item, {clickEvents: Array.from({length: 20}, () => ({}))}, components);
  const result = setup(cc).capture({traceControls: true}), controls = result.sceneNodes.filter(n => n.control);
  assert.equal(result.controlTrace.observedButtonCount, 70); assert.equal(result.controlTrace.candidateCount, 70);
  assert.equal(result.controlTrace.inspectedNodes, 70); assert.equal(result.controlTrace.metadataNodeCount, 64);
  assert.equal(controls.length, 64);
  assert.ok(controls.every(n => n.control.componentTypes.length === 8 && n.control.button.events.length === 8 && n.control.button.eventCount === 20));
  for (const reason of ['control_limit', 'component_limit', 'event_limit']) assert.ok(result.controlTrace.truncationReasons.includes(reason));
  assert.equal(result.controlTrace.truncated, true); validParents(result);
});
test('throwing trace getters remain bounded, redact errors and do not stop sibling observations', () => {
  const badButton = {interactable: true};
  Object.defineProperty(badButton, 'clickEvents', {get() {throw Error('SECRET_click');}});
  const target = node('other');
  Object.defineProperty(target, 'getComponent', {get() {throw Error('SECRET_target');}});
  const badEvent = {target, component: 'Controller', handler: 'undo'};
  Object.defineProperty(badEvent, 'customEventData', {get() {throw Error('SECRET_custom');}});
  const children = [node('other'), node('other'), node('other')], cc = traceEngine(node('Scene', children));
  attachButton(cc, children[0], badButton);
  attachButton(cc, children[1], {clickEvents: [badEvent]});
  attachButton(cc, children[2], {enabled: true, interactable: true, clickEvents: []});
  const result = setup(cc).capture({traceControls: true});
  assert.equal(result.sceneNodes.length, 4); assert.equal(result.controlTrace.observedButtonCount, 3);
  assert.equal(result.sceneNodes[3].control.button.interactable, true);
  assert.ok(result.controlTrace.truncationReasons.includes('read_error'));
  assert.ok(!JSON.stringify(result).includes('SECRET'));
});
function propsFixture({atlasX = [880, 1002, 1124], rightVariant = false, shuffle = false} = {}) {
  // Synthetic names deliberately reproduce the three captured FNV tags. This
  // tests structural matching, not identity of actual application resources.
  const names = ['\u0000w\u00cc\u0081r', shuffle ? '\u0000w\u00cc\u0081p' : '\u0000w\u00cc\u0081s', rightVariant ? '\u0000w\u00cc\u0081v' : '\u0000w\u00cc\u0081q'];
  const items = names.map((name, index) => node('other', [spriteNode(frame(name, {},
    {x: atlasX[index], y: 232, width: 120, height: 135}), {width: 80, height: 90, x: 0, y: 0})],
    {width: 80, height: 90, x: [-106, 0, 106][index], y: 0}));
  return {row: node('other', items, {width: 292, height: 90}), items};
}
test('return visual hint requires complete triple fingerprint and never recognizes an isolated clone tag', () => {
  const {row, items} = propsFixture();
  const clone = spriteNode(frame('\u0000w\u00cc\u0081s', {}, {x: 1002, y: 232, width: 120, height: 135}), {width: 80, height: 90});
  const cc = traceEngine(node('Scene', [row, clone]));
  const {capture} = setup(cc), first = capture({traceControls: true});
  const matches = first.sceneNodes.filter(n => n.control && n.control.semanticHint === 'central_visual_candidate');
  assert.equal(matches.length, 1); assert.equal(matches[0].siblingIndex, 1);
  assert.equal(matches[0].local.x, 0); assert.equal(matches[0].control.button, undefined);
  const cloneRow = first.sceneNodes.find(n => n.sprite && n.parentID === first.sceneNodes[0].nodeID);
  assert.equal(cloneRow.sprite.frameNameTag, '8b2cb8bc'); assert.equal(cloneRow.control, undefined);
  items[0].x = -105;
  assert.ok(capture({traceControls: true}).sceneNodes.every(n => !n.control || n.control.semanticHint === 'none'));
  items[0].x = -106;
  items[0].children[0].getComponent = () => ({spriteFrame: frame('\u0000w\u00cc\u0081r', {}, {x: 880, y: 232, width: 119, height: 135})});
  assert.ok(capture({traceControls: true}).sceneNodes.every(n => !n.control || n.control.semanticHint === 'none'));
});
test('return candidate requires visible valid sibling and icon evidence', () => {
  for (const [kind, key, value] of [['row', 'isValid', false], ['row', 'active', false], ['row', 'activeInHierarchy', false],
    ['item', 'isValid', false], ['item', 'activeInHierarchy', false], ['icon', 'active', false], ['icon', 'isValid', false]]) {
    const fixture = propsFixture(), target = kind === 'row' ? fixture.row : kind === 'item' ? fixture.items[0] : fixture.items[0].children[0];
    target[key] = value;
    const result = setup(traceEngine(node('Scene', [fixture.row]))).capture({traceControls: true});
    assert.ok(result.sceneNodes.every(n => !n.control || n.control.semanticHint === 'none'), kind + ':' + key);
  }
});
test('trace prioritizes the small control container over a dense board and preserves ordinary order by default', () => {
  const {row} = propsFixture();
  const board = node('other', Array.from({length: 400}, () => node('other', [node('other'), node('other'), node('other')], {width: 80, height: 90})),
    {width: 560, height: 720});
  const holder = node('other', [row]), cc = traceEngine(node('Scene', [board, holder]));
  const {capture} = setup(cc), normal = capture(), traced = capture({traceControls: true});
  assert.equal(normal.sceneNodes[1].prioritizationHint, 'board_geometry');
  assert.equal(traced.sceneNodes[1].prioritizationHint, 'control_geometry');
  assert.ok(traced.sceneNodes.some(n => n.control && n.control.semanticHint === 'central_visual_candidate'));
  assert.equal(traced.controlTrace.truncated, true);
  assert.ok(traced.controlTrace.truncationReasons.includes('scene_incomplete')); validParents(traced);
});
test('trace control inspection respects the existing cooperative traversal time budget', () => {
  let time = 0;
  const items = Array.from({length: 100}, () => node('other', [], {width: 240, height: 102}));
  const cc = traceEngine(node('Scene', items));
  for (const item of items) attachButton(cc, item, {clickEvents: Array.from({length: 8}, () => ({}))});
  const result = setup(cc, {performance: {now: () => time += 0.1}}).capture({traceControls: true});
  assert.ok(result.controlTrace.truncationReasons.includes('time_budget'));
  assert.ok(result.controlTrace.inspectedNodes < 100); assert.ok(result.sceneNodes.length < 101);
  assert.equal(result.controlTrace.truncated, true); validParents(result);
});

test('V2.3 captured prop fingerprints survive both atlas layouts and right-icon variants', () => {
  // Geometry/tags from F157 and 19EC, reconstructed without private names or
  // account data. Texture packing is not an identity across these sessions.
  for (const fixtureOptions of [
    {atlasX: [880, 1002, 1124], rightVariant: true},
    {atlasX: [758, 880, 1002], rightVariant: false}
  ]) {
    const {row} = propsFixture(fixtureOptions);
    const result = setup(traceEngine(node('Scene', [row]))).capture({traceControls: true});
    const candidates = result.sceneNodes.filter(n => n.control?.semanticHint === 'central_visual_candidate');
    assert.equal(candidates.length, 1); assert.equal(candidates[0].siblingIndex, 1);
    assert.equal(result.controlTrace.scope, 'non_board_ui_controls');
    assert.equal(result.controlTrace.skippedBoardButtonCount, 0);
  }
});

test('board touchBlock buttons never consume the 64 UI-control metadata slots before the popup', () => {
  let callbackCalls = 0;
  const pieces = Array.from({length: 130}, () => node('other', [], {width: 80, height: 90}));
  const board = node('other', pieces, {width: 560, height: 720});
  const confirm = node('other', [], {width: 240, height: 102});
  // The deeper popup is deliberately visited after the board; this regression
  // must not pass only because the one-level priority look-ahead moved it first.
  const popup = node('other', [node('other', [confirm])]);
  const cc = traceEngine(node('Scene', [board, popup]));
  const receiver = {className: 'PropPopup', onUseProp(sender) {callbackCalls++;}};
  const target = node('other', [], {getComponents: type => {assert.equal(type, cc.Component); return [receiver];}});
  for (const piece of pieces) attachButton(cc, piece, {clickEvents: [{target, component: null, handler: 'touchBlock'}]});
  attachButton(cc, confirm, {enabled: true, enabledInHierarchy: true, interactable: true,
    clickEvents: [{target, component: null, handler: 'onUseProp', customEventData: ''}]});
  const result = setup(cc).capture({traceControls: true});
  assert.equal(result.sceneNodes[1].prioritizationHint, 'board_geometry');
  assert.equal(result.controlTrace.observedButtonCount, 131);
  assert.equal(result.controlTrace.skippedBoardButtonCount, 130);
  assert.equal(result.controlTrace.metadataNodeCount, 1);
  assert.equal(result.controlTrace.truncated, false);
  assert.equal(result.controlTrace.scope, 'non_board_ui_controls');
  const event = result.sceneNodes.find(n => n.control).control.button.events[0];
  assert.equal(event.component, null); assert.equal(event.resolvedComponent, 'PropPopup');
  assert.equal(event.resolution, 'unique_target_method'); assert.equal(event.handlerResolved, true);
  assert.equal(event.handlerArity, 1); assert.equal(callbackCalls, 0); validParents(result);
});

test('touchBlock filtering preserves unknown geometry, multiple handlers and props controls', () => {
  const {row, items} = propsFixture();
  const unknown = node('other'), multiple = node('other', [], {width: 80, height: 90});
  const cc = traceEngine(node('Scene', [row, unknown, multiple]));
  attachButton(cc, unknown, {clickEvents: [{handler: 'touchBlock'}]});
  attachButton(cc, multiple, {clickEvents: [{handler: 'touchBlock'}, {handler: 'onUseProp'}]});
  attachButton(cc, items[1], {clickEvents: [{handler: 'touchBlock'}]});
  const result = setup(cc).capture({traceControls: true});
  assert.equal(result.controlTrace.observedButtonCount, 3);
  assert.equal(result.controlTrace.skippedBoardButtonCount, 0);
  assert.equal(result.sceneNodes.filter(n => n.control?.button).length, 3);
});

test('target method resolution is read-only, bounded and refuses ambiguous receivers', () => {
  let calls = 0;
  const first = {className: 'One', onUseProp(a, b) {calls++;}};
  const second = {className: 'Two', onUseProp() {calls++;}};
  const extra = {className: 'Decorative'};
  for (const components of [[first, second], [first, ...Array(8).fill(extra)], [extra]]) {
    const buttonNode = node('other'), cc = traceEngine(node('Scene', [buttonNode]));
    const target = node('other', [], {getComponents: () => components});
    attachButton(cc, buttonNode, {clickEvents: [{target, component: '', handler: 'onUseProp'}]});
    const result = setup(cc).capture({traceControls: true});
    const event = result.sceneNodes[1].control.button.events[0];
    assert.equal(event.resolution, components.length === 2 ? 'ambiguous' : 'unresolved');
    assert.equal(event.handlerResolved, false); assert.equal(event.handlerArity, null);
    assert.equal(event.resolvedComponent, null);
    if (components.length > 8) assert.ok(result.controlTrace.truncationReasons.includes('component_limit'));
  }
  assert.equal(calls, 0);
});

test('target component fallback exports only class identifier and method signature', () => {
  let privateReads = 0, methodCalls = 0;
  const callback = function(a, b) { methodCalls++; };
  callback.toString = () => {privateReads++; throw Error('PRIVATE_SOURCE');};
  const receiver = {className: 'Game.PropControl', onUseProp: callback};
  for (const key of ['stock', 'token', 'cards', 'state', '_data', 'toJSON'])
    Object.defineProperty(receiver, key, {get() {privateReads++; throw Error('PRIVATE_FIELD');}});
  const target = node('other', [], {getComponents: () => [receiver]});
  for (const key of ['_components', '_uuid']) Object.defineProperty(target, key, {get() {privateReads++; throw Error('PRIVATE_TARGET');}});
  const buttonNode = node('other'), cc = traceEngine(node('Scene', [buttonNode]));
  attachButton(cc, buttonNode, {clickEvents: [{target, component: null, handler: 'onUseProp', customEventData: {token: 'PRIVATE_PAYLOAD'}}]});
  const before = [target, receiver, callback].map(Object.getOwnPropertyDescriptors);
  const result = setup(cc).capture({traceControls: true});
  const event = result.sceneNodes[1].control.button.events[0];
  assert.equal(event.resolution, 'unique_target_method'); assert.equal(event.handlerArity, 2);
  assert.equal(event.resolvedComponent, 'Game.PropControl');
  assert.equal(privateReads, 0); assert.equal(methodCalls, 0);
  assert.ok(!JSON.stringify(result).includes('PRIVATE_'));
  assert.deepEqual([target, receiver, callback].map(Object.getOwnPropertyDescriptors), before);
});

test('failed component reads cannot establish a unique handler among unobserved candidates', () => {
  const first = {className: 'First', onUseProp() {throw Error('Never invoke');}}, inaccessible = {className: 'Second'};
  Object.defineProperty(inaccessible, 'onUseProp', {get() {throw Error('PRIVATE_CALLBACK');}});
  const target = node('other', [], {getComponents: () => [first, inaccessible]});
  const item = node('other'), cc = traceEngine(node('Scene', [item]));
  attachButton(cc, item, {clickEvents: [{target, component: null, handler: 'onUseProp'}]});
  const result = setup(cc).capture({traceControls: true});
  const event = result.sceneNodes[1].control.button.events[0];
  assert.equal(event.resolution, 'unresolved'); assert.equal(event.handlerResolved, false);
  assert.equal(event.resolvedComponent, null); assert.equal(event.handlerArity, null);
  assert.ok(result.controlTrace.truncationReasons.includes('read_error'));
  assert.ok(!JSON.stringify(result).includes('PRIVATE_CALLBACK'));
});

function returnInspectionFixture({stock = '3', modal = true, shuffle = false} = {}) {
  const props = propsFixture({shuffle});
  const scene = node('Scene', [props.row]);
  const cc = traceEngine(scene); cc.ENGINE_VERSION = '2.4.4'; cc.Label = function Label() {};
  let calls = 0;
  const prop = Object.assign(Object.create(cc.Component.prototype), {
    className: 'Prop', isValid: true, stockCount: 3, used: false,
    onUseProp(sender) { calls++; }
  });
  props.items[1].getComponents = () => [prop];
  attachButton(cc, props.items[1].children[0], {
    enabled: true, enabledInHierarchy: true, interactable: true,
    clickEvents: [{target: props.items[1], component: '', handler: 'onUseProp', customEventData: ''}]
  });
  const label = {string: stock};
  const leaf = node('other', [], {width: 13.35, height: 30.24, x: 0, y: 2.5,
    getComponent: type => type === cc.Label ? label : null});
  const badge = spriteNode(frame('\u0000\u00c7\u00b6\u00e2\u0019', {}, {x: 718, y: 232, width: 36, height: 40}),
    {width: 40, height: 40, x: 40, y: 33, children: [leaf]});
  props.items[1].children.push(badge);
  const popup = Object.assign(Object.create(cc.Component.prototype), {
    className: 'UsePropAlert', isValid: true, useLimit: 3, onBtnUseClick(sender) { calls++; }
  });
  const target = node('other', [], {getComponents: () => [popup]});
  const confirm = node('other', [], {width: 240, height: 102});
  const confirmButton = {enabled: true, enabledInHierarchy: true, interactable: true,
    clickEvents: [{target, component: '', handler: 'onBtnUseClick', customEventData: ''}]};
  attachButton(cc, confirm, confirmButton);
  if (modal) scene.children.push(confirm);
  return {cc, scene, props, prop, label, badge, leaf, popup, target, confirm, confirmButton, calls: () => calls};
}
function inspections(result) { return result.sceneNodes.filter(n => n.control?.returnInspection).map(n => n.control.returnInspection); }

test('V2.5 narrowly inspects the unique return Prop and actual registered popup receiver without calling handlers', () => {
  const f = returnInspectionFixture();
  const result = setup(f.cc).capture({traceControls: true});
  const rows = inspections(result);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map(r => r.role).sort(), ['central_prop', 'confirmation_candidate']);
  const prop = rows.find(r => r.role === 'central_prop'), popup = rows.find(r => r.role === 'confirmation_candidate');
  assert.equal(prop.component, 'Prop'); assert.equal(popup.component, 'UsePropAlert');
  assert.deepEqual(prop.stockBadge, {status: 'numeric', value: 3});
  assert.deepEqual(prop.fields, [{name: 'stockCount', value: 3}, {name: 'used', value: false}]);
  assert.deepEqual(popup.fields, [{name: 'useLimit', value: 3}]);
  assert.equal(prop.methods.length, 1); assert.equal(prop.methods[0].name, 'onUseProp');
  assert.equal(popup.methods.length, 1); assert.equal(popup.methods[0].name, 'onBtnUseClick');
  assert.equal(prop.methods[0].sourceTruncated, false);
  assert.equal(f.calls(), 0); assert.equal(result.cocos.truncated, false);
  const central = result.sceneNodes.find(n => n.control?.returnInspection?.role === 'central_prop');
  assert.equal(central.control.semanticHint, 'central_visual_candidate');
  assert.equal(central.control.geometryHint, 'props_item_geometry');
});

test('V2.5 source capture requires explicit tracing and exact unambiguous Cocos2.4.4', () => {
  for (const version of ['2.4.5', '2.4.4-custom', 'unknown']) {
    const f = returnInspectionFixture(); f.cc.ENGINE_VERSION = version;
    assert.equal(inspections(setup(f.cc).capture({traceControls: true})).length, 0);
  }
  const f = returnInspectionFixture(), {capture, context} = setup(f.cc);
  assert.equal(inspections(capture()).length, 0);
  assert.equal(inspections(capture({traceControls: false})).length, 0);
  context.window.CocosEngine = '2.4.5';
  assert.equal(inspections(capture({traceControls: true})).length, 0);
  delete context.window.CocosEngine;
  assert.equal(inspections(capture({traceControls: true})).length, 2);
});

test('V2.5 never invokes component accessors, custom toString or handlers and leaves frozen objects untouched', () => {
  const f = returnInspectionFixture(); let reads = 0;
  for (const key of ['stock', 'remaining', 'tokenCount', 'privateData'])
    Object.defineProperty(f.prop, key, {get() {reads++; throw Error('PRIVATE_GETTER');}});
  f.prop.onUseProp.toString = () => {reads++; throw Error('PRIVATE_TOSTRING');};
  const tracked = [f.prop, f.popup, f.prop.onUseProp, f.label, f.badge, f.leaf, f.props.items[1]];
  tracked.forEach(Object.freeze);
  f.props.items[1].children.forEach(n => { Object.freeze(n.children); Object.freeze(n); });
  Object.freeze(f.props.items[1].children);
  const before = tracked.map(Object.getOwnPropertyDescriptors);
  const result = setup(f.cc).capture({traceControls: true});
  const prop = inspections(result).find(i => i.role === 'central_prop');
  assert.ok(prop); assert.ok(prop.reasons.includes('accessor_skipped'));
  assert.equal(reads, 0); assert.equal(f.calls(), 0);
  assert.ok(!JSON.stringify(result).includes('PRIVATE_'));
  assert.deepEqual(tracked.map(Object.getOwnPropertyDescriptors), before);
});

test('V2.5 exports only relevant own finite numeric or boolean fields and excludes sensitive identifiers', () => {
  const f = returnInspectionFixture();
  Object.assign(f.prop, {propId: 456, uidCount: 8, tokenNum: 3, authLimit: 1, passwordStock: 3,
    sessionCount: 4, accountNum: 7, emailCount: 6, phoneStock: 9, credentialCount: 2,
    unrelated: 123, stockText: 'SECRET', remainingState: {count: 99}, remainingInfinite: Infinity,
    cooldown: 1.23456, propCount: 1e8});
  const proto = Object.create(f.cc.Component.prototype); proto.inheritedCount = 77;
  Object.setPrototypeOf(f.prop, proto);
  const prop = inspections(setup(f.cc).capture({traceControls: true})).find(i => i.role === 'central_prop');
  assert.deepEqual(prop.fields, [{name: 'stockCount', value: 3}, {name: 'used', value: false}, {name: 'cooldown', value: 1.235}]);
  assert.ok(!JSON.stringify(prop).includes('SECRET'));
});

test('V2.5 numeric badge parsing rejects whitespace, signs, Unicode digits, overlong and arbitrary text', () => {
  for (const [text, value] of [['0', 0], ['12345678', 12345678], ['000003', 3]]) {
    const f = returnInspectionFixture({stock: text});
    const prop = inspections(setup(f.cc).capture({traceControls: true})).find(i => i.role === 'central_prop');
    assert.deepEqual(prop.stockBadge, {status: 'numeric', value});
  }
  for (const text of ['', '3\n', ' 3', '3 ', '+3', '-1', '1.5', '１２', '123456789', 'SECRET_LABEL', 3, null]) {
    const f = returnInspectionFixture({stock: text});
    const result = setup(f.cc).capture({traceControls: true});
    const prop = inspections(result).find(i => i.role === 'central_prop');
    assert.deepEqual(prop.stockBadge, {status: 'not_numeric', value: null}, String(text));
    assert.ok(!JSON.stringify(result).includes('SECRET_LABEL'));
  }
});

test('V2.5 only reads cc.Label.string at the exact badge and leaf fingerprint', () => {
  for (const change of [f => {f.badge.x = 39;}, f => {f.badge.width = 41;},
    f => {f.badge.active = false;}, f => {f.leaf.x = 1;}, f => {f.leaf.height = 31;},
    f => {f.leaf.children.push(node('other'));}, f => {f.badge.children.push(node('other'));},
    f => {f.badge.getComponent = type => type === f.cc.Sprite ? {spriteFrame: frame('wrong')} : null;},
    f => {f.leaf.getComponent = () => null;}]) {
    const f = returnInspectionFixture(); let reads = 0;
    Object.defineProperty(f.label, 'string', {get() {reads++; throw Error('must not read');}});
    change(f);
    const prop = inspections(setup(f.cc).capture({traceControls: true})).find(i => i.role === 'central_prop');
    assert.ok(prop); assert.deepEqual(prop.stockBadge, {status: 'unavailable', value: null}); assert.equal(reads, 0);
  }
});

test('V2.5 refuses missing, ambiguous or incomplete return anchors and never substitutes an isolated icon', () => {
  const f = returnInspectionFixture();
  f.scene.children.shift();
  assert.equal(inspections(setup(f.cc).capture({traceControls: true})).length, 0);
  const duplicate = returnInspectionFixture(); duplicate.scene.children.push(propsFixture().row);
  assert.equal(inspections(setup(duplicate.cc).capture({traceControls: true})).length, 0);
  const partial = returnInspectionFixture(); partial.scene.children.push(node('other', Array.from({length: 600}, () => node('other'))));
  const result = setup(partial.cc).capture({traceControls: true});
  assert.equal(inspections(result).length, 0); assert.ok(result.cocos.truncated);
  const badProp = returnInspectionFixture(); badProp.prop.className = 'PropLookalike';
  assert.deepEqual(inspections(setup(badProp.cc).capture({traceControls: true})).map(r => r.role), ['confirmation_candidate']);
  const wrongEvent = returnInspectionFixture();
  wrongEvent.props.items[1].children[0].getComponent = () => null;
  assert.deepEqual(inspections(setup(wrongEvent.cc).capture({traceControls: true})).map(r => r.role), ['confirmation_candidate']);
});

test('V2.5 does not guess among multiple confirmations, multiple events or ambiguous popup receivers', () => {
  for (const change of [f => {const n = node('other', [], {width: 240, height: 102}); attachButton(f.cc, n, f.confirmButton); f.scene.children.push(n);},
    f => {f.confirmButton.clickEvents.push(f.confirmButton.clickEvents[0]);},
    f => {f.target.getComponents = () => [f.popup, {className: 'UsePropAlert', onBtnUseClick() {throw Error('never');}}];},
    f => {f.confirm.active = false;}]) {
    const f = returnInspectionFixture(); change(f);
    const result = setup(f.cc).capture({traceControls: true});
    assert.deepEqual(inspections(result).map(i => i.role), ['central_prop']); assert.equal(f.calls(), 0);
  }
});

test('V2.5 honors configured confirmation component and rejects accessors without invoking them', () => {
  const f = returnInspectionFixture();
  f.confirmButton.clickEvents[0].component = 'UsePropAlert';
  f.target.getComponents = () => [f.popup, {className: 'Other', onBtnUseClick() {throw Error('never');}}];
  assert.equal(inspections(setup(f.cc).capture({traceControls: true})).length, 2);
  let getterCalls = 0;
  Object.defineProperty(f.popup, 'onBtnUseClick', {get() {getterCalls++; return () => {};}});
  assert.equal(inspections(setup(f.cc).capture({traceControls: true})).length, 0);
  assert.equal(getterCalls, 0);
});

test('V2.5 method text is bounded per method, component and capture', () => {
  const f = returnInspectionFixture();
  // Function construction belongs solely to this synthetic test fixture. The
  // production collector uses Function.prototype.toString, never execution.
  for (const receiver of [f.prop, f.popup]) {
    for (let i = 0; i < 8; i++) receiver['method' + i] = new Function('/*' + 'x'.repeat(10000) + '*/');
  }
  const rows = inspections(setup(f.cc).capture({traceControls: true}));
  assert.equal(rows.length, 2);
  let total = 0;
  for (const row of rows) {
    const count = row.methods.reduce((sum, method) => sum + method.source.length, 0);
    assert.ok(count <= 32768); total += count;
    assert.ok(row.methods.every(m => m.source.length <= 8192));
    assert.ok(row.methods.some(m => m.sourceTruncated));
    assert.ok(row.reasons.includes('source_limit')); assert.equal(row.truncated, true);
  }
  assert.equal(total, 49152);
});

test('V2.5 stops after three application prototype levels and excludes Component methods', () => {
  const f = returnInspectionFixture();
  f.cc.Component.prototype.engineMethod = function ENGINE_SOURCE_NOT_ALLOWED() {};
  let proto = f.cc.Component.prototype;
  for (let i = 4; i >= 1; i--) {
    const next = Object.create(proto); next['level' + i] = function() {return 1;}; proto = next;
  }
  Object.setPrototypeOf(f.prop, proto);
  const prop = inspections(setup(f.cc).capture({traceControls: true})).find(i => i.role === 'central_prop');
  assert.deepEqual(prop.methods.map(m => m.name), ['onUseProp', 'level1', 'level2', 'level3']);
  assert.ok(prop.reasons.includes('prototype_limit'));
  assert.ok(!JSON.stringify(prop).includes('ENGINE_SOURCE_NOT_ALLOWED'));
});

test('V2.5 inspection obeys the cooperative budget and reports partial method collection', () => {
  const f = returnInspectionFixture(); let active = false, elapsed = 0;
  for (let i = 0; i < 10; i++) f.prop['method' + i] = () => {};
  f.prop = new Proxy(f.prop, {ownKeys(target) {active = true; return Reflect.ownKeys(target);}});
  f.props.items[1].getComponents = () => [f.prop];
  const result = setup(f.cc, {performance: {now: () => active ? (elapsed += 1) : 0}}).capture({traceControls: true});
  const prop = inspections(result).find(i => i.role === 'central_prop');
  assert.ok(prop); assert.ok(prop.reasons.includes('time_budget'));
  assert.ok(prop.methods.length < 11); assert.ok(result.cocos.truncationReasons.includes('time_budget'));
  assert.equal(f.calls(), 0);
});

test('V2.5 bounds inspected property descriptors, primitive fields and method count', () => {
  const methods = returnInspectionFixture({modal: false});
  for (let i = 0; i < 20; i++) methods.prop['method' + i] = () => {};
  const methodRow = inspections(setup(methods.cc).capture({traceControls: true}))[0];
  assert.equal(methodRow.methods.length, 16); assert.ok(methodRow.reasons.includes('method_limit'));
  const fields = returnInspectionFixture({modal: false});
  for (let i = 0; i < 36; i++) fields.prop['count' + i] = i;
  const fieldRow = inspections(setup(fields.cc).capture({traceControls: true}))[0];
  assert.equal(fieldRow.fields.length, 16); assert.ok(fieldRow.reasons.includes('property_limit'));
  assert.ok(fieldRow.fields.every(f => f.name !== 'count35'));
});

test('V2.5 cannot inspect extra component sources by replacing the original Prop event target or multiplying Props', () => {
  for (const change of [f => {
    const icon = f.props.items[1].children[0], original = icon.getComponent;
    icon.getComponent = type => {
      const button = original(type);
      if (type === f.cc.Button) return {...button, clickEvents: [{target: f.target, handler: 'onUseProp'}]};
      return button;
    };
  }, f => {f.props.items[1].getComponents = () => [f.prop, {...f.prop}];}]) {
    const f = returnInspectionFixture(); change(f);
    const rows = inspections(setup(f.cc).capture({traceControls: true}));
    assert.deepEqual(rows.map(r => r.role), ['confirmation_candidate']);
    assert.equal(f.calls(), 0);
  }
});

test('V2.5 truncates UTF16 method source without splitting a surrogate pair', () => {
  const f = returnInspectionFixture({modal: false});
  let method = new Function('/*' + '😀'.repeat(6000) + '*/');
  if (Function.prototype.toString.call(method).indexOf('😀') % 2 === 0)
    method = new Function('/*x' + '😀'.repeat(6000) + '*/');
  f.prop.oversized = method;
  const result = setup(f.cc).capture({traceControls: true});
  const source = inspections(result)[0].methods.find(m => m.name === 'oversized');
  assert.equal(source.source.length, 8191); assert.equal(source.sourceTruncated, true);
  assert.ok(!/[\uD800-\uDBFF]$/.test(source.source));
  assert.equal(result.controlTrace.limits.maxSampleSourceChars, 49152);
});

test('V2.5 captures registered callback first even after the 32 own-property enumeration limit', () => {
  const f = returnInspectionFixture();
  for (const [receiver, handler] of [[f.prop, 'onUseProp'], [f.popup, 'onBtnUseClick']]) {
    const callback = receiver[handler]; delete receiver[handler];
    for (let i = 0; i < 40; i++) receiver['helper' + i] = new Function('/*' + 'x'.repeat(1000) + '*/');
    receiver[handler] = callback;
    assert.ok(Object.getOwnPropertyNames(receiver).indexOf(handler) > 32);
  }
  const rows = inspections(setup(f.cc).capture({traceControls: true}));
  assert.equal(rows.length, 2);
  for (const row of rows) {
    const handler = row.role === 'central_prop' ? 'onUseProp' : 'onBtnUseClick';
    assert.equal(row.methods[0].name, handler); assert.equal(row.methods[0].sourceTruncated, false);
    assert.equal(row.methods.filter(m => m.name === handler).length, 1);
    assert.ok(row.reasons.includes('property_limit')); assert.ok(row.methods.length <= 16);
  }
  assert.equal(f.calls(), 0);
});

test('V2.5 handles captured 240x102 parent-child popup geometry when only one node has a Button', () => {
  // V2.3 recorded two same-size nodes per popup in eleven samples. It did not
  // record their Button metadata. This fixture tests the single-button case
  // without assuming the parent and child both represent callable controls.
  const f = returnInspectionFixture();
  f.scene.children.pop();
  f.scene.children.push(node('other', [f.confirm], {width: 240, height: 102}));
  const result = setup(f.cc).capture({traceControls: true});
  assert.equal(result.sceneNodes.filter(n => n.control?.geometryHint === 'confirm_geometry').length, 2);
  const rows = result.sceneNodes.filter(n => n.control?.returnInspection?.role === 'confirmation_candidate');
  assert.equal(rows.length, 1); assert.equal(rows[0].control.button.eventCount, 1);
  assert.equal(inspections(result).length, 2); assert.equal(f.calls(), 0);
});

test('V2.6 records both observed central-power icons without claiming they are the same ability', () => {
  for (const [shuffle, iconFrameTag] of [[false, '8b2cb8bc'], [true, '8e2cbd75']]) {
    const f = returnInspectionFixture({shuffle});
    const result = setup(f.cc).capture({traceControls: true});
    const central = inspections(result).find(i => i.role === 'central_prop');
    assert.ok(central); assert.equal(central.iconFrameTag, iconFrameTag);
    assert.equal(result.sceneNodes.find(n => n.control?.returnInspection === central).control.semanticHint, 'central_visual_candidate');
    assert.ok(!inspections(result).some(i => i.role === 'return_prop'));
    assert.equal(f.calls(), 0);
  }
});

test('V2.6 scopes the modal source to UsePropAlert.onBtnUseClick even without a central visual match', () => {
  const f = returnInspectionFixture();
  const icon = f.props.items[1].children[0], original = icon.getComponent;
  icon.getComponent = type => type === f.cc.Sprite ? {spriteFrame: frame('unknown prop icon')} : original(type);
  const rows = inspections(setup(f.cc).capture({traceControls: true}));
  assert.deepEqual(rows.map(i => i.role), ['confirmation_candidate']);
  assert.equal(rows[0].component, 'UsePropAlert'); assert.equal(rows[0].methods[0].name, 'onBtnUseClick');
  assert.deepEqual(rows[0].stockBadge, {status: 'unavailable', value: null});
  assert.equal(f.calls(), 0);
});

test('V2.6 never assigns central stock to a different power opened in the shared modal', () => {
  const f = returnInspectionFixture({shuffle: true, stock: '9'});
  const rows = inspections(setup(f.cc).capture({traceControls: true}));
  assert.deepEqual(rows.find(i => i.role === 'central_prop').stockBadge, {status: 'numeric', value: 9});
  assert.deepEqual(rows.find(i => i.role === 'confirmation_candidate').stockBadge, {status: 'unavailable', value: null});
});

test('V2.6 does not read source from unrelated popup callbacks with matching geometry', () => {
  for (const mutate of [
    f => {f.popup.className = 'UnrelatedPopup';},
    f => {f.confirmButton.clickEvents[0].handler = 'otherCallback'; f.popup.otherCallback = () => {};},
    f => {f.confirmButton.clickEvents[0].component = 'UnrelatedPopup';},
    f => {f.scene.children = [f.confirm];}
  ]) {
    const f = returnInspectionFixture(); mutate(f);
    const rows = inspections(setup(f.cc).capture({traceControls: true}));
    assert.ok(rows.every(i => i.role !== 'confirmation_candidate')); assert.equal(f.calls(), 0);
  }
});

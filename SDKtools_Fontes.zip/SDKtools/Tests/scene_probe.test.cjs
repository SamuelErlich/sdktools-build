const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(process.env.SDKTOOLS_PROBE_SOURCE || path.join(__dirname, '../Resources/scene_probe.js'), 'utf8');
function setup(cc, extra = {}) {
  const document = { readyState: 'complete', querySelectorAll: (selector) => selector === 'canvas' ? [{ width: 900, height: 1800,
    getBoundingClientRect: () => ({ x: 0, y: 12, width: 450, height: 900 }) }] : [] };
  const context = vm.createContext({ window: { cc, innerWidth: 450, innerHeight: 900, devicePixelRatio: 2 }, document,
    performance: { now: () => 0 }, ...extra });
  const before = Object.keys(context.window);
  vm.runInContext('var sdktoolsTestCapture = ' + source, context, { timeout: 100 });
  assert.deepEqual(Object.keys(context.window), before, 'resource factory must not install globals itself');
  return { context, capture: () => JSON.parse(JSON.stringify(vm.runInContext('sdktoolsTestCapture()', context, { timeout: 500 }))) };
}
function run(cc, extra) { return setup(cc, extra).capture(); }
function node(name, children = [], overrides = {}) { return { name, isValid: true, active: true, activeInHierarchy: true,
  x: 12, y: 24, z: 0, width: 40, height: 60, anchorX: .5, anchorY: .5, scaleX: 1, scaleY: 1, angle: 0, opacity: 255,
  children, getComponent: () => null, ...overrides }; }
function engine(scene) { return { ENGINE_VERSION: '2.4.5', director: { getScene: () => scene }, Sprite: function(){},
  v2: (x, y) => ({x, y}) }; }
function validParents(result) {
  result.sceneNodes.forEach((row, index) => {
    assert.equal(row.index, index);
    if (row.parent === null) { assert.equal(row.depth, 0); assert.equal(row.parentID, null); }
    else { assert.ok(row.parent < index); assert.equal(row.parentID, result.sceneNodes[row.parent].nodeID);
      assert.equal(row.depth, result.sceneNodes[row.parent].depth + 1); }
  });
}
function frame(name = 'frame', texture = {}, rect = {x: 2, y: 232, width: 120, height: 135}) {
  return { name, getRect: () => rect, getTexture: () => texture };
}
function spriteNode(publicFrame, overrides = {}) {
  return node('other', [], { getComponent: () => ({ spriteFrame: publicFrame }), ...overrides });
}
test('DOM-only observation remains useful without exposed Cocos', () => {
  const result = run(undefined); assert.equal(result.status, 'cocos_not_exposed');
  assert.equal(result.dom.canvasCount, 1); assert.equal(result.dom.canvases[0].cssRect.width, 450);
  assert.equal(result.sceneNodes.length, 0); assert.equal(result.version, 2);
});
test('unsupported engine does not call scene API', () => {
  let called = false;
  const result = run({ ENGINE_VERSION: '3.8.8', director: { getScene: () => { called = true; throw Error(); } } });
  assert.equal(result.status, 'cocos_version_unsupported'); assert.equal(called, false);
});
test('active geometry, parent references and world origin do not imply card identity', () => {
  const result = run(engine(node('Canvas', [node('Card_1', [], { convertToWorldSpaceAR: () => ({x: 375, y: 887.594}) })])));
  assert.equal(result.sceneNodes[1].category, 'card'); assert.equal(result.sceneNodes[1].parent, 0);
  assert.deepEqual(result.sceneNodes[1].worldOrigin, {x: 375, y: 887.594});
  assert.equal(result.cocos.occlusionResolved, false); assert.equal(result.cocos.cardRulesKnown, false);
  assert.equal(result.cocos.identityScope, 'probe_closure_object_identity_not_card_identity'); validParents(result);
});
test('private fields, text, URLs, storage and prototype hooks are never read', () => {
  const n = node('username_SECRET_ABC');
  for (const key of ['password', 'text', 'token', 'url', '_components', '_uuid', 'cards', 'cardType'])
    Object.defineProperty(n, key, {get: () => {throw Error('Forbidden read of ' + key);}});
  const w = {cc: engine(n), innerWidth: 450, innerHeight: 900, devicePixelRatio: 2};
  for (const key of ['localStorage', 'sessionStorage', 'fetch']) Object.defineProperty(w, key, { get: () => {throw Error('Forbidden global');} });
  const result = run(null, {window: w}); assert.ok(!JSON.stringify(result).includes('SECRET_ABC'));
  assert.equal(result.cocos.stats.readErrors, 0);
});
test('reconstructed broad board reaches descendant faces of 144 pieces beyond the old 64-child cap', () => {
  // Geometry and parent shape reconstructed from the Asia capture, not an
  // assertion that the US app has the same card types or complete scene model.
  const texture = {}, frames = [frame('cheese', texture), frame('rounded', texture, {x: 368, y: 232, width: 120, height: 135})];
  const pieces = Array.from({length: 144}, (_, i) => node('other', [node('other', [spriteNode(frames[i % 2])])],
    {width: 80, height: 90, x: (i % 7) * 70, y: Math.floor(i / 7) * 80}));
  const board = node('other', pieces, {width: 560, height: 720, y: 76});
  const decoration = Array.from({length: 120}, () => node('other'));
  const result = run(engine(node('Canvas', [...decoration, board])));
  assert.equal(result.sceneNodes.filter(n => n.sprite).length, 144);
  assert.equal(result.sceneNodes[1].prioritizationHint, 'board_geometry');
  assert.equal(result.sceneNodes[1].childCountReal, 144); assert.equal(result.sceneNodes[1].childrenQueued, 144);
  assert.equal(result.sceneNodes[2].siblingIndex, 0);
  assert.equal(result.sceneNodes[4].sprite.atlasRect.width, 120);
  assert.equal(result.cocos.truncated, false); validParents(result);
});
test('a bounded partial dense board retains complete early piece subtrees instead of only their roots', () => {
  const pieces = Array.from({length: 400}, () => node('other', [node('other', [spriteNode(frame()), spriteNode(frame())])], {width: 80, height: 90}));
  const result = run(engine(node('Canvas', [node('other', pieces, {width: 560, height: 720})])));
  assert.equal(result.sceneNodes.length, 1536); assert.ok(result.sceneNodes.filter(n => n.sprite).length > 700);
  assert.ok(result.cocos.truncationReasons.includes('node_limit')); validParents(result);
});
test('child limit reports real child count and does not pretend it captured all children', () => {
  const result = run(engine(node('Canvas', Array.from({length: 600}, () => node('other')))));
  assert.equal(result.sceneNodes[0].childCountReal, 600); assert.equal(result.sceneNodes[0].childrenQueued, 512);
  assert.equal(result.sceneNodes.length, 513); assert.ok(result.cocos.truncationReasons.includes('child_limit'));
});
test('cycle and repeated references terminate without invalid parent indices', () => {
  const root = node('Canvas'), a = node('Card'); root.children = [a, a]; a.children.push(root);
  const result = run(engine(root)); assert.equal(result.sceneNodes.length, 2);
  assert.equal(result.cocos.stats.skippedRepeated, 2); validParents(result);
});
test('inactive subtree is omitted even if a child incorrectly claims to be active', () => {
  const hidden = node('CardHidden', [node('CardHiddenChild')]); hidden.activeInHierarchy = false;
  const result = run(engine(node('Canvas', [hidden]))); assert.equal(result.sceneNodes.length, 1);
  assert.equal(result.cocos.stats.skippedInactive, 1);
});
test('non-finite and excessive geometry become null', () => {
  const result = run(engine(node('Card', [], {x: Infinity, y: NaN, width: 1e20})));
  assert.equal(result.sceneNodes[0].local.x, null); assert.equal(result.sceneNodes[0].local.y, null);
  assert.equal(result.sceneNodes[0].local.width, null);
});
test('sprite identities refer to objects without reading texture filenames or private data', () => {
  const texture = {};
  for (const key of ['url', 'nativeUrl', 'name', '_uuid', '_image']) Object.defineProperty(texture, key, {get: () => {throw Error('private');}});
  const shared = frame('PRIVATE_FRAME_ABC', texture), differentFrame = frame('PRIVATE_FRAME_ABC', texture);
  const result = run(engine(node('Canvas', [spriteNode(shared), spriteNode(shared), spriteNode(differentFrame)])));
  const [a, b, c] = result.sceneNodes.slice(1).map(n => n.sprite);
  assert.equal(a.frameID, b.frameID); assert.notEqual(a.frameID, c.frameID); assert.equal(a.textureID, c.textureID);
  assert.match(a.frameNameTag, /^[a-f0-9]{8}$/); assert.ok(!JSON.stringify(result).includes('PRIVATE_FRAME_ABC'));
  assert.equal(result.cocos.stats.readErrors, 0);
});
test('node IDs survive sibling reordering while indices and sibling indices describe current order', () => {
  const a = node('other', [], {x: 1}), b = node('other', [], {x: 2}), root = node('Canvas', [a, b]);
  const {capture} = setup(engine(root)), first = capture(); root.children.reverse(); const second = capture();
  assert.equal(first.sceneNodes[1].nodeID, second.sceneNodes[2].nodeID);
  assert.equal(first.sceneNodes[2].nodeID, second.sceneNodes[1].nodeID);
  assert.equal(second.sceneNodes[1].siblingIndex, 0); validParents(second);
});
test('new scene objects receive new IDs within a retained closure', () => {
  let scene = node('Canvas', [node('Card')]); const cc = engine(scene); cc.director.getScene = () => scene;
  const {capture} = setup(cc), first = capture(); scene = node('Canvas', [node('Card')]); const second = capture();
  const oldIDs = new Set(first.sceneNodes.map(n => n.nodeID)); assert.ok(second.sceneNodes.every(n => !oldIDs.has(n.nodeID)));
});
test('new factory has separate identity state, requiring the native context ID for joins', () => {
  const cc = engine(node('Canvas', [node('Card')])); const first = setup(cc), second = setup(cc);
  assert.equal(first.capture().sceneNodes[0].nodeID, 'n1'); assert.equal(second.capture().sceneNodes[0].nodeID, 'n1');
  assert.equal(Object.keys(first.context.window).some(k => /sdktools/i.test(k)), false);
});
test('protected engine global returns a bounded error without exposing exception text', () => {
  const window = {}; Object.defineProperty(window, 'cc', {get: () => {throw Error('secret-token');}});
  const result = run(null, {window}); assert.equal(result.status, 'capture_error');
  assert.ok(result.cocos.truncationReasons.includes('read_error')); assert.ok(!JSON.stringify(result).includes('secret-token'));
});
test('one protected public node property does not abort unrelated siblings', () => {
  const a = node('Card'); Object.defineProperty(a, 'width', {get: () => {throw Error('secret');}});
  const result = run(engine(node('Canvas', [a, node('Card')]))); assert.equal(result.sceneNodes.length, 3);
  assert.ok(result.cocos.truncationReasons.includes('read_error')); assert.ok(!JSON.stringify(result).includes('secret'));
});
test('soft time budget is checked while inspecting broad children and reports truncation', () => {
  let time = 0; const result = run(engine(node('Canvas', Array.from({length: 400}, () => node('other')))),
    {performance: {now: () => time++}});
  assert.ok(result.cocos.truncationReasons.includes('time_budget'));
  assert.ok(result.cocos.stats.inspectedChildren < 400); assert.ok(result.sceneNodes.length < 1536); validParents(result);
});
test('depth limit is explicit and parent references remain intact', () => {
  const root = node('Canvas'); let cursor = root;
  for (let i = 0; i < 30; i++) {const child = node('other'); cursor.children.push(child); cursor = child;}
  const result = run(engine(root)); assert.equal(result.sceneNodes.length, 25);
  assert.ok(result.cocos.truncationReasons.includes('depth_limit')); validParents(result);
});
test('queue bound is enforced for repeatedly broad subtrees', () => {
  const root = node('Canvas'); let cursor = root;
  for (let depth = 0; depth < 9; depth++) { cursor.children = Array.from({length: 512}, () => node('other')); cursor = cursor.children[0]; }
  const result = run(engine(root)); assert.ok(result.cocos.stats.queuePeak <= 4096);
  assert.ok(result.cocos.truncationReasons.includes('queue_limit')); validParents(result);
});
test('visit cap bounds invalid and repeated entries independently of output node count', () => {
  const invalid = {isValid: false};
  const result = run(engine(node('Canvas', Array.from({length: 9}, () => node('other', Array(512).fill(invalid))))));
  assert.equal(result.cocos.stats.visitedNodes, 4096); assert.ok(result.cocos.truncationReasons.includes('visit_limit'));
  assert.ok(result.sceneNodes.length < 11);
});
test('frozen scene, children, frames and texture remain untouched', () => {
  const texture = Object.freeze({}), sf = Object.freeze(frame('frame', texture));
  const child = spriteNode(sf); Object.freeze(child.children); Object.freeze(child);
  const root = node('Canvas', [child]); Object.freeze(root.children); Object.freeze(root);
  const result = run(engine(root)); assert.equal(result.status, 'cocos2_scene_captured');
  assert.equal(result.cocos.stats.readErrors, 0); assert.equal(root.children[0], child);
});
test('scene API errors and missing scene have distinct statuses', () => {
  const cc = engine(null); assert.equal(run(cc).status, 'no_scene');
  cc.director.getScene = () => {throw Error('secret');}; const result = run(cc);
  assert.equal(result.status, 'capture_error'); assert.ok(!JSON.stringify(result).includes('secret'));
});

test('director scene root inactive flags do not discard its active descendants', () => {
  // Regression of the US report: visitedNodes=1, skippedInactive=1, zero rows.
  // This reconstructs the rejected root condition, not the unrecorded game tree.
  for (const [active, activeInHierarchy] of [[false, true], [true, false], [false, false]]) {
    const root = node('Scene', [spriteNode(frame())], {active, activeInHierarchy});
    const cc = engine(root); cc.ENGINE_VERSION = '2.4.4';
    const result = run(cc);
    assert.equal(result.sceneNodes.length, 2);
    assert.equal(result.status, 'cocos2_scene_captured');
    assert.equal(result.cocos.stats.skippedInactive, 0);
    assert.equal(result.cocos.stats.inspectedChildren, 1);
    assert.equal(result.cocos.sceneRoot.active, active);
    assert.equal(result.cocos.sceneRoot.activeInHierarchy, activeInHierarchy);
    assert.equal(result.cocos.sceneRoot.childCountReal, 1);
    assert.equal(result.cocos.sceneRoot.nodeID, result.sceneNodes[0].nodeID);
    assert.equal(result.sceneNodes[0].structuralOnly, true);
    assert.equal(result.sceneNodes[0].isSceneRoot, true);
    assert.equal(result.cocos.visibilityVerified, false);
    assert.equal(result.cocos.activeNodesOnly, false);
    assert.equal(result.cocos.inactiveDescendantsSkipped, true);
    assert.equal(result.cocos.descendantNodeCount, 1);
    assert.equal(result.cocos.spriteNodeCount, 1);
    validParents(result);
  }
});
test('inactive root exception does not traverse inactive non-root subtrees', () => {
  const hidden = node('CardHidden', [spriteNode(frame('unread'))], {active: false});
  const hiddenHierarchy = node('CardHidden', [spriteNode(frame('unread2'))], {activeInHierarchy: false});
  const result = run(engine(node('Scene', [hidden, hiddenHierarchy, spriteNode(frame('visible'))], {active: false})));
  assert.equal(result.sceneNodes.length, 2);
  assert.equal(result.cocos.stats.skippedInactive, 2);
  assert.equal(result.cocos.descendantNodeCount, 1);
  assert.equal(result.cocos.spriteNodeCount, 1);
  validParents(result);
});
test('unknown root and descendant flags are null, not a false assertion', () => {
  const child = node('Card', [], {active: undefined, activeInHierarchy: undefined});
  const root = node('Scene', [child], {active: undefined, activeInHierarchy: undefined, isValid: undefined});
  const result = run(engine(root));
  assert.equal(result.cocos.sceneRoot.active, null);
  assert.equal(result.cocos.sceneRoot.activeInHierarchy, null);
  assert.equal(result.cocos.sceneRoot.isValid, null);
  assert.equal(result.sceneNodes[1].active, null);
  assert.equal(result.sceneNodes[1].activeInHierarchy, null);
  assert.equal(result.cocos.visibilityVerified, false);
  assert.equal(result.cocos.descendantNodeCount, 1);
});
test('root-only observation is explicitly empty and excludes root sprites', () => {
  const root = spriteNode(frame('root_not_a_card'), {active: false});
  for (const key of ['getComponent', 'convertToWorldSpaceAR'])
    Object.defineProperty(root, key, {get() {throw Error('structural root must not invoke render methods');}});
  const result = run(engine(root));
  assert.equal(result.status, 'cocos2_scene_observed_empty');
  assert.equal(result.sceneNodes.length, 1);
  assert.equal(result.sceneNodes[0].structuralOnly, true);
  assert.equal(result.sceneNodes[0].sprite, undefined);
  assert.equal(result.cocos.descendantNodeCount, 0);
  assert.equal(result.cocos.spriteNodeCount, 0);
  assert.equal(result.cocos.truncated, false);
});
test('invalid root and incomplete empty observation have distinct diagnostic statuses', () => {
  const invalid = run(engine(node('Scene', [node('Card')], {isValid: false})));
  assert.equal(invalid.status, 'scene_root_invalid');
  assert.equal(invalid.cocos.sceneRoot.isValid, false);
  assert.equal(invalid.sceneNodes.length, 0);
  assert.equal(invalid.cocos.stats.skippedInvalid, 1);
  const root = node('Scene', [], {active: false});
  Object.defineProperty(root, 'children', {get() {throw Error('do not expose this');}});
  const incomplete = run(engine(root));
  assert.equal(incomplete.status, 'cocos2_scene_observed_incomplete');
  assert.equal(incomplete.cocos.stats.readErrors, 1);
  assert.ok(incomplete.cocos.truncationReasons.includes('read_error'));
  assert.equal(incomplete.cocos.descendantNodeCount, 0);
  assert.ok(!JSON.stringify(incomplete).includes('do not expose this'));
});
test('inactive frozen root and descendant objects stay unmodified across captures', () => {
  const texture = Object.freeze({}), sf = Object.freeze(frame('frame', texture));
  const child = spriteNode(sf); Object.freeze(child.children); Object.freeze(child);
  const hidden = node('CardHidden', [spriteNode(frame())], {active: false});
  Object.freeze(hidden.children); Object.freeze(hidden);
  const root = node('Scene', [child, hidden], {active: false, activeInHierarchy: false});
  Object.freeze(root.children); Object.freeze(root);
  const cc = engine(root); Object.freeze(cc.director); Object.freeze(cc);
  const before = [root, child, hidden, sf, texture].map(o => Object.getOwnPropertyDescriptors(o));
  const {capture} = setup(cc), first = capture(), second = capture();
  assert.equal(first.cocos.descendantNodeCount, 1);
  assert.equal(first.cocos.spriteNodeCount, 1);
  assert.equal(first.cocos.stats.readErrors, 0);
  assert.equal(first.cocos.stats.skippedInactive, 1);
  assert.equal(first.sceneNodes[1].nodeID, second.sceneNodes[1].nodeID);
  assert.deepEqual([root, child, hidden, sf, texture].map(o => Object.getOwnPropertyDescriptors(o)), before);
});

test('US dense-board reconstruction captures all 225 piece subtrees within bounded capacity', () => {
  // Reconstruct the measured 225 direct children, including three active sprite
  // layers and three inactive extras per piece. This is a coverage regression,
  // not a claim that an iPhone can always traverse this tree inside 10 ms.
  const texture = {}, frames = [frame('base', texture), frame('face', texture), frame('mask', texture)];
  const pieces = Array.from({length: 225}, () => node('other', [
    ...frames.map(f => spriteNode(f)),
    ...Array.from({length: 3}, () => node('other', [], {active: false}))
  ], {width: 80, height: 90}));
  const board = node('other', pieces, {width: 560, height: 720});
  const root = node('Scene', [board, ...Array.from({length: 80}, () => node('other'))],
    {active: false, activeInHierarchy: true});
  const result = run(engine(root)), boardRow = result.sceneNodes[1];
  assert.equal(result.sceneNodes.length, 982);
  assert.equal(result.sceneNodes.filter(n => n.parentID === boardRow.nodeID).length, 225);
  assert.equal(result.cocos.spriteNodeCount, 675);
  assert.equal(result.cocos.stats.skippedInactive, 675);
  assert.equal(result.cocos.stats.visitedNodes, 1657);
  assert.equal(result.cocos.stats.frameMetadataReads, 3);
  assert.equal(result.cocos.stats.frameMetadataCacheHits, 672);
  assert.equal(result.cocos.truncated, false);
  assert.equal(result.cocos.stats.remainingQueued, 0);
  validParents(result);
});

test('shared frame metadata is read once per capture and refreshed on the next capture', () => {
  let nameReads = 0, rectReads = 0, textureReads = 0;
  let currentName = 'first', currentRect = {x: 2, y: 232, width: 120, height: 135}, currentTexture = {};
  const shared = {
    get name() { nameReads++; return currentName; },
    getRect() { rectReads++; return currentRect; },
    getTexture() { textureReads++; return currentTexture; }
  };
  const root = node('Scene', Array.from({length: 100}, () => spriteNode(shared)));
  const {capture} = setup(engine(root)), first = capture();
  assert.deepEqual([nameReads, rectReads, textureReads], [1, 1, 1]);
  assert.equal(first.cocos.stats.frameMetadataReads, 1);
  assert.equal(first.cocos.stats.frameMetadataCacheHits, 99);
  currentName = 'changed'; currentRect.x = 99; currentTexture = {};
  const second = capture();
  assert.deepEqual([nameReads, rectReads, textureReads], [2, 2, 2]);
  assert.equal(second.cocos.stats.frameMetadataReads, 1);
  assert.equal(second.cocos.stats.frameMetadataCacheHits, 99);
  const a = first.sceneNodes[1].sprite, b = second.sceneNodes[1].sprite;
  assert.equal(a.frameID, b.frameID);
  assert.notEqual(a.frameNameTag, b.frameNameTag);
  assert.notEqual(a.textureID, b.textureID);
  assert.equal(a.atlasRect.x, 2); assert.equal(b.atlasRect.x, 99);
  assert.ok(second.sceneNodes.slice(1).every(n => n.sprite.atlasRect.x === 99));
});

test('a failed shared frame getter is bounded to one attempt per capture and retried later', () => {
  let attempts = 0, broken = true;
  const shared = frame();
  shared.getRect = () => { attempts++; if (broken) throw Error('secret'); return {x: 1, y: 2, width: 3, height: 4}; };
  const {capture} = setup(engine(node('Scene', Array.from({length: 100}, () => spriteNode(shared)))));
  const first = capture();
  assert.equal(attempts, 1); assert.equal(first.cocos.stats.readErrors, 1);
  assert.ok(first.cocos.truncationReasons.includes('read_error'));
  assert.equal(first.cocos.spriteNodeCount, 100);
  assert.ok(first.sceneNodes.slice(1).every(n => n.sprite.textureID && !n.sprite.atlasRect));
  assert.ok(!JSON.stringify(first).includes('secret'));
  broken = false; const second = capture();
  assert.equal(attempts, 2); assert.equal(second.cocos.stats.readErrors, 0);
  assert.equal(second.cocos.truncated, false);
  assert.ok(second.sceneNodes.slice(1).every(n => n.sprite.atlasRect.width === 3));
});

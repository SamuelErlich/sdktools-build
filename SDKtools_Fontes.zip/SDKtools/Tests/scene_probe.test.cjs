const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../Resources/scene_probe.js'), 'utf8');
function run(cc, extra = {}) {
  const document = { readyState: 'complete', querySelectorAll: (selector) => selector === 'canvas' ? [{ width: 900, height: 1800,
    getBoundingClientRect: () => ({ x: 0, y: 12, width: 450, height: 900 }) }] : [] };
  const context = { window: { cc, innerWidth: 450, innerHeight: 900, devicePixelRatio: 2 }, document,
    performance: { now: () => 0 }, ...extra };
  return JSON.parse(JSON.stringify(vm.runInNewContext(source, context, { timeout: 100 })));
}
function node(name, children = []) { return { name, isValid: true, active: true, activeInHierarchy: true,
  x: 12, y: 24, width: 40, height: 60, children, getComponent: () => null }; }
function engine(scene) { return { ENGINE_VERSION: '2.4.11', director: { getScene: () => scene }, Sprite: function(){} }; }
test('DOM-only observation remains useful without exposed Cocos', () => {
  const result = run(undefined); assert.equal(result.status, 'cocos_not_exposed');
  assert.equal(result.dom.canvasCount, 1); assert.equal(result.dom.canvases[0].cssRect.width, 450);
  assert.equal(result.sceneNodes.length, 0);
});
test('unknown engine version does not call scene API', () => {
  let called = false;
  const result = run({ ENGINE_VERSION: '3.8.8', director: { getScene: () => { called = true; throw Error(); } } });
  assert.equal(result.status, 'cocos_version_unsupported'); assert.equal(called, false);
});
test('active scene geometry is observed without claiming card identity', () => {
  const result = run(engine(node('Canvas', [node('Card_1')])));
  assert.equal(result.sceneNodes[1].category, 'card'); assert.equal(result.sceneNodes[1].parent, 0);
  assert.equal(result.sceneNodes[1].local.x, 12); assert.equal(result.cocos.occlusionResolved, false);
  assert.equal(result.cocos.cardRulesKnown, false);
});
test('private texts, names, URL and arbitrary game fields do not enter output', () => {
  const n = node('username_SECRET_ABC'); n.password = 'SECRET_ABC'; n.text = 'SECRET_ABC';
  n.token = 'SECRET_ABC'; n.url = 'https://private.invalid/?secret=SECRET_ABC';
  assert.ok(!JSON.stringify(run(engine(n))).includes('SECRET_ABC'));
});
test('cycles and wide scenes terminate with an explicit coverage limit', () => {
  const root = node('Canvas'); root.children = Array.from({length: 300}, (_,i) => node('Card_'+i));
  root.children[0].children.push(root);
  const result = run(engine(root)); assert.ok(result.sceneNodes.length <= 120); assert.equal(result.cocos.truncated, true);
});
test('inactive subtrees are omitted', () => {
  const hidden = node('CardHidden', [node('CardHiddenChild')]); hidden.activeInHierarchy = false;
  assert.equal(run(engine(node('Canvas', [hidden]))).sceneNodes.length, 1);
});
test('non-finite geometry is sanitized', () => {
  const n = node('Card'); n.x = Infinity; n.y = NaN; n.width = 1e20;
  const local = run(engine(n)).sceneNodes[0].local;
  assert.equal(local.x, null); assert.equal(local.y, null); assert.equal(local.width, null);
});
test('sprite metadata is bounded and source name is hashed', () => {
  const n = node('Card'); n.getComponent = () => ({ spriteFrame: { name: 'PRIVATE_FRAME_ABC',
    getRect: () => ({x: 1, y: 2, width: 3, height: 4}) } });
  const result = run(engine(n)); assert.match(result.sceneNodes[0].sprite.frameNameTag, /^[a-f0-9]{8}$/);
  assert.ok(!JSON.stringify(result).includes('PRIVATE_FRAME_ABC'));
});
test('exceptions return an explicit incomplete observation', () => {
  const result = run({ ENGINE_VERSION: '2.4.11', director: { getScene: () => { throw Error('secret'); } } });
  assert.equal(result.status, 'capture_error'); assert.ok(!JSON.stringify(result).includes('secret'));
});
test('observation does not mutate a frozen host scene', () => {
  const n = node('Canvas'); Object.freeze(n.children); Object.freeze(n);
  assert.equal(run(engine(n)).status, 'cocos2_scene_captured'); assert.equal(n.x, 12);
});

const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const resource=path.join(__dirname,'../Resources/autoplay_coop.js');
function fixture({types=['a'],tray=['a','a'],self=false}={}){
 const root={},board={},trayNode={},cc={Component:function(){},director:{getScene:()=>root},js:{getClassName:c=>c.className}},calls=[];
 const window={cc},document={visibilityState:'visible'},context=vm.createContext({window,document,Date:{now:()=>0}});
 assert.ok(fs.existsSync(resource),'cooperative coordinator resource is required');
 const plan=vm.runInContext(fs.readFileSync(path.join(__dirname,'../Resources/autoplay_planner.js'),'utf8'),context);
 const coop=vm.runInContext(fs.readFileSync(resource,'utf8'),context)(plan);
 const store={uid:1,rid:2,start_time:3,state:2,isWatcher:false,isHotTiming:false,isAddingCommonBlock:false,isUsingPenetrateProp:false,isCanTouchBlock:true,common_blocks:[]};
 const owner={className:'CommonStore',isValid:true,node:{},itemsNode:{children:[]}},layer={CommonStore:owner},s={cc,root,board,trayNode,gameLayer:{},emitter:function(args){calls.push(args);},playState:{uid:1,rid:2,start:3,store,layer},records:new Map(),cards:[],tray:[],refs:new Map(),signature:'one',capacity:7};s.records.set(owner.node,root);
 const snapshots=[],cards=[];
 for(let i=0;i<3;i++){
  const node={isValid:true,active:true,activeInHierarchy:true,children:[],getComponents:()=>[item]},row={lock_state:2,block:i<types.length?{id:'supply-private-'+i,type:types[i].charCodeAt(0),state:3}:null},item={className:'CommonStoreItem',isValid:true,node,commonStore:owner,commonBlock:row,isSelf:i===2||self,isEmpty:!row.block};
  owner.itemsNode.children.push(node);store.common_blocks.push(row);s.records.set(node,owner.itemsNode);
  const snap={index:i,isSelf:item.isSelf,empty:item.isEmpty,lock:2,card:row.block?{type:'type:'+row.block.type,specialType:0}:null};snapshots.push(snap);
  if(row.block){const face={frame:{}},mask={active:false,activeInHierarchy:false},block={className:'Block',node:null,isValid:true,canTouch:true,isTouched:false,blockInfo:row.block},card={isValid:true,active:true,activeInHierarchy:true,parent:node,getComponents:()=>[block]};block.node=card;node.children.push(card);s.records.set(card,node);cards.push({node:card,block,face,mask,item,row});}
 }
 for(let i=0;i<tray.length;i++){const raw='tray-private-'+i,c={id:'c'+i,type:'type:'+tray[i].charCodeAt(0),zone:'tray',metadata:{rawID:raw}};s.tray.push(c);s.refs.set(c.id,c);}
 s.phaseSnapshot={complete:true,progressPercent:80,rules:{allRecognized:true},sharedSlots:snapshots};
 const api={parked:()=>true,layout:n=>{const c=cards.find(c=>c.node===n);return{block:c.block,face:c.face,mask:c.mask};},frame:n=>n.frame,id:n=>'node'+cards.findIndex(c=>c.node===n),ready:()=>true,budget:()=>{},
  action:row=>({receiver:cards.find(c=>c.node===row.node).block,button:{},event:{emit(args){calls.push(args);}}}),input:()=>({type:'touchend'})};
 function begin(){return coop.begin(s,{cooperativePlanning:true,allowAction:true},api,0);}
 function settle(){const c=cards[0];s.tray=[];s.refs=new Map();c.node.parent=null;c.item.node.children=[];c.item.isEmpty=true;c.row.block=null;s.phaseSnapshot.sharedSlots[0].empty=true;s.phaseSnapshot.sharedSlots[0].card=null;s.signature='settled';}
 return{s,store,cc,window,document,cards,calls,coop,api,begin,settle,observe:t=>coop.observe(s,{cooperativePlanning:true,allowAction:true},t)};
}
test('useful allied supply uses one registered touch and confirms exact stable trio effect',()=>{
 const f=fixture();assert.equal(f.begin().status,'original_event_dispatched');assert.equal(f.calls.length,1);assert.equal(f.coop.busy(),true);
 f.begin();assert.equal(f.calls.length,1);f.settle();assert.equal(f.observe(100).status,'waiting_confirmation');assert.equal(f.observe(180).status,'move_confirmed');assert.equal(f.coop.busy(),false);assert.equal(f.coop.diagnostic().confirmed,1);
 assert.doesNotMatch(JSON.stringify(f.coop.diagnostic()),/private|rawID|uid|rid/);
});
test('two allied supplies can complete a tray single without taking unrelated cards',()=>{
 const f=fixture({types:['a','a'],tray:['a']});assert.equal(f.begin().status,'original_event_dispatched');assert.equal(f.calls.length,1);
 const wrong=fixture({types:['b'],tray:['a','a']});assert.equal(wrong.begin(),null);assert.equal(wrong.calls.length,0);
 const own=fixture({self:true});assert.equal(own.begin(),null);assert.equal(own.calls.length,0);
});
test('phase and slot changes after planning fail closed before dispatch',()=>{
 for(const change of [f=>{f.api.ready=()=>false;},f=>{f.api.ready=()=>{f.cards[0].row.block={id:'changed',type:98,state:3};return true;};},f=>{f.s.phaseSnapshot.complete=false;},f=>{f.cards[0].block.canTouch=false;}]){
  const f=fixture();change(f);f.begin();assert.equal(f.calls.length,0);
 }
});
test('pause chat and timeout preserve pending supply and never resend or count unrelated changes',()=>{
 const f=fixture();f.begin();f.coop.freeze();f.s.signature='unrelated';assert.equal(f.observe(9000).status,'dispatch_uncertain');assert.equal(f.calls.length,1);
 f.document.visibilityState='hidden';f.begin();assert.equal(f.calls.length,1);f.document.visibilityState='visible';f.settle();f.observe(9100);assert.equal(f.observe(9200).status,'move_confirmed');
});
test('malformed identity or incomplete rules cannot authorize a pickup',()=>{
 for(const mutate of [f=>{f.store.isWatcher=true;},f=>{f.s.phaseSnapshot.rules.allRecognized=false;},f=>{f.store.start_time++;},f=>{f.cards[0].block.isTouched=true;}]){
  const f=fixture();mutate(f);f.begin();assert.equal(f.calls.length,0);
 }
});
test('input coordinate callback cannot change the slot after the final phase check',()=>{
 const f=fixture();f.api.input=()=>{f.cards[0].row.block={id:'replacement',state:3,type:98};return {type:'touchend'};};
 assert.equal(f.begin(),null);assert.equal(f.calls.length,0);
});
test('a pair of allied supplies is picked serially and each effect is independently confirmed',()=>{
 const f=fixture({types:['a','a'],tray:['a']});f.begin();
 f.s.tray.push({id:'new0',type:'type:97',metadata:{rawID:'supply-private-0'}});
 f.cards[0].item.isEmpty=true;f.cards[0].row.block=null;f.cards[0].item.node.children=[];Object.assign(f.s.phaseSnapshot.sharedSlots[0],{empty:true,card:null});f.s.signature='after-first';
 f.observe(100);assert.equal(f.observe(180).status,'move_confirmed');assert.equal(f.calls.length,1);
 assert.equal(f.begin().status,'original_event_dispatched');assert.equal(f.calls.length,2);
 f.s.tray=[];f.cards[1].item.isEmpty=true;f.cards[1].row.block=null;f.cards[1].item.node.children=[];Object.assign(f.s.phaseSnapshot.sharedSlots[1],{empty:true,card:null});f.s.signature='after-second';
 f.observe(300);assert.equal(f.observe(380).status,'move_confirmed');assert.equal(f.coop.diagnostic().confirmed,2);
});
test('matching tray and empty slot cannot confirm an unrelated board replacement',()=>{
 const f=fixture();f.begin();f.settle();f.s.cards.push({id:'new',type:'type:2',zone:'board',metadata:{rawID:'unrelated'}});
 assert.equal(f.observe(100).status,'waiting_confirmation');assert.equal(f.observe(9000).status,'dispatch_uncertain');assert.equal(f.coop.diagnostic().confirmed,0);assert.equal(f.calls.length,1);
});

for(const replacement of ['store','loader','layer'])test('same-round '+replacement+' replacement cannot release a pending pickup',()=>{
 const f=fixture();f.begin();
 if(replacement==='store')f.s.playState.store={...f.store};
 if(replacement==='loader')f.window.__require=()=>{};
 if(replacement==='layer')f.s.playState.layer={...f.s.playState.layer};
 f.observe(100);f.observe(180);f.begin();assert.equal(f.calls.length,1);assert.equal(f.coop.busy(),true);
 f.settle();f.observe(300);assert.equal(f.observe(380).status,'move_confirmed');assert.equal(f.coop.diagnostic().confirmed,1);
});

test('a stable genuinely different round retires the old pickup without counting it',()=>{
 const f=fixture();f.begin();f.s.playState.start=4;f.store.start_time=4;
 f.observe(100);assert.equal(f.coop.busy(),true);assert.equal(f.observe(180).reason,'cooperative_context_changed');
 assert.equal(f.coop.busy(),false);assert.equal(f.coop.diagnostic().confirmed,0);assert.equal(f.calls.length,1);
});

test('diamond warehouse supply completes a trio without any gauge dependency',()=>{
 const f=fixture({types:['\x01'],tray:['\x01','\x01']});
 assert.equal(f.begin().dispatched,true);assert.equal(f.calls.length,1);assert.equal(f.coop.busy(),true);
});
test('obsolete diamond predicate cannot suppress an otherwise validated warehouse pickup',()=>{
 const f=fixture({types:['\x01'],tray:['\x01','\x01']});f.api.allowed=()=>false;
 assert.equal(f.begin().dispatched,true);assert.equal(f.calls.length,1);assert.equal(f.coop.busy(),true);
});

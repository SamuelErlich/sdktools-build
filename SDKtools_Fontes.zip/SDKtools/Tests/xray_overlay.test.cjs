const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/xray_overlay.js'),'utf8');
function setup({labels=true,throwLabel=false,fill=true}={}) {
 const created=[],graphics=[];
 class Node {
  constructor(name) { Object.assign(this,{name,x:0,y:0,angle:0,scaleX:1,scaleY:1,width:80,height:90,anchorX:.5,anchorY:.5,isValid:true,active:true,children:[],comps:[],parent:null,zIndex:0});created.push(this); }
  addChild(c){if(c.parent)c.removeFromParent();this.children.push(c);c.parent=this;}
  removeFromParent(){if(this.parent){this.parent.children.splice(this.parent.children.indexOf(this),1);this.parent=null;}}
  destroy(){this.isValid=false;for(const c of this.children)c.destroy();}
  addComponent(C){if(throwLabel&&C===Label)throw Error('font component unavailable');const v=new C();v.kind=C;v.node=this;this.comps.push(v);return v;}
  getComponent(C){return this.comps.find(c=>c.kind===C)||null;}
  convertToWorldSpaceAR(p){let n=this,x=p.x,y=p.y;while(n){const a=n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=x*n.scaleX,yy=y*n.scaleY;x=c*xx-s*yy+n.x;y=s*xx+c*yy+n.y;n=n.parent;}return{x,y};}
  convertToNodeSpaceAR(p){const chain=[];let n=this,x=p.x,y=p.y;while(n){chain.push(n);n=n.parent;}for(n of chain.reverse()){x-=n.x;y-=n.y;const a=-n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=c*x-s*y,yy=s*x+c*y;x=xx/n.scaleX;y=yy/n.scaleY;}return{x,y};}
 }
 class Sprite{} Sprite.SizeMode={CUSTOM:0};
 class Label{} Label.HorizontalAlign={CENTER:1};Label.VerticalAlign={CENTER:1};
 class Color {constructor(r,g,b,a){Object.assign(this,{r,g,b,a});}}
 class Graphics {
  constructor(){this.commands=[];this.clears=0;graphics.push(this);}
  clear(){this.commands=[];this.clears++;}
  moveTo(x,y){this.commands.push(['move',x,y]);}
  lineTo(x,y){this.commands.push(['line',x,y]);}
  close(){this.commands.push(['close']);}
  stroke(){this.commands.push(['stroke',this.lineWidth,{...this.strokeColor}]);}
 }
 if(fill)Graphics.prototype.fill=function(){this.commands.push(['fill',{...this.fillColor}]);};
 const cc={Node,Sprite,Graphics,Color,v2:(x,y)=>({x,y})};if(labels)cc.Label=Label;
 const root=new Node('game scene'),gameLayer=new Node('game'),board=new Node('board');root.addChild(gameLayer);gameLayer.addChild(board);board.width=560;board.height=720;
 const s={cc,root,gameLayer,board,refs:new Map(),cards:[],tray:[],capacity:7,signature:'board'};
 function add(id,depth=0,{x=0,y=0,type='a',zone='board',frame}={}){const n=new Node('original '+id);n.x=x;n.y=y;(zone==='board'?board:gameLayer).addChild(n);const c={id,type,zone,occlusionDepth:depth,masked:depth>0,node:n,frame:frame||{name:'art '+type},available:depth===0,blockedBy:[]};s.refs.set(id,c);if(zone==='tray')s.tray.push(c);else s.cards.push(c);return c;}
 const factory=vm.runInNewContext(source),overlay=factory();
 const layer=()=>gameLayer.children.find(n=>n.name==='SDKtools Card Hints');
 const icons=()=>layer()?layer().children.filter(n=>n.name==='SDKtools Hidden Card'):[];
 const labelsList=()=>icons().flatMap(n=>n.children).filter(n=>n.name==='SDKtools Depth');
 return{cc,created,graphics,s,add,overlay,layer,icons,labelsList};
}
function proof(ids,peak=3){return{tripleCardIDs:ids,peakTrayCount:peak};}
function result(r){return JSON.parse(JSON.stringify(r));}

test('depth defaults to one, includes cutoff and reports deeper cards',()=>{
 const f=setup();for(let d=0;d<=6;d++)f.add('c'+d,d,{x:d*50-150});
 let r=f.overlay.render(f.s,null);assert.equal(r.coveredIcons,1);assert.equal(r.depthLimit,1);assert.equal(r.hiddenByDepth,5);assert.equal(f.labelsList()[0].getComponent(f.cc.Label).string,'1');
 r=f.overlay.render(f.s,null,{depth:5});assert.equal(r.coveredIcons,5);assert.equal(r.hiddenByDepth,1);assert.deepEqual(f.labelsList().map(n=>n.getComponent(f.cc.Label).string),['1','2','3','4','5']);
 assert.equal(f.overlay.render(f.s,null,{depth:99}).depthLimit,5);assert.equal(f.overlay.render(f.s,null,{depth:-4}).depthLimit,1);
});
test('original artwork is reused and original nodes and components are never changed',()=>{
 const f=setup(),a=f.add('a',1),frame=a.frame;const before={x:a.node.x,y:a.node.y,width:a.node.width,height:a.node.height,active:a.node.active,z:a.node.zIndex,children:a.node.children.length};
 const r=f.overlay.render(f.s,null,{depth:1});assert.equal(r.status,'ready');assert.equal(f.icons()[0].getComponent(f.cc.Sprite).spriteFrame,frame);
 assert.deepEqual({x:a.node.x,y:a.node.y,width:a.node.width,height:a.node.height,active:a.node.active,z:a.node.zIndex,children:a.node.children.length},before);assert.equal(a.masked,true);assert.equal(f.s.board.children.length,1);
 assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>!n.comps.some(c=>/Button|Collider|BlockInput/.test(c.constructor.name))));
});
test('depth changes remove only unwanted badges and reuse surviving nodes',()=>{
 const f=setup();f.add('a',1);f.add('b',2,{x:50});f.add('c',3,{x:100});f.overlay.render(f.s,null,{depth:3});const existing=f.icons().slice();
 f.overlay.render(f.s,null,{depth:1});assert.equal(f.icons().length,1);assert.equal(f.icons()[0],existing[0]);assert.equal(existing[1].isValid,false);assert.equal(existing[2].isValid,false);
 f.s.cards[0].masked=false;f.s.cards[0].occlusionDepth=0;f.overlay.render(f.s,null,{depth:1});assert.equal(f.icons().length,0);assert.equal(existing[0].isValid,false);
});
test('unchanged snapshots reuse icons labels and graphics without flicker',()=>{
 const f=setup();f.add('a',1);f.add('b',2,{x:80});f.overlay.render(f.s,null,{depth:2});const nodes=f.icons().slice(),labels=f.labelsList().slice(),clears=f.graphics[0].clears;
 for(let i=0;i<10;i++)f.overlay.render(f.s,null,{depth:2});assert.deepEqual(f.icons(),nodes);assert.deepEqual(f.labelsList(),labels);assert.equal(f.graphics[0].clears,clears);
});
test('numbers use white bold Cocos Labels over dark backing',()=>{
 const f=setup();f.add('a',4);const r=f.overlay.render(f.s,null,{depth:4}),n=f.labelsList()[0],label=n.getComponent(f.cc.Label);
 assert.equal(r.labelMode,'cocos_label');assert.equal(label.string,'4');assert.equal(label.fontSize,22);assert.equal(label.enableBold,true);assert.deepEqual({...n.color},{r:255,g:255,b:255,a:255});assert.ok(f.graphics[0].commands.some(c=>c[0]==='fill'&&c[1].a>=230));
});
test('missing or throwing Label uses explicit readable vector depth digits',()=>{
 for(const options of [{labels:false},{throwLabel:true},{labels:false,fill:false}]){
  const f=setup(options);for(let i=1;i<=5;i++)f.add('c'+i,i,{x:i*50-150});const r=f.overlay.render(f.s,null,{depth:5});
  assert.equal(r.status,'ready');assert.equal(r.labelMode,'vector_digits');assert.equal(r.coveredIcons,5);assert.equal(f.labelsList().length,0);
  assert.equal(f.graphics[0].commands.filter(c=>c[0]==='stroke'&&c[1]===2.5&&c[2].r===255&&c[2].g===255).length,5);
 }
});
test('overlapping hidden cards receive deterministic separate icon-number cells',()=>{
 const f=setup();for(let i=1;i<=5;i++)f.add('c'+i,i);const r=f.overlay.render(f.s,null,{depth:5});assert.equal(r.coveredIcons,5);assert.equal(r.hiddenByLayout,0);
 const positions=f.icons().map(n=>({x:n.x+12,y:n.y}));for(let i=0;i<positions.length;i++)for(let j=i+1;j<positions.length;j++)assert.ok(Math.abs(positions[i].x-positions[j].x)>=64||Math.abs(positions[i].y-positions[j].y)>=46);
 f.s.cards.reverse();f.overlay.render(f.s,null,{depth:5});assert.deepEqual(f.icons().map(n=>({x:n.x+12,y:n.y})),positions);
});
test('bounded collision search reports crowded cards instead of overlapping labels',()=>{
 const f=setup();for(let i=0;i<100;i++)f.add('c'+i,1);const r=f.overlay.render(f.s,null,{depth:1});assert.equal(r.coveredIcons,49);assert.equal(r.hiddenByLayout,51);assert.equal(f.icons().length,49);
});
test('matching triple gets external green outline and contrasting dark halo',()=>{
 const f=setup();f.add('a',0,{x:-80});f.add('b',0);f.add('c',0,{x:80,zone:'tray'});const r=f.overlay.render(f.s,proof(['a','b','c']));assert.equal(r.matchedBorders,3);
 const commands=f.graphics[0].commands,green=commands.filter(c=>c[0]==='stroke'&&c[1]===4&&c[2].g===255),halo=commands.filter(c=>c[0]==='stroke'&&c[1]===9);
 assert.equal(green.length,3);assert.equal(halo.length,3);assert.deepEqual(commands[0],['move',-124,-49]);assert.deepEqual(commands[1],['line',-36,-49]);
});
test('invalid unmatched duplicate or overflowing proofs never draw a green recommendation',()=>{
 const f=setup();f.add('a');f.add('b');f.add('c',0,{type:'different'});
 for(const p of [proof(['a','a','b']),proof(['a','b','missing']),proof(['a','b','c']),proof(['a','b','c'],8),proof(['a','b','c'],NaN)])assert.equal(f.overlay.render(f.s,p).matchedBorders,0);
});
test('outlines follow translation rotation scale and actual node anchor precisely',()=>{
 const f=setup();const cards=['a','b','c'].map((id,i)=>f.add(id,0,{x:i*80}));cards[0].node.angle=25;cards[0].node.scaleX=1.3;cards[0].node.scaleY=.7;cards[0].node.anchorX=.2;cards[0].node.anchorY=.8;f.s.board.angle=12;f.s.board.x=31;f.s.board.y=-9;
 f.overlay.render(f.s,proof(['a','b','c']));const n=cards[0].node,expected=f.layer().convertToNodeSpaceAR(n.convertToWorldSpaceAR({x:-80*.2-4,y:-90*.8-4})),first=f.graphics[0].commands[0];
 assert.equal(first[0],'move');assert.ok(Math.abs(first[1]-expected.x)<1e-8&&Math.abs(first[2]-expected.y)<1e-8);
});
test('ancestor movement updates badge geometry even when snapshot signature is unchanged',()=>{
 const f=setup();f.add('a',1);f.overlay.render(f.s,null);const n=f.icons()[0],before={x:n.x,y:n.y};f.s.board.x+=17;f.s.board.y-=11;f.overlay.render(f.s,null);
 assert.equal(n.x,before.x+17);assert.equal(n.y,before.y-11);
});
test('changed frame identity is reflected without recreating the badge',()=>{
 const f=setup(),card=f.add('a',1);f.overlay.render(f.s,null);const n=f.icons()[0];card.frame={name:'replacement art'};f.overlay.render(f.s,null);assert.equal(f.icons()[0],n);assert.equal(n.getComponent(f.cc.Sprite).spriteFrame,card.frame);
});
test('scene replacement destroys old owned tree and leaves original nodes intact',()=>{
 const f=setup();f.add('a',1);f.overlay.render(f.s,null);const old=f.layer(),oldIcon=f.icons()[0],other=setup();other.add('b',1);assert.equal(f.overlay.render(other.s,null).status,'ready');assert.equal(old.isValid,false);assert.equal(oldIcon.isValid,false);assert.equal(f.layer(),undefined);assert.equal(f.s.cards[0].node.isValid,true);f.overlay.clear();assert.equal(other.layer(),undefined);
});
test('invalid depth or coordinates fail closed and clean previously rendered hints',()=>{
 for(const change of [c=>delete c.occlusionDepth,c=>c.occlusionDepth=1.5,c=>c.node.x=NaN]){const f=setup(),c=f.add('a',1);f.overlay.render(f.s,null);const old=f.layer();change(c);assert.equal(f.overlay.render(f.s,null).status,'unavailable');assert.equal(f.layer(),undefined);assert.equal(old.isValid,false);}
});
test('clear is idempotent and owns recognizes only nodes created by this overlay',()=>{
 const f=setup();const c=f.add('a',1);f.overlay.render(f.s,null);assert.equal(f.overlay.owns(c.node),false);assert.equal(f.overlay.owns(f.icons()[0]),true);assert.equal(f.overlay.owns(f.labelsList()[0]),true);f.overlay.clear();f.overlay.clear();assert.equal(f.layer(),undefined);assert.equal(f.overlay.owns(null),false);
});
test('resource is bounded and cannot invoke original controls or load external images',()=>{
 assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);
 assert.doesNotMatch(source,/\.emit\s*\(|\.touchBlock\s*\(|\.on\s*\(|addComponent\(\s*cc\.(?:Button|BlockInputEvents)/);
});

test('hidden recommendations highlight only their visible badge within selected depth',()=>{
 const f=setup();f.add('hidden',2);f.add('visible',0,{x:120});f.add('tray',0,{x:-160,zone:'tray'});const p=proof(['hidden','visible','tray']);
 let r=f.overlay.render(f.s,p,{depth:1});assert.equal(r.coveredIcons,0);assert.equal(r.matchedBorders,2);assert.equal(r.hiddenByDepth,1);
 assert.equal(f.graphics[0].commands.filter(c=>c[0]==='stroke'&&c[2].g===255).length,2);
 r=f.overlay.render(f.s,p,{depth:2});assert.equal(r.coveredIcons,1);assert.equal(r.matchedBorders,3);
 const commands=f.graphics[0].commands,greenBadge=commands.findIndex(c=>c[0]==='stroke'&&c[1]===3&&c[2].g===255);assert.ok(greenBadge>4);
 const badge=f.icons()[0],moves=commands.slice(greenBadge-5,greenBadge);assert.deepEqual(moves[0],['move',badge.x+12-28.5,badge.y-19.5]);
 assert.equal(commands.filter(c=>c[0]==='stroke'&&c[1]===4&&c[2].g===255).length,2,'only actual exposed/tray cards receive full-sized outlines');
});
test('a hidden match omitted for crowded layout never receives a detached border',()=>{
 const f=setup();for(let i=0;i<60;i++)f.add(String(i).padStart(2,'0'),1);const r=f.overlay.render(f.s,proof(['00','01','59']),{depth:1});
 assert.equal(r.coveredIcons,49);assert.equal(r.matchedBorders,2);assert.equal(r.hiddenByLayout,11);
});

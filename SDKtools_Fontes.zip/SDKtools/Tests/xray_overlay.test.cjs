const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/xray_overlay.js'),'utf8');
function setup({labels=true,throwLabel=false,fill=true}={}) {
 const created=[],graphics=[];
 class Node {
  constructor(name) { Object.assign(this,{name,x:0,y:0,angle:0,scaleX:1,scaleY:1,width:80,height:90,anchorX:.5,anchorY:.5,isValid:true,active:true,children:[],comps:[],parent:null,zIndex:0});created.push(this); }
  addChild(c){if(c.parent)c.removeFromParent();this.children.push(c);c.parent=this;}
  removeFromParent(){if(this.parent){this.parent.children.splice(this.parent.children.indexOf(this),1);this.parent=null;}}
  destroy(){this.isValid=false;for(const c of this.children)c.destroy();}
  addComponent(C){if(throwLabel&&C===Label)throw Error('font component unavailable');const v=new C();v.kind=C;v.node=this;this.comps.push(v);return v;}
  getComponent(C){return this.comps.find(c=>c.kind===C)||null;}
  convertToWorldSpaceAR(p){let n=this,x=p.x,y=p.y;while(n){const a=n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=x*n.scaleX,yy=y*n.scaleY;x=c*xx-s*yy+n.x;y=s*xx+c*yy+n.y;n=n.parent;}return{x,y};}
  convertToNodeSpaceAR(p){const chain=[];let n=this,x=p.x,y=p.y;while(n){chain.push(n);n=n.parent;}for(n of chain.reverse()){x-=n.x;y-=n.y;const a=-n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=c*x-s*y,yy=s*x+c*y;x=xx/n.scaleX;y=yy/n.scaleY;}return{x,y};}
 }
 class Sprite{} Sprite.SizeMode={CUSTOM:0};
 class Label{} Label.HorizontalAlign={CENTER:1};Label.VerticalAlign={CENTER:1};
 class Color {constructor(r,g,b,a){Object.assign(this,{r,g,b,a});}}
 class Graphics {
  constructor(){this.commands=[];this.clears=0;graphics.push(this);}
  clear(){this.commands=[];this.clears++;}
  moveTo(x,y){this.commands.push(['move',x,y]);}
  lineTo(x,y){this.commands.push(['line',x,y]);}
  close(){this.commands.push(['close']);}
  stroke(){this.commands.push(['stroke',this.lineWidth,{...this.strokeColor}]);}
 }
 if(fill)Graphics.prototype.fill=function(){this.commands.push(['fill',{...this.fillColor}]);};
 const cc={Node,Sprite,Graphics,Color,v2:(x,y)=>({x,y})};if(labels)cc.Label=Label;
 const root=new Node('game scene'),gameLayer=new Node('game'),board=new Node('board');root.addChild(gameLayer);gameLayer.addChild(board);board.width=560;board.height=720;
 const s={cc,root,gameLayer,board,refs:new Map(),cards:[],tray:[],capacity:7,signature:'board'};
 function add(id,depth=0,{x=0,y=0,type='a',zone='board',frame}={}){const n=new Node('original '+id);n.x=x;n.y=y;(zone==='board'?board:gameLayer).addChild(n);const c={id,type,zone,occlusionDepth:depth,masked:depth>0,node:n,frame:frame||{name:'art '+type},available:depth===0,blockedBy:[]};s.refs.set(id,c);if(zone==='tray')s.tray.push(c);else s.cards.push(c);return c;}
 const factory=vm.runInNewContext(source),overlay=factory();
 const layer=()=>gameLayer.children.find(n=>n.name==='SDKtools Card Hints');
 const icons=()=>layer()?layer().children.filter(n=>n.name==='SDKtools Hidden Card'):[];
 const labelsList=()=>icons().flatMap(n=>n.children).filter(n=>n.name==='SDKtools Depth');
 return{cc,created,graphics,s,add,overlay,layer,icons,labelsList};
}
function proof(ids,peak=3){return{tripleCardIDs:ids,peakTrayCount:peak};}
function result(r){return JSON.parse(JSON.stringify(r));}


function stack(f,id,depths,{x=0,y=0,type='a'}={}) {
 const owner=f.add(id,0,{x,y,type});
 const hidden=depths.map((d,i)=>{const c=f.add(id+'-h'+i,d,{x,y,type});c.blockedBy=[owner.id];return c;});
 return {owner,hidden};
}
function more(f){return f.layer().children.filter(n=>n.name==='SDKtools Stack Overflow');}

test('cumulative depth1..5 uses true small numbers and counts deeper cards',()=>{
 const f=setup();for(let d=1;d<=6;d++)stack(f,'s'+d,[d],{x:d*85-300});
 let r=f.overlay.render(f.s,null);assert.equal(r.coveredIcons,1);assert.equal(r.depthLimit,1);assert.equal(r.hiddenByDepth,5);
 r=f.overlay.render(f.s,null,{depth:5});assert.equal(r.coveredIcons,5);assert.equal(r.hiddenByDepth,1);
 assert.deepEqual(f.labelsList().map(n=>n.getComponent(f.cc.Label).string),['1','2','3','4','5']);
 assert.equal(f.overlay.render(f.s,null,{depth:99}).depthLimit,5);assert.equal(f.overlay.render(f.s,null,{depth:-1}).depthLimit,1);
});
test('original artwork and original game nodes remain untouched',()=>{
 const f=setup(),{owner,hidden:[a]}=stack(f,'a',[1]),frame=a.frame;
 const before=JSON.stringify([owner,a].map(c=>({x:c.node.x,y:c.node.y,width:c.node.width,height:c.node.height,active:c.node.active,z:c.node.zIndex,children:c.node.children.length,masked:c.masked})));
 const r=f.overlay.render(f.s,null);assert.equal(r.status,'ready');assert.equal(f.icons()[0].getComponent(f.cc.Sprite).spriteFrame,frame);
 assert.equal(JSON.stringify([owner,a].map(c=>({x:c.node.x,y:c.node.y,width:c.node.width,height:c.node.height,active:c.node.active,z:c.node.zIndex,children:c.node.children.length,masked:c.masked}))),before);
 assert.equal(f.s.board.children.length,2);assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>!n.comps.some(c=>/Button|Collider|BlockInput/.test(c.constructor.name))));
});
test('at most two hints stay inside the owning card with a narrow overflow count',()=>{
 const f=setup();stack(f,'a',[1,2,3,4,5]);const r=f.overlay.render(f.s,null,{depth:5});
 assert.equal(r.coveredIcons,2);assert.equal(r.hiddenByLayout,3);assert.equal(more(f).length,1);
 assert.equal(more(f)[0].children.find(n=>n.name==='SDKtools More').getComponent(f.cc.Label).string,'+3');
 assert.deepEqual(f.icons().map(n=>n.x),[-23.5,7.5]);assert.ok(f.icons().every(n=>n.y===-26.5 && n.width===24 && n.height===27));
 assert.ok(f.icons().every(n=>n.x-n.width/2>=-40 && n.x+n.width/2<=40));
 assert.equal(f.labelsList()[0].getComponent(f.cc.Label).fontSize,12);
});
test('overflow badge remains bounded even on unusually dense stacks',()=>{
 const f=setup();stack(f,'a',Array.from({length:120},()=>1));const r=f.overlay.render(f.s,null);
 assert.equal(r.coveredIcons,2);assert.equal(r.hiddenByLayout,118);
 assert.equal(more(f)[0].children[0].getComponent(f.cc.Label).string,'99+');
});
test('local strips are never displaced to another card to resolve collisions',()=>{
 const f=setup();stack(f,'a',[1,2],{x:0});stack(f,'b',[1,2],{x:10});
 const r=f.overlay.render(f.s,null,{depth:2});assert.equal(r.coveredIcons,2);assert.equal(r.hiddenByLayout,2);
 assert.deepEqual(f.icons().map(n=>n.x),[-15.5,15.5]);
});
test('neighboring piles have non-overlapping anchored strips and deterministic order',()=>{
 const f=setup();stack(f,'a',[1,2,3],{x:-42});stack(f,'b',[1,2,3],{x:42});
 let r=f.overlay.render(f.s,null,{depth:3});assert.equal(r.coveredIcons,4);assert.equal(r.hiddenByLayout,2);
 const positions=f.icons().map(n=>({x:n.x,y:n.y}));for(let i=0;i<positions.length;i++)for(let j=i+1;j<positions.length;j++)assert.ok(Math.abs(positions[i].x-positions[j].x)>=29);
 f.s.cards.reverse();f.overlay.render(f.s,null,{depth:3});assert.deepEqual(f.icons().map(n=>({x:n.x,y:n.y})),positions);
});
test('only verified covering ancestry chooses the exposed anchor',()=>{
 const f=setup(),left=f.add('left',0,{x:-80}),right=f.add('right',0,{x:80}),hidden=f.add('hidden',1,{x:70});hidden.blockedBy=[left.id];
 f.overlay.render(f.s,null);assert.equal(f.icons()[0].x,left.node.x,'a nearby unrelated exposed card is never guessed as owner');
 hidden.blockedBy=[left.id,right.id];f.overlay.render(f.s,null);assert.equal(f.icons()[0].x,right.node.x,'nearest verified covering owner is selected');
});
test('covered ancestry can lead through an intermediate covered card',()=>{
 const f=setup(),{owner,hidden:[middle,bottom]}=stack(f,'owner',[1,2]);bottom.blockedBy=[middle.id];
 const r=f.overlay.render(f.s,null,{depth:2});assert.equal(r.coveredIcons,2);assert.ok(f.icons().every(n=>Math.abs(n.x-owner.node.x)<20));
});
test('missing exposed ancestry is counted rather than inventing a badge location',()=>{
 const f=setup();f.add('orphan',1);const r=f.overlay.render(f.s,null);assert.equal(r.status,'ready');assert.equal(r.coveredIcons,0);assert.equal(r.hiddenByLayout,1);
});
test('depth changes reuse surviving artwork and remove unwanted hint nodes',()=>{
 const f=setup();stack(f,'a',[1,2]);f.overlay.render(f.s,null,{depth:2});const old=f.icons().slice();
 f.overlay.render(f.s,null,{depth:1});assert.equal(f.icons().length,1);assert.equal(f.icons()[0],old[0]);assert.equal(old[1].isValid,false);
});
test('unchanged snapshots reuse all nodes and do not redraw or flicker',()=>{
 const f=setup();stack(f,'a',[1,2,3]);f.overlay.render(f.s,null,{depth:3});const nodes=f.created.slice(),clears=f.graphics.map(g=>g.clears);
 for(let i=0;i<10;i++)f.overlay.render(f.s,null,{depth:3});assert.deepEqual(f.created,nodes);assert.deepEqual(f.graphics.map(g=>g.clears),clears);
});
test('depth numbers have their own dark backing above the artwork',()=>{
 const f=setup();stack(f,'a',[4]);const r=f.overlay.render(f.s,null,{depth:4}),icon=f.icons()[0],n=f.labelsList()[0],label=n.getComponent(f.cc.Label);
 assert.equal(r.labelMode,'cocos_label');assert.equal(label.string,'4');assert.equal(label.fontSize,12);assert.equal(label.enableBold,true);
 const backing=icon.children.find(n=>n.name==='SDKtools Depth Backing');assert.ok(backing);assert.ok(backing.getComponent(f.cc.Graphics).commands.some(c=>c[0]==='fill'&&c[1].a===250));
 assert.deepEqual({...n.color},{r:255,g:255,b:255,a:255});assert.equal(n.x,7);assert.equal(n.y,8);
});
test('optional Label failure falls back to small vector digits above artwork',()=>{
 for(const options of [{labels:false},{throwLabel:true},{labels:false,fill:false}]){
  const f=setup(options);for(let i=1;i<=5;i++)stack(f,'s'+i,[i],{x:i*85});const r=f.overlay.render(f.s,null,{depth:5});
  assert.equal(r.status,'ready');assert.equal(r.labelMode,'vector_digits');assert.equal(r.coveredIcons,5);assert.equal(f.labelsList().length,0);
  for(const icon of f.icons())assert.ok(icon.children.find(n=>n.name==='SDKtools Depth Backing').getComponent(f.cc.Graphics).commands.some(c=>c[0]==='stroke'&&c[1]===1.2&&c[2].g===255));
 }
});
test('matching trio gets distinct green outlines with a dark halo',()=>{
 const f=setup();f.add('a',0,{x:-80});f.add('b',0);f.add('c',0,{x:80,zone:'tray'});const r=f.overlay.render(f.s,proof(['a','b','c']));assert.equal(r.matchedBorders,3);
 const commands=f.graphics[0].commands;assert.equal(commands.filter(c=>c[0]==='stroke'&&c[1]===3&&c[2].g===255).length,3);assert.equal(commands.filter(c=>c[0]==='stroke'&&c[1]===7).length,3);
 assert.deepEqual(commands[0],['move',-124,-49]);assert.deepEqual(commands[1],['line',-36,-49]);
});
test('invalid duplicates unmatched or overflowing proofs have no recommendation',()=>{
 const f=setup();f.add('a');f.add('b');f.add('c',0,{type:'different'});
 for(const p of [proof(['a','a','b']),proof(['a','b','missing']),proof(['a','b','c']),proof(['a','b','c'],8),proof(['a','b','c'],NaN)])assert.equal(f.overlay.render(f.s,p).matchedBorders,0);
});
test('hidden recommendations outline only displayed hint; omitted matches never move elsewhere',()=>{
 const f=setup(),{hidden}=stack(f,'a',[1,2,3]),ids=hidden.map(c=>c.id);const r=f.overlay.render(f.s,proof(ids),{depth:3});
 assert.equal(r.matchedBorders,2);assert.equal(r.hiddenByLayout,1);
 assert.equal(f.graphics[0].commands.filter(c=>c[0]==='stroke'&&c[1]===1.8&&c[2].g===255).length,2);
 assert.equal(f.graphics[0].commands.filter(c=>c[0]==='stroke'&&c[1]===3&&c[2].g===255).length,0);
});
test('original anchors and transforms determine strip and artwork placement',()=>{
 const f=setup(),{owner}=stack(f,'a',[1]);owner.node.anchorX=.2;owner.node.anchorY=.8;f.s.board.angle=12;f.s.board.x=31;f.s.board.y=-9;f.s.board.scaleX=.8;f.s.board.scaleY=.8;
 f.overlay.render(f.s,null);const icon=f.icons()[0],expected=f.layer().convertToNodeSpaceAR(owner.node.convertToWorldSpaceAR({x:24,y:-72+18.5}));
 assert.ok(Math.abs(icon.x-expected.x)<1e-8&&Math.abs(icon.y-expected.y)<1e-8);assert.ok(Math.abs(icon.angle-12)<1e-8);assert.ok(Math.abs(icon.scaleX-.8)<1e-8);
});
test('movement and frame changes update the same icon',()=>{
 const f=setup(),{hidden:[card]}=stack(f,'a',[1]);f.overlay.render(f.s,null);const icon=f.icons()[0],before={x:icon.x,y:icon.y};f.s.board.x+=17;f.s.board.y-=11;card.frame={name:'replacement'};f.overlay.render(f.s,null);
 assert.equal(f.icons()[0],icon);assert.equal(icon.x,before.x+17);assert.equal(icon.y,before.y-11);assert.equal(icon.getComponent(f.cc.Sprite).spriteFrame,card.frame);
});
test('scene replacement and clear destroy only SDK-owned nodes',()=>{
 const f=setup();stack(f,'a',[1]);f.overlay.render(f.s,null);const old=f.layer(),icon=f.icons()[0],other=setup();stack(other,'b',[1]);assert.equal(f.overlay.render(other.s,null).status,'ready');assert.equal(old.isValid,false);assert.equal(icon.isValid,false);assert.equal(f.s.cards[0].node.isValid,true);f.overlay.clear();f.overlay.clear();assert.equal(other.layer(),undefined);
});
test('invalid metadata or coordinates clean hints instead of drawing guesses',()=>{
 for(const change of [c=>delete c.occlusionDepth,c=>c.occlusionDepth=1.5,c=>c.node.x=NaN,c=>c.blockedBy=['missing']]){const f=setup(),{hidden:[c]}=stack(f,'a',[1]);f.overlay.render(f.s,null);const old=f.layer();change(c);assert.equal(f.overlay.render(f.s,null).status,'unavailable');assert.equal(f.layer(),undefined);assert.equal(old.isValid,false);}
});
test('resource cannot invoke original controls or load external assets',()=>{
 assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);
 assert.doesNotMatch(source,/\.emit\s*\(|\.touchBlock\s*\(|\.on\s*\(|addComponent\(\s*cc\.(?:Button|BlockInputEvents)/);
});

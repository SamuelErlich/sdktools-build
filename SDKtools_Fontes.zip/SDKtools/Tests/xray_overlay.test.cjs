const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/xray_overlay.js'),'utf8');
function setup({labels=true,outlines=true,throwLabel=false,fill=true}={}) {
 const created=[],graphics=[];
 class Node {
  constructor(name) { Object.assign(this,{name,x:0,y:0,angle:0,scaleX:1,scaleY:1,width:80,height:90,anchorX:.5,anchorY:.5,isValid:true,active:true,children:[],comps:[],parent:null,zIndex:0});created.push(this); }
  addChild(c){if(c.parent)c.removeFromParent();this.children.push(c);c.parent=this;}
  removeFromParent(){if(this.parent){this.parent.children.splice(this.parent.children.indexOf(this),1);this.parent=null;}}
  destroy(){this.isValid=false;for(const c of this.children)c.destroy();}
  addComponent(C){if(throwLabel&&C===Label)throw Error('font component unavailable');const v=new C();v.kind=C;v.node=this;this.comps.push(v);return v;}
  getComponent(C){return this.comps.find(c=>c.kind===C)||null;}
  convertToWorldSpaceAR(p){let n=this,x=p.x,y=p.y;while(n){const a=n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=x*n.scaleX,yy=y*n.scaleY;x=c*xx-s*yy+n.x;y=s*xx+c*yy+n.y;n=n.parent;}return{x,y};}
  convertToNodeSpaceAR(p){const chain=[];let n=this,x=p.x,y=p.y;while(n){chain.push(n);n=n.parent;}for(n of chain.reverse()){x-=n.x;y-=n.y;const a=-n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=c*x-s*y,yy=s*x+c*y;x=xx/n.scaleX;y=yy/n.scaleY;}return{x,y};}
 }
 class Sprite{set spriteFrame(value){this.frame=value;if(this.sizeMode!==0){this.node.width=100;this.node.height=100;}}get spriteFrame(){return this.frame;}} Sprite.SizeMode={CUSTOM:0};
 class Label{} Label.HorizontalAlign={CENTER:1};Label.VerticalAlign={CENTER:1};
 class LabelOutline{}
 class Color {constructor(r,g,b,a){Object.assign(this,{r,g,b,a});}}
 class Graphics {
  constructor(){this.commands=[];this.clears=0;graphics.push(this);}
  clear(){this.commands=[];this.clears++;}
  moveTo(x,y){this.commands.push(['move',x,y]);}
  lineTo(x,y){this.commands.push(['line',x,y]);}
  close(){this.commands.push(['close']);}
  stroke(){this.commands.push(['stroke',this.lineWidth,{...this.strokeColor}]);}
 }
 if(fill)Graphics.prototype.fill=function(){this.commands.push(['fill',{...this.fillColor}]);};
 const cc={Node,Sprite,Graphics,Color,v2:(x,y)=>({x,y})};if(labels)cc.Label=Label;if(outlines)cc.LabelOutline=LabelOutline;
 const root=new Node('game scene'),gameLayer=new Node('game'),board=new Node('board');root.addChild(gameLayer);gameLayer.addChild(board);board.width=560;board.height=720;
 const s={cc,root,gameLayer,board,refs:new Map(),cards:[],tray:[],capacity:7,signature:'board'};
 function add(id,depth=0,{x=0,y=0,type='a',zone='board',frame}={}){const n=new Node('original '+id);n.x=x;n.y=y;(zone==='board'?board:gameLayer).addChild(n);const c={id,type,zone,occlusionDepth:depth,masked:depth>0,node:n,frame:frame||{name:'art '+type},available:depth===0,blockedBy:[]};s.refs.set(id,c);if(zone==='tray')s.tray.push(c);else s.cards.push(c);return c;}
 const factory=vm.runInNewContext(source),overlay=factory();
 const layer=()=>gameLayer.children.find(n=>n.name==='SDKtools Card Hints');
 const icons=()=>layer()?layer().children.filter(n=>n.name==='SDKtools Hidden Card'):[];
 const labelsList=()=>icons().flatMap(n=>n.children).filter(n=>n.name==='SDKtools Depth');
 return{cc,created,graphics,s,add,overlay,layer,icons,labelsList};
}
function proof(ids,peak=3){return{tripleCardIDs:ids,peakTrayCount:peak};}
function result(r){return JSON.parse(JSON.stringify(r));}


function stack(f,id,depths,{x=0,y=0,type='a'}={}) {
 const owner=f.add(id,0,{x,y,type});
 const hidden=depths.map((d,i)=>{const c=f.add(id+'-h'+i,d,{x,y,type});c.blockedBy=[owner.id];return c;});
 return {owner,hidden};
}
function sprite(f,n){return n.children.find(n=>n.name==='SDKtools Hint Artwork').getComponent(f.cc.Sprite);}

test('cumulative depth1..4 uses verified numbers and excludes deeper cards',()=>{
 const f=setup();for(let d=1;d<=6;d++)stack(f,'s'+d,[d],{x:d*85-300});
 let r=f.overlay.render(f.s,null);assert.equal(r.coveredIcons,1);assert.equal(r.depthLimit,1);assert.equal(r.hiddenByDepth,5);
 r=f.overlay.render(f.s,null,{depth:5});assert.equal(r.coveredIcons,4);assert.equal(r.hiddenByDepth,2);
 assert.deepEqual(f.labelsList().map(n=>n.getComponent(f.cc.Label).string),['1','2','3','4']);
 assert.equal(f.overlay.render(f.s,null,{depth:99}).depthLimit,4);assert.equal(f.overlay.render(f.s,null,{depth:-1}).depthLimit,1);
});
test('original artwork and original game nodes remain untouched',()=>{
 const f=setup(),{owner,hidden:[a]}=stack(f,'a',[1]),frame=a.frame;
 const before=JSON.stringify([owner,a].map(c=>({x:c.node.x,y:c.node.y,width:c.node.width,height:c.node.height,active:c.node.active,z:c.node.zIndex,children:c.node.children.length,masked:c.masked})));
 const r=f.overlay.render(f.s,null);assert.equal(r.status,'ready');assert.equal(sprite(f,f.icons()[0]).spriteFrame,frame);
 assert.equal(JSON.stringify([owner,a].map(c=>({x:c.node.x,y:c.node.y,width:c.node.width,height:c.node.height,active:c.node.active,z:c.node.zIndex,children:c.node.children.length,masked:c.masked}))),before);
 assert.equal(f.s.board.children.length,2);assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>!n.comps.some(c=>/Button|Collider|BlockInput/.test(c.constructor.name))));
});
test('four transparent hints occupy two top and two bottom corners',()=>{
 const f=setup();stack(f,'a',[1,2,3,4,5]);const r=f.overlay.render(f.s,null,{depth:5});
 assert.equal(r.coveredIcons,4);assert.equal(r.hiddenByLayout,0);assert.equal(r.hiddenByDepth,1);
 assert.deepEqual(f.icons().map(n=>[n.x,n.y]),[[-26,30],[26,30],[-26,-30],[26,-30]]);
 assert.ok(f.icons().every(n=>n.width===18 && n.height===20));
 assert.ok(f.icons().every(n=>n.x-n.width/2>=-40 && n.x+n.width/2<=40));
 assert.equal(f.labelsList()[0].getComponent(f.cc.Label).fontSize,11);
});
test('dense stacks stay bounded without overflow text obscuring the center',()=>{
 const f=setup();stack(f,'a',Array.from({length:120},()=>1));const r=f.overlay.render(f.s,null);
 assert.equal(r.coveredIcons,4);assert.equal(r.hiddenByLayout,116);
 assert.equal(f.layer().children.length,4);assert.ok(f.labelsList().every(n=>n.getComponent(f.cc.Label).string==='1'));
});
test('corner hints are never displaced to another card to resolve collisions',()=>{
 const f=setup();stack(f,'a',[1,2],{x:0});stack(f,'b',[1,2],{x:10});
 const r=f.overlay.render(f.s,null,{depth:2});assert.equal(r.coveredIcons,2);assert.equal(r.hiddenByLayout,2);
 assert.deepEqual(f.icons().map(n=>n.x),[-26,26]);
});
test('neighboring piles have non-overlapping corner hints and deterministic order',()=>{
 const f=setup();stack(f,'a',[1,2,3],{x:-42});stack(f,'b',[1,2,3],{x:42});
 let r=f.overlay.render(f.s,null,{depth:3});assert.equal(r.coveredIcons,6);assert.equal(r.hiddenByLayout,0);
 const positions=f.icons().map(n=>({x:n.x,y:n.y}));for(let i=0;i<positions.length;i++)for(let j=i+1;j<positions.length;j++)assert.ok(Math.abs(positions[i].x-positions[j].x)>=30 || Math.abs(positions[i].y-positions[j].y)>=24);
 f.s.cards.reverse();f.overlay.render(f.s,null,{depth:3});assert.deepEqual(f.icons().map(n=>({x:n.x,y:n.y})),positions);
});
test('only verified covering ancestry chooses the exposed anchor',()=>{
 const f=setup(),left=f.add('left',0,{x:-80}),right=f.add('right',0,{x:80}),hidden=f.add('hidden',1,{x:70});hidden.blockedBy=[left.id];
 f.overlay.render(f.s,null);assert.equal(f.icons()[0].x,left.node.x-26,'a nearby unrelated exposed card is never guessed as owner');
 hidden.blockedBy=[left.id,right.id];f.overlay.render(f.s,null);assert.equal(f.icons()[0].x,right.node.x-26,'nearest verified covering owner is selected');
});
test('covered ancestry can lead through an intermediate covered card',()=>{
 const f=setup(),{owner,hidden:[middle,bottom]}=stack(f,'owner',[1,2]);bottom.blockedBy=[middle.id];
 const r=f.overlay.render(f.s,null,{depth:2});assert.equal(r.coveredIcons,2);assert.ok(f.icons().every(n=>Math.abs(n.x-owner.node.x)===26));
});
test('missing exposed ancestry is counted rather than inventing a badge location',()=>{
 const f=setup();f.add('orphan',1);const r=f.overlay.render(f.s,null);assert.equal(r.status,'ready');assert.equal(r.coveredIcons,0);assert.equal(r.hiddenByLayout,1);
});
test('masked reserve without verified geometry never receives a full-card recommendation border',()=>{
 const f=setup(),r=f.add('r',1,{zone:'reserve'});r.storageVerified=false;r.occlusionDepth=null;
 f.add('b',0,{x:120});f.add('c',0,{x:240});
 const result=f.overlay.render(f.s,proof(['r','b','c']));
 assert.equal(result.coveredIcons,0);assert.equal(result.hiddenByLayout,1);assert.equal(result.matchedBorders,2);
});
test('depth changes reuse surviving artwork and remove unwanted hint nodes',()=>{
 const f=setup();stack(f,'a',[1,2]);f.overlay.render(f.s,null,{depth:2});const old=f.icons().slice();
 f.overlay.render(f.s,null,{depth:1});assert.equal(f.icons().length,1);assert.equal(f.icons()[0],old[0]);assert.equal(old[1].isValid,false);
});
test('unchanged snapshots reuse all nodes and do not redraw or flicker',()=>{
 const f=setup();stack(f,'a',[1,2,3]);f.overlay.render(f.s,null,{depth:3});const nodes=f.created.slice(),clears=f.graphics.map(g=>g.clears);
 for(let i=0;i<10;i++)f.overlay.render(f.s,null,{depth:3});assert.deepEqual(f.created,nodes);assert.deepEqual(f.graphics.map(g=>g.clears),clears);
});
test('artwork and paired numbers use black outlines without filled plates',()=>{
 const f=setup();stack(f,'a',[4]);const r=f.overlay.render(f.s,null,{depth:4}),icon=f.icons()[0],n=f.labelsList()[0],label=n.getComponent(f.cc.Label);
 assert.equal(r.labelMode,'cocos_label');assert.equal(label.string,'4');assert.equal(label.fontSize,11);assert.equal(label.enableBold,true);
 const outline=icon.children.find(n=>n.name==='SDKtools Hint Outline');assert.ok(outline);assert.equal(outline.width,22);assert.equal(outline.height,24);
 assert.equal(outline.getComponent(f.cc.Sprite).spriteFrame,sprite(f,icon).spriteFrame);assert.deepEqual({...outline.color},{r:0,g:0,b:0,a:255});
 assert.ok(n.getComponent(f.cc.LabelOutline).width>=1.5);assert.equal(sprite(f,icon).node.width,18);assert.equal(sprite(f,icon).node.height,20);
 assert.ok(f.graphics.every(g=>!g.commands.some(c=>c[0]==='fill')));
 assert.deepEqual({...n.color},{r:255,g:255,b:255,a:255});assert.equal(n.x,14);assert.equal(n.y,0);
});
test('optional Label failure falls back to small vector digits above artwork',()=>{
 for(const options of [{labels:false},{outlines:false},{throwLabel:true},{labels:false,fill:false}]){
  const f=setup(options);for(let i=1;i<=5;i++)stack(f,'s'+i,[i],{x:i*85});const r=f.overlay.render(f.s,null,{depth:5});
  assert.equal(r.status,'ready');assert.equal(r.labelMode,'vector_digits');assert.equal(r.coveredIcons,4);assert.equal(f.labelsList().length,0);
  for(const icon of f.icons()){const commands=icon.children.find(n=>n.name==='SDKtools Depth Digits').getComponent(f.cc.Graphics).commands;
   assert.ok(commands.some(c=>c[0]==='stroke'&&c[1]===1.2&&c[2].g===255));assert.ok(commands.some(c=>c[0]==='stroke'&&c[1]===3.4&&c[2].g===0));}
 }
});
test('matching trio gets distinct neon red outlines with a dark halo',()=>{
 const f=setup();f.add('a',0,{x:-80});f.add('b',0);f.add('c',0,{x:80,zone:'tray'});const r=f.overlay.render(f.s,proof(['a','b','c']));assert.equal(r.matchedBorders,3);
 const commands=f.graphics[0].commands;assert.equal(commands.filter(c=>c[0]==='stroke'&&c[1]===3&&c[2].r===255&&c[2].g===24&&c[2].b===48&&c[2].a===255).length,3);assert.equal(commands.filter(c=>c[0]==='stroke'&&c[1]===7&&c[2].r===35&&c[2].g===3&&c[2].b===8&&c[2].a===245).length,3);
 assert.deepEqual(commands[0],['move',-124,-49]);assert.deepEqual(commands[1],['line',-36,-49]);
});
test('invalid duplicates unmatched or overflowing proofs have no recommendation',()=>{
 const f=setup();f.add('a');f.add('b');f.add('c',0,{type:'different'});
 for(const p of [proof(['a','a','b']),proof(['a','b','missing']),proof(['a','b','c']),proof(['a','b','c'],8),proof(['a','b','c'],NaN)])assert.equal(f.overlay.render(f.s,p).matchedBorders,0);
});
test('hidden recommendations outline only displayed hint; omitted matches never move elsewhere',()=>{
 const f=setup(),{hidden}=stack(f,'a',[1,2,3,4,4]),ids=[hidden[0].id,hidden[1].id,hidden[4].id];const r=f.overlay.render(f.s,proof(ids),{depth:4});
 assert.equal(r.matchedBorders,2);assert.equal(r.hiddenByLayout,1);
 assert.equal(f.graphics[0].commands.filter(c=>c[0]==='stroke'&&c[1]===1.8&&c[2].r===255&&c[2].g===24&&c[2].b===48&&c[2].a===255).length,2);
 assert.equal(f.graphics[0].commands.filter(c=>c[0]==='stroke'&&c[1]===3&&c[2].r===255&&c[2].g===24&&c[2].b===48&&c[2].a===255).length,0);
});
test('original anchors and transforms determine strip and artwork placement',()=>{
 const f=setup(),{owner}=stack(f,'a',[1]);owner.node.anchorX=.2;owner.node.anchorY=.8;f.s.board.angle=12;f.s.board.x=31;f.s.board.y=-9;f.s.board.scaleX=.8;f.s.board.scaleY=.8;
 f.overlay.render(f.s,null);const icon=f.icons()[0],expected=f.layer().convertToNodeSpaceAR(owner.node.convertToWorldSpaceAR({x:-2,y:3}));
 assert.ok(Math.abs(icon.x-expected.x)<1e-8&&Math.abs(icon.y-expected.y)<1e-8);assert.ok(Math.abs(icon.angle-12)<1e-8);assert.ok(Math.abs(icon.scaleX-.8)<1e-8);
});
test('movement and frame changes update the same icon',()=>{
 const f=setup(),{hidden:[card]}=stack(f,'a',[1]);f.overlay.render(f.s,null);const icon=f.icons()[0],before={x:icon.x,y:icon.y};f.s.board.x+=17;f.s.board.y-=11;card.frame={name:'replacement'};f.overlay.render(f.s,null);
 assert.equal(f.icons()[0],icon);assert.equal(icon.x,before.x+17);assert.equal(icon.y,before.y-11);assert.equal(sprite(f,icon).spriteFrame,card.frame);
});
test('scene replacement and clear destroy only SDK-owned nodes',()=>{
 const f=setup();stack(f,'a',[1]);f.overlay.render(f.s,null);const old=f.layer(),icon=f.icons()[0],other=setup();stack(other,'b',[1]);assert.equal(f.overlay.render(other.s,null).status,'ready');assert.equal(old.isValid,false);assert.equal(icon.isValid,false);assert.equal(f.s.cards[0].node.isValid,true);f.overlay.clear();f.overlay.clear();assert.equal(other.layer(),undefined);
});
test('invalid metadata or coordinates clean hints instead of drawing guesses',()=>{
 for(const change of [c=>delete c.occlusionDepth,c=>c.occlusionDepth=1.5,c=>c.node.x=NaN,c=>c.blockedBy=['missing']]){const f=setup(),{hidden:[c]}=stack(f,'a',[1]);f.overlay.render(f.s,null);const old=f.layer();change(c);assert.equal(f.overlay.render(f.s,null).status,'unavailable');assert.equal(f.layer(),undefined);assert.equal(old.isValid,false);}
});
test('resource cannot invoke original controls or load external assets',()=>{
 assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);
 assert.doesNotMatch(source,/\.emit\s*\(|\.touchBlock\s*\(|\.on\s*\(|addComponent\(\s*cc\.(?:Button|BlockInputEvents)/);
});

test('corner icon and paired depth stay inside small and noncentral-anchor cards',()=>{
 for(const [w,h,ax,ay] of [[80,90,.5,.5],[60,70,.5,.5],[48,54,.2,.8],[120,100,.8,.2]]){
  const f=setup(),{owner}=stack(f,'a',[1,2,3,4]);Object.assign(owner.node,{width:w,height:h,anchorX:ax,anchorY:ay});
  const r=f.overlay.render(f.s,null,{depth:4});assert.equal(r.coveredIcons,4);
  for(const icon of f.icons()){
   for(const child of icon.children.filter(n=>/Outline|Artwork|Depth$/.test(n.name))){
    const x=icon.x+(child.x||0)*icon.scaleX,y=icon.y+(child.y||0)*icon.scaleY;
    assert.ok(x-child.width*icon.scaleX/2>=-w*ax-1e-7);
    assert.ok(x+child.width*icon.scaleX/2<=w*(1-ax)+1e-7);
    assert.ok(y-child.height*icon.scaleY/2>=-h*ay-1e-7);
    assert.ok(y+child.height*icon.scaleY/2<=h*(1-ay)+1e-7);
   }
  }
 }
 const f=setup(),{owner}=stack(f,'tiny',[1,2,3,4]);owner.node.width=30;owner.node.height=35;
 assert.equal(f.overlay.render(f.s,null,{depth:4}).coveredIcons,0);assert.equal(f.icons().length,0);
});

test('repeated depths remain individual cards and do not invent layer numbers',()=>{
 const f=setup();stack(f,'a',[1,1,2,4,5]);const r=f.overlay.render(f.s,null,{depth:9});
 assert.equal(r.coveredIcons,4);assert.equal(r.hiddenByDepth,1);
 assert.deepEqual(f.labelsList().map(n=>n.getComponent(f.cc.Label).string),['1','1','2','4']);
});

test('skew and mirrored transforms are rejected instead of detaching corner badges',()=>{
 for(const change of [n=>n.scaleX=-1,n=>{n.scaleX=2;n.angle=30;}]){
  const f=setup(),{owner}=stack(f,'a',[1,2,3,4]);f.s.board.scaleX=1.3;change(owner.node);
  assert.equal(f.overlay.render(f.s,null,{depth:4}).status,'unavailable');assert.equal(f.layer(),undefined);
 }
});

function countSetup(options={}){
 const f=setup(options);f.s.gameLayer.width=750;f.s.gameLayer.height=1623;f.s.board.y=67;
 const reserve=new f.cc.Node('reserve'),tray=new f.cc.Node('tray'),trayBg=new f.cc.Node('tray background');
 Object.assign(reserve,{width:240,height:90,y:-420});Object.assign(trayBg,{width:600,height:130,y:-560});Object.assign(tray,{width:560,height:80,y:10});
 f.s.gameLayer.addChild(reserve);f.s.gameLayer.addChild(trayBg);trayBg.addChild(tray);f.s.reserve=reserve;f.s.trayNode=tray;f.trayBackground=trayBg;
 const add=f.add;f.add=(id,depth=0,options={})=>{const c=add(id,depth,{type:'type:1',...options});c.rawID=id;
  if(c.zone==='reserve')reserve.addChild(c.node);if(c.zone==='tray')tray.addChild(c.node);return c;};
 f.countPanel=()=>f.layer()?.children.find(n=>n.name==='SDKtools Card Counts');
 f.countRows=()=>f.countPanel()?.children.filter(n=>n.name==='SDKtools Card Count').sort((a,b)=>b.y-a.y)||[];
 f.countValues=()=>f.countRows().map(n=>({row:n,frame:n.children.find(n=>n.name==='SDKtools Count Artwork').getComponent(f.cc.Sprite).spriteFrame,
  value:n.children.find(n=>n.name==='SDKtools Count Number')?.getComponent(f.cc.Label).string}));
 return f;
}
function removeCountCard(f,c){f.s.cards=f.s.cards.filter(x=>x!==c);f.s.tray=f.s.tray.filter(x=>x!==c);f.s.refs.delete(c.id);c.node.removeFromParent();}
function countNodeBounds(f,n){
 const points=[[-n.width*n.anchorX,-n.height*n.anchorY],[n.width*(1-n.anchorX),-n.height*n.anchorY],
  [n.width*(1-n.anchorX),n.height*(1-n.anchorY)],[-n.width*n.anchorX,n.height*(1-n.anchorY)]]
  .map(([x,y])=>f.layer().convertToNodeSpaceAR(n.convertToWorldSpaceAR({x,y})));
 return{left:Math.min(...points.map(p=>p.x)),right:Math.max(...points.map(p=>p.x)),top:Math.max(...points.map(p=>p.y)),bottom:Math.min(...points.map(p=>p.y))};
}

test('side list counts every loaded type across visible covered reserve and tray cards independent of depth',()=>{
 const f=countSetup(),d=f.add('diamond-a'),one=f.add('diamond-b',1),deep=f.add('diamond-c',5);
 one.blockedBy=[d.id];deep.blockedBy=[d.id];f.add('diamond-d',0,{zone:'reserve'});f.add('diamond-e',0,{zone:'tray'});
 const other=f.add('other',0,{type:'type:2'});other.metadata={specialType:99,lock:2};
 let r=f.overlay.render(f.s,null,{depth:1});assert.equal(r.countStatus,'ready');assert.equal(r.countedCards,6);assert.equal(r.countedTypes,2);
 assert.deepEqual(f.countValues().map(v=>v.value),['5','1']);assert.equal(f.countValues()[0].frame,d.frame);
 const rows=f.countRows();r=f.overlay.render(f.s,null,{depth:4});assert.equal(r.countedCards,6);assert.deepEqual(f.countRows(),rows);
 assert.equal(r.hiddenByDepth,1,'deep cards remain in total even without a depth badge');
});
test('moving a card into the tray preserves its count and matched removal updates only the surviving types',()=>{
 const f=countSetup(),a=f.add('a'),b=f.add('b'),c=f.add('c'),other=f.add('other',0,{type:'type:2'});
 f.overlay.render(f.s,null);const first=f.countValues()[0].row,otherRow=f.countValues()[1].row;
 f.s.cards.splice(f.s.cards.indexOf(a),1);f.s.tray.push(a);a.zone='tray';f.s.trayNode.addChild(a.node);
 f.overlay.render(f.s,null);assert.deepEqual(f.countValues().map(v=>v.value),['3','1']);assert.equal(f.countValues()[0].row,first);
 for(const card of [a,b,c])removeCountCard(f,card);
 const r=f.overlay.render(f.s,null);assert.equal(r.countedCards,1);assert.equal(r.countedTypes,1);assert.equal(first.isValid,false);
 assert.equal(f.countValues()[0].row,otherRow);assert.equal(f.countValues()[0].frame,other.frame);
});
test('count rows use numeric type order and a stable representative even with cloned frames',()=>{
 const f=countSetup();f.add('ten',0,{type:'type:10'});f.add('two',0,{type:'type:2'});
 const last=f.add('z',0,{frame:{name:'alternate skin'}}),first=f.add('a',0,{frame:{name:'first skin'}});
 f.overlay.render(f.s,null);assert.deepEqual(f.countValues().map(v=>v.value),['2','1','1']);assert.equal(f.countValues()[0].frame,first.frame);
 const rows=f.countRows();f.s.cards.reverse();f.overlay.render(f.s,null);assert.deepEqual(f.countRows(),rows);assert.equal(f.countValues()[0].frame,first.frame);
 first.frame={name:'updated original frame'};f.overlay.render(f.s,null);assert.equal(f.countValues()[0].frame,first.frame);assert.equal(f.countRows()[0],rows[0]);
 assert.notEqual(last.frame,first.frame);
});
test('unchanged count snapshots reuse all nodes and graphics without redraw',()=>{
 const f=countSetup();for(let i=1;i<=16;i++)f.add('card-'+i,0,{type:'type:'+i});f.overlay.render(f.s,null);
 const nodes=f.created.slice(),clears=f.graphics.map(g=>g.clears);
 for(let i=0;i<10;i++)f.overlay.render(f.s,null);
 assert.deepEqual(f.created,nodes);assert.deepEqual(f.graphics.map(g=>g.clears),clears);
});
test('sixteen square tiles match the upper-left reference with icons above counts and separate menu-colored backgrounds',()=>{
 const f=countSetup();for(let i=1;i<=16;i++)f.add('card-'+i,0,{type:'type:'+i});
 const before=f.s.cards.map(c=>[c.node.x,c.node.y,c.node.width,c.node.height,c.node.children.length]);
 const r=f.overlay.render(f.s,null),panel=f.countPanel();assert.equal(r.countedTypes,16);assert.equal(panel.width,58);assert.equal(panel.height,1018);
 const box=countNodeBounds(f,panel),host=countNodeBounds(f,f.s.gameLayer),board=countNodeBounds(f,f.s.board);
 assert.equal(box.left-host.left,33);assert.equal(box.right-host.left,91);assert.equal(box.right,board.left-4);
 assert.ok(Math.abs(host.top-box.top-162.3)<1e-7);assert.ok(Math.abs(host.top-box.bottom-1180.3)<1e-7);
 assert.ok(box.bottom>countNodeBounds(f,f.trayBackground).top);assert.ok(box.bottom>=host.bottom+8);
 const rows=f.countRows();for(let i=0;i<rows.length;i++){
  const row=rows[i],art=row.children.find(n=>n.name==='SDKtools Count Artwork'),number=row.children.find(n=>n.name==='SDKtools Count Number');
  assert.equal(row.width,58);assert.equal(row.height,58);assert.equal(art.width,28);assert.equal(art.height,31);assert.equal(number.getComponent(f.cc.Label).fontSize,16);
  assert.equal(art.x,0);assert.equal(number.x,0);assert.ok(art.y-art.height/2>number.y+number.height/2);
  for(const child of row.children.filter(n=>/Outline|Artwork|Number/.test(n.name))){
   const border=child.getComponent(f.cc.LabelOutline)?.width||0;
   assert.ok(child.x-child.width/2-border>=-29&&child.x+child.width/2+border<=29);
   assert.ok(child.y-child.height/2-border>=-29&&child.y+child.height/2+border<=29);
  }
  assert.ok(row.y+29<=panel.height/2&&row.y-29>=-panel.height/2);
  if(i)assert.equal(rows[i-1].y-row.y,64);
 }
 const panelGraphics=panel.getComponent(f.cc.Graphics);assert.equal(panelGraphics.commands.filter(c=>c[0]==='close').length,16);
 assert.equal(panelGraphics.commands.filter(c=>c[0]==='fill'&&c[1].r===23&&c[1].g===17&&c[1].b===13).length,1);
 assert.deepEqual(f.s.cards.map(c=>[c.node.x,c.node.y,c.node.width,c.node.height,c.node.children.length]),before);
 assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>!n.comps.some(c=>/Button|Collider|BlockInput/.test(c.constructor.name))));
});
test('sidebar stays left and hides on insufficient margin or collisions with cards and zone backgrounds',()=>{
 const f=countSetup();f.add('one');f.s.board.x=25;
 assert.equal(f.overlay.render(f.s,null).countStatus,'ready');assert.ok(f.countPanel().x<0);
 f.s.board.x=-40;assert.equal(f.overlay.render(f.s,null).countStatus,'unavailable');assert.equal(f.countPanel(),undefined,'free right margin must not relocate the list');
 const g=countSetup();g.add('edge',0,{x:280,y:550});assert.equal(g.overlay.render(g.s,null).countStatus,'ready');assert.ok(g.countPanel().x<0);
 g.add('left-edge',0,{x:-280,y:550});assert.equal(g.overlay.render(g.s,null).countStatus,'unavailable');assert.equal(g.countPanel(),undefined);
 const h=countSetup();h.add('one');Object.assign(h.s.reserve,{x:320,y:620});
 assert.equal(h.overlay.render(h.s,null).countStatus,'ready');assert.ok(h.countPanel().x<0);
 Object.assign(h.s.reserve,{x:-320,y:620,width:80});assert.equal(h.overlay.render(h.s,null).countStatus,'unavailable');assert.equal(h.countPanel(),undefined);
 h.s.reserve.x=320;Object.assign(h.trayBackground,{x:-250,y:600,width:160});h.s.trayNode.width=40;
 assert.equal(h.overlay.render(h.s,null).countStatus,'unavailable');assert.equal(h.countPanel(),undefined,'the wider tray background also prevents overlap');
});
test('count list hides completely on narrow or short geometry rather than truncating types',()=>{
 const f=countSetup();for(let i=1;i<=24;i++)f.add('card-'+i,0,{type:'type:'+i});
 assert.equal(f.overlay.render(f.s,null).countStatus,'unavailable');assert.equal(f.countPanel(),undefined);
 const g=countSetup();g.add('one');g.s.gameLayer.width=600;
 assert.equal(g.overlay.render(g.s,null).countStatus,'unavailable');assert.equal(g.countPanel(),undefined);
 g.s.gameLayer.width=750;g.s.gameLayer.height=40;
 assert.equal(g.overlay.render(g.s,null).countStatus,'unavailable');assert.equal(g.countPanel(),undefined);
});
test('counts follow transformed board bounds and stay within host on scale and rotation',()=>{
 for(const change of [n=>{n.scaleX=n.scaleY=.8;},n=>{n.angle=5;},n=>{n.anchorX=.4;n.anchorY=.7;}]){
  const f=countSetup();f.s.gameLayer.width=1000;f.add('one');change(f.s.board);
  const r=f.overlay.render(f.s,null);assert.equal(r.countStatus,'ready');const panel=f.countPanel();
  const board=countNodeBounds(f,f.s.board);
  assert.ok(panel.x+panel.width/2<=500-8&&panel.x-panel.width/2>=-500+8);
  assert.ok(Math.abs(panel.x+panel.width/2-(board.left-4))<1e-7);
 }
 const f=countSetup();f.add('one');f.s.board.scaleX=-1;
 assert.equal(f.overlay.render(f.s,null).countStatus,'unavailable');assert.equal(f.countPanel(),undefined);
 const g=countSetup();for(let i=1;i<=16;i++)g.add('card-'+i,0,{type:'type:'+i});assert.equal(g.overlay.render(g.s,null).countStatus,'ready');
 const old=g.countPanel();g.s.gameLayer.width=1623;g.s.gameLayer.height=750;
 assert.equal(g.overlay.render(g.s,null).countStatus,'unavailable');assert.equal(old.isValid,false);assert.equal(g.countPanel(),undefined);
 g.s.gameLayer.width=750;g.s.gameLayer.height=1623;assert.equal(g.overlay.render(g.s,null).countStatus,'ready');assert.equal(g.countRows().length,16);
});
test('invalid count identity or image removes stale counts without erasing valid corner hints',()=>{
 const cases=[c=>c.type=null,c=>c.type='type:01',c=>c.type='type:10001',c=>c.frame=null,c=>c.frame={name:''},c=>c.frame.isValid=false,
  (c,f)=>f.s.refs.set(c.id,{}),(c,f)=>c.rawID=f.s.cards[0].rawID];
 for(const change of cases){
  const f=countSetup(),owner=f.add('owner'),hidden=f.add('hidden',1),bad=f.add('other',0,{type:'type:2'});hidden.blockedBy=[owner.id];
  assert.equal(f.overlay.render(f.s,null).countStatus,'ready');const panel=f.countPanel(),hint=f.icons()[0];change(bad,f);
  const r=f.overlay.render(f.s,null);assert.equal(r.status,'ready');assert.equal(r.countStatus,'unavailable');assert.equal(f.countPanel(),undefined);
  assert.equal(panel.isValid,false);assert.equal(f.icons()[0],hint);assert.equal(hint.isValid,true);
 }
});
test('cross-zone duplicate identities never create inflated totals',()=>{
 const f=countSetup(),a=f.add('one');f.overlay.render(f.s,null);f.s.tray.push(a);
 assert.equal(f.overlay.render(f.s,null).countStatus,'unavailable');assert.equal(f.countPanel(),undefined);
 const g=countSetup();g.add('one');const other=g.add('two',0,{zone:'tray'});other.rawID='one';
 assert.equal(g.overlay.render(g.s,null).countStatus,'unavailable');assert.equal(g.countPanel(),undefined);
});
test('three-digit counts remain complete and vector fallback fits without Label support',()=>{
 for(const options of [{},{labels:false},{outlines:false},{throwLabel:true},{labels:false,fill:false}]){
  const f=countSetup(options);for(let i=0;i<512;i++)f.add('card-'+String(i).padStart(3,'0'));
  const r=f.overlay.render(f.s,null);assert.equal(r.countStatus,'ready');assert.equal(r.countedCards,512);assert.equal(r.countedTypes,1);
  const row=f.countRows()[0],number=row.children.find(n=>n.name==='SDKtools Count Number');
  if(number){assert.equal(number.getComponent(f.cc.Label).string,'512');assert.equal(number.x,0);assert.ok(number.width>=3*number.getComponent(f.cc.Label).fontSize*.6);
   assert.ok(number.y-number.height/2-number.getComponent(f.cc.LabelOutline).width>=-29);
  }else{
   const digits=row.children.find(n=>n.name==='SDKtools Count Digits'),commands=digits.getComponent(f.cc.Graphics).commands;
   assert.ok(commands.some(c=>c[0]==='stroke'&&c[1]===1.2));
   const xs=commands.filter(c=>c[0]==='move'||c[0]==='line').map(c=>digits.x+c[1]*digits.scaleX);
   const ys=commands.filter(c=>c[0]==='move'||c[0]==='line').map(c=>digits.y+c[2]*digits.scaleY),halo=3.4*digits.scaleX/2;
   assert.ok(Math.min(...xs)-halo>=-29&&Math.max(...xs)+halo<=29);
   assert.ok(Math.min(...ys)-halo>=-29&&Math.max(...ys)+halo<=29);
  }
 }
});
test('combined card bound includes the tray and unavailable reads never display a false zero',()=>{
 const f=countSetup();for(let i=0;i<512;i++)f.add('card-'+i);f.overlay.render(f.s,null);f.add('extra',0,{zone:'tray'});
 const r=f.overlay.render(f.s,null);assert.equal(r.status,'ready');assert.equal(r.countStatus,'unavailable');assert.equal(f.countPanel(),undefined);
});
test('empty snapshots clear old totals and scene replacement never retains a prior table count',()=>{
 const f=countSetup(),a=f.add('one');f.overlay.render(f.s,null);const old=f.countPanel();removeCountCard(f,a);
 assert.equal(f.overlay.render(f.s,null).countStatus,'empty');assert.equal(old.isValid,false);assert.equal(f.countPanel(),undefined);
 const b=f.add('new');f.overlay.render(f.s,null);const old2=f.countPanel(),other=countSetup();other.add('one',0,{type:'type:2'});other.add('two',0,{type:'type:2'});
 assert.equal(f.overlay.render(other.s,null).countedCards,2);assert.equal(old2.isValid,false);assert.equal(other.countValues()[0].value,'2');
 f.overlay.clear();assert.equal(other.countPanel(),undefined);assert.equal(b.node.isValid,true);
});

'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_flow.js'),'utf8');
function fixture(options={}){
  let time=0,interval=null,requests=0,resolver,rejecter,scene;
  const response=new Promise((resolve,reject)=>{resolver=resolve;rejecter=reject;});
  class Card {setup(card){this.cardInfo=card;return card;} }
  Card.prototype.__classname__='Card';
  const info={id:64,type:0,color:0,num:0};
  const component=new Card();Object.assign(component,{cardInfo:info,skinNode:{},bgSprite:{},typeSprite:{},backSprite:{}});
  const node={width:224,height:295,_components:[component],children:[]};component._node=node;
  scene={children:[node]};
  class Store {sync(value){this.gamers=value.gamers;this.discard_cards=value.discard_cards;this.start_time=value.start_time;return value;} updatePushMessage(value){Object.assign(this,value);} }
  const store=new Store();store.gamers=[{uid:'PRIVATE-USER',cards:[info]}];store.state=2;
  class Socket {sync(){requests++;return response;} }
  const socket=new Socket();socket.pushHandler=function(event,value){return value;};
  const modules={Card:{default:Card},GameStore:{default:store},Socket:{default:socket}},loads=[];
  const document={hidden:false,visibilityState:'visible'};
  const context={performance:{now:()=>time},document,cc:{ENGINE_VERSION:'2.4.5',director:{getScene:()=>scene}},__require(name){loads.push(name);return modules[name];},setInterval(fn){interval=fn;return 1;},clearInterval(){interval=null;}};
  context.window=context;Object.assign(context,options.context||{});
  const runtime=vm.runInNewContext(source,context)();
  const clean=x=>JSON.parse(JSON.stringify(x));
  return {runtime,context,store,socket,Card,component,info,modules,loads,response,resolve:resolver,reject:rejecter,clean,tick:()=>clean(runtime.tick()),requests:()=>requests,advance(ms){time+=ms;if(interval)interval();},changeScene(){scene={children:[]};},timer:()=>interval};
}
module.exports={fixture};

"""Native wiring contracts; execution tests live in macOS Foundation and JS fixtures."""
from pathlib import Path
import re
import unittest
ROOT=Path(__file__).resolve().parents[1]

class RuntimeRecoveryTests(unittest.TestCase):
    def read(self,name):return (ROOT/name).read_text(encoding='utf-8')

    def test_play_arms_during_read_only_poll_but_physical_work_remains_serial(self):
        source=self.read('Sources/SDKtools/STAutoplayRecorder.inc')
        getter=source.split('- (BOOL)autoplayStartBlockedByEvaluation {',1)[1].split('\n}',1)[0]
        self.assertIn('self.autoplayBusy && self.autoplayEvaluationMayAct',getter)
        start=source.split('- (BOOL)startAutoplay {',1)[1].split('- (void)pauseAutoplayWithReason:',1)[0]
        self.assertIn('self.autoplayStartBlockedByEvaluation',start)
        self.assertNotIn('|| self.autoplayBusy ||',start)
        self.assertNotRegex(start,r'(autoplayBusy|autoplayFastPending|coveredAttemptPending|autoplayEvaluationMayAct)\s*=')
        self.assertIn('self.autoplayEvaluationMayAct=actionAllowed || experimental;',source)
        tick=source.split('- (BOOL)autoplayTickWithCoveredAttempt:',1)[1]
        self.assertIn('|| self.autoplayBusy ||',tick)
        overlay=self.read('Sources/SDKtools/STOverlay.m')
        for item in ('autoBusy=otherBusy || r.autoplayStartBlockedByEvaluation','(!autoBusy && !b.enabled','r.autoplayStartBlockedByEvaluation?@"Wait…"'):
            self.assertIn(item,overlay)

    def test_small_hot_command_requires_the_already_bound_document(self):
        bridge=self.read('Sources/SDKtools/STAutoplayBridge.inc')
        self.assertIn('if (!context.contextID.length)',bridge)
        hot=bridge.split('// Hot path:',1)[1].split('self.inFlight = YES;',1)[0]
        self.assertIn("s.documentID!=='%@'",hot)
        self.assertIn('return null;',hot)
        self.assertNotIn('Object.defineProperty',hot)
        template=re.search(r'@"([^"\n]+)"',hot).group(1)
        self.assertEqual(len(re.findall(r'%@|%ld|%lu',template)),12)
        self.assertNotIn('self.autoplayScript',hot)
        self.assertIn('BOOL evaluationMayAct=allowAction || coveredAttempt || penetrateAttempt;',bridge)
        self.assertIn('STWPAutoResult(evaluationMayAct?@"dispatch_uncertain":@"watching", @"evaluation_timeout", YES)',bridge)
        self.assertIn('// Do not release or reset any latch:',bridge)

    def test_report_keeps_only_closed_phase_and_fast_diagnostics(self):
        sanitizer=self.read('Sources/SDKtools/STAutoplaySanitizer.inc').split('static NSDictionary *STWPSanitizeAutoplayReading',1)[1]
        self.assertIn('STWPSanitizePhaseSnapshotSummary(value[@"phaseSnapshotSummary"])',sanitizer)
        self.assertIn('STWPSanitizeSuperFast(value[@"superFast"])',sanitizer)
        self.assertNotRegex(sanitizer,r'addEntriesFromDictionary|safe\[@"cards"\]|safe\[@"secret"\]|safe\[@"packet_id"\]')

    def test_foundation_fixture_executes_the_production_read_only_gate(self):
        script=self.read('scripts/test_autoplay_bridge.sh')
        self.assertIn("source.index('- (BOOL)autoplayStartBlockedByEvaluation {')",script)
        self.assertIn('methods=source[gate_start:gate_end]+methods',script)
        fixture=self.read('Tests/covered_recorder_test.m')
        self.assertIn('CHECK(read.autoplayStartBlockedByEvaluation==(mask==3))',fixture)

if __name__=='__main__':unittest.main()

"""Portable wiring/privacy contracts. Real Foundation TCP tests run in macOS CI."""
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]

class LANContracts(unittest.TestCase):
    def read(self,name):return (ROOT/name).read_text(encoding='utf-8')
    def test_command_dictionary_is_typed_after_runtime_shape_guard(self):
        # The macOS fixture compiles this exact production include. On Windows
        # this is a source contract, not a substitute for the Apple compiler.
        s=self.read('Sources/SDKtools/STLANProtocol.inc').split('static NSDictionary *STLANCommand(id value) {',1)[1].split('// nil + error=0:',1)[0]
        self.assertLess(s.index('if (![value isKindOfClass:NSDictionary.class]) return nil;'),s.index('NSDictionary *command=value;'))
        self.assertLess(s.index('![preferences isKindOfClass:NSDictionary.class]'),s.index('NSDictionary *p=preferences;'))
        self.assertIn('command.count!=3',s);self.assertIn('command.count==2',s)
        self.assertNotRegex(s,r'\b(?:value|preferences)\s*\.\s*count\b')
    def test_closed_remote_commands_have_no_game_protocol_or_arbitrary_execution(self):
        protocol=self.read('Sources/SDKtools/STLANProtocol.inc')
        for action in ('start','pause','preferences','capture_start','capture_stop','report_export','sources_export'):
            self.assertIn('@"'+action+'"',protocol)
        adapter=self.read('Sources/SDKtools/STLANRecorder.inc')
        for call in ('[self startAutoplay]','[self pauseAutoplayWithReason:', '[self setAutoplaySpeedLevel:', '[self setPowersEnabled:'):
            self.assertIn(call,adapter)
        for forbidden in ('evaluateJavaScript','CMD_','TouchBlock','performCoveredAttempt','performPenetrate','responseMap','autoplayFastPending=NO','coveredAttemptPending=NO'):
            self.assertNotIn(forbidden,adapter)
    def test_origin_host_pairing_and_replay_guards_precede_native_callback(self):
        server=self.read('Sources/SDKtools/STLANServer.m');protocol=self.read('Sources/SDKtools/STLANProtocol.inc')
        self.assertIn('SecRandomCopyBytes',server);self.assertIn('self.pairAttempts>=5',server)
        self.assertIn('self.sequence+1',server);self.assertLess(server.index('self.sequence++;self.lastSeen=t;'),server.index('self.commandHandler?self.commandHandler(command)'))
        self.assertIn('STLANRequestOrigin(headers,self.authority,post)',server)
        self.assertIn('![p.address isEqual:self.controllerAddress]',server)
        self.assertIn('headers[@"transfer-encoding"]',protocol)
        self.assertIn('headers[@"expect"]',protocol)
    def test_listener_is_opt_in_wifi_ipv4_not_a_public_relay(self):
        server=self.read('Sources/SDKtools/STLANServer.m')
        self.assertIn('strcmp(p->ifa_name,"en0")',server);self.assertIn('STLANPrivateAddress(s)',server)
        self.assertIn('a.sin_port=0',server);self.assertNotIn('INADDR_ANY',server)
        self.assertIn('HTTP is NOT TLS',self.read('Sources/SDKtools/STLANServer.h'))
        adapter=self.read('Sources/SDKtools/STLANRecorder.inc')
        self.assertIn('UIApplicationStateActive',adapter)
        self.assertIn('self.lanOwnsAuto',adapter);self.assertIn('[s pauseAutoplayWithReason:',adapter)
        self.assertIn('(s.paired?8:120)',server)
    def test_lan_read_only_sampling_keeps_existing_action_gate(self):
        recorder=self.read('Sources/SDKtools/STAutoplayRecorder.inc')
        self.assertIn('!self.autoplayEnabled && !self.xrayEnabled && !self.lanSharingEnabled',recorder)
        self.assertIn('t-self.lanPollAt<0.2',recorder)
        self.assertIn('!experimental && !self.autoplayEnabled && !self.xrayEnabled && self.lanSharingEnabled && !self.coveredAttemptPending && !self.autoplayFastPending',recorder)
        self.assertIn('self.autoplayEvaluationMayAct=actionAllowed || experimental;',recorder)
        self.assertIn('self.autoplayEnabled && !STClientInteractionBlocked()',recorder)
        adapter=self.read('Sources/SDKtools/STLANRecorder.inc')
        self.assertIn('age<2&&[phase[@"complete"] boolValue]',adapter)
        self.assertIn('@"counts":fresh?phase[@"counts"]:NSNull.null',adapter)
        self.assertNotIn('performAutoplayStep',adapter)
    def test_panel_assets_and_real_foundation_tests_are_required_by_build(self):
        build=self.read('scripts/build_framework.sh');self.assertIn('bash scripts/test_lan.sh',build)
        self.assertIn('-framework Security',build)
        integration=self.read('scripts/integrate_ipa.py')
        self.assertIn("('LAN/panel.html', 'LAN/panel.js', 'LAN/panel.css')",integration)
        script=self.read('scripts/test_lan.sh')
        for f in ('Tests/lan_server_test.m','Tests/lan_speed_test.m','Tests/lan_export_test.m'):
            self.assertIn(f,script)
        for f in ('panel.html','panel.js','panel.css'):
            self.assertLess((ROOT/'Resources/LAN'/f).stat().st_size,65536)
    def test_dashboard_has_no_external_assets_or_secret_persistence(self):
        html=self.read('Resources/LAN/panel.html');js=self.read('Resources/LAN/panel.js')
        self.assertNotRegex(html,r'(?:src|href)=["\']https?://')
        self.assertNotRegex(js,r'localStorage|sessionStorage|document\.cookie|innerHTML')
        for name in ('board','tray','reserve','total','start','pause','speed','planning','powers','xray','capture-start','capture-stop','report-export','sources-export','download'):
            self.assertIn('id="'+name+'"',html)
        self.assertIn('HTTP sem criptografia',html)
        self.assertIn('Nenhum reenvio automático',js)
    def test_no_account_or_game_identifiers_are_copied_into_remote_state(self):
        s=self.read('Sources/SDKtools/STLANRecorder.inc').split('- (NSDictionary *)lanControlSnapshot {',1)[1].split('- (NSDictionary *)lanApplyCommand:',1)[0]
        for key in ('token','uid','rid','packet_id','responseMap','rawID','URL','pairingCode'):
            self.assertNotIn('@"'+key+'"',s)
        self.assertIn('STWPSanitizePhaseSnapshotSummary',s);self.assertIn('STWPSanitizeSuperFast',s)

if __name__=='__main__':unittest.main()

#import <Foundation/Foundation.h>
extern BOOL STTestLicenseAuthorized;
extern BOOL STLicenseAllowsFeatures(void);

'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {setup}=require('./card_sampler_fixture.cjs');
const back=id=>({id,type:0,color:0,num:0});
const blue=id=>({id,type:1,color:2,num:9});
test('injected menu pipeline survives zero visible Card nodes',()=>{
 const f=setup({integrated:true,cards:[blue(1),back(2)]});f.first.nodes.forEach(x=>x.c.node.removeFromParent());
 const r=f.overlay.tick();assert.equal(r.samplerHooks,3);assert.equal(r.handTotal,2);assert.equal(r.handKnown,1);assert.equal(r.handsStatus,'ready');f.overlay.clear();assert.equal(f.intervals.size,0);
});
test('injected menu pipeline survives a scene traversal budget failure',()=>{
 const f=setup({integrated:true});for(let i=0;i<513;i++)f.initial.canvas.addChild(new f.cc.Node('decoration'));
 const r=f.overlay.tick();assert.equal(r.reason,'sampler_only');assert.equal(r.status,'ready');assert.equal(r.handTotal,1);assert.equal(r.handUnknown,1);assert.equal(r.samplerHooks,3);f.overlay.clear();
});
test('hooks remember a between-polls exposure and render its white-ring marker later',()=>{
 const f=setup({integrated:true});f.Card.prototype.setup=function(info){this.cardInfo=info;info.type=info.color=info.num=0;};
 const before=f.overlay.tick();assert.equal(before.handKnown,0);f.first.nodes[0].component.setup(blue(98));
 const after=f.overlay.tick();assert.equal(after.handKnown,1);assert.equal(after.handUnknown,0);assert.equal(after.samplerHiddenKnown,1);assert.equal(after.shown,1);assert.equal(after.samplerSetups,1);
 assert.ok(f.hints()[0].getComponent(f.cc.Graphics).commands.filter(x=>x[0]==='circle').length>=3);f.overlay.clear();
});
test('badge unknown count agrees with injected menu rather than the old polling-only reader',()=>{
 const f=setup({integrated:true});f.Card.prototype.setup=function(info){this.cardInfo=info;info.type=info.color=info.num=0;};
 f.overlay.tick();f.first.nodes[0].component.setup(blue(98));assert.equal(f.overlay.tick().handUnknown,0);
 const badge=f.layer().children.find(n=>n.name==='SDKtools Hand Count');assert.equal(badge.children[0].getComponent(f.cc.Label).string,'1 carta · ?0');f.overlay.clear();
});
test('direct typed model can bind a concealed UI face without Store object identity',()=>{
 const f=setup({integrated:true,cards:[blue(98)]});f.first.nodes[0].component.cardInfo=back(98);
 const r=f.overlay.tick();assert.equal(r.handKnown,1);assert.equal(r.shown,1);assert.equal(r.samplerHiddenKnown,0);f.overlay.clear();
});
test('native renderer clear removes hooks and leaves only original methods and game nodes',()=>{
 const f=setup({integrated:true});const sync=f.store.sync,setupMethod=f.Card.prototype.setup,node=f.first.nodes[0].c.node;
 f.overlay.tick();assert.notEqual(f.store.sync,sync);f.overlay.clear();assert.equal(f.store.sync,sync);assert.equal(f.Card.prototype.setup,setupMethod);assert.equal(node.isValid,true);assert.equal(f.intervals.size,0);
});

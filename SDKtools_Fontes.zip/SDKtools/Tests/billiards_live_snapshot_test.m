#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STBilliardsLiveSnapshot.h"
#import "../Sources/SDKtools/STBilliardsCaptureReport.h"
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#ifdef STBL_TEST_RUNTIME_HELPERS
#import "shot_helpers.h"
#endif

static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *message) {
    checks++;
    if (!condition) {
        failures++;
        fprintf(stderr, "FAIL %s\n", message.UTF8String);
    }
}

static NSMutableDictionary *Fixture(void) {
    NSDictionary *raw=@{
        @"format":@"SDKtools.BilliardsLive", @"schemaVersion":@1, @"status":@"aiming",
        @"resourceGameId":@20, @"gameType":@1003, @"sessionId":@700, @"frameNumber":@42,
        @"cameraInstanceId":@(-101),
        @"scene":@{@"handle":@41, @"name":@"BilliardInGame"},
        @"screen":@{@"width":@1170, @"height":@2532},
        @"balls":@[
            @{@"tag":@1, @"number":@0, @"active":@YES, @"potted":@NO,
              @"world":@{@"x":@0, @"y":@0, @"z":@0},
              @"screen":@{@"x":@100, @"y":@200, @"depth":@2},
              @"radiusPixels":@14, @"speed":@0},
            @{@"tag":@2, @"number":@1, @"active":@YES, @"potted":@NO,
              @"world":@{@"x":@1, @"y":@0, @"z":@0},
              @"screen":@{@"x":@200, @"y":@200, @"depth":@2},
              @"radiusPixels":@14, @"speed":@0}
        ],
        @"cue":@{@"world":@{@"x":@0, @"y":@0, @"z":@0},
                 @"direction":@{@"x":@1, @"y":@0, @"z":@0}},
        @"segments":@[
            @{@"kind":@"cue", @"from":@{@"x":@100, @"y":@200, @"depth":@2},
              @"to":@{@"x":@172, @"y":@200, @"depth":@2},
              @"worldFrom":@{@"x":@0, @"y":@0, @"z":@0},
              @"worldTo":@{@"x":@0.72, @"y":@0, @"z":@0}}
        ],
        @"prediction":@{@"available":@YES, @"reason":@"ready", @"model":@"geometric", @"maxBounces":@3}
    };
    NSData *json=[NSJSONSerialization dataWithJSONObject:raw options:0 error:NULL];
    return [NSJSONSerialization JSONObjectWithData:json options:NSJSONReadingMutableContainers error:NULL];
}

static NSMutableDictionary *Ball(NSMutableDictionary *raw, NSUInteger index) {
    return raw[@"balls"][index];
}
static NSMutableDictionary *Segment(NSMutableDictionary *raw) {
    return raw[@"segments"][0];
}
static NSDictionary *Sanitize(id raw, NSString *label, NSString **failure) {
    @try {
        NSDictionary *result=STBilliardsSanitizeSnapshot(raw, failure);
        Check(YES, [label stringByAppendingString:@": no exception"]);
        return result;
    } @catch (NSException *exception) {
        Check(NO, [NSString stringWithFormat:@"%@: raised %@",label,exception.name]);
        return nil;
    }
}
static void Reject(id raw, NSString *label) {
    NSString *failure=nil;
    NSDictionary *result=Sanitize(raw,label,&failure);
    Check(result==nil,label);
    Check(failure.length>0,[label stringByAppendingString:@": bounded failure reason"]);
}

static NSString *IdentityLabel(NSString *field, id value, NSString *testCase) {
    const char *type=[value isKindOfClass:NSNumber.class]?[value objCType]:"not NSNumber";
    return [NSString stringWithFormat:@"%@: field=%@ value=%@ objCType=%s",testCase,field,value,type?:"null"];
}
static void SetIdentity(NSMutableDictionary *raw, NSString *field, id value) {
    if ([field isEqual:@"scene.handle"]) raw[@"scene"][@"handle"]=value;
    else raw[field]=value;
}
static id Identity(NSDictionary *snapshot, NSString *field) {
    return [field isEqual:@"scene.handle"]?snapshot[@"scene"][@"handle"]:snapshot[field];
}

/* Keep both boxed literals and runtime unsigned construction: Foundation can
 * choose different NSNumber implementations for these two producer paths. */
static NSArray *OverflowIdentityCases(void) {
    volatile uint64_t runtimeMax=UINT64_MAX;
    volatile uint64_t runtimeAboveSigned=(uint64_t)INT64_MAX+UINT64_C(1);
    volatile uint64_t runtimeWrappedNegative=(uint64_t)(int64_t)-101;
    NSData *json=[@"{\"value\":18446744073709551615}" dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error=nil;
    id parsed=[NSJSONSerialization JSONObjectWithData:json options:0 error:&error];
    id jsonValue=[parsed isKindOfClass:NSDictionary.class]?parsed[@"value"]:nil;
    Check(error==nil && [jsonValue isKindOfClass:NSNumber.class],
          @"UINT64_MAX JSON literal parses into NSNumber without an error");
    NSMutableArray *cases=[@[
        @[@"UINT64_MAX literal", @(UINT64_MAX)],
        @[@"UINT64_MAX runtime unsigned", [NSNumber numberWithUnsignedLongLong:runtimeMax]],
        @[@"INT64_MAX plus one unsigned", [NSNumber numberWithUnsignedLongLong:runtimeAboveSigned]],
        @[@"unsigned representation of negative 101", [NSNumber numberWithUnsignedLongLong:runtimeWrappedNegative]]
    ] mutableCopy];
    if (error==nil && [jsonValue isKindOfClass:NSNumber.class])
        [cases addObject:@[@"UINT64_MAX parsed from literal JSON bytes",jsonValue]];
    return cases;
}

static void TestSignedIdentityBoundaries(void) {
    NSArray *accepted=@[
        @[@"INT32_MIN signed", [NSNumber numberWithLongLong:INT32_MIN]],
        @[@"INT32_MAX signed", [NSNumber numberWithLongLong:INT32_MAX]],
        @[@"negative one signed", @(-1)],
        @[@"negative 101 signed", @(-101)],
        @[@"INT32_MIN double", [NSNumber numberWithDouble:(double)INT32_MIN]],
        @[@"INT32_MAX double", [NSNumber numberWithDouble:(double)INT32_MAX]],
        @[@"negative one double", [NSNumber numberWithDouble:-1.0]],
        @[@"negative 101 double", [NSNumber numberWithDouble:-101.0]],
        @[@"positive integer double", [NSNumber numberWithDouble:41.0]]
    ];
    NSArray *rejected=@[
        @[@"signed below INT32_MIN", [NSNumber numberWithLongLong:(int64_t)INT32_MIN-1]],
        @[@"signed above INT32_MAX", [NSNumber numberWithLongLong:(int64_t)INT32_MAX+1]],
        @[@"INT64_MIN signed", [NSNumber numberWithLongLong:INT64_MIN]],
        @[@"INT64_MAX signed", [NSNumber numberWithLongLong:INT64_MAX]],
        @[@"double below INT32_MIN", [NSNumber numberWithDouble:(double)INT32_MIN-1.0]],
        @[@"double above INT32_MAX", [NSNumber numberWithDouble:(double)INT32_MAX+1.0]],
        @[@"positive fraction", @1.5],
        @[@"negative fraction", @(-101.5)],
        @[@"NaN", @(NAN)],
        @[@"positive infinity", @(INFINITY)],
        @[@"negative infinity", @(-INFINITY)]
    ];
    NSArray *allRejected=[rejected arrayByAddingObjectsFromArray:OverflowIdentityCases()];
    for (NSString *field in @[@"cameraInstanceId",@"scene.handle"]) {
        for (NSArray *testCase in accepted) {
            NSNumber *value=testCase[1];
            NSString *label=IdentityLabel(field,value,testCase[0]);
            NSMutableDictionary *raw=Fixture(); SetIdentity(raw,field,value);
            NSDictionary *safe=Sanitize(raw,label,NULL);
            Check(safe!=nil,[label stringByAppendingString:@": accepted"]);
            Check(Identity(safe,field)!=nil && [Identity(safe,field) longLongValue]==value.longLongValue,
                  [label stringByAppendingString:@": exact signed value retained"]);
            Check([safe[@"prediction"][@"available"] boolValue],
                  [label stringByAppendingString:@": drawable prediction retained"]);
        }
        for (NSArray *testCase in allRejected) {
            NSMutableDictionary *raw=Fixture(); SetIdentity(raw,field,testCase[1]);
            Reject(raw,IdentityLabel(field,testCase[1],testCase[0]));
        }
    }
}

static void TestNondrawableOverflowIdentities(void) {
    NSString *status=@"not_ready";
    NSArray *overflowCases=OverflowIdentityCases();
    for (NSString *field in @[@"cameraInstanceId",@"scene.handle"]) {
        for (NSArray *testCase in overflowCases) {
            NSMutableDictionary *raw=Fixture(); raw[@"status"]=status;
            raw[@"prediction"][@"reason"]=@"camera_unavailable";
            SetIdentity(raw,field,testCase[1]);
            NSString *label=IdentityLabel(field,testCase[1],
                [NSString stringWithFormat:@"%@ nondrawable %@",status,testCase[0]]);
            NSDictionary *safe=Sanitize(raw,label,NULL);
            Check(safe!=nil && [safe[@"status"] isEqual:status],
                  [label stringByAppendingString:@": diagnostic status retained"]);
            Check(Identity(safe,field)==nil,[label stringByAppendingString:@": overflow identity omitted"]);
            Check([safe[@"reason"] isEqual:@"camera_unavailable"] &&
                  [safe[@"prediction"][@"reason"] isEqual:@"camera_unavailable"],
                  [label stringByAppendingString:@": diagnostic reason retained"]);
            Check([safe[@"segments"] count]==0 && ![safe[@"prediction"][@"available"] boolValue],
                  [label stringByAppendingString:@": diagnostic cannot draw"]);
            Check([safe[@"sessionId"] isEqual:raw[@"sessionId"]],
                  [label stringByAppendingString:@": valid context retained"]);
        }
    }
}

static void TestValidAndDetachedOutput(void) {
    NSMutableDictionary *raw=Fixture();
    NSDictionary *safe=Sanitize(raw,@"valid aim",NULL);
    Check(safe!=nil,@"valid aim accepted");
    Check([safe[@"status"] isEqual:@"aiming"],@"aim status retained");
    Check([safe[@"prediction"][@"available"] boolValue],@"valid prediction available");
    Check([safe[@"balls"] count]==2 && [safe[@"segments"] count]==1,@"balls and segment retained");
    Check([safe[@"cameraInstanceId"] integerValue]==-101,@"negative Unity camera instance ID valid");
    Check([NSJSONSerialization isValidJSONObject:safe],@"accepted output is JSON compatible");

    raw=Fixture();
    raw[@"extra"]=[NSObject new];
    raw[@"screen"][@"token"]=@"private-value";
    raw[@"scene"][@"private"]=@"private-value";
    raw[@"cue"][@"private"]=@"private-value";
    raw[@"prediction"][@"private"]=@"private-value";
    Ball(raw,0)[@"private"]=[NSData data];
    Ball(raw,0)[@"screen"][@"private"]=@"private-value";
    Segment(raw)[@"private"]=[NSObject new];
    safe=Sanitize(raw,@"untrusted extras",NULL);
    Check(safe!=nil && [NSJSONSerialization isValidJSONObject:safe],@"non-JSON extras discarded");
    NSData *encoded=safe?[NSJSONSerialization dataWithJSONObject:safe options:0 error:NULL]:nil;
    NSString *text=encoded?[[NSString alloc] initWithData:encoded encoding:NSUTF8StringEncoding]:@"";
    Check(![text containsString:@"private"] && safe[@"extra"]==nil,@"extra fields omitted at all levels");
    Ball(raw,0)[@"screen"][@"x"]=@999;
    Segment(raw)[@"to"][@"x"]=@999;
    raw[@"screen"][@"width"]=@16;
    Check([safe[@"balls"][0][@"screen"][@"x"] integerValue]==100,@"ball coordinates detached");
    Check([safe[@"segments"][0][@"to"][@"x"] integerValue]==172,@"segment coordinates detached");
    Check([safe[@"screen"][@"width"] integerValue]==1170,@"screen dimensions detached");

    raw=Fixture();
    NSMutableString *status=[@"aiming" mutableCopy], *reason=[@"ready" mutableCopy];
    NSMutableString *scene=[@"BilliardInGame" mutableCopy], *kind=[@"cue" mutableCopy];
    raw[@"status"]=status; raw[@"prediction"][@"reason"]=reason;
    raw[@"scene"][@"name"]=scene; Segment(raw)[@"kind"]=kind;
    safe=Sanitize(raw,@"mutable incoming strings",NULL);
    [status setString:@"error"]; [reason setString:@"changed"];
    [scene setString:@"LoadingBilliard"]; [kind setString:@"changed"];
    Check([safe[@"status"] isEqual:@"aiming"],@"status string detached");
    Check([safe[@"reason"] isEqual:@"ready"] && [safe[@"prediction"][@"reason"] isEqual:@"ready"],@"reason strings detached");
    Check([safe[@"scene"][@"name"] isEqual:@"BilliardInGame"],@"scene name detached");
    Check([safe[@"segments"][0][@"kind"] isEqual:@"cue"],@"segment kind detached");
}

static void TestBallAndGeometryRejections(void) {
    NSMutableDictionary *raw=Fixture();
    Ball(raw,1)[@"tag"]=@1; Ball(raw,1)[@"number"]=@0;
    Reject(raw,@"duplicate ball identity");
    raw=Fixture(); Ball(raw,1)[@"number"]=@2; Reject(raw,@"mismatched ball number");
    raw=Fixture(); Ball(raw,0)[@"tag"]=@0; Reject(raw,@"invalid ball tag");
    raw=Fixture(); raw[@"scene"][@"name"]=@"LoadingBilliard";
    NSString *failure=nil;
    Check(Sanitize(raw,@"loading scene",&failure)==nil,@"loading is not a table");
    Check([failure isEqual:@"scene_not_billiards"],@"wrong scene reason is explicit");
    raw=Fixture(); raw[@"scene"][@"name"]=@"BilliardTutorial";
    Check(Sanitize(raw,@"tutorial scene",NULL)!=nil,@"evidenced tutorial scene accepted");

    NSArray *badValues=@[@(NAN), @(INFINITY), @(-INFINITY), @YES, @"100", NSNull.null, @{}, @[]];
    for (id value in badValues) {
        raw=Fixture(); Ball(raw,0)[@"screen"][@"x"]=value; Reject(raw,@"invalid projected scalar");
        raw=Fixture(); Ball(raw,0)[@"world"][@"z"]=value; Reject(raw,@"invalid world scalar");
    }
    raw=Fixture(); Ball(raw,0)[@"screen"][@"x"]=@1171; Reject(raw,@"ball offscreen");
    raw=Fixture(); Ball(raw,0)[@"screen"][@"depth"]=@0; Reject(raw,@"ball on camera plane");
    raw=Fixture(); Segment(raw)[@"to"][@"depth"]=@(-1); Reject(raw,@"segment behind camera");
    raw=Fixture(); Segment(raw)[@"worldTo"][@"x"]=@(NAN); Reject(raw,@"nonfinite segment endpoint");
    raw=Fixture(); Ball(raw,0)[@"radiusPixels"]=@0; Reject(raw,@"zero projected radius");
    raw=Fixture(); Ball(raw,0)[@"speed"]=@(-1); Reject(raw,@"negative speed");
    raw=Fixture(); raw[@"segments"]=@[]; Reject(raw,@"available prediction without segments");
    raw=Fixture(); raw[@"cue"]=NSNull.null; Reject(raw,@"available prediction without cue");
}

static void TestNondrawableStates(void) {
    NSMutableDictionary *raw=Fixture(); raw[@"status"]=@"not_ready";
    raw[@"gates"]=@{@"hasCore":@YES,@"hasCamera":@NO,@"hasFrame":@1,
                    @"hasEnum":@"true",@"unknownExtra":@YES};
    NSDictionary *safe=Sanitize(raw,@"partial capability gates",NULL);
    Check([safe[@"gates"] count]==2 && [safe[@"gates"][@"hasCore"] boolValue] &&
          [safe[@"gates"][@"hasCamera"] isEqual:@NO],@"only allowlisted literal boolean gates preserved");
    Check(safe[@"gates"][@"hasFrame"]==nil && safe[@"gates"][@"hasEnum"]==nil &&
          safe[@"gates"][@"unknownExtra"]==nil,@"nonboolean and unknown gates dropped");
    raw=Fixture(); raw[@"status"]=@"moving";
    safe=Sanitize(raw,@"explicit moving",NULL);
    Check(safe!=nil && [safe[@"segments"] count]==0,@"moving strips producer segments");
    Check(![safe[@"prediction"][@"available"] boolValue],@"moving disables prediction");
    raw=Fixture(); Ball(raw,1)[@"speed"]=@0.003;
    safe=Sanitize(raw,@"observed speed",NULL);
    Check([safe[@"status"] isEqual:@"moving"],@"observed motion overrides aiming claim");
    Check([safe[@"segments"] count]==0 && [safe[@"prediction"][@"reason"] isEqual:@"balls_moving"],@"motion clears lines and explains why");

    for (NSUInteger variant=0; variant<2; variant++) {
        raw=Fixture(); NSMutableDictionary *ball=Ball(raw,1);
        ball[@"active"]=variant?@YES:@NO; ball[@"potted"]=variant?@YES:@NO;
        ball[@"world"]=NSNull.null; ball[@"screen"]=NSNull.null;
        ball[@"speed"]=NSNull.null; ball[@"radiusPixels"]=NSNull.null;
        safe=Sanitize(raw,@"inactive or potted null projection",NULL);
        Check(safe!=nil && [safe[@"prediction"][@"available"] boolValue],@"nonplaying ball needs no projection");
        Check(safe[@"balls"][1][@"world"]==nil && safe[@"balls"][1][@"screen"]==nil,@"null projection omitted");
    }
    raw=Fixture(); Ball(raw,0)[@"potted"]=@YES; Ball(raw,0)[@"screen"]=NSNull.null;
    safe=Sanitize(raw,@"cue potted",NULL);
    Check(safe!=nil && ![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,@"potted cue suppresses all lines");

    for (NSString *status in @[@"not_ready",@"wrong_scene",@"unsupported",@"error",@"stopped"]) {
        raw=Fixture(); raw[@"status"]=status;
        raw[@"prediction"][@"reason"]=@"camera_unavailable";
        [raw removeObjectForKey:@"cameraInstanceId"];
        raw[@"cue"]=@"invalid but nondrawable";
        safe=Sanitize(raw,status,NULL);
        Check(safe!=nil && [safe[@"status"] isEqual:status],@"nondrawable status retained");
        Check([safe[@"reason"] isEqual:@"camera_unavailable"] && [safe[@"prediction"][@"reason"] isEqual:@"camera_unavailable"],@"nested failure reason retained");
        Check([safe[@"segments"] count]==0 && ![safe[@"prediction"][@"available"] boolValue],@"failure state cannot carry drawable lines");
        Check([safe[@"sessionId"] integerValue]==700 && [safe[@"scene"][@"handle"] integerValue]==41,@"partial context retained");
        Check([safe[@"balls"] count]==2 && safe[@"balls"][0][@"screen"]==nil,@"partial report keeps identities only");
    }
}

static void TestUntrustedTypes(void) {
    Reject(nil,@"nil root"); Reject(NSNull.null,@"null root"); Reject(@[],@"array root");
    NSMutableDictionary *raw=Fixture(); [raw removeObjectForKey:@"status"]; Reject(raw,@"missing status");
    raw=Fixture(); [raw[@"scene"] removeObjectForKey:@"name"]; Reject(raw,@"missing scene name");
    raw=Fixture(); [Segment(raw) removeObjectForKey:@"kind"]; Reject(raw,@"missing segment kind");
    for (NSString *key in @[@"schemaVersion",@"resourceGameId",@"gameType",@"sessionId",@"frameNumber",@"cameraInstanceId"]) {
        raw=Fixture(); raw[key]=@YES; Reject(raw,IdentityLabel(key,raw[key],@"boolean cannot impersonate numeric identity"));
        raw=Fixture(); raw[key]=@1.5; Reject(raw,IdentityLabel(key,raw[key],@"fractional identity rejected"));
        raw=Fixture(); raw[key]=@(UINT64_MAX); Reject(raw,IdentityLabel(key,raw[key],@"overflow identity rejected"));
    }
    raw=Fixture(); Ball(raw,0)[@"active"]=@1; Reject(raw,@"numeric one is not active boolean");
    raw=Fixture(); Ball(raw,0)[@"potted"]=@0; Reject(raw,@"numeric zero is not potted boolean");
    raw=Fixture(); raw[@"prediction"][@"available"]=@1; Reject(raw,@"numeric availability rejected");
    for (id invalid in @[NSNull.null,@"text",@7,@[]]) {
        for (NSString *key in @[@"scene",@"screen",@"prediction",@"cue"]) {
            raw=Fixture(); raw[key]=invalid; Reject(raw,@"invalid nested dictionary type");
        }
        raw=Fixture(); Ball(raw,0)[@"world"]=invalid; Reject(raw,@"invalid ball world type");
        raw=Fixture(); Ball(raw,0)[@"screen"]=invalid; Reject(raw,@"invalid ball screen type");
    }
    raw=Fixture(); raw[@"balls"]=@[@"not-a-ball"]; Reject(raw,@"invalid ball element");
    raw=Fixture(); raw[@"segments"]=@[@42]; Reject(raw,@"invalid segment element");
    raw=Fixture(); raw[@"balls"]=@{}; Reject(raw,@"dictionary instead of ball array");
    raw=Fixture(); raw[@"segments"]=NSNull.null; Reject(raw,@"null segment array");
    raw=Fixture(); raw[@"prediction"][@"reason"]=@"unsafe\nvalue";
    NSDictionary *safe=Sanitize(raw,@"reason control character",NULL);
    Check([safe[@"prediction"][@"reason"] isEqual:@"unavailable"],@"diagnostic reason excludes control characters");
    Check([STBilliardsDiagnosticToken([@"a" stringByPaddingToLength:97 withString:@"a" startingAtIndex:0]) isEqual:@"unavailable"],@"diagnostic token length bounded");
}

/* These fixtures exercise the data contract, not a physics simulation. The
 * Lua-produced three-ball fixture below separately tests producer agreement. */
static NSMutableDictionary *ChainFixture(void) {
    NSMutableDictionary *raw=Fixture();
    NSMutableDictionary *third=[Ball(raw,1) mutableCopy];
    third[@"tag"]=@3; third[@"number"]=@2;
    third[@"world"]=@{@"x":@2,@"y":@0,@"z":@0};
    third[@"screen"]=@{@"x":@300,@"y":@200,@"depth":@2};
    [raw[@"balls"] addObject:third];
    raw[@"prediction"]=[@{@"available":@YES,@"reason":@"ready",@"model":@"geometric",@"maxBounces":@6,
        @"chainVersion":@1,@"events":@3,@"queries":@4,@"collisions":@2,@"bounces":@0,
        @"affectedBallCount":@3,@"truncated":@NO} mutableCopy];
    NSMutableArray *segments=[NSMutableArray array];
    for (NSUInteger index=0; index<3; index++) {
        NSMutableDictionary *segment=[Segment(raw) mutableCopy];
        segment[@"kind"]=index?@"object":@"cue";
        segment[@"ballTag"]=@(index+1); segment[@"eventIndex"]=@(index+1);
        segment[@"terminal"]=index==2?@"horizon":@"ball";
        if (index<2) segment[@"hitBallTag"]=@(index+2);
        [segments addObject:segment];
    }
    raw[@"segments"]=segments;
    return raw;
}

static void TestChainRoundtripAndBounds(void) {
    NSMutableDictionary *raw=ChainFixture();
    NSDictionary *safe=Sanitize(raw,@"three-ball chain contract",NULL);
    Check(safe!=nil && [safe[@"prediction"] isEqual:raw[@"prediction"]],@"chain metadata retained exactly");
    Check([safe[@"segments"] isEqual:raw[@"segments"]],@"chain tags targets events and endpoints retained");
    Check(safe && [NSJSONSerialization isValidJSONObject:safe],@"chain output is JSON-compatible");
    NSData *json=safe?[NSJSONSerialization dataWithJSONObject:safe options:0 error:NULL]:nil;
    NSDictionary *decoded=json?[NSJSONSerialization JSONObjectWithData:json options:0 error:NULL]:nil;
    Check([decoded[@"prediction"] isEqual:safe[@"prediction"]] &&
          [decoded[@"segments"] isEqual:safe[@"segments"]],@"chain metadata survives JSON export roundtrip");
    NSMutableString *terminal=[@"ball" mutableCopy];
    Segment(raw)[@"terminal"]=terminal;
    raw[@"prediction"][@"unknown"]=[NSObject new];
    Segment(raw)[@"unknown"]=[NSObject new];
    safe=Sanitize(raw,@"chain strings and numeric fields detach",NULL);
    [terminal setString:@"changed"];
    Segment(raw)[@"ballTag"]=@16; raw[@"prediction"][@"events"]=@64;
    Check([safe[@"segments"][0][@"terminal"] isEqual:@"ball"] &&
          [safe[@"segments"][0][@"ballTag"] integerValue]==1 &&
          [safe[@"prediction"][@"events"] integerValue]==3,@"chain output detached from producer mutations");
    Check(safe[@"prediction"][@"unknown"]==nil && safe[@"segments"][0][@"unknown"]==nil,
          @"unknown chain fields omitted without traversal");

    raw=ChainFixture();
    for (NSUInteger tag=4; tag<=16; tag++) {
        NSMutableDictionary *ball=[Ball(raw,1) mutableCopy];
        ball[@"tag"]=@(tag); ball[@"number"]=@(tag-1);
        [raw[@"balls"] addObject:ball];
    }
    NSMutableArray *segments=[NSMutableArray array];
    for (NSUInteger index=0; index<48; index++) {
        NSMutableDictionary *segment=[Segment(raw) mutableCopy];
        segment[@"kind"]=@"rebound"; segment[@"ballTag"]=@(index/3+1);
        segment[@"eventIndex"]=@(index+1); segment[@"terminal"]=index%3==2?@"limit":@"cushion";
        [segment removeObjectForKey:@"hitBallTag"];
        [segments addObject:segment];
    }
    raw[@"segments"]=segments;
    raw[@"prediction"][@"events"]=@48; raw[@"prediction"][@"bounces"]=@32;
    raw[@"prediction"][@"affectedBallCount"]=@16; raw[@"prediction"][@"truncated"]=@YES;
    safe=Sanitize(raw,@"full forty-eight-segment chain",NULL);
    Check(safe!=nil && [safe[@"segments"] count]==48,@"chain permits forty-eight segments");
    Check([safe[@"prediction"][@"truncated"] isEqual:@YES] &&
          [safe[@"prediction"][@"maxBounces"] integerValue]==6,@"chain limit evidence preserved");
    [segments addObject:[segments[0] mutableCopy]];
    Reject(raw,@"chain forty-ninth segment rejected");

    raw=Fixture(); segments=[NSMutableArray array];
    for (NSUInteger i=0; i<12; i++) [segments addObject:[Segment(raw) mutableCopy]];
    raw[@"segments"]=segments;
    safe=Sanitize(raw,@"legacy twelve-segment limit",NULL);
    Check(safe!=nil && [safe[@"segments"] count]==12 && safe[@"prediction"][@"chainVersion"]==nil,
          @"legacy twelve-segment schema unchanged");
    [segments addObject:[segments[0] mutableCopy]];
    Reject(raw,@"legacy thirteenth segment still rejected");
    raw=Fixture(); raw[@"prediction"][@"maxBounces"]=@4;
    Reject(raw,@"legacy fourth bounce still rejected");
}

static void TestChainMalformedSchema(void) {
    NSDictionary *caps=@{@"chainVersion":@1,@"maxBounces":@6,@"events":@64,@"queries":@96,
        @"collisions":@64,@"bounces":@64,@"affectedBallCount":@16};
    for (NSString *key in caps) {
        NSMutableDictionary *raw=ChainFixture();
        if (![key isEqual:@"chainVersion"]) {
            [raw[@"prediction"] removeObjectForKey:key];
            Reject(raw,[key stringByAppendingString:@" chain field required"]);
        }
        for (id invalid in @[@YES,@NO,@(-1),@1.5,@(NAN),@(INFINITY),@(UINT64_MAX),@"1",NSNull.null,
                              @([caps[key] longLongValue]+1)]) {
            raw=ChainFixture(); raw[@"prediction"][key]=invalid;
            Reject(raw,[key stringByAppendingString:@" malformed chain integer rejected"]);
        }
    }
    NSMutableDictionary *raw=ChainFixture(); raw[@"prediction"][@"chainVersion"]=@0;
    Reject(raw,@"zero chain version cannot downgrade");
    raw=ChainFixture(); raw[@"prediction"][@"model"]=@"physical";
    Reject(raw,@"chain does not claim unimplemented physical model");
    for (NSString *key in @[@"truncated",@"available"]) {
        raw=ChainFixture(); [raw[@"prediction"] removeObjectForKey:key];
        Reject(raw,[key stringByAppendingString:@" chain boolean required"]);
        for (id value in @[@0,@1,@"true",NSNull.null]) {
            raw=ChainFixture(); raw[@"prediction"][key]=value;
            Reject(raw,[key stringByAppendingString:@" chain literal boolean required"]);
        }
    }
    for (NSString *key in @[@"ballTag",@"eventIndex",@"hitBallTag"]) {
        raw=ChainFixture(); [Segment(raw) removeObjectForKey:key];
        Reject(raw,[key stringByAppendingString:@" chain segment field required"]);
        for (id invalid in @[@YES,@NO,@0,@(-1),@1.5,@(NAN),@(INFINITY),@(UINT64_MAX),@"1",NSNull.null,@65]) {
            raw=ChainFixture(); Segment(raw)[key]=invalid;
            Reject(raw,[key stringByAppendingString:@" malformed chain segment integer rejected"]);
        }
    }
    raw=ChainFixture(); Segment(raw)[@"eventIndex"]=@4;
    Reject(raw,@"segment event cannot exceed observed event counter");
    raw=ChainFixture(); raw[@"prediction"][@"events"]=@0;
    Reject(raw,@"nonempty chain requires an event");
    raw=ChainFixture(); Segment(raw)[@"ballTag"]=@16;
    Reject(raw,@"segment source must be observed in same snapshot");
    raw=ChainFixture(); Segment(raw)[@"hitBallTag"]=@16;
    Reject(raw,@"collision target must be observed in same snapshot");
    raw=ChainFixture(); Segment(raw)[@"hitBallTag"]=@1;
    Reject(raw,@"ball cannot collide with itself");
    for (NSString *key in @[@"active",@"potted"]) {
        for (NSUInteger index=0; index<2; index++) {
            raw=ChainFixture(); Ball(raw,index)[key]=[key isEqual:@"active"]?@NO:@YES;
            Reject(raw,@"chain source and target must remain active and nonpotted");
        }
    }
    for (id terminal in @[@"unknown",@"Ball",@1,@YES,NSNull.null]) {
        raw=ChainFixture(); Segment(raw)[@"terminal"]=terminal;
        Reject(raw,@"unknown or mistyped chain terminal rejected");
    }
    raw=ChainFixture(); [Segment(raw) removeObjectForKey:@"terminal"];
    Reject(raw,@"chain terminal is required");
    for (NSString *terminal in @[@"cushion",@"pocket",@"horizon",@"limit"]) {
        raw=ChainFixture(); Segment(raw)[@"terminal"]=terminal;
        Reject(raw,@"nonball terminal must not carry a collision target");
        [Segment(raw) removeObjectForKey:@"hitBallTag"];
        NSDictionary *safe=Sanitize(raw,@"allowed nonball terminal",NULL);
        Check([safe[@"segments"][0][@"terminal"] isEqual:terminal],@"allowed terminal retained");
    }
    raw=ChainFixture(); Segment(raw)[@"worldTo"]=[@{@"x":@(NAN),@"y":@0,@"z":@0} mutableCopy];
    Reject(raw,@"chain cannot bypass finite world endpoint guard");
    raw=ChainFixture(); Segment(raw)[@"to"]=[@{@"x":@100,@"y":@200,@"depth":@(-1)} mutableCopy];
    Reject(raw,@"chain cannot bypass camera depth guard");
}

static void TestChainNondrawableStates(void) {
    for (NSString *status in @[@"moving",@"not_ready",@"wrong_scene",@"unsupported",@"error",@"stopped"]) {
        NSMutableDictionary *raw=ChainFixture(); raw[@"status"]=status;
        NSDictionary *safe=Sanitize(raw,@"chain nondraw status",NULL);
        Check(safe!=nil && [safe[@"segments"] count]==0 && ![safe[@"prediction"][@"available"] boolValue],
              @"nondraw chain status cannot release guides");
        Check([safe[@"prediction"][@"chainVersion"] integerValue]==1 &&
              [safe[@"prediction"][@"events"] integerValue]==3,@"nondraw chain counters retained");
        raw[@"prediction"][@"chainVersion"]=@2;
        Reject(raw,@"nondraw status cannot hide unsupported chain version");
    }
    NSMutableDictionary *raw=ChainFixture(); Ball(raw,1)[@"speed"]=@0.003;
    NSDictionary *safe=Sanitize(raw,@"observed chain motion",NULL);
    Check([safe[@"status"] isEqual:@"moving"] && [safe[@"segments"] count]==0 &&
          ![safe[@"prediction"][@"available"] boolValue],@"observed motion still overrides chain aiming claim");
    raw=ChainFixture(); raw[@"prediction"][@"available"]=@NO; raw[@"segments"]=@[];
    safe=Sanitize(raw,@"chain aiming with unavailable prediction",NULL);
    Check(safe!=nil && [safe[@"status"] isEqual:@"aiming"] && [safe[@"segments"] count]==0,
          @"aiming unavailable chain may have no segments");
    raw=ChainFixture(); raw[@"status"]=@"moving"; Segment(raw)[@"ballTag"]=@16;
    Reject(raw,@"moving chain does not excuse malformed supplied segment identity");
}

static NSMutableDictionary *PhysicsFixture(void) {
    return [@{@"schemaVersion":@1,@"available":@YES,@"reason":@"ready",@"fixedDeltaTime":@0.02,
        @"gravity":@{@"x":@0,@"y":@(-9.81),@"z":@0},@"stopSpeedSquared":@0.008,@"stopAngularSpeed":@0.2,
        @"power":@40,@"sliderMax":@100,@"powerReference":@100,@"deadzone":@1,
        @"spin":@{@"x":@0,@"y":@0},@"launchSpeed":@3,@"muTable":@1,
        @"profile":@"cache1084_physics_v1",@"modelLimit":@"no_custom_contact_correction"} mutableCopy];
}
static NSMutableDictionary *FiniteFixture(void) {
    NSMutableDictionary *raw=ChainFixture();
    raw[@"physics"]=PhysicsFixture();
    for (NSMutableDictionary *ball in raw[@"balls"]) {
        ball[@"velocity"]=@{@"x":@0,@"y":@0,@"z":@0};
        ball[@"angularVelocity"]=@{@"x":@0,@"y":@0,@"z":@0};
        ball[@"inertiaTensor"]=@{@"x":@0.0049,@"y":@0.0049,@"z":@0.0049};
        ball[@"mass"]=@0.45; ball[@"drag"]=@0.8; ball[@"angularDrag"]=@0.05;
    }
    NSMutableDictionary *prediction=raw[@"prediction"];
    [prediction addEntriesFromDictionary:@{@"chainVersion":@2,@"model":@"finite",@"durationSeconds":@3,
        @"stepCount":@150,@"complete":@YES,@"calibration":@"captured_damping_sliding_v1"}];
    NSMutableArray *states=[NSMutableArray array];
    for (NSMutableDictionary *segment in raw[@"segments"]) {
        segment[@"timeSeconds"]=segment[@"eventIndex"];
        if ([segment[@"ballTag"] integerValue]==3) segment[@"terminal"]=@"rest";
        [states addObject:[@{@"ballTag":segment[@"ballTag"],@"world":segment[@"worldTo"],
            @"screen":segment[@"to"],@"outcome":@"rest"} mutableCopy]];
    }
    prediction[@"finalStates"]=states;
    return raw;
}
static void TestFinitePredictionSchema(void) {
    NSMutableDictionary *raw=FiniteFixture();
    NSDictionary *safe=Sanitize(raw,@"finite guide and rest endpoints",NULL);
    Check(safe!=nil && [safe[@"prediction"] isEqual:raw[@"prediction"]],@"finite prediction metadata preserved");
    Check([safe[@"physics"] isEqual:raw[@"physics"]] && [safe[@"segments"] isEqual:raw[@"segments"]],
          @"finite live inputs and timed segments preserved");
    Check([safe[@"balls"] isEqual:raw[@"balls"]],@"measured per-ball dynamics preserved");
    Check(safe && [NSJSONSerialization isValidJSONObject:safe],@"finite output is JSON-compatible");
    for (NSString *key in @[@"durationSeconds",@"stepCount",@"complete",@"calibration",@"finalStates"]) {
        raw=FiniteFixture(); [raw[@"prediction"] removeObjectForKey:key];
        Reject(raw,[key stringByAppendingString:@" finite field required"]);
    }
    for (id value in @[@YES,@(-1),@15.01,@(NAN),@(INFINITY),NSNull.null]) {
        raw=FiniteFixture();raw[@"prediction"][@"durationSeconds"]=value;Reject(raw,@"invalid finite duration rejected");
    }
    for (id value in @[@YES,@(-1),@750.5,@751,@(NAN),@(UINT64_MAX),NSNull.null]) {
        raw=FiniteFixture();raw[@"prediction"][@"stepCount"]=value;Reject(raw,@"invalid finite step count rejected");
    }
    raw=FiniteFixture();raw[@"prediction"][@"complete"]=@1;Reject(raw,@"finite completion requires boolean");
    raw=FiniteFixture();raw[@"prediction"][@"calibration"]=@"guessed";Reject(raw,@"unknown finite calibration rejected");
    raw=FiniteFixture();raw[@"prediction"][@"truncated"]=@YES;Reject(raw,@"truncated prediction cannot claim completion");
    raw=FiniteFixture();raw[@"prediction"][@"complete"]=@NO;Reject(raw,@"incomplete prediction cannot label resting position");
    raw=FiniteFixture();raw[@"prediction"][@"finalStates"][0][@"outcome"]=@"unknown";
    Reject(raw,@"complete prediction cannot include unknown final position");
    raw=FiniteFixture(); raw[@"prediction"][@"complete"]=@NO;raw[@"prediction"][@"truncated"]=@YES;
    for (NSMutableDictionary *state in raw[@"prediction"][@"finalStates"]) state[@"outcome"]=@"unknown";
    safe=Sanitize(raw,@"explicitly incomplete finite prefix",NULL);
    Check(safe!=nil && ![safe[@"prediction"][@"complete"] boolValue],@"unknown partial positions remain distinguishable");
    for (id value in @[@YES,@0,@17,@1.5,@(UINT64_MAX),NSNull.null]) {
        raw=FiniteFixture();raw[@"prediction"][@"finalStates"][0][@"ballTag"]=value;
        Reject(raw,@"invalid final ball identity rejected");
    }
    raw=FiniteFixture();raw[@"prediction"][@"finalStates"][0][@"ballTag"]=@16;
    Reject(raw,@"final ball must be initially observed active");
    raw=FiniteFixture();raw[@"prediction"][@"finalStates"][1][@"ballTag"]=@1;
    Reject(raw,@"duplicate final ball rejected");
    raw=FiniteFixture();raw[@"prediction"][@"affectedBallCount"]=@2;
    Reject(raw,@"final count must match affected count");
    raw=FiniteFixture();raw[@"prediction"][@"finalStates"][0][@"outcome"]=@"stopped";
    Reject(raw,@"unknown final outcome rejected");
    raw=FiniteFixture();raw[@"prediction"][@"finalStates"][0][@"screen"]=@{@"x":@100,@"y":@2533,@"depth":@2};
    Reject(raw,@"finite final point outside viewport rejected");
    raw=FiniteFixture();raw[@"prediction"][@"finalStates"][0][@"world"]=@{@"x":@99,@"y":@0,@"z":@0};
    Reject(raw,@"claimed final rest must agree with emitted endpoint");
    for (id value in @[@YES,@(-1),@3.01,@15.01,@(NAN),NSNull.null]) {
        raw=FiniteFixture();Segment(raw)[@"timeSeconds"]=value;Reject(raw,@"invalid segment simulation time rejected");
    }
    raw=FiniteFixture();[Segment(raw) removeObjectForKey:@"timeSeconds"];Reject(raw,@"finite segment needs simulation time");
    raw=ChainFixture();Segment(raw)[@"terminal"]=@"rest";[Segment(raw) removeObjectForKey:@"hitBallTag"];
    Reject(raw,@"legacy geometric chain cannot claim rest terminal");
    raw=FiniteFixture();raw[@"status"]=@"moving";
    safe=Sanitize(raw,@"finite observed motion disables drawing",NULL);
    Check(safe!=nil && ![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,
          @"finite model never bypasses moving guard");
}
static void TestPhysicsEvidenceAndObservedDynamics(void) {
    for (NSString *key in @[@"velocity",@"angularVelocity",@"mass",@"drag",@"angularDrag",@"inertiaTensor"]) {
        NSMutableDictionary *raw=FiniteFixture();[Ball(raw,0) removeObjectForKey:key];
        Reject(raw,[key stringByAppendingString:@" required for finite available guide"]);
        raw=FiniteFixture();Ball(raw,0)[key]=NSNull.null;Reject(raw,@"present malformed dynamics rejected");
    }
    NSMutableDictionary *raw=FiniteFixture();[raw removeObjectForKey:@"physics"];Reject(raw,@"finite guide requires live physics input");
    raw=FiniteFixture();raw[@"physics"][@"available"]=@NO;Reject(raw,@"unavailable physics cannot authorize finite guide");
    for (NSString *key in @[@"fixedDeltaTime",@"power",@"launchSpeed",@"muTable"]) {
        raw=FiniteFixture();raw[@"physics"][key]=@YES;Reject(raw,@"physics scalar cannot be boolean");
        raw=FiniteFixture();raw[@"physics"][key]=@(NAN);Reject(raw,@"physics scalar must be finite");
    }
    raw=FiniteFixture();raw[@"physics"][@"profile"]=@"other";Reject(raw,@"unknown physics profile cannot authorize guide");
    raw=FiniteFixture();Ball(raw,0)[@"inertiaTensor"]=@{@"x":@0,@"y":@1,@"z":@1};
    Reject(raw,@"nonpositive inertia component rejected");
    raw=FiniteFixture();raw[@"status"]=@"not_ready";raw[@"reason"]=@"not_aiming";
    NSDictionary *safe=Sanitize(raw,@"observed stopped turn geometry",NULL);
    Check([safe[@"observedDynamics"][@"schemaVersion"] integerValue]==1 &&
          [safe[@"observedDynamics"][@"balls"] isEqual:raw[@"balls"]],@"not-ready evidence retains all validated observed dynamics");
    Check([safe[@"segments"] count]==0 && ![safe[@"prediction"][@"available"] boolValue],
          @"observed dynamics never authorize guides");
    Ball(raw,1)[@"angularVelocity"]=@{@"x":@(NAN),@"y":@0,@"z":@0};
    safe=Sanitize(raw,@"one bad observed dynamics row",NULL);
    Check(safe!=nil && safe[@"observedDynamics"]==nil,@"invalid observed row drops whole evidence block");
    raw=FiniteFixture();raw[@"status"]=@"not_ready";
    [Ball(raw,1) removeObjectForKey:@"angularVelocity"];
    safe=Sanitize(raw,@"missing measured angular velocity",NULL);
    Check([safe[@"observedDynamics"][@"balls"] count]==3 &&
          safe[@"observedDynamics"][@"balls"][1][@"angularVelocity"]==nil,
          @"missing angular velocity remains missing rather than becoming a rest claim");
    raw=FiniteFixture();raw[@"status"]=@"not_ready";[raw removeObjectForKey:@"cameraInstanceId"];
    safe=Sanitize(raw,@"partial identity cannot attach observed geometry",NULL);
    Check(safe!=nil && safe[@"observedDynamics"]==nil,@"observed dynamics require full frame identity");
    raw=FiniteFixture();raw[@"status"]=@"unsupported";
    safe=Sanitize(raw,@"unsupported scene does not attach observed geometry",NULL);
    Check(safe!=nil && safe[@"observedDynamics"]==nil,@"observed dynamics are limited to not-ready samples");
    raw=Fixture();raw[@"physics"]=PhysicsFixture();raw[@"physics"][@"gravity"]=@"invalid";
    safe=Sanitize(raw,@"malformed optional physics on legacy snapshot",NULL);
    Check(safe!=nil && safe[@"physics"]==nil,@"malformed optional diagnostic is dropped without weakening legacy guards");
}

static NSMutableDictionary *EnvironmentFixture(void) {
    NSDictionary *raw=@{
        @"schemaVersion":@1, @"mode":@"structural_only", @"stage":@"before_contract", @"sequence":@1,
        @"packageType":@"table", @"loadedType":@"table", @"debugType":@"table", @"getupvalueType":@"function",
        @"scannedKeys":@12, @"matchedKeys":@2, @"scanTruncated":@NO,
        @"modulesTruncated":@NO, @"environmentsTruncated":@NO, @"errorCount":@0,
        @"limits":@{@"scanKeys":@512,@"modules":@24,@"environments":@8,@"upvalues":@16,@"lookupDepth":@4},
        @"globals":@[@{@"name":@"Enum",@"rawType":@"nil",@"resolvedType":@"table",
                       @"lookup":@"metatable_table",@"indexType":@"table",@"depth":@1}],
        @"modules":@[@{@"name":@"Billiard/Lua/Const/Init",@"valueType":@"function",@"source":@"known_key",
                       @"gameType":@1003,@"upvaluesScanned":@1,@"environmentIndex":@2,@"environmentStatus":@"found"}],
        @"environments":@[
            @{@"index":@1,@"source":@"_G",@"sameAsGlobal":@YES,@"coreType":@"table",@"enumType":@"nil",
              @"constType":@"nil",@"biLogicType":@"nil",@"managerType":@"table",
              @"frameDescriptorType":@"nil",@"tutorialDescriptorType":@"nil",@"contractValid":@NO},
            @{@"index":@2,@"source":@"Billiard/Lua/Const/Init",@"sameAsGlobal":@NO,
              @"coreType":@"table",@"enumType":@"table",@"constType":@"table",@"biLogicType":@"table",
              @"managerType":@"table",@"enumGameType":@1003,@"constGameType":@1003,
              @"frameDescriptorType":@"string",@"tutorialDescriptorType":@"table",@"contractValid":@YES}
        ]
    };
    NSData *json=[NSJSONSerialization dataWithJSONObject:raw options:0 error:NULL];
    return [NSJSONSerialization JSONObjectWithData:json options:NSJSONReadingMutableContainers error:NULL];
}
static NSMutableDictionary *EnvironmentSnapshot(id environment) {
    NSMutableDictionary *raw=Fixture();
    raw[@"status"]=@"unsupported";
    raw[@"reason"]=@"billiards_contract_mismatch";
    raw[@"environment"]=environment;
    return raw;
}
static void DiscardEnvironment(id environment, NSString *label) {
    NSDictionary *safe=Sanitize(EnvironmentSnapshot(environment),label,NULL);
    Check(safe!=nil && [safe[@"status"] isEqual:@"unsupported"],
          [label stringByAppendingString:@": legacy diagnostic survives"]);
    Check(safe[@"environment"]==nil,[label stringByAppendingString:@": whole invalid environment removed"]);
    Check(![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,
          [label stringByAppendingString:@": unsupported cannot draw"]);
    Check(safe && [NSJSONSerialization isValidJSONObject:safe],
          [label stringByAppendingString:@": no untrusted values retained"]);
}
static void TestEnvironmentRoundtripAndIsolation(void) {
    NSMutableDictionary *environment=EnvironmentFixture();
    NSDictionary *safe=Sanitize(EnvironmentSnapshot(environment),@"environment structural evidence",NULL);
    Check([safe[@"environment"] isEqual:environment],@"all explicit environment fields retained");
    Check([safe[@"environment"][@"globals"][0][@"lookup"] isEqual:@"metatable_table"],
          @"table-valued __index resolution remains explicit diagnostic evidence");
    Check(safe[@"environment"][@"environments"][0][@"enumGameType"]==nil &&
          safe[@"environment"][@"environments"][0][@"constGameType"]==nil,
          @"unobserved global game types are not synthesized");
    Check([safe[@"environment"][@"environments"][1][@"contractValid"] boolValue] &&
          ![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,
          @"valid alternate environment cannot authorize unsupported segments");
    NSData *encoded=safe?[NSJSONSerialization dataWithJSONObject:safe options:0 error:NULL]:nil;
    id parsed=encoded?[NSJSONSerialization JSONObjectWithData:encoded options:NSJSONReadingMutableContainers error:NULL]:nil;
    NSDictionary *roundtrip=Sanitize(parsed,@"environment JSON roundtrip",NULL);
    Check([roundtrip isEqual:safe],@"environment survives JSON roundtrip without new drawing authority");
    NSMutableDictionary *legacy=Fixture();
    NSDictionary *legacySafe=Sanitize(legacy,@"legacy without environment",NULL);
    Check(legacySafe[@"environment"]==nil && [legacySafe[@"prediction"][@"available"] boolValue],
          @"legacy valid drawing schema remains additive and compatible");
    legacy[@"environment"]=environment;
    NSDictionary *withEnvironment=Sanitize(legacy,@"aiming with environment",NULL);
    Check([withEnvironment[@"segments"] isEqual:legacySafe[@"segments"]] &&
          [withEnvironment[@"prediction"] isEqual:legacySafe[@"prediction"]],
          @"environment does not change previously validated drawing");
    legacy[@"environment"]=@{@"mode":@"invalid"};
    NSDictionary *invalidOptional=Sanitize(legacy,@"aiming invalid optional environment",NULL);
    Check([invalidOptional isEqual:legacySafe],@"invalid optional environment does not invalidate legacy drawing");

    environment=EnvironmentFixture();
    [environment[@"modules"][0] removeObjectForKey:@"gameType"];
    [environment[@"modules"][0] removeObjectForKey:@"environmentIndex"];
    [environment[@"environments"][1] removeObjectForKey:@"enumGameType"];
    [environment[@"environments"][1] removeObjectForKey:@"constGameType"];
    safe=Sanitize(EnvironmentSnapshot(environment),@"absent optional environment fields",NULL);
    Check([safe[@"environment"] isEqual:environment],@"optional observed IDs may be absent without defaults");

    environment=EnvironmentFixture();
    NSMutableString *module=[@"Billiard/Lua/Const/Init" mutableCopy];
    environment[@"modules"][0][@"name"]=module;
    environment[@"private"]=[NSObject new];
    environment[@"limits"][@"private"]=[NSData data];
    environment[@"globals"][0][@"private"]=@{@"account":@"private-value"};
    environment[@"modules"][0][@"private"]=[NSObject new];
    environment[@"environments"][0][@"private"]=@[@"private-value"];
    safe=Sanitize(EnvironmentSnapshot(environment),@"environment private extras",NULL);
    Check(safe[@"environment"]!=nil && [NSJSONSerialization isValidJSONObject:safe],
          @"unknown non-JSON environment fields are never copied");
    encoded=safe?[NSJSONSerialization dataWithJSONObject:safe options:0 error:NULL]:nil;
    NSString *text=encoded?[[NSString alloc] initWithData:encoded encoding:NSUTF8StringEncoding]:@"";
    Check(![text containsString:@"private"],@"private extras omitted at every environment level");
    [module setString:@"Changed"];
    environment[@"globals"][0][@"resolvedType"]=@"string";
    environment[@"limits"][@"scanKeys"]=@1;
    [environment[@"environments"] removeAllObjects];
    Check([safe[@"environment"][@"modules"][0][@"name"] isEqual:@"Billiard/Lua/Const/Init"] &&
          [safe[@"environment"][@"globals"][0][@"resolvedType"] isEqual:@"table"] &&
          [safe[@"environment"][@"limits"][@"scanKeys"] integerValue]==512 &&
          [safe[@"environment"][@"environments"] count]==2,@"environment output detached from producer mutation");
}
static void TestEnvironmentBoundsAndNames(void) {
    NSMutableDictionary *environment=EnvironmentFixture();
    environment[@"sequence"]=@(INT32_MAX); environment[@"scannedKeys"]=@512;
    environment[@"matchedKeys"]=@536; environment[@"errorCount"]=@128;
    environment[@"scanTruncated"]=@YES; environment[@"modulesTruncated"]=@YES; environment[@"environmentsTruncated"]=@YES;
    NSMutableArray *globals=[NSMutableArray array], *modules=[NSMutableArray array], *environments=[NSMutableArray array];
    for (NSString *name in @[@"Core",@"Enum",@"Const",@"BiLogic",@"package",@"debug",@"CS"]) {
        NSMutableDictionary *row=[environment[@"globals"][0] mutableCopy]; row[@"name"]=name; row[@"depth"]=@4;
        [globals addObject:row];
    }
    for (NSUInteger index=0; index<24; index++) {
        NSMutableDictionary *row=[environment[@"modules"][0] mutableCopy];
        row[@"name"]=[NSString stringWithFormat:@"Billiard/Lua/Test%lu",(unsigned long)index];
        row[@"gameType"]=@(INT32_MAX); row[@"upvaluesScanned"]=@16; row[@"environmentIndex"]=@8;
        [modules addObject:row];
    }
    for (NSUInteger index=1; index<=8; index++) {
        NSMutableDictionary *row=[environment[@"environments"][1] mutableCopy];
        row[@"index"]=@(index); row[@"enumGameType"]=@0; row[@"constGameType"]=@(INT32_MAX);
        [environments addObject:row];
    }
    environment[@"globals"]=globals; environment[@"modules"]=modules; environment[@"environments"]=environments;
    NSDictionary *safe=Sanitize(EnvironmentSnapshot(environment),@"maximum bounded environment",NULL);
    Check([safe[@"environment"] isEqual:environment],@"inclusive environment limits retained exactly");
    NSData *encoded=safe?[NSJSONSerialization dataWithJSONObject:safe options:0 error:NULL]:nil;
    Check(encoded && encoded.length<65536,@"bounded environment fits bridge snapshot byte limit");
    for (NSString *key in @[@"globals",@"modules",@"environments"]) {
        [environment[key] addObject:[environment[key][0] mutableCopy]];
        DiscardEnvironment(environment,[key stringByAppendingString:@" exceeds array limit"]);
        [environment[key] removeLastObject];
    }
    for (NSString *name in @[@"Billiard/Lua/Const/Enum",@"billiard/lua/const/enum",@"Billiard.Lua.Const.Enum",@"billiard.lua.const.enum"]) {
        environment=EnvironmentFixture(); environment[@"modules"][0][@"name"]=name;
        environment[@"environments"][1][@"source"]=name;
        safe=Sanitize(EnvironmentSnapshot(environment),name,NULL);
        Check([safe[@"environment"][@"modules"][0][@"name"] isEqual:name] &&
              [safe[@"environment"][@"environments"][1][@"source"] isEqual:name],@"explicit slash and dotted module prefixes retained");
    }
    NSString *length96=[@"Billiard/" stringByPaddingToLength:96 withString:@"a" startingAtIndex:0];
    environment=EnvironmentFixture(); environment[@"modules"][0][@"name"]=length96;
    safe=Sanitize(EnvironmentSnapshot(environment),@"96-character module name",NULL);
    Check([safe[@"environment"][@"modules"][0][@"name"] length]==96,@"module name inclusive maximum accepted");
    NSArray *invalidNames=@[@"Billiard/",@"Billiard//Lua",@"Billiard/../Secret",@"Billiard./Lua",@"BILLIARD/Lua",
                           @"Other/Lua",@"Billiard/Lua\nSecret",@"Billiard/Lua Secret",@"Billiard/Lua:Secret",
                           @"Billiard/Lua-é",[length96 stringByAppendingString:@"a"]];
    for (NSString *name in invalidNames) {
        environment=EnvironmentFixture(); environment[@"modules"][0][@"name"]=name;
        DiscardEnvironment(environment,@"invalid module token");
        environment=EnvironmentFixture(); environment[@"environments"][1][@"source"]=name;
        DiscardEnvironment(environment,@"invalid environment source token");
    }
}
static void TestEnvironmentMalformedFields(void) {
    for (id invalid in @[NSNull.null,@[],@"text",@1,[NSObject new]])
        DiscardEnvironment(invalid,@"invalid environment root type");
    NSMutableDictionary *environment;
    NSDictionary *integers=@{@"schemaVersion":@1,@"sequence":@(INT32_MAX),@"scannedKeys":@512,@"matchedKeys":@536,@"errorCount":@128};
    for (NSString *key in integers) {
        for (id value in @[@YES,@(-1),@1.5,@(UINT64_MAX),@([integers[key] longLongValue]+1),NSNull.null]) {
            environment=EnvironmentFixture(); environment[key]=value;
            DiscardEnvironment(environment,[key stringByAppendingString:@" invalid integer"]);
        }
        environment=EnvironmentFixture(); [environment removeObjectForKey:key];
        DiscardEnvironment(environment,[key stringByAppendingString:@" missing integer"]);
    }
    for (NSString *key in @[@"mode",@"stage",@"packageType",@"loadedType",@"debugType",@"getupvalueType"]) {
        for (id value in @[@"unsafe\nvalue",@{},NSNull.null]) {
            environment=EnvironmentFixture(); environment[key]=value;
            DiscardEnvironment(environment,[key stringByAppendingString:@" invalid token"]);
        }
    }
    for (NSString *key in @[@"scanTruncated",@"modulesTruncated",@"environmentsTruncated"]) {
        for (id value in @[@0,@1,@"false",NSNull.null]) {
            environment=EnvironmentFixture(); environment[key]=value;
            DiscardEnvironment(environment,[key stringByAppendingString:@" nonboolean"]);
        }
    }
    for (NSString *key in @[@"globals",@"modules",@"environments"]) {
        for (id value in @[@{},NSNull.null,@"text",@[@"malformed-row"],@[@{}]]) {
            environment=EnvironmentFixture(); environment[key]=value;
            DiscardEnvironment(environment,[key stringByAppendingString:@" malformed array"]);
        }
    }
    environment=EnvironmentFixture(); environment[@"limits"]=@[]; DiscardEnvironment(environment,@"invalid limits type");
    for (NSString *key in @[@"scanKeys",@"modules",@"environments",@"upvalues",@"lookupDepth"]) {
        environment=EnvironmentFixture(); environment[@"limits"][key]=@1;
        DiscardEnvironment(environment,[key stringByAppendingString:@" inconsistent configured limit"]);
    }
    NSDictionary *rowFields=@{
        @"globals":@[@"name",@"rawType",@"resolvedType",@"lookup",@"indexType",@"depth"],
        @"modules":@[@"name",@"valueType",@"source",@"gameType",@"upvaluesScanned",@"environmentIndex",@"environmentStatus"],
        @"environments":@[@"index",@"source",@"sameAsGlobal",@"coreType",@"enumType",@"constType",@"biLogicType",@"managerType",@"enumGameType",@"constGameType",@"frameDescriptorType",@"tutorialDescriptorType",@"contractValid"]
    };
    for (NSString *arrayKey in rowFields) {
        NSUInteger index=[arrayKey isEqual:@"environments"]?1:0;
        for (NSString *key in rowFields[arrayKey]) {
            environment=EnvironmentFixture(); environment[arrayKey][index][key]=NSNull.null;
            DiscardEnvironment(environment,[NSString stringWithFormat:@"%@.%@ null known field",arrayKey,key]);
        }
    }
    NSArray *numericRows=@[
        @[@"globals",@0,@"depth",@4],@[@"modules",@0,@"gameType",@(INT32_MAX)],
        @[@"modules",@0,@"upvaluesScanned",@16],@[@"modules",@0,@"environmentIndex",@8],
        @[@"environments",@1,@"index",@8],@[@"environments",@1,@"enumGameType",@(INT32_MAX)],
        @[@"environments",@1,@"constGameType",@(INT32_MAX)]
    ];
    for (NSArray *testCase in numericRows) {
        for (id invalid in @[@YES,@(-1),@1.5,@(UINT64_MAX),@([testCase[3] longLongValue]+1)]) {
            environment=EnvironmentFixture();
            environment[testCase[0]][[testCase[1] unsignedIntegerValue]][testCase[2]]=invalid;
            DiscardEnvironment(environment,@"invalid nested environment integer");
        }
    }
    for (NSString *key in @[@"sameAsGlobal",@"contractValid"]) {
        environment=EnvironmentFixture(); environment[@"environments"][1][key]=@1;
        DiscardEnvironment(environment,@"numeric environment boolean rejected");
    }
    environment=EnvironmentFixture(); environment[@"globals"][0][@"lookup"]=@"function_executed";
    DiscardEnvironment(environment,@"unrecognized lookup result rejected");
    environment=EnvironmentFixture(); environment[@"globals"][0][@"indexType"]=@"unsafe\nvalue";
    DiscardEnvironment(environment,@"control character in nested enum rejected");
}

static NSMutableDictionary *ResolutionFixture(void) {
    return [@{
        @"schemaVersion":@1, @"source":@"package_loaded", @"contractStatus":@"selected",
        @"enumType":@"table", @"constType":@"table", @"descriptorType":@"table",
        @"managerType":@"table", @"managerGetType":@"function", @"frameType":@"table",
        @"managerLookup":@"metatable_table", @"frameCallAttempted":@YES, @"frameCallSucceeded":@YES,
        @"enumGameType":@1003, @"constGameType":@1003, @"descriptorName":@"Game/BiFrameLogic",
        @"descriptorPackage":@"Billiard", @"frameDestroyed":@NO
    } mutableCopy];
}
static NSMutableDictionary *ResolutionSnapshot(id resolution) {
    NSMutableDictionary *raw=Fixture();
    raw[@"status"]=@"unsupported";
    raw[@"reason"]=@"frame_not_observed";
    raw[@"resolution"]=resolution;
    return raw;
}
static void DiscardResolution(id resolution, NSString *label) {
    NSDictionary *safe=Sanitize(ResolutionSnapshot(resolution),label,NULL);
    Check(safe!=nil && [safe[@"status"] isEqual:@"unsupported"],
          [label stringByAppendingString:@": snapshot survives"]);
    Check(safe[@"resolution"]==nil,[label stringByAppendingString:@": malformed optional block removed"]);
    Check(![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,
          [label stringByAppendingString:@": diagnostic never authorizes drawing"]);
    Check(safe && [NSJSONSerialization isValidJSONObject:safe],
          [label stringByAppendingString:@": no untrusted values retained"]);
}
static void TestResolutionRoundtripAndIsolation(void) {
    NSMutableDictionary *resolution=ResolutionFixture();
    NSDictionary *safe=Sanitize(ResolutionSnapshot(resolution),@"resolution evidence",NULL);
    Check([safe[@"resolution"] isEqual:resolution],@"all explicit resolution fields retained");
    Check(![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,
          @"selected contract and successful getter do not authorize unsupported drawing");
    NSData *encoded=safe?[NSJSONSerialization dataWithJSONObject:safe options:0 error:NULL]:nil;
    id parsed=encoded?[NSJSONSerialization JSONObjectWithData:encoded options:0 error:NULL]:nil;
    NSDictionary *roundtrip=Sanitize(parsed,@"resolution JSON roundtrip",NULL);
    Check([roundtrip isEqual:safe],@"resolution survives JSON roundtrip");

    NSMutableDictionary *legacy=Fixture();
    NSDictionary *legacySafe=Sanitize(legacy,@"legacy without resolution",NULL);
    Check(legacySafe[@"resolution"]==nil && [legacySafe[@"prediction"][@"available"] boolValue],
          @"legacy drawing remains compatible without resolution");
    legacy[@"resolution"]=resolution;
    NSDictionary *withResolution=Sanitize(legacy,@"aiming with resolution",NULL);
    Check([withResolution[@"segments"] isEqual:legacySafe[@"segments"]] &&
          [withResolution[@"prediction"] isEqual:legacySafe[@"prediction"]],
          @"resolution leaves independently validated drawing unchanged");
    legacy[@"resolution"]=@{@"source":@"package_loaded"};
    NSDictionary *invalidOptional=Sanitize(legacy,@"aiming invalid optional resolution",NULL);
    Check([invalidOptional isEqual:legacySafe],@"invalid optional resolution leaves legacy drawing unchanged");
    legacy[@"resolution"]=resolution;
    Ball(legacy,0)[@"radiusPixels"]=@(-1);
    Reject(legacy,@"selected resolution cannot bypass invalid ball geometry");

    resolution=ResolutionFixture();
    resolution[@"frameType"]=@"nil";
    [resolution removeObjectForKey:@"frameDestroyed"];
    safe=Sanitize(ResolutionSnapshot(resolution),@"successful getter returned nil",NULL);
    Check([safe[@"resolution"] isEqual:resolution],@"completed protected getter may return nil");
    Check(![safe[@"prediction"][@"available"] boolValue],@"successful nil getter cannot draw");
    for (NSString *key in @[@"enumGameType",@"constGameType",@"descriptorName",@"descriptorPackage"])
        [resolution removeObjectForKey:key];
    safe=Sanitize(ResolutionSnapshot(resolution),@"unobserved resolution fields",NULL);
    Check([safe[@"resolution"] isEqual:resolution],@"optional observed fields remain absent without synthesized values");

    resolution=ResolutionFixture();
    NSMutableString *name=[@"Game/BiFrameLogic" mutableCopy];
    resolution[@"descriptorName"]=name;
    resolution[@"private"]=[NSObject new];
    resolution[@"nested"] = @{@"private": [NSData data]};
    safe=Sanitize(ResolutionSnapshot(resolution),@"resolution unknown values",NULL);
    Check(safe[@"resolution"]!=nil && [NSJSONSerialization isValidJSONObject:safe],
          @"unknown non-JSON resolution objects are not traversed or copied");
    Check(safe[@"resolution"][@"private"]==nil && safe[@"resolution"][@"nested"]==nil,
          @"unknown resolution keys omitted");
    [name setString:@"Changed"];
    resolution[@"source"]=@"none";
    resolution[@"enumGameType"]=@0;
    Check([safe[@"resolution"][@"descriptorName"] isEqual:@"Game/BiFrameLogic"] &&
          [safe[@"resolution"][@"source"] isEqual:@"package_loaded"] &&
          [safe[@"resolution"][@"enumGameType"] integerValue]==1003,
          @"resolution scalars detached from producer mutation");
}
static void TestResolutionMalformedFields(void) {
    for (id invalid in @[NSNull.null,@[],@"text",@1,[NSObject new]])
        DiscardResolution(invalid,@"invalid resolution root");
    NSArray *required=@[@"schemaVersion",@"source",@"contractStatus",@"enumType",@"constType",
                        @"descriptorType",@"managerType",@"managerGetType",@"frameType",
                        @"managerLookup",@"frameCallAttempted",@"frameCallSucceeded"];
    for (NSString *key in required) {
        NSMutableDictionary *resolution=ResolutionFixture();
        [resolution removeObjectForKey:key];
        DiscardResolution(resolution,[key stringByAppendingString:@" missing required field"]);
    }
    for (NSString *key in ResolutionFixture()) {
        NSMutableDictionary *resolution=ResolutionFixture(); resolution[key]=NSNull.null;
        DiscardResolution(resolution,[key stringByAppendingString:@" null known field"]);
    }
    NSDictionary *numeric=@{@"schemaVersion":@1,@"enumGameType":@(INT32_MAX),@"constGameType":@(INT32_MAX)};
    for (NSString *key in numeric) {
        for (id invalid in @[@YES,@(-1),@1.5,@(UINT64_MAX),@([numeric[key] longLongValue]+1),@(NAN),@(INFINITY),@"1003"]) {
            NSMutableDictionary *resolution=ResolutionFixture(); resolution[key]=invalid;
            DiscardResolution(resolution,[key stringByAppendingString:@" invalid integer"]);
        }
    }
    NSMutableDictionary *resolution=ResolutionFixture(); resolution[@"schemaVersion"]=@0;
    DiscardResolution(resolution,@"zero resolution schema version");
    for (NSString *key in @[@"enumGameType",@"constGameType"]) {
        for (NSNumber *boundary in @[@0,@(INT32_MAX)]) {
            resolution=ResolutionFixture(); resolution[key]=boundary;
            NSDictionary *safe=Sanitize(ResolutionSnapshot(resolution),@"observed game type boundary",NULL);
            Check([safe[@"resolution"][key] isEqual:boundary],@"inclusive observed integer boundary retained");
        }
    }
    for (NSString *key in @[@"frameCallAttempted",@"frameCallSucceeded",@"frameDestroyed"]) {
        for (id invalid in @[@0,@1,@"false"]) {
            resolution=ResolutionFixture(); resolution[key]=invalid;
            DiscardResolution(resolution,[key stringByAppendingString:@" nonboolean"]);
        }
    }
    for (NSString *key in @[@"source",@"contractStatus",@"enumType",@"constType",@"descriptorType",
                            @"managerType",@"managerGetType",@"frameType",@"managerLookup",
                            @"descriptorName",@"descriptorPackage"]) {
        for (id invalid in @[@"unsafe\nvalue",@{},@1]) {
            resolution=ResolutionFixture(); resolution[key]=invalid;
            DiscardResolution(resolution,[key stringByAppendingString:@" invalid token"]);
        }
    }
    resolution=ResolutionFixture(); resolution[@"descriptorName"]=@"Game/OtherLogic";
    DiscardResolution(resolution,@"unexpected descriptor name");
    resolution=ResolutionFixture(); resolution[@"descriptorPackage"]=@"Other";
    DiscardResolution(resolution,@"unexpected descriptor package");
    resolution=ResolutionFixture(); resolution[@"frameCallAttempted"]=@NO;
    DiscardResolution(resolution,@"getter success requires attempted call");
    resolution=ResolutionFixture(); resolution[@"descriptorName"]=@"Game/BiTutorialLogic";
    NSDictionary *safe=Sanitize(ResolutionSnapshot(resolution),@"tutorial resolution descriptor",NULL);
    Check([safe[@"resolution"] isEqual:resolution],@"known tutorial descriptor preserved");
}

static void TestProbeEnvironmentJSON(NSString *path) {
    NSError *error=nil;
    NSData *data=[NSData dataWithContentsOfFile:path options:0 error:&error];
    Check(data!=nil && error==nil,@"Lua-produced environment fixture can be read");
    id raw=data?[NSJSONSerialization JSONObjectWithData:data options:0 error:&error]:nil;
    Check([raw isKindOfClass:NSDictionary.class] && error==nil,@"Lua-produced fixture is a JSON snapshot");
    NSDictionary *safe=Sanitize(raw,@"actual Lua producer environment contract",NULL);
    Check([safe[@"status"] isEqual:@"unsupported"] && [safe[@"reason"] isEqual:@"billiards_contract_mismatch"],
          @"Lua producer retains unsupported contract failure");
    NSDictionary *environment=safe[@"environment"];
    Check(environment!=nil,@"native sanitizer retains actual Lua-produced environment");
    NSArray *environments=environment[@"environments"];
    Check(environments.count==2,@"Lua producer reports global and distinct loaded-module environment");
    NSDictionary *global=environments.count>0?environments[0]:nil;
    NSDictionary *candidate=environments.count>1?environments[1]:nil;
    Check([global[@"sameAsGlobal"] boolValue] && ![global[@"contractValid"] boolValue] &&
          [global[@"enumType"] isEqual:@"nil"] && [global[@"constType"] isEqual:@"nil"],
          @"actual producer global contract remains unresolved");
    Check(![candidate[@"sameAsGlobal"] boolValue] && [candidate[@"contractValid"] boolValue] &&
          [candidate[@"index"] integerValue]==2,
          @"actual producer distinct candidate evidence preserved");
    BOOL foundInit=NO;
    for (NSDictionary *module in environment[@"modules"])
        if ([module[@"name"] isEqual:@"Billiard/Lua/Const/Init"] &&
            [module[@"environmentIndex"] integerValue]==2 && [module[@"environmentStatus"] isEqual:@"found"])
            foundInit=YES;
    Check(foundInit,@"actual producer module references observed environment two");
    Check(![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,
          @"actual producer alternate environment never authorizes drawing");
    Check(safe && [NSJSONSerialization isValidJSONObject:safe],@"actual producer sanitized snapshot is JSON-compatible");
}

static void TestProbeResolutionJSON(NSString *path) {
    NSError *error=nil;
    NSData *data=[NSData dataWithContentsOfFile:path options:0 error:&error];
    Check(data!=nil && error==nil,@"Lua-produced loaded-module fixture can be read");
    id raw=data?[NSJSONSerialization JSONObjectWithData:data options:0 error:&error]:nil;
    BOOL isSnapshot=[raw isKindOfClass:NSDictionary.class] && error==nil;
    Check(isSnapshot,@"loaded-module fixture is a JSON snapshot");
    if (!isSnapshot) return;
    NSDictionary *safe=Sanitize(raw,@"actual Lua producer resolution contract",NULL);
    NSDictionary *resolution=safe[@"resolution"];
    Check(resolution!=nil && [resolution isEqual:raw[@"resolution"]],
          @"native sanitizer retains exact Lua-produced resolution evidence");
    Check([resolution[@"source"] isEqual:@"package_loaded"] && [resolution[@"contractStatus"] isEqual:@"selected"],
          @"actual producer selected already-loaded module contract");
    Check([resolution[@"enumGameType"] integerValue]==1003 && [resolution[@"constGameType"] integerValue]==1003 &&
          [resolution[@"descriptorName"] isEqual:@"Game/BiFrameLogic"] && [resolution[@"descriptorPackage"] isEqual:@"Billiard"],
          @"actual producer contract values survive native sanitizer");
    Check([resolution[@"frameCallAttempted"] boolValue] && [resolution[@"frameCallSucceeded"] boolValue],
          @"actual producer reports completed frame getter");
    Check([safe[@"gates"] isEqual:raw[@"gates"]],@"actual producer gates remain independently preserved");
    Check([safe[@"status"] isEqual:raw[@"status"]] && safe && [NSJSONSerialization isValidJSONObject:safe],
          @"actual producer resolution keeps snapshot status and JSON compatibility");
    NSMutableDictionary *blocked=[raw mutableCopy];
    blocked[@"status"]=@"unsupported";
    blocked[@"reason"]=@"test_downstream_guard";
    NSDictionary *blockedSafe=Sanitize(blocked,@"actual resolution cannot override downstream guard",NULL);
    Check([blockedSafe[@"resolution"] isEqual:resolution] &&
          ![blockedSafe[@"prediction"][@"available"] boolValue] && [blockedSafe[@"segments"] count]==0,
          @"real Lua resolution evidence cannot authorize unsupported drawing");
}

static void TestProbeChainJSON(NSString *path) {
    NSError *error=nil;
    NSData *data=[NSData dataWithContentsOfFile:path options:0 error:&error];
    Check(data!=nil && error==nil,@"Lua-produced chain fixture can be read");
    id raw=data?[NSJSONSerialization JSONObjectWithData:data options:0 error:&error]:nil;
    BOOL isSnapshot=[raw isKindOfClass:NSDictionary.class] && error==nil;
    Check(isSnapshot,@"Lua-produced chain fixture is a JSON snapshot");
    if (!isSnapshot) return;
    NSDictionary *safe=Sanitize(raw,@"actual Lua producer three-ball chain",NULL);
    Check(safe!=nil && [safe[@"prediction"][@"available"] boolValue],@"Lua-produced chain is drawable after native guards");
    Check([safe[@"prediction"] isEqual:raw[@"prediction"]],@"actual chain producer counters survive native sanitizer");
    Check([safe[@"segments"] isEqual:raw[@"segments"]],@"actual chain producer identities and geometry survive native sanitizer");
    BOOL firstContact=NO, secondContact=NO, thirdPath=NO;
    for (NSDictionary *segment in safe[@"segments"]) {
        NSInteger tag=[segment[@"ballTag"] integerValue], target=[segment[@"hitBallTag"] integerValue];
        BOOL ball=[segment[@"terminal"] isEqual:@"ball"];
        if (tag==1 && target==2 && ball) firstContact=YES;
        if (tag==2 && target==3 && ball) secondContact=YES;
        if (tag==3) thirdPath=YES;
    }
    Check(firstContact && secondContact && thirdPath,@"actual producer propagates cue to second and third balls");
    Check(safe && [NSJSONSerialization isValidJSONObject:safe],@"actual chain output remains JSON-compatible");
    // Keep the exact V3.18 build regression as a rejected input. Correcting the
    // mock's pocket must never weaken the native viewport boundary.
    NSMutableDictionary *offscreen=[NSJSONSerialization JSONObjectWithData:data
        options:NSJSONReadingMutableContainers error:NULL];
    NSMutableArray *offscreenSegments=offscreen[@"segments"];
    Check(offscreenSegments.count==5,@"finite chain retains three contact paths and two rest paths");
    NSMutableDictionary *pocketSegment=nil;
    NSUInteger pocketSegments=0;
    for (NSMutableDictionary *segment in offscreenSegments) {
        if ([segment[@"ballTag"] integerValue]==3 && [segment[@"terminal"] isEqual:@"pocket"]) {
            pocketSegment=segment;
            pocketSegments++;
        }
    }
    Check(pocketSegments==1,@"viewport regression selects the third ball's pocket endpoint by identity");
    if (pocketSegments==1) {
        NSMutableDictionary *end=pocketSegment[@"to"];
        Check(fabs([end[@"y"] doubleValue]-1760.0)<0.00001,
              @"unmodified pocket endpoint remains within the 1920px viewport");
        end[@"y"]=@2160;
        Reject(offscreen,@"V3.18 chain endpoint beyond 1920px viewport stays rejected");
        offscreen[@"status"]=@"moving";
        Reject(offscreen,@"offscreen chain cannot bypass validation while moving");
    }
    NSMutableDictionary *blocked=[raw mutableCopy]; blocked[@"status"]=@"moving";
    NSDictionary *blockedSafe=Sanitize(blocked,@"actual chain producer moving guard",NULL);
    Check(blockedSafe!=nil && ![blockedSafe[@"prediction"][@"available"] boolValue] &&
          [blockedSafe[@"segments"] count]==0,@"actual chain cannot override moving guard");
}

static void TestCaptureReportBounds(void) {
    NSMutableArray *samples=[NSMutableArray array];
    NSString *payload=[@"x" stringByPaddingToLength:1024 withString:@"x" startingAtIndex:0];
    for (NSUInteger index=0; index<8; index++)
        [samples addObject:@{@"index":@(index),@"payload":payload}];
    NSMutableDictionary *report=[@{@"format":@"SDKtools.BilliardsLiveCapture",@"samples":samples,
        @"counts":[@{@"omittedOlderSamples":@7,@"attempts":@321} mutableCopy],
        @"lastSnapshot":ChainFixture()} mutableCopy];
    NSData *originalBytes=[NSJSONSerialization dataWithJSONObject:report options:0 error:NULL];
    NSDictionary *original=[NSJSONSerialization JSONObjectWithData:originalBytes options:0 error:NULL];
    NSError *error=nil;
    NSData *all=STBilliardsEncodeCapture(report,4u*1024u*1024u,&error);
    NSDictionary *decoded=all?[NSJSONSerialization JSONObjectWithData:all options:0 error:NULL]:nil;
    Check(all!=nil && error==nil && [decoded[@"samples"] count]==8,@"capture within budget retains all samples");
    Check([decoded[@"counts"][@"exportTrimmedSamples"] integerValue]==0 &&
          [decoded[@"counts"][@"omittedOlderSamples"] integerValue]==7,@"untrimmed capture preserves omission evidence");
    Check([decoded[@"lastSnapshot"] isEqual:report[@"lastSnapshot"]],@"untrimmed capture preserves last snapshot");
    if (all.length>1456) {
        NSUInteger budget=all.length-1200;
        NSData *bounded=STBilliardsEncodeCapture(report,budget,&error);
        NSDictionary *trimmed=bounded?[NSJSONSerialization JSONObjectWithData:bounded options:0 error:NULL]:nil;
        NSArray *kept=trimmed[@"samples"];
        NSUInteger removed=8-kept.count;
        Check(bounded!=nil && error==nil && bounded.length<=budget && kept.count>0 && kept.count<8,
              @"expanded capture trims enough oldest samples to fit its byte budget");
        BOOL suffix=kept.count>0;
        for (NSUInteger index=0; index<kept.count; index++)
            if ([kept[index][@"index"] unsignedIntegerValue]!=removed+index) suffix=NO;
        Check(suffix,@"bounded capture preserves newest chronological sample suffix");
        Check([trimmed[@"counts"][@"exportTrimmedSamples"] unsignedIntegerValue]==removed &&
              [trimmed[@"counts"][@"omittedOlderSamples"] unsignedIntegerValue]==7+removed &&
              [trimmed[@"counts"][@"attempts"] integerValue]==321,@"trimmed capture adjusts omissions and retains other counters");
        Check([trimmed[@"lastSnapshot"] isEqual:report[@"lastSnapshot"]],@"trimming never changes latest snapshot");
    } else Check(NO,@"capture fixture is large enough to test trimming");
    Check([report isEqual:original],@"capture encoder leaves caller dictionary and arrays unchanged");
    NSMutableDictionary *oversized=[report mutableCopy]; oversized[@"samples"]=@[];
    oversized[@"lastSnapshot"]=@{@"payload":payload};
    NSData *failed=STBilliardsEncodeCapture(oversized,256,&error);
    Check(failed==nil && error!=nil,@"oversized fixed capture fields produce explicit failure");
    NSMutableDictionary *invalid=[report mutableCopy]; invalid[@"invalid"]=[NSObject new];
    failed=STBilliardsEncodeCapture(invalid,4u*1024u*1024u,&error);
    Check(failed==nil && error!=nil,@"capture refuses non-JSON payloads");
}

static void TestProbeFiniteJSON(NSString *path, NSString *expectedStatus) {
    NSError *error=nil;
    NSData *data=[NSData dataWithContentsOfFile:path options:0 error:&error];
    id raw=data?[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error]:nil;
    BOOL valid=[raw isKindOfClass:NSDictionary.class] && error==nil;
    Check(valid,@"finite Lua fixture can be decoded");
    if (!valid) return;
    NSDictionary *safe=Sanitize(raw,@"actual finite Lua producer",NULL);
    Check(safe!=nil && [safe[@"status"] isEqual:expectedStatus],@"actual finite status survives native boundary");
    Check([safe[@"physics"] isEqual:raw[@"physics"]],@"actual finite physics evidence survives native boundary");
    Check([safe[@"prediction"] isEqual:raw[@"prediction"]],@"actual finite prediction metadata survives native boundary");
    if ([expectedStatus isEqual:@"aiming"]) {
        Check([safe[@"prediction"][@"complete"] boolValue] && [safe[@"prediction"][@"available"] boolValue] &&
              [safe[@"prediction"][@"finalStates"] count]==1 &&
              [safe[@"prediction"][@"finalStates"][0][@"outcome"] isEqual:@"rest"],
              @"actual finite single-ball simulation ends at rest");
        Check([safe[@"balls"] isEqual:raw[@"balls"]] && [safe[@"segments"] isEqual:raw[@"segments"]],
              @"actual finite observed dynamics and timed line preserved");
        raw[@"prediction"][@"finalStates"][0][@"screen"][@"y"]=@([raw[@"screen"][@"height"] doubleValue]+1);
        Reject(raw,@"actual finite producer cannot bypass final viewport guard");
    } else {
        Check(![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,
              @"actual unavailable finite sample cannot draw");
        if ([expectedStatus isEqual:@"not_ready"])
            Check([safe[@"observedDynamics"][@"balls"] isEqual:raw[@"balls"]],
                  @"actual not-ready Lua sample retains measured dynamics without guides");
    }
}
#ifdef STBL_TEST_RUNTIME_HELPERS
static void TestRuntimeObservedRestHelpers(void) {
    NSMutableDictionary *raw=FiniteFixture(); raw[@"status"]=@"not_ready";
    NSDictionary *safe=Sanitize(raw,@"rest observation helper fixture",NULL);
    Check(STBLShotObservedRest(safe),@"runtime accepts all measured resting active balls");
    Check(STBLShotSameContext(safe,safe),@"runtime preserves matching observed context");
    Check(STBLShotIdentityMatches(safe[@"balls"],safe[@"balls"]),@"complete observed ball identity set matches");
    NSMutableArray *identities=[safe[@"balls"] mutableCopy];
    [identities exchangeObjectAtIndex:0 withObjectAtIndex:2];
    Check(STBLShotIdentityMatches(safe[@"balls"],identities),@"identity matcher accepts reordered observations");
    [identities removeLastObject];
    Check(!STBLShotIdentityMatches(safe[@"balls"],identities),@"missing observed ball cannot stand for a potted ball");
    identities=[safe[@"balls"] mutableCopy];
    identities[1]=@{@"tag":@4,@"number":@3};
    Check(!STBLShotIdentityMatches(safe[@"balls"],identities),@"substituted ball cannot close original shot observation");
    identities=[safe[@"balls"] mutableCopy];identities[1]=@{@"tag":@2,@"number":@2};
    Check(!STBLShotIdentityMatches(safe[@"balls"],identities),@"changed ball number cannot match original shot");
    Check(STBLShotKnownNonlocal(@{@"physics":@{@"localTurn":@NO}}) &&
          !STBLShotKnownLocal(@{@"physics":@{@"localTurn":@NO}}),@"observed opposing turn cannot authorize shot completion");
    Check(STBLShotKnownLocal(@{@"physics":@{@"localTurn":@YES}}) &&
          !STBLShotKnownNonlocal(@{@"physics":@{@"localTurn":@YES}}),@"explicit local turn remains distinguishable");
    Check(!STBLShotKnownLocal(@{}) && !STBLShotKnownNonlocal(@{}) &&
          !STBLShotKnownLocal(@{@"physics":@{@"localTurn":@1}}),@"missing or numeric turn flag remains unknown");
    NSMutableDictionary *different=[safe mutableCopy];different[@"cameraInstanceId"]=@102;
    Check(!STBLShotSameContext(safe,different),@"runtime rejects changed camera context");
    Ball(raw,1)[@"angularVelocity"]=@{@"x":@0.21,@"y":@0,@"z":@0};
    safe=Sanitize(raw,@"spinning observed ball",NULL);
    Check(!STBLShotObservedRest(safe),@"linear rest cannot conceal residual spin");
    raw=FiniteFixture();raw[@"status"]=@"not_ready";[Ball(raw,1) removeObjectForKey:@"angularVelocity"];
    safe=Sanitize(raw,@"missing measured spin",NULL);
    Check(!STBLShotObservedRest(safe),@"runtime refuses rest without every angular measurement");
    raw=FiniteFixture();raw[@"status"]=@"not_ready";Ball(raw,1)[@"speed"]=@0.003;
    safe=Sanitize(raw,@"slow active ball still moving",NULL);
    Check(!STBLShotObservedRest(safe),@"runtime waits for every active linear speed");
    raw=FiniteFixture();raw[@"status"]=@"not_ready";raw[@"prediction"][@"finalStates"]=@[];
    raw[@"prediction"][@"affectedBallCount"]=@0;
    for (NSMutableDictionary *ball in raw[@"balls"]) ball[@"potted"]=@YES;
    safe=Sanitize(raw,@"no observed active ball",NULL);
    Check(!STBLShotObservedRest(safe),@"empty active set cannot become a fabricated rest observation");
}
#endif

int main(int argc, const char *argv[]) { @autoreleasepool {
    TestValidAndDetachedOutput();
    TestBallAndGeometryRejections();
    TestNondrawableStates();
    TestUntrustedTypes();
    TestChainRoundtripAndBounds();
    TestChainMalformedSchema();
    TestChainNondrawableStates();
    TestCaptureReportBounds();
    TestFinitePredictionSchema();
    TestPhysicsEvidenceAndObservedDynamics();
#ifdef STBL_TEST_RUNTIME_HELPERS
    TestRuntimeObservedRestHelpers();
#endif
    TestSignedIdentityBoundaries();
    TestNondrawableOverflowIdentities();
    TestEnvironmentRoundtripAndIsolation();
    TestEnvironmentBoundsAndNames();
    TestEnvironmentMalformedFields();
    TestResolutionRoundtripAndIsolation();
    TestResolutionMalformedFields();
    if (argc>=2) TestProbeEnvironmentJSON([NSString stringWithUTF8String:argv[1]]);
    if (argc>=3) TestProbeResolutionJSON([NSString stringWithUTF8String:argv[2]]);
    if (argc>=4) TestProbeChainJSON([NSString stringWithUTF8String:argv[3]]);
    if (argc>=5) TestProbeFiniteJSON([NSString stringWithUTF8String:argv[4]],@"aiming");
    if (argc>=6) TestProbeFiniteJSON([NSString stringWithUTF8String:argv[5]],@"moving");
    if (argc>=7) TestProbeFiniteJSON([NSString stringWithUTF8String:argv[6]],@"not_ready");
    printf("Billiards live snapshot: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
} }

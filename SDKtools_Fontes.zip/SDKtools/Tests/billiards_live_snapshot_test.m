#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STBilliardsLiveSnapshot.h"
#include <math.h>
#include <stdio.h>

static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *message) {
    checks++;
    if (!condition) {
        failures++;
        fprintf(stderr, "FAIL %s\n", message.UTF8String);
    }
}

static NSMutableDictionary *Fixture(void) {
    NSDictionary *raw=@{
        @"format":@"SDKtools.BilliardsLive", @"schemaVersion":@1, @"status":@"aiming",
        @"resourceGameId":@20, @"gameType":@1003, @"sessionId":@700, @"frameNumber":@42,
        @"cameraInstanceId":@(-101),
        @"scene":@{@"handle":@41, @"name":@"BilliardInGame"},
        @"screen":@{@"width":@1170, @"height":@2532},
        @"balls":@[
            @{@"tag":@1, @"number":@0, @"active":@YES, @"potted":@NO,
              @"world":@{@"x":@0, @"y":@0, @"z":@0},
              @"screen":@{@"x":@100, @"y":@200, @"depth":@2},
              @"radiusPixels":@14, @"speed":@0},
            @{@"tag":@2, @"number":@1, @"active":@YES, @"potted":@NO,
              @"world":@{@"x":@1, @"y":@0, @"z":@0},
              @"screen":@{@"x":@200, @"y":@200, @"depth":@2},
              @"radiusPixels":@14, @"speed":@0}
        ],
        @"cue":@{@"world":@{@"x":@0, @"y":@0, @"z":@0},
                 @"direction":@{@"x":@1, @"y":@0, @"z":@0}},
        @"segments":@[
            @{@"kind":@"cue", @"from":@{@"x":@100, @"y":@200, @"depth":@2},
              @"to":@{@"x":@172, @"y":@200, @"depth":@2},
              @"worldFrom":@{@"x":@0, @"y":@0, @"z":@0},
              @"worldTo":@{@"x":@0.72, @"y":@0, @"z":@0}}
        ],
        @"prediction":@{@"available":@YES, @"reason":@"ready", @"model":@"geometric", @"maxBounces":@3}
    };
    NSData *json=[NSJSONSerialization dataWithJSONObject:raw options:0 error:NULL];
    return [NSJSONSerialization JSONObjectWithData:json options:NSJSONReadingMutableContainers error:NULL];
}

static NSMutableDictionary *Ball(NSMutableDictionary *raw, NSUInteger index) {
    return raw[@"balls"][index];
}
static NSMutableDictionary *Segment(NSMutableDictionary *raw) {
    return raw[@"segments"][0];
}
static NSDictionary *Sanitize(id raw, NSString *label, NSString **failure) {
    @try {
        NSDictionary *result=STBilliardsSanitizeSnapshot(raw, failure);
        Check(YES, [label stringByAppendingString:@": no exception"]);
        return result;
    } @catch (NSException *exception) {
        Check(NO, [NSString stringWithFormat:@"%@: raised %@",label,exception.name]);
        return nil;
    }
}
static void Reject(id raw, NSString *label) {
    NSString *failure=nil;
    NSDictionary *result=Sanitize(raw,label,&failure);
    Check(result==nil,label);
    Check(failure.length>0,[label stringByAppendingString:@": bounded failure reason"]);
}

static void TestValidAndDetachedOutput(void) {
    NSMutableDictionary *raw=Fixture();
    NSDictionary *safe=Sanitize(raw,@"valid aim",NULL);
    Check(safe!=nil,@"valid aim accepted");
    Check([safe[@"status"] isEqual:@"aiming"],@"aim status retained");
    Check([safe[@"prediction"][@"available"] boolValue],@"valid prediction available");
    Check([safe[@"balls"] count]==2 && [safe[@"segments"] count]==1,@"balls and segment retained");
    Check([safe[@"cameraInstanceId"] integerValue]==-101,@"negative Unity camera instance ID valid");
    Check([NSJSONSerialization isValidJSONObject:safe],@"accepted output is JSON compatible");

    raw=Fixture();
    raw[@"extra"]=[NSObject new];
    raw[@"screen"][@"token"]=@"private-value";
    raw[@"scene"][@"private"]=@"private-value";
    raw[@"cue"][@"private"]=@"private-value";
    raw[@"prediction"][@"private"]=@"private-value";
    Ball(raw,0)[@"private"]=[NSData data];
    Ball(raw,0)[@"screen"][@"private"]=@"private-value";
    Segment(raw)[@"private"]=[NSObject new];
    safe=Sanitize(raw,@"untrusted extras",NULL);
    Check(safe!=nil && [NSJSONSerialization isValidJSONObject:safe],@"non-JSON extras discarded");
    NSData *encoded=safe?[NSJSONSerialization dataWithJSONObject:safe options:0 error:NULL]:nil;
    NSString *text=encoded?[[NSString alloc] initWithData:encoded encoding:NSUTF8StringEncoding]:@"";
    Check(![text containsString:@"private"] && safe[@"extra"]==nil,@"extra fields omitted at all levels");
    Ball(raw,0)[@"screen"][@"x"]=@999;
    Segment(raw)[@"to"][@"x"]=@999;
    raw[@"screen"][@"width"]=@16;
    Check([safe[@"balls"][0][@"screen"][@"x"] integerValue]==100,@"ball coordinates detached");
    Check([safe[@"segments"][0][@"to"][@"x"] integerValue]==172,@"segment coordinates detached");
    Check([safe[@"screen"][@"width"] integerValue]==1170,@"screen dimensions detached");

    raw=Fixture();
    NSMutableString *status=[@"aiming" mutableCopy], *reason=[@"ready" mutableCopy];
    NSMutableString *scene=[@"BilliardInGame" mutableCopy], *kind=[@"cue" mutableCopy];
    raw[@"status"]=status; raw[@"prediction"][@"reason"]=reason;
    raw[@"scene"][@"name"]=scene; Segment(raw)[@"kind"]=kind;
    safe=Sanitize(raw,@"mutable incoming strings",NULL);
    [status setString:@"error"]; [reason setString:@"changed"];
    [scene setString:@"LoadingBilliard"]; [kind setString:@"changed"];
    Check([safe[@"status"] isEqual:@"aiming"],@"status string detached");
    Check([safe[@"reason"] isEqual:@"ready"] && [safe[@"prediction"][@"reason"] isEqual:@"ready"],@"reason strings detached");
    Check([safe[@"scene"][@"name"] isEqual:@"BilliardInGame"],@"scene name detached");
    Check([safe[@"segments"][0][@"kind"] isEqual:@"cue"],@"segment kind detached");
}

static void TestBallAndGeometryRejections(void) {
    NSMutableDictionary *raw=Fixture();
    Ball(raw,1)[@"tag"]=@1; Ball(raw,1)[@"number"]=@0;
    Reject(raw,@"duplicate ball identity");
    raw=Fixture(); Ball(raw,1)[@"number"]=@2; Reject(raw,@"mismatched ball number");
    raw=Fixture(); Ball(raw,0)[@"tag"]=@0; Reject(raw,@"invalid ball tag");
    raw=Fixture(); raw[@"scene"][@"name"]=@"LoadingBilliard";
    NSString *failure=nil;
    Check(Sanitize(raw,@"loading scene",&failure)==nil,@"loading is not a table");
    Check([failure isEqual:@"scene_not_billiards"],@"wrong scene reason is explicit");
    raw=Fixture(); raw[@"scene"][@"name"]=@"BilliardTutorial";
    Check(Sanitize(raw,@"tutorial scene",NULL)!=nil,@"evidenced tutorial scene accepted");

    NSArray *badValues=@[@(NAN), @(INFINITY), @(-INFINITY), @YES, @"100", NSNull.null, @{}, @[]];
    for (id value in badValues) {
        raw=Fixture(); Ball(raw,0)[@"screen"][@"x"]=value; Reject(raw,@"invalid projected scalar");
        raw=Fixture(); Ball(raw,0)[@"world"][@"z"]=value; Reject(raw,@"invalid world scalar");
    }
    raw=Fixture(); Ball(raw,0)[@"screen"][@"x"]=@1171; Reject(raw,@"ball offscreen");
    raw=Fixture(); Ball(raw,0)[@"screen"][@"depth"]=@0; Reject(raw,@"ball on camera plane");
    raw=Fixture(); Segment(raw)[@"to"][@"depth"]=@(-1); Reject(raw,@"segment behind camera");
    raw=Fixture(); Segment(raw)[@"worldTo"][@"x"]=@(NAN); Reject(raw,@"nonfinite segment endpoint");
    raw=Fixture(); Ball(raw,0)[@"radiusPixels"]=@0; Reject(raw,@"zero projected radius");
    raw=Fixture(); Ball(raw,0)[@"speed"]=@(-1); Reject(raw,@"negative speed");
    raw=Fixture(); raw[@"segments"]=@[]; Reject(raw,@"available prediction without segments");
    raw=Fixture(); raw[@"cue"]=NSNull.null; Reject(raw,@"available prediction without cue");
}

static void TestNondrawableStates(void) {
    NSMutableDictionary *raw=Fixture(); raw[@"status"]=@"not_ready";
    raw[@"gates"]=@{@"hasCore":@YES,@"hasCamera":@NO,@"hasFrame":@1,
                    @"hasEnum":@"true",@"unknownExtra":@YES};
    NSDictionary *safe=Sanitize(raw,@"partial capability gates",NULL);
    Check([safe[@"gates"] count]==2 && [safe[@"gates"][@"hasCore"] boolValue] &&
          [safe[@"gates"][@"hasCamera"] isEqual:@NO],@"only allowlisted literal boolean gates preserved");
    Check(safe[@"gates"][@"hasFrame"]==nil && safe[@"gates"][@"hasEnum"]==nil &&
          safe[@"gates"][@"unknownExtra"]==nil,@"nonboolean and unknown gates dropped");
    raw=Fixture(); raw[@"status"]=@"moving";
    safe=Sanitize(raw,@"explicit moving",NULL);
    Check(safe!=nil && [safe[@"segments"] count]==0,@"moving strips producer segments");
    Check(![safe[@"prediction"][@"available"] boolValue],@"moving disables prediction");
    raw=Fixture(); Ball(raw,1)[@"speed"]=@0.003;
    safe=Sanitize(raw,@"observed speed",NULL);
    Check([safe[@"status"] isEqual:@"moving"],@"observed motion overrides aiming claim");
    Check([safe[@"segments"] count]==0 && [safe[@"prediction"][@"reason"] isEqual:@"balls_moving"],@"motion clears lines and explains why");

    for (NSUInteger variant=0; variant<2; variant++) {
        raw=Fixture(); NSMutableDictionary *ball=Ball(raw,1);
        ball[@"active"]=variant?@YES:@NO; ball[@"potted"]=variant?@YES:@NO;
        ball[@"world"]=NSNull.null; ball[@"screen"]=NSNull.null;
        ball[@"speed"]=NSNull.null; ball[@"radiusPixels"]=NSNull.null;
        safe=Sanitize(raw,@"inactive or potted null projection",NULL);
        Check(safe!=nil && [safe[@"prediction"][@"available"] boolValue],@"nonplaying ball needs no projection");
        Check(safe[@"balls"][1][@"world"]==nil && safe[@"balls"][1][@"screen"]==nil,@"null projection omitted");
    }
    raw=Fixture(); Ball(raw,0)[@"potted"]=@YES; Ball(raw,0)[@"screen"]=NSNull.null;
    safe=Sanitize(raw,@"cue potted",NULL);
    Check(safe!=nil && ![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,@"potted cue suppresses all lines");

    for (NSString *status in @[@"not_ready",@"wrong_scene",@"unsupported",@"error",@"stopped"]) {
        raw=Fixture(); raw[@"status"]=status;
        raw[@"prediction"][@"reason"]=@"camera_unavailable";
        [raw removeObjectForKey:@"cameraInstanceId"];
        raw[@"cue"]=@"invalid but nondrawable";
        safe=Sanitize(raw,status,NULL);
        Check(safe!=nil && [safe[@"status"] isEqual:status],@"nondrawable status retained");
        Check([safe[@"reason"] isEqual:@"camera_unavailable"] && [safe[@"prediction"][@"reason"] isEqual:@"camera_unavailable"],@"nested failure reason retained");
        Check([safe[@"segments"] count]==0 && ![safe[@"prediction"][@"available"] boolValue],@"failure state cannot carry drawable lines");
        Check([safe[@"sessionId"] integerValue]==700 && [safe[@"scene"][@"handle"] integerValue]==41,@"partial context retained");
        Check([safe[@"balls"] count]==2 && safe[@"balls"][0][@"screen"]==nil,@"partial report keeps identities only");
    }
}

static void TestUntrustedTypes(void) {
    Reject(nil,@"nil root"); Reject(NSNull.null,@"null root"); Reject(@[],@"array root");
    NSMutableDictionary *raw=Fixture(); [raw removeObjectForKey:@"status"]; Reject(raw,@"missing status");
    raw=Fixture(); [raw[@"scene"] removeObjectForKey:@"name"]; Reject(raw,@"missing scene name");
    raw=Fixture(); [Segment(raw) removeObjectForKey:@"kind"]; Reject(raw,@"missing segment kind");
    for (NSString *key in @[@"schemaVersion",@"resourceGameId",@"gameType",@"sessionId",@"frameNumber",@"cameraInstanceId"]) {
        raw=Fixture(); raw[key]=@YES; Reject(raw,@"boolean cannot impersonate numeric identity");
        raw=Fixture(); raw[key]=@1.5; Reject(raw,@"fractional identity rejected");
        raw=Fixture(); raw[key]=@(UINT64_MAX); Reject(raw,@"overflow identity rejected");
    }
    raw=Fixture(); Ball(raw,0)[@"active"]=@1; Reject(raw,@"numeric one is not active boolean");
    raw=Fixture(); Ball(raw,0)[@"potted"]=@0; Reject(raw,@"numeric zero is not potted boolean");
    raw=Fixture(); raw[@"prediction"][@"available"]=@1; Reject(raw,@"numeric availability rejected");
    for (id invalid in @[NSNull.null,@"text",@7,@[]]) {
        for (NSString *key in @[@"scene",@"screen",@"prediction",@"cue"]) {
            raw=Fixture(); raw[key]=invalid; Reject(raw,@"invalid nested dictionary type");
        }
        raw=Fixture(); Ball(raw,0)[@"world"]=invalid; Reject(raw,@"invalid ball world type");
        raw=Fixture(); Ball(raw,0)[@"screen"]=invalid; Reject(raw,@"invalid ball screen type");
    }
    raw=Fixture(); raw[@"balls"]=@[@"not-a-ball"]; Reject(raw,@"invalid ball element");
    raw=Fixture(); raw[@"segments"]=@[@42]; Reject(raw,@"invalid segment element");
    raw=Fixture(); raw[@"balls"]=@{}; Reject(raw,@"dictionary instead of ball array");
    raw=Fixture(); raw[@"segments"]=NSNull.null; Reject(raw,@"null segment array");
    raw=Fixture(); raw[@"prediction"][@"reason"]=@"unsafe\nvalue";
    NSDictionary *safe=Sanitize(raw,@"reason control character",NULL);
    Check([safe[@"prediction"][@"reason"] isEqual:@"unavailable"],@"diagnostic reason excludes control characters");
    Check([STBilliardsDiagnosticToken([@"a" stringByPaddingToLength:97 withString:@"a" startingAtIndex:0]) isEqual:@"unavailable"],@"diagnostic token length bounded");
}

int main(void) { @autoreleasepool {
    TestValidAndDetachedOutput();
    TestBallAndGeometryRejections();
    TestNondrawableStates();
    TestUntrustedTypes();
    printf("Billiards live snapshot: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
} }

"""Portable contracts of the native-only covered report; does not execute a game."""
from pathlib import Path
import re
import unittest

ROOT=Path(__file__).resolve().parents[1]


class CoveredReportContractTests(unittest.TestCase):
    def test_public_report_api_is_separate_from_capture(self):
        header=(ROOT/'Sources/SDKtools/STRecorder.h').read_text(encoding='utf-8')
        self.assertIn('writeCoveredAttemptReportWithError:',header)
        source=(ROOT/'Sources/SDKtools/STRecorder.m').read_text(encoding='utf-8')
        method=source.split('- (NSURL *)writeCoveredAttemptReportWithError:',1)[1].split('- (NSURL *)writeReportWithError:',1)[0]
        # Strip prose so the no-call check verifies implementation rather than comments.
        implementation=re.sub(r'//[^\n]*','',method)
        self.assertIn('NSThread.isMainThread',implementation)
        self.assertIn('STCCReportData(self.coveredAttemptPending,self.coveredAttemptContextLost,',implementation)
        self.assertIn('self.coveredAttemptDiagnostic,self.coveredAttemptEvents',implementation)
        self.assertIn('STCCReportWriteData(data,documents,error)',implementation)
        self.assertNotRegex(implementation,r'pause|stop|reset|invalidate|clear|WebProbe|WebKit|evaluateJavaScript|writeReportWithError|snapshotReport|startedAt|isRecording|performCoveredAttempt')
        self.assertNotRegex(implementation,r'self\.covered\w+\s*=')

    def test_closed_serializer_reuses_original_sanitizer_and_last_24(self):
        helper=(ROOT/'Sources/SDKtools/STCoveredCardReport.inc').read_text(encoding='utf-8')
        self.assertIn('#import "STAutoplaySanitizer.inc"',helper)
        self.assertIn('STWPSanitizeCovered(diagnostic)',helper)
        self.assertIn('STWPSanitizeCovered(events[i])',helper)
        self.assertIn('first=count>24?count-24:0',helper)
        self.assertIn('@"SDKtools.CoveredCardReport.v1"',helper)
        self.assertIn('@"toolVersion":@"4.0.0"',helper)
        self.assertIn('@"frameworkBuild":@"75"',helper)
        self.assertIn('data.length>=STCCReportMaximumBytes',helper)
        self.assertNotRegex(helper,r'WKWebView|evaluateJavaScript|STWebProbe|\.socket|URLSession|NSURLConnection|performCoveredAttempt')

    def test_last_observation_is_stored_closed_state_not_a_fresh_scan(self):
        source=(ROOT/'Sources/SDKtools/STRecorder.m').read_text(encoding='utf-8')
        method=source.split('- (NSURL *)writeCoveredAttemptReportWithError:',1)[1].split('- (NSURL *)writeReportWithError:',1)[0]
        self.assertIn('self.autoplayReadingDiagnostic',method)
        helper=(ROOT/'Sources/SDKtools/STCoveredCardReport.inc').read_text(encoding='utf-8')
        self.assertIn('@"lastObservation":STWPSanitizeAutoplayReading(reading)',helper)
        sanitizer=(ROOT/'Sources/SDKtools/STAutoplaySanitizer.inc').read_text(encoding='utf-8')
        self.assertIn('static NSDictionary *STWPSanitizeAutoplayReading(id value)',sanitizer)
        for field in ('status','reason','cardsRead','cardTypesRead','animationDetail','cardRuleDetail'):
            self.assertIn('@"'+field+'"',sanitizer)
        self.assertNotRegex(method,r'evaluateJavaScript|performAutoplay|autoplayTick|sampleWebView')

    def test_ios_atomic_protection_and_no_backup_are_not_silently_ignored(self):
        helper=(ROOT/'Sources/SDKtools/STCoveredCardReport.inc').read_text(encoding='utf-8')
        self.assertIn('NSDataWritingAtomic',helper)
        self.assertIn('NSFileProtectionKey:NSFileProtectionComplete',helper)
        self.assertIn('options|=NSDataWritingFileProtectionComplete',helper)
        self.assertIn('if (![destination setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey',helper)
        self.assertIn('STCCReportSetError(error,7); return nil;',helper)
        self.assertIn('@"SDKtools-CoveredCard-%@.json"',helper)
        self.assertNotIn('NSUnderlyingErrorKey',helper)

    def test_foundation_fixture_is_run_by_existing_native_suite(self):
        script=(ROOT/'scripts/test_autoplay_bridge.sh').read_text(encoding='utf-8')
        self.assertIn('Tests/covered_report_test.m',script)
        self.assertIn('"$test_workspace/covered-report"',script)
        fixture=(ROOT/'Tests/covered_report_test.m').read_text(encoding='utf-8')
        self.assertIn('#import "../Sources/SDKtools/STCoveredCardReport.inc"',fixture)
        self.assertIn('STCCReportData(YES,YES',fixture)
        self.assertIn('STCCReportData(NO,NO,nil,nil',fixture)


if __name__=='__main__':
    unittest.main()

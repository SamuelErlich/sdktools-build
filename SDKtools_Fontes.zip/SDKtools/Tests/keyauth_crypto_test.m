#include "../Sources/SDKtools/STKeyAuthCrypto.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks;

static void expect(int32_t actual, int32_t expected, const char *label) {
    if (actual != expected) {
        fprintf(stderr, "%s: expected %d, got %d\n", label, expected, actual);
        abort();
    }
    checks++;
}

static void decodeHex(const char *hex, uint8_t *bytes, size_t length) {
    assert(strlen(hex) == length * 2);
    for (size_t index = 0; index < length; index++) {
        unsigned value;
        assert(sscanf(hex + index * 2, "%2x", &value) == 1);
        bytes[index] = (uint8_t)value;
    }
}

int main(void) {
    uint8_t publicKey[32], signature[64];
    /* RFC 8032 section 7.1, TEST 1: the empty message is valid. */
    decodeHex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a", publicKey, sizeof publicKey);
    decodeHex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555f"
              "b8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b", signature, sizeof signature);
    expect(STKeyAuthVerifyEd25519(signature, 64, NULL, 0, publicKey, 32), 1, "RFC 8032 empty message");
    uint8_t unused = 0;
    expect(STKeyAuthVerifyEd25519(signature, 64, &unused, 0, publicKey, 32), 1, "empty non-NULL buffer");
    expect(STKeyAuthVerifyEd25519(signature, 64, &unused, 1, publicKey, 32), 0, "changed empty message");
    signature[0] ^= 1;
    expect(STKeyAuthVerifyEd25519(signature, 64, NULL, 0, publicKey, 32), 0, "tampered signature");
    signature[0] ^= 1;
    publicKey[0] ^= 1;
    expect(STKeyAuthVerifyEd25519(signature, 64, NULL, 0, publicKey, 32), 0, "wrong public key");
    publicKey[0] ^= 1;

    /* RFC 8032 section 7.1, TEST 2: a nonempty message. */
    uint8_t message = 0x72;
    decodeHex("3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c", publicKey, sizeof publicKey);
    decodeHex("92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da"
              "085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00", signature, sizeof signature);
    expect(STKeyAuthVerifyEd25519(signature, 64, &message, 1, publicKey, 32), 1, "RFC 8032 one byte message");
    message ^= 1;
    expect(STKeyAuthVerifyEd25519(signature, 64, &message, 1, publicKey, 32), 0, "tampered message");
    message ^= 1;

    expect(STKeyAuthVerifyEd25519(NULL, 64, &message, 1, publicKey, 32), 0, "NULL signature");
    expect(STKeyAuthVerifyEd25519(signature, 64, &message, 1, NULL, 32), 0, "NULL key");
    expect(STKeyAuthVerifyEd25519(signature, 64, NULL, 1, publicKey, 32), 0, "NULL nonempty message");
    const size_t badSignatureLengths[] = {0, 63, 65, SIZE_MAX};
    for (size_t i = 0; i < sizeof badSignatureLengths / sizeof badSignatureLengths[0]; i++) {
        expect(STKeyAuthVerifyEd25519(signature, badSignatureLengths[i], &message, 1, publicKey, 32), 0, "invalid signature length");
    }
    const size_t badKeyLengths[] = {0, 31, 33, SIZE_MAX};
    for (size_t i = 0; i < sizeof badKeyLengths / sizeof badKeyLengths[0]; i++) {
        expect(STKeyAuthVerifyEd25519(signature, 64, &message, 1, publicKey, badKeyLengths[i]), 0, "invalid key length");
    }
    expect(STKeyAuthVerifyEd25519(signature, 64, &message, 1024 * 1024 + 1, publicKey, 32), 0, "bounded message");
    expect(STKeyAuthVerifyEd25519(signature, 64, &message, SIZE_MAX, publicKey, 32), 0, "message length overflow");

    /* Fixed vector signed independently with Node crypto using RFC TEST 1's public test seed. */
    uint8_t rawMessage[] = {0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x7b,0x22,0x78,0x22,0x3a,0x22,0x00,0xff,0xc3,0xa9,0x22,0x7d};
    decodeHex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a", publicKey, sizeof publicKey);
    decodeHex("c479f68d3baec39ca850eeab96ba9cbd8c0bf7ac8fe9bad7b07e3e44cf9814a65"
              "e3257eed20e8d736903028e16f4c0245fe409e52940281231143a0cb1fbe504", signature, sizeof signature);
    expect(STKeyAuthVerifyEd25519(signature, 64, rawMessage, sizeof rawMessage, publicKey, 32), 1, "raw bytes with NUL and invalid UTF-8");
    expect(STKeyAuthVerifyEd25519(signature, 64, rawMessage, strlen((const char *)rawMessage), publicKey, 32), 0, "raw message must not truncate at NUL");
    rawMessage[17] = 0xfe;
    expect(STKeyAuthVerifyEd25519(signature, 64, rawMessage, sizeof rawMessage, publicKey, 32), 0, "raw byte tampering");

    uint8_t *maximumMessage = calloc(1024 * 1024, 1);
    assert(maximumMessage);
    decodeHex("634deabcc4a65c3fe5ddbd658a0a4b697df567e879784b111851d5fc0389f057b7"
              "e460f47f9c3226a19bbbf8c083dde402d09fb1ec27df9c0dee34689e8d5f0e", signature, sizeof signature);
    expect(STKeyAuthVerifyEd25519(signature, 64, maximumMessage, 1024 * 1024, publicKey, 32), 1, "maximum message size");
    free(maximumMessage);
    printf("KeyAuth Ed25519: %u checks passed.\n", checks);
    return 0;
}

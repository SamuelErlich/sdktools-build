#import <Foundation/Foundation.h>
#import "STSceneCodec.h"
#include <stdio.h>
#include <string.h>

static NSUInteger STAssertions;
static void Check(BOOL condition, NSString *message) {
    STAssertions++;
    if (!condition) [NSException raise:@"SceneCodecTestFailure" format:@"%@", message];
}
static NSData *JSON(id value) {
    return [NSJSONSerialization dataWithJSONObject:value options:NSJSONWritingSortedKeys error:NULL];
}
static void EqualJSON(id actual, id expected, NSString *message) {
    Check([JSON(actual) isEqualToData:JSON(expected)], message);
}
static NSArray *Rows(void) {
    NSString *padding = [@"geometry:" stringByPaddingToLength:700 withString:@"p" startingAtIndex:0];
    return @[
        @{@"nodeID": @"root", @"index": @0, @"parent": NSNull.null, @"parentID": NSNull.null, @"padding": padding},
        @{@"nodeID": @"a", @"index": @1, @"parent": @0, @"parentID": @"root", @"padding": padding,
            @"local": @{@"x": @10, @"y": @20}, @"optional": NSNull.null},
        @{@"nodeID": @"b", @"index": @2, @"parent": @0, @"parentID": @"root", @"padding": padding,
            @"local": @{@"x": @30, @"y": @40}, @"flag": @YES}
    ];
}
static NSArray *Change(NSArray *rows, NSUInteger index, NSDictionary *set, NSArray *unset) {
    NSMutableArray *copy = [rows mutableCopy];
    NSMutableDictionary *row = [copy[index] mutableCopy];
    [row addEntriesFromDictionary:set];
    [row removeObjectsForKeys:unset];
    copy[index] = [row copy];
    return [copy copy];
}
static STSceneEncodingCandidate *Prepare(STSceneCodec *codec, NSArray *rows, NSUInteger sequence) {
    STSceneEncodingCandidate *candidate = [codec prepareNodes:rows contextID:@"context" webViewID:@"web" sequence:sequence];
    Check(candidate != nil, @"valid candidate");
    return candidate;
}
static void Commit(STSceneCodec *codec, STSceneEncodingCandidate *candidate) {
    Check([codec commitCandidate:candidate], @"accepted candidate commits");
}
// Independent test-side patch application. Serialization comparison catches a
// missing key versus JSON null as well as true versus numeric 1.
static NSArray *Decode(STSceneEncodingCandidate *candidate, NSArray *previous) {
    NSDictionary *fields = candidate.fields;
    if ([fields[@"sceneNodesEncoding"] isEqualToString:@"full"]) return fields[@"sceneNodes"];
    if ([fields[@"sceneNodesEncoding"] isEqualToString:@"reference"]) return previous;
    NSDictionary *delta = fields[@"sceneNodesDelta"];
    NSMutableDictionary *nodes = [NSMutableDictionary dictionary];
    for (NSDictionary *row in previous) nodes[row[@"nodeID"]] = row;
    for (NSDictionary *row in delta[@"added"]) nodes[row[@"nodeID"]] = row;
    for (NSDictionary *patch in delta[@"changed"]) {
        NSMutableDictionary *row = [nodes[patch[@"nodeID"]] mutableCopy];
        [row addEntriesFromDictionary:patch[@"set"]];
        [row removeObjectsForKeys:patch[@"unset"]];
        nodes[patch[@"nodeID"]] = [row copy];
    }
    NSMutableArray *result = [NSMutableArray array];
    for (NSString *nodeID in delta[@"order"]) [result addObject:nodes[nodeID]];
    return [result copy];
}
static void Encoding(STSceneEncodingCandidate *candidate, NSString *encoding) {
    Check([candidate.fields[@"sceneNodesEncoding"] isEqualToString:encoding], [@"encoding: " stringByAppendingString:encoding]);
}

static void RunTests(void) {
    STSceneCodec *codec = [STSceneCodec new];
    NSArray *base = Rows();
    STSceneEncodingCandidate *first = Prepare(codec, base, 1);
    Encoding(first, @"full");
    EqualJSON(Decode(first, nil), base, @"first full is exact");
    Check(first.dependencyDepth == 0, @"full depth zero");
    Commit(codec, first);

    STSceneEncodingCandidate *same = Prepare(codec, base, 2);
    Encoding(same, @"reference");
    Check([same.fields[@"sceneNodesRefSequence"] unsignedIntegerValue] == 1, @"reference targets full");
    Commit(codec, same);
    NSArray *moved = Change(base, 1, @{@"local": @{@"x": @11, @"y": @20}, @"newNullable": NSNull.null}, @[@"optional"]);
    STSceneEncodingCandidate *delta = Prepare(codec, moved, 3);
    Encoding(delta, @"delta");
    EqualJSON(Decode(delta, base), moved, @"changed coordinate, added null, removed optional key");
    Check([delta.fields[@"sceneNodesRefSequence"] unsignedIntegerValue] == 1, @"delta skips earlier reference");
    Check(delta.encodedPayloadBytes < delta.fullPayloadBytes, @"delta saves serialized bytes");
    Commit(codec, delta);
    STSceneEncodingCandidate *afterDelta = Prepare(codec, moved, 4);
    Encoding(afterDelta, @"reference");
    Check([afterDelta.fields[@"sceneNodesRefSequence"] unsignedIntegerValue] == 3, @"reference targets accepted delta");
    Commit(codec, afterDelta);

    NSArray *swapped = @[moved[0], Change(moved, 2, @{@"index": @1}, @[])[2], Change(moved, 1, @{@"index": @2}, @[])[1]];
    STSceneEncodingCandidate *reordered = Prepare(codec, swapped, 5);
    Encoding(reordered, @"delta");
    EqualJSON(Decode(reordered, moved), swapped, @"order and index preserved exactly");
    Commit(codec, reordered);
    NSArray *partial = @[swapped[0], swapped[1]];
    STSceneEncodingCandidate *missing = Prepare(codec, partial, 6);
    Encoding(missing, @"delta");
    EqualJSON(Decode(missing, swapped), partial, @"missing node affects observation membership only");
    Check(missing.fields[@"sceneNodesDelta"][@"removed"] == nil, @"no game-removal claim");
    Commit(codec, missing);
    NSArray *restored = [partial arrayByAddingObject:swapped[2]];
    STSceneEncodingCandidate *added = Prepare(codec, restored, 7);
    EqualJSON(Decode(added, partial), restored, @"newly observed node restored with complete row");
    Commit(codec, added);
    NSArray *booleanRows = Change(restored, 1, @{@"flag": @1, @"nested": @[@YES, @{@"v": @NO}]}, @[]);
    STSceneEncodingCandidate *boolToNumber = Prepare(codec, booleanRows, 8);
    Encoding(boolToNumber, @"delta");
    EqualJSON(Decode(boolToNumber, restored), booleanRows, @"true-to-number change retained");
    Commit(codec, boolToNumber);
    NSArray *nestedNumbers = Change(booleanRows, 1, @{@"nested": @[@1, @{@"v": @0}]}, @[]);
    STSceneEncodingCandidate *nested = Prepare(codec, nestedNumbers, 9);
    EqualJSON(Decode(nested, booleanRows), nestedNumbers, @"nested boolean-to-number retained");
    Commit(codec, nested);

    // Prepare-and-reject cannot advance the base, including a rejected full that
    // would otherwise replace the context.
    STSceneEncodingCandidate *rejected = [codec prepareNodes:base contextID:@"rejected-context" webViewID:@"web" sequence:10];
    Encoding(rejected, @"full");
    STSceneEncodingCandidate *afterRejected = Prepare(codec, nestedNumbers, 11);
    Encoding(afterRejected, @"reference");
    Check([afterRejected.fields[@"sceneNodesRefSequence"] unsignedIntegerValue] == 9, @"rejection keeps last accepted base");
    Commit(codec, afterRejected);
    Check(![codec commitCandidate:rejected], @"stale rejected proposal cannot later commit");

    STSceneEncodingCandidate *contextSwitch = [codec prepareNodes:base contextID:@"other" webViewID:@"web" sequence:12];
    Encoding(contextSwitch, @"full"); Commit(codec, contextSwitch);
    STSceneEncodingCandidate *webSwitch = [codec prepareNodes:base contextID:@"other" webViewID:@"second-web" sequence:13];
    Encoding(webSwitch, @"full"); Commit(codec, webSwitch);
    STSceneEncodingCandidate *unscoped = [codec prepareNodes:base contextID:@"other" webViewID:nil sequence:14];
    Encoding(unscoped, @"full"); Commit(codec, unscoped);
    STSceneEncodingCandidate *scopedAgain = Prepare(codec, base, 15);
    Encoding(scopedAgain, @"full"); Commit(codec, scopedAgain);

    NSArray *duplicateIDs = @[base[0], base[0]];
    STSceneEncodingCandidate *invalid = Prepare(codec, duplicateIDs, 16);
    Encoding(invalid, @"full");
    EqualJSON(Decode(invalid, nil), duplicateIDs, @"invalid-ID full remains exact and never becomes a delta base");
    Commit(codec, invalid);
    STSceneEncodingCandidate *validAgain = Prepare(codec, base, 17);
    Encoding(validAgain, @"full"); Commit(codec, validAgain);
    Check([codec prepareNodes:@[@{@"nodeID": @"bad", @"value": NSDate.date}] contextID:@"context" webViewID:@"web" sequence:18] == nil,
        @"invalid JSON cannot advance encoding state");
    STSceneEncodingCandidate *afterInvalidJSON = Prepare(codec, base, 19);
    Encoding(afterInvalidJSON, @"reference");
    Check([afterInvalidJSON.fields[@"sceneNodesRefSequence"] unsignedIntegerValue] == 17, @"serialization rejection keeps valid base");
    Commit(codec, afterInvalidJSON);
    Check([codec prepareNodes:base contextID:@"context" webViewID:@"web" sequence:19] == nil, @"sequence must advance");
    [codec reset];
    STSceneEncodingCandidate *reset = Prepare(codec, base, 1);
    Encoding(reset, @"full"); Commit(codec, reset);
    Check(![codec commitCandidate:validAgain], @"pre-reset proposal cannot commit");

    // Worst-case changing-scene chain: 19 dependencies, then a keyframe even if
    // one more delta would be smaller. The interval uses accepted sample numbers.
    NSArray *last = base;
    for (NSUInteger sequence = 2; sequence <= 20; sequence++) {
        NSArray *next = Change(last, 1, @{@"tick": @(sequence)}, @[]);
        STSceneEncodingCandidate *candidate = Prepare(codec, next, sequence);
        Encoding(candidate, @"delta");
        Check(candidate.dependencyDepth == sequence - 1, @"bounded delta depth");
        EqualJSON(Decode(candidate, last), next, @"keyframe-chain step reconstructs exactly");
        Commit(codec, candidate);
        last = next;
    }
    STSceneEncodingCandidate *keyframe = Prepare(codec, last, 21);
    Encoding(keyframe, @"full"); Check(keyframe.dependencyDepth == 0, @"keyframe resets depth"); Commit(codec, keyframe);
    for (NSUInteger sequence = 22; sequence <= 40; sequence++) {
        STSceneEncodingCandidate *candidate = Prepare(codec, last, sequence);
        Encoding(candidate, @"reference");
        Check([candidate.fields[@"sceneNodesRefSequence"] unsignedIntegerValue] == 21, @"references do not extend chain");
        Check(candidate.dependencyDepth == 1, @"reference depth stays one");
        Commit(codec, candidate);
    }
    STSceneEncodingCandidate *unchangedKeyframe = Prepare(codec, last, 41);
    Encoding(unchangedKeyframe, @"full"); Commit(codec, unchangedKeyframe);

    STSceneCodec *small = [STSceneCodec new];
    Commit(small, Prepare(small, @[@{@"nodeID": @"a"}], 1));
    STSceneEncodingCandidate *notSmaller = Prepare(small, @[@{@"nodeID": @"b"}], 2);
    Encoding(notSmaller, @"full"); Commit(small, notSmaller);
    STSceneEncodingCandidate *empty = Prepare(small, @[], 3);
    Encoding(empty, @"full"); Commit(small, empty);
    STSceneEncodingCandidate *emptyReference = Prepare(small, @[], 4);
    Encoding(emptyReference, @"reference"); EqualJSON(Decode(emptyReference, @[]), @[], @"empty scene reference");
    Check(![codec commitCandidate:emptyReference], @"candidate cannot cross codec owners");
    Commit(small, emptyReference);

    STSceneCodec *parentCodec = [STSceneCodec new];
    Commit(parentCodec, Prepare(parentCodec, base, 1));
    NSArray *reparented = Change(base, 2, @{@"parent": @1, @"parentID": @"a"}, @[]);
    STSceneEncodingCandidate *parentChange = Prepare(parentCodec, reparented, 2);
    Encoding(parentChange, @"delta");
    EqualJSON(Decode(parentChange, base), reparented, @"parent index and object ID preserved through reparenting");
    Commit(parentCodec, parentChange);
    fprintf(stderr, "Scene codec: %lu assertions passed.\n", (unsigned long)STAssertions);
}

// Optional machine-readable harness for an independent Python decoder. Each
// input line is a sample containing sceneNodes, contextID, webViewID, sequence.
// commit:false models a complete-sample budget rejection without advancing state.
static int RunJSONLines(void) {
    NSData *input = [NSFileHandle.fileHandleWithStandardInput readDataToEndOfFile];
    NSString *text = [[NSString alloc] initWithData:input encoding:NSUTF8StringEncoding];
    if (!text) return 2;
    STSceneCodec *codec = [STSceneCodec new];
    for (NSString *line in [text componentsSeparatedByCharactersInSet:NSCharacterSet.newlineCharacterSet]) {
        if (!line.length) continue;
        @autoreleasepool {
            NSDictionary *sample = [NSJSONSerialization JSONObjectWithData:[line dataUsingEncoding:NSUTF8StringEncoding] options:0 error:NULL];
            if (![sample isKindOfClass:NSDictionary.class]) return 2;
            if ([sample[@"reset"] boolValue]) [codec reset];
            NSUInteger sequence = [sample[@"sequence"] unsignedIntegerValue];
            STSceneEncodingCandidate *candidate = [codec prepareNodes:sample[@"sceneNodes"] contextID:sample[@"contextID"]
                webViewID:sample[@"webViewID"] sequence:sequence];
            if (!candidate) return 3;
            BOOL accepted = !sample[@"commit"] || [sample[@"commit"] boolValue];
            NSMutableDictionary *output = [sample mutableCopy];
            [output removeObjectForKey:@"sceneNodes"];
            [output addEntriesFromDictionary:candidate.fields];
            output[@"_codecMetrics"] = @{@"fullPayloadBytes": @(candidate.fullPayloadBytes),
                @"encodedPayloadBytes": @(candidate.encodedPayloadBytes), @"dependencyDepth": @(candidate.dependencyDepth),
                @"committed": @(accepted)};
            NSData *data = JSON(output);
            if (!data || (accepted && ![codec commitCandidate:candidate])) return 4;
            [NSFileHandle.fileHandleWithStandardOutput writeData:data];
            [NSFileHandle.fileHandleWithStandardOutput writeData:[@"\n" dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }
    return 0;
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        @try {
            if (argc == 2 && strcmp(argv[1], "--jsonl") == 0) return RunJSONLines();
            if (argc != 1) return 2;
            RunTests();
            return 0;
        } @catch (NSException *exception) {
            fprintf(stderr, "%s: %s\n", exception.name.UTF8String, exception.reason.UTF8String);
            return 1;
        }
    }
}

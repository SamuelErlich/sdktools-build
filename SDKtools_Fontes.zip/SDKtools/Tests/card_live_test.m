#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import "../Sources/SDKtools/STCardLifecycle.h"
#import "../Sources/SDKtools/STCardColorFeed.h"
#include <stdio.h>
static NSUInteger checks,failures,calls,phase;
static BOOL answer;
static id receiver;
static SEL selectorSeen;
static void Check(BOOL ok, NSString *label) { checks++; if (!ok) { failures++; fprintf(stderr,"FAIL %s\n",label.UTF8String); } }
static BOOL Load(id self,SEL cmd) { calls++; receiver=self; selectorSeen=cmd; Check(phase==1,@"checkpoint before BOOL original"); phase=2; return answer; }
static void Setup(id self,SEL cmd) { calls++; receiver=self; selectorSeen=cmd; Check(phase==0,@"void original before checkpoint"); phase=2; }
int main(void) { @autoreleasepool {
    id object=[NSObject new]; SEL load=NSSelectorFromString(@"loadCurrentGame"), setup=NSSelectorFromString(@"setupWKWebView");
    IMP lb=STCardLifecycleWrapper(load,(IMP)Load,^(id o,BOOL before){Check(o==object && before,@"BOOL checkpoint receives object");phase=1;});
    IMP vb=STCardLifecycleWrapper(setup,(IMP)Setup,^(id o,BOOL before){Check(o==object && !before && phase==2,@"void checkpoint follows original");phase=3;});
    for (NSUInteger i=0;i<2;i++) { answer=i!=0; phase=0; NSUInteger prior=calls;
        BOOL actual=((BOOL(*)(id,SEL))lb)(object,load);
        Check(actual==answer && calls==prior+1 && receiver==object && sel_isEqual(selectorSeen,load),@"BOOL preserved, correct self/selector, exactly one call");
    }
    phase=0;NSUInteger prior=calls;((void(*)(id,SEL))vb)(object,setup);
    Check(calls==prior+1 && phase==3 && sel_isEqual(selectorSeen,setup),@"void wrapper forwards exactly once");
    Check(strcmp(STCardLifecycleEncoding(load),"B16@0:8")==0 && strcmp(STCardLifecycleEncoding(setup),"v16@0:8")==0,@"selector-specific encodings");
    Check(STCardLifecycleWrapper(NSSelectorFromString(@"unreviewed"),(IMP)Load,nil)==NULL,@"unknown selector rejected");
    imp_removeBlock(lb);imp_removeBlock(vb);
    STCardColorFeed *feed=[STCardColorFeed new];
    NSMutableDictionary *card=[@{@"id":@7,@"type":@1,@"color":@3,@"colorState":@"known",@"private":@"SECRET"} mutableCopy];
    NSMutableDictionary *e=[@{@"sequence":@1,@"stage":@"skin_bg_complete",@"bindingValid":@YES,@"cards":@[card]} mutableCopy];
    [feed consumeEvents:@[e]]; [feed consumeEvents:@[e]];
    Check([feed.snapshot[@"observations"] isEqual:@1],@"duplicate event cannot increment feed");
    e[@"sequence"]=@2;e[@"bindingValid"]=@NO;[feed consumeEvents:@[e]];
    Check([feed.snapshot[@"rejected"] isEqual:@1],@"stale completion rejected");
    e[@"sequence"]=@3;e[@"bindingValid"]=@YES;card[@"type"]=@0;card[@"colorState"]=@"candidate";[feed consumeEvents:@[e]];
    Check([feed.snapshot[@"observations"] isEqual:@1],@"candidate never promoted");
    e[@"sequence"]=@4;card[@"type"]=@6;card[@"color"]=@0;card[@"colorState"]=@"special";[feed consumeEvents:@[e]];
    Check([feed.snapshot[@"byColor"][0] isEqual:@1],@"special zero retained");
    for(NSUInteger i=5;i<30;i++){e[@"sequence"]=@(i);[feed consumeEvents:@[e]];}
    Check([feed.snapshot[@"recent"] count]==8,@"history bounded");
    NSData *data=[NSJSONSerialization dataWithJSONObject:feed.snapshot options:0 error:nil];
    Check(![[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding] containsString:@"SECRET"],@"no arbitrary strings retained");
    [feed reset];Check([feed.snapshot[@"observations"] isEqual:@0] && [feed.snapshot[@"recent"] count]==0,@"new capture clears history");
    printf("Card typed hooks/feed: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
} }

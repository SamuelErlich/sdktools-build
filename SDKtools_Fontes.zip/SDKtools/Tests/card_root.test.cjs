'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {setup,attachCard,graphic,plain}=require('./card_hints_fixture.cjs');
const rootSource=fs.readFileSync(path.join(__dirname,'../Resources/card_root.js'),'utf8');
function fixture(info={id:17,type:1,color:2}){
  const f=setup({rootSource});
  class Card {} Card.prototype.__classname__='Card';
  const handNode=new f.cc.Node('HandArea'),items=new f.cc.Node('Items');
  f.initial.canvas.addChild(handNode);handNode.addChild(items);
  const gamer={uid:'LOCAL-ONLY',cards:[info]},store={gamers:[gamer],state:3,start_time:1};
  const hand={__classname__:'HandArea',itemsNode:items,gamer,uid:gamer.uid};handNode._components.push(hand);
  const c=f.card({face:false,parent:items}),component=attachCard(f,c,info);Object.setPrototypeOf(component,Card.prototype);
  const calls=[];f.win.__require=name=>{calls.push(name);return {default:name==='Card'?Card:store};};
  return Object.assign(f,{c,component,hand,handNode,items,gamer,store,info,Card,calls});
}
function noKnown(f){const r=f.overlay.tick();assert.equal(r.shown,0);assert.equal(r.rootShown,0);return r;}
function duringGeometry(f,mutate){const original=f.c.node.convertToWorldSpaceAR.bind(f.c.node);let once=false;f.c.node.convertToWorldSpaceAR=p=>{if(!once){once=true;mutate();}return original(p);};}
test('current Store object and hand ownership allow a hidden color without writing the game',()=>{
 const f=fixture(),before=JSON.stringify(f.store);Object.freeze(f.info);
 const r=f.overlay.tick();assert.equal(r.shown,1);assert.equal(r.rootShown,1);assert.equal(r.rootBound,1);assert.equal(r.rootKnown,1);
 assert.equal(JSON.stringify(f.store),before);assert.equal(f.c.front.active,false);assert.equal(f.c.back.active,true);
 assert.deepEqual(plain(graphic(f).fillColor),{r:17,g:135,b:255,a:255});assert.deepEqual(f.calls,['Card','GameStore']);
 assert.ok(!JSON.stringify(r).includes('LOCAL-ONLY'));f.overlay.clear();
});
test('Back zero remains unknown even with a valid current root link',()=>{
 const f=fixture({id:17,type:0,color:0,num:0}),r=noKnown(f);assert.equal(r.rootBound,1);assert.equal(r.rootUnknown,1);assert.equal(r.unknownShown,1);
});
test('residual nonzero Back color is only a candidate',()=>{
 const f=fixture({id:17,type:0,color:4}),r=noKnown(f);assert.equal(r.candidates,1);assert.equal(r.rootKnown,0);
});
test('same ID or identical copied fields never substitute for current object identity',()=>{
 const f=fixture();f.component.cardInfo={...f.info};assert.equal(noKnown(f).rootUnbound,1);
});
test('reused node changes to unknown immediately and never keeps the previous paint',()=>{
 const f=fixture();assert.equal(f.overlay.tick().rootShown,1);const marker=f.hints()[0];
 const next={id:90,type:0,color:0};f.component.cardInfo=next;f.gamer.cards=[next];f.advance(40);
 const r=noKnown(f);assert.equal(r.unknownShown,1);assert.equal(f.hints()[0],marker);
 assert.ok(graphic(f).commands.some(c=>c[0]==='stroke'));assert.equal(r.rootKnown,0);
});
test('new current card on the same node uses only its new root color',()=>{
 const f=fixture();f.overlay.tick();const next={id:90,type:3,color:4};f.component.cardInfo=next;f.gamer.cards=[next];
 assert.equal(f.overlay.tick().rootShown,1);assert.deepEqual(plain(graphic(f).fillColor),{r:175,g:226,b:77,a:255});
});
test('same ID in a new Store round cannot preserve an old Card object',()=>{
 const f=fixture();f.overlay.tick();const g={uid:f.gamer.uid,cards:[{id:17,type:1,color:4}]};f.store.gamers=[g];f.store.start_time=2;f.hand.gamer=g;
 noKnown(f);
});
test('moving a node to another hand invalidates its old owner binding',()=>{
 const f=fixture();f.overlay.tick();const p=new f.cc.Node('OtherItems');f.handNode.addChild(p);p.addChild(f.c.node);noKnown(f);
});
test('a stale HandArea gamer reference is not matched by UID alone',()=>{
 const f=fixture();f.hand.gamer={uid:f.gamer.uid,cards:f.gamer.cards};noKnown(f);
});
test('duplicate Store IDs and duplicate displayed IDs are rejected',()=>{
 const f=fixture();f.gamer.cards.push({...f.info});noKnown(f);
 const g=fixture(),c=g.card({face:false,parent:g.items,x:300});const comp=attachCard(g,c,{...g.info});Object.setPrototypeOf(comp,g.Card.prototype);noKnown(g);
});
test('accessor color is never invoked or treated as known',()=>{
 const info={id:17,type:1};let reads=0;Object.defineProperty(info,'color',{get(){reads++;return 2;}});const f=fixture(info);noKnown(f);assert.equal(reads,0);
});
test('root fields changing during geometry cannot publish an old color',()=>{
 for(const change of [f=>f.info.color=4,f=>f.store.start_time++,f=>f.store.state=7,f=>f.gamer.cards=[f.info],f=>f.component.cardInfo={...f.info},f=>f.hand.uid='OTHER']){
  const f=fixture();duringGeometry(f,()=>change(f));noKnown(f);assert.equal(f.hints().length,0);
 }
});
test('reparenting during geometry cannot display a root marker in the wrong hand',()=>{
 const f=fixture();duringGeometry(f,()=>f.initial.canvas.addChild(f.c.node));noKnown(f);
});
test('bounded root scan rejects oversized state without changing the game',()=>{
 const f=fixture();f.gamer.cards=Array.from({length:257},(_,id)=>({id,type:1,color:2}));const r=noKnown(f);assert.equal(r.rootStatus,'root_incomplete');assert.equal(f.gamer.cards.length,257);
});
test('unknown module contract falls back to an unknown hidden marker',()=>{
 const f=fixture();f.win.__require=()=>({default:function Foreign(){}});noKnown(f);
});
test('special color zero remains special and does not use the turn color',()=>{
 const f=fixture({id:17,type:6,color:0});f.store.color=4;const r=f.overlay.tick();assert.equal(r.rootShown,1);assert.equal(r.special,1);
});
test('manual repeated tick rereads current state without reinstalling or remembering a color',()=>{
 const f=fixture();f.overlay.tick();f.info.color=3;assert.equal(f.overlay.tick().rootKnown,1);
 assert.deepEqual(plain(graphic(f).fillColor),{r:254,g:200,b:100,a:255});assert.equal(f.hints().length,1);
 f.info.type=0;noKnown(f);
});
test('lease expiration clears root markers as well as visible markers',()=>{
 const f=fixture();f.overlay.tick();f.advance(601);assert.equal(f.hints().length,0);
});

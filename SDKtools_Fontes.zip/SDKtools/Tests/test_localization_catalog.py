"""Translation resource consistency and production UI coverage contracts."""
import json
from pathlib import Path
import re
import unittest
ROOT=Path(__file__).resolve().parents[1]
TOKEN=re.compile(r'%%|%(?:[0-9]+)?(?:\.[0-9]+)?(?:@|(?:ll|l)?[udi]|f)')

def format_arguments(text):
    return [token for token in TOKEN.findall(text) if token != '%%']

class LocalizationCatalogTests(unittest.TestCase):
    def setUp(self):
        self.catalog=json.loads((ROOT/'Resources/Brand/menu-localizations.json').read_text(encoding='utf-8'))
        self.rows=self.catalog['entries']

    def test_complete_bilingual_rows_unambiguous_aliases_and_format_arguments(self):
        self.assertEqual(self.catalog['schemaVersion'],1)
        self.assertEqual(self.catalog['languages'],['en','pt'])
        aliases={}
        for row in self.rows:
            self.assertTrue(row['en'] and row['pt'])
            self.assertEqual(format_arguments(row['en']),format_arguments(row['pt']),row)
            for key in ('en','pt','source'):
                if key not in row:continue
                value=row[key]
                self.assertIsInstance(value,str)
                self.assertTrue(value)
                self.assertEqual(format_arguments(row['en']),format_arguments(value),row)
                self.assertEqual(aliases.setdefault(value,row),row,value)

    def test_all_static_customer_labels_buttons_switches_and_accessibility_are_covered(self):
        source=(ROOT/'Sources/SDKtools/STOverlay.m').read_text(encoding='utf-8')
        controller=source[source.index('@implementation STOverlayController'):source.index('@implementation STOverlay\n')]
        aliases={v for row in self.rows for v in row.values()}
        neutral={'SDK Client','Forged hot. Played cold.'}
        copy=re.findall(r'(?:\[self (?:label|button|addSwitch|module):|STLocalizeAccessibility(?:Label|Hint|Value)\([^,]+,)@"([^"\n]+)"',controller)
        self.assertGreater(len(copy),35)
        for text in copy:
            if text.startswith('SDK Client · '):continue
            self.assertIn(text,aliases|neutral,text)

    def test_live_billiards_automation_reasons_have_both_translations(self):
        source=(ROOT/'Resources/billiards_probe.lua').read_text(encoding='utf-8')
        # The phase can be dynamic; physics and planner failures also flow
        # through controlStatus via variables and are displayed to the player.
        reasons=set(re.findall(r'controlStatus\([^,\n]+,\s*"([a-z_]+)"',source))
        reasons.update(re.findall(r'\b(?:reject|bodyReject)\("([a-z_]+)"',source))
        strategy=(ROOT/'Resources/billiards_strategy.lua').read_text(encoding='utf-8')
        strategy=strategy[strategy.index('function M.plan(s)'):]
        reasons.update(re.findall(r'return nil,\s*"([a-z_]+)"',strategy))
        aliases={row.get('source') for row in self.rows}
        self.assertTrue(reasons)
        self.assertFalse(reasons-aliases,reasons-aliases)

    def test_live_status_producers_and_slider_templates_have_translations(self):
        aliases={v for row in self.rows for v in row.values()}
        sections=[
            ('STAutoplayRecorder.inc','- (NSString *)autoplayStatusText','- (void)ensureAutoplayTimer'),
            ('STCardHintsRecorder.inc','- (NSString *)cardHintsStatusText','- (NSString *)cardHintsDetailsText'),
            ('STBilliardsRuntime.m','- (void)setAutomationMode:','- (BOOL)startInWindow:'),
            ('STOverlay.m','- (void)changeXrayDepth {','- (void)runWarehouseTest:'),
        ]
        neutral={'Auto','BilliardInGame','%02lu:%02lu','%@'}
        checked=set()
        for name,start,end in sections:
            source=(ROOT/'Sources/SDKtools'/name).read_text(encoding='utf-8')
            section=source[source.index(start):source.index(end,source.index(start))]
            for literal in re.findall(r'@"((?:\\.|[^"\\])*)"',section):
                for fragment in re.split(r' · |\\n',literal):
                    fragment=fragment.strip()
                    # Ignore internal keys, printf-only fields and ObjC asserts.
                    if not fragment or (re.fullmatch(r'[a-z][A-Za-z_0-9]*',fragment) and fragment not in aliases) or fragment in neutral:
                        continue
                    if not re.search(r'[A-Za-zÀ-ÿ]',TOKEN.sub('',fragment)):
                        continue
                    if fragment.startswith(('Main thread','STRecorder requires')):
                        continue
                    self.assertTrue(fragment in aliases,(name,fragment))
                    checked.add(fragment)
        self.assertGreater(len(checked),80)

    def test_customer_error_copy_does_not_offer_removed_export_controls(self):
        # Internal diagnostics retain their original source text. The client
        # menu has no export button, so displayed copy must not direct to one.
        sources={
            'Cores indisponíveis; confira o relatório.',
            'Leitura nativa indisponível. Exporte o diagnóstico.',
            'Dados incompletos; guia ocultada. Exporte o diagnóstico.',
            'Essa leitura ainda não está disponível. Exporte o diagnóstico.',
            'A leitura falhou. Exporte o diagnóstico.',
            'Módulos do bilhar encontrados. Exporte a leitura para verificar a mesa.',
            'Diagnóstico do ambiente coletado. Exporte a leitura do bilhar.',
            'Não foi possível identificar esse poder nesta tela. Entre na partida e exporte um relatório se continuar.',
        }
        by_source={row.get('source'):row for row in self.rows}
        for source in sources:
            self.assertIn(source,by_source)
            for language in ('en','pt'):
                self.assertNotRegex(by_source[source][language],r'(?i)export|report|relatório')

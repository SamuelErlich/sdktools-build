const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_hints.js'),'utf8');
const BASE_NAME=String.fromCharCode(65,18,178,215,49),ALT_BACK_NAME=String.fromCharCode(67,37,243,108,163);
function setup({viewportWidth=390,rootSource=null}={}){
 let time=0,nextRAF=0,currentRoot;const created=[],scheduled=new Map();
 class Color{constructor(r=255,g=255,b=255,a=255){Object.assign(this,{r,g,b,a});}}
 class Node{
  constructor(name){Object.assign(this,{name,x:0,y:0,width:10,height:10,scaleX:1,scaleY:1,angle:0,anchorX:.5,anchorY:.5,zIndex:0,active:true,isValid:true,opacity:255,color:new Color(),children:[],parent:null,comps:[],group:'default'});this._components=this.comps;created.push(this);}
  get activeInHierarchy(){return this.parent?this.active&&this.parent.activeInHierarchy:true;}
  addChild(n){if(n.parent)n.removeFromParent();n.parent=this;this.children.push(n);}
  removeFromParent(){if(this.parent){this.parent.children.splice(this.parent.children.indexOf(this),1);this.parent=null;}}
  destroy(){this.isValid=false;this.children.forEach(c=>c.destroy());}
  addComponent(C){const c=new C();c.node=this;this.comps.push(c);return c;}
  getComponent(C){return this.comps.find(c=>c instanceof C)||null;}
  convertToWorldSpaceAR(p){let n=this,x=p.x,y=p.y;while(n){const a=n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=x*n.scaleX,yy=y*n.scaleY;x=c*xx-s*yy+n.x;y=s*xx+c*yy+n.y;n=n.parent;}return{x,y};}
  convertToNodeSpaceAR(p){const chain=[];let n=this,x=p.x,y=p.y;while(n){chain.push(n);n=n.parent;}for(n of chain.reverse()){x-=n.x;y-=n.y;const a=-n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=c*x-s*y,yy=s*x+c*y;x=xx/n.scaleX;y=yy/n.scaleY;}return{x,y};}
 }
 class Sprite{constructor(){this.enabled=true;this.type=0;this.trim=true;}get enabledInHierarchy(){return this.enabled&&this.node.activeInHierarchy;}}Sprite.Type={SIMPLE:0};Sprite.SizeMode={CUSTOM:0};
 class Graphics{constructor(){this.commands=[];this.clears=0;}clear(){this.commands=[];this.clears++;}moveTo(x,y){this.commands.push(['M',x,y]);}lineTo(x,y){this.commands.push(['L',x,y]);}close(){this.commands.push(['Z']);}fill(){this.commands.push(['fill']);}stroke(){this.commands.push(['stroke']);}circle(x,y,r){this.commands.push(['circle',x,y,r]);}}
 const cc={Node,Sprite,Graphics,Color,ENGINE_VERSION:'2.4.5',v2:(x,y)=>({x,y}),director:{getScene:()=>currentRoot},Canvas:{instance:{node:null}}};
 const doc={hidden:false,visibilityState:'visible',querySelector:()=>({getBoundingClientRect:()=>({width:viewportWidth,height:viewportWidth*2666/1500})})};
 const win={cc,CocosEngine:'2.4.5',performance:{now:()=>time},requestAnimationFrame:fn=>{scheduled.set(++nextRAF,fn);return nextRAF;},cancelAnimationFrame:id=>scheduled.delete(id)};
 const context={window:win,document:doc,Map,WeakMap,Set,WeakSet,Date};vm.createContext(context);
 const overlay=vm.runInContext(source,context)(rootSource?vm.runInContext(rootSource,context):undefined);
 function newScene(){const scene=new Node('Scene');scene.active=false;const canvas=new Node('Canvas');canvas.width=1500;canvas.height=2666;scene.addChild(canvas);currentRoot=scene;cc.Canvas.instance.node=canvas;return {scene,canvas};}
 const initial=newScene();
 function frame(name,rect){const texture={loaded:true};return{name,getRect:()=>({x:rect[0],y:rect[1],width:rect[2],height:rect[3]}),getTexture:()=>texture};}
 function art(name,parent,w,h,fr){const n=new Node(name);n.width=w;n.height=h;parent.addChild(n);const sp=n.addComponent(Sprite);sp.spriteFrame=fr;return n;}
 function card({x=0,y=-850,face=true,alternateBack=false,parent=cc.Canvas.instance.node}={}){
  const n=new Node('Card');Object.assign(n,{width:224,height:295,x,y,scaleX:.8,scaleY:.8});parent.addChild(n);
  const shadow=new Node('Shadow');shadow.active=false;n.addChild(shadow);
  const base=art('Base',n,216,286,frame(BASE_NAME,[909,212,216,286]));
  const front=new Node('Front');front.width=224;front.height=295;front.active=face;n.addChild(front);
  const color=art('Color',front,210,280,frame('card_bg_red',[1590,212,210,280]));
  const decoration=new Node('Decoration');decoration.active=false;front.addChild(decoration);
  const symbol=art('Symbol',front,175,209,frame('num3_red',[1834,228,175,209]));
  const extra=new Node('Extra');extra.active=false;front.addChild(extra);
  const back=art('Back',n,224,295,alternateBack?frame(ALT_BACK_NAME,[1138,212,210,280]):frame('',[1357,208,224,295]));back.active=!face;
  return{node:n,base,front,color,symbol,back};
 }
 function hints(){const l=cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Colors');return l?l.children.filter(n=>n.name==='SDKtools Card Color'):[];}
 function layer(){return cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Colors');}
 function advance(ms){time+=ms;const q=[...scheduled.values()];scheduled.clear();q.forEach(fn=>fn(time));}
 return{cc,doc,win,context,overlay,frame,card,hints,layer,advance,created,scheduled,initial,newScene,viewportWidth,now:()=>time};
}
function plain(v){return JSON.parse(JSON.stringify(v));}
function attachCard(f,c,info={type:1,color:1,num:3},className='Card'){
 const component={__classname__:className,cardInfo:info,skinNode:c.front,bgSprite:c.color.getComponent(f.cc.Sprite),typeSprite:c.symbol.getComponent(f.cc.Sprite),backSprite:c.back.getComponent(f.cc.Sprite)};
 c.node._components.push(component);return component;
}
function currentArt(f,c,bg='card_bg_red',symbol='num3_red'){
 c.color.getComponent(f.cc.Sprite).spriteFrame=f.frame(bg,[1590,212,210,280]);
 c.symbol.getComponent(f.cc.Sprite).spriteFrame=f.frame(symbol,[1834,228,175,209]);
}
function hintBounds(f,hint){
 const unit=1500/f.viewportWidth,hw=11*unit,hh=11*unit;
 return{left:hint.x-hw,right:hint.x+hw,bottom:hint.y-hh,top:hint.y+hh};
}
function intersects(a,b){return a.left<b.right&&a.right>b.left&&a.bottom<b.top&&a.top>b.bottom;}
function cardBounds(f,card){
 const n=card.node,points=[[-112,-147.5],[112,-147.5],[112,147.5],[-112,147.5]].map(([x,y])=>f.layer().convertToNodeSpaceAR(n.convertToWorldSpaceAR({x,y})));
 return{left:Math.min(...points.map(p=>p.x)),right:Math.max(...points.map(p=>p.x)),bottom:Math.min(...points.map(p=>p.y)),top:Math.max(...points.map(p=>p.y))};
}

function graphic(f,index=0){return f.hints()[index].getComponent(f.cc.Graphics);}
function counts(r){return [r.shown,r.unknown,r.unavailable,r.unknownShown,r.special,r.candidates];}

module.exports={setup,plain,attachCard,currentArt,graphic,counts,hintBounds,intersects,cardBounds,source,BASE_NAME,ALT_BACK_NAME};

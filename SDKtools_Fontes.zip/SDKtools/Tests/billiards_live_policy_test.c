#include "../Sources/SDKtools/STBilliardsLivePolicy.h"
#include <limits.h>
#include <stdio.h>

static unsigned checks, failures;
#define CHECK(condition) do { checks++; if (!(condition)) { failures++; \
    fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #condition); } } while (0)

static const STBLContext table = { .sceneHandle=41, .sessionId=700,
    .cameraId=-101, .width=1170, .height=2532 };

static void test_projection_bounds(void) {
    /* Behind-camera projections and invalid numbers must never become visible
     * overlays, even when their screen coordinates look plausible. */
    CHECK(STBLValidPoint((STBLPoint){0, 0, 1}, 390, 844));
    CHECK(STBLValidPoint((STBLPoint){390, 844, 1}, 390, 844));
    CHECK(STBLValidPoint((STBLPoint){195, 422, 0.0001}, 390, 844));
    const STBLPoint invalid[] = {
        {-0.001, 422, 1}, {390.001, 422, 1},
        {195, -0.001, 1}, {195, 844.001, 1},
        {195, 422, 0}, {195, 422, -1},
        {NAN, 422, 1}, {195, NAN, 1}, {195, 422, NAN},
        {INFINITY, 422, 1}, {195, INFINITY, 1}, {195, 422, INFINITY}
    };
    for (unsigned i=0; i<sizeof invalid/sizeof invalid[0]; i++)
        CHECK(!STBLValidPoint(invalid[i], 390, 844));
    CHECK(!STBLValidPoint((STBLPoint){0, 0, 1}, 0, 844));
    CHECK(!STBLValidPoint((STBLPoint){0, 0, 1}, 390, -1));
    CHECK(!STBLValidPoint((STBLPoint){0, 0, 1}, NAN, 844));
    CHECK(!STBLValidPoint((STBLPoint){0, 0, 1}, 390, INFINITY));

    /* A Retina scale difference is valid; a rotated or mismatched viewport is
     * not. Keep tests on either side of the documented 2% aspect tolerance. */
    CHECK(STBLValidViewport(1170, 2532, 390, 844));
    CHECK(STBLValidViewport(1000, 500, 509, 250));
    CHECK(!STBLValidViewport(1000, 500, 511, 250));
    CHECK(STBLValidViewport(1000, 500, 491, 250));
    CHECK(!STBLValidViewport(1000, 500, 489, 250));
    CHECK(!STBLValidViewport(1170, 2532, 844, 390));
    CHECK(STBLValidViewport(16, 16, 16, 16));
    CHECK(STBLValidViewport(16384, 16384, 16384, 16384));
    const double invalidDimensions[] = {0, -1, 15.999, 16385, 1e100, NAN, INFINITY};
    for (unsigned i=0; i<sizeof invalidDimensions/sizeof invalidDimensions[0]; i++) {
        double value=invalidDimensions[i];
        CHECK(!STBLValidViewport(value, value, 390, 390));
        CHECK(!STBLValidViewport(1170, 1170, value, value));
    }
}

static void test_ball_identity(void) {
    /* An entire rack has one unique tag/number pair per ball. Rejected
     * observations must not reserve a slot and hide a later valid ball. */
    uint32_t mask=0;
    CHECK(!STBLValidIdentityBall(1, 0, NULL));
    CHECK(!STBLValidIdentityBall(0, -1, &mask));
    CHECK(!STBLValidIdentityBall(17, 16, &mask));
    CHECK(!STBLValidIdentityBall(INT64_MIN, 0, &mask));
    CHECK(!STBLValidIdentityBall(INT64_MAX, 0, &mask));
    CHECK(!STBLValidIdentityBall(1, 1, &mask));
    CHECK(!STBLValidIdentityBall(16, 0, &mask));
    CHECK(mask==0);
    for (int64_t tag=1; tag<=16; tag++)
        CHECK(STBLValidIdentityBall(tag, tag-1, &mask));
    CHECK(mask==UINT32_C(0xffff));
    for (int64_t tag=1; tag<=16; tag++)
        CHECK(!STBLValidIdentityBall(tag, tag-1, &mask));
    CHECK(mask==UINT32_C(0xffff));
    mask=0;
    CHECK(!STBLValidIdentityBall(4, 4, &mask));
    CHECK(STBLValidIdentityBall(4, 3, &mask));
    CHECK(mask==UINT32_C(8));
}

static STBLFrameGate fresh_gate(void) {
    STBLFrameGate gate={0};
    CHECK(STBLAcceptFrame(&gate, table, 100, 1.0)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
    CHECK(STBLAcceptFrame(&gate, table, 101, 1.1)==STBLFrameFresh);
    CHECK(gate.confirmed);
    return gate;
}

static void test_liveness(void) {
    STBLFrameGate gate={0};
    CHECK(STBLAcceptFrame(&gate, table, 50, 1.0)==STBLFrameWarmup);
    CHECK(STBLAcceptFrame(&gate, table, 50, 1.1)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
    CHECK(STBLAcceptFrame(&gate, table, 51, 1.2)==STBLFrameFresh);
    CHECK(STBLAcceptFrame(&gate, table, 51, 1.3)==STBLFrameDuplicate);
    CHECK(STBLAcceptFrame(&gate, table, 51, 1.4)==STBLFrameDuplicate);
    CHECK(gate.advancedAt==1.2);
    /* Polling the same frame must not extend its lifetime. */
    CHECK(STBLAcceptFrame(&gate, table, 51, 1.2+STBL_STALE_SECONDS+0.001)==STBLFrameReject);
    CHECK(!gate.confirmed);
    CHECK(STBLAcceptFrame(&gate, table, 52, 1.6)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
    CHECK(STBLAcceptFrame(&gate, table, 53, 1.7)==STBLFrameFresh);
    /* A resumed feed needs two recent observations even if its frame advanced. */
    CHECK(STBLAcceptFrame(&gate, table, 60, 3.0)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
    CHECK(STBLAcceptFrame(&gate, table, 62, 3.1)==STBLFrameFresh);
    CHECK(gate.confirmed);

    gate=fresh_gate();
    CHECK(STBLAcceptFrame(&gate, table, 101, gate.advancedAt+STBL_STALE_SECONDS)==STBLFrameReject);
    CHECK(!gate.confirmed);
    gate=fresh_gate();
    CHECK(STBLAcceptFrame(&gate, table, 102, gate.advancedAt+STBL_STALE_SECONDS)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
}

static void test_context_changes(void) {
    STBLContext replacement[] = {table, table, table, table, table};
    replacement[0].sceneHandle++;
    replacement[1].sessionId++;
    replacement[2].cameraId--;
    replacement[3].width++;
    replacement[4].height++;
    /* Every context dependency invalidates confirmation. A reused frame number
     * or camera pointer must not carry a previous table's overlay forward. */
    for (unsigned i=0; i<sizeof replacement/sizeof replacement[0]; i++) {
        STBLFrameGate gate=fresh_gate();
        CHECK(STBLAcceptFrame(&gate, replacement[i], 101, 1.2)==STBLFrameWarmup);
        CHECK(!gate.confirmed);
        CHECK(STBLContextEqual(gate.context, replacement[i]));
        CHECK(STBLAcceptFrame(&gate, replacement[i], 101, 1.3)==STBLFrameWarmup);
        CHECK(STBLAcceptFrame(&gate, replacement[i], 102, 1.4)==STBLFrameFresh);
        CHECK(STBLAcceptFrame(&gate, table, 103, 1.5)==STBLFrameWarmup);
        CHECK(!gate.confirmed);
    }
    STBLFrameGate gate=fresh_gate();
    CHECK(STBLAcceptFrame(&gate, table, 0, 1.2)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
    CHECK(STBLAcceptFrame(&gate, table, 1, 1.3)==STBLFrameFresh);
    CHECK(STBLAcceptFrame(&gate, table, 2, 1.0)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
    CHECK(STBLAcceptFrame(&gate, table, 3, 1.1)==STBLFrameFresh);
    CHECK(STBLAcceptFrame(&gate, table, UINT64_MAX, 1.2)==STBLFrameFresh);
    CHECK(STBLAcceptFrame(&gate, table, 0, 1.3)==STBLFrameWarmup);
    CHECK(!gate.confirmed);
}

static void test_invalid_frames(void) {
    STBLFrameGate gate={0};
    CHECK(STBLAcceptFrame(NULL, table, 1, 1.0)==STBLFrameReject);
    const double invalidTime[] = {0, -1, NAN, INFINITY};
    for (unsigned i=0; i<sizeof invalidTime/sizeof invalidTime[0]; i++)
        CHECK(STBLAcceptFrame(&gate, table, 1, invalidTime[i])==STBLFrameReject);
    STBLContext invalid[] = {table, table, table, table, table, table, table};
    invalid[0].sessionId=0;
    invalid[1].sessionId=-1;
    invalid[2].cameraId=0;
    invalid[3].width=15;
    invalid[4].height=15;
    invalid[5].width=16385;
    invalid[6].height=16385;
    for (unsigned i=0; i<sizeof invalid/sizeof invalid[0]; i++)
        CHECK(STBLAcceptFrame(&gate, invalid[i], 1, 1.0)==STBLFrameReject);
    CHECK(!gate.hasContext);
    CHECK(!gate.confirmed);
}

int main(void) {
    test_projection_bounds();
    test_ball_identity();
    test_liveness();
    test_context_changes();
    test_invalid_frames();
    printf("Billiards live policy: %u checks, %u failures\n", checks, failures);
    return failures ? 1 : 0;
}

#include "../Sources/SDKtools/STNewGameCapturePolicy.h"
#include <limits.h>
#include <stdio.h>
static unsigned checks, failures;
#define CHECK(condition) do { checks++; if (!(condition)) { failures++; fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #condition); } } while (0)
int main(void) {
    /* The new title is never inferred from a number; only eligible identities
     * may reach the separate visual confirmation step. */
    CHECK(!STNewGameCanConfirm(60, true));
    CHECK(!STNewGameCanConfirm(-1, true));
    CHECK(!STNewGameCanConfirm(LLONG_MIN, true));
    CHECK(!STNewGameCanConfirm(LLONG_MAX, true));
    CHECK(!STNewGameCanConfirm(1000001, true));
    CHECK(!STNewGameCanConfirm(61, false));
    CHECK(STNewGameCanConfirm(0, true));
    CHECK(STNewGameCanConfirm(61, true));
    CHECK(STNewGameCanConfirm(1000000, true));
    /* Identical numbers on a replacement webview/controller/document never
     * inherit the prior opt-in. A reload needs a new confirmation. */
    for (unsigned bindings = 0; bindings < 8; bindings++) {
        CHECK(STNewGameContextMatches(61, 61, (bindings & 1) != 0,
            (bindings & 2) != 0, (bindings & 4) != 0) == (bindings == 7));
    }
    CHECK(!STNewGameContextMatches(61, 62, true, true, true));
    CHECK(!STNewGameContextMatches(61, 60, true, true, true));
    CHECK(!STNewGameContextMatches(60, 60, true, true, true));
    CHECK(!STNewGameContextMatches(-1, -1, true, true, true));
    CHECK(!STNewGameContextMatches(LLONG_MAX, LLONG_MAX, true, true, true));
    printf("New game capture policy: %u checks, %u failures\n", checks, failures);
    return failures ? 1 : 0;
}

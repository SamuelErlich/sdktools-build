'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_flow.js'),'utf8');
const {fixture}=require('./card_flow_fixture.cjs');
test('explicit factory is inert; first tick binds exact live modules without requests',()=>{
  const f=fixture();assert.equal(f.requests(),0);assert.equal(f.loads.length,0);const out=f.tick();assert.equal(out.status,'ready');assert.deepEqual(f.loads,['Card','GameStore','Socket']);assert.equal(f.requests(),0);assert.equal(out.events[0].stage,'store_snapshot');assert.equal(out.events[0].cards[0].color,0);f.runtime.clear();
});
test('decoded sync precedes store and visual events, copying values before mutations',async()=>{
  const f=fixture();f.tick();const card={id:64,type:1,color:3,num:3};const payload={gamers:[{uid:'PRIVATE',cards:[card]}],start_time:123};
  const promise=f.socket.sync();assert.equal(promise,f.response);promise.then(value=>{f.store.sync(value);f.component.setup(value.gamers[0].cards[0]);});f.resolve(payload);await promise;await Promise.resolve();
  card.color=4;const out=f.tick();assert.deepEqual(out.events.map(x=>x.stage),['socket_sync_result','store_input','store_after','card_setup_input','card_setup_after']);
  assert.ok(out.events.every(x=>x.cards[0].color===3));assert.equal(new Set(out.events.map(x=>x.cards[0].objectID)).size,1);assert.equal(f.requests(),1);assert.equal(out.events[1].callID,out.events[2].callID);assert.equal(out.events[3].callID,out.events[4].callID);f.runtime.clear();
});
test('wrapper preserves this, argument identity, return identity and thrown identity',()=>{
  const f=fixture();const token={},args=[{},'extra'];let observed;
  f.store.sync=function(){observed={self:this,args:Array.from(arguments)};return token;};f.socket.pushHandler=function(){throw token;};
  f.tick();assert.equal(f.store.sync(...args),token);assert.equal(observed.self,f.store);assert.equal(observed.args[0],args[0]);assert.equal(observed.args[1],args[1]);assert.throws(()=>f.socket.pushHandler('event',{}),e=>e===token);f.runtime.clear();
});
test('push and update messages capture only allowed card fields before forwarding',()=>{
  const f=fixture();f.tick();const payload={cards:[{id:37,type:6,color:0,num:0,token:'PRIVATE'}],card:{id:9,type:0,color:0,num:0},uid:'PRIVATE',message:'PRIVATE'};
  assert.equal(f.socket.pushHandler(5,payload),payload);f.store.updatePushMessage(payload);const out=f.tick();assert.deepEqual(out.events.map(x=>x.stage),['push_input','store_update_input','store_update_after']);assert.ok(!JSON.stringify(out).includes('PRIVATE'));assert.equal(out.events[0].pushEvent,5);f.runtime.clear();
});
test('missing, getter, invalid and unknown fields never become invented zero',()=>{
  const f=fixture();f.tick();let invoked=0;const card={id:22,color:NaN,num:-1,unknown:'secret'};Object.defineProperty(card,'type',{get(){invoked++;return 1;}});f.component.setup(card);const out=f.tick();assert.equal(invoked,0);assert.equal(out.events[0].cards[0].present,1);assert.ok(!('color' in out.events[0].cards[0]));assert.ok(!('type' in out.events[0].cards[0]));f.runtime.clear();
});
test('stop restores inherited and own descriptors exactly; clear is idempotent',()=>{
  const f=fixture(),push=Object.getOwnPropertyDescriptor(f.socket,'pushHandler'),setup=Object.getOwnPropertyDescriptor(f.Card.prototype,'setup');f.tick();assert.ok(Object.hasOwn(f.store,'sync'));f.runtime.clear();f.runtime.clear();assert.ok(!Object.hasOwn(f.store,'sync'));assert.ok(!Object.hasOwn(f.socket,'sync'));assert.deepEqual(Object.getOwnPropertyDescriptor(f.socket,'pushHandler'),push);assert.deepEqual(Object.getOwnPropertyDescriptor(f.Card.prototype,'setup'),setup);assert.equal(f.timer(),null);
});
test('watchdog removes wrappers after lost native heartbeat without another tick',()=>{
  const f=fixture();f.tick();f.advance(1900);assert.ok(!Object.hasOwn(f.store,'sync'));assert.equal(f.tick().reason,'lease_expired');
});
test('regular native heartbeat renews lease and absolute deadline remains bounded',()=>{
  const f=fixture();f.tick();for(let i=0;i<180;i++){f.advance(500);f.tick();}assert.equal(f.tick().reason,'duration_limit');assert.ok(!Object.hasOwn(f.store,'sync'));
});
test('scene or visibility transition stops before recording next call',()=>{
  for(const which of ['scene','hidden']){const f=fixture();f.tick();if(which==='scene')f.changeScene();else f.context.document.hidden=true;f.component.setup({id:2,type:1,color:1,num:1});const out=f.tick();assert.equal(out.status,'stopped');assert.equal(out.events.length,0);assert.ok(!Object.hasOwn(f.store,'sync'));}
});
test('foreign replacement is preserved and remaining observers are removed',()=>{
  const f=fixture();f.tick();const foreign=()=>1;f.socket.pushHandler=foreign;const out=f.tick();assert.equal(out.reason,'method_replaced');assert.equal(f.socket.pushHandler,foreign);assert.ok(!Object.hasOwn(f.store,'sync'));
});
test('partial installation failure rolls back every successful mutation',()=>{
  const f=fixture();Object.defineProperty(f.Card.prototype,'setup',{value:f.Card.prototype.setup,writable:false,configurable:false});const before=f.socket.pushHandler;const out=f.tick();assert.equal(out.reason,'install_failed');assert.ok(!Object.hasOwn(f.store,'sync'));assert.ok(!Object.hasOwn(f.socket,'sync'));assert.equal(f.socket.pushHandler,before);
});
test('unverified engine and mismatched Card module refuse all instrumentation',()=>{
  const a=fixture({context:{cc:{ENGINE_VERSION:'3.8'}}});assert.equal(a.tick().reason,'unsupported_engine');assert.equal(a.loads.length,0);
  const b=fixture();b.modules.Card.default=class AnotherCard{};assert.equal(b.tick().reason,'module_contract_mismatch');assert.ok(!Object.hasOwn(b.store,'sync'));assert.equal(b.requests(),0);
});
test('queue pressure is explicit, bounded and does not prevent original calls',()=>{
  const f=fixture();f.tick();for(let i=0;i<200;i++)assert.equal(f.component.setup(f.info),f.info);const out=f.tick();assert.ok(out.dropped>0);assert.ok(out.events.length<=96);assert.ok(JSON.stringify(out).length<65536);f.runtime.clear();
});
test('oversized hands and arrays are clipped with explicit truncation',()=>{
  const f=fixture();f.store.gamers=Array.from({length:12},()=>({cards:Array.from({length:400},(_,id)=>({id,type:0,color:0,num:0}))}));const out=f.tick();assert.ok(out.events[0].truncated);assert.ok(out.events[0].cards.length<=256);assert.ok(JSON.stringify(out).length<65536);f.runtime.clear();
});
test('pending promise settles after stop without recording or reinstalling hooks',async()=>{
  const f=fixture();f.tick();const promise=f.socket.sync();f.runtime.clear();f.resolve({gamers:[{cards:[f.info]}]});await promise;await Promise.resolve();assert.equal(f.tick().events.length,0);assert.ok(!Object.hasOwn(f.store,'sync'));
});
test('rejected original promise remains the original rejection and observer is handled',async()=>{
  const f=fixture();f.tick();const token={};const promise=f.socket.sync();f.reject(token);await assert.rejects(promise,e=>e===token);await Promise.resolve();assert.ok(f.tick().errors>=1);f.runtime.clear();
});

test('unrelated text and gift pushes are forwarded without data collection',()=>{
  const f=fixture();f.tick();const payload={card:{id:1,type:1,color:1,num:1}};
  for(const event of [14,1001,'private-event'])assert.equal(f.socket.pushHandler(event,payload),payload);
  assert.equal(f.tick().events.length,0);f.runtime.clear();
});

test('explicit cleanup discards undrained tail and pending callbacks cannot retain game state through the queue',()=>{
  const f=fixture();f.tick();f.component.setup(f.info);f.runtime.clear();const out=f.tick();assert.equal(out.events.length,0);assert.equal(out.queued,0);assert.equal(out.reason,'explicit_stop');
});

#if defined(__APPLE__)
#ifndef _DARWIN_C_SOURCE
#define _DARWIN_C_SOURCE 1
#endif
#else
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#endif
#include "../Sources/SDKtools/STBilliardsResourceIO.h"
#include <stdio.h>
static unsigned checks, failures;
#define CHECK(value) do { checks++; if(!(value)){failures++;fprintf(stderr,"FAIL %d: %s\n",__LINE__,#value);} } while(0)
typedef struct { unsigned char data[65536];size_t n; } Buffer;
static void varint(Buffer *b,uint64_t v){do{unsigned char x=(unsigned char)(v&127);v>>=7;b->data[b->n++]=(unsigned char)(x|(v?128:0));}while(v);}
static void number(Buffer *b,unsigned f,uint64_t v){varint(b,(uint64_t)f<<3);varint(b,v);}
static void span(Buffer *b,unsigned f,const void *p,size_t n){varint(b,((uint64_t)f<<3)|2);varint(b,n);if(n)memcpy(b->data+b->n,p,n);b->n+=n;}
static void text(Buffer *b,unsigned f,const char *s){span(b,f,s,strlen(s));}
static const char *name="billiard_cres_0123456789abcdef0123456789abcdef";
static const char *hash="abcdef0123456789abcdef0123456789";
static Buffer record(const char *n,uint64_t size){Buffer b={{0},0};text(&b,1,n);text(&b,2,hash);number(&b,6,size);return b;}
static Buffer manifest(Buffer *r){Buffer b={{0},0};number(&b,1,20);number(&b,2,1047);span(&b,7,r->data,r->n);return b;}
static STBRParseStatus parse(Buffer *b,STBRManifest *m){return STBRParseManifest(b->data,b->n,m);}
static void put(int root,const char *path,const void *bytes,size_t n){int fd=openat(root,path,O_CREAT|O_EXCL|O_WRONLY,0600);CHECK(fd>=0);if(fd>=0){CHECK(write(fd,bytes,n)==(ssize_t)n);close(fd);}}
static void parser_tests(const char *fixture){
    STBRManifest *m=calloc(1,sizeof(*m));CHECK(m!=NULL);if(!m)return;
    Buffer r=record(name,90),b=manifest(&r);
    CHECK(parse(&b,m)==STBRParseOK);CHECK(m->gameId==20&&m->version==1047&&m->recordCount==1&&m->selectedCount==1&&m->selectedDeclaredBytes==90);
    CHECK(!strcmp(m->records[0].name,name)&&!strcmp(m->records[0].md5,hash)&&m->records[0].declaredSize==90&&m->records[0].category==STBRCategoryCres);
    CHECK(STBRCategoryForName("billiard_model_0123456789abcdef0123456789abcdef")==STBRCategoryModel);
    CHECK(STBRCategoryForName("billiard_scene_0123456789abcdef0123456789abcdef")==STBRCategoryScene);
    CHECK(STBRCategoryForName("billiard_prefabs_0123456789abcdef0123456789abcdef")==STBRCategoryPrefabs);
    CHECK(STBRCategoryForName("billiard_physicmaterials_0123456789abcdef0123456789abcdef")==STBRCategoryPhysicMaterials);
    CHECK(STBRCategoryForName("billiard_cres_0123456789abcdef0123456789abcde")==STBRCategoryNone);
    CHECK(STBRCategoryForName("billiard_cres_0123456789abcdef0123456789abcdef_extra")==STBRCategoryNone);
    CHECK(STBRCategoryForName("billiard_cres_0123456789abcdef0123456789abcdeg")==STBRCategoryNone);
    CHECK(STBRCategoryForName(NULL)==STBRCategoryNone);
    const char *excluded[]={"billiard_textures_0123456789abcdef0123456789abcdef","billiard_audiores_0123456789abcdef0123456789abcdef","billiard_fairygui_0123456789abcdef0123456789abcdef","alpaca_cres_0123456789abcdef0123456789abcdef"};
    for(size_t i=0;i<sizeof(excluded)/sizeof(excluded[0]);i++){r=record(excluded[i],30u*1024u*1024u);b=manifest(&r);CHECK(parse(&b,m)==STBRParseOK);CHECK(m->selectedCount==0&&!m->records[0].selected);}
    r=record(name,STBR_MAX_FILE+1u);b=manifest(&r);CHECK(parse(&b,m)==STBRParseOK);CHECK(m->records[0].declaredSize>STBR_MAX_FILE); /* Oversize is a per-file skip, not silent truncation. */
    r=record(name,90);b=manifest(&r);number(&b,1,20);CHECK(parse(&b,m)==STBRParseDuplicateIdentity);CHECK(m->recordCount==0&&m->selectedCount==0);
    b=manifest(&r);number(&b,2,1047);CHECK(parse(&b,m)==STBRParseDuplicateIdentity);
    b=manifest(&r);span(&b,7,r.data,r.n);CHECK(parse(&b,m)==STBRParseDuplicateIdentity);
    r=record(name,90);text(&r,1,name);b=manifest(&r);CHECK(parse(&b,m)==STBRParseDuplicateIdentity);
    r=record(name,90);text(&r,2,hash);b=manifest(&r);CHECK(parse(&b,m)==STBRParseDuplicateIdentity);
    r=record(name,90);number(&r,6,91);b=manifest(&r);CHECK(parse(&b,m)==STBRParseDuplicateIdentity);
    r=record(name,90);b=manifest(&r);b.data[1]=21;CHECK(parse(&b,m)==STBRParseWrongGame);
    b=manifest(&r);b.data[0]=10;CHECK(parse(&b,m)==STBRParseWrongWire);
    b=manifest(&r);b.data[b.n++]=0;CHECK(parse(&b,m)==STBRParseMalformed);
    b=manifest(&r);b.data[b.n++]=0x80;CHECK(parse(&b,m)==STBRParseMalformed);
    b=manifest(&r);b.data[b.n++]=0x4b;CHECK(parse(&b,m)==STBRParseMalformed); /* Unsupported groups. */
    b=manifest(&r);varint(&b,((uint64_t)8<<3)|2);varint(&b,UINT64_MAX);CHECK(parse(&b,m)==STBRParseMalformed);
    b=manifest(&r);varint(&b,(uint64_t)8<<3);for(unsigned i=0;i<9;i++)b.data[b.n++]=0xff;b.data[b.n++]=2;CHECK(parse(&b,m)==STBRParseMalformed);
    b=manifest(&r);text(&b,8,"unknown permitted field");CHECK(parse(&b,m)==STBRParseOK);
    b=manifest(&r);varint(&b,((uint64_t)8<<3)|1);for(unsigned i=0;i<8;i++)b.data[b.n++]=0;CHECK(parse(&b,m)==STBRParseOK);
    b=manifest(&r);b.n--;CHECK(parse(&b,m)==STBRParseMalformed);
    const char *unsafe[]={"../secret","/absolute","billiard_cres_hash/file","billiard_cres_hash\\file",".hidden","bad\nname","bad%2fname"};
    for(size_t i=0;i<sizeof(unsafe)/sizeof(unsafe[0]);i++){r=record(unsafe[i],90);b=manifest(&r);CHECK(parse(&b,m)==STBRParseInvalidName);}
    r=(Buffer){{0},0};const unsigned char nulname[]={'a',0,'b'};span(&r,1,nulname,sizeof(nulname));text(&r,2,hash);number(&r,6,90);b=manifest(&r);CHECK(parse(&b,m)==STBRParseInvalidName);
    r=(Buffer){{0},0};text(&r,1,name);text(&r,2,"abcdef");number(&r,6,90);b=manifest(&r);CHECK(parse(&b,m)==STBRParseInvalidMD5);
    r=(Buffer){{0},0};text(&r,1,name);text(&r,2,"zbcdef0123456789abcdef0123456789");number(&r,6,90);b=manifest(&r);CHECK(parse(&b,m)==STBRParseInvalidMD5);
    r=record(name,0);b=manifest(&r);CHECK(parse(&b,m)==STBRParseInvalidSize);
    r=record(name,UINT64_MAX);b=manifest(&r);CHECK(parse(&b,m)==STBRParseInvalidSize);
    r=(Buffer){{0},0};text(&r,1,name);text(&r,2,hash);b=manifest(&r);CHECK(parse(&b,m)==STBRParseMissingIdentity);
    r=record(name,90);Buffer dependencies={{0},0};varint(&dependencies,128);varint(&dependencies,16384);span(&r,5,dependencies.data,dependencies.n);number(&r,5,1);b=manifest(&r);CHECK(parse(&b,m)==STBRParseOK);
    r=record(name,90);const unsigned char truncated[]={0x80};span(&r,5,truncated,sizeof(truncated));b=manifest(&r);CHECK(parse(&b,m)==STBRParseMalformed);
    b=(Buffer){{0},0};number(&b,1,20);number(&b,2,1047);
    for(unsigned i=0;i<STBR_MAX_RECORDS;i++){char unique[64];snprintf(unique,sizeof(unique),"unselected_%u",i);r=record(unique,90);span(&b,7,r.data,r.n);}
    CHECK(parse(&b,m)==STBRParseOK&&m->recordCount==STBR_MAX_RECORDS);
    r=record("unselected_extra",90);span(&b,7,r.data,r.n);CHECK(parse(&b,m)==STBRParseTooManyRecords);
    CHECK(STBRParseManifest(NULL,0,m)==STBRParseInvalidArgument);CHECK(STBRParseManifest(b.data,b.n,NULL)==STBRParseInvalidArgument);
    CHECK(STBRParseManifest(b.data,STBR_MAX_MANIFEST+1u,m)==STBRParseTooLarge);
    FILE *file=fopen(fixture,"rb");CHECK(file!=NULL);
    if(file){unsigned char original[4096];size_t n=fread(original,1,sizeof(original),file);CHECK(!ferror(file)&&feof(file));fclose(file);CHECK(n==1423);CHECK(STBRParseManifest(original,n,m)==STBRParseOK);CHECK(m->gameId==20&&m->version==1047&&m->recordCount==14&&m->selectedCount==5&&m->selectedDeclaredBytes==293452);CHECK(!strcmp(m->records[6].name,"billiard_cres_472fa237e9f2357c3acb79e40b4f27c5"));CHECK(!strcmp(m->records[6].md5,"42cec827ff21fff1e31e8a9a70d1811f"));CHECK(m->records[6].declaredSize==90072);}
    free(m);
}
static void io_tests(void){
    char pattern[]="/tmp/sdktools-billiards-io.XXXXXX";char *directory=mkdtemp(pattern);CHECK(directory!=NULL);if(!directory)return;
    int root=open(directory,O_RDONLY|O_DIRECTORY|O_NOFOLLOW);CHECK(root>=0);if(root<0)return;
    struct stat rootStat;CHECK(!fstat(root,&rootStat));unsigned char binary[]={0,255,1,2,3,0,4,5,6};put(root,"bundle",binary,sizeof(binary));
    unsigned char *bytes=NULL;size_t size=0;STBRReceipt receipt;double deadline=STGSNow()+10;
    CHECK(STBRRead(root,"bundle",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadOK);
    CHECK(bytes&&size==sizeof(binary)&&!memcmp(bytes,binary,size)&&receipt.valid);free(bytes);bytes=NULL;
    CHECK(STBRRevalidate(root,"bundle",&receipt));STBRReceipt original=receipt;
    CHECK(STBRRead(root,"bundle",rootStat.st_dev,2,deadline,&bytes,&size,&receipt)==STBRReadSizeLimit);CHECK(!bytes&&!size&&!receipt.valid);
    CHECK(STBRRead(root,"bundle",rootStat.st_dev,0,deadline,&bytes,&size,&receipt)==STBRReadInvalidArgument);
    CHECK(STBRRead(root,"bundle",rootStat.st_dev,STBR_MAX_FILE,NAN,&bytes,&size,&receipt)==STBRReadInvalidArgument);
    CHECK(STBRRead(root,"bundle",rootStat.st_dev,STBR_MAX_FILE,STGSNow()-1,&bytes,&size,&receipt)==STBRReadTimeout);
    CHECK(STBRRead(root,"bundle",rootStat.st_dev+1,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadUnsafeFile);
    CHECK(STBRRead(root,"../bundle",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadInvalidArgument);
    CHECK(STBRRead(root,"absent",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadUnavailable);
    CHECK(!symlinkat("bundle",root,"symlink"));CHECK(STBRRead(root,"symlink",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadUnavailable);CHECK(!STBRRevalidate(root,"symlink",&original));
    CHECK(!linkat(root,"bundle",root,"hardlink",0));CHECK(STBRRead(root,"bundle",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadUnsafeFile);CHECK(!STBRRevalidate(root,"bundle",&original));CHECK(!unlinkat(root,"hardlink",0));
    CHECK(!mkdirat(root,"child",0700));CHECK(STBRRead(root,"child",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadUnsafeFile);
    CHECK(!symlinkat("child",root,"linked_child"));CHECK(STBRRead(root,"linked_child/anything",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadUnavailable);
    CHECK(!mkfifoat(root,"pipe",0600));CHECK(STBRRead(root,"pipe",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadUnsafeFile);
    int fd=openat(root,"oversize",O_CREAT|O_EXCL|O_WRONLY,0600);CHECK(fd>=0);if(fd>=0){CHECK(!ftruncate(fd,STBR_MAX_FILE+1u));close(fd);}
    CHECK(STBRRead(root,"oversize",rootStat.st_dev,SIZE_MAX,deadline,&bytes,&size,&receipt)==STBRReadSizeLimit);
    CHECK(STBRRead(root,"bundle",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadOK);free(bytes);bytes=NULL;original=receipt;
    fd=openat(root,"bundle",O_WRONLY|O_APPEND);CHECK(fd>=0);if(fd>=0){CHECK(write(fd,"x",1)==1);close(fd);}CHECK(!STBRRevalidate(root,"bundle",&original)); /* Changed after read. */
    CHECK(STBRRead(root,"bundle",rootStat.st_dev,STBR_MAX_FILE,deadline,&bytes,&size,&receipt)==STBRReadOK);free(bytes);bytes=NULL;original=receipt;
    CHECK(!renameat(root,"bundle",root,"old_inode"));put(root,"bundle",binary,sizeof(binary));CHECK(!STBRRevalidate(root,"bundle",&original)); /* Replaced pathname. */
    const char *files[]={"bundle","old_inode","symlink","linked_child","pipe","oversize"};
    for(size_t i=0;i<sizeof(files)/sizeof(files[0]);i++){CHECK(!unlinkat(root,files[i],0));}
    CHECK(!unlinkat(root,"child",AT_REMOVEDIR));close(root);CHECK(!rmdir(directory));
}
int main(int argc,char **argv){if(argc!=2){fprintf(stderr,"fixture path required\n");return 2;}parser_tests(argv[1]);io_tests();printf("Billiards resource IO: %u checks, %u failures\n",checks,failures);return failures?1:0;}

'use strict';
// SDKtools module tests with explicit synthetic collaborators, not game/runtime execution.
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_covered.js'),'utf8');
const reasonSet=new Set(['not_armed','observer_unavailable','context_unavailable','candidate_unavailable','external_mode_active',
 'original_pending','mode_disabled','no_covered_candidate','action_disabled','xray_required','observing_board','no_covered_card',
 'invoking_original','awaiting_server','awaiting_original_settlement','server_200','server_rejected','awaiting_stability',
 'effect_not_confirmed','response_timeout','socket_closed','context_changed','original_exception','outbound_not_observed',
 'request_mismatch','response_mismatch','observer_restore_failed','cancelled_uncertain',
 'penetrate_unavailable','penetrate_stock_not_zero','penetrate_id_unverified','recovery_timeout','secure_transport_required']);

function fixture(options={}){
 let time=100,sequence=0,nextTimer=0,invocations=0,otherMessages=0;
 const timers=new Map(),listeners=new Map(),wire=[],calls=[],returns=[];
 const root={},board={},tray={},game={},layer={},doc={visibilityState:'visible'},cc={ENGINE_VERSION:'2.4.4',director:{getScene(){return root;}}};
 const store={uid:'fixture-player',rid:'fixture-room',start_time:123,state:2,isWatcher:false,isHotTiming:false,isAddingCommonBlock:false,
  isUsingPenetrateProp:false,isCanTouchBlock:true,gamers:[{uid:'fixture-player',state:1}],pile_blocks:[],hand_blocks:[],storage_blocks:[],
  props_blocks:options.kind==='penetrate_zero'?[{type:3,count:0,id:'3-fixture-player'}]:[]};
 const rawID='fixture-card-0-0',info={id:rawID,type:2,state:0},node={parent:board},block={node,isValid:true,blockInfo:info};
 const button={isValid:true,enabled:true,enabledInHierarchy:true,interactable:false},event={target:node,handler:'touchBlock'};
 const mapNode=new Map([[rawID,node]]);
 store.pile_blocks=[info];
 const ws={readyState:1,url:'wss://fixture.invalid/ws',
  addEventListener(name,fn){if(options.addFails===name)throw Error('listener failure');if(!listeners.has(name))listeners.set(name,new Set());listeners.get(name).add(fn);},
  removeEventListener(name,fn){listeners.get(name)?.delete(fn);},
  send(data){assert.equal(this,ws);if(options.sendThrows)throw options.sendThrows;wire.push(data);if(options.sendPrefix)options.sendPrefix(data);}};
 const socket={uid:store.uid,rid:store.rid,socket:ws,packetId:41,responseMap:{},
  async send(command,param={}){
   if(this.socket&&this.socket.readyState===1){param.rid=this.rid;param.uid=this.uid;return new Promise((resolve,reject)=>{
    this.responseMap[this.packetId]={resolve,reject};this.socket.send(JSON.stringify({packet_id:this.packetId,command,param}));this.packetId++;});}
  },
  TouchBlock(id,state){assert.equal(this,socket);calls.push([...arguments]);return this.send('CMD_TOUCH_BLOCK',{block_id:id,block_state:state});},
  UseProp(propID,id){assert.equal(this,socket);calls.push([...arguments]);return this.send('CMD_USE_PROP',{prop_id:propID,block_id:id});},
  onMessage({data}){
   let value;try{value=JSON.parse(data);}catch(_){value={};}
   const {packet_id:pid,code,message}=value;
   // Models original decode-before-resolve; no JS recovered module is executed.
   if(value.body_encoding)throw Error('synthetic decode failure');
   const entry=this.responseMap[pid];if(pid&&entry){if(code===200)entry.resolve(value.data);else entry.reject(message);}
  }};
 const originalTouch=socket.TouchBlock,originalUseProp=socket.UseProp,originalSend=ws.send;
 ws.onmessage=socket.onMessage.bind(socket);ws.onclose=()=>{otherMessages++;};
 const originalOnmessage=ws.onmessage,originalOnclose=ws.onclose;
 const win={cc,__require(name){return {default:name==='GameStore'?store:name==='Socket'?socket:null};}};win.top=win;
 const context=vm.createContext({window:win,document:doc,performance:{now:()=>time},Date,Promise,
  setTimeout(fn,delay){const id=++nextTimer;timers.set(id,{fn,at:time+delay});return id;},clearTimeout(id){timers.delete(id);}});
 const make=vm.runInContext(source,context,{timeout:1000}),runtime=make();
 function snapshot(){
  const refs=new Map();
  for(const [zone,list] of [['board',store.pile_blocks],['tray',store.hand_blocks],['reserve',store.storage_blocks.flat()]]){
   for(const row of list){let n=mapNode.get(row.id);if(!n){n={parent:zone==='board'?board:tray};mapNode.set(row.id,n);}
    const c={id:row.id===rawID?'local-card':'local-other-'+row.id,rawID:row.id,type:'type:'+row.type,zone,node:n,
     masked:zone==='board',blockedBy:zone==='board'?['local-blocker']:[],selectable:true,
     metadata:{rawID:row.id,type:'type:'+row.type,state:row.state,specialType:0,lock:0,canTouch:zone==='board'?false:true,block:row.id===rawID?block:{isValid:true,node:n,blockInfo:row}},
     action:{receiver:row.id===rawID?block:null,button,event}};refs.set(c.id,c);
   }
  }
  const signature=JSON.stringify([...refs.values()].map(c=>[c.rawID,c.type,c.zone]));
  return {cc,root,board,refs,signature,playState:{store,game,layer,uid:store.uid,rid:store.rid,start:store.start_time}};
 }
 function move(zone='tray'){
  store.pile_blocks=store.pile_blocks.filter(v=>v.id!==rawID);store.hand_blocks=store.hand_blocks.filter(v=>v.id!==rawID);
  if(zone==='board'){info.state=0;store.pile_blocks.push(info);node.parent=board;}
  else if(zone==='tray'){info.state=1;store.hand_blocks.push(info);node.parent=tray;}
  else node.parent=null;
 }
 function invoke(){invocations++;if(options.invokePrefix)options.invokePrefix();
  if(options.optimistic===true||options.optimistic!==false&&options.kind!=='penetrate_zero')move('tray');
  const promise=options.kind==='penetrate_zero'?socket.UseProp('3-fixture-player',rawID):socket.TouchBlock(rawID,0);
  returns.push(promise);Promise.prototype.then.call(promise,()=>{},()=>{});if(options.invokeThrows)throw options.invokeThrows;}
 function emit(name,e){for(const fn of [...(listeners.get(name)||[])])fn(e);}
 function reply(code=200,{pid=41,trusted=true,target=ws,raw,original=true,extra={}}={}){
  const e={isTrusted:trusted,target,data:raw===undefined?JSON.stringify({packet_id:pid,code,data:{notExported:true},message:'fixture rejection',...extra}):raw};
  if(original){try{ws.onmessage(e);}catch(_){}}
  emit('message',e);return e;
 }
 function dispatch(){const s=snapshot();return runtime.dispatch(s,s.refs.get('local-card'),invoke,{kind:options.kind||'touch'});}
 return {context,win,doc,cc,root,board,tray,store,node,block,button,event,info,socket,ws,wire,calls,returns,timers,listeners,runtime,
  originalTouch,originalUseProp,originalSend,originalOnmessage,originalOnclose,snapshot,move,invoke,dispatch,reply,emit,
  invocations:()=>invocations,otherMessages:()=>otherMessages,
  setTime(ms){time=ms;},time:()=>time,
  advance(ms){time+=ms;for(const [id,v]of [...timers])if(v.at<=time){timers.delete(id);v.fn();}},
  tick(){runtime.observe(snapshot());return runtime.diagnostic();},
  listenerCount(){return [...listeners.values()].reduce((n,s)=>n+s.size,0);}};
}
async function flush(){for(let i=0;i<6;i++)await Promise.resolve();}
async function acknowledged(f,code=200){assert.equal(f.dispatch(),true);f.reply(code);await flush();return f.runtime.diagnostic();}
function stable(f){f.tick();f.advance(79);let d=f.tick();assert.equal(d.pending,true);f.advance(1);return f.tick();}
function closed(d){assert.deepEqual(Object.keys(d).sort(),['attempts','effectObserved','pending','promiseSettled','reason','requestObserved','responseObserved','status','kind','responseOutcome','phase',...(d.serverCode===undefined?[]:['serverCode'])].sort());
 assert.ok(['touch','penetrate_zero'].includes(d.kind));assert.ok(['unknown','accepted','rejected'].includes(d.responseOutcome));assert.ok(['idle','response','recovery','blocked','complete'].includes(d.phase));
 assert.ok(['idle','blocked','submitted','accepted','rejected','uncertain'].includes(d.status));assert.ok(reasonSet.has(d.reason));
 assert.ok(Number.isInteger(d.attempts)&&d.attempts>=0&&d.attempts<=10000);assert.doesNotMatch(JSON.stringify(d),/fixture-player|fixture-room|fixture-card|message|token/);}

test('default is inert, closed and installs no observer or timer',()=>{const f=fixture(),d=f.runtime.diagnostic();closed(d);assert.equal(d.status,'idle');assert.equal(f.runtime.busy(),false);assert.equal(f.listenerCount(),0);assert.equal(f.timers.size,0);assert.equal(f.wire.length,0);assert.equal(f.socket.TouchBlock,f.originalTouch);});
test('one registered invoke preserves wire/this/return identity and original listeners',()=>{const f=fixture();assert.equal(f.dispatch(),true);assert.equal(f.invocations(),1);assert.equal(f.wire.length,1);assert.deepEqual(f.calls[0],['fixture-card-0-0',0]);assert.equal(f.socket.TouchBlock,f.originalTouch);assert.equal(f.ws.send,f.originalSend);assert.equal(f.ws.onmessage,f.originalOnmessage);assert.equal(f.ws.onclose,f.originalOnclose);assert.equal(f.returns.length,1);assert.equal(f.runtime.diagnostic().status,'submitted');closed(f.runtime.diagnostic());});
test('200 plus actual Promise settlement then two stable Store-consistent snapshots releases with effect',async()=>{const f=fixture();let d=await acknowledged(f);assert.equal(d.status,'accepted');assert.equal(d.pending,true);assert.equal(d.promiseSettled,true);assert.equal(d.responseObserved,true);d=stable(f);assert.equal(d.pending,false);assert.equal(d.effectObserved,true);assert.equal(d.serverCode,200);assert.equal(f.listenerCount(),0);assert.equal(f.timers.size,0);closed(d);});
test('200 acknowledgement without effect never fabricates effect or confirmedMoves',async()=>{const f=fixture({optimistic:false});await acknowledged(f);const d=stable(f);assert.equal(d.status,'accepted');assert.equal(d.effectObserved,false);assert.equal(d.reason,'effect_not_confirmed');assert.equal(d.pending,false);assert.equal(d.confirmedMoves,undefined);});
test('accepted consumed triple can be absent only after full consistent census',async()=>{const f=fixture();await acknowledged(f);f.move('gone');const d=stable(f);assert.equal(d.pending,false);assert.equal(d.effectObserved,true);});
test('500 rejection remains pending through optimistic animation and only releases after rollback',async()=>{const f=fixture();let d=await acknowledged(f,500);assert.equal(d.status,'rejected');assert.equal(d.pending,true);f.tick();f.advance(100);assert.equal(f.tick().pending,true);f.move('board');d=stable(f);assert.equal(d.pending,false);assert.equal(d.effectObserved,false);assert.equal(d.reason,'server_rejected');assert.equal(d.serverCode,500);});
test('optimistic visual and Store changes alone never release a pending attempt',async()=>{const f=fixture();f.dispatch();for(let i=0;i<3;i++){f.advance(100);f.tick();}await flush();assert.equal(f.runtime.busy(),true);assert.equal(f.runtime.diagnostic().promiseSettled,false);assert.equal(f.runtime.diagnostic().responseObserved,false);assert.equal(f.dispatch(),false);assert.equal(f.wire.length,1);});
test('wire header alone cannot stand in for original settlement',async()=>{const f=fixture();f.dispatch();f.reply(200,{original:false});await flush();assert.equal(f.runtime.diagnostic().responseObserved,true);assert.equal(f.runtime.diagnostic().promiseSettled,false);f.advance(200);f.tick();assert.equal(f.runtime.busy(),true);});
test('Promise settlement alone cannot stand in for trusted matching wire header',async()=>{const f=fixture();f.dispatch();f.socket.responseMap[41].resolve({});await flush();assert.equal(f.runtime.diagnostic().promiseSettled,true);assert.equal(f.runtime.diagnostic().responseObserved,false);f.advance(200);f.tick();assert.equal(f.runtime.busy(),true);});
test('compressed malformed body with trusted 200 remains uncertain at deadline',async()=>{const f=fixture();f.dispatch();f.reply(200,{extra:{body_encoding:1}});await flush();assert.equal(f.runtime.diagnostic().promiseSettled,false);f.advance(15000);assert.equal(f.runtime.diagnostic().status,'uncertain');});
for(const [wireCode,resolved]of[[200,false],[500,true]])test('header and settlement disagreement is latched '+wireCode,async()=>{const f=fixture();f.dispatch();const e=f.socket.responseMap[41];if(resolved)e.resolve({});else e.reject('fixture');f.reply(wireCode,{original:false});await flush();assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.diagnostic().reason,'response_mismatch');assert.equal(f.runtime.busy(),true);});
test('wrong, malformed, nested, string-code, oversized and page-created responses do not confirm',async()=>{const f=fixture();f.dispatch();f.reply(200,{pid:99});f.reply(200,{trusted:false});f.reply(200,{target:{}});f.reply('200',{original:false});f.reply(200,{raw:'not json',original:false});f.reply(200,{raw:'x'.repeat(262145),original:false});f.reply(200,{raw:JSON.stringify({packet_id:41,data:{code:200}}),original:false});await flush();assert.equal(f.runtime.diagnostic().responseObserved,false);assert.equal(f.runtime.busy(),true);});
test('late acknowledgement after timeout cannot clear latch, toggle or block does not reset it',async()=>{const f=fixture();f.dispatch();f.advance(15000);f.reply();await flush();f.runtime.invalidate();f.runtime.block('mode_disabled');assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.busy(),true);assert.equal(f.dispatch(),false);assert.equal(f.wire.length,1);});
test('close/error must be trusted and original close listener stays untouched',()=>{const f=fixture();f.dispatch();f.emit('close',{target:f.ws,isTrusted:false});assert.equal(f.runtime.diagnostic().status,'submitted');f.emit('close',{target:f.ws,isTrusted:true});assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.ws.onclose,f.originalOnclose);f.ws.onclose();assert.equal(f.otherMessages(),1);});
for(const [name,change]of[
 ['new responseMap',f=>{f.socket.responseMap={};}],['new physical socket',f=>{f.socket.socket={readyState:1};}],
 ['new round',f=>{f.store.start_time++;}],['new player',f=>{f.store.uid='other';}],['new room',f=>{f.socket.rid='other';}],
 ['new engine',f=>{f.win.cc={};}],['new loader',f=>{f.win.__require=()=>({});}],['new scene',f=>{f.cc.director.getScene=()=>({});}],
 ['new document',f=>{f.context.document={visibilityState:'visible'};}]
])test(name+' invalidates pending correlation permanently',()=>{const f=fixture();f.dispatch();change(f);f.runtime.observe(f.snapshot());assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.busy(),true);assert.equal(f.wire.length,1);});
test('incomplete Store census or duplicate identity cannot satisfy stability',async()=>{const f=fixture();await acknowledged(f);const s=f.snapshot();f.store.hand_blocks.push({...f.info});f.runtime.observe(s);f.advance(100);f.runtime.observe(s);assert.equal(f.runtime.busy(),true);});
test('incomplete scene snapshot or invalidation breaks consecutiveness',async()=>{const f=fixture();await acknowledged(f);f.tick();f.advance(60);f.runtime.invalidate();f.tick();f.advance(60);assert.equal(f.tick().pending,true);f.advance(20);assert.equal(f.tick().pending,false);});
test('changed stable signature restarts 80ms proof',async()=>{const f=fixture();await acknowledged(f);f.tick();f.advance(70);const s=f.snapshot();s.signature+='new';f.runtime.observe(s);f.advance(70);f.runtime.observe(s);assert.equal(f.runtime.busy(),true);f.advance(10);f.runtime.observe(s);assert.equal(f.runtime.busy(),false);});
test('a new preflight block after terminal resets flags but preserves cumulative attempts',async()=>{const f=fixture();await acknowledged(f);stable(f);const d=f.runtime.block('xray_required');assert.equal(d.status,'blocked');assert.equal(d.reason,'xray_required');assert.equal(d.attempts,1);for(const k of ['pending','requestObserved','responseObserved','promiseSettled','effectObserved'])assert.equal(d[k],false);assert.equal(d.serverCode,undefined);closed(d);});
test('unknown preflight reason is closed to candidate_unavailable',()=>{const f=fixture();const d=f.runtime.block('fixture-private-string');assert.equal(d.reason,'candidate_unavailable');closed(d);});

for(const kind of ['touch','penetrate_zero'])for(const url of [undefined,'ws://fixture.invalid/ws','https://fixture.invalid/ws',
 'wss://user:fixture@fixture.invalid/ws','wss://fixture.invalid/ws#fixture','wss://fixture.invalid/unsafe\npath'])
test(kind+' refuses missing or unsafe transport before original invocation '+String(url),()=>{
 const f=fixture({kind});f.ws.url=url;
 assert.equal(f.dispatch(),false);assert.equal(f.invocations(),0);assert.equal(f.wire.length,0);
 assert.equal(f.runtime.diagnostic().reason,'secure_transport_required');assert.equal(f.runtime.busy(),false);
 assert.equal(JSON.stringify(f.runtime.diagnostic()).includes('fixture.invalid'),false);
});
test('physical socket URL change invalidates correlation without leaking URL or retrying',()=>{
 const f=fixture();f.dispatch();f.ws.url='ws://fixture.invalid/ws?secret=fixture-private';f.tick();
 assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.diagnostic().reason,'context_changed');
 assert.equal(f.runtime.busy(),true);assert.equal(f.wire.length,1);
 assert.equal(JSON.stringify(f.runtime.diagnostic()).includes('fixture-private'),false);
});
for(const [name,change]of[
 ['uncovered',(_,s,c)=>{c.masked=false;}],['no blocker',(_,s,c)=>{c.blockedBy=[];}],['unknown type',(_,s,c)=>{c.type=null;}],
 ['not selectable',(_,s,c)=>{c.selectable=false;}],['special card',(_,s,c)=>{c.metadata.specialType=1;}],
 ['special lock',(_,s,c)=>{c.metadata.lock=1;}],['mismatched receiver',(_,s,c)=>{c.action.receiver={};}],
 ['wrong raw ID',(_,s,c)=>{c.rawID='another';}],['wrong zone',(_,s,c)=>{c.zone='reserve';}],
 ['wrong metadata state',(_,s,c)=>{c.metadata.state=2;}],['stale metadata',f=>{f.info.state=1;}],
 ['interactable covered control',f=>{f.button.interactable=true;}],['disabled control',f=>{f.button.enabled=false;}],
 ['watcher',f=>{f.store.isWatcher=true;}],['HotTime',f=>{f.store.isHotTiming=true;}],
 ['penetrate power',f=>{f.store.isUsingPenetrateProp=true;}],['warehouse selector',f=>{f.store.isAddingCommonBlock=true;}],
 ['dead self',f=>{f.store.gamers[0].state=2;}],['closed socket',f=>{f.ws.readyState=3;}],
 ['bad packet counter',f=>{f.socket.packetId=0;}],['reused packet entry',f=>{f.socket.responseMap[41]={resolve(){},reject(){}};}],
 ['nonwritable transport',f=>{Object.defineProperty(f.ws,'send',{writable:false});}],
 ['nonwritable TouchBlock',f=>{Object.defineProperty(f.socket,'TouchBlock',{writable:false});}],
 ['accessor singleton',f=>{Object.defineProperty(f.socket,'socket',{get(){throw Error('must not read getter');}});}]
])test('preflight refuses '+name+' without invoke or send',()=>{const f=fixture(),s=f.snapshot(),c=s.refs.get('local-card');change(f,s,c);assert.equal(f.runtime.dispatch(s,c,f.invoke),false);assert.equal(f.invocations(),0);assert.equal(f.wire.length,0);assert.equal(f.listenerCount(),0);assert.equal(f.timers.size,0);assert.equal(f.runtime.busy(),false);closed(f.runtime.diagnostic());});
test('listener registration failure rolls back all installed observers before invoke',()=>{const f=fixture({addFails:'error'});assert.equal(f.dispatch(),false);assert.equal(f.invocations(),0);assert.equal(f.listenerCount(),0);assert.equal(f.socket.TouchBlock,f.originalTouch);assert.equal(f.ws.send,f.originalSend);});
test('exception after original invoke is consumed only by SDK dispatcher and uncertainty stays latched',()=>{const boom=new Error('fixture'),f=fixture({invokeThrows:boom});assert.equal(f.dispatch(),true);assert.equal(f.invocations(),1);assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.diagnostic().reason,'original_exception');assert.equal(f.dispatch(),false);});
test('actual send synchronous throw preserves rejected Promise and latches uncertainty',async()=>{const boom=new Error('fixture send'),f=fixture({sendThrows:boom});assert.equal(f.dispatch(),true);await assert.rejects(f.returns[0],e=>e===boom);assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.wire.length,0);assert.equal(f.socket.TouchBlock,f.originalTouch);assert.equal(f.ws.send,f.originalSend);});
test('an invoked handler which never reaches transport is uncertain, not a safe retry',()=>{const f=fixture(),s=f.snapshot();assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{}),true);assert.equal(f.runtime.diagnostic().reason,'outbound_not_observed');assert.equal(f.runtime.busy(),true);assert.equal(f.dispatch(),false);});
test('wrong original arguments are forwarded untouched but cannot be attributed to experiment',()=>{const f=fixture(),s=f.snapshot();let returned;assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{returned=f.socket.TouchBlock('other',0);returned.catch(()=>{});}),true);assert.equal(f.calls[0][0],'other');assert.equal(f.runtime.diagnostic().reason,'request_mismatch');assert.equal(f.runtime.busy(),true);});
test('second original touch call is forwarded but makes the single attempt uncertain',()=>{const f=fixture(),s=f.snapshot();assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{f.socket.TouchBlock(f.info.id,0).catch(()=>{});f.socket.TouchBlock(f.info.id,0).catch(()=>{});}),true);assert.equal(f.calls.length,2);assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.diagnostic().attempts,1);});
test('capture packet ID inside TouchBlock after synchronous prefix request',async()=>{const f=fixture(),s=f.snapshot();assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{f.socket.send('CMD_HEART_BEAT',{}).catch(()=>{});f.invoke();}),true);assert.equal(JSON.parse(f.wire[1]).packet_id,42);f.reply(200,{pid:41});await flush();assert.equal(f.runtime.diagnostic().responseObserved,false);f.reply(200,{pid:42});await flush();assert.equal(stable(f).pending,false);});
test('reentrant dispatch cannot invoke a second SDK action',()=>{const f=fixture(),s=f.snapshot();let nested;assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{nested=f.runtime.dispatch(s,s.refs.get('local-card'),()=>assert.fail('must not invoke'));f.invoke();}),true);assert.equal(nested,false);assert.equal(f.invocations(),1);assert.equal(f.wire.length,1);});
test('a later observer replacing our hook is not overwritten during cleanup',()=>{const f=fixture(),s=f.snapshot();const newer=function(){};assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{f.invoke();f.ws.send=newer;}),true);assert.equal(f.ws.send,newer);assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.diagnostic().reason,'observer_restore_failed');});
test('fake original return lacking native Promise settlement is uncertainty',()=>{const f=fixture();const original=f.socket.TouchBlock;f.socket.TouchBlock=function(id,state){original.call(this,id,state).catch(()=>{});return {then(){throw Error('must not use thenable');}};};assert.equal(f.dispatch(),true);assert.equal(f.runtime.diagnostic().status,'uncertain');});
test('synchronous response in original send is retained until real Promise adoption settles',async()=>{let f;f=fixture({sendPrefix(){f.reply(200);}});assert.equal(f.dispatch(),true);await flush();assert.equal(f.runtime.diagnostic().responseObserved,true);assert.equal(f.runtime.diagnostic().promiseSettled,true);assert.equal(stable(f).pending,false);});
test('same native Promise is returned by observed original TouchBlock',async()=>{const f=fixture(),expected=Promise.resolve('fixture');const original=f.socket.TouchBlock;f.socket.TouchBlock=function(id,state){original.call(this,id,state).catch(()=>{});return expected;};const s=f.snapshot();let got;assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{got=f.socket.TouchBlock(f.info.id,0);}),true);assert.equal(got,expected);await flush();assert.equal(f.runtime.diagnostic().responseObserved,false);});
test('default and blocked diagnostics expose closed kind/outcome/phase, with explicit kind on generic preflight',()=>{
 const f=fixture();let d=f.runtime.diagnostic();assert.equal(d.kind,'touch');assert.equal(d.responseOutcome,'unknown');assert.equal(d.phase,'idle');
 for(const reason of ['xray_required','observing_board','original_pending']){d=f.runtime.block(reason,'penetrate_zero');assert.equal(d.kind,'penetrate_zero');assert.equal(d.phase,'blocked');assert.equal(d.responseOutcome,'unknown');closed(d);}
 d=f.runtime.block('xray_required');assert.equal(d.kind,'touch');
});
test('real regression: acknowledged500 crosses old15s while waiting rollback without losing response outcome',async()=>{
 const f=fixture();let d=await acknowledged(f,500);assert.equal(d.responseOutcome,'rejected');assert.equal(d.phase,'recovery');
 f.advance(15000);d=f.runtime.diagnostic();assert.equal(d.status,'rejected');assert.equal(d.reason,'recovery_timeout');assert.equal(d.responseOutcome,'rejected');assert.equal(d.pending,true);assert.equal(f.listenerCount(),0);
 assert.equal(f.dispatch(),false);assert.equal(f.wire.length,1);f.move('board');d=stable(f);assert.equal(d.pending,false);assert.equal(d.phase,'complete');assert.equal(d.serverCode,500);assert.equal(f.wire.length,1);
});
test('ACK near response deadline gets separate recovery lease, and stale response callback cannot affect it',async()=>{
 const f=fixture();f.dispatch();const stale=[...f.timers.values()][0].fn;f.advance(14950);f.reply(500);await flush();
 assert.equal(f.runtime.diagnostic().phase,'recovery');stale();assert.equal(f.runtime.diagnostic().status,'rejected');
 f.move('board');let d=stable(f);assert.equal(d.pending,false);assert.equal(d.phase,'complete');assert.equal(d.responseOutcome,'rejected');stale();assert.equal(f.runtime.diagnostic().phase,'complete');
});
test('late passive recovery must still prove full Store census and two stable snapshots',async()=>{
 const f=fixture();await acknowledged(f,500);f.advance(16000);f.move('board');const s=f.snapshot();f.store.pile_blocks.push({...f.info});
 f.runtime.observe(s);f.advance(100);f.runtime.observe(s);assert.equal(f.runtime.busy(),true);assert.equal(f.runtime.diagnostic().reason,'recovery_timeout');
 f.store.pile_blocks.pop();const d=stable(f);assert.equal(d.pending,false);assert.equal(d.responseOutcome,'rejected');assert.equal(f.wire.length,1);
});
test('response arriving after deadline cannot win a queued-timer race',async()=>{
 const f=fixture();f.dispatch();f.setTime(f.time()+15001);f.reply(500);await flush();const d=f.runtime.diagnostic();
 assert.equal(d.status,'uncertain');assert.equal(d.phase,'blocked');assert.equal(d.responseOutcome,'unknown');assert.equal(d.pending,true);assert.equal(f.wire.length,1);
});
test('header without original settlement has genuine response timeout and ignores late Promise settlement',async()=>{
 const f=fixture();f.dispatch();f.reply(500,{original:false});f.advance(15000);f.socket.responseMap[41].reject('late fixture');await flush();
 const d=f.runtime.diagnostic();assert.equal(d.status,'uncertain');assert.equal(d.reason,'response_timeout');assert.equal(d.responseOutcome,'unknown');assert.equal(d.pending,true);assert.equal(d.promiseSettled,false);
});
test('context swap after known ACK preserves outcome but latches context uncertainty',async()=>{
 const f=fixture();await acknowledged(f,500);f.socket.responseMap={};f.runtime.observe(f.snapshot());const d=f.runtime.diagnostic();
 assert.equal(d.status,'uncertain');assert.equal(d.responseOutcome,'rejected');assert.equal(d.phase,'blocked');assert.equal(d.serverCode,500);assert.equal(f.dispatch(),false);
});
test('trusted socket close after known ACK preserves known response outcome',async()=>{
 const f=fixture();await acknowledged(f);f.emit('close',{target:f.ws,isTrusted:true});const d=f.runtime.diagnostic();
 assert.equal(d.status,'uncertain');assert.equal(d.reason,'socket_closed');assert.equal(d.responseOutcome,'accepted');assert.equal(d.pending,true);
});
test('zero-stock Penetrate invokes exactly original UseProp once, with exact server IDs and unchanged stock',()=>{
 const f=fixture({kind:'penetrate_zero'}),before=JSON.stringify(f.store),row=f.store.props_blocks[0];Object.freeze(row);
 assert.equal(f.dispatch(),true);assert.equal(f.invocations(),1);assert.equal(f.wire.length,1);const request=JSON.parse(f.wire[0]);
 assert.equal(request.command,'CMD_USE_PROP');assert.deepEqual(request.param,{prop_id:'3-fixture-player',block_id:'fixture-card-0-0',rid:'fixture-room',uid:'fixture-player'});
 assert.deepEqual(f.calls,[['3-fixture-player','fixture-card-0-0']]);assert.equal(f.socket.UseProp,f.originalUseProp);assert.equal(f.socket.TouchBlock,f.originalTouch);assert.equal(f.ws.send,f.originalSend);
 assert.equal(JSON.stringify(f.store),before);assert.equal(f.runtime.diagnostic().kind,'penetrate_zero');assert.equal(f.runtime.diagnostic().phase,'response');
});
test('zero-stock Penetrate500 without optimistic movement releases only after real board stability',async()=>{
 const f=fixture({kind:'penetrate_zero'});let d=await acknowledged(f,500);assert.equal(d.status,'rejected');assert.equal(d.pending,true);assert.equal(d.responseOutcome,'rejected');
 d=stable(f);assert.equal(d.pending,false);assert.equal(d.effectObserved,false);assert.equal(d.phase,'complete');assert.equal(f.wire.length,1);closed(d);
});
test('Penetrate200 without card effect stays pending through recovery timeout, then accepts only late passive effect',async()=>{
 const f=fixture({kind:'penetrate_zero'});await acknowledged(f);f.tick();f.advance(100);assert.equal(f.tick().pending,true);
 f.advance(15000);let d=f.runtime.diagnostic();assert.equal(d.status,'accepted');assert.equal(d.reason,'recovery_timeout');assert.equal(d.responseOutcome,'accepted');assert.equal(d.pending,true);
 assert.equal(f.dispatch(),false);assert.equal(f.wire.length,1);f.move('tray');d=stable(f);assert.equal(d.pending,false);assert.equal(d.effectObserved,true);assert.equal(d.phase,'complete');assert.equal(f.wire.length,1);
});
test('Penetrate200 may observe an already removed triple only with complete consistent census',async()=>{
 const f=fixture({kind:'penetrate_zero'});await acknowledged(f);f.move('gone');const d=stable(f);assert.equal(d.pending,false);assert.equal(d.effectObserved,true);
});
test('Penetrate200 tray identity with different type is not the proven effect',async()=>{
 const f=fixture({kind:'penetrate_zero'});await acknowledged(f);f.move('tray');f.info.type=3;f.tick();f.advance(100);assert.equal(f.tick().pending,true);assert.equal(f.runtime.diagnostic().effectObserved,false);
});
test('post-ACK authoritative prop row replacement/removal is not a context failure',async()=>{
 const f=fixture({kind:'penetrate_zero'});await acknowledged(f);f.store.props_blocks=[];f.move('tray');const d=stable(f);assert.equal(d.pending,false);assert.equal(d.status,'accepted');assert.equal(d.effectObserved,true);
});
test('shared one-inflight gate prevents touch/Penetrate interleaving and preserves old kind on block',()=>{
 const f=fixture({kind:'penetrate_zero'});f.dispatch();const s=f.snapshot();let called=0;
 assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>called++,{kind:'touch'}),false);f.runtime.block('xray_required','touch');
 assert.equal(called,0);assert.equal(f.runtime.diagnostic().kind,'penetrate_zero');assert.equal(f.wire.length,1);
});
test('block after completed Penetrate resets attempt proof/outcome but keeps cumulative count',async()=>{
 const f=fixture({kind:'penetrate_zero'});await acknowledged(f,500);stable(f);const d=f.runtime.block('xray_required','penetrate_zero');
 assert.equal(d.kind,'penetrate_zero');assert.equal(d.phase,'blocked');assert.equal(d.responseOutcome,'unknown');assert.equal(d.attempts,1);
 for(const key of ['pending','requestObserved','responseObserved','promiseSettled','effectObserved'])assert.equal(d[key],false);assert.equal(d.serverCode,undefined);
});
for(const [name,edit,reason]of[
 ['missing row',f=>{f.store.props_blocks=[];},'penetrate_unavailable'],
 ['missing array',f=>{delete f.store.props_blocks;},'penetrate_unavailable'],
 ['duplicate row',f=>{f.store.props_blocks.push({...f.store.props_blocks[0]});},'penetrate_unavailable'],
 ['owned positive stock',f=>{f.store.props_blocks[0].count=1;},'penetrate_stock_not_zero'],
 ['string zero',f=>{f.store.props_blocks[0].count='0';},'penetrate_unavailable'],
 ['boolean zero',f=>{f.store.props_blocks[0].count=false;},'penetrate_unavailable'],
 ['missing count',f=>{delete f.store.props_blocks[0].count;},'penetrate_unavailable'],
 ['foreign ID',f=>{f.store.props_blocks[0].id='3-other-player';},'penetrate_id_unverified'],
 ['missing ID',f=>{delete f.store.props_blocks[0].id;},'penetrate_id_unverified'],
 ['excessive ID',f=>{f.store.props_blocks[0].id='x'.repeat(129);},'penetrate_id_unverified'],
 ['numeric ID',f=>{f.store.props_blocks[0].id=3;},'penetrate_id_unverified'],
 ['unknown type',f=>{f.store.props_blocks[0].type='3';},'penetrate_unavailable']
])test('zero-stock preflight blocks '+name+' without any original invocation',()=>{
 const f=fixture({kind:'penetrate_zero'});edit(f);assert.equal(f.dispatch(),false);const d=f.runtime.diagnostic();assert.equal(d.reason,reason);assert.equal(d.kind,'penetrate_zero');assert.equal(d.phase,'blocked');
 assert.equal(f.invocations(),0);assert.equal(f.wire.length,0);assert.equal(f.timers.size,0);assert.equal(f.listenerCount(),0);closed(d);
});
test('invalid operation kind never invokes any original method',()=>{const f=fixture(),s=f.snapshot();assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),f.invoke,{kind:'forged'}),false);assert.equal(f.wire.length,0);assert.equal(f.invocations(),0);});
test('generic preflight failure in Penetrate retains intended kind',()=>{const f=fixture({kind:'penetrate_zero'});f.ws.readyState=3;assert.equal(f.dispatch(),false);assert.equal(f.runtime.diagnostic().kind,'penetrate_zero');assert.equal(f.runtime.diagnostic().phase,'blocked');});
for(const [name,edit]of[
 ['missing UseProp',f=>{delete f.socket.UseProp;}],
 ['wrong original arity',f=>{f.socket.UseProp=function(id){return id;};}],
 ['nonwritable UseProp',f=>{Object.defineProperty(f.socket,'UseProp',{writable:false});}]
])test('UseProp method contract blocks '+name+' before invoking',()=>{const f=fixture({kind:'penetrate_zero'});edit(f);assert.equal(f.dispatch(),false);assert.equal(f.invocations(),0);assert.equal(f.wire.length,0);assert.equal(f.runtime.diagnostic().kind,'penetrate_zero');});
test('stock changing during observer installation blocks before any invocation',()=>{
 const f=fixture({kind:'penetrate_zero'}),add=f.ws.addEventListener;
 f.ws.addEventListener=function(name,fn){add.call(this,name,fn);if(name==='error')f.store.props_blocks[0].count=1;};
 assert.equal(f.dispatch(),false);assert.equal(f.invocations(),0);assert.equal(f.wire.length,0);assert.equal(f.listenerCount(),0);assert.equal(f.timers.size,0);
});
test('a context error during listener installation cannot rearm an uncertain phase and invoke',()=>{
 const f=fixture({kind:'penetrate_zero'}),add=f.ws.addEventListener;
 f.ws.addEventListener=function(name,fn){add.call(this,name,fn);if(name==='error')f.emit('error',{isTrusted:true,target:f.ws});};
 assert.equal(f.dispatch(),false);assert.equal(f.invocations(),0);assert.equal(f.wire.length,0);assert.equal(f.runtime.busy(),false);
});
test('UseProp argument mismatch is forwarded unchanged, never accepted as the selected attempt',async()=>{
 const f=fixture({kind:'penetrate_zero'}),s=f.snapshot();assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{const p=f.socket.UseProp('3-other','fixture-card-0-0');Promise.prototype.then.call(p,()=>{},()=>{});},{kind:'penetrate_zero'}),true);
 assert.deepEqual(f.calls,[['3-other','fixture-card-0-0']]);assert.equal(f.runtime.diagnostic().status,'uncertain');assert.equal(f.runtime.diagnostic().responseOutcome,'unknown');
});
test('UseProp original send throw is observed without unhandled rejection and never retried',async()=>{
 const boom=new Error('fixture UseProp send'),f=fixture({kind:'penetrate_zero',sendThrows:boom});assert.equal(f.dispatch(),true);await assert.rejects(f.returns[0],e=>e===boom);await flush();
 const d=f.runtime.diagnostic();assert.equal(d.status,'uncertain');assert.equal(d.kind,'penetrate_zero');assert.equal(d.responseOutcome,'unknown');assert.equal(f.dispatch(),false);assert.equal(f.invocations(),1);
});
test('UseProp counter capture ignores preceding heartbeat and preserves original Promise identity',async()=>{
 const f=fixture({kind:'penetrate_zero'}),s=f.snapshot();let p;
 assert.equal(f.runtime.dispatch(s,s.refs.get('local-card'),()=>{f.socket.send('CMD_HEART_BEAT',{}).catch(()=>{});p=f.socket.UseProp('3-fixture-player',f.info.id);Promise.prototype.then.call(p,()=>{},()=>{});},{kind:'penetrate_zero'}),true);
 assert.ok(p instanceof Promise);assert.equal(JSON.parse(f.wire[1]).packet_id,42);f.reply(500,{pid:41});await flush();assert.equal(f.runtime.diagnostic().responseOutcome,'unknown');f.reply(500,{pid:42});await flush();assert.equal(stable(f).pending,false);
});
test('resource bounded and contains no direct send, forged response, dynamic code or credential exports',()=>{assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\.(?:send|TouchBlock|UseProp|ChooseCommonBlock|sync)\s*\(/);assert.doesNotMatch(source,/new\s+(?:WebSocket|Function)\b|\b(?:fetch|XMLHttpRequest|eval)\s*\(/);assert.doesNotMatch(source,/\bsecret\b|authorization|cookie|password/i);});

const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_snapshot.js'),'utf8'),clone=v=>JSON.parse(JSON.stringify(v));
function fixture(){
 const store={uid:10,rid:20,start_time:30,state:2,isWatcher:false,isHotTiming:false,isAddingCommonBlock:false,isUsingPenetrateProp:false,isCanTouchBlock:true,
 gamers:[{uid:10,state:1}],pile_blocks:[],hand_blocks:[],storage_blocks:[],props_blocks:[{id:'0-private',type:0,count:2},{id:'3-private',type:3,count:0}],common_blocks:[],task_info:{target_block_type:2,current_num:1,total_num:9},mode:0,total_num:6};
 const socket={uid:10,rid:20,socket:{readyState:1},responseMap:{}},env={window:{},document:{},loader:name=>({default:name==='GameStore'?store:name==='Socket'?socket:null}),generation:1};
 const s={playState:{store,uid:10,rid:20,start:30,game:{},layer:{}},cc:{Component:function(){},js:{getClassName:c=>c.className}},root:{},board:{},reserve:{},trayNode:{},cards:[],tray:[],refs:new Map(),records:new Map(),capacity:7};
 function card(zone,type,layer,row,col,masked=false){const z=['board','tray','reserve'].indexOf(zone),n=s.refs.size+1,raw='private-card-'+n,id='c'+n;
 store[['pile_blocks','hand_blocks','storage_blocks'][z]].push({id:raw,type,state:z,...(zone==='board'?{layer,row,col}:{})});
 const c={id,rawID:raw,type:'type:'+type,zone,order:s[zone==='tray'?'tray':'cards'].length,layer,gridRow:row,gridCol:col,x:row*5-240,y:315-col*4.5,blockedBy:[],available:zone!=='tray'&&!masked,selectable:true,metadata:{specialType:0,lock:0,canTouch:zone!=='tray'&&!masked,ruleIssue:null}};
 c.node={};c.metadata.block={isValid:true,node:c.node,isTouched:false,canTouch:c.metadata.canTouch,blockInfo:store[['pile_blocks','hand_blocks','storage_blocks'][z]].at(-1)};
 s.refs.set(id,c);s[zone==='tray'?'tray':'cards'].push(c);return c;}
 const covered=card('board',1,0,48,70,true),top=card('board',2,1,48,70);covered.blockedBy=[top.id];card('board',2,2,80,70);card('reserve',1,0,0,0);card('tray',2,0,0,0);card('tray',1,0,0,0);
 const reader=vm.runInNewContext('('+source+')()');return {store,socket,s,env,reader,card,observe:t=>reader.observe(s,env,t),current:()=>clone(reader.current()),diag:()=>clone(reader.diagnostic())};
}
function ready(p){assert.equal(p.observe(0),false);assert.equal(p.observe(80),true,JSON.stringify(p.diag()));return p.current();}
function slots(p,count=3){const commonNode={isValid:true},items={children:[]},common={className:'CommonStore',isValid:true,node:commonNode,selfIndex:0,itemsNode:items};p.s.records.set(commonNode,p.s.root);p.s.playState.layer.CommonStore=common;
 for(let i=0;i<3;i++){const node={isValid:true,parent:items,children:[]},row={lock_state:i,block:null},item={className:'CommonStoreItem',isValid:true,node,commonStore:common,commonBlock:row,isSelf:i===0,isEmpty:true};node.getComponents=()=>[item];items.children.push(node);if(i<count){p.store.common_blocks.push(row);p.s.records.set(node,items);}}return common;}
test('full local census includes real stock, mission, zones, graph, rules and no raw identities',()=>{const p=fixture(),s=ready(p);assert.deepEqual(s.counts,{board:3,tray:2,reserve:1,types:2,dependencyEdges:1,inventoryRows:2,sharedSlots:0,sharedCards:0});assert.deepEqual(s.cards[0].blockedBy,['c2']);assert.equal(s.cards[0].available,false);assert.deepEqual(s.tray.map(c=>c.type),['type:2','type:1']);assert.equal(s.inventory[1].count,0);assert.equal(s.mission.current,1);assert.equal(s.complete,true);assert.equal(s.serverConfirmed,false);assert.equal(s.rules.allRecognized,true);assert.doesNotMatch(JSON.stringify(s),/private|"uid"|"rid"|secret|token|socket|responseMap/);});
test('original own progress is nullable bounded data and invalidates the phase on change',()=>{
 const p=fixture(),self=p.store.gamers.find(g=>g.uid===p.s.playState.uid);self.current_progress=75;
 assert.equal(ready(p).progressPercent,75);self.current_progress=80;assert.equal(p.observe(100),false);assert.equal(p.observe(180),true);assert.equal(p.current().progressPercent,80);
 for(const invalid of [undefined,true,-1,101,'75',NaN]){const q=fixture();q.store.gamers[0].current_progress=invalid;assert.equal(ready(q).progressPercent,null);}
});
test('two observations require 80ms minimum, not merely repeated ticks',()=>{const p=fixture();assert.equal(p.observe(0),false);for(let t=1;t<80;t++)assert.equal(p.observe(t),false);assert.equal(p.current(),null);assert.equal(p.observe(80),true);});
test('returned snapshot and diagnostics cannot mutate private state',()=>{const p=fixture(),s=ready(p);s.cards[0].blockedBy=[];s.inventory[0].count=999;const d=p.reader.diagnostic();d.counts.board=999;assert.equal(p.current().cards[0].blockedBy.length,1);assert.equal(p.current().inventory[0].count,2);assert.equal(p.diag().counts.board,3);});
test('tray visual sequence takes priority over child insertion order',()=>{const p=fixture();p.s.tray[0].order=1;p.s.tray[1].order=0;const s=ready(p);assert.deepEqual(s.tray.map(c=>c.type),['type:2','type:1']);assert.deepEqual(s.tray.map(c=>c.order),[0,1]);});
test('geometry tolerates same rounding as live adapter',()=>{const p=fixture();p.s.cards[0].x+=.005;assert.equal(ready(p).complete,true);});
for(const [name,mutate,reason] of [
 ['missing store array',p=>delete p.store.pile_blocks,'store_unavailable'],['uncensused Store row',p=>p.store.pile_blocks.push({...p.store.pile_blocks[0],id:'extra'}),'store_scene_mismatch'],
 ['duplicate raw scene identity',p=>p.s.cards[1].rawID=p.s.cards[0].rawID,'store_scene_mismatch'],['duplicate raw Store identity',p=>p.store.pile_blocks[1].id=p.store.pile_blocks[0].id,'invalid_cards'],
 ['wrong zone',p=>p.store.pile_blocks[0].state=1,'invalid_cards'],['wrong type',p=>p.store.pile_blocks[0].type=8,'store_scene_mismatch'],['missing dependency',p=>p.s.cards[0].blockedBy=[],'invalid_dependencies'],
 ['self cycle',p=>p.s.cards[0].blockedBy=['c1'],'invalid_dependencies'],['foreign dependency',p=>p.s.cards[0].blockedBy=['c999'],'invalid_dependencies'],
 ['lock divergence',p=>p.store.pile_blocks[0].special_info={type:1,lock_state:3},'store_scene_mismatch'],['negative stock',p=>p.store.props_blocks[0].count=-1,'invalid_inventory'],['missing stock',p=>delete p.store.props_blocks,'invalid_inventory'],['duplicate stock identity',p=>p.store.props_blocks[1].id=p.store.props_blocks[0].id,'invalid_inventory'],
 ['impossible mission',p=>p.store.task_info.current_num=10,'invalid_mission'],['missing mission not null',p=>delete p.store.task_info,'invalid_mission'],['missing mode',p=>delete p.store.mode,'store_unavailable'],
 ['closed transport',p=>p.socket.socket.readyState=3,'context_unavailable'],['foreign socket player',p=>p.socket.uid=11,'context_unavailable'],['foreign round',p=>p.store.start_time++,'context_changed'],
 ['HotTime',p=>p.store.isHotTiming=true,'external_mode_active'],['common selector',p=>p.store.isAddingCommonBlock=true,'external_mode_active'],['penetrate selector',p=>p.store.isUsingPenetrateProp=true,'external_mode_active'],['spectator',p=>p.store.isWatcher=true,'external_mode_active'],['dead self',p=>p.store.gamers[0].state=0,'external_mode_active'],
 ['data accessor',p=>Object.defineProperty(p.store,'props_blocks',{get(){throw Error('do not execute');}}),'read_error']
])test('invalid state clears complete snapshot: '+name,()=>{const p=fixture();ready(p);mutate(p);assert.equal(p.observe(100),false);assert.equal(p.current(),null);assert.equal(p.diag().reason,reason);});
for(const [name,mutate,newScope=false] of [
 ['stock',p=>p.store.props_blocks[0].count++],['mission',p=>p.store.task_info.current_num++],['mode',p=>p.store.mode=1],['phase total',p=>p.store.total_num++],['source identity',p=>{p.store.pile_blocks[0].id='new-private';p.s.cards[0].rawID='new-private';}],['socket',p=>p.socket.socket={readyState:1},true],['document',p=>p.env.document={},true],['generation',p=>p.env.generation++,true]
])test('new stable revision required on '+name,()=>{const p=fixture(),old=ready(p);mutate(p);assert.equal(p.observe(100),false);assert.equal(p.current(),null);assert.ok(p.diag().revision>old.revision);assert.equal(p.diag().scope>old.scope,newScope);assert.equal(p.observe(179),false);assert.equal(p.observe(180),true);});
test('unchanged observations retain revision and scope',()=>{const p=fixture(),s=ready(p);for(let i=100;i<1000;i+=100){assert.equal(p.observe(i),true);assert.equal(p.current().revision,s.revision);}});
test('same-value server array refreshes do not starve the 80ms census stability window',()=>{
 const p=fixture();let revision;
 for(let t=0;t<=200;t+=20){
  for(const name of ['pile_blocks','hand_blocks','storage_blocks','props_blocks','common_blocks'])p.store[name]=p.store[name].slice();
  assert.equal(p.observe(t),t>=80,JSON.stringify(p.diag()));
  if(t===0)revision=p.diag().revision;
  assert.equal(p.diag().revision,revision);
 }
 assert.equal(p.current().complete,true);assert.equal(p.current().serverConfirmed,false);
});
test('content-equivalent deep sync is safe between reads; changed stock still requires a new proof',()=>{
 const p=fixture(),before=ready(p);
 for(const name of ['pile_blocks','hand_blocks','storage_blocks','props_blocks'])p.store[name]=clone(p.store[name]);
 assert.equal(p.observe(100),true);assert.equal(p.current().revision,before.revision);
 p.store.props_blocks[0].count++;assert.equal(p.observe(120),false);assert.equal(p.current(),null);
 assert.equal(p.observe(199),false);assert.equal(p.observe(200),true);assert.ok(p.current().revision>before.revision);
});
test('null task is verified absence, not invented mission',()=>{const p=fixture();p.store.task_info=null;assert.deepEqual(ready(p).mission,{status:'none'});});
test('nested storage is flattened with same census',()=>{const p=fixture();p.store.storage_blocks=[p.store.storage_blocks];assert.equal(ready(p).counts.reserve,1);});
function reserveStack(){
 const p=fixture(),bottom=p.s.cards.find(c=>c.zone==='reserve'),middle=p.card('reserve',2,0,0,0),top=p.card('reserve',3,0,0,0),other=p.card('reserve',4,0,0,0);
 const positions=[[bottom,0,1],[middle,1,1],[top,2,1],[other,3,2]],matrix=[];
 for(const [c,layer,index] of positions){
  c.metadata.block.blockInfo.storage_info={layer,index};Object.assign(c,{storageVerified:true,storageLayer:layer,storageIndex:index,masked:false,x:80*index-80,y:7*layer});
  Object.assign(c.node,{x:c.x,y:c.y});matrix[layer]=[null,null,null];matrix[layer][index]=c.metadata.block.blockInfo;
 }
 bottom.blockedBy=[middle.id,top.id];middle.blockedBy=[top.id];
 for(const [c] of positions){c.hintBlockedBy=c.blockedBy.slice();c.available=!c.blockedBy.length;c.occlusionDepth=c===bottom?2:c===middle?1:0;}
 p.store.storage_blocks=matrix;return {...p,bottom,middle,top,other};
}
test('verified reserve DAG includes every higher card in the same sparse storage column',()=>{
 const p=reserveStack(),s=ready(p),bottom=s.cards.find(c=>c.id===p.bottom.id),middle=s.cards.find(c=>c.id===p.middle.id);
 assert.deepEqual(bottom.blockedBy,[p.middle.id,p.top.id]);assert.deepEqual(middle.blockedBy,[p.top.id]);
 assert.equal(bottom.canTouch,true);assert.equal(bottom.available,false);assert.equal(s.counts.dependencyEdges,4);
 assert.deepEqual(s.cards.find(c=>c.id===p.other.id).blockedBy,[]);
});
for(const [name,mutate] of [
 ['missing higher card',p=>{p.bottom.blockedBy=[p.top.id];}],
 ['another storage column',p=>{p.bottom.blockedBy.push(p.other.id);}],
 ['board source',p=>{p.bottom.blockedBy=[p.s.cards.find(c=>c.zone==='board'&&c.available).id];}],
 ['lower storage layer',p=>{p.middle.blockedBy=[p.bottom.id];}]
])test('reserve snapshot rejects dependency from '+name,()=>{
 const p=reserveStack();ready(p);mutate(p);assert.equal(p.observe(100),false);assert.equal(p.current(),null);assert.equal(p.diag().reason,'invalid_dependencies');
});
test('unknown card and power mechanics remain explicit, not claimed solved',()=>{const p=fixture();p.store.pile_blocks[0].special_info={type:73,lock_state:1};Object.assign(p.s.cards[0].metadata,{specialType:73,lock:1});p.s.cards[0].selectable=false;p.store.props_blocks.push({id:'power-unknown',type:999,count:5});const s=ready(p);assert.equal(s.rules.allRecognized,false);assert.deepEqual(s.rules.unknownSpecialTypes,[73]);assert.equal(s.inventory[2].recognized,false);});
test('slots expose actual locks and ownership',()=>{const p=fixture();slots(p);const s=ready(p);assert.deepEqual(s.sharedSlots.map(v=>v.lock),[0,1,2]);assert.deepEqual(s.sharedSlots.map(v=>v.isSelf),[true,false,false]);});

function hiddenWarehouse(p){
 const common=p.s.playState.layer.CommonStore||slots(p);p.s.records.delete(common.node);common.node.active=false;delete common.selfIndex;
 for(const node of common.itemsNode.children){p.s.records.delete(node);delete node.getComponents()[0].commonBlock;}
 return common;
}
test('solo board census ignores uninitialized hidden warehouse rows from GameStore sync',()=>{
 const p=fixture();p.store.mode=1;hiddenWarehouse(p);const s=ready(p);
 assert.equal(s.complete,true);assert.equal(s.rules.allRecognized,true);assert.equal(s.counts.board,3);
 assert.deepEqual(s.sharedSlots,[]);assert.equal(s.counts.sharedCards,0);
});
for(const common of [undefined,null])test('solo has no shared slots when sync omits the unused warehouse: '+common,()=>{
 const p=fixture();p.store.mode=1;p.store.common_blocks=common;
 assert.deepEqual(ready(p).sharedSlots,[]);
});
test('team hidden warehouse still blocks even with a single player left',()=>{
 const p=fixture();hiddenWarehouse(p);assert.equal(p.observe(0),false);
 assert.equal(p.observe(80),false);assert.equal(p.diag().reason,'invalid_slots');assert.equal(p.current(),null);
});
test('solo-to-team mode transition cannot retain a phase with an uninitialized warehouse',()=>{
 const p=fixture();p.store.mode=1;hiddenWarehouse(p);ready(p);p.store.mode=0;
 assert.equal(p.observe(100),false);assert.equal(p.current(),null);assert.equal(p.diag().reason,'invalid_slots');
});
test('team-to-solo transition drops shared slots only after a fresh stable census',()=>{
 const p=fixture();slots(p);assert.equal(ready(p).sharedSlots.length,3);p.store.mode=1;hiddenWarehouse(p);
 assert.equal(p.observe(100),false);assert.equal(p.current(),null);assert.equal(p.observe(179),false);
 assert.equal(p.observe(180),true);assert.deepEqual(p.current().sharedSlots,[]);
});
test('solo does not accept an oversized or malformed provided warehouse container',()=>{
 for(const value of [{},Array(4).fill(null)]){const p=fixture();p.store.mode=1;p.store.common_blocks=value;
  assert.equal(p.observe(0),false);assert.equal(p.diag().reason,'invalid_slots');}
});
test('two-player layout retains inactive third prefab slot',()=>{const p=fixture();slots(p,2);assert.equal(ready(p).counts.sharedSlots,2);});
test('shared lock update invalidates even when card geometry unchanged',()=>{const p=fixture();slots(p);const old=ready(p);p.store.common_blocks[0].lock_state=3;assert.equal(p.observe(100),false);assert.equal(p.observe(180),true);assert.equal(p.current().sharedSlots[0].lock,3);assert.ok(p.current().revision>old.revision);});
test('occupied slot requires actual bound Block agreement, not label alone',()=>{const p=fixture(),common=slots(p),node=common.itemsNode.children[1],row=p.store.common_blocks[1];row.block={id:'shared-private',type:8,state:3};node.getComponents()[0].isEmpty=false;const blockNode={isValid:true,parent:node,children:[]},block={className:'Block',node:blockNode,blockInfo:row.block};blockNode.getComponents=()=>[block];node.children.push(blockNode);p.s.records.set(blockNode,node);assert.equal(ready(p).sharedSlots[1].type,'type:8');block.blockInfo={...row.block};assert.equal(p.observe(100),false);assert.equal(p.diag().reason,'invalid_slots');});
for(const inPlace of [false,true])test('torn collection cannot publish '+(inPlace?'in-place mutation':'array replacement'),()=>{const p=fixture(),common=slots(p),node=common.itemsNode.children[0],original=node.getComponents;node.getComponents=()=>{if(inPlace)p.store.props_blocks[0].count++;else p.store.props_blocks=p.store.props_blocks.slice();return original();};assert.equal(p.observe(0),false);assert.equal(p.diag().reason,'context_changed');});
test('clock rollback, nonfinite time and explicit pause invalidate',()=>{const p=fixture();ready(p);assert.equal(p.observe(79),false);assert.equal(p.diag().reason,'clock_invalid');p.reader.invalidate('user_paused');assert.equal(p.current(),null);assert.equal(p.diag().reason,'user_paused');assert.equal(p.observe(NaN),false);});
test('bounded reader has no transport, actions, hooks, dynamic execution or timers',()=>{assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|setTimeout|setInterval|eval)\s*\(|new\s+Function/);assert.doesNotMatch(source,/\.(?:send|TouchBlock|UseProp|ChooseCommonBlock|UseCommonBlock|touchBlock|emit|addEventListener)\s*\(/);});

test('server HotTime choosing flag invalidates even before local global flag catches up',()=>{const p=fixture();ready(p);p.store.gamers[0].choosing_hot_time_block=true;assert.equal(p.observe(100),false);assert.equal(p.diag().reason,'external_mode_active');});
test('unrecognized mode is observed but cannot claim all mechanics recognized',()=>{const p=fixture();p.store.mode=99;const s=ready(p);assert.equal(s.rules.allRecognized,false);assert.equal(s.rules.modeRecognized,false);});

test('late component touch-state mutation invalidates copied metadata',()=>{const p=fixture();ready(p);p.s.cards[1].metadata.block.canTouch=false;assert.equal(p.observe(100),false);assert.equal(p.diag().reason,'store_scene_mismatch');});
test('bounded budget can abort without keeping stale current',()=>{const p=fixture();ready(p);p.env.checkBudget=()=>false;assert.equal(p.observe(100),false);assert.equal(p.current(),null);assert.equal(p.diag().reason,'time_budget');});

test('Cocos public inherited accessors are allowed; Store accessors remain forbidden',()=>{
 const p=fixture(),common=slots(p);
 function inherited(object,keys){const proto=Object.create(Object.getPrototypeOf(object));for(const key of keys){const value=object[key];delete object[key];Object.defineProperty(proto,key,{get:()=>value});}Object.setPrototypeOf(object,proto);}
 for(const card of p.s.cards.concat(p.s.tray))inherited(card.metadata.block,['isValid','node']);
 inherited(common,['isValid','node']);inherited(common.itemsNode,['children']);
 for(const node of common.itemsNode.children){inherited(node,['children']);inherited(node.getComponents()[0],['isValid','node']);}
 assert.equal(ready(p).complete,true);
});

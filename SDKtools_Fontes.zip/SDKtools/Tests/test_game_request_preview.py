import importlib.util
import json
from pathlib import Path
import unittest

path=Path(__file__).resolve().parents[1]/'scripts/game_request_preview.py'
spec=importlib.util.spec_from_file_location('game_request_preview',path)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class PreviewTests(unittest.TestCase):
    def encode(self,value):return json.dumps(value).encode()
    def touch(self):return {'command':'CMD_TOUCH_BLOCK','param':{'block_id':'fixture-card','block_state':0}}
    def test_edits_valid_preview_but_never_supplies_session_envelope(self):
        result=module.preview(self.encode(self.touch()),block_id='fixture-other')
        self.assertTrue(result['dryRun']);self.assertFalse(result['networkEnabled'])
        self.assertEqual(result['param']['block_id'],'fixture-other')
        self.assertEqual(set(result),{'schema','dryRun','networkEnabled','command','param'})
    def test_use_prop_retains_only_method_parameters(self):
        value={'command':'CMD_USE_PROP','param':{'block_id':'fixture-card','prop_id':'3-fixture-user'}}
        self.assertEqual(module.preview(self.encode(value),prop_id='3-fixture-other')['param']['prop_id'],'3-fixture-other')
    def test_reject_credentials_and_arbitrary_fields_instead_of_stripping_them(self):
        for key in ['secret','token','uid','rid','packet_id','Authorization','url','__proto__']:
            for target in ['root','param']:
                with self.subTest(key=key,target=target):
                    value=self.touch();(value if target=='root' else value['param'])[key]='fixture-secret'
                    with self.assertRaises(module.PreviewError):module.preview(self.encode(value))
    def test_reject_arbitrary_commands_and_edits(self):
        for command in ['CMD_ENTER_GAME','CMD_HEART_BEAT','CMD_DEBUG','UseProp',None,[]]:
            value=self.touch();value['command']=command
            with self.assertRaises(module.PreviewError):module.preview(self.encode(value))
        with self.assertRaises(module.PreviewError):module.preview(self.encode(self.touch()),prop_id='fixture')
    def test_reject_noninteger_states_control_characters_and_limits(self):
        for state in [True,False,'0',0.5,-1,3,None]:
            value=self.touch();value['param']['block_state']=state
            with self.assertRaises(module.PreviewError):module.preview(self.encode(value))
        for identifier in ['', 'a'*129,'fixture\nsecret','a\x00b','a b']:
            with self.assertRaises(module.PreviewError):module.preview(self.encode(self.touch()),block_id=identifier)
        with self.assertRaises(module.PreviewError):module.preview(b' '*8193)
    def test_reject_duplicate_fields_nonfinite_bad_utf8_and_deep_json(self):
        for raw in [b'{"command":"x","command":"CMD_TOUCH_BLOCK"}',b'{"x":NaN}',b'\xff',b'['*1500+b']'*1500]:
            with self.assertRaises(module.PreviewError):module.preview(raw)
    def test_no_transport_module_or_send_mode_is_defined(self):
        import ast
        tree=ast.parse(path.read_text(encoding='utf-8'))
        imports={n.name.split('.')[0] for item in ast.walk(tree) if isinstance(item,ast.Import) for n in item.names}
        self.assertFalse(imports & {'socket','requests','http','urllib','websocket','subprocess'})
        with self.assertRaises(SystemExit):module.main(['--input','unused.json','--send'])
    def test_argument_errors_never_echo_an_accidentally_supplied_secret(self):
        import contextlib,io
        error=io.StringIO()
        with contextlib.redirect_stderr(error),self.assertRaises(SystemExit):
            module.main(['--input','unused.json','--token','fixture-private-secret'])
        self.assertNotIn('fixture-private-secret',error.getvalue())

if __name__=='__main__':unittest.main()

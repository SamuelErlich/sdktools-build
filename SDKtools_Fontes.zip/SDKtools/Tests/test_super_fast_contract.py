"""Source contracts only: no Apple compiler, packaging, network or device."""
import ast
import json
import re
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class SuperFastContracts(unittest.TestCase):
    def read(self,name):return (ROOT/name).read_text(encoding='utf-8-sig')
    def test_menu_toggle_default_off_and_independent_timer_preference(self):
        overlay=self.read('Sources/SDKtools/STOverlay.m');recorder=self.read('Sources/SDKtools/STAutoplayRecorder.inc')
        self.assertIn('self.autoplaySpeedSlider.maximumValue=10',overlay)
        self.assertIn('[r setAutoplaySpeedLevel:level]',overlay)
        self.assertIn('STAutoplaySpeedName((unsigned)r.autoplaySpeedLevel)',overlay)
        self.assertIn('_superFastEnabled = NO',self.read('Sources/SDKtools/STRecorder.m'))
        self.assertIn('STAutoplayIntervalMilliseconds((unsigned)self.autoplaySpeedLevel)/1000.0',recorder)
        self.assertIn('self.autoplayTimer.tolerance = MIN(interval*0.1,0.01)',recorder)
        setter=recorder.split('- (void)setSuperFastEnabled:',1)[1].split('- (void)setExtendedPlanning:',1)[0]
        self.assertNotIn('startAutoplay',setter);self.assertNotIn('autoplayFastPending=',setter)
    def test_real_factory_and_option_are_wired_through_native_bridge(self):
        bridge=self.read('Sources/SDKtools/STAutoplayBridge.inc');web=self.read('Sources/SDKtools/STWebProbe.m')
        self.assertIn('self.phaseSnapshotScript, self.fastScript,',bridge)
        self.assertIn('superFastEnabled:%@',bridge);self.assertIn('!self.fastScript.length',bridge)
        self.assertEqual(bridge.count('superFastEnabled:%@,cardsPerBatch:%lu,'),2)
        self.assertIn('_fastScript = source;',web)
        template=re.search(r'NSString \*wrapped[\s\S]*?@"([^"\n]+)"',bridge).group(1)
        self.assertEqual(len(re.findall(r'%@|%ld|%lu',template)),27)
    def test_pending_native_guard_precedes_evaluation_and_survives_context_loss(self):
        recorder=self.read('Sources/SDKtools/STAutoplayRecorder.inc')
        self.assertLess(recorder.index('BOOL fastMayDispatch='),recorder.index('BOOL submitted=[self.webProbe'))
        self.assertIn('BOOL fastMayDispatch=actionAllowed && self.autoplayCardsPerBatch>1;',recorder)
        self.assertIn('!self.autoplayFastPending && !self.autoplayFastContextLost',recorder)
        self.assertIn('observed!=self.autoplayFastWebView',recorder)
        self.assertIn('![observed.URL isEqual:self.autoplayFastURL]',recorder)
        self.assertIn('self.autoplayFastContextLost=YES;',recorder)
        self.assertIn('.wasPending=wasFastPending, .mayDispatch=fastMayDispatch',recorder)
        self.assertIn('.diagnosticIdle=[fastInfo[@"status"] isEqual:@"idle"]',recorder)
        self.assertIn('strongSelf.autoplayFastPending=YES;',recorder)
        self.assertIn('.refusedBeforeSubmission=refusedBeforeSubmission',recorder)
        self.assertIn('batchResult==STNativeBatchClearProvisional) strongSelf.autoplayFastPending=NO;',recorder)
        policy=self.read('Sources/SDKtools/STNativeActionPolicy.h')
        self.assertIn('f.wasPending && f.diagnosticIdle',policy)
        self.assertIn('!f.wasPending && f.mayDispatch ? STNativeBatchClearProvisional',policy)
    def test_future_packaging_lists_required_resource_without_running_it(self):
        self.assertIn('Resources/alpaca_fast.js',self.read('scripts/build_framework.sh'))
        self.assertIn("'alpaca_fast.js'",self.read('scripts/integrate_ipa.py'))
        ast.parse(self.read('Tests/test_packaging.py'))
        for name in ['autoplay_tool.js','alpaca_fast.js','alpaca_snapshot.js','xray_overlay.js']:
            self.assertLess((ROOT/'Resources'/name).stat().st_size,65536)
    def test_runtime_does_not_synthesize_game_packets_or_edit_game_permissions(self):
        source=self.read('Resources/alpaca_fast.js')
        self.assertNotRegex(source,r"\.send\s*\(\s*['\"]CMD_")
        self.assertNotRegex(source,r'\.(?:setIsCanTouchBlock|setTouchState|UseProp|ChooseCommonBlock)\s*\(')
        self.assertNotRegex(source,r'\b(?:eval|fetch|XMLHttpRequest)\s*\(|new\s+Function')
        self.assertIn("Promise.prototype.then.call(returned",source)
        self.assertIn("e.isTrusted!==true",source)
        self.assertIn("v.packet_id!==r.packet",source)
    def test_translation_copy_is_available_in_both_languages(self):
        rows=json.loads(self.read('Resources/Brand/menu-localizations.json'))['entries']
        text={r['en']:r['pt'] for r in rows}
        self.assertIn('Super Fast',text)
        self.assertIn('Up to 3 exposed cards per burst. Waits for server replies.',text)
if __name__=='__main__':unittest.main()

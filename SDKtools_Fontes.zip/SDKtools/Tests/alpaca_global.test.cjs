const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_global.js'),'utf8');
function create(config={}){return vm.runInNewContext(source,{performance:{now:()=>0}},{timeout:1000})(config);}
function card(id,type,blockedBy=[],extra={}){return {id,type,zone:'board',blockedBy,available:!blockedBy.length,selectable:true,specialType:0,...extra};}
function fixture(types=[],hand=[],extra={}){return {mode:1,snapshotVerified:true,signature:'round-board',capacity:7,matchSize:3,
 cards:types.map((t,i)=>typeof t==='string'?card('c'+i,t):t),tray:hand.map((t,i)=>({id:'t'+i,type:t,specialType:0})),inventory:[],...extra};}
function finish(s,solver=create()){let r;for(let i=0;i<50000;i++){r=solver.plan(s);if(r.status!=='searching')return JSON.parse(JSON.stringify(r));}assert.fail('search did not terminate');}
function clone(o){return JSON.parse(JSON.stringify(o));}
test('whole board proof includes every card, not only the next trio',()=>{
 const s=fixture(['a','a','a','b','b','b','c','c','c']),before=JSON.stringify(s),solver=create(),r=finish(s,solver);
 assert.equal(r.status,'solved');assert.equal(r.complete,true);assert.equal(r.route.length,9);assert.equal(r.bestCleared,9);assert.equal(r.remaining,0);
 assert.equal(solver.validate(s,r).valid,true);assert.equal(solver.replay(s,r.route).complete,true);assert.equal(JSON.stringify(s),before);
 assert.equal(solver.replay(s,r.route.slice(0,3)).complete,false);assert.equal(solver.replay(s,r.route.slice(0,3)).firstTrioIndex,2);
});
test('dependency chain is replayed through the full generated board',()=>{
 const s=fixture([card('bottom','a',['middle']),card('middle','a',['top']),card('top','a')]),solver=create(),r=finish(s,solver);
 assert.deepEqual(r.route.map(a=>a.id),['top','middle','bottom']);assert.equal(solver.replay(s,r.route).complete,true);
});
test('owned covered-card power is part of a certified full route and consumes exact stock',()=>{
 const s=fixture([card('hidden','a',['x0']),card('x0','x'),card('x1','x'),card('x2','x'),
 ...['b','c','d','e'].flatMap(t=>[card(t+'0',t),card(t+'1',t)])],['a','a','b','c','d','e'],{inventory:[{type:3,count:1}]}),solver=create(),r=finish(s,solver);
 assert.equal(r.status,'solved');assert.equal(r.route[0].kind,'power');assert.equal(r.route[0].powerType,3);assert.equal(r.route[0].id,'hidden');
 assert.equal(r.powerUses,1);assert.equal(solver.replay(s,r.route).cleared,18);assert.equal(solver.replay(s,r.route).firstTrioIndex,0);
 const no=clone(s);no.inventory=[];const impossible=finish(no);assert.equal(impossible.complete,false);assert.equal(impossible.exhaustive,true);assert.equal(impossible.bestCleared,0);
 assert.equal(solver.replay(no,r.route).valid,false);
});
test('an exposed card cannot waste Penetrate and a pair is mandatory',()=>{
 const solver=create(),s=fixture(['a'],['a','a'],{inventory:[{type:3,count:1}]});
 assert.equal(solver.replay(s,[{kind:'power',powerType:3,id:'c0'}]).valid,false);
 const other=fixture([card('hidden','a',['cover']),card('cover','b')],['a'],{inventory:[{type:3,count:1}]});
 assert.equal(solver.replay(other,[{kind:'power',powerType:3,id:'hidden'}]).valid,false);
});
test('initial Withdraw is a verified deterministic graph restoration, never inferred',()=>{
 const s=fixture([card('a','a'),card('b','a')],['a','b','c','d','e','f'],{inventory:[{type:1,count:1}],
  withdraw:{verified:true,id:'t5',zone:'board',blockedBy:[],covers:[]}}),solver=create();
 const r=solver.replay(s,[{kind:'power',powerType:1,id:'t5'},{kind:'card',id:'a'},{kind:'card',id:'b'}]);
 assert.equal(r.valid,true);assert.equal(r.cleared,3);assert.equal(r.powerUses,1);
 assert.equal(solver.replay(s,[{kind:'card',id:'a'},{kind:'power',powerType:1,id:'t5'}]).valid,false);
 const absent=clone(s);absent.inventory=[];assert.equal(solver.replay(absent,[{kind:'power',powerType:1,id:'t5'}]).valid,false);
 const restore=clone(s);restore.withdraw.covers=['a'];assert.equal(solver.replay(restore,[{kind:'power',powerType:1,id:'t5'},{kind:'card',id:'a'}]).valid,false);
});
test('the seventh slot can only complete a trio; a full observed tray cannot authorize powers',()=>{
 const solver=create(),safe=fixture(['a'],['a','a','b','c','d','e']);assert.equal(solver.replay(safe,[{kind:'card',id:'c0'}]).cleared,3);
 const unsafe=fixture(['x'],['a','a','b','c','d','e']);assert.equal(solver.replay(unsafe,[{kind:'card',id:'c0'}]).valid,false);
 const full=fixture(['a'],['a','a','b','b','c','c','d'],{inventory:[{type:1,count:1}],withdraw:{verified:true,id:'t6',zone:'board',blockedBy:[],covers:[]}});
 assert.equal(solver.replay(full,[{kind:'power',powerType:1,id:'t6'}]).valid,false);assert.equal(finish(full).route.length,0);
});
test('a bounded stop returns best observed, not an impossibility or invented perfect route',()=>{
 const s=fixture(['a','a','a','b','b','b']),solver=create({maxStates:2,sliceNodes:1}),first=solver.plan(s);
 assert.equal(first.status,'searching');assert.equal(first.route.length,0);assert.equal(first.firstAction,null);
 const r=finish(s,solver);assert.equal(r.status,'best');assert.equal(r.complete,false);assert.equal(r.optimal,false);assert.equal(r.exhaustive,false);
 assert.equal(r.reason,'state_limit_best_observed');assert.equal(solver.validate(s,r).valid,true);
});
test('known unequal totals have a clearance upper bound, not fabricated 100%',()=>{
 const s=fixture(['a','a','a','b']),solver=create(),r=finish(s,solver);
 assert.equal(r.status,'best');assert.equal(r.bestCleared,3);assert.equal(r.upperBound,3);assert.equal(r.complete,false);assert.equal(r.optimal,true);
 assert.equal(r.remaining,1);assert.equal(solver.validate(s,r).valid,true);
});
test('snapshots, inventory, graph and diagnostic outputs cannot mutate a cached proof',()=>{
 const s=fixture(['a','a','a']),solver=create(),r=finish(s,solver),initial=solver.diagnostic();
 const d=solver.diagnostic();d.route[0].id='forged';assert.equal(solver.diagnostic().route[0].id,initial.route[0].id);
 const direct=solver.plan(s);direct.route[0].id='also-forged';assert.equal(solver.diagnostic().route[0].id,initial.route[0].id);
 const changed=clone(s);changed.cards[0].type='b';assert.equal(solver.validate(changed,r).reason,'snapshot_changed');assert.equal(finish(changed,solver).complete,false);
 solver.invalidate();assert.equal(solver.diagnostic().reason,'invalidated');assert.equal(finish(s,solver).complete,true);
 const forged=clone(r);forged.bestCleared=2;assert.equal(solver.validate(s,forged).reason,'false_claim');
 forged.route=forged.route.concat(forged.route[0]);assert.equal(solver.validate(s,forged).valid,false);
});
for(const [name,mutate] of [
 ['not SOLO',s=>s.mode=0],['unverified census',s=>s.snapshotVerified=false],['unknown card',s=>s.cards[0].type='unknown'],
 ['special rule',s=>s.cards[0].specialType=2],['locked',s=>s.cards[0].locked=true],['not selectable',s=>s.cards[0].selectable=false],
 ['duplicate ID',s=>s.cards[0].id=s.cards[1].id],['duplicate tray ID',s=>s.tray=[{id:'c0',type:'a'}]],
 ['cycle',s=>{s.cards[0].blockedBy=['c1'];s.cards[1].blockedBy=['c0'];s.cards[0].available=s.cards[1].available=false;}],
 ['unknown blocker',s=>{s.cards[0].blockedBy=['missing'];s.cards[0].available=false;}],['unexplained disabled',s=>s.cards[0].available=false],
 ['reserve unverified',s=>s.cards[0].zone='reserve'],['stock duplicate',s=>s.inventory=[{type:3,count:1},{type:3,count:1}]],
 ['stock negative',s=>s.inventory=[{type:3,count:-1}]],['stock fractional',s=>s.inventory=[{type:3,count:1.5}]],
 ['unordered hand',s=>s.tray=[{id:'t0',type:'a'},{id:'t1',type:'b'},{id:'t2',type:'a'}]],
 ['unsettled triple',s=>s.tray=[0,1,2].map(i=>({id:'t'+i,type:'a'}))],['oversized board',s=>s.cards=Array.from({length:513},(_,i)=>card('big'+i,'a'))],
 ['unverified withdraw',s=>s.withdraw={id:'t0',zone:'board',blockedBy:[],covers:[]}]
 ,['sparse board',s=>delete s.cards[0]],['sparse inventory',s=>s.inventory=Array(1)]
])test('unsafe observation does not generate a route: '+name,()=>{
 const s=fixture(['a','a','a']);mutate(s);const solver=create(),r=finish(s,solver);assert.equal(r.status,'unavailable');assert.equal(r.route.length,0);
 assert.equal(solver.replay(s,[]).valid,false);
});
test('accessor and inherited contract fields are rejected without invoking getters',()=>{
 let reads=0;const s=fixture(['a','a','a']);Object.defineProperty(s.cards[0],'type',{get(){reads++;return 'a';}});
 assert.equal(finish(s).reason,'accessor_input');assert.equal(reads,0);
 const inherited=fixture(['a','a','a']);delete inherited.cards[0].type;Object.setPrototypeOf(inherited.cards[0],{get type(){reads++;return 'a';}});
 assert.equal(finish(inherited).reason,'inherited_input');assert.equal(reads,0);
});
test('verified reserve graph and maximum 510-card ordinary board produce replayed whole routes',()=>{
 const reserve=fixture([card('a','a',[],{zone:'reserve',storageVerified:true}),card('b','a',['a'],{zone:'reserve',storageVerified:true}),card('c','a',['b'],{zone:'reserve',storageVerified:true})]);
 assert.equal(finish(reserve).complete,true);
 const s=fixture(Array(510).fill('a')),solver=create(),r=finish(s,solver);assert.equal(r.status,'solved');assert.equal(r.route.length,510);assert.equal(r.bestCleared,510);
 assert.equal(solver.replay(s,r.route).complete,true);assert.ok(r.slices>1);
});
test('factory does not export side effects, global search state, sampling or transport',()=>{
 const context=vm.createContext({performance:{now:()=>0}}),before=Object.keys(context),factory=vm.runInContext(source,context),solver=factory();
 finish(fixture(['a','a','a']),solver);assert.deepEqual(Object.keys(context),before);
 assert.equal(/Math\.random|WebSocket|fetch\(|window\.|document\./.test(source),false);assert.ok(Buffer.byteLength(source)<65536);
});
test('large whole-route witness guides are resumable and independently replayable, never local picks',()=>{
 const {fixture:large,constructedRoute}=require('./alpaca_global.benchmark.cjs');
 for(const size of[228,510]){
  const input=large(size,'branch'),solver=create({sliceNodes:7}),witness=solver.replay(input,constructedRoute(size)),first=solver.plan(input);
  assert.equal(witness.valid,true);assert.equal(witness.complete,true);assert.equal(first.status,'searching');assert.equal(first.route.length,0);
  const r=finish(input,solver);assert.equal(r.complete,true);assert.equal(r.bestCleared,size);assert.ok(r.slices>1);assert.ok(r.states<=size+1);
  assert.equal(solver.replay(input,r.route).complete,true);assert.equal(r.exhaustive,false);
 }
});
test('failed deterministic witnesses do not remove exhaustive alternative search branches',()=>{
 const {fixture:large,constructedRoute}=require('./alpaca_global.benchmark.cjs'),input=large(228,'branch-shuffled'),solver=create({maxStates:500});
 assert.equal(solver.replay(input,constructedRoute(228)).complete,true,'a known complete route exists');
 const r=finish(input,solver);assert.equal(solver.validate(input,r).valid,true);
 if(!r.complete){assert.equal(r.exhaustive,false);assert.equal(r.optimal,false);assert.equal(r.reason,'state_limit_best_observed');}
});

"""Exercise the real preprocessor policy, not a duplicate Python flag."""
from pathlib import Path
import re
import shutil
import subprocess
import unittest


class CardActivationPolicyTests(unittest.TestCase):
    def policy(self, *defines):
        compiler = shutil.which("cc") or shutil.which("clang") or shutil.which("gcc")
        if not compiler:
            self.skipTest("C preprocessor unavailable; exercised by macOS CI")
        header = Path(__file__).resolve().parents[1] / "Sources/SDKtools/STCardFeaturePolicy.h"
        result = subprocess.run(
            [compiler, *defines, "-dM", "-E", "-x", "c", str(header)],
            capture_output=True, text=True, check=True,
        )
        match = re.search(r"^#define ST_CARD_GAME_FEATURE_ENABLED ([01])$", result.stdout, re.M)
        self.assertIsNotNone(match, result.stdout)
        return int(match.group(1))

    def test_production_default_activates_cards(self):
        self.assertEqual(self.policy(), 1)

    def test_disabled_regression_build_remains_explicitly_selectable(self):
        self.assertEqual(self.policy("-DST_CARD_GAME_FEATURE_ENABLED=0"), 0)


if __name__ == "__main__":
    unittest.main()

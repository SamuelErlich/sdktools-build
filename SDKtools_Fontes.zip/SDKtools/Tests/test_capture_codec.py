"""Decoder contract tests, including genuine V2.1 scene/reference samples."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
DECODER = ROOT / "scripts/decode_capture.py"
spec = importlib.util.spec_from_file_location("decode_capture", DECODER)
codec = importlib.util.module_from_spec(spec)
spec.loader.exec_module(codec)


def node(node_id, index, parent=None, parent_id=None, **values):
    return {"nodeID": node_id, "index": index, "parent": parent, "parentID": parent_id, **values}


def full(sequence=1, rows=None, **values):
    if rows is None:
        rows = [node("a", 0, local={"x": 0}, sprite={"frameID": "f1"}),
                node("b", 1, 0, "a"), node("c", 2, 0, "a")]
    return {"sequence": sequence, "contextID": "document-1", "webViewID": "webview-1",
            "sceneNodesEncoding": "full", "sceneNodes": rows, **values}


def reference(sequence=2, base=1, **values):
    return {"sequence": sequence, "contextID": "document-1", "webViewID": "webview-1",
            "sceneNodesEncoding": "reference", "sceneNodesRefSequence": base, **values}


def delta(sequence=2, base=1, order=None, added=None, changed=None, **values):
    return reference(sequence, base, sceneNodesEncoding="delta",
                     sceneNodesDelta={"version": 1, "order": order if order is not None else ["a", "b", "c"],
                                      "added": added or [], "changed": changed or []}, **values)


def report(*samples, schema=3, **values):
    return {"schemaVersion": schema, "webSamples": list(samples), **values}


class CaptureCodecTests(unittest.TestCase):
    def test_storage_metadata_survives_delta_and_reference_export(self):
        before = dict(type=3, state=2, storageLayer=2, storageIndex=1, canTouch=True, isTouched=False)
        after = dict(before, storageLayer=1)
        capture = report(full(rows=[node('a', 0, cardObservation=before)]),
                         delta(order=['a'], changed=[dict(nodeID='a', set=dict(cardObservation=after), unset=[])]), reference(3, 2))
        scenes = codec.resolve(capture)['webSamples']
        self.assertEqual([sample['sceneNodes'][0]['cardObservation'] for sample in scenes], [before, after, after])

    def assertInvalid(self, capture, text=None):
        with self.assertRaises(codec.CaptureDecodeError) as caught:
            codec.resolve(capture)
        if text:
            self.assertIn(text, str(caught.exception))

    def test_genuine_schema2_full_and_reference(self):
        capture = codec.load_capture(ROOT / "Tests/fixtures/schema2_scene_reference.json")
        result = codec.resolve(capture)
        self.assertEqual(result["schemaVersion"], 3)
        self.assertEqual(result["decoderTransform"]["sourceSchemaVersion"], 2)
        self.assertEqual(result["application"], capture["application"])
        first, second = result["webSamples"]
        self.assertEqual(len(first["sceneNodes"]), 70)
        self.assertEqual(second["sceneNodes"], first["sceneNodes"])
        for old, new in zip(capture["webSamples"], result["webSamples"]):
            self.assertEqual({k:v for k,v in old.items() if not k.startswith("sceneNodes")},
                             {k:v for k,v in new.items() if not k.startswith("sceneNodes")})
        self.assertNotIn("sceneNodesRefSequence", second)

    def test_field_patch_null_and_unset_are_distinct(self):
        patch = {"nodeID": "a", "set": {"local": None, "extra": False}, "unset": ["sprite"]}
        capture = report(full(), delta(changed=[patch]))
        original = deepcopy(capture)
        row = codec.resolve(capture)["webSamples"][1]["sceneNodes"][0]
        self.assertIsNone(row["local"])
        self.assertIs(row["extra"], False)
        self.assertNotIn("sprite", row)
        self.assertEqual(capture, original)

    def test_reorder_add_parent_indices_and_reference_to_delta(self):
        rows = [node("d", 3, 2, "b", local={"x": 12})]
        changes = [{"nodeID": "c", "set": {"index": 1}, "unset": []},
                   {"nodeID": "b", "set": {"index": 2}, "unset": []}]
        capture = report(full(), delta(order=["a", "c", "b", "d"], added=rows, changed=changes), reference(3,2))
        expanded = list(codec.iter_scenes(capture))
        self.assertEqual([n["nodeID"] for n in expanded[1]["sceneNodes"]], ["a", "c", "b", "d"])
        self.assertEqual(expanded[1]["sceneNodes"][3]["parentID"], "b")
        self.assertEqual(expanded[2]["sceneNodes"], expanded[1]["sceneNodes"])

    def test_truncated_membership_is_not_card_removal(self):
        sample = delta(order=["a", "b"], cocos={"nodeCount":2,"truncated":True,"truncationReasons":["node_limit"]})
        result = codec.resolve(report(full(), sample))
        self.assertEqual(len(result["webSamples"][1]["sceneNodes"]), 2)
        self.assertEqual(result["webSamples"][1]["cocos"], sample["cocos"])
        self.assertEqual(result["decoderTransform"]["membershipMeaning"], "nodes_observed_in_this_sample_not_cards_removed")

    def test_expanded_sample_mutation_does_not_poison_reference(self):
        iterator = codec.iter_scenes(report(full(), reference()))
        first = next(iterator)
        first["sceneNodes"][0]["local"]["x"] = 99
        self.assertEqual(next(iterator)["sceneNodes"][0]["local"]["x"], 0)

    def test_reference_chain_bound_and_keyframe_reset(self):
        samples = [full()]
        for sequence in range(2,21):
            samples.append(delta(sequence, sequence-1, changed=[{"nodeID":"a","set":{"tick":sequence},"unset":[]}]))
        self.assertEqual(codec.summarize(report(*samples))["maximumChainDepth"], 19)
        self.assertInvalid(report(*samples, delta(21,20)), "chain exceeds")
        self.assertEqual(len(codec.resolve(report(*samples,full(21),reference(22,21)))["webSamples"]), 22)

    def test_unknown_schema_and_schema2_delta_rejected(self):
        for schema in (True,1,4,"3",None):
            self.assertInvalid(report(full(),schema=schema))
        self.assertInvalid(report(full(),delta(),schema=2), "requires schemaVersion 3")

    def test_forward_dangling_and_reference_to_reference_rejected(self):
        for sample in (reference(base=2),reference(base=5),reference(base=99)):
            self.assertInvalid(report(full(),sample), "forward or dangling")
        self.assertInvalid(report(full(),reference(3,2)), "forward or dangling")
        self.assertInvalid(report(full(),reference(),reference(3,2)), "full or delta")

    def test_context_or_webview_change_cannot_reuse_base(self):
        for values in ({"contextID":"new-document"}, {"webViewID":"new-view"}, {"contextID":None}):
            self.assertInvalid(report(full(),reference(**values)), "context")
        self.assertEqual(len(codec.resolve(report(full(),full(2,contextID="new-document")))["webSamples"]),2)
        self.assertInvalid(report(full(webViewID=None),reference(webViewID=None)), "context")

    def test_non_scene_diagnostics_preserved_and_never_reference_targets(self):
        for status in codec.NON_SCENE_STATUSES:
            diagnostic={"sequence":2,"status":status,"requestedElapsedMs":1250}
            capture=report(full(),diagnostic,delta(3,1),reference(4,3))
            result=codec.resolve(capture)
            self.assertEqual(result["webSamples"][1],diagnostic)
            self.assertNotIn("sceneNodes",result["webSamples"][1])
            self.assertEqual(codec.summarize(capture)["encodings"]["nonScene"],1)
            self.assertInvalid(report(full(),diagnostic,reference(3,2)),"dangling")
        self.assertInvalid(report({"sequence":1,"status":"cocos2_scene_captured"}))
        self.assertInvalid(report({"sequence":1,"status":"evaluation_failed","sceneNodes":[]}))

    def test_duplicate_noninteger_and_out_of_order_sequence(self):
        for sample in (full(1),full(0),full(True),full(1.5),full("2")):
            self.assertInvalid(report(full(),sample))

    def test_ambiguous_encoding_fields_rejected(self):
        self.assertInvalid(report(full(sceneNodesRefSequence=1)), "encoding fields")
        self.assertInvalid(report(full(),reference(sceneNodes=[])), "encoding fields")
        sample = delta(); del sample["sceneNodesDelta"]
        self.assertInvalid(report(full(),sample), "encoding fields")
        self.assertInvalid(report(full(sceneNodesEncoding="unknown")))

    def test_duplicate_node_order_added_and_changed_rejected(self):
        self.assertInvalid(report(full(rows=[node("a",0),node("a",1,0,"a")])), "duplicate nodeID")
        self.assertInvalid(report(full(),delta(order=["a","a"])), "duplicate nodeID")
        self.assertInvalid(report(full(),delta(order=["a","b","c","d"],added=[node("d",3,0,"a")]*2)), "already exists")
        patch = {"nodeID":"a","set":{"local":None},"unset":[]}
        self.assertInvalid(report(full(),delta(changed=[patch,patch])), "duplicate changed")

    def test_unknown_order_and_changed_nodes_rejected(self):
        self.assertInvalid(report(full(),delta(order=["a","missing"])), "unknown nodeID")
        self.assertInvalid(report(full(),delta(changed=[{"nodeID":"missing","set":{"x":0},"unset":[]}])), "retained base")
        self.assertInvalid(report(full(),delta(order=["a"],changed=[{"nodeID":"b","set":{"x":0},"unset":[]}])), "retained base")
        self.assertInvalid(report(full(),delta(added=[node("d",3,0,"a")])), "absent from order")

    def test_bad_delta_version_shape_and_patch_rejected(self):
        bad_deltas = [{}, {"version":True,"order":[],"added":[],"changed":[]},
                      {"version":2,"order":[],"added":[],"changed":[]},
                      {"version":1,"order":"a","added":[],"changed":[]}]
        for invalid in bad_deltas:
            sample = delta(); sample["sceneNodesDelta"] = invalid
            self.assertInvalid(report(full(),sample))
        patches = [None, {}, {"nodeID":"a","set":{},"unset":[]},
                   {"nodeID":"a","set":{"nodeID":"z"},"unset":[]},
                   {"nodeID":"a","set":{},"unset":["parentID"]},
                   {"nodeID":"a","set":{},"unset":["absent"]},
                   {"nodeID":"a","set":{},"unset":["local","local"]},
                   {"nodeID":"a","set":{"local":None},"unset":["local"]},
                   {"nodeID":"a","set":[],"unset":[]},
                   {"nodeID":"a","set":{},"unset":[5]}]
        for patch in patches:
            self.assertInvalid(report(full(),delta(changed=[patch])))

    def test_exact_indices_parents_and_node_count_required(self):
        invalid = [node("a",0,0,"a"), node("a",True), node("a",1)]
        for row in invalid:
            self.assertInvalid(report(full(rows=[row])))
        for row in [node("b",1,1,"b"),node("b",1,None,None),node("b",1,0,"wrong"),
                    node("b",1,False,"a"),node("b",1,0,"a",depth=4)]:
            self.assertInvalid(report(full(rows=[node("a",0,depth=0),row])))
        self.assertInvalid(report(full(cocos={"nodeCount":1})), "nodeCount")
        self.assertInvalid(report(full(),delta(order=["a","c","b"])), "index")

    def test_node_and_sample_bounds(self):
        rows = [node("a",0)]+[node(f"n{i}",i,0,"a") for i in range(1,1537)]
        self.assertInvalid(report(full(rows=rows)), "1536")
        self.assertEqual(len(codec.resolve(report(full(rows=rows[:1536])))["webSamples"][0]["sceneNodes"]),1536)
        self.assertInvalid(report(full(rows=rows[:769]),schema=2), "768")
        self.assertInvalid(report(*(full(i,rows=[]) for i in range(1,722))), "720")

    def test_empty_scene_allowed(self):
        result=codec.resolve(report(full(rows=[]),reference()))
        self.assertEqual(result["webSamples"][1]["sceneNodes"],[])

    def test_input_json_duplicate_nonfinite_and_byte_bound(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/"in.json"
            for raw in ('{"schemaVersion":3,"schemaVersion":3,"webSamples":[]}',
                        '{"schemaVersion":3,"webSamples":[],"bad":NaN}',
                        '{"schemaVersion":3,"webSamples":[],"bad":Infinity}'):
                path.write_text(raw)
                with self.assertRaises(codec.CaptureDecodeError): codec.load_capture(path)
            path.write_text(json.dumps(report(full())))
            with self.assertRaises(codec.CaptureDecodeError): codec.load_capture(path,10)

    def test_cli_jsonl_json_summary_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            source=Path(directory)/"input.json"; source.write_text(json.dumps(report(full(),reference())))
            def run(*args):
                return subprocess.run([sys.executable,str(DECODER),str(source),*map(str,args)],capture_output=True,text=True)
            summary=run("--summary")
            self.assertEqual(summary.returncode,0,summary.stderr)
            self.assertEqual(json.loads(summary.stdout)["samples"],2)
            jsonl=Path(directory)/"expanded.jsonl"
            self.assertEqual(run(jsonl).returncode,0)
            records=[json.loads(line) for line in jsonl.read_text().splitlines()]
            self.assertEqual([r["recordType"] for r in records],["capture","webSample","webSample"])
            self.assertEqual(records[1]["sample"]["sceneNodes"],records[2]["sample"]["sceneNodes"])
            previous=jsonl.read_bytes()
            self.assertEqual(run(jsonl).returncode,2)
            self.assertEqual(jsonl.read_bytes(),previous)
            original=source.read_bytes()
            self.assertEqual(run(source).returncode,2)
            self.assertEqual(source.read_bytes(),original)
            destination=Path(directory)/"expanded.json"
            self.assertEqual(run(destination,"--format","json").returncode,0)
            self.assertEqual(json.loads(destination.read_text())["webSamples"][1]["sceneNodes"],records[2]["sample"]["sceneNodes"])

    def test_invalid_report_never_creates_output(self):
        with tempfile.TemporaryDirectory() as directory:
            source=Path(directory)/"bad.json"; output=Path(directory)/"expanded.jsonl"
            source.write_text(json.dumps(report(full(),reference(base=99))))
            result=subprocess.run([sys.executable,str(DECODER),str(source),str(output)],capture_output=True,text=True)
            self.assertEqual(result.returncode,2)
            self.assertFalse(output.exists())

    @unittest.skipUnless(sys.platform == "darwin", "native Foundation interoperability requires macOS")
    def test_native_encoder_output_roundtrips_in_independent_python_decoder(self):
        rows=[node("a",0,depth=0)]+[node(f"n{i}",i,0,"a",depth=1,
            local={"x":i*10,"y":40,"width":80,"height":90,"opacity":255},
            sprite={"frameID":"f1","textureID":"t1","rect":{"x":0,"y":0,"width":80,"height":90}})
            for i in range(1,80)]
        samples=[]
        for sequence in range(1,26):
            if sequence % 2 == 0:
                rows[1]["local"]={**rows[1]["local"],"x":sequence}
            if sequence == 6: rows[2]["optional"]=None
            if sequence == 8: del rows[2]["optional"]
            if sequence == 10:
                rows[2],rows[3]=rows[3],rows[2]
                rows[2]["index"]=2; rows[3]["index"]=3
            samples.append(full(sequence,deepcopy(rows)))
        payload="".join(json.dumps(sample,separators=(",",":"))+"\n" for sample in samples)
        result=subprocess.run(["bash",str(ROOT/"scripts/test_scene_codec.sh"),"--jsonl"],
                              input=payload,capture_output=True,text=True,timeout=60)
        self.assertEqual(result.returncode,0,result.stderr)
        encoded=[json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual(len(encoded),len(samples))
        self.assertTrue(all(sample["_codecMetrics"]["committed"] for sample in encoded))
        self.assertTrue(any(sample["sceneNodesEncoding"]=="delta" for sample in encoded))
        self.assertTrue(any(sample["sceneNodesEncoding"]=="reference" for sample in encoded))
        expanded=list(codec.iter_scenes(report(*encoded)))
        self.assertEqual([s["sceneNodes"] for s in expanded],[s["sceneNodes"] for s in samples])
        self.assertEqual(encoded[20]["sceneNodesEncoding"],"full")
        by_sequence={sample["sequence"]:sample for sample in encoded}
        for sample in encoded:
            if "sceneNodesRefSequence" in sample:
                self.assertIn(by_sequence[sample["sceneNodesRefSequence"]]["sceneNodesEncoding"],("full","delta"))


if __name__ == "__main__":
    unittest.main()

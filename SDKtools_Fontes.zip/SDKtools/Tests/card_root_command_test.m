// macOS/Foundation: execute the native command with controlled collaborators.
#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STCardFeaturePolicy.h"
#include <stdio.h>
@interface STRecorder : NSObject
@property (nonatomic, readonly) BOOL cardHintsEnabled;
@property BOOL cardHintsBusy;
@property BOOL allowStart;
@property BOOL loseContext;
@property NSUInteger starts;
@property NSUInteger reads;
- (BOOL)setCardHintsEnabled:(BOOL)enabled;
- (void)cardHintsTick;
- (BOOL)injectCardColorsAndReadRoot;
@end
@implementation STRecorder
- (BOOL)setCardHintsEnabled:(BOOL)enabled {
    self.starts++; _cardHintsEnabled = enabled && self.allowStart;
    if (_cardHintsEnabled) [self cardHintsTick];
    return _cardHintsEnabled;
}
- (void)cardHintsTick { self.reads++; if (self.loseContext) _cardHintsEnabled = NO; }
#include "../Sources/SDKtools/STCardRootRecorder.inc"
@end
static NSUInteger checks, failures;
static void Check(BOOL ok, NSString *why) { checks++; if (!ok) { failures++; fprintf(stderr, "FAIL: %s\n", why.UTF8String); } }
int main(void) { @autoreleasepool {
    STRecorder *r = [STRecorder new]; r.allowStart = YES;
    Check(![r injectCardColorsAndReadRoot] && r.starts == 0 && r.reads == 0, @"direct command cannot activate paused cards");
    Check(![r injectCardColorsAndReadRoot] && r.starts == 0 && r.reads == 0, @"repeated command cannot schedule a read");
    r.cardHintsBusy = YES;
    Check(![r injectCardColorsAndReadRoot] && r.starts == 0 && r.reads == 0, @"busy collaborators remain untouched");
    r.cardHintsBusy = NO;
    [r setCardHintsEnabled:YES]; // Simulate stale state outside the gated command.
    NSUInteger starts = r.starts, reads = r.reads;
    Check(![r injectCardColorsAndReadRoot] && r.starts == starts && r.reads == reads,
        @"even an already-enabled collaborator cannot bypass the command gate");
    r.loseContext = YES;
    Check(![r injectCardColorsAndReadRoot] && r.reads == reads, @"paused command does not probe page context");
    r.allowStart = NO;
    Check(![r injectCardColorsAndReadRoot] && r.reads == reads, @"failed activation does not read a foreign page");
    printf("card root native command: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

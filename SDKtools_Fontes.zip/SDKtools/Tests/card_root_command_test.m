// macOS/Foundation: execute the native command with controlled collaborators.
#import <Foundation/Foundation.h>
#include <stdio.h>
@interface STRecorder : NSObject
@property (nonatomic, readonly) BOOL cardHintsEnabled;
@property BOOL cardHintsBusy;
@property BOOL allowStart;
@property BOOL loseContext;
@property NSUInteger starts;
@property NSUInteger reads;
- (BOOL)setCardHintsEnabled:(BOOL)enabled;
- (void)cardHintsTick;
- (BOOL)injectCardColorsAndReadRoot;
@end
@implementation STRecorder
- (BOOL)setCardHintsEnabled:(BOOL)enabled {
    self.starts++; _cardHintsEnabled = enabled && self.allowStart;
    if (_cardHintsEnabled) [self cardHintsTick];
    return _cardHintsEnabled;
}
- (void)cardHintsTick { self.reads++; if (self.loseContext) _cardHintsEnabled = NO; }
#include "../Sources/SDKtools/STCardRootRecorder.inc"
@end
static NSUInteger checks, failures;
static void Check(BOOL ok, NSString *why) { checks++; if (!ok) { failures++; fprintf(stderr, "FAIL: %s\n", why.UTF8String); } }
int main(void) { @autoreleasepool {
    STRecorder *r = [STRecorder new]; r.allowStart = YES;
    Check([r injectCardColorsAndReadRoot] && r.starts == 1 && r.reads == 1, @"first tap activates and requests the immediate read");
    Check([r injectCardColorsAndReadRoot] && r.starts == 1 && r.reads == 2, @"next tap rereads without reinstalling");
    r.cardHintsBusy = YES;
    Check(![r injectCardColorsAndReadRoot] && r.reads == 2, @"pending physical evaluation cannot be overlapped");
    r.cardHintsBusy = NO; r.loseContext = YES;
    Check(![r injectCardColorsAndReadRoot] && !r.cardHintsEnabled, @"context loss does not report a live read");
    r.allowStart = NO;
    NSUInteger reads = r.reads;
    Check(![r injectCardColorsAndReadRoot] && r.reads == reads, @"failed activation does not read a foreign page");
    printf("card root native command: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),zlib=require('node:zlib');
const {fixture}=require('./card_flow_fixture.cjs');
function networkFixture(){
  const f=fixture(),s=f.socket;
  Object.assign(s,{packetId:1,responseMap:{},sent:[]});
  s.send=function(command,param){const id=this.packetId++;const response=new Promise((resolve,reject)=>{this.responseMap[id]={resolve,reject};});this.sent.push({id,command,param,response});return response;};
  s.sync=function(){return this.send('CMD_SYNC');};
  s.onMessage=function({data}){const packet=JSON.parse(data);const value=packet.body_encoding?JSON.parse(zlib.brotliDecompressSync(Buffer.from(packet.message,'base64')).toString()):packet.message;if(packet.packet_id)this.responseMap[packet.packet_id].resolve(value);else this.pushHandler(packet.event,value);};
  f.deliver=(value,compressed=false,id=s.sent.at(-1).id)=>s.onMessage({data:JSON.stringify({packet_id:id,body_encoding:compressed?1:0,message:compressed?zlib.brotliCompressSync(Buffer.from(JSON.stringify(value))).toString('base64'):value})});
  return f;
}
test('original JSON and Brotli decoder handoff is observed before Promise continuations and Store',async()=>{
  for(const compressed of [false,true]){
    const f=networkFixture(),send=f.socket.send;const first=f.tick();assert.equal(first.version,2);assert.equal(first.decoderStatus,'ready');assert.equal(f.socket.sent.length,0);
    const payload={state:3,gamers:[{uid:'PRIVATE',cards:[{id:12,type:0,color:0,num:0}]}],secret:'PRIVATE'};
    const promise=f.socket.sync();assert.equal(promise,f.socket.sent[0].response);promise.then(v=>f.store.sync(v));
    f.deliver(payload,compressed);const immediate=f.tick();assert.deepEqual(immediate.events.map(x=>x.stage),['socket_decoded_response']);assert.equal(immediate.events[0].cards[0].type,0);
    await promise;await Promise.resolve();const later=f.tick();assert.deepEqual(later.events.map(x=>x.stage),['socket_sync_result','store_input','store_after']);
    assert.equal(immediate.events[0].cards[0].objectID,later.events[0].cards[0].objectID);assert.ok(!JSON.stringify(immediate).includes('PRIVATE'));f.runtime.clear();assert.equal(f.socket.send,send);
  }
});
test('concurrent responses pair with their own resolver, preserving call and result identity',async()=>{
  const f=networkFixture();f.tick();const a=f.socket.sync(),b=f.socket.sync();f.deliver({cards:[{id:2}]},false,2);f.deliver({cards:[{id:1}]},false,1);
  const now=f.tick();assert.deepEqual(now.events.map(x=>x.cards[0].id),[2,1]);assert.notEqual(now.events[0].callID,now.events[1].callID);await Promise.all([a,b]);f.runtime.clear();
});
test('unrelated commands are forwarded and never observed at resolver boundary',async()=>{
  const f=networkFixture();f.tick();const param={secret:'PRIVATE'},p=f.socket.send('CMD_REGISTER',param);assert.equal(f.socket.sent[0].param,param);f.deliver({cards:[{id:10}]});await p;assert.equal(f.tick().events.length,0);f.runtime.clear();
});
test('result fields retain concrete tuples, local slots and rank grouping without user IDs',()=>{
  const f=fixture();f.store.gamers=[{uid:'A',cards:[]},{uid:'B',cards:[]}];f.tick();
  const payload={rank_infos:[{uid:'B',cards:[{id:11,type:3,color:2,num:0}]},{uid:'A',cards:[]}],game_over_info:{rank_infos:[{uid:'A',cards:[{id:9,type:1,color:4,num:3}]}]}};
  f.socket.pushHandler(12,payload);const e=f.tick().events[0];assert.equal(e.afterGameOver,true);assert.deepEqual(e.cards.map(x=>[x.zone,x.slot,x.group,x.id]),[['result_rank',1,0,11],['result_sync',0,0,9]]);
  assert.equal(e.resultFields.find(x=>x.path==='rank_infos_cards'&&x.group===1).count,0);assert.ok(!JSON.stringify(e).includes('uid'));assert.equal(payload.rank_infos[0].uid,'B');f.runtime.clear();
});
test('absent, null, empty, invalid and accessor result fields remain distinguishable',()=>{
  const f=fixture();f.tick();let reads=0;const getter={};Object.defineProperty(getter,'rank_infos',{get(){reads++;return [];}});
  for(const x of [{},{rank_infos:null},{rank_infos:[]},{rank_infos:7},getter])f.socket.pushHandler(3,x);
  const events=f.tick().events;assert.deepEqual(events.map(x=>x.resultFields[0].presence),['absent','null','array','invalid','accessor']);assert.equal(events[2].resultFields[0].count,0);assert.equal(reads,0);f.runtime.clear();
});
test('rank order is not a player slot; unknown player mapping stays absent',()=>{
  const f=fixture();f.tick();f.socket.pushHandler(12,{rank_infos:[{uid:'UNMATCHED',cards:[{id:1}]}]});const c=f.tick().events[0].cards[0];assert.equal(c.group,0);assert.ok(!('slot' in c));f.runtime.clear();
});
test('large results are bounded and explicitly truncated without hiding container counts',()=>{
  const f=fixture();f.tick();f.socket.pushHandler(12,{rank_infos:Array.from({length:10},()=>({cards:Array.from({length:300},(_,id)=>({id,type:1,color:1,num:1}))}))});const e=f.tick().events[0];assert.equal(e.resultFields[0].count,10);assert.equal(e.truncated,true);assert.ok(e.cards.length<=256);assert.ok(e.resultFields.length<=19);f.runtime.clear();
});
test('result before GameOver remains distinguishable from ending and next-round data',()=>{
  const f=fixture();f.tick();const p={rank_infos:[{cards:[{id:3,type:1,color:2,num:7}]}]};f.socket.pushHandler(3,p);f.socket.pushHandler(12,p);f.socket.pushHandler(2,p);assert.deepEqual(f.tick().events.map(x=>x.afterGameOver),[false,true,false]);f.runtime.clear();
});
test('pending resolver descriptor restored on stop; foreign replacement not overwritten',async()=>{
  const f=networkFixture();f.tick();const p=f.socket.sync(),entry=f.socket.responseMap[1],wrapper=entry.resolve;
  f.runtime.clear();assert.notEqual(entry.resolve,wrapper);f.deliver({cards:[{id:5}]});await p;assert.equal(f.tick().events.length,0);
  const g=networkFixture();g.tick();g.socket.sync();const foreign=()=>123;g.socket.responseMap[1].resolve=foreign;g.runtime.clear();assert.equal(g.socket.responseMap[1].resolve,foreign);
});
test('missing or read-only decoder contract retains core diagnostic with explicit coverage status',()=>{
  const f=fixture();assert.equal(f.tick().decoderStatus,'unavailable');f.store.sync({gamers:[]});assert.equal(f.tick().events.length,2);f.runtime.clear();
  const g=networkFixture();Object.defineProperty(g.socket,'send',{writable:false,configurable:false});const o=g.tick();assert.equal(o.status,'ready');assert.equal(o.decoderReason,'observer_unavailable');g.runtime.clear();
});
test('resolver capacity is bounded and missed observation count is exported',()=>{
  const f=networkFixture();f.tick();for(let i=0;i<34;i++)f.socket.sync();assert.equal(f.tick().decoderMissed,2);f.runtime.clear();
});
test('resolver preserves original this, arguments, thrown value and descriptor',()=>{
  const f=networkFixture(),token={};let seen;
  f.socket.send=function(){this.responseMap[this.packetId++]={resolve:function(){seen={self:this,args:[...arguments]};throw token;}};return token;};
  f.tick();assert.equal(f.socket.sync(),token);const entry=f.socket.responseMap[1],arg={cards:[{id:7}]};assert.throws(()=>entry.resolve(arg,'extra'),e=>e===token);assert.equal(seen.self,entry);assert.equal(seen.args[0],arg);assert.equal(seen.args[1],'extra');assert.equal(f.tick().events[0].stage,'socket_decoded_response');f.runtime.clear();
});

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#include "STClientGamePolicy.h"
// Synthetic UIKit hierarchy; both production implementations are included verbatim.
@class UIWindow, UIViewController, UIWindowScene;
@interface UIResponder : NSObject
@property(nonatomic,weak) UIResponder *nextResponder;
@end
@implementation UIResponder @end
@interface UIView : UIResponder
@property(nonatomic) BOOL hidden;
@property(nonatomic) CGFloat alpha;
@property(nonatomic) CGRect bounds;
@property(nonatomic,weak) UIView *superview;
@property(nonatomic,weak) UIWindow *window;
@property(nonatomic,copy) NSArray<UIView *> *subviews;
- (BOOL)isDescendantOfView:(UIView *)view;
- (CGPoint)convertPoint:(CGPoint)p toView:(UIView *)view;
- (CGRect)convertRect:(CGRect)r toView:(UIView *)view;
@end
@implementation UIView
- (instancetype)init { if ((self=[super init])) { _alpha=1;_bounds=CGRectMake(0,0,390,844);_subviews=@[]; } return self; }
- (BOOL)isDescendantOfView:(UIView *)view { for (UIView *p=self.superview;p;p=p.superview) if (p==view) return YES; return NO; }
- (CGPoint)convertPoint:(CGPoint)p toView:(UIView *)view { (void)view;return p; }
- (CGRect)convertRect:(CGRect)r toView:(UIView *)view { (void)view;return r; }
@end
@interface UIViewController : UIResponder
@property(nonatomic) BOOL isBeingPresented;
@property(nonatomic) BOOL isBeingDismissed;
@property(nonatomic) BOOL isViewLoaded;
@property(nonatomic,strong) id transitionCoordinator;
@property(nonatomic,strong) UIViewController *presentedViewController;
@property(nonatomic,strong) UIView *view;
@end
@implementation UIViewController @end
@interface UIWindow : UIView
@property(nonatomic,strong) UIViewController *rootViewController;
@property(nonatomic,strong) id screen;
@property(nonatomic) CGFloat windowLevel;
@property(nonatomic,weak) UIWindowScene *windowScene;
@property(nonatomic,strong) UIView *hit;
- (UIView *)hitTest:(CGPoint)p withEvent:(id)event;
@end
@implementation UIWindow
- (UIView *)hitTest:(CGPoint)p withEvent:(id)event { (void)p;(void)event;return self.hit; }
@end
@interface UnityView : UIView @end
@implementation UnityView @end
static const NSInteger UISceneActivationStateForegroundActive=0,UIApplicationStateActive=0;
static const CGFloat UIWindowLevelNormal=0;
@interface UIWindowScene : NSObject
@property(nonatomic) NSInteger activationState;
@property(nonatomic,copy) NSArray<UIWindow *> *windows;
@end
@implementation UIWindowScene @end
@interface UIApplication : NSObject
@property(nonatomic) NSInteger applicationState;
@property(nonatomic,copy) NSArray<UIWindow *> *windows;
+ (instancetype)sharedApplication;
@end
@implementation UIApplication
+ (instancetype)sharedApplication { static id app; if (!app) app=[self new]; return app; }
@end
static BOOL inputBlocked;
static BOOL STClientInteractionBlocked(void) { return inputBlocked; }
static NSNumber *webGame;
@interface STRecorder : NSObject
+ (instancetype)shared;
- (NSNumber *)visibleHostedGameTypeInWindow:(UIWindow *)window;
- (NSNumber *)hostedGameIdentityInWindow:(UIWindow *)window;
@end
@implementation STRecorder
+ (instancetype)shared { static id value; if (!value) value=[self new]; return value; }
- (NSNumber *)visibleHostedGameTypeInWindow:(UIWindow *)window { (void)window;return webGame; }
- (NSNumber *)hostedGameIdentityInWindow:(UIWindow *)window { (void)window;return webGame; }
@end
static NSDictionary *identity;
@interface STBilliardsLuaBridge : NSObject
+ (NSDictionary *)executeCommand:(NSString *)command error:(NSError **)error;
@end
@implementation STBilliardsLuaBridge
+ (NSDictionary *)executeCommand:(NSString *)command error:(NSError **)error { (void)error;NSCAssert([command isEqual:@"identify"],@"read-only identity only");return identity; }
@end
#include "STClientHostVisibility.inc"
#include "STClientContext.inc"
static NSUInteger checks;
#define CHECK(c) do { checks++;if (!(c)) { NSLog(@"FAIL line %d: %s",__LINE__,#c);abort(); } } while(0)
static void attach(UIView *child,UIView *parent,UIWindow *window) {
    child.superview=parent;child.window=window;child.nextResponder=parent;
    parent.subviews=[parent.subviews arrayByAddingObject:child];
}
static UIViewController *controller(UIView *view) {
    UIViewController *c=[UIViewController new];c.view=view;c.isViewLoaded=YES;return c;
}
int main(void) { @autoreleasepool {
    UIWindow *host=[UIWindow new],*sdk=[UIWindow new];id screen=[NSObject new];host.screen=screen;sdk.screen=screen;
    host.window=host;sdk.window=sdk;sdk.rootViewController=controller(sdk);
    UIWindowScene *scene=[UIWindowScene new];scene.windows=@[host,sdk];sdk.windowScene=scene;host.windowScene=scene;
    UIView *root=[UIView new];attach(root,host,host);host.rootViewController=controller(root);
    UnityView *game=[UnityView new];attach(game,root,host);host.hit=game;
    identity=@{@"format":@"SDK.ClientContext",@"active":@YES};
    CHECK(STClientCurrentGame(sdk)==STClientGameBilliards);CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    // Regression: a legitimately presented game must accept Guide/Aim/Auto.
    UIView *presented=[UIView new];attach(presented,root,host);root.subviews=@[presented];presented.subviews=@[];attach(game,presented,host);
    UIViewController *gameController=controller(presented);host.rootViewController.presentedViewController=gameController;
    CHECK(STClientCurrentGame(sdk)==STClientGameBilliards);CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    UIViewController *container=controller(root);container.presentedViewController=gameController;host.rootViewController.presentedViewController=container;
    CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    // A modal ABOVE the game blocks input but preserves the positive identity.
    gameController.presentedViewController=controller([UIView new]);
    CHECK(STClientCurrentGame(sdk)==STClientGameBilliards);CHECK(STClientActionGame(sdk)==STClientGameNone);
    gameController.presentedViewController=nil;CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    host.hit=root;CHECK(STClientActionGame(sdk)==STClientGameNone);CHECK(STClientCurrentGame(sdk)==STClientGameBilliards);
    UIView *gameChild=[UIView new];attach(gameChild,game,host);host.hit=gameChild;CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    host.hit=nil;CHECK(STClientActionGame(sdk)==STClientGameNone);host.hit=game;
    inputBlocked=YES;CHECK(STClientActionGame(sdk)==STClientGameNone);CHECK(STClientCurrentGame(sdk)==STClientGameBilliards);inputBlocked=NO;
    CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    gameController.isBeingPresented=YES;CHECK(STClientActionGame(sdk)==STClientGameNone);gameController.isBeingPresented=NO;
    container.isBeingDismissed=YES;CHECK(STClientActionGame(sdk)==STClientGameNone);container.isBeingDismissed=NO;
    gameController.transitionCoordinator=[NSObject new];CHECK(STClientActionGame(sdk)==STClientGameNone);gameController.transitionCoordinator=nil;
    gameController.isViewLoaded=NO;CHECK(STClientActionGame(sdk)==STClientGameNone);gameController.isViewLoaded=YES;
    presented.hidden=YES;CHECK(!STClientHostViewAllowsActions(game));CHECK(STClientActionGame(sdk)==STClientGameNone);presented.hidden=NO;
    presented.alpha=0;CHECK(!STClientHostViewAllowsActions(game));presented.alpha=1;
    CGRect original=game.bounds;game.bounds=CGRectZero;CHECK(STClientActionGame(sdk)==STClientGameNone);game.bounds=original;
    UnityView *second=[UnityView new];attach(second,presented,host);CHECK(STClientActionGame(sdk)==STClientGameNone);CHECK(STClientCurrentGame(sdk)==STClientGameNone);presented.subviews=@[game];
    UIWindow *unrelated=[UIWindow new];unrelated.screen=screen;unrelated.rootViewController=controller([UIView new]);unrelated.rootViewController.presentedViewController=controller([UIView new]);
    scene.windows=@[unrelated,host,sdk];CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    sdk.rootViewController.presentedViewController=controller([UIView new]);CHECK(STClientActionGame(sdk)==STClientGameNone);sdk.rootViewController.presentedViewController=nil;
    identity=@{@"format":@"SDK.ClientContext",@"active":@NO};CHECK(STClientActionGame(sdk)==STClientGameNone);
    identity=@{@"format":@"other",@"active":@YES};CHECK(STClientActionGame(sdk)==STClientGameNone);identity=@{@"format":@"SDK.ClientContext",@"active":@YES};
    webGame=@60;CHECK(STClientActionGame(sdk)==STClientGameAlpaca);webGame=@2007;CHECK(STClientActionGame(sdk)==STClientGameCards);webGame=@999;CHECK(STClientActionGame(sdk)==STClientGameNone);webGame=nil;
    UIApplication.sharedApplication.applicationState=1;CHECK(STClientActionGame(sdk)==STClientGameNone);UIApplication.sharedApplication.applicationState=0;
    scene.activationState=1;CHECK(STClientActionGame(sdk)==STClientGameNone);scene.activationState=0;
    host.hidden=YES;CHECK(STClientActionGame(sdk)==STClientGameNone);host.hidden=NO;
    host.screen=[NSObject new];CHECK(STClientActionGame(sdk)==STClientGameNone);host.screen=screen;
    CHECK(STClientActionGame(sdk)==STClientGameBilliards);
    // Bounded traversal refuses cyclic controller graphs.
    gameController.presentedViewController=container;CHECK(!STClientHostViewAllowsActions(game));gameController.presentedViewController=nil;
    CHECK(!STClientHostViewAllowsActions(nil));
    printf("Client host/context regression: %lu checks passed\n",(unsigned long)checks);
}return 0;}

// Compile the production native pending coordinator with synthetic WebKit results.
// This validates latch transitions, not execution on an iPhone.
#import "../Sources/SDKtools/STAutoplaySanitizer.inc"
#import <Foundation/Foundation.h>
#import "license_gate_stub.h"
#include "../Sources/SDKtools/STAutoplaySpeed.h"
#include <assert.h>
#include <stdio.h>
@interface STRecorder : NSObject
@property BOOL coveredAttemptPending;
@property BOOL coveredAttemptContextLost;
@property BOOL coveredAttemptMayHaveRequest;
@property BOOL coveredAttemptRequiresProtocol;
@property BOOL autoplayFastPending;
@property BOOL autoplayFastContextLost;
@property BOOL autoplayResponsePending;
@property BOOL autoplayPowerContextLost;
@property(nonatomic,copy) NSDictionary *autoplayPowersDiagnostic;
@property NSUInteger autoplaySpeedLevel;
@property BOOL autoplayBusy;
@property BOOL autoplayEvaluationMayAct;
@property(nonatomic,readonly) BOOL autoplayStartBlockedByEvaluation;
@property(nonatomic,copy) NSString *coveredAttemptKind;
@property(nonatomic,copy) NSDictionary *coveredAttemptDiagnostic;
@property(nonatomic,copy) NSString *coveredAttemptDocument;
@property(nonatomic,strong) NSMutableArray *coveredAttemptEvents;
@property(nonatomic,strong) NSTimer *autoplayTimer;
@property BOOL autoplayEnabled;
@property BOOL xrayEnabled;
@property BOOL lanSharingEnabled;
@property NSUInteger notifications;
- (NSString *)coveredAttemptStatusText;
- (void)markCoveredContextLost;
- (void)acceptCoveredResult:(NSDictionary *)result manual:(BOOL)manual;
- (BOOL)autoplayHasPendingObservation;
- (void)ensureAutoplayTimer;
- (void)autoplayTick;
@end
@implementation STRecorder
- (instancetype)init { if ((self=[super init])) {
    _coveredAttemptPending=YES;_coveredAttemptDiagnostic=@{};_coveredAttemptEvents=[NSMutableArray array];
} return self; }
- (void)notifyChange {self.notifications++;}
- (void)autoplayTick {}
#include "covered_recorder.inc"
@end
static NSUInteger checks;
#define CHECK(c) do {checks++;assert(c);} while(0)
static NSMutableDictionary *Covered(NSString *status,BOOL pending,BOOL request,BOOL response,BOOL settled,BOOL effect) {
    NSMutableDictionary *d=[@{@"status":status,@"reason":@"awaiting_server",@"pending":@(pending),@"requestObserved":@(request),
        @"responseObserved":@(response),@"promiseSettled":@(settled),@"effectObserved":@(effect),@"attempts":@3} mutableCopy];
    if(response)d[@"serverCode"]=[status isEqual:@"rejected"]?@500:@200;
    return d;
}
static NSMutableDictionary *Modern(NSString *kind,NSString *status,BOOL pending,NSString *outcome,NSString *phase,BOOL effect) {
    BOOL known=![outcome isEqual:@"unknown"];
    NSMutableDictionary *d=Covered(status,pending,YES,known,known,effect);
    d[@"kind"]=kind;d[@"responseOutcome"]=outcome;d[@"phase"]=phase;
    if(known)d[@"serverCode"]=[outcome isEqual:@"rejected"]?@500:@200;
    return d;
}
static NSDictionary *Result(NSDictionary *covered,NSString *document) {
    NSMutableDictionary *row=[@{@"version":@1,@"status":@"watching",@"reason":@"covered_experiment",@"dispatched":@NO,
        @"awaitingBoardChange":@YES,@"cardsRead":@24,@"confirmedMoves":@0} mutableCopy];
    if(covered)row[@"covered"]=covered;
    NSMutableDictionary *safe=[STWPSanitizeAutoplay(row) mutableCopy];
    if(document){safe[@"runtimeContextID"]=document;safe[@"runtimeWebViewID"]=@"view-A";}
    return safe;
}
int main(void) { @autoreleasepool {
    for (NSUInteger mask=0;mask<4;mask++) {
        STRecorder *read=[STRecorder new];
        read.autoplayBusy=(mask&1)!=0;read.autoplayEvaluationMayAct=(mask&2)!=0;
        CHECK(read.autoplayStartBlockedByEvaluation==(mask==3));
        CHECK(read.autoplayBusy==((mask&1)!=0)); // Arming is not another evaluation.
    }
    // The covered coordinator must never inspect/change a Super Fast latch.
    // In particular, merely adding outer parentheses to the failed CI guard
    // would still create a phantom covered attempt when only Fast was pending.
    for (NSUInteger mask=0;mask<16;mask++) {
        STRecorder *guard=[STRecorder new];
        guard.coveredAttemptPending=(mask&1)!=0;
        guard.coveredAttemptContextLost=(mask&2)!=0;
        guard.autoplayFastPending=(mask&4)!=0;
        guard.autoplayFastContextLost=(mask&8)!=0;
        NSDictionary *before=guard.coveredAttemptDiagnostic;
        BOOL mustMark=guard.coveredAttemptPending && !guard.coveredAttemptContextLost;
        [guard markCoveredContextLost];
        CHECK(guard.coveredAttemptPending==((mask&1)!=0));
        CHECK(guard.coveredAttemptContextLost==(mustMark || ((mask&2)!=0)));
        CHECK(guard.coveredAttemptMayHaveRequest==mustMark);
        CHECK(guard.autoplayFastPending==((mask&4)!=0));
        CHECK(guard.autoplayFastContextLost==((mask&8)!=0));
        CHECK(guard.notifications==(mustMark?1u:0u));
        CHECK(guard.coveredAttemptEvents.count==(mustMark?1u:0u));
        CHECK(mustMark?[guard.coveredAttemptDiagnostic[@"status"] isEqual:@"uncertain"]:guard.coveredAttemptDiagnostic==before);
        NSDictionary *after=guard.coveredAttemptDiagnostic;
        [guard markCoveredContextLost];
        CHECK(guard.coveredAttemptDiagnostic==after && guard.notifications==(mustMark?1u:0u));
    }
    STRecorder *r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"blocked",NO,NO,NO,NO,NO),@"doc-A") manual:YES];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost); // cumulative attempts need not be zero
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"submitted",YES,YES,NO,NO,NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptMayHaveRequest && [r.coveredAttemptDocument isEqual:@"doc-A"]);
    [r acceptCoveredResult:Result(Covered(@"accepted",YES,YES,YES,NO,NO),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending); // 200 alone cannot release while original Promise is pending
    [r acceptCoveredResult:Result(Covered(@"accepted",YES,YES,YES,YES,NO),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending); // factory still awaits stable card effect
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-A") manual:NO];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost);
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"rejected",YES,YES,YES,NO,NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending);
    [r acceptCoveredResult:Result(Covered(@"rejected",NO,YES,YES,YES,NO),@"doc-A") manual:NO];
    CHECK(!r.coveredAttemptPending && [r.coveredAttemptDiagnostic[@"serverCode"] isEqual:@500]);
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,NO),@"doc-A") manual:YES];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost); // matching ACK + original settlement + factory stability permits another explicit tap
    CHECK([r.coveredAttemptStatusText containsString:@"200"] && [r.coveredAttemptStatusText containsString:@"não confirmado"]); // never claim the card was obtained
    r=[STRecorder new];r.coveredAttemptDocument=@"doc-A";
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-B") manual:NO];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost);
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // late callback never heals a lost context
    for(NSDictionary *bad in @[@{},@{@"status":@"accepted"}]) {
        r=[STRecorder new];[r acceptCoveredResult:Result(bad,@"doc-A") manual:YES];
        CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost);
    }
    r=[STRecorder new];
    [r acceptCoveredResult:STWPAutoResult(@"dispatch_uncertain",@"evaluation_timeout",YES) manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptMayHaveRequest && !r.coveredAttemptContextLost);
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-A") manual:YES];
    CHECK(!r.coveredAttemptPending); // real late callback can finish its own command
    r=[STRecorder new];
    [r acceptCoveredResult:STWPAutoResult(@"blocked",@"cleanup_pending",NO) manual:YES];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost); // bridge proved no evaluation was submitted
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"uncertain",YES,YES,NO,NO,NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost);
    r=[STRecorder new];r.coveredAttemptMayHaveRequest=YES;
    [r acceptCoveredResult:Result(Covered(@"blocked",NO,NO,NO,NO,NO),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // no downgrade to a fresh preflight
    CHECK(r.coveredAttemptEvents.count && r.notifications);
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    [r acceptCoveredResult:Result(Covered(@"rejected",NO,YES,YES,YES,NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // no new manual request accepts legacy attribution
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    [r acceptCoveredResult:Result(Modern(@"touch",@"rejected",NO,@"rejected",@"complete",NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // never substitute TouchBlock
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    [r acceptCoveredResult:Result(Modern(@"penetrate_zero",@"accepted",YES,@"accepted",@"recovery",NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && !r.coveredAttemptContextLost);
    NSMutableDictionary *recovery=Modern(@"penetrate_zero",@"accepted",YES,@"accepted",@"blocked",NO);recovery[@"reason"]=@"recovery_timeout";
    [r acceptCoveredResult:Result(recovery,@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending && !r.coveredAttemptContextLost);
    CHECK([r.coveredAttemptStatusText containsString:@"200"] && [r.coveredAttemptStatusText containsString:@"recuperação não confirmada"]);
    [r acceptCoveredResult:Result(Modern(@"penetrate_zero",@"accepted",NO,@"accepted",@"complete",YES),@"doc-A") manual:NO];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost); // late observed effect can finish without another request
    CHECK([r.coveredAttemptStatusText containsString:@"Não confirma poder ilimitado"]);
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    [r acceptCoveredResult:Result(Modern(@"penetrate_zero",@"accepted",NO,@"accepted",@"complete",NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // Penetrate bare 200/no-op cannot release native latch
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    [r acceptCoveredResult:Result(Modern(@"penetrate_zero",@"rejected",YES,@"rejected",@"recovery",NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && [r.coveredAttemptStatusText containsString:@"500"]);
    recovery=Modern(@"penetrate_zero",@"rejected",YES,@"rejected",@"blocked",NO);recovery[@"reason"]=@"recovery_timeout";
    [r acceptCoveredResult:Result(recovery,@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending && !r.coveredAttemptContextLost && [r.coveredAttemptStatusText containsString:@"500"]);
    CHECK(![r.coveredAttemptStatusText containsString:@"Resultado desconhecido"]);
    [r acceptCoveredResult:Result(Modern(@"penetrate_zero",@"rejected",NO,@"rejected",@"complete",NO),@"doc-A") manual:NO];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost);
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    [r acceptCoveredResult:Result(Modern(@"penetrate_zero",@"uncertain",YES,@"rejected",@"blocked",NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost && [r.coveredAttemptStatusText containsString:@"500"]);
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    NSMutableDictionary *mismatch=Modern(@"penetrate_zero",@"uncertain",YES,@"unknown",@"blocked",NO);
    mismatch[@"requestObserved"]=@YES;mismatch[@"responseObserved"]=@YES;mismatch[@"promiseSettled"]=@YES;mismatch[@"serverCode"]=@500;mismatch[@"reason"]=@"response_mismatch";
    [r acceptCoveredResult:Result(mismatch,@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost && [r.coveredAttemptStatusText containsString:@"Resultado desconhecido"]);
    r=[STRecorder new];r.coveredAttemptRequiresProtocol=YES;r.coveredAttemptKind=@"penetrate_zero";
    [r acceptCoveredResult:Result(Modern(@"penetrate_zero",@"uncertain",NO,@"accepted",@"complete",YES),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // known outcome never heals true context uncertainty
    r=[STRecorder new];r.coveredAttemptPending=NO;r.autoplayResponsePending=YES;r.autoplaySpeedLevel=10;
    STTestLicenseAuthorized=NO;
    [r ensureAutoplayTimer];
    CHECK(r.autoplayTimer.valid && r.autoplayTimer.timeInterval>=0.1);
    CHECK(!r.autoplayEnabled && r.autoplayResponsePending);
    [r acceptCoveredResult:Result(nil,@"doc-A") manual:NO];
    CHECK(r.autoplayTimer.valid && r.autoplayResponsePending);
    [r.autoplayTimer invalidate];r.autoplayTimer=nil;r.autoplayResponsePending=NO;
    r.autoplayPowersDiagnostic=@{@"status":@"submitted"};
    [r ensureAutoplayTimer];CHECK(r.autoplayTimer.valid && r.autoplayTimer.timeInterval>=0.1);
    [r.autoplayTimer invalidate];STTestLicenseAuthorized=YES;
    printf("Covered-card native pending lifecycle: %lu checks passed\n",(unsigned long)checks);
} return 0; }

// Compile the production native pending coordinator with synthetic WebKit results.
// This validates latch transitions, not execution on an iPhone.
#import "../Sources/SDKtools/STAutoplaySanitizer.inc"
#import <Foundation/Foundation.h>
#include <assert.h>
#include <stdio.h>
@interface STRecorder : NSObject
@property BOOL coveredAttemptPending;
@property BOOL coveredAttemptContextLost;
@property BOOL coveredAttemptMayHaveRequest;
@property(nonatomic,copy) NSDictionary *coveredAttemptDiagnostic;
@property(nonatomic,copy) NSString *coveredAttemptDocument;
@property(nonatomic,strong) NSMutableArray *coveredAttemptEvents;
@property(nonatomic,strong) NSTimer *autoplayTimer;
@property BOOL autoplayEnabled;
@property BOOL xrayEnabled;
@property NSUInteger notifications;
- (NSString *)coveredAttemptStatusText;
- (void)markCoveredContextLost;
- (void)acceptCoveredResult:(NSDictionary *)result manual:(BOOL)manual;
@end
@implementation STRecorder
- (instancetype)init { if ((self=[super init])) {
    _coveredAttemptPending=YES;_coveredAttemptDiagnostic=@{};_coveredAttemptEvents=[NSMutableArray array];
} return self; }
- (void)notifyChange {self.notifications++;}
#include "covered_recorder.inc"
@end
static NSUInteger checks;
#define CHECK(c) do {checks++;assert(c);} while(0)
static NSMutableDictionary *Covered(NSString *status,BOOL pending,BOOL request,BOOL response,BOOL settled,BOOL effect) {
    NSMutableDictionary *d=[@{@"status":status,@"reason":@"awaiting_server",@"pending":@(pending),@"requestObserved":@(request),
        @"responseObserved":@(response),@"promiseSettled":@(settled),@"effectObserved":@(effect),@"attempts":@3} mutableCopy];
    if(response)d[@"serverCode"]=[status isEqual:@"rejected"]?@500:@200;
    return d;
}
static NSDictionary *Result(NSDictionary *covered,NSString *document) {
    NSMutableDictionary *row=[@{@"version":@1,@"status":@"watching",@"reason":@"covered_experiment",@"dispatched":@NO,
        @"awaitingBoardChange":@YES,@"cardsRead":@24,@"confirmedMoves":@0} mutableCopy];
    if(covered)row[@"covered"]=covered;
    NSMutableDictionary *safe=[STWPSanitizeAutoplay(row) mutableCopy];
    if(document){safe[@"runtimeContextID"]=document;safe[@"runtimeWebViewID"]=@"view-A";}
    return safe;
}
int main(void) { @autoreleasepool {
    STRecorder *r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"blocked",NO,NO,NO,NO,NO),@"doc-A") manual:YES];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost); // cumulative attempts need not be zero
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"submitted",YES,YES,NO,NO,NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptMayHaveRequest && [r.coveredAttemptDocument isEqual:@"doc-A"]);
    [r acceptCoveredResult:Result(Covered(@"accepted",YES,YES,YES,NO,NO),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending); // 200 alone cannot release while original Promise is pending
    [r acceptCoveredResult:Result(Covered(@"accepted",YES,YES,YES,YES,NO),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending); // factory still awaits stable card effect
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-A") manual:NO];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost);
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"rejected",YES,YES,YES,NO,NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending);
    [r acceptCoveredResult:Result(Covered(@"rejected",NO,YES,YES,YES,NO),@"doc-A") manual:NO];
    CHECK(!r.coveredAttemptPending && [r.coveredAttemptDiagnostic[@"serverCode"] isEqual:@500]);
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,NO),@"doc-A") manual:YES];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost); // matching ACK + original settlement + factory stability permits another explicit tap
    CHECK([r.coveredAttemptStatusText containsString:@"200"] && [r.coveredAttemptStatusText containsString:@"não confirmado"]); // never claim the card was obtained
    r=[STRecorder new];r.coveredAttemptDocument=@"doc-A";
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-B") manual:NO];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost);
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // late callback never heals a lost context
    for(NSDictionary *bad in @[@{},@{@"status":@"accepted"}]) {
        r=[STRecorder new];[r acceptCoveredResult:Result(bad,@"doc-A") manual:YES];
        CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost);
    }
    r=[STRecorder new];
    [r acceptCoveredResult:STWPAutoResult(@"dispatch_uncertain",@"evaluation_timeout",YES) manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptMayHaveRequest && !r.coveredAttemptContextLost);
    [r acceptCoveredResult:Result(Covered(@"accepted",NO,YES,YES,YES,YES),@"doc-A") manual:YES];
    CHECK(!r.coveredAttemptPending); // real late callback can finish its own command
    r=[STRecorder new];
    [r acceptCoveredResult:STWPAutoResult(@"blocked",@"cleanup_pending",NO) manual:YES];
    CHECK(!r.coveredAttemptPending && !r.coveredAttemptContextLost); // bridge proved no evaluation was submitted
    r=[STRecorder new];
    [r acceptCoveredResult:Result(Covered(@"uncertain",YES,YES,NO,NO,NO),@"doc-A") manual:YES];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost);
    r=[STRecorder new];r.coveredAttemptMayHaveRequest=YES;
    [r acceptCoveredResult:Result(Covered(@"blocked",NO,NO,NO,NO,NO),@"doc-A") manual:NO];
    CHECK(r.coveredAttemptPending && r.coveredAttemptContextLost); // no downgrade to a fresh preflight
    CHECK(r.coveredAttemptEvents.count && r.notifications);
    printf("Covered-card native pending lifecycle: %lu checks passed\n",(unsigned long)checks);
} return 0; }

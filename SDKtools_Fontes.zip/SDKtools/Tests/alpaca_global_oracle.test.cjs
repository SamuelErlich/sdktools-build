/* Independent tiny-state oracle. The oracle below does not invoke the shipped
 * solver's replay/validate helpers, production transition functions, or the
 * recovered commercial game. Synthetic boards only; no generator guarantee. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/alpaca_global.js'), 'utf8');
const factory = vm.runInNewContext(source, {Date:{now:()=>0}}, {timeout:1000});
const copy = value => JSON.parse(JSON.stringify(value));

function board(types, hand = [], extra = {}) {
  return {
    snapshotVerified:true, mode:1, signature:'oracle-synthetic', capacity:7,
    cards:types.map((type, i)=>({id:'c'+(i+1), type, zone:'board',
      blockedBy:[], available:true, selectable:true, specialType:0})),
    tray:hand.map((type, i)=>({id:'t'+(i+1), type, zone:'tray', specialType:0})),
    inventory:[], ...extra
  };
}
function cover(input, below, above) {
  const c=input.cards[below]; c.blockedBy.push(input.cards[above].id); c.available=false;
}
function finish(input, solver = factory()) {
  let result;
  for (let i=0; i<100000; i++) {
    result=copy(solver.plan(input));
    if (result.status!=='searching') return result;
  }
  assert.fail('tiny exact search did not terminate within bounded resumptions');
}

// Model the original group insertion and then the FIRST ADJACENT triple.
// Counts-only matching would conceal an invalid nongrouped hand in a fixture.
function insert(hand, card) {
  const next=hand.slice(); let at=next.length;
  for (let i=0; i<next.length; i++) {
    if (i+1===next.length) { at=i+1; break; }
    if (next[i].type===card.type && next[i+1].type!==card.type) { at=i+1; break; }
  }
  next.splice(at,0,card);
  for (let i=0; i+2<next.length; i++) {
    if (next[i].type===next[i+1].type && next[i].type===next[i+2].type) {
      next.splice(i,3); break;
    }
  }
  return next;
}
function start(input) {
  return {cards:new Map(input.cards.map(c=>[c.id,copy(c)])), hand:copy(input.tray),
    pen:input.inventory.filter(p=>p.type===3).reduce((a,p)=>a+p.count,0),
    undo:input.inventory.filter(p=>p.type===1).reduce((a,p)=>a+p.count,0),
    first:true, spent:0, route:[]};
}
function move(input, state, action) {
  const next={cards:new Map(state.cards), hand:state.hand.slice(), pen:state.pen,
    undo:state.undo, first:false, spent:state.spent, route:state.route.concat(copy(action))};
  if (action.kind==='power' && action.powerType===1) {
    const w=input.withdraw;
    assert.ok(state.first && w && w.verified===true && state.undo>0, 'Withdraw is initially verified and owned');
    assert.equal(action.id,w.id);
    const target=state.hand.find(c=>c.id===w.id); assert.ok(target,'Withdraw is the actual last card');
    next.hand=next.hand.filter(c=>c!==target); next.undo--; next.spent++;
    const restored={...target,zone:'board',available:!w.blockedBy.length,selectable:true,
      blockedBy:w.blockedBy.slice(),specialType:0};
    next.cards.set(restored.id,restored);
    for (const id of w.covers) {
      const below=next.cards.get(id); assert.ok(below,'Withdraw covers a present known card');
      next.cards.set(id,{...below,blockedBy:below.blockedBy.concat(restored.id)});
    }
    return next;
  }
  const target=state.cards.get(action.id); assert.ok(target,'route identity is present exactly once');
  assert.notEqual(target.selectable,false); assert.notEqual(target.locked,true);
  assert.equal(target.specialType,0,'no unmodeled special transition');
  const blocked=target.blockedBy.some(id=>state.cards.has(id));
  if (action.kind==='power') {
    assert.equal(action.powerType,3,'only independently modeled powers may be certified');
    assert.equal(target.zone,'board'); assert.ok(blocked,'owned Penetrate addresses a covered card');
    assert.ok(state.pen>0,'power must exist in finite stock');
    assert.equal(state.hand.filter(c=>c.type===target.type).length,2,'Penetrate closes an exact existing pair');
    next.pen--; next.spent++;
  } else {
    assert.equal(action.kind,'card'); assert.equal(blocked,false,'normal pick cannot cross a blocker');
  }
  next.cards.delete(target.id); next.hand=insert(state.hand,target);
  assert.ok(next.hand.length<input.capacity,'seventh nonmatching card is a loss, not a legal route');
  return next;
}
function choices(input,state) {
  const actions=[];
  for (const c of state.cards.values()) {
    if (c.selectable===false || c.locked===true || c.specialType!==0) continue;
    const blocked=c.blockedBy.some(id=>state.cards.has(id));
    const pair=state.hand.filter(t=>t.type===c.type).length===2;
    if (!blocked && (pair || state.hand.length+1<input.capacity)) actions.push({kind:'card',id:c.id});
    if (blocked && c.zone==='board' && pair && state.pen>0) actions.push({kind:'power',powerType:3,id:c.id});
  }
  const w=input.withdraw;
  if (state.first && state.undo>0 && w && w.verified===true &&
      w.zone==='board' && state.hand.some(t=>t.id===w.id)) actions.push({kind:'power',powerType:1,id:w.id});
  return actions;
}
function key(state) {
  return JSON.stringify([[...state.cards].sort((a,b)=>a[0].localeCompare(b[0])).map(([id,c])=>[id,c.blockedBy]),
    state.hand.map(c=>[c.id,c.type]),state.pen,state.undo,state.first]);
}
function oracle(input, initial=start(input)) {
  const total=input.cards.length+input.tray.length, memo=new Map(); let expanded=0;
  function visit(state) {
    const stamp=key(state); if(memo.has(stamp))return memo.get(stamp);
    expanded++;
    const cleared=total-state.cards.size-state.hand.length;
    let result={complete:state.cards.size===0&&state.hand.length===0,cleared,spent:state.spent,route:state.route};
    for (const action of choices(input,state)) {
      const child=visit(move(input,state,action));
      if (child.cleared>result.cleared || child.cleared===result.cleared&&child.spent<result.spent) result=child;
    }
    memo.set(stamp,result); return result;
  }
  return {...visit(initial),expanded};
}
function independentReplay(input,route) {
  let state=start(input);
  for (const action of route) state=move(input,state,action);
  return {state,cleared:input.cards.length+input.tray.length-state.cards.size-state.hand.length,
    complete:state.cards.size===0&&state.hand.length===0};
}
function compare(input) {
  const before=JSON.stringify(input), expected=oracle(input), result=finish(input);
  assert.equal(JSON.stringify(input),before,'planner never mutates the immutable input');
  assert.ok(['solved','best'].includes(result.status),JSON.stringify(result));
  const replay=independentReplay(input,result.route);
  assert.equal(replay.complete,expected.complete,'exact reachability agrees with exhaustive independent oracle');
  assert.equal(replay.cleared,expected.cleared,'published terminal route is globally maximal on tiny states');
  assert.equal(result.bestCleared,replay.cleared);
  assert.equal(result.totalCards,input.cards.length+input.tray.length);
  assert.equal(result.complete,replay.complete);
  if (!expected.complete) {
    assert.equal(result.optimal,true);
    assert.ok(result.exhaustive===true || result.bestCleared===result.upperBound,
      'maximal nonwinning progress requires exhaustion or an attained sound upper bound');
  }
  return {input,result,expected,replay};
}

test('oracle independently models group insertion and adjacent trio rather than set matching',()=>{
  const a={id:'a',type:'A'}, b={id:'b',type:'B'}, a2={id:'a2',type:'A'}, a3={id:'a3',type:'A'};
  assert.deepEqual(insert([a,a2,b],a3).map(c=>c.type),['B']);
  assert.deepEqual(insert([a,b,a2],a3).map(c=>c.type),['A','A','B','A']);
});
test('every complete six-card solution is replayable and conserves unused power stock',()=>{
  const s=board(['A','A','A','B','B','B'],[],{inventory:[{type:3,count:2},{type:1,count:2}]});
  const {result,replay}=compare(s); assert.equal(result.status,'solved');
  assert.equal(replay.state.spent,0); assert.equal(replay.state.pen,2); assert.equal(replay.state.undo,2);
});
test('seventh-slot trio is legal; unrelated seventh single cannot be certified',()=>{
  compare(board(['A','B','C'],['A','A','B','B','C','C']));
  const blocked=board(['G','G','G'],['A','B','C','D','E','F']);
  const {result,replay}=compare(blocked); assert.equal(result.complete,false); assert.equal(replay.cleared,0);
});
test('maximum captured cards is not mistaken for maximum cleared cards',()=>{
  const s=board(['A','B','C','D','E','F']); const {result,replay}=compare(s);
  assert.equal(result.complete,false); assert.equal(replay.cleared,0);
  assert.ok(replay.state.hand.length<=6); assert.equal(result.bestCleared,0);
});
test('verified reserve dependencies are part of the same whole-board proof',()=>{
  const s=board(['A','A','A']); s.cards.forEach(c=>{c.zone='reserve';c.storageVerified=true;});
  cover(s,0,1); cover(s,1,2); const {result}=compare(s);
  assert.deepEqual(result.route.map(a=>a.id),['c3','c2','c1']);
});

function powerTrap(stock) {
  const s=board(['A','B','C','X','X','X'],['A','A','B','B','C','C'],{inventory:[{type:3,count:stock}]});
  for(let i=0;i<3;i++)cover(s,i,3); return s;
}
test('finite owned Penetrate is integrated into the full route, not a random rescue',()=>{
  const {result,replay}=compare(powerTrap(1)); assert.equal(result.status,'solved');
  assert.equal(result.route[0].kind,'power'); assert.equal(result.route[0].powerType,3);
  assert.equal(replay.state.spent,1); assert.equal(replay.state.pen,0);
});
test('same balanced board without Penetrate stock is exhaustively unsolved',()=>{
  const {result,replay}=compare(powerTrap(0)); assert.equal(result.complete,false);
  assert.equal(replay.cleared,0); assert.deepEqual(result.route,[]);
});
test('unknown owned powers do not become fabricated winning transitions',()=>{
  const s=powerTrap(0); s.inventory.push({type:4,count:10},{type:2,count:10},{type:0,count:10},{type:5,count:10});
  const result=finish(s); assert.notEqual(result.status,'solved');
  assert.ok(!result.route || result.route.every(a=>a.kind==='card'||[1,3].includes(a.powerType)));
});

function withdrawTrap(stock) {
  // The fifth tray card X blocks three needed nonmatching picks by capacity.
  // Verified return restores X far from this graph, allowing Y,Z,A to clear.
  const s=board(['A','B','X','X','Y','Y','Z','Z','Y','Z'],['A','A','B','B','X'],
    {inventory:[{type:1,count:stock}]});
  cover(s,0,8);cover(s,0,9);
  for(let i=1;i<8;i++)cover(s,i,0);
  s.withdraw={verified:true,id:'t5',zone:'board',blockedBy:[],covers:[]};return s;
}
test('initial verified Withdraw is modeled with exact identity and finite stock',()=>{
  const {result,replay}=compare(withdrawTrap(1));assert.equal(result.status,'solved');
  assert.deepEqual(result.route[0],{kind:'power',powerType:1,id:'t5'});
  assert.equal(replay.state.undo,0);assert.equal(replay.state.spent,1);
});
test('a supposed Withdraw route is not usable without the owned unit',()=>{
  const {result}=compare(withdrawTrap(0));assert.equal(result.complete,false);
  assert.equal(result.bestCleared,0);assert.ok(result.route.every(a=>a.kind==='card'));
});
test('restored board geometry is part of the proof, not just an extra tray space',()=>{
  const solver=factory(),s=withdrawTrap(1);assert.equal(finish(s,solver).status,'solved');
  const changed=copy(s);changed.withdraw.covers=['c1'];
  const {result}=compare(changed);assert.equal(result.complete,false);
  const cached=finish(changed,solver);assert.equal(cached.complete,false);
});

function seededCases(withPower) {
  let seed=withPower?937:1847;
  const rand=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;};
  const cases=[];
  for(let trial=0;trial<40;trial++) {
    const types=['A','A','A','B','B','B','C','C','C'];
    for(let i=types.length-1;i>0;i--){const j=rand(i+1);[types[i],types[j]]=[types[j],types[i]];}
    const s=board(types,[],{signature:'oracle-'+withPower+'-'+trial,inventory:[{type:3,count:withPower?1:0}]});
    for(let i=0;i<s.cards.length;i++)for(let j=i+1;j<s.cards.length;j++)if(rand(100)<35)cover(s,i,j);
    cases.push(s);
  }
  return cases;
}
for(const powered of [false,true])test('independent exhaustive tiny DAG corpus agrees, powers='+powered,()=>{
  let wins=0,losses=0;
  for(const input of seededCases(powered)){const {expected}=compare(input);expected.complete?wins++:losses++;}
  assert.ok(wins>0,'corpus contains winning boards');
  // Nine cards are deliberately small for an independent exhaustive oracle.
  // A separate crowded balanced fixture above proves the losing branch.
  assert.equal(wins+losses,40);
});

test('crowded initial tray corpus exercises actual power spending and finite stock differences',()=>{
  let seed=6503,winsWithout=0,winsWith=0,powerRequired=0;
  const rand=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;};
  for(let trial=0;trial<40;trial++) {
    const hand=trial%2?['A','A','B','B','C','C']:['A','A','B','B'];
    const types=trial%2?['A','B','C','X','X','X']:['A','B','C','C','C','D','D','D'];
    for(let i=types.length-1;i>0;i--){const j=rand(i+1);[types[i],types[j]]=[types[j],types[i]];}
    const s=board(types,hand,{signature:'crowded-'+trial,inventory:[{type:3,count:0}]});
    for(let i=0;i<s.cards.length;i++)for(let j=i+1;j<s.cards.length;j++)if(rand(100)<40)cover(s,i,j);
    const without=compare(s);if(without.expected.complete)winsWithout++;
    s.inventory[0].count=1;const withPower=compare(s);if(withPower.expected.complete)winsWith++;
    if(withPower.expected.complete&&!without.expected.complete){powerRequired++;assert.ok(withPower.result.route.some(a=>a.powerType===3));}
    assert.ok(withPower.expected.cleared>=without.expected.cleared,'an unused extra owned unit cannot worsen the optimum');
  }
  assert.ok(winsWith>=winsWithout);assert.ok(powerRequired>0,'corpus must actually need Penetrate, not merely contain stock');
});

test('independent initial-Withdraw corpus includes a restored card blocked by otherwise equivalent faces',()=>{
  let seed=23177,compared=0;
  const rand=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;};
  for(let trial=0;trial<24;trial++) {
    const types=['A','B','X','X','C','C','C','D','D','D'];
    for(let i=types.length-1;i>0;i--){const j=rand(i+1);[types[i],types[j]]=[types[j],types[i]];}
    const s=board(types,['A','A','B','B','X'],{signature:'withdraw-'+trial,
      inventory:[{type:1,count:1},{type:3,count:trial%2}]});
    for(let i=0;i<s.cards.length;i++)for(let j=i+1;j<s.cards.length;j++)if(rand(100)<25)cover(s,i,j);
    s.withdraw={verified:true,id:'t5',zone:'board',blockedBy:[s.cards[rand(s.cards.length)].id],covers:[]};
    compare(s);compared++;
  }
  assert.equal(compared,24);
});

test('geometric 18-card board proves a local-trio route can lose an existing full solution',()=>{
  const tuples=[['D',0,24,32],['A',0,12,0],['B',0,48,32],['F',0,0,0],['F',1,0,32],['D',1,12,0],
    ['C',1,36,32],['C',1,0,0],['F',2,24,32],['E',2,12,0],['A',2,48,32],['E',2,24,0],
    ['C',3,12,32],['A',3,12,0],['B',3,48,32],['E',3,36,0],['B',4,0,32],['D',4,36,0]];
  const s=board(tuples.map(v=>v[0]));
  s.cards.forEach((c,i)=>{const t=tuples[i];Object.assign(c,{layer:t[1],row:t[2],col:t[3]});});
  for(let i=0;i<s.cards.length;i++)for(let j=0;j<s.cards.length;j++) {
    const a=s.cards[i],b=s.cards[j];
    if(b.layer>a.layer&&Math.abs(b.row-a.row)<16&&Math.abs(b.col-a.col)<20)cover(s,i,j);
  }
  const oldSource=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_planner.js'),'utf8');
  const old=vm.runInNewContext(oldSource,{Date:{now:()=>0}});let local;
  for(let i=0;i<2000;i++){local=copy(old({...s,matchSize:3}));if(local.status!=='searching')break;}
  assert.equal(local.status,'move');
  assert.deepEqual(local.sequence,['c14','c10','c18','c16','c12']);
  const localReplay=independentReplay(s,local.sequence.map(id=>({kind:'card',id})));
  const tail=oracle(s,localReplay.state); assert.equal(tail.complete,false,'local first-trio choice destroys all full solutions');
  const known=[14,10,16,12,8,6,2,13,9,7,17,15,11,0,4,5,1,3].map(i=>({kind:'card',id:'c'+(i+1)}));
  assert.equal(independentReplay(s,known).complete,true,'independent full-route witness really empties board and hand');
  const result=finish(s),proof=independentReplay(s,result.route);
  assert.equal(result.status,'solved'); assert.equal(result.complete,true); assert.equal(proof.complete,true);
  assert.equal(proof.cleared,18); assert.equal(proof.state.spent,0);
});

test('changed board invalidates a cached full route even when caller reuses signature',()=>{
  const solver=factory(),s=board(['A','A','A']); assert.equal(finish(s,solver).status,'solved');
  const changed=copy(s); changed.cards[2].type='B';
  const next=finish(changed,solver); assert.notEqual(next.status,'solved');
  assert.equal(next.complete,false); assert.equal(independentReplay(changed,next.route).cleared,0);
});
test('finite stock changes invalidate a cached power proof with reused signature',()=>{
  const solver=factory(),s=powerTrap(1);assert.equal(finish(s,solver).status,'solved');
  const changed=copy(s);changed.inventory[0].count=0;
  const next=finish(changed,solver);assert.notEqual(next.status,'solved');assert.equal(next.complete,false);
  assert.ok(next.route.every(a=>a.kind!=='power'));
});


#import <Foundation/Foundation.h>
#import "../Sources/SDKtools/STBilliardsResourceExporter.h"
#include <unistd.h>
#include <stdio.h>

static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *message) {
    checks++; if (!condition) { failures++; fprintf(stderr, "FAIL %s\n", message.UTF8String); }
}
static void Varint(NSMutableData *data, uint64_t value) {
    do { uint8_t b=value&127; value>>=7; if(value)b|=128; [data appendBytes:&b length:1]; } while(value);
}
static void Field(NSMutableData *data, unsigned number, NSData *value) {
    Varint(data, ((uint64_t)number<<3)|2); Varint(data,value.length); [data appendData:value];
}
static NSData *Manifest(NSString *name, NSUInteger bytes, unsigned game) {
    NSMutableData *record=[NSMutableData data];
    Field(record,1,[name dataUsingEncoding:NSUTF8StringEncoding]);
    Field(record,2,[@"00000000000000000000000000000000" dataUsingEncoding:NSUTF8StringEncoding]);
    Varint(record,48);Varint(record,bytes);
    NSMutableData *result=[NSMutableData data]; Varint(result,8);Varint(result,game);
    Varint(result,16);Varint(result,1048);Field(result,7,record);return result;
}
static NSURL *Run(NSURL *documents, NSURL *library, NSDictionary **diagnostic, NSError **error) {
    __block NSURL *result=nil; __block NSDictionary *diag=nil; __block NSError *failure=nil;
    dispatch_semaphore_t done=dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{ @autoreleasepool {
        result=[STBilliardsResourceExporter writePackageFromDocumentsURL:documents libraryURL:library
            destinationDirectory:[documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES]
            diagnostic:&diag error:&failure];
        dispatch_semaphore_signal(done);
    }});
    Check(dispatch_semaphore_wait(done,dispatch_time(DISPATCH_TIME_NOW,30*NSEC_PER_SEC))==0,@"bounded exporter completion");
    if(diagnostic)*diagnostic=diag;if(error)*error=failure;return result;
}
static NSDictionary *JSON(NSURL *url) {
    NSData *data=url?[NSData dataWithContentsOfURL:url]:nil;
    return data?[NSJSONSerialization JSONObjectWithData:data options:0 error:nil]:nil;
}
static NSArray *Variants(NSDictionary *report) {
    NSMutableArray *out=[NSMutableArray array];
    for(NSDictionary *catalog in report[@"cachedCatalogs"])
        for(NSDictionary *record in catalog[@"records"])
            [out addObjectsFromArray:record[@"variants"]];
    return out;
}
static NSDictionary *Payload(NSDictionary *report) {
    for(NSDictionary *variant in Variants(report))if(variant[@"data"])return variant;
    return nil;
}
int main(void) { @autoreleasepool {
    NSFileManager *fm=[NSFileManager new];
    NSURL *base=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:
        [@"sdktools-billiards-test-" stringByAppendingString:NSUUID.UUID.UUIDString]] isDirectory:YES];
    NSURL *documents=[base URLByAppendingPathComponent:@"Documents" isDirectory:YES];
    NSURL *library=[base URLByAppendingPathComponent:@"Library" isDirectory:YES];
    NSURL *bundles=[documents URLByAppendingPathComponent:@"AssetBundles" isDirectory:YES];
    Check([fm createDirectoryAtURL:bundles withIntermediateDirectories:YES attributes:nil error:nil],@"create document fixture");
    Check([fm createDirectoryAtURL:library withIntermediateDirectories:YES attributes:nil error:nil],@"create library fixture");
    NSDictionary *diag=nil;NSError *error=nil;
    NSURL *url=Run(documents,library,&diag,&error);NSDictionary *report=JSON(url);
    Check(url&&error==nil&&report!=nil,@"empty cache still returns a diagnostic JSON");
    Check([diag[@"status"] isEqual:@"resources_missing"]&&[diag[@"filesExported"] integerValue]==0,@"empty cache is not success reading balls");
    Check([report[@"format"] isEqual:@"SDKtools.BilliardsResources"]&&[report[@"toolVersion"] isEqual:@"3.19.6"],@"new export format identified");
    Check(![report[@"currentMatchIdentified"] boolValue]&&![report[@"billiardsPredictionAvailable"] boolValue],@"cached files never identify current match or prediction");

    NSString *name=@"billiard_cres_0123456789abcdef0123456789abcdef";
    NSURL *catalog=[documents URLByAppendingPathComponent:@"pro_AssetBundleRecord_us_20_3_0_1_v3.svga"];
    NSData *bytes=[@"UnityFS\0FIXTURE_ONLY_NOT_EXECUTABLE" dataUsingEncoding:NSUTF8StringEncoding];
    Check([Manifest(name,bytes.length,20) writeToURL:catalog atomically:YES],@"write current catalog fixture");
    NSURL *original=[bundles URLByAppendingPathComponent:name];
    Check([bytes writeToURL:original atomically:YES],@"write selected bundle fixture");
    NSURL *unrelated=[documents URLByAppendingPathComponent:@"private-account.json"];
    Check([@"DO_NOT_EXPORT_ACCOUNT_OR_CHAT" writeToURL:unrelated atomically:YES encoding:NSUTF8StringEncoding error:nil],@"create unrelated fixture");
    report=JSON(Run(documents,library,&diag,&error));NSDictionary *payload=Payload(report);
    Check([diag[@"filesExported"] integerValue]==1&&[diag[@"manifestsAccepted"] integerValue]==1,@"one evidenced catalog and selected file exported");
    NSData *decoded=payload[@"data"]?[[NSData alloc] initWithBase64EncodedString:payload[@"data"] options:0]:nil;
    Check([decoded isEqual:bytes],@"binary NUL retained by base64");
    Check([payload[@"observedSHA256"] length]==64&&[payload[@"representation"] isEqual:@"originalNamedBundle"],@"actual bytes and representation recorded");
    Check([[[report[@"cachedCatalogs"] firstObject] objectForKey:@"manifestVersion"] integerValue]==1048,@"current manifest version not pinned to embedded1047");
    NSString *text=[[NSString alloc]initWithData:[NSJSONSerialization dataWithJSONObject:report options:0 error:nil] encoding:NSUTF8StringEncoding];
    Check(![text containsString:@"DO_NOT_EXPORT_ACCOUNT_OR_CHAT"]&&![text containsString:base.path],@"unrelated contents and absolute sandbox path omitted");

    Check([fm removeItemAtURL:original error:nil],@"remove original for recompressed route");
    NSURL *lz4=[bundles URLByAppendingPathComponent:[name stringByAppendingString:@".lz4"]];
    NSData *recompressed=[@"UnityFS recompressed representation has different bytes" dataUsingEncoding:NSUTF8StringEncoding];
    Check([recompressed writeToURL:lz4 atomically:YES],@"write recompressed variant");
    report=JSON(Run(documents,library,&diag,&error));payload=Payload(report);
    Check([diag[@"filesExported"] integerValue]==1&&[payload[@"representation"] isEqual:@"runtimeRecompressedLZ4"],@"recompressed route remains collectable");
    Check([payload[@"manifestSizeComparison"] isEqual:@"not_applicable"]&&[payload[@"manifestMD5Comparison"] isEqual:@"not_performed"],@"recompression does not falsely validate original MD5/size");
    Check([fm removeItemAtURL:lz4 error:nil],@"remove recompressed variant");

    NSURL *cache=[library URLByAppendingPathComponent:[NSString stringWithFormat:@"UnityCache/Shared/%@/abcdef",name] isDirectory:YES];
    Check([fm createDirectoryAtURL:cache withIntermediateDirectories:YES attributes:nil error:nil],@"create precise Unity cache fixture");
    NSURL *cacheData=[cache URLByAppendingPathComponent:@"__data"];
    Check([bytes writeToURL:cacheData atomically:YES],@"write cache payload");
    report=JSON(Run(documents,library,&diag,&error));payload=Payload(report);
    Check([diag[@"filesExported"] integerValue]==1&&[payload[@"representation"] isEqual:@"unityCache"],@"single precise fallback selected");
    NSURL *otherData=[cache URLByAppendingPathComponent:@"other_data"];
    Check([bytes writeToURL:otherData atomically:YES],@"create ambiguous fallback");
    report=JSON(Run(documents,library,&diag,&error));
    Check([diag[@"filesExported"] integerValue]==0&&Payload(report)==nil,@"multiple cache data files are not guessed");
    Check([fm removeItemAtURL:otherData error:nil]&&[fm removeItemAtURL:cacheData error:nil],@"clear fallback payloads");

    Check(symlink(unrelated.fileSystemRepresentation,original.fileSystemRepresentation)==0,@"create file link fixture");
    report=JSON(Run(documents,library,&diag,&error));
    Check([diag[@"filesExported"] integerValue]==0&&Payload(report)==nil,@"selected bundle name cannot follow an unrelated link");
    Check([fm removeItemAtURL:original error:nil],@"remove link fixture");
    Check([Manifest(name,bytes.length,2007) writeToURL:catalog atomically:YES],@"wrong identity under matching filename");
    report=JSON(Run(documents,library,&diag,&error));
    Check([diag[@"manifestsAccepted"] integerValue]==0&&[diag[@"filesExported"] integerValue]==0,@"filename cannot override protobuf game identity");
    Check(![STBilliardsResourceExporter writePackageFromDocumentsURL:documents libraryURL:library destinationDirectory:
        [documents URLByAppendingPathComponent:@"SDKtools"] diagnostic:nil error:&error],@"main-thread scan rejected");
    Check([fm removeItemAtURL:base error:nil],@"cleanup isolated test tree");
    printf("Billiards Foundation: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
}}

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/autoplay_planner.js'), 'utf8');
function card(id, type, blockedBy = [], extra = {}) {
  return {id, type, zone: 'board', blockedBy, available: !blockedBy.length, ...extra};
}
function state(cards, types = [], extra = {}) {
  return {cards, tray: types.map((type, i) => ({id: `tray${i}`, type})), capacity: 7, matchSize: 3, budgetMs: 40, ...extra};
}
function run(input, clock = () => 0) {
  const context = vm.createContext({Date: {now: clock}});
  const before = Object.keys(context);
  const planner = vm.runInContext(source, context, {timeout: 1000});
  const result = JSON.parse(JSON.stringify(planner(input)));
  assert.deepEqual(Object.keys(context), before, 'planner must not install globals');
  return result;
}
function replay(input, result) {
  const remaining = new Map(input.cards.map(x => [x.id, x]));
  const tray = input.tray.map(x => x.type);
  assert.deepEqual(result.sequence, result.actions);
  const initialCount = tray.length;
  let tripleCount = 0;
  for (let step = 0; step < result.actions.length; step++) {
    const id = result.actions[step];
    const card = remaining.get(id);
    assert.ok(card, 'planned card must still exist');
    assert.ok(card.available || card.blockedBy.length, 'disabled uncovered card cannot be selected');
    assert.ok(card.blockedBy.every(id => !remaining.has(id)), 'every blocker must already have left');
    remaining.delete(id); tray.push(card.type);
    if (tray.filter(type => type === card.type).length === 3) {
      tripleCount++;
      assert.equal(step, result.actions.length - 1, 'proof ends at its first completed triple');
      for (let i = tray.length - 1; i >= 0; i--) if (tray[i] === card.type) tray.splice(i, 1);
    }
    assert.ok(tray.length < input.capacity, 'no intermediate step may fill the final slot');
  }
  if (result.status === 'move') {
    assert.equal(tripleCount, 1, 'every executable route completes a triple');
    assert.equal(result.cardID, result.sequence[0]);
    assert.equal(result.peakTrayCount, initialCount + result.sequence.length);
    assert.ok(result.peakTrayCount <= input.capacity);
    const expectedIDs = [...input.tray.filter(c => c.type === result.matchedType).map(c => c.id),
      ...result.sequence.filter(id => input.cards.find(c => c.id === id).type === result.matchedType)];
    assert.equal(expectedIDs.length, 3); assert.deepEqual(result.tripleCardIDs, expectedIDs);
  } else { assert.equal(result.cardID, null); assert.deepEqual(result.sequence, []); }
  return {remaining, tray};
}

test('completes an existing pair with the exact matching third card', () => {
  const input = state([card('noise', 'B'), card('match', 'A')], ['A', 'A']);
  const output = run(input);
  assert.equal(output.status, 'move'); assert.equal(output.cardID, 'match');
  replay(input, output);
});
test('finds and replays a complete three-card solution rather than matching pairs', () => {
  const input = state([card('1', 'A'), card('2', 'A'), card('3', 'A')]);
  const output = run(input), replayed = replay(input, output);
  assert.equal(output.reason, 'solution_found'); assert.equal(output.stats.completeSolution, true);
  assert.equal(output.actions.length, 3); assert.equal(replayed.remaining.size, 0); assert.equal(replayed.tray.length, 0);
});
test('removes the blocker before selecting the cards it reveals', () => {
  const input = state([card('cover', 'B'), card('a1', 'A', ['cover']), card('a2', 'A'), card('a3', 'A')], ['B', 'B']);
  const output = run(input); assert.equal(output.cardID, 'cover');
  assert.deepEqual(output.actions, ['cover']); assert.equal(output.matchedType, 'B'); replay(input, output);
});
test('waits for both shared blockers and does not mistake one removal for exposure', () => {
  const input = state([card('b1', 'B'), card('b2', 'C'), card('a1', 'A', ['b1', 'b2']), card('a2', 'A'), card('a3', 'A')]);
  const output = run(input); replay(input, output);
  assert.equal(output.matchedType, 'A'); assert.equal(output.stats.searchMode, 'unlock');
  assert.ok(output.actions.indexOf('a1') > output.actions.indexOf('b1'));
  assert.ok(output.actions.indexOf('a1') > output.actions.indexOf('b2'));
});
test('rejects a pick that fills the final slot without immediately forming a triple', () => {
  const input = state([card('1', 'G')], ['A', 'B', 'C', 'D', 'E', 'F']);
  const output = run(input); assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'tray_capacity');
});
test('a seventh-slot pick is allowed only when the same pick clears its triple', () => {
  const input = state([card('third', 'A'), card('bad', 'D')], ['A', 'A', 'B', 'B', 'C', 'C']);
  const output = run(input); assert.equal(output.cardID, 'third'); replay(input, output);
});
test('avoids an immediate tray dead end even when that pick exposes several cards', () => {
  const input = state([card('trap', 'G'), card('right', 'A'), card('b1', 'B', ['trap']), card('b2', 'B', ['trap']), card('b3', 'B', ['trap'])], ['A', 'A', 'C', 'D', 'E']);
  const output = run(input); assert.equal(output.cardID, 'right'); replay(input, output);
});
test('does not select an uncovered disabled card', () => {
  const output = run(state([card('1', 'A', [], {available: false})], ['A', 'A']));
  assert.equal(output.status, 'blocked'); assert.equal(output.cardID, null);
});
test('reserve cards participate in the same triple rules', () => {
  const input = state([card('reserve', 'A', [], {zone: 'reserve'})], ['A', 'A']);
  const output = run(input); assert.equal(output.cardID, 'reserve'); assert.equal(output.stats.completeSolution, true);
});
test('returns solved only when board and tray are both clear', () => {
  assert.equal(run(state([])).status, 'solved');
  assert.equal(run(state([], ['A'])).reason, 'unmatched_tray');
});
test('a single unmatched terminal card is not advertised as a solution', () => {
  const output = run(state([card('1', 'A')]));
  assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'no_complete_triple'); assert.equal(output.stats.completeSolution, false);
});
test('finite node budget is obeyed and any emitted route remains legal', () => {
  const input = state(Array.from({length: 24}, (_, i) => card('c' + i, 'T' + Math.floor(i / 3))), [], {maxNodes: 2});
  const output = run(input); assert.ok(output.stats.generated <= 2); assert.equal(output.status, 'blocked'); assert.equal(output.stats.limit, 'node_budget'); replay(input, output);
});
test('finite search depth is obeyed', () => {
  const input = state([card('1', 'A'), card('2', 'A'), card('3', 'A')], [], {maxDepth: 1});
  const output = run(input); assert.equal(output.stats.depth, 1); assert.equal(output.stats.limit, 'depth_limit'); assert.equal(output.stats.completeSolution, false);
});
test('expired time budget produces no speculative action', () => {
  let now = 0;
  const output = run(state([card('1', 'A'), card('2', 'A'), card('3', 'A')], [], {budgetMs: 1}), () => now++);
  assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'search_budget_exhausted'); assert.equal(output.cardID, null);
});
test('equivalent cards are pruned while the fast direct trio stays bounded', () => {
  const input = state(Array.from({length: 30}, (_, i) => card('c' + i, 'T' + Math.floor(i / 3))), [], {beamWidth: 1, maxNodes: 100, maxDepth: 4});
  const output = run(input); assert.ok(output.stats.pruned > 0); assert.ok(output.stats.generated <= 100); replay(input, output);
});
test('input and its nested arrays are unchanged', () => {
  const input = state([card('1', 'A'), card('2', 'A'), card('3', 'A')]);
  const original = structuredClone(input);
  Object.freeze(input.cards[0].blockedBy); Object.freeze(input.cards[0]); Object.freeze(input.cards); Object.freeze(input.tray); Object.freeze(input);
  run(input); assert.deepEqual(input, original);
});
test('type and id strings cannot collide with inherited object properties', () => {
  const input = state([card('__proto__', 'constructor'), card('toString', 'constructor'), card('hasOwnProperty', 'constructor')]);
  const output = run(input); assert.equal(output.stats.completeSolution, true); replay(input, output);
});
test('wide bitsets correctly handle card indices above 31 and 63', () => {
  const input = state(Array.from({length: 66}, (_, i) => card('c' + i, i >= 63 ? 'match' : 'T' + i, [], {available: i >= 63})), [], {maxDepth: 3});
  const output = run(input); assert.equal(output.status, 'move');
  assert.ok(output.actions.every(id => Number(id.slice(1)) >= 63)); replay(input, output);
});
for (const [name, mutate, reason] of [
  ['duplicate board IDs', s => s.cards.push(card('1', 'B')), 'duplicate_or_invalid_card_id'],
  ['duplicate tray IDs', s => s.tray.push({id: 'tray0', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['board-tray ID collision', s => s.tray.push({id: '1', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['missing card face', s => delete s.cards[0].type, 'unreadable_card'],
  ['special unknown face', s => s.cards[0].type = 'unknown', 'unreadable_card'],
  ['missing tray face', s => delete s.tray[0].type, 'unreadable_tray'],
  ['absent blocker', s => {s.cards[0].blockedBy = ['absent']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['self blocker', s => {s.cards[0].blockedBy = ['1']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['duplicate blocker', s => {s.cards.push(card('2', 'B')); s.cards[0].blockedBy = ['2', '2']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['cycle', s => {s.cards[0].blockedBy = ['2']; s.cards[0].available = false; s.cards.push(card('2', 'B', ['1']));}, 'cyclic_blockers'],
  ['covered but available', s => {s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['reserve blockers', s => {s.cards[0].zone = 'reserve'; s.cards[0].available = false; s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['unsettled triple in tray', s => {s.tray = ['a', 'b', 'c'].map(id => ({id, type: 'A'}));}, 'unsettled_tray'],
  ['full tray', s => {s.tray = Array.from({length: 7}, (_, i) => ({id: 't' + i, type: 'T' + i}));}, 'invalid_board_size'],
  ['unknown capacity', s => delete s.capacity, 'unsupported_rules'],
  ['pair matching requested', s => s.matchSize = 2, 'unsupported_rules'],
  ['missing availability', s => delete s.cards[0].available, 'unreadable_card']
]) {
  test(`rejects ${name}`, () => {
    const input = state([card('1', 'A')], ['A']); mutate(input);
    const output = run(input); assert.equal(output.status, 'invalid_state'); assert.equal(output.reason, reason); assert.equal(output.cardID, null);
  });
}
test('rejects missing input and excessive board data', () => {
  assert.equal(run(null).reason, 'invalid_input');
  assert.equal(run(state(Array.from({length: 513}, (_, i) => card('c' + i, 'A')))).reason, 'invalid_board_size');
});
test('rejects excessive blocker lists before searching an expensive malformed graph', () => {
  const input = state([card('1', 'A', Array.from({length: 65}, (_, i) => 'c' + i))]);
  assert.equal(run(input).reason, 'excessive_blockers');
});
test('collapses equivalent exposed cards so a broad board still reaches triple routes', () => {
  const input = state(Array.from({length: 90}, (_, i) => card('c' + i, 'T' + (i % 12))), [], {maxDepth: 4, maxNodes: 1800});
  const output = run(input); assert.equal(output.reason, 'triple_route');
  assert.ok(output.stats.depth >= 3); replay(input, output);
});

test('never publishes unrelated singles when no complete triple can be proved', () => {
  const input = state([card('a', 'A'), card('b', 'B'), card('c', 'C'), card('d', 'D')]);
  const output = run(input);
  assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'no_complete_triple');
  assert.equal(output.matchedType, null); assert.deepEqual(output.tripleCardIDs, []); replay(input, output);
});
test('direct trio outranks a tempting unrelated card that reveals many cards', () => {
  const cards = [card('noise', 'N'), ...Array.from({length: 12}, (_, i) => card('hidden' + i, 'H' + i, ['noise'])),
    card('a1', 'A'), card('a2', 'A'), card('a3', 'A')];
  const input = state(cards), output = run(input);
  assert.deepEqual(output.sequence, ['a1', 'a2', 'a3']); assert.equal(output.stats.searchMode, 'direct'); replay(input, output);
});
test('existing single is completed before starting an unrelated fresh trio', () => {
  const input = state([card('b1', 'B'), card('b2', 'B'), card('b3', 'B'), card('a1', 'A'), card('a2', 'A')], ['A']);
  const output = run(input); assert.deepEqual(output.sequence, ['a1', 'a2']);
  assert.deepEqual(output.tripleCardIDs, ['tray0', 'a1', 'a2']); assert.equal(output.peakTrayCount, 3); replay(input, output);
});
test('three matching stacked cards have a direct legal topological route', () => {
  const input = state([card('bottom', 'A', ['middle', 'top']), card('middle', 'A', ['top']), card('top', 'A')]);
  const output = run(input); assert.deepEqual(output.sequence, ['top', 'middle', 'bottom']);
  assert.equal(output.stats.searchMode, 'direct'); replay(input, output);
});
test('an unrelated blocker is picked only with a proved complete triple behind it', () => {
  const input = state([card('noise', 'N'), card('cover', 'B'), card('a1', 'A', ['cover']), card('a2', 'A'), card('a3', 'A')]);
  const output = run(input); assert.equal(output.matchedType, 'A'); assert.equal(output.stats.searchMode, 'unlock');
  assert.equal(output.sequence.includes('noise'), false); assert.equal(output.sequence.includes('cover'), true);
  assert.equal(output.sequence.length, 4); assert.equal(output.tripleCardIDs.includes('cover'), false); replay(input, output);
});
function sevenMoveRoute(types = []) {
  return state([card('b1', 'B'), card('b2', 'C', ['b1']), card('b3', 'D', ['b2']), card('b4', 'E', ['b3']),
    card('a1', 'A', ['b4']), card('a2', 'A', ['b4']), card('a3', 'A', ['b4'])], types);
}
test('a proved seven-move route uses the last slot only for the final triple', () => {
  const input = sevenMoveRoute(), output = run(input);
  assert.equal(output.sequence.length, 7); assert.equal(output.peakTrayCount, 7); assert.equal(output.matchedType, 'A'); replay(input, output);
});
test('the same unlocking route is rejected when an existing card makes it exceed capacity', () => {
  const input = sevenMoveRoute(['X']), output = run(input);
  assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'no_complete_triple'); replay(input, output);
});
test('a depth budget ending before a triple returns no partial route', () => {
  const input = state([card('a1', 'A'), card('a2', 'A'), card('a3', 'A')], [], {maxDepth: 2});
  const output = run(input); assert.equal(output.status, 'blocked'); assert.equal(output.stats.limit, 'depth_limit'); replay(input, output);
});
test('broad direct matching uses three generated states instead of exhausting the old beam budget', () => {
  const input = state(Array.from({length: 228}, (_, i) => card('c' + i, 'T' + (i % 16))), [], {maxNodes: 1800});
  const output = run(input); assert.equal(output.status, 'move'); assert.equal(output.stats.generated, 3);
  assert.equal(output.stats.searchMode, 'direct'); assert.equal(output.stats.limit, null); replay(input, output);
});
test('identical snapshots produce identical proofs without random choice', () => {
  const input = state([card('n', 'N'), card('a1', 'A', ['n']), card('a2', 'A'), card('a3', 'A'), card('b', 'B')]);
  const first = run(input); for (let i = 0; i < 5; i++) assert.deepEqual(run(input), first); replay(input, first);
});
const observedV30 = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/autoplay-board-observed-v30.json'), 'utf8'));
for (const seq of [9, 55]) test('captured V2.9 scene ' + seq + ' refuses a known blocked tray rather than taking a single', () => {
  const snapshot = observedV30.snapshots.find(s => s.sequence === seq), input = snapshot.plannerInput;
  assert.equal(snapshot.rows.length, 49); assert.equal(input.tray.length, seq === 9 ? 5 : 6);
  const output = run(input); assert.equal(output.status, 'blocked');
  assert.equal(output.reason, seq === 9 ? 'no_complete_triple' : 'tray_capacity'); replay(input, output);
});
test('captured masks match the same observed blocker geometry before planner replay', () => {
  for (const snapshot of observedV30.snapshots) for (const row of snapshot.rows) {
    const blockers = snapshot.rows.filter(other => row.zone === 'board' && other.zone === 'board' && other.order > row.order &&
      Math.abs(row.x - other.x) < 79.99 && Math.abs(row.y - other.y) < 89.99).map(other => other.id);
    assert.deepEqual(row.blockedBy, blockers); assert.equal(row.mask, blockers.length > 0);
  }
});
test('cleared tray replays real observed stacked geometry and emits only a full triple', () => {
  const input = structuredClone(observedV30.snapshots.find(s => s.sequence === 55).plannerInput);
  input.tray = []; // Explicit synthetic variant, not a claim that the captured user cleared their tray.
  const output = run(input); assert.equal(output.status, 'move'); replay(input, output);
});

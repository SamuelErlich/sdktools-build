const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/autoplay_planner.js'), 'utf8');
function card(id, type, blockedBy = [], extra = {}) {
  return {id, type, zone:'board', blockedBy, available:!blockedBy.length, ...extra};
}
function state(cards, types = [], extra = {}) {
  return {cards, tray:types.map((type,i)=>({id:'tray'+i,type})), capacity:7, matchSize:3, budgetMs:8, ...extra};
}
function createPlanner(clock = ()=>0) {
  const context = vm.createContext({Date:{now:clock}}), before=Object.keys(context);
  const planner = vm.runInContext(source,context,{timeout:1000});
  return input => { const result=JSON.parse(JSON.stringify(planner(input))); assert.deepEqual(Object.keys(context),before,'no global search state'); return result; };
}
function run(input) { const planner=createPlanner();let result;for(let i=0;i<2000;i++){result=planner(input);if(result.status!=='searching')return result;}throw Error('search did not terminate within bounded calls'); }
for(const target of [null,{type:'a',current:0,total:9}])test('cooperative rush chooses a continuing trio over a greedy direct dead end '+JSON.stringify(target),()=>{
 const cards=[0,1,2,3].map(i=>card('a'+i,'a'));
 for(let i=0;i<3;i++)for(let j=0;j<2;j++)cards.push(card('u'+i+j,'single'+i+j,['a'+i]));
 cards.push(card('b0','b'),card('b1','b'),card('b2','b',['a3']));
 const input=state(cards,['w','x','y','z'],{cooperative:true,mission:target});
 const before=JSON.stringify(input),out=run(input);assert.equal(out.status,'move');
 assert.ok(out.sequence.includes('a3'),'the first trio must release the third B instead of leaving an unmatched blocker');
 assert.equal(out.stats.continuation,'proved');simulate(input,out.sequence);assert.equal(JSON.stringify(input),before);
});
function simulate(input, actions) {
  const remaining = new Map(input.cards.map(c=>[c.id,c]));let tray=input.tray.map(c=>({...c}));
  let triples=0,peak=tray.length,firstIDs=null,firstType=null,lastTriple=false;
  for(const id of actions){
    const c=remaining.get(id);assert.ok(c,'every selected identity exists exactly once');
    assert.notEqual(c.locked,true);assert.notEqual(c.selectable,false);
    assert.ok(c.available||c.blockedBy.length,'disabled uncovered card is not silently activated');
    assert.ok(c.blockedBy.every(b=>!remaining.has(b)),'covered card waits for every blocker');
    remaining.delete(id);tray.push({id:c.id,type:c.type});peak=Math.max(peak,tray.length);assert.ok(peak<=input.capacity);
    const group=tray.filter(t=>t.type===c.type);lastTriple=group.length===3;
    if(lastTriple){triples++;if(!firstIDs){firstIDs=group.map(t=>t.id);firstType=c.type;}tray=tray.filter(t=>t.type!==c.type);}
    assert.ok(tray.length<input.capacity,'a non-triple must not fill the last slot');
  }
  return {remaining,tray,triples,peak,firstIDs,firstType,lastTriple};
}
function replay(input, output) {
  assert.deepEqual(output.actions,output.sequence);
  if(output.status!=='move'){assert.equal(output.cardID,null);assert.deepEqual(output.sequence,[]);assert.equal(output.stats.completePlan,false);return;}
  const r=simulate(input,output.sequence);assert.equal(output.cardID,output.sequence[0]);assert.equal(output.stats.completePlan,true);
  assert.equal(r.lastTriple,true,'no picks after the last useful triple');assert.equal(output.peakTrayCount,r.peak);
  assert.equal(output.matchedType,r.firstType);assert.deepEqual(output.tripleCardIDs,r.firstIDs);
  assert.equal(output.proofKind,'local_trio');assert.equal(r.triples,1,'exactly one next trio is proved');
  assert.equal(output.stats.completeSolution,r.remaining.size===0&&r.tray.length===0);
  return r;
}
function advanceInput(input, actions) {
  const result=simulate(input,actions), remaining=new Set(result.remaining.keys());
  return {...input,cards:[...result.remaining.values()].map(c=>({...c,blockedBy:c.blockedBy.filter(b=>remaining.has(b)),
    available:c.available||(c.blockedBy.length>0&&c.blockedBy.every(b=>!remaining.has(b)))})),tray:result.tray};
}


test('publishes the next trio without waiting to solve the complete six-card board',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t))),output=run(input);
  assert.equal(output.sequence.length,3);assert.equal(output.stats.goal,'next_trio');assert.equal(output.stats.completeSolution,false);replay(input,output);
});
test('completes an existing pair before a fresh exposed trio to preserve headroom',()=>{
  const input=state([card('b1','B'),card('b2','B'),card('b3','B'),card('match','A')],['A','A']),output=run(input);
  assert.equal(output.cardID,'match');assert.deepEqual(output.tripleCardIDs,['tray0','tray1','match']);assert.equal(output.sequence.length,1);replay(input,output);
});
test('seven-slot completion is legal but an unrelated seventh single is not',()=>{
  const input=state([card('c','C'),card('a','A'),card('b','B')],['A','A','B','B','C','C']),output=run(input);
  assert.equal(output.peakTrayCount,7);replay(input,output);
  const blocked=state([card('g1','G'),card('g2','G'),card('g3','G')],['A','B','C','D','E','F']);
  assert.equal(run(blocked).reason,'no_complete_solution');
});
test('an impossible remote trio no longer prevents a local exposed trio',()=>{
  const input=state([card('a1','A'),card('a2','A'),card('a3','A'),card('b1','B',[],{available:false}),card('b2','B'),card('b3','B'),card('noise','N')]);
  const output=run(input);assert.equal(output.status,'move');assert.deepEqual(output.sequence,['a1','a2','a3']);replay(input,output);
});
test('receding local routes make all available progress then stop without arbitrary singles',()=>{
  let input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)).concat([card('locked','C',[],{locked:true}),card('lockedPeer1','C'),card('lockedPeer2','C'),card('noise','N')]));
  let total=0,trios=0;
  for(let i=0;i<10;i++){const output=run(input);if(output.status!=='move'){assert.equal(output.reason,'no_complete_solution');break;}replay(input,output);total+=output.sequence.length;trios++;input=advanceInput(input,output.sequence);}
  assert.equal(total,6);assert.equal(trios,2);assert.equal(input.cards.length,4);assert.equal(input.tray.length,0);
});
test('unmatched blockers are collected only with a fully replayable route completing a trio',()=>{
  const input=state([card('block','X'),card('a1','A',['block']),card('a2','A'),card('a3','A')]),output=run(input);
  assert.ok(output.sequence.includes('block'));assert.equal(output.sequence.length,4);replay(input,output);
});
test('remaining singles and pairs wait for a real board change without a move',()=>{
  const input=state([card('a','A'),card('b','B')],['B']),output=run(input);
  assert.equal(output.status,'blocked');assert.equal(output.reason,'no_remaining_triples');replay(input,output);
});
test('special locked cards cannot be selected but unrelated accessible trios still work',()=>{
  const input=state([card('a1','A',['b'],{locked:true}),card('a2','A'),card('a3','A'),card('b','B')]);
  assert.equal(run(input).reason,'no_complete_solution');
  const changed={...input,cards:input.cards.concat([card('c1','C'),card('c2','C'),card('c3','C')])};replay(changed,run(changed));
});
test('lookahead prefers an equally short trio that exposes another match',()=>{
  const input=state([card('a1','A'),card('a2','A'),card('a3','A'),card('b1','B'),card('b2','B'),card('b3','B'),card('c1','C',['b1']),card('c2','C',['b2']),card('c3','C',['b3'])]);
  const output=run(input);assert.equal(output.matchedType,'B');assert.ok(output.stats.candidates>=2);replay(input,output);
});
test('same-type stacked cards are resolved in topological order',()=>{
  const input=state([card('bottom','A',['middle','top']),card('middle','A',['top']),card('top','A')]),output=run(input);
  assert.deepEqual(output.sequence,['top','middle','bottom']);replay(input,output);
});
test('reserve cards obey the same exact triple rules',()=>{
  const input=state([card('r','A',[],{zone:'reserve'})],['A','A']);replay(input,run(input));
});
test('board clear is distinct from a nonempty unmatched tray',()=>{
  const solved=run(state([]));assert.equal(solved.status,'solved');assert.equal(solved.stats.completeSolution,true);
  assert.equal(run(state([],['A'])).reason,'no_remaining_triples');
});
test('one-node slices resume a local trio and never publish one or two unproved picks',()=>{
  const planner=createPlanner(),input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1});
  let output;for(let i=0;i<3;i++){output=planner(input);assert.equal(output.stats.generated,i+1);if(i<2){assert.equal(output.status,'searching');assert.equal(output.stats.completePlan,false);assert.deepEqual(output.sequence,[]);}}
  assert.equal(output.status,'move');assert.equal(output.stats.slices,3);replay(input,output);
});
test('changed board invalidates unfinished search even with a reused external key',()=>{
  const planner=createPlanner(),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1,stateKey:'same'});
  planner(input);planner(input);const changed=structuredClone(input);changed.cards[0].id='replacement';
  const next=planner(changed);assert.equal(next.stats.slices,1);assert.equal(next.stats.generated,1);assert.equal(next.status,'searching');
});
test('changed context and invalid observations discard the prior continuation',()=>{
  const planner=createPlanner(),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1,stateKey:'one'});
  planner(input);assert.equal(planner({...input,stateKey:'two'}).stats.slices,1);
  assert.equal(planner(null).status,'invalid_state');assert.equal(planner(input).stats.slices,1);
});
test('expired time slice returns searching when there is no proved next trio',()=>{
  let now=0;const planner=createPlanner(()=>now++),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{budgetMs:1});
  const result=planner(input);assert.equal(result.status,'searching');assert.equal(result.stats.limit,'time_slice');assert.deepEqual(result.sequence,[]);
});
test('a proved prefix remains executable when the remaining comparison reaches its budget',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxTotalNodes:3});const output=run(input);
  assert.equal(output.status,'move');assert.equal(output.sequence.length,3);assert.equal(output.stats.limit,'total_node_budget');replay(input,output);
});
test('total node budget without a completed trio is never mislabeled impossible',()=>{
  const input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxTotalNodes:2,maxNodes:1}),output=run(input);
  assert.equal(output.reason,'search_limit_reached');assert.equal(output.stats.limit,'total_node_budget');assert.equal(output.stats.generated,2);assert.equal(output.stats.completeSearch,false);replay(input,output);
});
test('depth ceiling applies to the next trio rather than the whole board',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxDepth:3});replay(input,run(input));
  assert.equal(run({...input,maxDepth:2}).reason,'search_limit_reached');
});
test('input remains unchanged and inherited-property identifiers do not collide',()=>{
  const input=state([card('__proto__','constructor'),card('toString','constructor'),card('hasOwnProperty','constructor')]);const before=structuredClone(input);
  Object.freeze(input.cards[0].blockedBy);Object.freeze(input.cards[0]);Object.freeze(input.cards);Object.freeze(input.tray);Object.freeze(input);
  replay(input,run(input));assert.deepEqual(input,before);
});
test('204 loaded cards complete through local receding routes rather than one enormous proof',()=>{
  let input=state(Array.from({length:204},(_,i)=>card('c'+i,'T'+(i%17))));let picks=0;
  for(let i=0;i<68;i++){const output=run(input);replay(input,output);assert.equal(output.sequence.length,3);picks+=output.sequence.length;input=advanceInput(input,output.sequence);}
  assert.equal(picks,204);assert.equal(run(input).status,'solved');
});
test('candidate scans are resumable on a wide board',()=>{
  let now=0;const planner=createPlanner(()=>{now+=.25;return now;}),input=state(Array.from({length:72},(_,i)=>card('c'+i,'T'+(i%8))),[],{budgetMs:2,maxNodes:4000});
  let output,waiting=0;for(let i=0;i<1000;i++){output=planner(input);if(output.status!=='searching')break;waiting++;assert.deepEqual(output.sequence,[]);}
  assert.equal(output.status,'move');assert.ok(waiting>1);replay(input,output);
});
const observed=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v30.json'),'utf8'));
for(const seq of [9,55])test('real blocked 49-card state '+seq+' does not invent a nonmatching overflow',()=>{
  const input=observed.snapshots.find(s=>s.sequence===seq).plannerInput,output=run(input);
  assert.equal(input.cards.length+input.tray.length,49);assert.equal(output.status,'blocked');assert.equal(output.reason,'no_complete_solution');assert.equal(output.stats.completeSearch,true);replay(input,output);
});
test('invalid lock metadata and invalid external keys reject before continuing',()=>{
  assert.equal(run(state([card('a','A',[],{locked:1})])).reason,'invalid_card_lock');
  assert.equal(run(state([card('a','A',[],{selectable:0})])).reason,'invalid_card_lock');
  assert.equal(run(state([card('a','A')],[],{stateKey:1})).reason,'invalid_state_key');
});
for (const [name, mutate, reason] of [
  ['duplicate board IDs', s => s.cards.push(card('1', 'B')), 'duplicate_or_invalid_card_id'],
  ['duplicate tray IDs', s => s.tray.push({id: 'tray0', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['board-tray ID collision', s => s.tray.push({id: '1', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['missing card face', s => delete s.cards[0].type, 'unreadable_card'],
  ['special unknown face', s => s.cards[0].type = 'unknown', 'unreadable_card'],
  ['missing tray face', s => delete s.tray[0].type, 'unreadable_tray'],
  ['absent blocker', s => {s.cards[0].blockedBy = ['absent']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['self blocker', s => {s.cards[0].blockedBy = ['1']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['duplicate blocker', s => {s.cards.push(card('2', 'B')); s.cards[0].blockedBy = ['2', '2']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['cycle', s => {s.cards[0].blockedBy = ['2']; s.cards[0].available = false; s.cards.push(card('2', 'B', ['1']));}, 'cyclic_blockers'],
  ['covered but available', s => {s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['reserve blockers', s => {s.cards[0].zone = 'reserve'; s.cards[0].available = false; s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['unsettled triple in tray', s => {s.tray = ['a', 'b', 'c'].map(id => ({id, type: 'A'}));}, 'unsettled_tray'],
  ['full tray', s => {s.tray = Array.from({length: 7}, (_, i) => ({id: 't' + i, type: 'T' + i}));}, 'invalid_board_size'],
  ['unknown capacity', s => delete s.capacity, 'unsupported_rules'],
  ['pair matching requested', s => s.matchSize = 2, 'unsupported_rules'],
  ['missing availability', s => delete s.cards[0].available, 'unreadable_card']
]) {
  test(`rejects ${name}`, () => {
    const input = state([card('1', 'A')], ['A']); mutate(input);
    const output = run(input); assert.equal(output.status, 'invalid_state'); assert.equal(output.reason, reason); assert.equal(output.cardID, null);
  });
}
test('rejects missing input and excessive board data', () => {
  assert.equal(run(null).reason, 'invalid_input');
  assert.equal(run(state(Array.from({length: 513}, (_, i) => card('c' + i, 'A')))).reason, 'invalid_board_size');
});
test('rejects excessive blocker lists before searching an expensive malformed graph', () => {
  const input = state([card('1', 'A', Array.from({length: 65}, (_, i) => 'c' + i))]);
  assert.equal(run(input).reason, 'excessive_blockers');
});

test('bounded transposition memory never turns an unproved prefix into an action',()=>{
 const input=state([card('a1','A'),card('a2','A'),card('a3','A',[],{available:false}),card('b1','B'),card('b2','B'),card('b3','B',[],{available:false})],[],{maxTranspositions:1});
 const output=run(input);assert.equal(output.reason,'search_limit_reached');assert.equal(output.stats.limit,'memory_budget');assert.ok(output.stats.transpositions<=1);assert.equal(output.stats.completeSearch,false);replay(input,output);
});
test('three-layer 204-card fixture continues legal progress with wide blocker bitsets',()=>{
 let input=state(Array.from({length:204},(_,i)=>card('c'+i,'T'+(i%17),i<153?['c'+(i+51)]:[])));let total=0;
 for(let i=0;i<68;i++){const output=run(input);assert.equal(output.status,'move');replay(input,output);total+=output.sequence.length;input=advanceInput(input,output.sequence);}
 assert.equal(total,204);assert.equal(run(input).status,'solved');
});

// V3.19.8: mission hints change priority, never the proved action contract.
function mission(type,current=0,total=9){return {type,current,total};}
test('mission trio outranks completing an unrelated existing pair',()=>{
 const input=state([card('a','A'),card('m1','M'),card('m2','M'),card('m3','M')],['A','A'],{mission:mission('M')}),out=run(input);
 assert.equal(out.matchedType,'M');assert.equal(out.stats.missionStatus,'priority');assert.equal(out.sequence.length,3);replay(input,out);
 assert.equal(run({...input,mission:null}).cardID,'a');
});
for(const cooperative of [false,true])test('mission search explores unrelated blockers even when a normal direct trio exists '+cooperative,()=>{
 const input=state([card('b','X'),card('m1','M',['b']),card('m2','M'),card('m3','M'),card('a1','A'),card('a2','A'),card('a3','A')],[],{mission:mission('M'),cooperative}),out=run(input);
 assert.equal(out.matchedType,'M');assert.equal(out.stats.missionStatus,'priority');assert.ok(out.sequence.includes('b'));replay(input,out);
});
test('two layers of mission blockers are replayed without inventing a click through the mask',()=>{
 const input=state([card('b1','X'),card('b2','Y',['b1']),card('m1','M',['b1','b2']),card('m2','M'),card('m3','M'),...['a1','a2','a3'].map(id=>card(id,'A'))],[],{mission:mission('M')}),out=run(input);
 assert.equal(out.matchedType,'M');assert.ok(out.sequence.indexOf('b1')<out.sequence.indexOf('b2'));assert.ok(out.sequence.indexOf('b2')<out.sequence.indexOf('m1'));replay(input,out);
});
for(const reason of ['absent','scarce','locked','full_headroom'])test('normal exact fallback with '+reason+' mission route',()=>{
 let cards=[card('a','A'),card('m1','M'),card('m2','M'),card('m3','M')],tray=['A','A'];
 if(reason==='absent')cards=cards.filter(c=>c.type!=='M');
 if(reason==='scarce')cards=cards.filter(c=>c.id!=='m3');
 if(reason==='locked')cards[1].locked=true;
 if(reason==='full_headroom')tray=['A','A','B','B','C','C'];
 const input=state(cards,tray),normal=run(input),out=run({...input,mission:mission('M')});
 assert.equal(out.stats.missionStatus,'fallback');assert.deepEqual(out.sequence,normal.sequence);assert.equal(out.matchedType,'A');replay(input,out);
});
test('a completed mission no longer overrides normal strategy',()=>{
 const input=state([card('a','A'),card('m1','M'),card('m2','M'),card('m3','M')],['A','A'],{mission:mission('M',9,9)}),out=run(input);
 assert.equal(out.stats.missionStatus,'complete');assert.equal(out.cardID,'a');replay(input,out);
});
for(const bad of [null,{},mission('M',-1),mission('M',1.5),mission('M',10,9),mission('M',0,0),mission('M',true),mission('unknown'),mission('M',0,1000001)])test('invalid optional mission falls back without invalidating board '+JSON.stringify(bad),()=>{
 const input=state([card('a','A'),card('m1','M'),card('m2','M'),card('m3','M')],['A','A']);
 const out=run({...input,mission:bad});assert.deepEqual(out.sequence,run(input).sequence);assert.equal(out.stats.missionStatus,'unavailable');replay(input,out);
});
test('mission identity/progress is part of resumable search fingerprint',()=>{
 const plan=createPlanner(),input=state([card('a','A'),card('m1','M'),card('m2','M'),card('m3','M')],['A','A'],{mission:mission('M'),maxNodes:1});
 assert.equal(plan(input).status,'searching');const changed={...input,mission:mission('A',3,6),maxNodes:600};
 const out=plan(changed);assert.equal(out.stats.slices,1);assert.equal(out.cardID,'a');assert.equal(out.stats.missionStatus,'priority');replay(changed,out);
});
test('bounded pursuit waits rather than prematurely publishing a normal direct fallback',()=>{
 const input=state([card('a','A'),card('b','X'),card('m1','M',['b']),card('m2','M'),card('m3','M')],['A','A'],{mission:mission('M'),maxNodes:1});
 const plan=createPlanner();let out;const slices=[];for(let i=0;i<30;i++){out=plan(input);slices.push(out);if(out.status!=='searching')break;}
 assert.ok(slices.some(r=>r.status==='searching'&&r.stats.candidates>0),'normal proof remains provisional while target is pursued');
 assert.equal(out.status,'move');assert.ok(out.stats.slices<=9);replay(input,out);
});
test('search budget returns the original proved normal route, not an unproved target single',()=>{
 const input=state([card('a','A'),card('b','X'),card('m1','M',['b']),card('m2','M'),card('m3','M')],['A','A'],{mission:mission('M'),maxNodes:1,maxTotalNodes:4});
 const out=run(input);assert.equal(out.stats.missionStatus,'fallback');assert.equal(out.stats.missionReason,'search_limit');assert.equal(out.cardID,'a');replay(input,out);
});
test('mission can resume on the next trio after normal play clears a crowded tray',()=>{
 let input=state([card('a','A'),card('m1','M'),card('m2','M'),card('m3','M')],['A','A','B','B','C','C'],{mission:mission('M')});
 const first=run(input);assert.equal(first.matchedType,'A');input=advanceInput(input,first.sequence);
 const second=run(input);assert.equal(second.matchedType,'M');assert.equal(second.stats.missionStatus,'priority');replay(input,second);
});

test('failed mission pursuit without a normal direct proof still runs the original normal unlock search',()=>{
 const input=state([card('top','X'),card('a1','A',['top']),card('a2','A'),card('a3','A'),card('m1','M',[],{locked:true}),card('m2','M'),card('m3','M')],[],{mission:mission('M'),maxNodes:1});
 const out=run(input);assert.equal(out.status,'move');assert.equal(out.matchedType,'A');assert.equal(out.stats.missionStatus,'fallback');assert.ok(out.stats.missionNodes>0);replay(input,out);
});

test('independent exhaustive oracle: 120 small DAG boards always prefer an available target trio or prove normal fallback',()=>{
 let seed=0x3198;const rand=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;};
 function reachable(input,target){
  const initial=input.tray.map(c=>c.type),memo=new Set();
  function visit(removed,bar){
   const key=removed+'|'+bar.slice().sort().join(',');if(memo.has(key))return false;memo.add(key);
   for(let i=0;i<input.cards.length;i++){
    const c=input.cards[i];if((removed&(1<<i))||c.locked||c.blockedBy.some(id=>!(removed&(1<<Number(id.slice(1))))))continue;
    const count=bar.filter(t=>t===c.type).length;
    if(bar.length+1>input.capacity || (bar.length+1===input.capacity&&count!==2))continue;
    if(count===2){if(!target||c.type===target)return true;continue;}
    if(visit(removed|(1<<i),bar.concat(c.type)))return true;
   }
   return false;
  }
  return visit(0,initial);
 }
 for(let sample=0;sample<120;sample++){
  const cards=Array.from({length:9},(_,i)=>{const blockedBy=[];for(let j=0;j<i;j++)if(rand(9)===0)blockedBy.push('c'+j);return card('c'+i,['A','B','C'][rand(3)],blockedBy,{locked:rand(20)===0});});
  const counts={A:0,B:0,C:0},tray=[];for(let i=0,n=rand(5);i<n;i++){const t=['A','B','C'][rand(3)];if(counts[t]<2){counts[t]++;tray.push(t);}}
  const input=state(cards,tray,{mission:mission('B')}),hasTarget=reachable(input,'B'),hasNormal=reachable(input),out=run(input);
  assert.equal(out.status==='move',hasNormal,'sample '+sample);if(hasTarget)assert.equal(out.matchedType,'B','sample '+sample);replay(input,out);
 }
});

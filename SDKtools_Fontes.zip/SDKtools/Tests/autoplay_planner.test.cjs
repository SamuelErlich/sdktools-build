const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/autoplay_planner.js'), 'utf8');
function card(id, type, blockedBy = [], extra = {}) {
  return {id, type, zone:'board', blockedBy, available:!blockedBy.length, ...extra};
}
function state(cards, types = [], extra = {}) {
  return {cards, tray:types.map((type,i)=>({id:'tray'+i,type})), capacity:7, matchSize:3, budgetMs:8, ...extra};
}
function createPlanner(clock = ()=>0) {
  const context = vm.createContext({Date:{now:clock}}), before=Object.keys(context);
  const planner = vm.runInContext(source,context,{timeout:1000});
  return input => { const result=JSON.parse(JSON.stringify(planner(input))); assert.deepEqual(Object.keys(context),before,'no global search state'); return result; };
}
function run(input) { const planner=createPlanner();let result;for(let i=0;i<2000;i++){result=planner(input);if(result.status!=='searching')return result;}throw Error('search did not terminate within bounded calls'); }
function simulate(input, actions) {
  const remaining = new Map(input.cards.map(c=>[c.id,c]));let tray=input.tray.map(c=>({...c}));
  let triples=0,peak=tray.length,firstIDs=null,firstType=null,lastTriple=false;
  for(const id of actions){
    const c=remaining.get(id);assert.ok(c,'every selected identity exists exactly once');
    assert.notEqual(c.locked,true);assert.notEqual(c.selectable,false);
    assert.ok(c.available||c.blockedBy.length,'disabled uncovered card is not silently activated');
    assert.ok(c.blockedBy.every(b=>!remaining.has(b)),'covered card waits for every blocker');
    remaining.delete(id);tray.push({id:c.id,type:c.type});peak=Math.max(peak,tray.length);assert.ok(peak<=input.capacity);
    const group=tray.filter(t=>t.type===c.type);lastTriple=group.length===3;
    if(lastTriple){triples++;if(!firstIDs){firstIDs=group.map(t=>t.id);firstType=c.type;}tray=tray.filter(t=>t.type!==c.type);}
    assert.ok(tray.length<input.capacity,'a non-triple must not fill the last slot');
  }
  return {remaining,tray,triples,peak,firstIDs,firstType,lastTriple};
}
function replay(input, output) {
  assert.deepEqual(output.actions,output.sequence);
  if(output.status!=='move'){assert.equal(output.cardID,null);assert.deepEqual(output.sequence,[]);assert.equal(output.stats.completePlan,false);return;}
  const r=simulate(input,output.sequence);assert.equal(output.cardID,output.sequence[0]);assert.equal(output.stats.completePlan,true);
  assert.equal(r.lastTriple,true,'no picks after the last useful triple');assert.equal(output.peakTrayCount,r.peak);
  assert.equal(output.matchedType,r.firstType);assert.deepEqual(output.tripleCardIDs,r.firstIDs);
  const initialTotals=new Map();for(const c of [...input.cards,...input.tray])initialTotals.set(c.type,(initialTotals.get(c.type)||0)+1);
  const target=[...initialTotals.values()].reduce((sum,n)=>sum+Math.floor(n/3),0);assert.equal(r.triples,target,'plan reaches the mathematical global upper bound');
  const residual=new Map();for(const c of [...r.remaining.values(),...r.tray])residual.set(c.type,(residual.get(c.type)||0)+1);
  assert.ok([...residual.values()].every(n=>n<3));
  if(output.proofKind==='complete_board'){assert.equal(r.remaining.size,0);assert.equal(r.tray.length,0);assert.equal(output.stats.completeSolution,true);}
  else{assert.equal(output.proofKind,'all_observed_triples');assert.equal(output.stats.completeSolution,false);}
  return r;
}
function advanceInput(input, actions) {
  const result=simulate(input,actions), remaining=new Set(result.remaining.keys());
  return {...input,cards:[...result.remaining.values()].map(c=>({...c,blockedBy:c.blockedBy.filter(b=>remaining.has(b)),
    available:c.available||(c.blockedBy.length>0&&c.blockedBy.every(b=>!remaining.has(b)))})),tray:result.tray};
}

test('proves two complete triples, not just the first tempting trio',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t))),output=run(input);
  assert.equal(output.sequence.length,6);assert.equal(output.stats.targetTriples,2);replay(input,output);
});
test('existing pair is completed and the rest of the board is also solved',()=>{
  const input=state([card('b1','B'),card('b2','B'),card('b3','B'),card('match','A')],['A','A']),output=run(input);
  assert.equal(output.cardID,'match');assert.deepEqual(output.tripleCardIDs,['tray0','tray1','match']);replay(input,output);
});
test('seven-slot completion is legal but an unrelated seventh single is not',()=>{
  const input=state([card('c','C'),card('a','A'),card('b','B')],['A','A','B','B','C','C']),output=run(input);
  assert.equal(output.peakTrayCount,7);replay(input,output);
  const blocked=state([card('g1','G'),card('g2','G'),card('g3','G')],['A','B','C','D','E','F']);
  assert.equal(run(blocked).reason,'no_complete_solution');
});
test('unbalanced snapshot requires every possible trio and does not collect gratuitous residue',()=>{
  const input=state([card('noise','N'),...['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t))]),output=run(input);
  assert.equal(output.proofKind,'all_observed_triples');assert.equal(output.sequence.includes('noise'),false);assert.equal(output.sequence.length,6);replay(input,output);
});
test('a necessary unmatched blocker is included only as part of a globally maximal plan',()=>{
  const input=state([card('block','X'),card('a1','A',['block']),card('a2','A'),card('a3','A'),card('b1','B'),card('b2','B'),card('b3','B')]),output=run(input);
  assert.ok(output.sequence.includes('block'));assert.equal(output.sequence.length,7);replay(input,output);
});
test('remaining singles and pairs produce an explicit external-change wait',()=>{
  const input=state([card('a','A'),card('b','B')],['B']),output=run(input);
  assert.equal(output.status,'blocked');assert.equal(output.reason,'no_remaining_triples');replay(input,output);
});
test('all-observed-triples does not hide an unresolved group behind an easy trio',()=>{
  const input=state([card('a1','A'),card('a2','A'),card('a3','A'),card('b1','B',[],{available:false}),card('b2','B'),card('b3','B'),card('noise','N')]);
  const output=run(input);assert.equal(output.status,'blocked');assert.equal(output.reason,'no_complete_solution');assert.equal(output.stats.completeSearch,true);replay(input,output);
});
test('special locked card is not inferred to unlock after its cover is removed',()=>{
  const input=state([card('a1','A',['b'],{locked:true}),card('a2','A'),card('a3','A'),card('b','B')]),output=run(input);
  assert.equal(output.reason,'observed_state_locked');replay(input,output);
});
test('a locked residual card can remain if all mathematical triples are still achievable',()=>{
  const input=state([card('a1','A'),card('a2','A'),card('a3','A'),card('locked','A',[],{selectable:false})]),output=run(input);
  assert.equal(output.sequence.includes('locked'),false);assert.equal(output.proofKind,'all_observed_triples');replay(input,output);
});
test('shared blockers and matching stacked cards are replayed in legal order',()=>{
  const input=state([card('b1','B'),card('b2','B'),card('b3','B'),card('bottom','A',['middle','top','b1','b2']),card('middle','A',['top']),card('top','A')]),output=run(input);
  assert.ok(output.sequence.indexOf('bottom')>output.sequence.indexOf('b1'));assert.ok(output.sequence.indexOf('bottom')>output.sequence.indexOf('b2'));replay(input,output);
});
test('reserve cards obey the same exact triple rules',()=>{
  const input=state([card('r','A',[],{zone:'reserve'})],['A','A']);replay(input,run(input));
});
test('board clear is distinct from a nonempty unmatched tray',()=>{
  const solved=run(state([]));assert.equal(solved.status,'solved');assert.equal(solved.stats.completeSolution,true);
  assert.equal(run(state([],['A'])).reason,'no_remaining_triples');
});
test('search state resumes across node-limited slices without publishing partial actions',()=>{
  const planner=createPlanner(),input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1});
  let last=0,output;for(let i=0;i<6;i++){output=planner(input);assert.equal(output.stats.generated,last+1);last=output.stats.generated;if(i<5){assert.equal(output.status,'searching');assert.equal(output.stats.completePlan,false);assert.deepEqual(output.sequence,[]);}}
  assert.equal(output.status,'move');assert.equal(output.stats.slices,6);replay(input,output);
});
test('changed board invalidates an unfinished search even with a reused external key',()=>{
  const planner=createPlanner(),input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1,stateKey:'same'});
  planner(input);planner(input);const changed=structuredClone(input);changed.cards[0].id='replacement';
  const next=planner(changed);assert.equal(next.stats.slices,1);assert.equal(next.stats.generated,1);assert.equal(next.status,'searching');
});
test('external context key invalidates a structurally identical search',()=>{
  const planner=createPlanner(),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1,stateKey:'generation1'});
  planner(input);const next=planner({...input,stateKey:'generation2'});assert.equal(next.stats.slices,1);assert.equal(next.stats.generated,1);
});
test('invalid observation discards the prior continuation',()=>{
  const planner=createPlanner(),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1});
  planner(input);assert.equal(planner(null).status,'invalid_state');assert.equal(planner(input).stats.slices,1);
});
test('expired time slice returns searching without a partial executable route',()=>{
  let now=0;const planner=createPlanner(()=>now++),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{budgetMs:1});
  const result=planner(input);assert.equal(result.status,'searching');assert.equal(result.stats.limit,'time_slice');assert.deepEqual(result.sequence,[]);
});
test('total node budget is terminal, bounded, and never mislabeled unsolvable',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxTotalNodes:2,maxNodes:1}),output=run(input);
  assert.equal(output.reason,'search_limit_reached');assert.equal(output.stats.limit,'total_node_budget');assert.equal(output.stats.generated,2);assert.equal(output.stats.completeSearch,false);replay(input,output);
});
test('finite depth limit never emits a locally promising trio',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxDepth:3}),output=run(input);
  assert.equal(output.reason,'search_limit_reached');assert.equal(output.stats.limit,'depth_limit');replay(input,output);
});
test('input remains unchanged and inherited-property identifiers do not collide',()=>{
  const input=state([card('__proto__','constructor'),card('toString','constructor'),card('hasOwnProperty','constructor')]);const before=structuredClone(input);
  Object.freeze(input.cards[0].blockedBy);Object.freeze(input.cards[0]);Object.freeze(input.cards);Object.freeze(input.tray);Object.freeze(input);
  replay(input,run(input));assert.deepEqual(input,before);
});
for (const [name, mutate, reason] of [
  ['duplicate board IDs', s => s.cards.push(card('1', 'B')), 'duplicate_or_invalid_card_id'],
  ['duplicate tray IDs', s => s.tray.push({id: 'tray0', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['board-tray ID collision', s => s.tray.push({id: '1', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['missing card face', s => delete s.cards[0].type, 'unreadable_card'],
  ['special unknown face', s => s.cards[0].type = 'unknown', 'unreadable_card'],
  ['missing tray face', s => delete s.tray[0].type, 'unreadable_tray'],
  ['absent blocker', s => {s.cards[0].blockedBy = ['absent']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['self blocker', s => {s.cards[0].blockedBy = ['1']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['duplicate blocker', s => {s.cards.push(card('2', 'B')); s.cards[0].blockedBy = ['2', '2']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['cycle', s => {s.cards[0].blockedBy = ['2']; s.cards[0].available = false; s.cards.push(card('2', 'B', ['1']));}, 'cyclic_blockers'],
  ['covered but available', s => {s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['reserve blockers', s => {s.cards[0].zone = 'reserve'; s.cards[0].available = false; s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['unsettled triple in tray', s => {s.tray = ['a', 'b', 'c'].map(id => ({id, type: 'A'}));}, 'unsettled_tray'],
  ['full tray', s => {s.tray = Array.from({length: 7}, (_, i) => ({id: 't' + i, type: 'T' + i}));}, 'invalid_board_size'],
  ['unknown capacity', s => delete s.capacity, 'unsupported_rules'],
  ['pair matching requested', s => s.matchSize = 2, 'unsupported_rules'],
  ['missing availability', s => delete s.cards[0].available, 'unreadable_card']
]) {
  test(`rejects ${name}`, () => {
    const input = state([card('1', 'A')], ['A']); mutate(input);
    const output = run(input); assert.equal(output.status, 'invalid_state'); assert.equal(output.reason, reason); assert.equal(output.cardID, null);
  });
}
test('rejects missing input and excessive board data', () => {
  assert.equal(run(null).reason, 'invalid_input');
  assert.equal(run(state(Array.from({length: 513}, (_, i) => card('c' + i, 'A')))).reason, 'invalid_board_size');
});
test('rejects excessive blocker lists before searching an expensive malformed graph', () => {
  const input = state([card('1', 'A', Array.from({length: 65}, (_, i) => 'c' + i))]);
  assert.equal(run(input).reason, 'excessive_blockers');
});
const counterexample=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-global-counterexample-v31.json'),'utf8'));
test('backtracks out of a locally valid trio that makes the 24-card puzzle unsolvable',()=>{
  const input=counterexample.input, trapped=advanceInput(input,counterexample.oldLocalRoute), failed=run(trapped);
  assert.equal(failed.reason,'no_complete_solution');assert.equal(failed.stats.completeSearch,true);
  const output=run(input);assert.equal(output.sequence.length,24);assert.ok(output.stats.backtracks>0);assert.ok(output.stats.pruned>0);replay(input,output);
});
test('transposition storage has a finite enforced ceiling',()=>{
  const input={...counterexample.input,maxTranspositions:1},output=run(input);
  assert.equal(output.reason,'search_limit_reached');assert.equal(output.stats.limit,'memory_budget');assert.ok(output.stats.transpositions<=1);assert.equal(output.stats.completeSearch,false);replay(input,output);
});
test('deterministic search resumes to the same full solution with different slice node budgets',()=>{
  const a=run({...counterexample.input,maxNodes:7}),b=run({...counterexample.input,maxNodes:4000});
  assert.deepEqual(a.sequence,b.sequence);assert.equal(a.stats.generated,b.stats.generated);replay(counterexample.input,a);
});
test('204 loaded cards are solved across slices and wide bitsets without a 24-card horizon',()=>{
  const input=state(Array.from({length:204},(_,i)=>card('c'+i,'T'+(i%17))),[],{maxNodes:40});
  const output=run(input);assert.equal(output.sequence.length,204);assert.equal(output.stats.generated,204);assert.ok(output.stats.slices>=6);replay(input,output);
});
test('204 layered cards use future releases and verify every dependency',()=>{
  const input=state(Array.from({length:204},(_,i)=>card('c'+i,'T'+(i%17),i<153?['c'+(i+51)]:[])),[],{maxNodes:40});
  const output=run(input);assert.equal(output.sequence.length,204);assert.equal(output.stats.completeSolution,true);replay(input,output);
});
test('49 loaded cards can reach all sixteen triples without pretending the last card wins a match',()=>{
  const input=state(Array.from({length:49},(_,i)=>card('c'+i,i===48?'residue':'T'+Math.floor(i/3))),[],{maxNodes:10});
  const output=run(input);assert.equal(output.sequence.length,48);assert.equal(output.stats.targetTriples,16);assert.equal(output.proofKind,'all_observed_triples');replay(input,output);
});
const observed=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v30.json'),'utf8'));
for(const seq of [9,55])test('real captured 49-card state '+seq+' is not advertised as globally solvable after the tray became blocked',()=>{
  const input=observed.snapshots.find(s=>s.sequence===seq).plannerInput,output=run(input);
  assert.equal(input.cards.length+input.tray.length,49);assert.equal(output.status,'blocked');assert.equal(output.reason,'no_complete_solution');assert.equal(output.stats.completeSearch,true);replay(input,output);
});
test('invalid lock metadata and invalid external keys reject before continuing',()=>{
  assert.equal(run(state([card('a','A',[],{locked:1})])).reason,'invalid_card_lock');
  assert.equal(run(state([card('a','A',[],{selectable:0})])).reason,'invalid_card_lock');
  assert.equal(run(state([card('a','A')],[],{stateKey:1})).reason,'invalid_state_key');
});
test('final proof removes a residual blocker that was explored but was not needed by the successful route',()=>{
  const input=state([card('a1','A'),card('a2','A'),card('a3','A'),card('block','N'),card('unusedA','A',['block'])]);
  const output=run(input);assert.ok(output.stats.generated>output.sequence.length);assert.deepEqual(output.sequence,['a1','a2','a3']);replay(input,output);
});
test('candidate scanning resumes after a time-slice interruption on a wide board',()=>{
  let now=0;const planner=createPlanner(()=>{now+=0.25;return now;}),input=state(Array.from({length:72},(_,i)=>card('c'+i,'T'+(i%8))),[],{budgetMs:2,maxNodes:4000});
  let output,waiting=0;for(let i=0;i<2000;i++){output=planner(input);if(output.status!=='searching')break;waiting++;assert.deepEqual(output.sequence,[]);assert.equal(output.stats.limit,'time_slice');}
  assert.equal(output.status,'move');assert.ok(waiting>5);assert.equal(output.sequence.length,72);replay(input,output);
});

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/autoplay_planner.js'), 'utf8');
function card(id, type, blockedBy = [], extra = {}) {
  return {id, type, zone: 'board', blockedBy, available: !blockedBy.length, ...extra};
}
function state(cards, types = [], extra = {}) {
  return {cards, tray: types.map((type, i) => ({id: `tray${i}`, type})), capacity: 7, matchSize: 3, budgetMs: 40, ...extra};
}
function run(input, clock = () => 0) {
  const context = vm.createContext({Date: {now: clock}});
  const before = Object.keys(context);
  const planner = vm.runInContext(source, context, {timeout: 1000});
  const result = JSON.parse(JSON.stringify(planner(input)));
  assert.deepEqual(Object.keys(context), before, 'planner must not install globals');
  return result;
}
function replay(input, result) {
  const remaining = new Map(input.cards.map(x => [x.id, x]));
  const tray = input.tray.map(x => x.type);
  for (const id of result.actions) {
    const card = remaining.get(id);
    assert.ok(card, 'planned card must still exist');
    assert.ok(card.available || card.blockedBy.length, 'disabled uncovered card cannot be selected');
    assert.ok(card.blockedBy.every(id => !remaining.has(id)), 'every blocker must already have left');
    remaining.delete(id); tray.push(card.type);
    if (tray.filter(type => type === card.type).length === 3) {
      for (let i = tray.length - 1; i >= 0; i--) if (tray[i] === card.type) tray.splice(i, 1);
    }
    assert.ok(tray.length < input.capacity, 'no intermediate step may fill the final slot');
  }
  return {remaining, tray};
}

test('completes an existing pair with the exact matching third card', () => {
  const input = state([card('noise', 'B'), card('match', 'A')], ['A', 'A']);
  const output = run(input);
  assert.equal(output.status, 'move'); assert.equal(output.cardID, 'match');
  replay(input, output);
});
test('finds and replays a complete three-card solution rather than matching pairs', () => {
  const input = state([card('1', 'A'), card('2', 'A'), card('3', 'A')]);
  const output = run(input), replayed = replay(input, output);
  assert.equal(output.reason, 'solution_found'); assert.equal(output.stats.completeSolution, true);
  assert.equal(output.actions.length, 3); assert.equal(replayed.remaining.size, 0); assert.equal(replayed.tray.length, 0);
});
test('removes the blocker before selecting the cards it reveals', () => {
  const input = state([card('cover', 'B'), card('a1', 'A', ['cover']), card('a2', 'A'), card('a3', 'A')], ['B', 'B']);
  const output = run(input); assert.equal(output.cardID, 'cover');
  assert.equal(output.stats.completeSolution, true); replay(input, output);
});
test('waits for both shared blockers and does not mistake one removal for exposure', () => {
  const input = state([card('b1', 'B'), card('b2', 'B'), card('a1', 'A', ['b1', 'b2']), card('a2', 'A'), card('a3', 'A')], ['B']);
  const output = run(input); replay(input, output);
  assert.equal(output.stats.completeSolution, true);
  assert.ok(output.actions.indexOf('a1') > output.actions.indexOf('b1'));
  assert.ok(output.actions.indexOf('a1') > output.actions.indexOf('b2'));
});
test('rejects a pick that fills the final slot without immediately forming a triple', () => {
  const input = state([card('1', 'G')], ['A', 'B', 'C', 'D', 'E', 'F']);
  const output = run(input); assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'tray_capacity');
});
test('a seventh-slot pick is allowed only when the same pick clears its triple', () => {
  const input = state([card('third', 'A'), card('bad', 'D')], ['A', 'A', 'B', 'B', 'C', 'C']);
  const output = run(input); assert.equal(output.cardID, 'third'); replay(input, output);
});
test('avoids an immediate tray dead end even when that pick exposes several cards', () => {
  const input = state([card('trap', 'G'), card('right', 'A'), card('b1', 'B', ['trap']), card('b2', 'B', ['trap']), card('b3', 'B', ['trap'])], ['A', 'A', 'C', 'D', 'E']);
  const output = run(input); assert.equal(output.cardID, 'right'); replay(input, output);
});
test('does not select an uncovered disabled card', () => {
  const output = run(state([card('1', 'A', [], {available: false})], ['A', 'A']));
  assert.equal(output.status, 'blocked'); assert.equal(output.cardID, null);
});
test('reserve cards participate in the same triple rules', () => {
  const input = state([card('reserve', 'A', [], {zone: 'reserve'})], ['A', 'A']);
  const output = run(input); assert.equal(output.cardID, 'reserve'); assert.equal(output.stats.completeSolution, true);
});
test('returns solved only when board and tray are both clear', () => {
  assert.equal(run(state([])).status, 'solved');
  assert.equal(run(state([], ['A'])).reason, 'unmatched_tray');
});
test('a single unmatched terminal card is not advertised as a solution', () => {
  const output = run(state([card('1', 'A')]));
  assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'no_safe_continuation'); assert.equal(output.stats.completeSolution, false);
});
test('finite node budget is obeyed and any emitted route remains legal', () => {
  const input = state(Array.from({length: 24}, (_, i) => card('c' + i, 'T' + Math.floor(i / 3))), [], {maxNodes: 3});
  const output = run(input); assert.ok(output.stats.generated <= 3); assert.equal(output.stats.limit, 'node_budget'); replay(input, output);
});
test('finite search depth is obeyed', () => {
  const input = state([card('1', 'A'), card('2', 'A'), card('3', 'A')], [], {maxDepth: 1});
  const output = run(input); assert.equal(output.stats.depth, 1); assert.equal(output.stats.limit, 'depth_limit'); assert.equal(output.stats.completeSolution, false);
});
test('expired time budget produces no speculative action', () => {
  let now = 0;
  const output = run(state([card('1', 'A'), card('2', 'A'), card('3', 'A')], [], {budgetMs: 1}), () => now++);
  assert.equal(output.status, 'blocked'); assert.equal(output.reason, 'search_budget_exhausted'); assert.equal(output.cardID, null);
});
test('beam pruning stays bounded without promising a complete search', () => {
  const input = state(Array.from({length: 30}, (_, i) => card('c' + i, 'T' + Math.floor(i / 3))), [], {beamWidth: 1, maxNodes: 100, maxDepth: 4});
  const output = run(input); assert.ok(output.stats.pruned > 0); assert.ok(output.stats.generated <= 100); replay(input, output);
});
test('input and its nested arrays are unchanged', () => {
  const input = state([card('1', 'A'), card('2', 'A'), card('3', 'A')]);
  const original = structuredClone(input);
  Object.freeze(input.cards[0].blockedBy); Object.freeze(input.cards[0]); Object.freeze(input.cards); Object.freeze(input.tray); Object.freeze(input);
  run(input); assert.deepEqual(input, original);
});
test('type and id strings cannot collide with inherited object properties', () => {
  const input = state([card('__proto__', 'constructor'), card('toString', 'constructor'), card('hasOwnProperty', 'constructor')]);
  const output = run(input); assert.equal(output.stats.completeSolution, true); replay(input, output);
});
test('wide bitsets correctly handle card indices above 31 and 63', () => {
  const input = state(Array.from({length: 66}, (_, i) => card('c' + i, i >= 63 ? 'match' : 'T' + i, [], {available: i >= 63})), [], {maxDepth: 3});
  const output = run(input); assert.equal(output.status, 'move');
  assert.ok(output.actions.every(id => Number(id.slice(1)) >= 63)); replay(input, output);
});
for (const [name, mutate, reason] of [
  ['duplicate board IDs', s => s.cards.push(card('1', 'B')), 'duplicate_or_invalid_card_id'],
  ['duplicate tray IDs', s => s.tray.push({id: 'tray0', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['board-tray ID collision', s => s.tray.push({id: '1', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['missing card face', s => delete s.cards[0].type, 'unreadable_card'],
  ['special unknown face', s => s.cards[0].type = 'unknown', 'unreadable_card'],
  ['missing tray face', s => delete s.tray[0].type, 'unreadable_tray'],
  ['absent blocker', s => {s.cards[0].blockedBy = ['absent']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['self blocker', s => {s.cards[0].blockedBy = ['1']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['duplicate blocker', s => {s.cards.push(card('2', 'B')); s.cards[0].blockedBy = ['2', '2']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['cycle', s => {s.cards[0].blockedBy = ['2']; s.cards[0].available = false; s.cards.push(card('2', 'B', ['1']));}, 'cyclic_blockers'],
  ['covered but available', s => {s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['reserve blockers', s => {s.cards[0].zone = 'reserve'; s.cards[0].available = false; s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['unsettled triple in tray', s => {s.tray = ['a', 'b', 'c'].map(id => ({id, type: 'A'}));}, 'unsettled_tray'],
  ['full tray', s => {s.tray = Array.from({length: 7}, (_, i) => ({id: 't' + i, type: 'T' + i}));}, 'invalid_board_size'],
  ['unknown capacity', s => delete s.capacity, 'unsupported_rules'],
  ['pair matching requested', s => s.matchSize = 2, 'unsupported_rules'],
  ['missing availability', s => delete s.cards[0].available, 'unreadable_card']
]) {
  test(`rejects ${name}`, () => {
    const input = state([card('1', 'A')], ['A']); mutate(input);
    const output = run(input); assert.equal(output.status, 'invalid_state'); assert.equal(output.reason, reason); assert.equal(output.cardID, null);
  });
}
test('rejects missing input and excessive board data', () => {
  assert.equal(run(null).reason, 'invalid_input');
  assert.equal(run(state(Array.from({length: 513}, (_, i) => card('c' + i, 'A')))).reason, 'invalid_board_size');
});
test('rejects excessive blocker lists before searching an expensive malformed graph', () => {
  const input = state([card('1', 'A', Array.from({length: 65}, (_, i) => 'c' + i))]);
  assert.equal(run(input).reason, 'excessive_blockers');
});
test('collapses equivalent exposed cards so a broad board still reaches triple routes', () => {
  const input = state(Array.from({length: 90}, (_, i) => card('c' + i, 'T' + (i % 12))), [], {maxDepth: 4, maxNodes: 1800});
  const output = run(input); assert.equal(output.reason, 'triple_route');
  assert.ok(output.stats.depth >= 3); replay(input, output);
});

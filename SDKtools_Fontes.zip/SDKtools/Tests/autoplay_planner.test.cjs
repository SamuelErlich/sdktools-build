const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Resources/autoplay_planner.js'), 'utf8');
function card(id, type, blockedBy = [], extra = {}) {
  return {id, type, zone:'board', blockedBy, available:!blockedBy.length, ...extra};
}
function state(cards, types = [], extra = {}) {
  return {cards, tray:types.map((type,i)=>({id:'tray'+i,type})), capacity:7, matchSize:3, budgetMs:8, ...extra};
}
function createPlanner(clock = ()=>0) {
  const context = vm.createContext({Date:{now:clock}}), before=Object.keys(context);
  const planner = vm.runInContext(source,context,{timeout:1000});
  return input => { const result=JSON.parse(JSON.stringify(planner(input))); assert.deepEqual(Object.keys(context),before,'no global search state'); return result; };
}
function run(input) { const planner=createPlanner();let result;for(let i=0;i<2000;i++){result=planner(input);if(result.status!=='searching')return result;}throw Error('search did not terminate within bounded calls'); }
function simulate(input, actions) {
  const remaining = new Map(input.cards.map(c=>[c.id,c]));let tray=input.tray.map(c=>({...c}));
  let triples=0,peak=tray.length,firstIDs=null,firstType=null,lastTriple=false;
  for(const id of actions){
    const c=remaining.get(id);assert.ok(c,'every selected identity exists exactly once');
    assert.notEqual(c.locked,true);assert.notEqual(c.selectable,false);
    assert.ok(c.available||c.blockedBy.length,'disabled uncovered card is not silently activated');
    assert.ok(c.blockedBy.every(b=>!remaining.has(b)),'covered card waits for every blocker');
    remaining.delete(id);tray.push({id:c.id,type:c.type});peak=Math.max(peak,tray.length);assert.ok(peak<=input.capacity);
    const group=tray.filter(t=>t.type===c.type);lastTriple=group.length===3;
    if(lastTriple){triples++;if(!firstIDs){firstIDs=group.map(t=>t.id);firstType=c.type;}tray=tray.filter(t=>t.type!==c.type);}
    assert.ok(tray.length<input.capacity,'a non-triple must not fill the last slot');
  }
  return {remaining,tray,triples,peak,firstIDs,firstType,lastTriple};
}
function replay(input, output) {
  assert.deepEqual(output.actions,output.sequence);
  if(output.status!=='move'){assert.equal(output.cardID,null);assert.deepEqual(output.sequence,[]);assert.equal(output.stats.completePlan,false);return;}
  const r=simulate(input,output.sequence);assert.equal(output.cardID,output.sequence[0]);assert.equal(output.stats.completePlan,true);
  assert.equal(r.lastTriple,true,'no picks after the last useful triple');assert.equal(output.peakTrayCount,r.peak);
  assert.equal(output.matchedType,r.firstType);assert.deepEqual(output.tripleCardIDs,r.firstIDs);
  assert.equal(output.proofKind,'local_trio');assert.equal(r.triples,1,'exactly one next trio is proved');
  assert.equal(output.stats.completeSolution,r.remaining.size===0&&r.tray.length===0);
  return r;
}
function advanceInput(input, actions) {
  const result=simulate(input,actions), remaining=new Set(result.remaining.keys());
  return {...input,cards:[...result.remaining.values()].map(c=>({...c,blockedBy:c.blockedBy.filter(b=>remaining.has(b)),
    available:c.available||(c.blockedBy.length>0&&c.blockedBy.every(b=>!remaining.has(b)))})),tray:result.tray};
}


test('publishes the next trio without waiting to solve the complete six-card board',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t))),output=run(input);
  assert.equal(output.sequence.length,3);assert.equal(output.stats.goal,'next_trio');assert.equal(output.stats.completeSolution,false);replay(input,output);
});
test('completes an existing pair before a fresh exposed trio to preserve headroom',()=>{
  const input=state([card('b1','B'),card('b2','B'),card('b3','B'),card('match','A')],['A','A']),output=run(input);
  assert.equal(output.cardID,'match');assert.deepEqual(output.tripleCardIDs,['tray0','tray1','match']);assert.equal(output.sequence.length,1);replay(input,output);
});
test('seven-slot completion is legal but an unrelated seventh single is not',()=>{
  const input=state([card('c','C'),card('a','A'),card('b','B')],['A','A','B','B','C','C']),output=run(input);
  assert.equal(output.peakTrayCount,7);replay(input,output);
  const blocked=state([card('g1','G'),card('g2','G'),card('g3','G')],['A','B','C','D','E','F']);
  assert.equal(run(blocked).reason,'no_complete_solution');
});
test('an impossible remote trio no longer prevents a local exposed trio',()=>{
  const input=state([card('a1','A'),card('a2','A'),card('a3','A'),card('b1','B',[],{available:false}),card('b2','B'),card('b3','B'),card('noise','N')]);
  const output=run(input);assert.equal(output.status,'move');assert.deepEqual(output.sequence,['a1','a2','a3']);replay(input,output);
});
test('receding local routes make all available progress then stop without arbitrary singles',()=>{
  let input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)).concat([card('locked','C',[],{locked:true}),card('lockedPeer1','C'),card('lockedPeer2','C'),card('noise','N')]));
  let total=0,trios=0;
  for(let i=0;i<10;i++){const output=run(input);if(output.status!=='move'){assert.equal(output.reason,'no_complete_solution');break;}replay(input,output);total+=output.sequence.length;trios++;input=advanceInput(input,output.sequence);}
  assert.equal(total,6);assert.equal(trios,2);assert.equal(input.cards.length,4);assert.equal(input.tray.length,0);
});
test('unmatched blockers are collected only with a fully replayable route completing a trio',()=>{
  const input=state([card('block','X'),card('a1','A',['block']),card('a2','A'),card('a3','A')]),output=run(input);
  assert.ok(output.sequence.includes('block'));assert.equal(output.sequence.length,4);replay(input,output);
});
test('remaining singles and pairs wait for a real board change without a move',()=>{
  const input=state([card('a','A'),card('b','B')],['B']),output=run(input);
  assert.equal(output.status,'blocked');assert.equal(output.reason,'no_remaining_triples');replay(input,output);
});
test('special locked cards cannot be selected but unrelated accessible trios still work',()=>{
  const input=state([card('a1','A',['b'],{locked:true}),card('a2','A'),card('a3','A'),card('b','B')]);
  assert.equal(run(input).reason,'no_complete_solution');
  const changed={...input,cards:input.cards.concat([card('c1','C'),card('c2','C'),card('c3','C')])};replay(changed,run(changed));
});
test('lookahead prefers an equally short trio that exposes another match',()=>{
  const input=state([card('a1','A'),card('a2','A'),card('a3','A'),card('b1','B'),card('b2','B'),card('b3','B'),card('c1','C',['b1']),card('c2','C',['b2']),card('c3','C',['b3'])]);
  const output=run(input);assert.equal(output.matchedType,'B');assert.ok(output.stats.candidates>=2);replay(input,output);
});
test('same-type stacked cards are resolved in topological order',()=>{
  const input=state([card('bottom','A',['middle','top']),card('middle','A',['top']),card('top','A')]),output=run(input);
  assert.deepEqual(output.sequence,['top','middle','bottom']);replay(input,output);
});
test('reserve cards obey the same exact triple rules',()=>{
  const input=state([card('r','A',[],{zone:'reserve'})],['A','A']);replay(input,run(input));
});
test('board clear is distinct from a nonempty unmatched tray',()=>{
  const solved=run(state([]));assert.equal(solved.status,'solved');assert.equal(solved.stats.completeSolution,true);
  assert.equal(run(state([],['A'])).reason,'no_remaining_triples');
});
test('one-node slices resume a local trio and never publish one or two unproved picks',()=>{
  const planner=createPlanner(),input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1});
  let output;for(let i=0;i<3;i++){output=planner(input);assert.equal(output.stats.generated,i+1);if(i<2){assert.equal(output.status,'searching');assert.equal(output.stats.completePlan,false);assert.deepEqual(output.sequence,[]);}}
  assert.equal(output.status,'move');assert.equal(output.stats.slices,3);replay(input,output);
});
test('changed board invalidates unfinished search even with a reused external key',()=>{
  const planner=createPlanner(),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1,stateKey:'same'});
  planner(input);planner(input);const changed=structuredClone(input);changed.cards[0].id='replacement';
  const next=planner(changed);assert.equal(next.stats.slices,1);assert.equal(next.stats.generated,1);assert.equal(next.status,'searching');
});
test('changed context and invalid observations discard the prior continuation',()=>{
  const planner=createPlanner(),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxNodes:1,stateKey:'one'});
  planner(input);assert.equal(planner({...input,stateKey:'two'}).stats.slices,1);
  assert.equal(planner(null).status,'invalid_state');assert.equal(planner(input).stats.slices,1);
});
test('expired time slice returns searching when there is no proved next trio',()=>{
  let now=0;const planner=createPlanner(()=>now++),input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{budgetMs:1});
  const result=planner(input);assert.equal(result.status,'searching');assert.equal(result.stats.limit,'time_slice');assert.deepEqual(result.sequence,[]);
});
test('a proved prefix remains executable when the remaining comparison reaches its budget',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxTotalNodes:3});const output=run(input);
  assert.equal(output.status,'move');assert.equal(output.sequence.length,3);assert.equal(output.stats.limit,'total_node_budget');replay(input,output);
});
test('total node budget without a completed trio is never mislabeled impossible',()=>{
  const input=state(['A','A','A'].map((t,i)=>card('c'+i,t)),[],{maxTotalNodes:2,maxNodes:1}),output=run(input);
  assert.equal(output.reason,'search_limit_reached');assert.equal(output.stats.limit,'total_node_budget');assert.equal(output.stats.generated,2);assert.equal(output.stats.completeSearch,false);replay(input,output);
});
test('depth ceiling applies to the next trio rather than the whole board',()=>{
  const input=state(['A','A','A','B','B','B'].map((t,i)=>card('c'+i,t)),[],{maxDepth:3});replay(input,run(input));
  assert.equal(run({...input,maxDepth:2}).reason,'search_limit_reached');
});
test('input remains unchanged and inherited-property identifiers do not collide',()=>{
  const input=state([card('__proto__','constructor'),card('toString','constructor'),card('hasOwnProperty','constructor')]);const before=structuredClone(input);
  Object.freeze(input.cards[0].blockedBy);Object.freeze(input.cards[0]);Object.freeze(input.cards);Object.freeze(input.tray);Object.freeze(input);
  replay(input,run(input));assert.deepEqual(input,before);
});
test('204 loaded cards complete through local receding routes rather than one enormous proof',()=>{
  let input=state(Array.from({length:204},(_,i)=>card('c'+i,'T'+(i%17))));let picks=0;
  for(let i=0;i<68;i++){const output=run(input);replay(input,output);assert.equal(output.sequence.length,3);picks+=output.sequence.length;input=advanceInput(input,output.sequence);}
  assert.equal(picks,204);assert.equal(run(input).status,'solved');
});
test('candidate scans are resumable on a wide board',()=>{
  let now=0;const planner=createPlanner(()=>{now+=.25;return now;}),input=state(Array.from({length:72},(_,i)=>card('c'+i,'T'+(i%8))),[],{budgetMs:2,maxNodes:4000});
  let output,waiting=0;for(let i=0;i<1000;i++){output=planner(input);if(output.status!=='searching')break;waiting++;assert.deepEqual(output.sequence,[]);}
  assert.equal(output.status,'move');assert.ok(waiting>1);replay(input,output);
});
const observed=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v30.json'),'utf8'));
for(const seq of [9,55])test('real blocked 49-card state '+seq+' does not invent a nonmatching overflow',()=>{
  const input=observed.snapshots.find(s=>s.sequence===seq).plannerInput,output=run(input);
  assert.equal(input.cards.length+input.tray.length,49);assert.equal(output.status,'blocked');assert.equal(output.reason,'no_complete_solution');assert.equal(output.stats.completeSearch,true);replay(input,output);
});
test('invalid lock metadata and invalid external keys reject before continuing',()=>{
  assert.equal(run(state([card('a','A',[],{locked:1})])).reason,'invalid_card_lock');
  assert.equal(run(state([card('a','A',[],{selectable:0})])).reason,'invalid_card_lock');
  assert.equal(run(state([card('a','A')],[],{stateKey:1})).reason,'invalid_state_key');
});
for (const [name, mutate, reason] of [
  ['duplicate board IDs', s => s.cards.push(card('1', 'B')), 'duplicate_or_invalid_card_id'],
  ['duplicate tray IDs', s => s.tray.push({id: 'tray0', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['board-tray ID collision', s => s.tray.push({id: '1', type: 'B'}), 'duplicate_or_invalid_tray_id'],
  ['missing card face', s => delete s.cards[0].type, 'unreadable_card'],
  ['special unknown face', s => s.cards[0].type = 'unknown', 'unreadable_card'],
  ['missing tray face', s => delete s.tray[0].type, 'unreadable_tray'],
  ['absent blocker', s => {s.cards[0].blockedBy = ['absent']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['self blocker', s => {s.cards[0].blockedBy = ['1']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['duplicate blocker', s => {s.cards.push(card('2', 'B')); s.cards[0].blockedBy = ['2', '2']; s.cards[0].available = false;}, 'invalid_blocker'],
  ['cycle', s => {s.cards[0].blockedBy = ['2']; s.cards[0].available = false; s.cards.push(card('2', 'B', ['1']));}, 'cyclic_blockers'],
  ['covered but available', s => {s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['reserve blockers', s => {s.cards[0].zone = 'reserve'; s.cards[0].available = false; s.cards[0].blockedBy = ['2']; s.cards.push(card('2', 'B'));}, 'inconsistent_availability'],
  ['unsettled triple in tray', s => {s.tray = ['a', 'b', 'c'].map(id => ({id, type: 'A'}));}, 'unsettled_tray'],
  ['full tray', s => {s.tray = Array.from({length: 7}, (_, i) => ({id: 't' + i, type: 'T' + i}));}, 'invalid_board_size'],
  ['unknown capacity', s => delete s.capacity, 'unsupported_rules'],
  ['pair matching requested', s => s.matchSize = 2, 'unsupported_rules'],
  ['missing availability', s => delete s.cards[0].available, 'unreadable_card']
]) {
  test(`rejects ${name}`, () => {
    const input = state([card('1', 'A')], ['A']); mutate(input);
    const output = run(input); assert.equal(output.status, 'invalid_state'); assert.equal(output.reason, reason); assert.equal(output.cardID, null);
  });
}
test('rejects missing input and excessive board data', () => {
  assert.equal(run(null).reason, 'invalid_input');
  assert.equal(run(state(Array.from({length: 513}, (_, i) => card('c' + i, 'A')))).reason, 'invalid_board_size');
});
test('rejects excessive blocker lists before searching an expensive malformed graph', () => {
  const input = state([card('1', 'A', Array.from({length: 65}, (_, i) => 'c' + i))]);
  assert.equal(run(input).reason, 'excessive_blockers');
});

test('bounded transposition memory never turns an unproved prefix into an action',()=>{
 const input=state([card('a1','A'),card('a2','A'),card('a3','A',[],{available:false}),card('b1','B'),card('b2','B'),card('b3','B',[],{available:false})],[],{maxTranspositions:1});
 const output=run(input);assert.equal(output.reason,'search_limit_reached');assert.equal(output.stats.limit,'memory_budget');assert.ok(output.stats.transpositions<=1);assert.equal(output.stats.completeSearch,false);replay(input,output);
});
test('three-layer 204-card fixture continues legal progress with wide blocker bitsets',()=>{
 let input=state(Array.from({length:204},(_,i)=>card('c'+i,'T'+(i%17),i<153?['c'+(i+51)]:[])));let total=0;
 for(let i=0;i<68;i++){const output=run(input);assert.equal(output.status,'move');replay(input,output);total+=output.sequence.length;input=advanceInput(input,output.sequence);}
 assert.equal(total,204);assert.equal(run(input).status,'solved');
});

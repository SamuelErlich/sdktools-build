"""Evidence boundaries for the V3.12 offline report, with no device dependency."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts/analyze_card_early.py'
spec = importlib.util.spec_from_file_location('analyze_card_early', SCRIPT)
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)


def card(zone='hand', card_id=69, known=False, slot=1, **extra):
    row = {'zone': zone, 'index': 0, 'id': card_id, 'type': 1 if known else 0,
           'color': 1 if known else 0, 'num': 7 if known else 0,
           'objectID': 'ec2' if known else 'ec1'}
    if zone == 'hand':
        row['slot'] = slot
    row.update(extra)
    return row


def event(sequence=1, stage='socket_decoded_response', cards=None, **extra):
    row = {'sequence': sequence, 'stage': stage, 'callID': sequence, 'parentCallID': 0,
           'elapsedMs': sequence * 10, 'connectionGeneration': 1, 'round': 1,
           'truncated': False, 'cards': cards if cards is not None else [card(), card('selected', known=True)]}
    if stage == 'socket_decoded_response':
        row['command'] = 'CMD_SYNC'
    row.update(extra)
    return row


def observation(events=None, **extra):
    events = [event()] if events is None else events
    row = {'version': 1, 'status': 'ready', 'reason': 'observing', 'elapsedMs': 90000,
           'events': events, 'milestones': {key: key != 'lateAttach' for key in analysis.MILESTONES},
           'counters': {'lastSequence': max([e['sequence'] for e in events] + [0]),
                        'decodedResponses': sum(e['stage'] == 'socket_decoded_response' for e in events),
                        'bytesQueued': 0}, 'gaps': [], 'nativeOmittedEvents': 0}
    row.update(extra)
    return row


def capture(events=None, **extra):
    early = {'version': 1, 'gameType': 2007, 'generation': 1, 'documentGeneration': 1,
             'native': {'helloReceived': True, 'scriptInstalled': True, 'finalDrainReceived': True, 'finalDrainConfirmed': True},
             'samples': [{'kind': 'end', 'nativeElapsedMs': 90000, 'observation': observation(events)}]}
    early.update(extra)
    return {'schemaVersion': 3, 'format': 'SDKtools.Capture', 'cardEarly': early}


class CardEarlyAnalysisTests(unittest.TestCase):
    def test_missing_early_block_is_unavailable_not_negative_evidence(self):
        summary = analysis.analyze({'schemaVersion': 3})
        self.assertEqual(summary['status'], 'unavailable')
        self.assertFalse(summary['unknownProvesUniversalAbsence'])

    def test_waiting_empty_capture_is_unavailable(self):
        data = capture([], documentGeneration=0, native={})
        data['cardEarly']['samples'][0]['observation'].update(milestones={}, status='waiting', reason='awaiting_loader')
        result = analysis.analyze(data)
        self.assertEqual(result['status'], 'unavailable')
        self.assertIn('unconfirmed_hasInitialSync', result['coverage']['gaps'])

    def test_observed_early_path_does_not_claim_complete_server_state(self):
        result = analysis.analyze(capture())
        self.assertEqual(result['status'], 'early_path_observed')
        self.assertEqual(result['provenHiddenIdentities'], 0)
        self.assertEqual(result['sideFieldCandidates']['decodedResponseOccurrences'], 1)
        self.assertEqual(result['sideFieldCandidates']['values'][0]['sameObjectReference'], False)
        self.assertFalse(result['unknownProvesUniversalAbsence'])

    def test_late_attach_stays_partial_despite_zero_error_counters(self):
        data = capture()
        obs = data['cardEarly']['samples'][0]['observation']
        obs['milestones'].update(lateAttach=True, beforeScene=False, beforeFirstSync=False, hasInitialSync=False)
        obs['gaps'] = ['late_attach', 'initial_sync_unproven']
        result = analysis.analyze(data)
        self.assertEqual(result['status'], 'partial')
        self.assertIn('late_attach', result['coverage']['gaps'])

    def test_decoded_and_store_repetitions_are_not_three_discoveries(self):
        events = [event(1), event(2, 'store_input'), event(3, 'store_after')]
        result = analysis.analyze(capture(events))
        self.assertEqual(result['observations']['uniqueDecodedResponseEvents'], 1)
        self.assertEqual(result['observations']['hiddenZeroAtDecodedIngressRepeatedObservations'], 1)
        self.assertEqual(result['sideFieldCandidates']['decodedResponseOccurrences'], 1)
        self.assertEqual(result['observations']['stages']['store_input']['cardObservations'], 2)

    def test_duplicate_delivery_is_counted_once(self):
        data = capture()
        data['cardEarly']['samples'].append(deepcopy(data['cardEarly']['samples'][0]))
        result = analysis.analyze(data)
        self.assertEqual(result['coverage']['uniqueEvents'], 1)
        self.assertEqual(result['coverage']['duplicateEventDeliveriesIgnored'], 1)
        self.assertEqual(result['sideFieldCandidates']['decodedResponseOccurrences'], 1)

    def test_conflicting_sequence_is_rejected(self):
        data = capture()
        duplicate = deepcopy(data['cardEarly']['samples'][0])
        duplicate['observation']['events'][0]['cards'][1]['color'] = 2
        data['cardEarly']['samples'].append(duplicate)
        with self.assertRaisesRegex(analysis.CaptureAnalysisError, 'conflicting_event_sequence'):
            analysis.analyze(data)

    def test_unique_ids_are_scoped_to_connection_and_round(self):
        events = [event(1), event(2), event(3, connectionGeneration=2), event(4, round=2)]
        result = analysis.analyze(capture(events))
        self.assertEqual(result['observations']['hiddenZeroAtDecodedIngressRepeatedObservations'], 4)
        self.assertEqual(result['observations']['uniqueHiddenZeroCardIDsScopedByDocumentConnectionRound'], 3)

    def test_missing_scope_is_partial_and_not_merged(self):
        row = event()
        del row['round']
        result = analysis.analyze(capture([row]))
        self.assertEqual(result['observations']['uniqueHandCardIDsScopedByDocumentConnectionRound'], 0)
        self.assertIn('event_scope_unavailable', result['coverage']['gaps'])

    def test_duplicate_hand_id_even_if_other_hand_is_known_blocks_candidate(self):
        row = event(cards=[card(), card(known=True, slot=0), card('selected', known=True)])
        result = analysis.analyze(capture([row]))
        self.assertEqual(result['sideFieldCandidates']['decodedResponseOccurrences'], 0)

    def test_duplicate_selected_id_blocks_candidate(self):
        row = event(cards=[card(), card('selected', known=True), card('selected', known=True, color=2)])
        self.assertEqual(analysis.analyze(capture([row]))['sideFieldCandidates']['decodedResponseOccurrences'], 0)

    def test_truncated_event_is_not_sufficient_for_candidate(self):
        result = analysis.analyze(capture([event(truncated=True)]))
        self.assertEqual(result['sideFieldCandidates']['decodedResponseOccurrences'], 0)
        self.assertEqual(result['status'], 'partial')

    def test_fabricated_candidate_claim_is_ignored(self):
        row = event(cards=[card()], sideChannelCandidates=[{'id': 69, 'color': 1, 'confidence': 'candidate'}])
        result = analysis.analyze(capture([row]))
        self.assertEqual(result['sideFieldCandidates']['decodedResponseOccurrences'], 0)

    def test_no_persistent_id_color_propagation(self):
        result = analysis.analyze(capture([event(1), event(2, cards=[card()])]))
        self.assertEqual(result['sideFieldCandidates']['decodedResponseOccurrences'], 1)
        self.assertEqual(result['observations']['uniqueKnownHandCardIDsScopedByDocumentConnectionRound'], 0)

    def test_native_loss_and_final_drain_are_visible(self):
        data = capture()
        data['cardEarly']['native'].update(finalDrainReceived=False, finalDrainConfirmed=False, nativeOmittedEvents=1)
        result = analysis.analyze(data)
        self.assertIn('final_drain_unconfirmed', result['coverage']['gaps'])
        self.assertIn('native_omitted_events', result['coverage']['gaps'])

    def test_end_receipt_alone_does_not_confirm_final_drain(self):
        data = capture()
        data['cardEarly']['native'].pop('finalDrainConfirmed')
        result = analysis.analyze(data)
        self.assertEqual(result['status'], 'partial')
        self.assertIn('final_drain_unconfirmed', result['coverage']['gaps'])

    def test_cumulative_counters_not_summed_and_queue_uses_last_value(self):
        data = capture()
        second = deepcopy(data['cardEarly']['samples'][0])
        first = data['cardEarly']['samples'][0]['observation']
        first['counters'].update(decodedResponses=1, bytesQueued=2048)
        second['observation']['events'] = []
        second['observation']['counters'].update(decodedResponses=1, bytesQueued=0)
        data['cardEarly']['samples'].append(second)
        result = analysis.analyze(data)
        self.assertEqual(result['coverage']['counterMaxima']['decodedResponses'], 1)
        self.assertEqual(result['coverage']['lastReportedQueueBytes'], 0)

    def test_missing_event_sequences_are_reported(self):
        result = analysis.analyze(capture([event(2)]))
        self.assertEqual(result['coverage']['missingEventSequenceCount'], 1)
        self.assertIn('event_sequence_gap', result['coverage']['gaps'])

    def test_sensitive_unknown_fields_are_never_copied(self):
        data = capture()
        data['userID'] = 'do-not-copy-user'
        data['url'] = 'https://private.example/secret'
        data['cardEarly']['token'] = 'do-not-copy-token'
        data['cardEarly']['samples'][0]['observation']['events'][0]['secret'] = 'do-not-copy-secret'
        before = deepcopy(data)
        text = json.dumps(analysis.analyze(data))
        self.assertNotIn('do-not-copy', text)
        self.assertNotIn('private.example', text)
        self.assertEqual(data, before)

    def test_malformed_schema_types_rejected(self):
        for mutate in [
            lambda d: d.update(schemaVersion=True),
            lambda d: d['cardEarly'].update(version=2),
            lambda d: d['cardEarly'].update(documentGeneration=2),
            lambda d: d['cardEarly'].update(samples={}),
            lambda d: d['cardEarly']['samples'][0]['observation'].update(events=[event(cards=[card(color=True)])]),
            lambda d: d['cardEarly']['samples'][0]['observation'].update(events=[event(stage=[])]),
            lambda d: d['cardEarly']['samples'][0]['observation'].update(events=[event(cards=[card(zone={})])]),
            lambda d: d['cardEarly']['samples'][0]['observation'].update(reason=[]),
            lambda d: d['cardEarly']['samples'][0]['observation'].update(gaps=['https://sensitive']),
        ]:
            with self.subTest(mutate=mutate):
                data = capture()
                mutate(data)
                with self.assertRaises(analysis.CaptureAnalysisError):
                    analysis.analyze(data)

    def test_color_state_claim_must_match_fields(self):
        with self.assertRaisesRegex(analysis.CaptureAnalysisError, 'inconsistent_color_state'):
            analysis.analyze(capture([event(cards=[card(colorState='known')])]))

    def test_input_parser_rejects_nan_duplicate_keys_and_deep_nesting(self):
        invalid = ['{"schemaVersion":3,"x":NaN}', '{"schemaVersion":3,"schemaVersion":3}', '[' * 66 + '0' + ']' * 66]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'capture.json'
            for payload in invalid:
                path.write_text(payload)
                with self.assertRaises(analysis.CaptureAnalysisError):
                    analysis.load_capture(path)

    def test_input_byte_limit(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'capture.json'
            path.write_bytes(b' ' * 65)
            with patch.object(analysis, 'MAX_INPUT_BYTES', 64):
                with self.assertRaisesRegex(analysis.CaptureAnalysisError, 'input_byte_limit'):
                    analysis.load_capture(path)

    def test_cli_atomic_success_and_source_preservation(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / 'capture.json', Path(directory) / 'summary.json'
            source.write_text(json.dumps(capture()))
            before = source.read_bytes()
            result = subprocess.run([sys.executable, str(SCRIPT), '--input', str(source), '--output', str(output)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(source.read_bytes(), before)
            self.assertEqual(json.loads(output.read_text())['sideFieldCandidates']['decodedResponseOccurrences'], 1)
            result = subprocess.run([sys.executable, str(SCRIPT), '--input', str(source), '--output', str(source)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(source.read_bytes(), before)

    def test_cli_invalid_input_does_not_replace_existing_output(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / 'capture.json', Path(directory) / 'summary.json'
            source.write_text('{ broken sensitive input')
            output.write_text('preserve-me')
            result = subprocess.run([sys.executable, str(SCRIPT), '--input', str(source), '--output', str(output)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertNotIn('sensitive', result.stderr)
            self.assertEqual(output.read_text(), 'preserve-me')

    def test_legacy_numeric_native_tail_boolean_is_explicit_compatibility(self):
        for value in [0, 1]:
            data = capture()
            data['cardEarly']['native']['undrainedTailMayBeLost'] = value
            analysis.analyze(data)
        for key, value in [('undrainedTailMayBeLost', 2), ('hooksInstalled', 1)]:
            data = capture()
            data['cardEarly']['native'][key] = value
            with self.assertRaises(analysis.CaptureAnalysisError):
                analysis.analyze(data)

    def test_build_scripts_use_unix_line_endings(self):
        for path in (SCRIPT.parent).glob('*.sh'):
            with self.subTest(path=path.name):
                self.assertNotIn(b'\r', path.read_bytes())


if __name__ == '__main__':
    unittest.main()

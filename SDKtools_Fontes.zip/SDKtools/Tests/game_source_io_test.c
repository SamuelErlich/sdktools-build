#define _POSIX_C_SOURCE 200809L
#include "../Sources/SDKtools/STGameSourceIO.h"
#include <stdio.h>
static unsigned checks,failures;
#define CHECK(value) do{checks++;if(!(value)){failures++;fprintf(stderr,"FAIL %d: %s\n",__LINE__,#value);}}while(0)
static void Put(int dir,const char *name,const char *text) {int fd=openat(dir,name,O_WRONLY|O_CREAT|O_EXCL,0600);CHECK(fd>=0);if(fd>=0){CHECK(write(fd,text,strlen(text))==(ssize_t)strlen(text));close(fd);}}
int main(void) {
    for(unsigned i=0;i<6;i++){const char *bad[]={"../secret.js","/secret.js","src/../../x.js","a//b.js",".private.js","a\\b.js"};CHECK(!STGSRelative(bad[i]));}
    CHECK(STGSRelative("src/project.abc.js"));CHECK(STGSJS("project.js"));CHECK(!STGSJS("project.js.map"));CHECK(!STGSJS("credentials.json"));
    const unsigned char valid[]={0x61,0x0A,0xC3,0xA7,0xF0,0x9F,0x98,0x80};CHECK(STGSText(valid,sizeof(valid)));
    const unsigned char binary[]={0x61,0};CHECK(!STGSText(binary,sizeof(binary)));
    const unsigned char overlong[]={0xC0,0x80};CHECK(!STGSText(overlong,sizeof(overlong)));
    const unsigned char surrogate[]={0xED,0xA0,0x80};CHECK(!STGSText(surrogate,sizeof(surrogate)));
    const unsigned char shortUTF8[]={0xF0,0x9F};CHECK(!STGSText(shortUTF8,sizeof(shortUTF8)));
    size_t offsets[2];CHECK(STGSMatches((const unsigned char*)"UseProp UseProp UseProp",23,"UseProp",offsets,2)==2);CHECK(offsets[0]==0&&offsets[1]==8);
    char base[]="/tmp/sdktools-source-test.XXXXXX";CHECK(mkdtemp(base)!=NULL);
    int dir=open(base,O_RDONLY|O_DIRECTORY);CHECK(dir>=0);struct stat root;CHECK(!fstat(dir,&root));
    Put(dir,"project.js","function UseProp(){}\n");Put(dir,"private.json","secret");
    CHECK(!mkdirat(dir,"src",0700));int sub=STGSOpenRelative(dir,"src",true);CHECK(sub>=0);Put(sub,"game.js","var x=1;");close(sub);
    CHECK(!symlinkat("/etc",dir,"outside"));CHECK(!symlinkat("project.js",dir,"link.js"));
    CHECK(STGSOpenRelative(dir,"outside/passwd",false)<0);CHECK(STGSOpenRelative(dir,"link.js",false)<0);CHECK(STGSOpenRelative(dir,"../etc",false)<0);
    unsigned char *bytes=NULL;size_t size=0;
    CHECK(STGSRead(dir,"project.js",root.st_dev,1024,STGSNow()+5,&bytes,&size)==STGSReadOK);CHECK(size==21);free(bytes);
    CHECK(STGSRead(dir,"project.js",root.st_dev,3,STGSNow()+5,&bytes,&size)==STGSReadSize);
    CHECK(STGSRead(dir,"project.js",root.st_dev,1024,STGSNow()-1,&bytes,&size)==STGSReadTimeout);
    CHECK(STGSRead(dir,"private.json",root.st_dev,1024,STGSNow()+5,&bytes,&size)==STGSReadUnavailable);
    CHECK(!mkfifoat(dir,"pipe.js",0600));
    CHECK(STGSRead(dir,"pipe.js",root.st_dev,1024,STGSNow()+1,&bytes,&size)==STGSReadUnavailable);
    CHECK(!unlinkat(dir,"pipe.js",0));
    int invalid=openat(dir,"binary.js",O_CREAT|O_WRONLY|O_EXCL,0600);CHECK(invalid>=0);
    CHECK(write(invalid,binary,sizeof(binary))==(ssize_t)sizeof(binary));close(invalid);
    CHECK(STGSRead(dir,"binary.js",root.st_dev,1024,STGSNow()+1,&bytes,&size)==STGSReadNotText);
    CHECK(!unlinkat(dir,"binary.js",0));
    CHECK(!linkat(dir,"project.js",dir,"hardlink.js",0));CHECK(STGSRead(dir,"hardlink.js",root.st_dev,1024,STGSNow()+5,&bytes,&size)==STGSReadUnavailable);CHECK(!unlinkat(dir,"hardlink.js",0));
    STGSInventory *inventory=calloc(1,sizeof(*inventory));CHECK(inventory!=NULL);inventory->deadline=STGSNow()+5;inventory->device=root.st_dev;
    STGSWalk(dir,dir,"",0,inventory);CHECK(inventory->count==2);CHECK(inventory->symlinks==2);CHECK(inventory->nonJS==1);CHECK(!strcmp(inventory->files[0].path,"project.js")&&!strcmp(inventory->files[1].path,"src/game.js"));CHECK(!inventory->errors&&!inventory->timedOut&&!inventory->entryLimit);
    memset(inventory,0,sizeof(*inventory));inventory->deadline=STGSNow()-1;inventory->device=root.st_dev;STGSWalk(dir,dir,"",0,inventory);CHECK(inventory->timedOut);CHECK(inventory->count==0);
    memset(inventory,0,sizeof(*inventory));inventory->deadline=STGSNow()+5;inventory->device=root.st_dev;inventory->visited=STGS_MAX_ENTRIES;STGSWalk(dir,dir,"",0,inventory);CHECK(inventory->entryLimit);
    memset(inventory,0,sizeof(*inventory));inventory->deadline=STGSNow()+5;inventory->device=root.st_dev;STGSWalk(dir,dir,"",STGS_MAX_DEPTH+1,inventory);CHECK(inventory->excessiveDepth==1);CHECK(inventory->count==0);
    struct stat changed=root;changed.st_size++;CHECK(!STGSStatSame(root,changed));CHECK(STGSStatSame(root,root));
    CHECK(STGSDirectoryPriority("src")<STGSDirectoryPriority("assets"));CHECK(STGSDirectoryPriority("main")<STGSDirectoryPriority("native"));
    free(inventory);CHECK(!unlinkat(dir,"src/game.js",0));CHECK(!unlinkat(dir,"src",AT_REMOVEDIR));CHECK(!unlinkat(dir,"project.js",0));CHECK(!unlinkat(dir,"private.json",0));CHECK(!unlinkat(dir,"outside",0));CHECK(!unlinkat(dir,"link.js",0));close(dir);CHECK(!rmdir(base));
    printf("Game source IO: %u checks, %u failures\n",checks,failures);return failures?1:0;
}

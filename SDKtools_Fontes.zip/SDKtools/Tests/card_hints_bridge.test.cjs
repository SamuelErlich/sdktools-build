'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const bridge = fs.readFileSync(path.join(__dirname, '../Sources/SDKtools/STCardHintsBridge.inc'), 'utf8');
function template(name) {
  const match = bridge.match(new RegExp('NSString \\*' + name + ' = \\[NSString stringWithFormat:\\s*@"([^"\\n]+)"'));
  assert.ok(match, 'production wrapper must be discoverable');
  return match[1];
}
function format(source, values) {
  let i = 0;
  const result = source.replace(/%@/g, () => values[i++]);
  assert.equal(i, values.length);
  return result;
}
const runtime = 'function(){factoryCalls++;return {tick:function(){ticks++;return {version:1,status:"ready",reason:"hints_ready",shown:1,unknown:2,unavailable:0};},clear:function(){clears++;},owns:function(){return false;}};}';
function fixture() { return vm.createContext({ window: {}, factoryCalls: 0, ticks: 0, clears: 0 }); }
function tick(ctx, known = '', candidate = 'doc1', factory = runtime, rootFactory = 'function(){return {};}') {
  return vm.runInContext(format(template('wrapped'), ['__SDKtools_cards_native', known || candidate, known ? 'true' : 'false', factory, rootFactory, candidate]), ctx);
}
test('native injection passes the packaged root reader to the renderer and immediately ticks it', () => {
  const ctx=fixture();
  const renderer='function(makeRoot){var root=makeRoot();return {tick:function(){return {shown:root.read()};},clear:function(){},owns:function(){return false;}};}';
  const root='function(){factoryCalls++;return {read:function(){return ++ticks;}};}';
  assert.equal(tick(ctx,'','doc1',renderer,root).shown,1);
  assert.equal(tick(ctx,'doc1','doc2',renderer,root).shown,2);
  assert.equal(ctx.factoryCalls,1);
});
test('native wrapper creates one runtime and reuses the native document binding', () => {
  const ctx = fixture();
  assert.equal(tick(ctx).runtimeDocumentID, 'doc1');
  assert.equal(tick(ctx, 'doc1', 'doc2').runtimeDocumentID, 'doc1');
  assert.equal(ctx.factoryCalls, 1);
  assert.equal(ctx.ticks, 2);
  const descriptor = Object.getOwnPropertyDescriptor(ctx.window, '__SDKtools_cards_native');
  assert.equal(descriptor.enumerable, false);
  assert.equal(descriptor.writable, false);
});
test('cleanup invokes only the SDK-owned clear and keeps identity for resumed observation', () => {
  const ctx = fixture(); tick(ctx);
  vm.runInContext(format(template('script'), ['__SDKtools_cards_native', 'false']), ctx);
  assert.equal(ctx.clears, 1);
  assert.equal(tick(ctx, 'doc1', 'doc2').runtimeDocumentID, 'doc1');
  assert.equal(ctx.factoryCalls, 1);
});
test('same-webview navigation never silently reinstalls a renderer without explicit activation', () => {
  const ctx = fixture(); tick(ctx);
  ctx.window = {};
  const result = tick(ctx, 'doc1', 'doc2');
  assert.equal(result.reason, 'document_changed');
  assert.equal(result.shown, 0);
  assert.equal(ctx.factoryCalls, 1);
  assert.equal(ctx.window.__SDKtools_cards_native, undefined);
});
test('a getter or foreign namespace cannot trigger accessors, factory or cleanup', () => {
  const ctx = fixture(); let reads = 0;
  Object.defineProperty(ctx.window, '__SDKtools_cards_native', { get() { reads++; return {}; }, configurable: true });
  assert.equal(tick(ctx).reason, 'namespace_conflict');
  vm.runInContext(format(template('script'), ['__SDKtools_cards_native', 'false']), ctx);
  assert.equal(reads, 0);
  assert.equal(ctx.factoryCalls, 0);
  Object.defineProperty(ctx.window, '__SDKtools_cards_native', { value: { owner: 'foreign', runtime: { tick() { throw Error('must not call'); }, clear() { throw Error('must not call'); } } }, configurable: true });
  assert.equal(tick(ctx).reason, 'namespace_conflict');
  vm.runInContext(format(template('script'), ['__SDKtools_cards_native', 'true']), ctx);
});
test('missing factory methods do not become a live renderer', () => {
  const ctx = fixture();
  assert.equal(tick(ctx, '', 'doc1', 'function(){return {tick:function(){throw Error("must not call");}};}').reason, 'renderer_unavailable');
  assert.equal(ctx.window.__SDKtools_cards_native, undefined);
});
test('retired session cleanup releases its own namespace rather than accumulating closures', () => {
  const ctx = fixture(); tick(ctx);
  vm.runInContext(format(template('script'), ['__SDKtools_cards_native', 'true']), ctx);
  assert.equal(ctx.clears, 1);
  assert.equal(ctx.window.__SDKtools_cards_native, undefined);
});

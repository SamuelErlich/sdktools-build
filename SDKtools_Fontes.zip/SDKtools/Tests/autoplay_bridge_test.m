// macOS/Foundation test of the exact production result boundary.
#import "../Sources/SDKtools/STAutoplaySanitizer.inc"
#import "../Sources/SDKtools/STPowerSanitizer.inc"
#import "../Sources/SDKtools/STWarehouseSanitizer.inc"
#include <stdio.h>

static NSUInteger checks = 0, failures = 0;
static void Check(BOOL condition, NSString *message) {
    checks++;
    if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSMutableDictionary *Result(NSString *status, BOOL dispatched) {
    return [@{@"version": @1, @"status": status, @"reason": @"plan_ready", @"dispatched": @(dispatched),
        @"awaitingBoardChange": @(dispatched), @"cardsRead": @217, @"confirmedMoves": @3} mutableCopy];
}
static BOOL Invalid(id input) { return [STWPSanitizeAutoplay(input)[@"status"] isEqual:@"dispatch_uncertain"]; }
static NSMutableDictionary *WarehouseResult(NSString *status, id dispatched) {
    return [@{@"version": @1, @"command": @"open", @"status": status,
        @"reason": @"original_warehouse_requested", @"dispatched": dispatched ?: NSNull.null} mutableCopy];
}
static BOOL InvalidWarehouse(id input) {
    NSDictionary *safe = STWPSanitizeWarehouse(input);
    return [safe[@"status"] isEqual:@"dispatch_uncertain"] && [safe[@"reason"] isEqual:@"invalid_action_result"] &&
        safe[@"dispatched"] == NSNull.null && ![safe[@"physicalPending"] boolValue];
}
int main(void) { @autoreleasepool {
    NSDictionary *valid = STWPSanitizeAutoplay(Result(@"original_event_dispatched", YES));
    Check([valid[@"status"] isEqual:@"original_event_dispatched"] && [valid[@"dispatched"] boolValue], @"one original event retained");
    Check([valid[@"confirmedMoves"] isEqual:@3] && [valid[@"cardsRead"] isEqual:@217], @"bounded counters retained");
    Check(![valid[@"physicalPending"] boolValue], @"JS cannot claim a native physical pending lock");
    NSMutableDictionary *uncertain = Result(@"dispatch_uncertain", YES);
    uncertain[@"reason"] = @"event_exception";
    NSDictionary *safeUncertain = STWPSanitizeAutoplay(uncertain);
    Check([safeUncertain[@"dispatched"] boolValue] && [safeUncertain[@"awaitingBoardChange"] boolValue], @"throwing original callback remains an attempted pending move");
    Check([safeUncertain[@"reason"] isEqual:@"event_exception"], @"uncertain action reason retained");
    Check(Invalid(@[]), @"array rejected");
    Check(Invalid(NSNull.null), @"null rejected");
    for (id bad in @[@YES, @0, @2, @"1"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"version"] = bad;
        Check(Invalid(row), @"invalid or Boolean version rejected");
    }
    for (NSString *key in @[@"cardsRead", @"confirmedMoves"]) {
        for (id bad in @[@YES, @(-1), @1.5, @"3", @1000001]) {
            NSMutableDictionary *row = Result(@"watching", NO); row[key] = bad;
            Check(Invalid(row), @"invalid count rejected");
        }
    }
    NSMutableDictionary *tooMany = Result(@"watching", NO); tooMany[@"cardsRead"] = @4097;
    Check(Invalid(tooMany), @"card count boundary enforced");
    for (NSString *key in @[@"dispatched", @"awaitingBoardChange"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[key] = @1;
        Check(Invalid(row), @"numeric Boolean rejected");
    }
    Check(Invalid(Result(@"watching", YES)), @"dispatched move cannot masquerade as observation");
    Check(Invalid(Result(@"original_event_dispatched", NO)), @"dispatch success must include true flag");
    NSMutableDictionary *arbitrary = Result(@"watching", NO);
    arbitrary[@"reason"] = @"private_identifier"; arbitrary[@"secret"] = @"must_not_escape";
    NSDictionary *bounded = STWPSanitizeAutoplay(arbitrary);
    Check([bounded[@"reason"] isEqual:@"unrecognized_reason"] && !bounded[@"secret"], @"unknown reason and extra fields removed");
    for (NSString *reason in @[@"new_board_stability", @"new_board_detected", @"confirmation_uncertain"]) {
        NSMutableDictionary *row = Result(@"waiting_confirmation", NO); row[@"reason"] = reason;
        Check([STWPSanitizeAutoplay(row)[@"reason"] isEqual:reason], @"observed transition reason preserved");
    }
    for (NSString *detail in @[@"board_bounds", @"tray_mask_or_y", @"tray_spacing", @"external_card", @"warehouse_card_unsettled",
        @"original_touch_pending", @"board_metadata_position"]) {
        NSMutableDictionary *row = Result(@"blocked", NO);
        row[@"reason"] = @"animation_active"; row[@"animationDetail"] = detail;
        Check([STWPSanitizeAutoplay(row)[@"animationDetail"] isEqual:detail], @"bounded animation diagnosis retained");
        row[@"reason"] = @"plan_ready";
        Check(!STWPSanitizeAutoplay(row)[@"animationDetail"], @"animation diagnosis cannot attach to unrelated state");
    }
    NSMutableDictionary *untrustedDetail = Result(@"blocked", NO);
    untrustedDetail[@"reason"] = @"animation_active";
    untrustedDetail[@"animationDetail"] = @"private_card_name";
    Check(!STWPSanitizeAutoplay(untrustedDetail)[@"animationDetail"], @"arbitrary animation string omitted");
    for (id count in @[@0, @16, @512]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"cardTypesRead"] = count;
        Check([STWPSanitizeAutoplay(row)[@"cardTypesRead"] isEqual:count], @"card type diagnostic bounded integer retained");
    }
    for (id count in @[@YES, @(-1), @1.2, @513, @"16"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"cardTypesRead"] = count;
        Check(Invalid(row), @"invalid card type count rejected");
    }
    NSMutableDictionary *inputUnavailable = Result(@"blocked", NO); inputUnavailable[@"reason"] = @"input_event_unavailable";
    Check([STWPSanitizeAutoplay(inputUnavailable)[@"reason"] isEqual:@"input_event_unavailable"], @"Cocos touch construction failure remains diagnosable");
    for (NSString *slot in @[@"left", @"center", @"right", @"current"]) {
        NSString *command = [slot isEqual:@"current"] ? @"confirm" : @"open";
        NSDictionary *power = @{@"version": @1, @"slot": slot, @"command": command,
            @"status": @"original_event_dispatched", @"reason": @"original_power_requested", @"dispatched": @YES,
            @"boardEffectConfirmed": @YES, @"secret": @"do not export"};
        NSDictionary *safe = STWPSanitizeReturnResult(power, slot, command);
        Check([safe[@"slot"] isEqual:slot] && [safe[@"command"] isEqual:command], @"power request identity retained");
        Check([safe[@"popupConfirmationRequired"] boolValue] == [command isEqual:@"open"], @"opening and consuming have distinct confirmation status");
        Check(![safe[@"boardEffectConfirmed"] boolValue] && !safe[@"secret"], @"callback dispatch cannot prove a board effect");
        Check([STWPSanitizeReturnResult(power, @"right", @"confirm")[@"status"] isEqual:@"dispatch_uncertain"], @"mismatched response cannot confirm another request");
    }
    Check(!STWPPowerOptions(@"current", @"open") && !STWPPowerOptions(@"arbitrary", @"confirm"), @"unknown power arguments rejected");
    for (NSString *reason in @[@"stock_empty", @"stock_unavailable", @"prop_mismatch", @"confirmation_unavailable", @"confirmation_ambiguous"]) {
        NSDictionary *power = @{@"version": @1, @"slot": @"current", @"command": @"confirm",
            @"status": @"no_action", @"reason": reason, @"dispatched": @NO};
        Check([STWPSanitizeReturnResult(power, @"current", @"confirm")[@"reason"] isEqual:reason], @"power stock and identity refusals remain diagnosable");
    }
    NSDictionary *boolVersion = @{@"version": @YES, @"slot": @"left", @"command": @"open", @"status": @"no_action", @"dispatched": @NO};
    Check([STWPSanitizeReturnResult(boolVersion, @"left", @"open")[@"status"] isEqual:@"dispatch_uncertain"], @"boolean power protocol version rejected");
    NSDictionary *pending = STWPAutoResult(@"dispatch_uncertain", @"evaluation_timeout", YES);
    Check([pending[@"physicalPending"] boolValue], @"native timeout helper keeps physical lock flag");

    // X-ray contributes bounded visual diagnostics, never card IDs, source or a native lock.
    for (NSString *status in @[@"off", @"ready", @"unavailable", @"blocked"]) {
        NSMutableDictionary *row = Result(@"watching", NO);
        row[@"xray"] = @{@"status": status, @"coveredIcons": @512, @"matchedBorders": @3,
            @"cardIDs": @[@"private-card"], @"source": @"private-source", @"physicalPending": @YES};
        row[@"physicalPending"] = @YES;
        NSDictionary *safe = STWPSanitizeAutoplay(row), *xray = safe[@"xray"];
        Check([xray[@"status"] isEqual:status] && [xray[@"coveredIcons"] isEqual:@512] &&
            [xray[@"matchedBorders"] isEqual:@3], @"bounded x-ray state retained at maximum counts");
        Check(xray.count == 3 && !xray[@"cardIDs"] && !xray[@"source"] && !xray[@"physicalPending"],
            @"private and extra x-ray fields never cross the result boundary");
        Check(![safe[@"physicalPending"] boolValue], @"x-ray and page cannot claim native physical pending");
    }
    NSMutableDictionary *zeroXray = Result(@"watching", NO);
    zeroXray[@"xray"] = @{@"status": @"off", @"coveredIcons": @0, @"matchedBorders": @0};
    Check([STWPSanitizeAutoplay(zeroXray)[@"xray"] isEqual:zeroXray[@"xray"]], @"zero x-ray counts retained");
    for (NSString *key in @[@"coveredIcons", @"matchedBorders"]) {
        NSNumber *overflow = [key isEqual:@"coveredIcons"] ? @513 : @4;
        for (id bad in @[@YES, @(-1), @0.5, @"1", NSNull.null, overflow, @(NAN), @(INFINITY)]) {
            NSMutableDictionary *row = Result(@"watching", NO);
            NSMutableDictionary *xray = [@{@"status": @"ready", @"coveredIcons": @4, @"matchedBorders": @3} mutableCopy];
            xray[key] = bad; row[@"xray"] = xray;
            NSDictionary *safe = STWPSanitizeAutoplay(row);
            Check(!safe[@"xray"] && [safe[@"status"] isEqual:@"watching"], @"invalid optional x-ray count omitted without inventing action uncertainty");
        }
        NSMutableDictionary *row = Result(@"watching", NO);
        NSMutableDictionary *xray = [@{@"status": @"ready", @"coveredIcons": @4, @"matchedBorders": @3} mutableCopy];
        [xray removeObjectForKey:key]; row[@"xray"] = xray;
        Check(!STWPSanitizeAutoplay(row)[@"xray"], @"missing x-ray count omits the optional object");
    }
    for (id badStatus in @[@"private-status", @YES, @1, NSNull.null]) {
        NSMutableDictionary *row = Result(@"watching", NO);
        row[@"xray"] = @{@"status": badStatus, @"coveredIcons": @2, @"matchedBorders": @3};
        NSDictionary *safe = STWPSanitizeAutoplay(row);
        Check(!safe[@"xray"] && [safe[@"status"] isEqual:@"watching"], @"unknown or non-string x-ray status omitted");
    }
    for (id badXray in @[@[], @"ready", @YES, NSNull.null, @{}]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"xray"] = badXray;
        Check(!STWPSanitizeAutoplay(row)[@"xray"], @"malformed optional x-ray object omitted");
    }
    Check(!STWPSanitizeAutoplay(Result(@"watching", NO))[@"xray"], @"absent x-ray remains absent");

    // V3.1: depth preferences and incremental planning are bounded diagnostics.
    // They must never turn an observation into a dispatched move.
    NSMutableDictionary *layered = Result(@"planning", NO);
    layered[@"reason"] = @"search_in_progress";
    layered[@"xray"] = @{@"status": @"ready", @"coveredIcons": @12, @"matchedBorders": @0,
        @"depthLimit": @5, @"hiddenByDepth": @300, @"hiddenByLayout": @4, @"labelMode": @"cocos_label",
        @"cards": @[@"private-card"]};
    layered[@"planning"] = @{@"state": @"searching", @"nodes": @1000000, @"slices": @1000000,
        @"goal": @"all_observed_triples", @"residualCards": @2, @"solution": @[@"private-card"], @"dispatched": @YES};
    NSDictionary *layeredSafe = STWPSanitizeAutoplay(layered);
    Check([layeredSafe[@"status"] isEqual:@"planning"] && [layeredSafe[@"reason"] isEqual:@"search_in_progress"] &&
        ![layeredSafe[@"dispatched"] boolValue], @"incremental search is an observation, never a move");
    Check([layeredSafe[@"xray"][@"depthLimit"] isEqual:@5] && [layeredSafe[@"xray"][@"hiddenByDepth"] isEqual:@300] &&
        [layeredSafe[@"xray"][@"hiddenByLayout"] isEqual:@4] && !layeredSafe[@"xray"][@"cards"], @"bounded layer statistics retained without card identifiers");
    Check([layeredSafe[@"planning"][@"goal"] isEqual:@"all_observed_triples"] &&
        [layeredSafe[@"planning"][@"residualCards"] isEqual:@2] && !layeredSafe[@"planning"][@"solution"] &&
        !layeredSafe[@"planning"][@"dispatched"], @"local planning goal retained without source, route or dispatch claims");
    Check(Invalid(Result(@"planning", YES)), @"search cannot claim a dispatched card");
    for (id bad in @[@0, @6, @YES, @1.5, @"2", NSNull.null]) {
        NSMutableDictionary *row = [layered mutableCopy], *visual = [layered[@"xray"] mutableCopy];
        visual[@"depthLimit"] = bad; row[@"xray"] = visual;
        Check(!STWPSanitizeAutoplay(row)[@"xray"][@"depthLimit"], @"depth accepts only integers one through five");
    }
    for (NSString *key in @[@"hiddenByDepth", @"hiddenByLayout"]) {
        NSMutableDictionary *row = [layered mutableCopy], *visual = [layered[@"xray"] mutableCopy];
        visual[key] = @513; row[@"xray"] = visual;
        Check(!STWPSanitizeAutoplay(row)[@"xray"][key], @"hidden icon counts are capped at the board limit");
    }
    for (NSString *mode in @[@"cocos_label", @"vector_digits", @"none"]) {
        NSMutableDictionary *row = [layered mutableCopy], *visual = [layered[@"xray"] mutableCopy];
        visual[@"labelMode"] = mode; row[@"xray"] = visual;
        Check([STWPSanitizeAutoplay(row)[@"xray"][@"labelMode"] isEqual:mode], @"known label rendering modes retained");
    }
    for (NSString *state in @[@"searching", @"proved", @"blocked"]) {
        NSMutableDictionary *row = [layered mutableCopy], *progress = [layered[@"planning"] mutableCopy];
        progress[@"state"] = state; row[@"planning"] = progress;
        Check([STWPSanitizeAutoplay(row)[@"planning"][@"state"] isEqual:state], @"closed planning states retained");
    }
    for (NSString *key in @[@"nodes", @"slices"]) for (id bad in @[@YES, @(-1), @0.5, @1000001, @"1", NSNull.null]) {
        NSMutableDictionary *row = [layered mutableCopy], *progress = [layered[@"planning"] mutableCopy];
        progress[key] = bad; row[@"planning"] = progress;
        NSDictionary *safe = STWPSanitizeAutoplay(row);
        Check(!safe[@"planning"] && [safe[@"status"] isEqual:@"planning"], @"invalid optional search statistics do not invent dispatch uncertainty");
    }
    for (NSString *reason in @[@"observed_state_unbalanced", @"observed_state_locked", @"no_complete_solution",
        @"search_limit_reached", @"unsupported_card_rules", @"external_mode_active", @"board_clear", @"no_remaining_triples"]) {
        NSMutableDictionary *row = Result(@"blocked", NO); row[@"reason"] = reason;
        Check([STWPSanitizeAutoplay(row)[@"reason"] isEqual:reason], @"bounded planner outcome remains diagnosable");
    }

    // Own-warehouse dispatch reports only an original callback request. It cannot
    // prove a selector opened, authorize another owner or assert native pending.
    NSMutableDictionary *warehouse = WarehouseResult(@"original_event_dispatched", @YES);
    warehouse[@"effectConfirmed"] = @YES; warehouse[@"boardEffectConfirmed"] = @YES;
    warehouse[@"physicalPending"] = @YES; warehouse[@"ownerOnly"] = @NO; warehouse[@"serverManaged"] = @NO;
    warehouse[@"ownerID"] = @"private-owner"; warehouse[@"secret"] = @"private-value";
    warehouse[@"stats"] = @{@"path": @"private-local-path"};
    NSDictionary *safeWarehouse = STWPSanitizeWarehouse(warehouse);
    Check([safeWarehouse[@"status"] isEqual:@"original_event_dispatched"] &&
        safeWarehouse[@"dispatched"] == (__bridge id)kCFBooleanTrue, @"original warehouse request retained");
    Check(![safeWarehouse[@"effectConfirmed"] boolValue] && !safeWarehouse[@"boardEffectConfirmed"],
        @"warehouse callback cannot claim selector or board effect confirmation");
    Check([safeWarehouse[@"ownerOnly"] boolValue] && [safeWarehouse[@"serverManaged"] boolValue] &&
        ![safeWarehouse[@"physicalPending"] boolValue], @"warehouse result retains ownership and server policy and cannot forge native pending");
    Check(!safeWarehouse[@"ownerID"] && !safeWarehouse[@"secret"] && !safeWarehouse[@"stats"] && safeWarehouse.count == 9,
        @"warehouse extra fields and identifiers dropped");
    for (NSString *reason in @[@"own_slot_locked", @"own_slot_occupied", @"owner_unknown", @"owner_ambiguous",
        @"selection_already_open", @"store_unavailable", @"slot_state_unavailable", @"slot_state_changed", @"disabled_control", @"modal_visible"]) {
        NSMutableDictionary *row = WarehouseResult(@"no_action", @NO); row[@"reason"] = reason;
        NSDictionary *safe = STWPSanitizeWarehouse(row);
        Check([safe[@"status"] isEqual:@"no_action"] && [safe[@"reason"] isEqual:reason] &&
            safe[@"dispatched"] == (__bridge id)kCFBooleanFalse, @"own-slot refusal reason retained without claiming a dispatch");
    }
    NSMutableDictionary *unknownWarehouse = WarehouseResult(@"no_action", @NO);
    unknownWarehouse[@"reason"] = @"private-player-name";
    Check([STWPSanitizeWarehouse(unknownWarehouse)[@"reason"] isEqual:@"warehouse_unavailable"],
        @"unknown warehouse reason replaced with bounded diagnostic");
    for (id bad in @[@[], NSNull.null, @"open"]) Check(InvalidWarehouse(bad), @"non-object warehouse result rejected");
    for (id bad in @[@YES, @0, @2, @0.5, @"1", NSNull.null]) {
        NSMutableDictionary *row = WarehouseResult(@"no_action", @NO); row[@"version"] = bad;
        Check(InvalidWarehouse(row), @"invalid or boolean warehouse protocol rejected");
    }
    NSMutableDictionary *missingVersion = WarehouseResult(@"no_action", @NO); [missingVersion removeObjectForKey:@"version"];
    Check(InvalidWarehouse(missingVersion), @"missing warehouse protocol rejected");
    for (id bad in @[@"close", @"all", @"", @YES, NSNull.null]) {
        NSMutableDictionary *row = WarehouseResult(@"no_action", @NO); row[@"command"] = bad;
        Check(InvalidWarehouse(row), @"unknown or non-string warehouse command rejected");
    }
    NSMutableDictionary *missingCommand = WarehouseResult(@"no_action", @NO); [missingCommand removeObjectForKey:@"command"];
    Check(InvalidWarehouse(missingCommand), @"missing warehouse command rejected");
    for (NSString *status in @[@"no_action", @"original_event_dispatched"]) {
        for (id bad in @[@0, @1, @"true", @"false", NSNull.null]) {
            Check(InvalidWarehouse(WarehouseResult(status, bad)), @"numeric or malformed warehouse boolean rejected");
        }
    }
    Check(InvalidWarehouse(WarehouseResult(@"no_action", @YES)), @"warehouse no-action cannot carry dispatched true");
    Check(InvalidWarehouse(WarehouseResult(@"original_event_dispatched", @NO)), @"warehouse dispatched status cannot carry false");
    Check(InvalidWarehouse(WarehouseResult(@"watching", @NO)), @"unrecognized warehouse status rejected");
    NSMutableDictionary *uncertainWarehouse = WarehouseResult(@"dispatch_uncertain", @YES);
    uncertainWarehouse[@"effectConfirmed"] = @YES; uncertainWarehouse[@"physicalPending"] = @YES;
    NSDictionary *safeWarehouseUncertain = STWPSanitizeWarehouse(uncertainWarehouse);
    Check([safeWarehouseUncertain[@"status"] isEqual:@"dispatch_uncertain"] &&
        safeWarehouseUncertain[@"dispatched"] == NSNull.null && ![safeWarehouseUncertain[@"effectConfirmed"] boolValue] &&
        ![safeWarehouseUncertain[@"physicalPending"] boolValue], @"uncertain warehouse result does not infer a dispatch, effect or native lock");
    NSDictionary *nativeWarehousePending = STWPWarehouseResult(@"dispatch_uncertain", @"evaluation_timeout", NSNull.null, YES);
    Check([nativeWarehousePending[@"physicalPending"] boolValue] && ![nativeWarehousePending[@"effectConfirmed"] boolValue],
        @"only native warehouse timeout helper may retain physical pending");
    printf("Autoplay bridge: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

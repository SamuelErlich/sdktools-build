// macOS/Foundation test of the exact production result boundary.
#import "../Sources/SDKtools/STAutoplaySanitizer.inc"
#include <stdio.h>

static NSUInteger checks = 0, failures = 0;
static void Check(BOOL condition, NSString *message) {
    checks++;
    if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSMutableDictionary *Result(NSString *status, BOOL dispatched) {
    return [@{@"version": @1, @"status": status, @"reason": @"plan_ready", @"dispatched": @(dispatched),
        @"awaitingBoardChange": @(dispatched), @"cardsRead": @217, @"confirmedMoves": @3} mutableCopy];
}
static BOOL Invalid(id input) { return [STWPSanitizeAutoplay(input)[@"status"] isEqual:@"dispatch_uncertain"]; }
int main(void) { @autoreleasepool {
    NSDictionary *valid = STWPSanitizeAutoplay(Result(@"original_event_dispatched", YES));
    Check([valid[@"status"] isEqual:@"original_event_dispatched"] && [valid[@"dispatched"] boolValue], @"one original event retained");
    Check([valid[@"confirmedMoves"] isEqual:@3] && [valid[@"cardsRead"] isEqual:@217], @"bounded counters retained");
    Check(![valid[@"physicalPending"] boolValue], @"JS cannot claim a native physical pending lock");
    NSMutableDictionary *uncertain = Result(@"dispatch_uncertain", YES);
    uncertain[@"reason"] = @"event_exception";
    NSDictionary *safeUncertain = STWPSanitizeAutoplay(uncertain);
    Check([safeUncertain[@"dispatched"] boolValue] && [safeUncertain[@"awaitingBoardChange"] boolValue], @"throwing original callback remains an attempted pending move");
    Check([safeUncertain[@"reason"] isEqual:@"event_exception"], @"uncertain action reason retained");
    Check(Invalid(@[]), @"array rejected");
    Check(Invalid(NSNull.null), @"null rejected");
    for (id bad in @[@YES, @0, @2, @"1"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"version"] = bad;
        Check(Invalid(row), @"invalid or Boolean version rejected");
    }
    for (NSString *key in @[@"cardsRead", @"confirmedMoves"]) {
        for (id bad in @[@YES, @(-1), @1.5, @"3", @1000001]) {
            NSMutableDictionary *row = Result(@"watching", NO); row[key] = bad;
            Check(Invalid(row), @"invalid count rejected");
        }
    }
    NSMutableDictionary *tooMany = Result(@"watching", NO); tooMany[@"cardsRead"] = @4097;
    Check(Invalid(tooMany), @"card count boundary enforced");
    for (NSString *key in @[@"dispatched", @"awaitingBoardChange"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[key] = @1;
        Check(Invalid(row), @"numeric Boolean rejected");
    }
    Check(Invalid(Result(@"watching", YES)), @"dispatched move cannot masquerade as observation");
    Check(Invalid(Result(@"original_event_dispatched", NO)), @"dispatch success must include true flag");
    NSMutableDictionary *arbitrary = Result(@"watching", NO);
    arbitrary[@"reason"] = @"private_identifier"; arbitrary[@"secret"] = @"must_not_escape";
    NSDictionary *bounded = STWPSanitizeAutoplay(arbitrary);
    Check([bounded[@"reason"] isEqual:@"unrecognized_reason"] && !bounded[@"secret"], @"unknown reason and extra fields removed");
    for (NSString *reason in @[@"new_board_stability", @"new_board_detected", @"confirmation_uncertain"]) {
        NSMutableDictionary *row = Result(@"waiting_confirmation", NO); row[@"reason"] = reason;
        Check([STWPSanitizeAutoplay(row)[@"reason"] isEqual:reason], @"observed transition reason preserved");
    }
    NSDictionary *pending = STWPAutoResult(@"dispatch_uncertain", @"evaluation_timeout", YES);
    Check([pending[@"physicalPending"] boolValue], @"native timeout helper keeps physical lock flag");
    printf("Autoplay bridge: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

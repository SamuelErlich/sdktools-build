// macOS/Foundation test of the exact production result boundary.
#import "../Sources/SDKtools/STAutoplaySanitizer.inc"
#import "../Sources/SDKtools/STPowerSanitizer.inc"
#import "../Sources/SDKtools/STWarehouseSanitizer.inc"
#import "../Sources/SDKtools/STWarehouseTestSanitizer.inc"
#include <stdio.h>

static NSUInteger checks = 0, failures = 0;
static void Check(BOOL condition, NSString *message) {
    checks++;
    if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSMutableDictionary *Result(NSString *status, BOOL dispatched) {
    return [@{@"version": @1, @"status": status, @"reason": @"plan_ready", @"dispatched": @(dispatched),
        @"awaitingBoardChange": @(dispatched), @"cardsRead": @217, @"confirmedMoves": @3} mutableCopy];
}
static BOOL Invalid(id input) { return [STWPSanitizeAutoplay(input)[@"status"] isEqual:@"dispatch_uncertain"]; }
static NSMutableDictionary *WarehouseResult(NSString *status, id dispatched) {
    return [@{@"version": @1, @"command": @"open", @"status": status,
        @"reason": @"original_warehouse_requested", @"dispatched": dispatched ?: NSNull.null} mutableCopy];
}
static BOOL InvalidWarehouse(id input) {
    NSDictionary *safe = STWPSanitizeWarehouse(input);
    return [safe[@"status"] isEqual:@"dispatch_uncertain"] && [safe[@"reason"] isEqual:@"invalid_action_result"] &&
        safe[@"dispatched"] == NSNull.null && ![safe[@"physicalPending"] boolValue];
}
static NSMutableDictionary *StockResult(void) {
    return [@{@"version":@1,@"command":@"warehouse_test",@"status":@"accepted",@"reason":@"server_200",
        @"active":@NO,@"localWriteApplied":@YES,@"localRestored":@YES,@"hooksRestored":@YES,@"requestObserved":@YES,
        @"responseObserved":@YES,@"slotEffectConfirmed":@NO,@"testedWhileLocked":@YES,@"attemptCount":@1,@"beforeLock":@3,@"afterLock":@3,@"serverCode":@200} mutableCopy];
}
int main(void) { @autoreleasepool {
    for (id malformed in @[NSNull.null,@{},@{@"version":@YES}]) {
        NSDictionary *read=STWPSanitizeAutoplayEvaluation(malformed,NO);
        Check([read[@"status"] isEqual:@"blocked"] && [read[@"dispatchOutcomeKnown"] boolValue] &&
            ![read[@"dispatched"] boolValue],@"a malformed read-only result cannot invent an uncertain new dispatch");
        Check([STWPSanitizeAutoplayEvaluation(malformed,YES)[@"status"] isEqual:@"dispatch_uncertain"],
            @"the same malformed result preserves uncertainty for action-capable evaluations");
    }
    NSMutableDictionary *contradictory=Result(@"watching",YES);
    Check([STWPSanitizeAutoplayEvaluation(contradictory,NO)[@"status"] isEqual:@"blocked"],
        @"inconsistent read-only report cannot pause a newly armed Play as an uncertain action");
    Check([STWPSanitizeAutoplayEvaluation(contradictory,YES)[@"status"] isEqual:@"dispatch_uncertain"],
        @"inconsistent action-capable report remains uncertain");
    NSMutableDictionary *priorPending=Result(@"dispatch_uncertain",NO);
    priorPending[@"reason"]=@"super_fast_uncertain";priorPending[@"awaitingBoardChange"]=@YES;
    NSDictionary *observedPending=STWPSanitizeAutoplayEvaluation(priorPending,NO);
    Check([observedPending[@"status"] isEqual:@"dispatch_uncertain"] && [observedPending[@"awaitingBoardChange"] boolValue],
        @"read-only observation preserves genuine uncertainty from an earlier action");
    NSMutableDictionary *hotTime=[@{@"version":@1,@"status":@"protected",@"reason":@"diamond_charge_unverified",
        @"chargePercent":@87.5,@"trioChargePercent":NSNull.null,@"thresholdPercent":NSNull.null,
        @"rawProgress":@0.875,@"cardID":@"private"} mutableCopy];
    NSDictionary *safeHotTime=STWPSanitizeHotTime(hotTime);
    Check(safeHotTime.count==6 && [safeHotTime[@"chargePercent"] isEqual:@87.5] && !safeHotTime[@"rawProgress"] && !safeHotTime[@"cardID"],@"HotTime exports a closed observed percentage without game identifiers");
    NSMutableDictionary *hotTimeRow=Result(@"blocked",NO);hotTimeRow[@"reason"]=@"diamond_charge_unverified";hotTimeRow[@"hotTime"]=hotTime;
    Check([STWPSanitizeAutoplay(hotTimeRow)[@"hotTime"] isEqual:safeHotTime],@"HotTime diagnostic survives production result sanitizer");
    hotTimeRow[@"cardTypesRead"]=@0;
    Check([STWPSanitizeAutoplayReading(hotTimeRow)[@"hotTime"] isEqual:safeHotTime],@"last-reading reports retain observed HotTime percentage");
    for (NSString *reason in @[@"diamond_charge_unverified",@"diamond_charge_unavailable"])
        Check([STWPAutoReason(reason) isEqual:reason],@"diamond protection reason remains actionable");
    for (id charge in @[@0,@100,@0.25]) {
        NSMutableDictionary *row=[hotTime mutableCopy];row[@"chargePercent"]=charge;
        Check(STWPSanitizeHotTime(row)!=nil,@"observed fractional charge includes both bounds");
    }
    for (id charge in @[@YES,@(-0.01),@100.01,@(NAN),@(INFINITY),@"87.5"]) {
        NSMutableDictionary *row=[hotTime mutableCopy];row[@"chargePercent"]=charge;
        Check(!STWPSanitizeHotTime(row),@"HotTime rejects nonfinite unbounded and nonnumeric charge");
    }
    for (NSString *key in @[@"trioChargePercent",@"thresholdPercent"]) {
        NSMutableDictionary *row=[hotTime mutableCopy];row[key]=@10;
        Check(!STWPSanitizeHotTime(row),@"unverified trio gain and threshold cannot become guessed percentages");
        [row removeObjectForKey:key];
        Check(!STWPSanitizeHotTime(row),@"unverified values must remain explicitly unknown");
    }
    for (NSString *key in @[@"version",@"status",@"reason",@"chargePercent"]) {
        NSMutableDictionary *row=[hotTime mutableCopy];[row removeObjectForKey:key];
        Check(!STWPSanitizeHotTime(row),@"partial HotTime diagnostic is discarded");
    }
    NSMutableDictionary *unavailableHotTime=[hotTime mutableCopy];unavailableHotTime[@"reason"]=@"diamond_charge_unavailable";
    Check(!STWPSanitizeHotTime(unavailableHotTime),@"unavailable gauge cannot retain stale charge");
    unavailableHotTime[@"chargePercent"]=NSNull.null;
    Check(STWPSanitizeHotTime(unavailableHotTime)!=nil,@"unavailable gauge remains explicitly unknown");
    unavailableHotTime[@"reason"]=@"diamond_charge_unverified";
    Check(!STWPSanitizeHotTime(unavailableHotTime),@"unverified gain still requires a valid observed gauge");
    hotTimeRow[@"hotTime"]=unavailableHotTime;hotTimeRow[@"status"]=@"original_event_dispatched";hotTimeRow[@"dispatched"]=@YES;
    NSDictionary *dispatchWithBadGauge=STWPSanitizeAutoplay(hotTimeRow);
    Check([dispatchWithBadGauge[@"dispatched"] boolValue] && !dispatchWithBadGauge[@"hotTime"],@"bad optional gauge does not erase an already submitted event");
    NSMutableDictionary *cooperative=Result(@"watching",NO);
    cooperative[@"cooperative"]=@{@"version":@1,@"phase":@"waiting_supply",@"progressPercent":@80,@"available":@2,@"pending":@NO,@"confirmed":@3,@"reason":@"waiting_supply",@"serverConfirmed":@NO,@"rawID":@"private"};
    NSDictionary *safeCooperative=STWPSanitizeAutoplay(cooperative)[@"cooperative"];
    Check(safeCooperative.count==8 && [safeCooperative[@"progressPercent"] isEqual:@80] && !safeCooperative[@"rawID"],@"cooperative diagnostics retain only bounded closed fields");
    cooperative[@"cardsRead"]=@0;cooperative[@"cardTypesRead"]=@0;
    Check([STWPSanitizeAutoplayReading(cooperative)[@"cooperative"] isEqual:safeCooperative],@"last-reading reports retain the same closed cooperative diagnostics");
    for (NSString *reason in @[@"diamond_charge_unverified",@"diamond_charge_unavailable"]) {
        NSMutableDictionary *row=[cooperative mutableCopy], *supply=[cooperative[@"cooperative"] mutableCopy];
        row[@"status"]=@"blocked";row[@"reason"]=reason;supply[@"reason"]=reason;supply[@"available"]=@0;row[@"cooperative"]=supply;
        NSDictionary *safe=STWPSanitizeAutoplay(row)[@"cooperative"];
        Check(safe.count==8 && [safe[@"reason"] isEqual:reason] && [safe[@"available"] isEqual:@0] && !safe[@"rawID"],@"protected allied diamond supply retains closed cooperative detail");
        Check([STWPSanitizeAutoplayReading(row)[@"cooperative"] isEqual:safe],@"protected supply detail survives last-reading report projection");
        supply[@"reason"]=@"private_unbounded_reason";
        Check(!STWPSanitizeCooperative(supply),@"diamond protection does not widen cooperative reason boundary");
    }
    for(id invalidProgress in @[@YES,@(-1),@101,@"80"]){
        NSMutableDictionary *row=[cooperative[@"cooperative"] mutableCopy];row[@"progressPercent"]=invalidProgress;cooperative[@"cooperative"]=row;
        Check(!STWPSanitizeAutoplay(cooperative)[@"cooperative"],@"invalid cooperative progress is discarded");
    }
    NSMutableDictionary *fast=[@{@"version":@1,@"status":@"submitted",@"reason":@"invoking_original",@"pending":@YES,@"batches":@1,
        @"submitted":@3,@"requests":@3,@"responses":@2,@"settled":@2,@"accepted":@2,@"effectObserved":@NO,@"confirmedCards":@0,
        @"packet_id":@77,@"cardID":@"private"} mutableCopy];
    NSDictionary *safeFast=STWPSanitizeSuperFast(fast);
    Check(safeFast.count==12 && !safeFast[@"packet_id"] && !safeFast[@"cardID"],@"burst boundary exports only closed counters");
    for(NSString *key in @[@"submitted",@"requests",@"responses",@"settled",@"accepted"]){
        NSMutableDictionary *bad=[fast mutableCopy];bad[key]=@4;
        Check(!STWPSanitizeSuperFast(bad),@"at most three per batch");
        bad=[fast mutableCopy];bad[key]=@YES;
        Check(!STWPSanitizeSuperFast(bad),@"batch counters reject boolean impostors");
    }
    NSMutableDictionary *badFast=[fast mutableCopy];badFast[@"status"]=@"confirmed";badFast[@"pending"]=@NO;badFast[@"effectObserved"]=@YES;
    Check(!STWPSanitizeSuperFast(badFast),@"cannot confirm batch with missing acknowledgements");
    badFast[@"responses"]=@3;badFast[@"settled"]=@3;badFast[@"accepted"]=@3;badFast[@"confirmedCards"]=@3;
    Check(STWPSanitizeSuperFast(badFast)!=nil,@"all responses settlements and effect agree");
    NSMutableDictionary *fastRow=Result(@"watching",NO);fastRow[@"superFast"]=fast;
    Check([STWPSanitizeAutoplay(fastRow)[@"superFast"] isEqual:safeFast],@"batch summary survives production sanitizer");
    NSMutableDictionary *compatFast=[@{@"version":@1,@"status":@"blocked",@"reason":@"observer_unavailable",@"pending":@NO,@"batches":@0,
        @"submitted":@0,@"requests":@0,@"responses":@0,@"settled":@0,@"accepted":@0,@"effectObserved":@NO,@"confirmedCards":@0,
        @"observerIssue":@"transport",@"compatibility":@YES,@"url":@"private"} mutableCopy];
    NSDictionary *safeCompat=STWPSanitizeSuperFast(compatFast);
    Check(safeCompat.count==14 && [safeCompat[@"compatibility"] boolValue] && !safeCompat[@"url"],@"closed zero-submission compatibility survives");
    for(NSString *key in @[@"pending",@"submitted",@"requests"]) {
        NSMutableDictionary *bad=[compatFast mutableCopy];bad[key]=[key isEqual:@"pending"]?@YES:@1;
        Check(!STWPSanitizeSuperFast(bad),@"compatibility cannot release a potentially submitted request");
    }
    for(id value in @[@1,@"true",NSNull.null]) {
        NSMutableDictionary *bad=[compatFast mutableCopy];bad[@"compatibility"]=value;
        Check(!STWPSanitizeSuperFast(bad),@"compatibility requires an actual boolean");
    }
    for(NSString *issue in @[@"context",@"restore",@"private-exception-with-url"]) {
        NSMutableDictionary *bad=[compatFast mutableCopy];bad[@"observerIssue"]=issue;
        Check(!STWPSanitizeSuperFast(bad),@"incompatible context or arbitrary exception never authorizes fallback");
    }
    Check([STWPAutoReason(@"super_fast_compatibility") isEqual:@"super_fast_compatibility"],@"normal compatibility state has a closed reason");

    NSMutableDictionary *phase=[@{@"version":@1,@"status":@"ready",@"reason":@"verified",@"revision":@2,@"scope":@1,@"complete":@YES,@"serverConfirmed":@NO,
        @"allRulesRecognized":@YES,@"counts":@{@"board":@3,@"tray":@2,@"reserve":@1,@"types":@2,@"dependencyEdges":@1,@"inventoryRows":@2,@"sharedSlots":@0,@"sharedCards":@0},
        @"cards":@[@"private"],@"secret":@"private"} mutableCopy];
    NSDictionary *safePhase=STWPSanitizePhaseSnapshotSummary(phase);
    Check(safePhase.count==9 && !safePhase[@"cards"] && !safePhase[@"secret"],@"phase summary is a closed projection");
    NSMutableDictionary *phaseRow=Result(@"watching",NO);phaseRow[@"phaseSnapshotSummary"]=phase;
    Check([STWPSanitizeAutoplay(phaseRow)[@"phaseSnapshotSummary"] isEqual:safePhase],@"summary crosses periodic result boundary");
    for(NSString *key in @[@"complete",@"serverConfirmed",@"allRulesRecognized"]) {
        NSMutableDictionary *bad=[phase mutableCopy];bad[key]=@1;
        Check(!STWPSanitizePhaseSnapshotSummary(bad),@"phase flags require actual booleans");
    }
    for(NSString *key in @[@"revision",@"scope"])for(id invalid in @[@YES,@(-1),@1.5,@(INFINITY),@"1"]) {
        NSMutableDictionary *bad=[phase mutableCopy];bad[key]=invalid;
        Check(!STWPSanitizePhaseSnapshotSummary(bad),@"phase counters reject nonintegers and boolean impostors");
    }
    NSMutableDictionary *badPhase=[phase mutableCopy];badPhase[@"serverConfirmed"]=@YES;
    Check(!STWPSanitizePhaseSnapshotSummary(badPhase),@"local census is never exported as a server acknowledgement");
    badPhase=[phase mutableCopy];badPhase[@"complete"]=@NO;
    Check(!STWPSanitizePhaseSnapshotSummary(badPhase),@"ready status cannot contradict completeness");
    badPhase=[phase mutableCopy];badPhase[@"counts"]=@{@"board":@513};
    Check(!STWPSanitizePhaseSnapshotSummary(badPhase),@"unbounded or incomplete count object rejected");
    NSMutableDictionary *waiting=[@{@"version":@1,@"status":@"waiting",@"reason":@"snapshot_stability",@"revision":@1,@"scope":@1,@"complete":@NO,@"serverConfirmed":@NO} mutableCopy];
    Check(STWPSanitizePhaseSnapshotSummary(waiting)!=nil,@"stability waiting is not a current full snapshot");
    waiting[@"counts"]=phase[@"counts"];
    Check(!STWPSanitizePhaseSnapshotSummary(waiting),@"stale counts cannot leak with waiting status");

    NSMutableDictionary *covered=[@{@"status":@"accepted",@"reason":@"server_200",@"pending":@NO,
        @"requestObserved":@YES,@"responseObserved":@YES,@"promiseSettled":@YES,@"effectObserved":@YES,
        @"attempts":@10000,@"serverCode":@200,@"cardID":@"private",@"packet_id":@17} mutableCopy];
    NSMutableDictionary *coveredRow=Result(@"watching",NO); coveredRow[@"covered"]=covered;
    NSDictionary *safeCovered=STWPSanitizeAutoplay(coveredRow)[@"covered"];
    Check([safeCovered[@"status"] isEqual:@"accepted"] && [safeCovered[@"serverCode"] isEqual:@200],@"bounded server result retained");
    Check(safeCovered.count==9 && !safeCovered[@"cardID"] && !safeCovered[@"packet_id"],@"no private card/packet data exported");
    for (NSString *key in @[@"pending",@"requestObserved",@"responseObserved",@"promiseSettled",@"effectObserved"])
        for (id invalid in @[@0,@1,@"true",NSNull.null]) {
            NSMutableDictionary *bad=[covered mutableCopy];bad[key]=invalid;
            Check(!STWPSanitizeCovered(bad),@"covered booleans reject numeric or text impostors");
        }
    for (NSString *key in @[@"attempts",@"serverCode"]) for (id invalid in @[@YES,@(-1),@1.5,@"200",@(INFINITY)]) {
        NSMutableDictionary *bad=[covered mutableCopy];bad[key]=invalid;
        Check(!STWPSanitizeCovered(bad),@"covered counters reject malformed values");
    }
    NSMutableDictionary *badCovered=[covered mutableCopy];badCovered[@"attempts"]=@10001;
    Check(!STWPSanitizeCovered(badCovered),@"covered attempt limit enforced");
    badCovered=[covered mutableCopy];badCovered[@"serverCode"]=@500;
    Check(!STWPSanitizeCovered(badCovered),@"accepted cannot contradict server refusal");
    badCovered=[covered mutableCopy];badCovered[@"responseObserved"]=@NO;
    Check(!STWPSanitizeCovered(badCovered),@"server code cannot exist without observed response");
    badCovered=[covered mutableCopy];badCovered[@"reason"]=@"private_text";
    Check([STWPSanitizeCovered(badCovered)[@"reason"] isEqual:@"unrecognized_reason"],@"unknown covered reason neutralized");
    badCovered=[covered mutableCopy];badCovered[@"status"]=@"private_status";
    Check(!STWPSanitizeCovered(badCovered),@"unknown covered status rejected");
    coveredRow[@"reason"]=@"covered_experiment";
    Check([STWPSanitizeAutoplay(coveredRow)[@"reason"] isEqual:@"covered_experiment"],@"explicit experiment diagnostic retained");
    NSMutableDictionary *modern=[covered mutableCopy];modern[@"kind"]=@"penetrate_zero";modern[@"responseOutcome"]=@"accepted";modern[@"phase"]=@"complete";
    NSDictionary *safeModern=STWPSanitizeCovered(modern);
    Check([safeModern[@"kind"] isEqual:@"penetrate_zero"] && [safeModern[@"responseOutcome"] isEqual:@"accepted"] && [safeModern[@"phase"] isEqual:@"complete"],@"new explicit protocol fields retained");
    Check(safeModern.count==12 && !safeModern[@"cardID"],@"new result remains a closed projection");
    for(NSString *key in @[@"kind",@"responseOutcome",@"phase"]) {
        NSMutableDictionary *bad=[modern mutableCopy];[bad removeObjectForKey:key];
        Check(!STWPSanitizeCovered(bad),@"partial new protocol rejected");
        bad=[modern mutableCopy];bad[key]=@"private_value";
        Check(!STWPSanitizeCovered(bad),@"unknown new enum rejected");
    }
    NSMutableDictionary *falseAgreement=[modern mutableCopy];falseAgreement[@"promiseSettled"]=@NO;
    Check(!STWPSanitizeCovered(falseAgreement),@"explicit accepted outcome requires original settlement");
    falseAgreement=[modern mutableCopy];falseAgreement[@"responseOutcome"]=@"rejected";
    Check(!STWPSanitizeCovered(falseAgreement),@"explicit outcome cannot contradict code 200");
    falseAgreement=[modern mutableCopy];falseAgreement[@"status"]=@"uncertain";falseAgreement[@"phase"]=@"blocked";
    Check([STWPSanitizeCovered(falseAgreement)[@"responseOutcome"] isEqual:@"accepted"],@"context uncertainty may preserve known response outcome");
    for(NSString *reason in @[@"recovery_timeout",@"penetrate_unavailable",@"penetrate_stock_not_zero",@"penetrate_id_unverified"]) {
        NSMutableDictionary *row=[modern mutableCopy];row[@"reason"]=reason;
        Check([STWPSanitizeCovered(row)[@"reason"] isEqual:reason],@"bounded new experiment reason retained");
    }
    NSDictionary *read=@{@"status":@"blocked",@"reason":@"animation_active",@"cardsRead":@215,@"cardTypesRead":@16,@"animationDetail":@"original_touch_pending",@"cardID":@"private",@"packet_id":@3};
    NSDictionary *safeRead=STWPSanitizeAutoplayReading(read);
    Check(safeRead.count==5 && [safeRead[@"animationDetail"] isEqual:@"original_touch_pending"] && !safeRead[@"cardID"],@"read-only last observation is closed and actionable");
    Check([STWPSanitizeAutoplayReading(@{})[@"reason"] isEqual:@"not_observed"],@"absent last observation is explicit");
    for (NSString *status in @[@"off", @"ready", @"unavailable", @"opening", @"submitted", @"uncertain", @"confirmed"]) {
        NSMutableDictionary *row = Result(@"watching", NO);
        row[@"powers"] = @{@"status":status,@"confirmed":@2,@"type":@1,@"privateID":@"drop"};
        NSDictionary *power = STWPSanitizeAutoplay(row)[@"powers"];
        Check([power[@"status"] isEqual:status] && [power[@"confirmed"] isEqual:@2], @"power telemetry retained");
        Check(!power[@"privateID"], @"no private stock ID exported");
    }
    for (id bad in @[@YES,@(-1),@1.5,@1000001,@"1"]) {
        NSMutableDictionary *row = Result(@"original_event_dispatched", YES);
        row[@"powers"] = @{@"status":@"submitted",@"confirmed":bad};
        NSDictionary *safe = STWPSanitizeAutoplay(row);
        Check(!safe[@"powers"] && [safe[@"dispatched"] boolValue], @"bad optional power data cannot erase a dispatch");
    }
    NSMutableDictionary *deep = Result(@"planning", NO);
    deep[@"planning"] = @{@"state":@"searching",@"nodes":@3,@"slices":@1,@"goal":@"multi_trio",@"lookaheadDepth":@12,@"lookaheadNodes":@12000};
    Check([STWPSanitizeAutoplay(deep)[@"planning"][@"goal"] isEqual:@"multi_trio"], @"multi-trio goal retained");
    Check([STWPSanitizeAutoplay(deep)[@"planning"][@"lookaheadDepth"] isEqual:@12], @"lookahead telemetry retained");
    NSDictionary *valid = STWPSanitizeAutoplay(Result(@"original_event_dispatched", YES));
    Check([valid[@"status"] isEqual:@"original_event_dispatched"] && [valid[@"dispatched"] boolValue], @"one original event retained");
    Check([valid[@"confirmedMoves"] isEqual:@3] && [valid[@"cardsRead"] isEqual:@217], @"bounded counters retained");
    Check(![valid[@"physicalPending"] boolValue], @"JS cannot claim a native physical pending lock");
    NSMutableDictionary *uncertain = Result(@"dispatch_uncertain", YES);
    uncertain[@"reason"] = @"event_exception";
    NSDictionary *safeUncertain = STWPSanitizeAutoplay(uncertain);
    Check([safeUncertain[@"dispatched"] boolValue] && [safeUncertain[@"awaitingBoardChange"] boolValue], @"throwing original callback remains an attempted pending move");
    Check([safeUncertain[@"reason"] isEqual:@"event_exception"], @"uncertain action reason retained");
    Check(Invalid(@[]), @"array rejected");
    Check(Invalid(NSNull.null), @"null rejected");
    for (id bad in @[@YES, @0, @2, @"1"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"version"] = bad;
        Check(Invalid(row), @"invalid or Boolean version rejected");
    }
    for (NSString *key in @[@"cardsRead", @"confirmedMoves"]) {
        for (id bad in @[@YES, @(-1), @1.5, @"3", @1000001]) {
            NSMutableDictionary *row = Result(@"watching", NO); row[key] = bad;
            Check(Invalid(row), @"invalid count rejected");
        }
    }
    for (NSString *missionStatus in @[@"identified", @"searching", @"priority", @"fallback", @"complete", @"unavailable"]) {
        NSMutableDictionary *row = Result(@"watching", NO);
        row[@"planning"] = @{@"state": @"proved", @"nodes": @12, @"slices": @2,
            @"mission": @{@"status": missionStatus, @"targetType": @2,
                @"current": [missionStatus isEqual:@"complete"] ? @9 : @3, @"total": @9, @"secret": @"drop"}};
        NSDictionary *mission = STWPSanitizeAutoplay(row)[@"planning"][@"mission"];
        Check([mission[@"status"] isEqual:missionStatus], @"mission status retained");
        Check(!mission[@"secret"], @"arbitrary mission text removed");
        if ([missionStatus isEqual:@"unavailable"]) Check(mission.count == 1, @"absent mission has no invented progress");
        else Check([mission[@"targetType"] isEqual:@2] && [mission[@"total"] isEqual:@9], @"bounded target/progress retained");
    }
    for (NSDictionary *mission in @[
        @{@"status": @"secret", @"targetType": @2, @"current": @0, @"total": @3},
        @{@"status": @"priority", @"targetType": @YES, @"current": @0, @"total": @3},
        @{@"status": @"priority", @"targetType": @0, @"current": @0, @"total": @3},
        @{@"status": @"priority", @"targetType": @10001, @"current": @0, @"total": @3},
        @{@"status": @"priority", @"targetType": @2, @"current": @4, @"total": @3},
        @{@"status": @"complete", @"targetType": @2, @"current": @0, @"total": @3},
        @{@"status": @"priority", @"targetType": @2, @"current": @3, @"total": @3},
        @{@"status": @"priority", @"targetType": @2, @"current": @0, @"total": @1000001},
        @{@"status": @"priority", @"targetType": @2, @"current": @0.5, @"total": @3}]) {
        NSMutableDictionary *row = Result(@"original_event_dispatched", YES);
        row[@"planning"] = @{@"state": @"proved", @"nodes": @12, @"slices": @2, @"mission": mission};
        NSDictionary *safe = STWPSanitizeAutoplay(row);
        Check(!safe[@"planning"][@"mission"], @"invalid optional mission discarded");
        Check([safe[@"dispatched"] boolValue], @"mission telemetry cannot erase a dispatched action");
    }
    NSMutableDictionary *tooMany = Result(@"watching", NO); tooMany[@"cardsRead"] = @4097;
    Check(Invalid(tooMany), @"card count boundary enforced");
    for (NSString *key in @[@"dispatched", @"awaitingBoardChange"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[key] = @1;
        Check(Invalid(row), @"numeric Boolean rejected");
    }
    Check(Invalid(Result(@"watching", YES)), @"dispatched move cannot masquerade as observation");
    Check(Invalid(Result(@"original_event_dispatched", NO)), @"dispatch success must include true flag");
    NSMutableDictionary *arbitrary = Result(@"watching", NO);
    NSMutableDictionary *reserveReading=Result(@"watching",NO);
    NSDictionary *reserveRow=@{@"type":@2,@"layer":@0,@"index":@1,@"x":@0,@"y":@0,@"masked":@NO,@"depth":@1,@"uid":@"private"};
    reserveReading[@"reserveXray"]=@{@"status":@"ready",@"cards":@1,@"verified":@1,@"geometricCovered":@1,@"masked":@0,@"omitted":@0,@"rows":@[reserveRow]};
    NSDictionary *safeReserve=STWPSanitizeAutoplay(reserveReading)[@"reserveXray"];
    Check(safeReserve!=nil && !safeReserve[@"rows"][0][@"uid"],@"reserve diagnostics preserve bounded geometry without identifiers");
    NSMutableDictionary *badReserve=[reserveReading[@"reserveXray"] mutableCopy];badReserve[@"verified"]=@2;
    reserveReading[@"reserveXray"]=badReserve;
    Check(!STWPSanitizeAutoplay(reserveReading)[@"reserveXray"],@"inconsistent reserve counts are discarded");
    arbitrary[@"reason"] = @"private_identifier"; arbitrary[@"secret"] = @"must_not_escape";
    NSDictionary *bounded = STWPSanitizeAutoplay(arbitrary);
    Check([bounded[@"reason"] isEqual:@"unrecognized_reason"] && !bounded[@"secret"], @"unknown reason and extra fields removed");
    for (NSString *reason in @[@"new_board_stability", @"new_board_detected", @"board_resync_stability", @"board_resynced", @"confirmation_uncertain"]) {
        NSMutableDictionary *row = Result(@"waiting_confirmation", NO); row[@"reason"] = reason;
        Check([STWPSanitizeAutoplay(row)[@"reason"] isEqual:reason], @"observed transition reason preserved");
    }
    for (NSString *detail in @[@"board_bounds", @"tray_mask_or_y", @"tray_spacing", @"external_card", @"warehouse_card_unsettled",
        @"original_touch_pending", @"board_metadata_position"]) {
        NSMutableDictionary *row = Result(@"blocked", NO);
        row[@"reason"] = @"animation_active"; row[@"animationDetail"] = detail;
        Check([STWPSanitizeAutoplay(row)[@"animationDetail"] isEqual:detail], @"bounded animation diagnosis retained");
        row[@"reason"] = @"plan_ready";
        Check(!STWPSanitizeAutoplay(row)[@"animationDetail"], @"animation diagnosis cannot attach to unrelated state");
    }
    NSMutableDictionary *untrustedDetail = Result(@"blocked", NO);
    untrustedDetail[@"reason"] = @"animation_active";
    untrustedDetail[@"animationDetail"] = @"private_card_name";
    Check(!STWPSanitizeAutoplay(untrustedDetail)[@"animationDetail"], @"arbitrary animation string omitted");
    // V3.2 pinpoints rule refusals without exporting card values or page text.
    for (NSString *detail in @[@"component", @"metadata_missing", @"metadata_id", @"metadata_type", @"metadata_state",
        @"metadata_layer", @"metadata_position", @"metadata_grid", @"metadata_special_type",
        @"metadata_special_lock", @"touch_flags", @"duplicate_id", @"control_state"]) {
        NSMutableDictionary *row = Result(@"blocked", NO);
        row[@"reason"] = @"unsupported_card_rules"; row[@"cardRuleDetail"] = detail;
        Check([STWPSanitizeAutoplay(row)[@"cardRuleDetail"] isEqual:detail], @"known rule refusal retained");
        row[@"reason"] = @"plan_ready";
        Check(!STWPSanitizeAutoplay(row)[@"cardRuleDetail"], @"rule detail cannot attach to an unrelated reason");
    }
    for (id detail in @[@"private-card-id", @YES, @1, NSNull.null, @[], @{}]) {
        NSMutableDictionary *row = Result(@"blocked", NO);
        row[@"reason"] = @"unsupported_card_rules"; row[@"cardRuleDetail"] = detail;
        Check(!STWPSanitizeAutoplay(row)[@"cardRuleDetail"], @"unknown rule data omitted");
    }
    NSMutableDictionary *visualOnly = Result(@"blocked", NO);
    visualOnly[@"reason"] = @"unsupported_card_rules"; visualOnly[@"cardRuleDetail"] = @"control_state";
    visualOnly[@"xray"] = @{@"status": @"ready", @"coveredIcons": @2, @"matchedBorders": @0};
    NSDictionary *safeVisualOnly = STWPSanitizeAutoplay(visualOnly);
    Check([safeVisualOnly[@"xray"][@"status"] isEqual:@"ready"] &&
        [safeVisualOnly[@"cardRuleDetail"] isEqual:@"control_state"] && ![safeVisualOnly[@"dispatched"] boolValue],
        @"validated visuals remain distinguishable from a blocked card action");
    for (id count in @[@0, @16, @512]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"cardTypesRead"] = count;
        Check([STWPSanitizeAutoplay(row)[@"cardTypesRead"] isEqual:count], @"card type diagnostic bounded integer retained");
    }
    for (id count in @[@YES, @(-1), @1.2, @513, @"16"]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"cardTypesRead"] = count;
        Check(Invalid(row), @"invalid card type count rejected");
    }
    NSMutableDictionary *inputUnavailable = Result(@"blocked", NO); inputUnavailable[@"reason"] = @"input_event_unavailable";
    Check([STWPSanitizeAutoplay(inputUnavailable)[@"reason"] isEqual:@"input_event_unavailable"], @"Cocos touch construction failure remains diagnosable");
    for (NSString *slot in @[@"left", @"center", @"right", @"current"]) {
        NSString *command = [slot isEqual:@"current"] ? @"confirm" : @"open";
        NSDictionary *power = @{@"version": @1, @"slot": slot, @"command": command,
            @"status": @"original_event_dispatched", @"reason": @"original_power_requested", @"dispatched": @YES,
            @"boardEffectConfirmed": @YES, @"secret": @"do not export"};
        NSDictionary *safe = STWPSanitizeReturnResult(power, slot, command);
        Check([safe[@"slot"] isEqual:slot] && [safe[@"command"] isEqual:command], @"power request identity retained");
        Check([safe[@"popupConfirmationRequired"] boolValue] == [command isEqual:@"open"], @"opening and consuming have distinct confirmation status");
        Check(![safe[@"boardEffectConfirmed"] boolValue] && !safe[@"secret"], @"callback dispatch cannot prove a board effect");
        Check([STWPSanitizeReturnResult(power, @"right", @"confirm")[@"status"] isEqual:@"dispatch_uncertain"], @"mismatched response cannot confirm another request");
    }
    Check(!STWPPowerOptions(@"current", @"open") && !STWPPowerOptions(@"arbitrary", @"confirm"), @"unknown power arguments rejected");
    for (NSString *reason in @[@"stock_empty", @"stock_unavailable", @"prop_mismatch", @"confirmation_unavailable", @"confirmation_ambiguous"]) {
        NSDictionary *power = @{@"version": @1, @"slot": @"current", @"command": @"confirm",
            @"status": @"no_action", @"reason": reason, @"dispatched": @NO};
        Check([STWPSanitizeReturnResult(power, @"current", @"confirm")[@"reason"] isEqual:reason], @"power stock and identity refusals remain diagnosable");
    }
    NSDictionary *boolVersion = @{@"version": @YES, @"slot": @"left", @"command": @"open", @"status": @"no_action", @"dispatched": @NO};
    Check([STWPSanitizeReturnResult(boolVersion, @"left", @"open")[@"status"] isEqual:@"dispatch_uncertain"], @"boolean power protocol version rejected");
    NSDictionary *pending = STWPAutoResult(@"dispatch_uncertain", @"evaluation_timeout", YES);
    Check([pending[@"physicalPending"] boolValue], @"native timeout helper keeps physical lock flag");

    // X-ray contributes bounded visual diagnostics, never card IDs, source or a native lock.
    for (NSString *status in @[@"off", @"ready", @"unavailable", @"blocked"]) {
        NSMutableDictionary *row = Result(@"watching", NO);
        row[@"xray"] = @{@"status": status, @"coveredIcons": @512, @"matchedBorders": @3,
            @"cardIDs": @[@"private-card"], @"source": @"private-source", @"physicalPending": @YES};
        row[@"physicalPending"] = @YES;
        NSDictionary *safe = STWPSanitizeAutoplay(row), *xray = safe[@"xray"];
        Check([xray[@"status"] isEqual:status] && [xray[@"coveredIcons"] isEqual:@512] &&
            [xray[@"matchedBorders"] isEqual:@3], @"bounded x-ray state retained at maximum counts");
        Check(xray.count == 3 && !xray[@"cardIDs"] && !xray[@"source"] && !xray[@"physicalPending"],
            @"private and extra x-ray fields never cross the result boundary");
        Check(![safe[@"physicalPending"] boolValue], @"x-ray and page cannot claim native physical pending");
    }
    NSMutableDictionary *zeroXray = Result(@"watching", NO);
    zeroXray[@"xray"] = @{@"status": @"off", @"coveredIcons": @0, @"matchedBorders": @0};
    Check([STWPSanitizeAutoplay(zeroXray)[@"xray"] isEqual:zeroXray[@"xray"]], @"zero x-ray counts retained");
    for (NSString *key in @[@"coveredIcons", @"matchedBorders"]) {
        NSNumber *overflow = [key isEqual:@"coveredIcons"] ? @513 : @4;
        for (id bad in @[@YES, @(-1), @0.5, @"1", NSNull.null, overflow, @(NAN), @(INFINITY)]) {
            NSMutableDictionary *row = Result(@"watching", NO);
            NSMutableDictionary *xray = [@{@"status": @"ready", @"coveredIcons": @4, @"matchedBorders": @3} mutableCopy];
            xray[key] = bad; row[@"xray"] = xray;
            NSDictionary *safe = STWPSanitizeAutoplay(row);
            Check(!safe[@"xray"] && [safe[@"status"] isEqual:@"watching"], @"invalid optional x-ray count omitted without inventing action uncertainty");
        }
        NSMutableDictionary *row = Result(@"watching", NO);
        NSMutableDictionary *xray = [@{@"status": @"ready", @"coveredIcons": @4, @"matchedBorders": @3} mutableCopy];
        [xray removeObjectForKey:key]; row[@"xray"] = xray;
        Check(!STWPSanitizeAutoplay(row)[@"xray"], @"missing x-ray count omits the optional object");
    }
    for (id badStatus in @[@"private-status", @YES, @1, NSNull.null]) {
        NSMutableDictionary *row = Result(@"watching", NO);
        row[@"xray"] = @{@"status": badStatus, @"coveredIcons": @2, @"matchedBorders": @3};
        NSDictionary *safe = STWPSanitizeAutoplay(row);
        Check(!safe[@"xray"] && [safe[@"status"] isEqual:@"watching"], @"unknown or non-string x-ray status omitted");
    }
    for (id badXray in @[@[], @"ready", @YES, NSNull.null, @{}]) {
        NSMutableDictionary *row = Result(@"watching", NO); row[@"xray"] = badXray;
        Check(!STWPSanitizeAutoplay(row)[@"xray"], @"malformed optional x-ray object omitted");
    }
    Check(!STWPSanitizeAutoplay(Result(@"watching", NO))[@"xray"], @"absent x-ray remains absent");

    // V3.1: depth preferences and incremental planning are bounded diagnostics.
    // They must never turn an observation into a dispatched move.
    NSMutableDictionary *layered = Result(@"planning", NO);
    layered[@"reason"] = @"search_in_progress";
    layered[@"xray"] = @{@"status": @"ready", @"coveredIcons": @12, @"matchedBorders": @0,
        @"depthLimit": @4, @"hiddenByDepth": @300, @"hiddenByLayout": @4, @"labelMode": @"cocos_label",
        @"cards": @[@"private-card"]};
    layered[@"planning"] = @{@"state": @"searching", @"nodes": @1000000, @"slices": @1000000,
        @"goal": @"all_observed_triples", @"residualCards": @2, @"solution": @[@"private-card"], @"dispatched": @YES};
    NSDictionary *layeredSafe = STWPSanitizeAutoplay(layered);
    Check([layeredSafe[@"status"] isEqual:@"planning"] && [layeredSafe[@"reason"] isEqual:@"search_in_progress"] &&
        ![layeredSafe[@"dispatched"] boolValue], @"incremental search is an observation, never a move");
    Check([layeredSafe[@"xray"][@"depthLimit"] isEqual:@4] && [layeredSafe[@"xray"][@"hiddenByDepth"] isEqual:@300] &&
        [layeredSafe[@"xray"][@"hiddenByLayout"] isEqual:@4] && !layeredSafe[@"xray"][@"cards"], @"bounded layer statistics retained without card identifiers");
    Check([layeredSafe[@"planning"][@"goal"] isEqual:@"all_observed_triples"] &&
        [layeredSafe[@"planning"][@"residualCards"] isEqual:@2] && !layeredSafe[@"planning"][@"solution"] &&
        !layeredSafe[@"planning"][@"dispatched"], @"local planning goal retained without source, route or dispatch claims");
    Check(Invalid(Result(@"planning", YES)), @"search cannot claim a dispatched card");
    NSMutableDictionary *localPlan = [layered mutableCopy];
    localPlan[@"planning"] = @{@"state": @"proved", @"nodes": @18, @"slices": @1, @"goal": @"next_trio", @"residualCards": @255,
        @"route": @[@"private-card"], @"globalVictoryGuaranteed": @YES};
    NSDictionary *localSafe = STWPSanitizeAutoplay(localPlan);
    Check([localSafe[@"planning"][@"goal"] isEqual:@"next_trio"] &&
        !localSafe[@"planning"][@"route"] && !localSafe[@"planning"][@"globalVictoryGuaranteed"] &&
        ![localSafe[@"dispatched"] boolValue], @"local trio proof retained without claiming full-game solution or dispatch");
    for (id bad in @[@0, @5, @6, @YES, @1.5, @"2", NSNull.null]) {
        NSMutableDictionary *row = [layered mutableCopy], *visual = [layered[@"xray"] mutableCopy];
        visual[@"depthLimit"] = bad; row[@"xray"] = visual;
        Check(!STWPSanitizeAutoplay(row)[@"xray"][@"depthLimit"], @"depth accepts only integers one through four");
    }
    for (NSString *key in @[@"hiddenByDepth", @"hiddenByLayout"]) {
        NSMutableDictionary *row = [layered mutableCopy], *visual = [layered[@"xray"] mutableCopy];
        visual[key] = @513; row[@"xray"] = visual;
        Check(!STWPSanitizeAutoplay(row)[@"xray"][key], @"hidden icon counts are capped at the board limit");
    }
    for (NSString *mode in @[@"cocos_label", @"vector_digits", @"none"]) {
        NSMutableDictionary *row = [layered mutableCopy], *visual = [layered[@"xray"] mutableCopy];
        visual[@"labelMode"] = mode; row[@"xray"] = visual;
        Check([STWPSanitizeAutoplay(row)[@"xray"][@"labelMode"] isEqual:mode], @"known label rendering modes retained");
    }
    for (NSString *state in @[@"searching", @"proved", @"blocked"]) {
        NSMutableDictionary *row = [layered mutableCopy], *progress = [layered[@"planning"] mutableCopy];
        progress[@"state"] = state; row[@"planning"] = progress;
        Check([STWPSanitizeAutoplay(row)[@"planning"][@"state"] isEqual:state], @"closed planning states retained");
    }
    for (NSString *key in @[@"nodes", @"slices"]) for (id bad in @[@YES, @(-1), @0.5, @1000001, @"1", NSNull.null]) {
        NSMutableDictionary *row = [layered mutableCopy], *progress = [layered[@"planning"] mutableCopy];
        progress[key] = bad; row[@"planning"] = progress;
        NSDictionary *safe = STWPSanitizeAutoplay(row);
        Check(!safe[@"planning"] && [safe[@"status"] isEqual:@"planning"], @"invalid optional search statistics do not invent dispatch uncertainty");
    }
    for (NSString *reason in @[@"observed_state_unbalanced", @"observed_state_locked", @"no_complete_solution",
        @"search_limit_reached", @"unsupported_card_rules", @"external_mode_active", @"board_clear", @"no_remaining_triples"]) {
        NSMutableDictionary *row = Result(@"blocked", NO); row[@"reason"] = reason;
        Check([STWPSanitizeAutoplay(row)[@"reason"] isEqual:reason], @"bounded planner outcome remains diagnosable");
    }

    // Own-warehouse dispatch reports only an original callback request. It cannot
    // prove a selector opened, authorize another owner or assert native pending.
    NSMutableDictionary *warehouse = WarehouseResult(@"original_event_dispatched", @YES);
    warehouse[@"effectConfirmed"] = @YES; warehouse[@"boardEffectConfirmed"] = @YES;
    warehouse[@"physicalPending"] = @YES; warehouse[@"ownerOnly"] = @NO; warehouse[@"serverManaged"] = @NO;
    warehouse[@"ownerID"] = @"private-owner"; warehouse[@"secret"] = @"private-value";
    warehouse[@"stats"] = @{@"path": @"private-local-path"};
    NSDictionary *safeWarehouse = STWPSanitizeWarehouse(warehouse);
    Check([safeWarehouse[@"status"] isEqual:@"original_event_dispatched"] &&
        safeWarehouse[@"dispatched"] == (__bridge id)kCFBooleanTrue, @"original warehouse request retained");
    Check(![safeWarehouse[@"effectConfirmed"] boolValue] && !safeWarehouse[@"boardEffectConfirmed"],
        @"warehouse callback cannot claim selector or board effect confirmation");
    Check([safeWarehouse[@"ownerOnly"] boolValue] && [safeWarehouse[@"serverManaged"] boolValue] &&
        ![safeWarehouse[@"physicalPending"] boolValue], @"warehouse result retains ownership and server policy and cannot forge native pending");
    Check(!safeWarehouse[@"ownerID"] && !safeWarehouse[@"secret"] && !safeWarehouse[@"stats"] && safeWarehouse.count == 9,
        @"warehouse extra fields and identifiers dropped");
    for (NSString *reason in @[@"own_slot_locked", @"own_slot_occupied", @"owner_unknown", @"owner_ambiguous",
        @"selection_already_open", @"store_unavailable", @"slot_state_unavailable", @"slot_state_changed", @"disabled_control", @"modal_visible"]) {
        NSMutableDictionary *row = WarehouseResult(@"no_action", @NO); row[@"reason"] = reason;
        NSDictionary *safe = STWPSanitizeWarehouse(row);
        Check([safe[@"status"] isEqual:@"no_action"] && [safe[@"reason"] isEqual:reason] &&
            safe[@"dispatched"] == (__bridge id)kCFBooleanFalse, @"own-slot refusal reason retained without claiming a dispatch");
    }
    NSMutableDictionary *unknownWarehouse = WarehouseResult(@"no_action", @NO);
    unknownWarehouse[@"reason"] = @"private-player-name";
    Check([STWPSanitizeWarehouse(unknownWarehouse)[@"reason"] isEqual:@"warehouse_unavailable"],
        @"unknown warehouse reason replaced with bounded diagnostic");
    for (id bad in @[@[], NSNull.null, @"open"]) Check(InvalidWarehouse(bad), @"non-object warehouse result rejected");
    for (id bad in @[@YES, @0, @2, @0.5, @"1", NSNull.null]) {
        NSMutableDictionary *row = WarehouseResult(@"no_action", @NO); row[@"version"] = bad;
        Check(InvalidWarehouse(row), @"invalid or boolean warehouse protocol rejected");
    }
    NSMutableDictionary *missingVersion = WarehouseResult(@"no_action", @NO); [missingVersion removeObjectForKey:@"version"];
    Check(InvalidWarehouse(missingVersion), @"missing warehouse protocol rejected");
    for (id bad in @[@"close", @"all", @"", @YES, NSNull.null]) {
        NSMutableDictionary *row = WarehouseResult(@"no_action", @NO); row[@"command"] = bad;
        Check(InvalidWarehouse(row), @"unknown or non-string warehouse command rejected");
    }
    NSMutableDictionary *missingCommand = WarehouseResult(@"no_action", @NO); [missingCommand removeObjectForKey:@"command"];
    Check(InvalidWarehouse(missingCommand), @"missing warehouse command rejected");
    for (NSString *status in @[@"no_action", @"original_event_dispatched"]) {
        for (id bad in @[@0, @1, @"true", @"false", NSNull.null]) {
            Check(InvalidWarehouse(WarehouseResult(status, bad)), @"numeric or malformed warehouse boolean rejected");
        }
    }
    Check(InvalidWarehouse(WarehouseResult(@"no_action", @YES)), @"warehouse no-action cannot carry dispatched true");
    Check(InvalidWarehouse(WarehouseResult(@"original_event_dispatched", @NO)), @"warehouse dispatched status cannot carry false");
    Check(InvalidWarehouse(WarehouseResult(@"watching", @NO)), @"unrecognized warehouse status rejected");
    NSMutableDictionary *uncertainWarehouse = WarehouseResult(@"dispatch_uncertain", @YES);
    uncertainWarehouse[@"effectConfirmed"] = @YES; uncertainWarehouse[@"physicalPending"] = @YES;
    NSDictionary *safeWarehouseUncertain = STWPSanitizeWarehouse(uncertainWarehouse);
    Check([safeWarehouseUncertain[@"status"] isEqual:@"dispatch_uncertain"] &&
        safeWarehouseUncertain[@"dispatched"] == NSNull.null && ![safeWarehouseUncertain[@"effectConfirmed"] boolValue] &&
        ![safeWarehouseUncertain[@"physicalPending"] boolValue], @"uncertain warehouse result does not infer a dispatch, effect or native lock");
    NSDictionary *nativeWarehousePending = STWPWarehouseResult(@"dispatch_uncertain", @"evaluation_timeout", NSNull.null, YES);
    Check([nativeWarehousePending[@"physicalPending"] boolValue] && ![nativeWarehousePending[@"effectConfirmed"] boolValue],
        @"only native warehouse timeout helper may retain physical pending");
    NSMutableDictionary *stock=StockResult();stock[@"uid"]=@"private";stock[@"packet_id"]=@41;stock[@"physicalPending"]=@YES;
    NSDictionary *stockSafe=STWPSanitizeStockTest(stock);
    Check([stockSafe[@"status"] isEqual:@"accepted"] && [stockSafe[@"serverCode"] isEqual:@200],@"original protocol 200 retained");
    Check(![stockSafe[@"slotEffectConfirmed"] boolValue],@"200 alone is not a confirmed slot change");
    Check(!stockSafe[@"uid"] && !stockSafe[@"packet_id"] && ![stockSafe[@"physicalPending"] boolValue],@"no page identifiers or native lock claims escape");
    stock=StockResult();stock[@"slotEffectConfirmed"]=@YES;
    Check([STWPSanitizeStockTest(stock)[@"slotEffectConfirmed"] boolValue],@"coherent observed slot effect may be reported");
    for (NSString *key in @[@"active",@"localWriteApplied",@"localRestored",@"hooksRestored",@"requestObserved",@"responseObserved",@"slotEffectConfirmed",@"testedWhileLocked"]) {
        stock=StockResult();stock[key]=@1;
        Check([STWPSanitizeStockTest(stock)[@"status"] isEqual:@"uncertain"],@"numeric boolean in stock result rejected");
    }
    for (NSString *key in @[@"version",@"attemptCount",@"serverCode"]) {
        for (id bad in @[@YES,@(-1),@1.5,@"200"]) {
            stock=StockResult();stock[key]=bad;
            Check([STWPSanitizeStockTest(stock)[@"status"] isEqual:@"uncertain"],@"malformed stock counter/code rejected");
        }
    }
    for (NSString *key in @[@"beforeLock",@"afterLock"]) {
        stock=StockResult();stock[key]=@999;
        Check(!STWPSanitizeStockTest(stock)[key],@"unbounded stock detail discarded");
    }
    for (NSString *key in @[@"requestObserved",@"responseObserved",@"testedWhileLocked"]) {
        stock=StockResult();stock[key]=@NO;
        Check([STWPSanitizeStockTest(stock)[@"status"] isEqual:@"uncertain"],@"incoherent acceptance rejected");
    }
    stock=StockResult();stock[@"serverCode"]=@403;
    Check([STWPSanitizeStockTest(stock)[@"status"] isEqual:@"uncertain"],@"403 cannot be labeled accepted");
    stock[@"status"]=@"rejected";stock[@"reason"]=@"server_rejected";
    Check([STWPSanitizeStockTest(stock)[@"status"] isEqual:@"rejected"],@"real rejection retained");
    stock[@"slotEffectConfirmed"]=@YES;
    Check([STWPSanitizeStockTest(stock)[@"status"] isEqual:@"uncertain"],@"rejection cannot assert slot success");
    stock=StockResult();stock[@"reason"]=@"private error body";
    Check([STWPSanitizeStockTest(stock)[@"reason"] isEqual:@"unrecognized_reason"],@"server text never exported as stock reason");
    Check([STWPStockResult(@"uncertain",@"evaluation_timeout",YES)[@"physicalPending"] boolValue],@"only native helper can retain physical lock");
    printf("Autoplay bridge: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

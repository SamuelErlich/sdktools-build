// Compile on macOS with Foundation and CoreFoundation. This imports the exact
// private sanitizer shared with the production probe, without iOS WebKit code.
#import "../Sources/SDKtools/STWebProbeSanitizer.inc"
#include <stdio.h>

static NSUInteger failures = 0;
static void Check(BOOL condition, NSString *message) {
    if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSDictionary *Event(void) {
    return @{@"targetNodeID": @"n7", @"targetValid": @YES,
        @"component": @"Game.ReturnControl", @"handler": @"onReturn",
        @"customData": @{@"present": @YES, @"type": @"string", @"length": @6},
        @"handlerResolved": @YES, @"handlerArity": @2};
}
static NSDictionary *Control(void) {
    return @{@"geometryHint": @"props_item_geometry", @"semanticHint": @"return_visual_candidate",
        @"componentTypes": @[@"cc.Button", @"Game.ReturnControl"],
        @"button": @{@"enabled": @NO, @"enabledInHierarchy": NSNull.null, @"interactable": @YES,
            @"eventCount": @1, @"events": @[Event()]}};
}
static NSMutableDictionary *Probe(NSArray *nodes) {
    return [@{@"version": @2, @"status": @"cocos2_scene_captured", @"sceneNodes": nodes,
        @"cocos": @{@"truncated": @NO},
        @"controlTrace": @{@"enabled": @YES, @"observedButtonCount": @1,
            @"candidateCount": @1, @"inspectedNodes": @(nodes.count),
            @"metadataNodeCount": @(nodes.count), @"truncated": @NO,
            @"truncationReasons": @[], @"limits": @{@"maxControls": @999999}}} mutableCopy];
}
static NSDictionary *Node(NSString *identifier, NSDictionary *control) {
    return @{@"nodeID": identifier, @"isSceneRoot": @NO, @"control": control,
        @"prioritizationHint": @"control_geometry"};
}
static NSDictionary *FirstControl(NSDictionary *result) { return result[@"sceneNodes"][0][@"control"]; }

int main(void) {
    @autoreleasepool {
        NSMutableDictionary *input = Probe(@[Node(@"n1", Control())]);
        NSDictionary *result = STWPSanitize(input, YES);
        NSDictionary *control = FirstControl(result), *button = control[@"button"];
        Check([control[@"semanticHint"] isEqual:@"return_visual_candidate"], @"valid visual hint survives");
        Check([result[@"sceneNodes"][0][@"prioritizationHint"] isEqual:@"control_geometry"], @"control traversal hint survives");
        Check([button[@"enabled"] isEqual:@NO], @"false is not dropped");
        Check(button[@"enabledInHierarchy"] == NSNull.null, @"unknown bool remains null");
        Check([button[@"events"][0][@"handler"] isEqual:@"onReturn"], @"valid handler identifier survives");
        Check([result[@"controlTrace"][@"limits"][@"maxControls"] isEqual:@64], @"native bounds override page claims");
        Check([result[@"controlTrace"][@"actionInvoked"] isEqual:@NO], @"metadata cannot claim execution");
        NSDictionary *disabled = STWPSanitize(input, NO);
        Check(disabled[@"controlTrace"] == nil && FirstControl(disabled) == nil, @"native opt-in is mandatory");
        input[@"controlTrace"] = @{@"enabled": @2};
        Check(STWPSanitize(input, YES)[@"controlTrace"] == nil, @"numeric enabled is not boolean consent");

        NSMutableDictionary *badEvent = [Event() mutableCopy];
        badEvent[@"handler"] = @"secret-token/untrusted";
        badEvent[@"component"] = @"Class with spaces";
        badEvent[@"targetNodeID"] = @"n1\nTOKEN";
        badEvent[@"targetValid"] = @2;
        badEvent[@"handlerResolved"] = @"true";
        badEvent[@"handlerArity"] = @129;
        badEvent[@"customEventData"] = @"DO_NOT_EXPORT_SECRET";
        badEvent[@"customData"] = @{@"present": @YES, @"type": @"string", @"length": @(-1), @"value": @"DO_NOT_EXPORT_SECRET"};
        NSMutableDictionary *badControl = [Control() mutableCopy];
        badControl[@"componentTypes"] = @[@"cc.Button", @"Class with spaces", @"secret-token/untrusted", @7];
        badControl[@"button"] = @{@"enabled": @2, @"enabledInHierarchy": @"false", @"interactable": NSNull.null,
            @"eventCount": @1.5, @"events": @[badEvent], @"token": @"DO_NOT_EXPORT_SECRET"};
        badControl[@"stock"] = @999;
        result = STWPSanitize(Probe(@[Node(@"n1", badControl)]), YES);
        button = FirstControl(result)[@"button"];
        NSDictionary *event = button[@"events"][0];
        Check([FirstControl(result)[@"componentTypes"] isEqual:@[@"cc.Button"]], @"unsafe component identifiers are removed");
        for (NSString *key in @[@"handler", @"component", @"targetNodeID", @"targetValid", @"handlerResolved", @"handlerArity"])
            Check(event[key] == NSNull.null, [@"malformed event field becomes null: " stringByAppendingString:key]);
        Check(button[@"enabled"] == NSNull.null && button[@"eventCount"] == NSNull.null, @"malformed button scalars become null");
        Check(event[@"customData"][@"length"] == NSNull.null, @"negative custom data length rejected");
        NSString *serialized = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:result options:0 error:nil] encoding:NSUTF8StringEncoding];
        Check(![serialized containsString:@"DO_NOT_EXPORT_SECRET"] && ![serialized containsString:@"secret-token"], @"raw custom data and unsafe values never exported");
        Check(FirstControl(result)[@"stock"] == nil && event[@"customEventData"] == nil, @"unknown fields discarded");
        Check(STWPControlIdentifier(@"onReturn\n") == NSNull.null && STWPControlIdentifier(@"onReturn\r\n") == NSNull.null,
            @"trailing newlines cannot bypass anchored identifier regex");

        NSMutableArray *largeEvents = [NSMutableArray array], *largeComponents = [NSMutableArray array], *largeNodes = [NSMutableArray array];
        for (NSUInteger index = 0; index < 12; index++) { [largeEvents addObject:Event()]; [largeComponents addObject:[NSString stringWithFormat:@"Component%lu", (unsigned long)index]]; }
        NSDictionary *largeControl = @{@"componentTypes": largeComponents, @"button": @{@"events": largeEvents}};
        for (NSUInteger index = 0; index < 70; index++) [largeNodes addObject:Node([NSString stringWithFormat:@"n%lu", (unsigned long)(index + 1)], largeControl)];
        result = STWPSanitize(Probe(largeNodes), YES);
        Check([result[@"controlTrace"][@"metadataNodeCount"] isEqual:@64], @"64 control cap");
        Check(result[@"sceneNodes"][64][@"control"] == nil, @"excess control dropped without dropping scene node");
        Check([FirstControl(result)[@"componentTypes"] count] == 8 && [FirstControl(result)[@"button"][@"events"] count] == 8, @"per-control arrays bounded");
        for (NSString *reason in @[@"control_limit", @"event_limit", @"component_limit"])
            Check([result[@"controlTrace"][@"truncationReasons"] containsObject:reason], [@"native truncation explicit: " stringByAppendingString:reason]);
        Check([result[@"controlTrace"][@"truncated"] isEqual:@YES], @"native truncation cannot be hidden by page");

        input = Probe(@[Node(@"n1", Control())]);
        input[@"cocos"] = @{@"truncated": @YES};
        result = STWPSanitize(input, YES);
        Check([result[@"controlTrace"][@"truncationReasons"] containsObject:@"scene_incomplete"], @"partial scene prevents complete trace claim");
        Check([STWPSanitize(@[], YES)[@"status"] isEqual:@"invalid_probe_result"], @"non-object probe rejected");
        if (failures) return 1;
        printf("Web probe sanitizer checks passed.\n");
    }
    return 0;
}

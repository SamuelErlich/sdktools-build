// Compile on macOS with Foundation and CoreFoundation. This imports the exact
// private sanitizer shared with the production probe, without iOS WebKit code.
#import "../Sources/SDKtools/STWebProbeSanitizer.inc"
#include <stdio.h>

static NSUInteger failures = 0;
static void Check(BOOL condition, NSString *message) {
    if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSDictionary *Event(void) {
    return @{@"targetNodeID": @"n7", @"targetValid": @YES,
        @"component": @"Game.ReturnControl", @"handler": @"onReturn",
        @"resolvedComponent": @"Game.ReturnControl", @"resolution": @"configured_component",
        @"customData": @{@"present": @YES, @"type": @"string", @"length": @6},
        @"handlerResolved": @YES, @"handlerArity": @2};
}
static NSDictionary *Control(void) {
    return @{@"geometryHint": @"props_item_geometry", @"semanticHint": @"return_visual_candidate",
        @"componentTypes": @[@"cc.Button", @"Game.ReturnControl"],
        @"button": @{@"enabled": @NO, @"enabledInHierarchy": NSNull.null, @"interactable": @YES,
            @"eventCount": @1, @"events": @[Event()]}};
}
static NSMutableDictionary *Probe(NSArray *nodes) {
    return [@{@"version": @2, @"status": @"cocos2_scene_captured", @"sceneNodes": nodes,
        @"cocos": @{@"truncated": @NO},
        @"controlTrace": @{@"enabled": @YES, @"observedButtonCount": @1,
            @"scope": @"non_board_ui_controls", @"skippedBoardButtonCount": @130,
            @"candidateCount": @1, @"inspectedNodes": @(nodes.count),
            @"metadataNodeCount": @(nodes.count), @"truncated": @NO,
            @"truncationReasons": @[], @"limits": @{@"maxControls": @999999}}} mutableCopy];
}
static NSDictionary *Node(NSString *identifier, NSDictionary *control) {
    return @{@"nodeID": identifier, @"isSceneRoot": @NO, @"control": control,
        @"prioritizationHint": @"control_geometry"};
}
static NSDictionary *FirstControl(NSDictionary *result) { return result[@"sceneNodes"][0][@"control"]; }
static NSMutableDictionary *Inspection(void) {
    return [@{@"version": @1, @"role": @"return_prop", @"component": @"Prop",
        @"stockBadge": @{@"status": @"numeric", @"value": @3},
        @"fields": @[@{@"name": @"remainingCount", @"value": @3}, @{@"name": @"propUsed", @"value": @NO}],
        @"methods": @[@{@"name": @"onUseProp", @"source": @"function onUseProp(){ return this.remainingCount; }", @"sourceTruncated": @NO}],
        @"truncated": @NO, @"reasons": @[]} mutableCopy];
}
static NSMutableDictionary *ControlWithInspection(id inspection) {
    NSMutableDictionary *control = [Control() mutableCopy];
    control[@"returnInspection"] = inspection;
    return control;
}
static NSMutableDictionary *InspectionProbe(NSArray *nodes) {
    NSMutableDictionary *probe = Probe(nodes);
    probe[@"cocos"] = @{@"version": @"2.4.4", @"truncated": @NO};
    return probe;
}
static NSDictionary *SanitizedInspection(id inspection) {
    return FirstControl(STWPSanitize(InspectionProbe(@[Node(@"n1", ControlWithInspection(inspection))]), YES))[@"returnInspection"];
}
static NSUInteger SourceCharacters(NSDictionary *inspection) {
    NSUInteger count = 0;
    for (NSDictionary *method in inspection[@"methods"]) count += [method[@"source"] length];
    return count;
}

int main(void) {
    @autoreleasepool {
        NSMutableDictionary *input = Probe(@[Node(@"n1", Control())]);
        NSDictionary *result = STWPSanitize(input, YES);
        NSDictionary *control = FirstControl(result), *button = control[@"button"];
        Check([control[@"semanticHint"] isEqual:@"return_visual_candidate"], @"valid visual hint survives");
        Check([result[@"sceneNodes"][0][@"prioritizationHint"] isEqual:@"control_geometry"], @"control traversal hint survives");
        Check([button[@"enabled"] isEqual:@NO], @"false is not dropped");
        Check(button[@"enabledInHierarchy"] == NSNull.null, @"unknown bool remains null");
        Check([button[@"events"][0][@"handler"] isEqual:@"onReturn"], @"valid handler identifier survives");
        Check([button[@"events"][0][@"resolvedComponent"] isEqual:@"Game.ReturnControl"], @"resolved component identifier survives");
        Check([button[@"events"][0][@"resolution"] isEqual:@"configured_component"], @"resolution source survives");
        Check([result[@"controlTrace"][@"scope"] isEqual:@"non_board_ui_controls"], @"UI-only trace scope is explicit");
        Check([result[@"controlTrace"][@"skippedBoardButtonCount"] isEqual:@130], @"omitted board metadata count survives");
        Check([result[@"controlTrace"][@"limits"][@"maxControls"] isEqual:@64], @"native bounds override page claims");
        Check([result[@"controlTrace"][@"actionInvoked"] isEqual:@NO], @"metadata cannot claim execution");
        NSDictionary *disabled = STWPSanitize(input, NO);
        Check(disabled[@"controlTrace"] == nil && FirstControl(disabled) == nil, @"native opt-in is mandatory");
        input[@"controlTrace"] = @{@"enabled": @2};
        Check(STWPSanitize(input, YES)[@"controlTrace"] == nil, @"numeric enabled is not boolean consent");

        NSMutableDictionary *badEvent = [Event() mutableCopy];
        badEvent[@"handler"] = @"secret-token/untrusted";
        badEvent[@"component"] = @"Class with spaces";
        badEvent[@"resolvedComponent"] = @"secret-token/private";
        badEvent[@"resolution"] = @"PRIVATE_UNSUPPORTED_RESOLUTION";
        badEvent[@"targetNodeID"] = @"n1\nTOKEN";
        badEvent[@"targetValid"] = @2;
        badEvent[@"handlerResolved"] = @"true";
        badEvent[@"handlerArity"] = @129;
        badEvent[@"customEventData"] = @"DO_NOT_EXPORT_SECRET";
        badEvent[@"customData"] = @{@"present": @YES, @"type": @"string", @"length": @(-1), @"value": @"DO_NOT_EXPORT_SECRET"};
        NSMutableDictionary *badControl = [Control() mutableCopy];
        badControl[@"componentTypes"] = @[@"cc.Button", @"Class with spaces", @"secret-token/untrusted", @7];
        badControl[@"button"] = @{@"enabled": @2, @"enabledInHierarchy": @"false", @"interactable": NSNull.null,
            @"eventCount": @1.5, @"events": @[badEvent], @"token": @"DO_NOT_EXPORT_SECRET"};
        badControl[@"stock"] = @999;
        result = STWPSanitize(Probe(@[Node(@"n1", badControl)]), YES);
        button = FirstControl(result)[@"button"];
        NSDictionary *event = button[@"events"][0];
        Check([FirstControl(result)[@"componentTypes"] isEqual:@[@"cc.Button"]], @"unsafe component identifiers are removed");
        for (NSString *key in @[@"handler", @"component", @"resolvedComponent", @"targetNodeID", @"targetValid", @"handlerResolved", @"handlerArity"])
            Check(event[key] == NSNull.null, [@"malformed event field becomes null: " stringByAppendingString:key]);
        Check([event[@"resolution"] isEqual:@"unresolved"], @"unknown resolution falls back to unresolved");
        Check(button[@"enabled"] == NSNull.null && button[@"eventCount"] == NSNull.null, @"malformed button scalars become null");
        Check(event[@"customData"][@"length"] == NSNull.null, @"negative custom data length rejected");
        NSString *serialized = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:result options:0 error:nil] encoding:NSUTF8StringEncoding];
        Check(![serialized containsString:@"DO_NOT_EXPORT_SECRET"] && ![serialized containsString:@"secret-token"], @"raw custom data and unsafe values never exported");
        Check(FirstControl(result)[@"stock"] == nil && event[@"customEventData"] == nil, @"unknown fields discarded");
        Check(STWPControlIdentifier(@"onReturn\n") == NSNull.null && STWPControlIdentifier(@"onReturn\r\n") == NSNull.null,
            @"trailing newlines cannot bypass anchored identifier regex");

        for (NSString *resolution in @[@"unique_target_method", @"ambiguous", @"unresolved"]) {
            NSMutableDictionary *resolvedEvent = [Event() mutableCopy];
            resolvedEvent[@"resolution"] = resolution;
            NSDictionary *resolvedControl = @{@"button": @{@"events": @[resolvedEvent]}};
            NSDictionary *resolved = FirstControl(STWPSanitize(Probe(@[Node(@"n1", resolvedControl)]), YES))[@"button"][@"events"][0];
            Check([resolved[@"resolution"] isEqual:resolution], @"all bounded resolution enums survive");
        }
        input = Probe(@[Node(@"n1", Control())]);
        input[@"controlTrace"] = @{@"enabled": @YES, @"scope": @"all_controls_complete", @"skippedBoardButtonCount": @1537};
        result = STWPSanitize(input, YES);
        Check([result[@"controlTrace"][@"scope"] isEqual:@"unknown"], @"unknown scope cannot claim global coverage");
        Check(result[@"controlTrace"][@"skippedBoardButtonCount"] == NSNull.null, @"omitted board count is bounded");

        NSMutableArray *largeEvents = [NSMutableArray array], *largeComponents = [NSMutableArray array], *largeNodes = [NSMutableArray array];
        for (NSUInteger index = 0; index < 12; index++) { [largeEvents addObject:Event()]; [largeComponents addObject:[NSString stringWithFormat:@"Component%lu", (unsigned long)index]]; }
        NSDictionary *largeControl = @{@"componentTypes": largeComponents, @"button": @{@"events": largeEvents}};
        for (NSUInteger index = 0; index < 70; index++) [largeNodes addObject:Node([NSString stringWithFormat:@"n%lu", (unsigned long)(index + 1)], largeControl)];
        result = STWPSanitize(Probe(largeNodes), YES);
        Check([result[@"controlTrace"][@"metadataNodeCount"] isEqual:@64], @"64 control cap");
        Check(result[@"sceneNodes"][64][@"control"] == nil, @"excess control dropped without dropping scene node");
        Check([FirstControl(result)[@"componentTypes"] count] == 8 && [FirstControl(result)[@"button"][@"events"] count] == 8, @"per-control arrays bounded");
        for (NSString *reason in @[@"control_limit", @"event_limit", @"component_limit"])
            Check([result[@"controlTrace"][@"truncationReasons"] containsObject:reason], [@"native truncation explicit: " stringByAppendingString:reason]);
        Check([result[@"controlTrace"][@"truncated"] isEqual:@YES], @"native truncation cannot be hidden by page");

        input = Probe(@[Node(@"n1", Control())]);
        input[@"cocos"] = @{@"truncated": @YES};
        result = STWPSanitize(input, YES);
        Check([result[@"controlTrace"][@"truncationReasons"] containsObject:@"scene_incomplete"], @"partial scene prevents complete trace claim");
        Check([STWPSanitize(@[], YES)[@"status"] isEqual:@"invalid_probe_result"], @"non-object probe rejected");

        // V2.5: explicitly opted-in, targeted method inspection is rebuilt and
        // bounded separately from the ordinary controls. No game action occurs.
        NSMutableDictionary *inspection = Inspection();
        NSDictionary *safeInspection = SanitizedInspection(inspection);
        Check([safeInspection[@"role"] isEqual:@"return_prop"] && [safeInspection[@"component"] isEqual:@"Prop"], @"targeted return inspection accepted");
        Check([safeInspection[@"stockBadge"] isEqual:@{@"status": @"numeric", @"value": @3}], @"numeric badge survives independently of ordinary number limit");
        Check([safeInspection[@"fields"] count] == 2 && [safeInspection[@"fields"][1][@"value"] isEqual:@NO], @"safe numeric and strict boolean state survive");
        Check([safeInspection[@"methods"][0][@"source"] isEqual:inspection[@"methods"][0][@"source"]], @"source survives only targeted inspection");
        Check([safeInspection[@"truncated"] isEqual:@NO], @"complete bounded inspection remains complete");
        input = InspectionProbe(@[Node(@"n1", ControlWithInspection(inspection))]);
        Check(FirstControl(STWPSanitize(input, NO)) == nil, @"native consent suppresses all inspection text");
        input[@"controlTrace"] = @{@"enabled": @NO};
        Check(FirstControl(STWPSanitize(input, YES)) == nil, @"page trace off suppresses all inspection text");
        input = InspectionProbe(@[Node(@"n1", ControlWithInspection(inspection))]);
        for (id wrongVersion in @[@"2.4.3", @"2.4.4-custom", @"3.0.0", @244, NSNull.null]) {
            input[@"cocos"] = @{@"version": wrongVersion};
            NSDictionary *safe = FirstControl(STWPSanitize(input, YES));
            Check(safe != nil && safe[@"returnInspection"] == nil, @"wrong or malformed Cocos version removes only inspection");
        }
        NSMutableDictionary *mismatchedControl = ControlWithInspection(Inspection());
        mismatchedControl[@"semanticHint"] = @"none";
        result = STWPSanitize(InspectionProbe(@[Node(@"n1", mismatchedControl)]), YES);
        Check(FirstControl(result)[@"returnInspection"] == nil, @"return role needs original semantic target");
        Check([result[@"controlTrace"][@"truncationReasons"] containsObject:@"native_limit"], @"rejected targeted payload is reported");
        mismatchedControl = ControlWithInspection(Inspection());
        mismatchedControl[@"geometryHint"] = @"confirm_geometry";
        Check(FirstControl(STWPSanitize(InspectionProbe(@[Node(@"n1", mismatchedControl)]), YES))[@"returnInspection"] == nil, @"return role also needs prop geometry");
        inspection = Inspection(); inspection[@"role"] = @"confirmation_candidate";
        mismatchedControl = ControlWithInspection(inspection);
        Check(FirstControl(STWPSanitize(InspectionProbe(@[Node(@"n1", mismatchedControl)]), YES))[@"returnInspection"] == nil, @"confirmation role cannot reuse prop geometry");
        mismatchedControl[@"geometryHint"] = @"confirm_geometry";
        Check(FirstControl(STWPSanitize(InspectionProbe(@[Node(@"n1", mismatchedControl)]), YES))[@"returnInspection"] != nil, @"confirmation geometry accepts bounded candidate inspection");
        for (id malformed in @[NSNull.null, @YES, @"source", @[], @{@"version": @1}])
            Check(SanitizedInspection(malformed) == nil, @"malformed inspection root rejected without crash");
        for (id badVersion in @[@YES, @0, @2, @"1", NSNull.null]) {
            inspection = Inspection(); inspection[@"version"] = badVersion;
            Check(SanitizedInspection(inspection) == nil, @"inspection version must be numeric integer one, not boolean");
        }
        for (id badComponent in @[@"Prop\n", @"Prop/Class", @7, NSNull.null]) {
            inspection = Inspection(); inspection[@"component"] = badComponent;
            Check(SanitizedInspection(inspection) == nil, @"component identifier strict");
        }

        inspection = Inspection();
        inspection[@"fields"] = @[
            @{@"name": @"propCount", @"value": @(-10000000)},
            @{@"name": @"propCount", @"value": @9},
            @{@"name": @"propUsed", @"value": @YES},
            @{@"name": @"stockUid", @"value": @1},
            @{@"name": @"accountCount", @"value": @1},
            @{@"name": @"propSecret", @"value": @1},
            @{@"name": @"propCountText", @"value": @"DO_NOT_EXPORT_SECRET"},
            @{@"name": @"propCountObject", @"value": @{@"token": @"DO_NOT_EXPORT_SECRET"}},
            @{@"name": @"propTooLarge", @"value": @10000001},
            @{@"name": @"remaining", @"value": @(NAN)},
            @{@"name": @"cooldown", @"value": @(INFINITY)},
            @{@"name": @"notRelevant", @"value": @2},
            @{@"name": @"num\n", @"value": @2}, NSNull.null, @YES];
        inspection[@"unknown"] = @"DO_NOT_EXPORT_SECRET";
        inspection[@"stockBadge"] = @{@"status": @"numeric", @"value": @99999999, @"text": @"DO_NOT_EXPORT_SECRET"};
        inspection[@"methods"] = @[
            @{@"name": @"onUseProp", @"source": @"function(){return 1;}", @"sourceTruncated": @NO, @"token": @"DO_NOT_EXPORT_SECRET"},
            @{@"name": @"onUseProp", @"source": @"DUPLICATE_SOURCE", @"sourceTruncated": @NO},
            @{@"name": @"constructor", @"source": @"DO_NOT_EXPORT_SECRET", @"sourceTruncated": @NO},
            @{@"name": @"onUseProp\n", @"source": @"DO_NOT_EXPORT_SECRET", @"sourceTruncated": @NO},
            @{@"name": @"badSource", @"source": @{@"token": @"DO_NOT_EXPORT_SECRET"}, @"sourceTruncated": @NO},
            @{@"name": @"badFlag", @"source": @"DO_NOT_EXPORT_SECRET", @"sourceTruncated": @2},
            NSNull.null, @YES];
        safeInspection = SanitizedInspection(inspection);
        Check([safeInspection[@"fields"] count] == 2, @"fields reject sensitive names, duplicates, strings, objects, nonfinite and oversized numbers");
        Check([safeInspection[@"methods"] count] == 1, @"methods reject duplicates, constructor, invalid names and nonstring sources");
        Check([safeInspection[@"stockBadge"][@"value"] isEqual:@99999999], @"eight digit stock maximum preserved");
        Check([safeInspection[@"reasons"] containsObject:@"native_limit"] && [safeInspection[@"truncated"] isEqual:@YES], @"filtered payload cannot claim complete inspection");
        serialized = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:safeInspection options:0 error:nil] encoding:NSUTF8StringEncoding];
        Check(![serialized containsString:@"DO_NOT_EXPORT_SECRET"] && ![serialized containsString:@"DUPLICATE_SOURCE"], @"only whitelisted inspection data survives");
        for (id badStock in @[@YES, @(-1), @1.5, @100000000, @(NAN), @(INFINITY), @"3", @{}, NSNull.null]) {
            inspection = Inspection(); inspection[@"stockBadge"] = @{@"status": @"numeric", @"value": badStock};
            NSDictionary *badge = SanitizedInspection(inspection)[@"stockBadge"];
            Check([badge[@"status"] isEqual:@"unavailable"] && badge[@"value"] == NSNull.null, @"bad numeric stock becomes unavailable/null");
        }
        for (NSString *status in @[@"not_numeric", @"unavailable", @"invented_status"]) {
            inspection = Inspection(); inspection[@"stockBadge"] = @{@"status": status, @"value": @3};
            NSDictionary *badge = SanitizedInspection(inspection)[@"stockBadge"];
            Check(badge[@"value"] == NSNull.null, @"nonnumeric status never retains numeric value");
            Check([badge[@"status"] isEqual:([status isEqual:@"not_numeric"] ? @"not_numeric" : @"unavailable")], @"stock status enum is bounded");
        }

        NSMutableArray *manyFields = [NSMutableArray array], *manyMethods = [NSMutableArray array];
        NSString *largeSource = [@"x" stringByPaddingToLength:9000 withString:@"x" startingAtIndex:0];
        for (NSUInteger index = 0; index < 20; index++) {
            [manyFields addObject:@{@"name": [NSString stringWithFormat:@"propCount%lu", (unsigned long)index], @"value": @(index)}];
            [manyMethods addObject:@{@"name": [NSString stringWithFormat:@"method%lu", (unsigned long)index], @"source": largeSource, @"sourceTruncated": @NO}];
        }
        inspection = Inspection(); inspection[@"fields"] = manyFields; inspection[@"methods"] = manyMethods;
        input = InspectionProbe(@[Node(@"n1", ControlWithInspection(inspection)), Node(@"n2", ControlWithInspection(inspection)), Node(@"n3", ControlWithInspection(inspection))]);
        result = STWPSanitize(input, YES);
        NSDictionary *inspectionLimits = result[@"controlTrace"][@"limits"];
        Check([inspectionLimits[@"maxReturnInspections"] isEqual:@2] && [inspectionLimits[@"maxInspectionFields"] isEqual:@16]
            && [inspectionLimits[@"maxInspectionMethods"] isEqual:@16], @"inspection count caps recorded independently of page claims");
        Check([inspectionLimits[@"maxMethodSourceChars"] isEqual:@8192] && [inspectionLimits[@"maxComponentSourceChars"] isEqual:@32768]
            && [inspectionLimits[@"maxSampleSourceChars"] isEqual:@49152], @"native UTF16 source budgets recorded");
        NSDictionary *firstInspection = FirstControl(result)[@"returnInspection"];
        NSDictionary *secondInspection = result[@"sceneNodes"][1][@"control"][@"returnInspection"];
        Check([firstInspection[@"fields"] count] == 16 && [firstInspection[@"methods"] count] == 16, @"16 field and method caps enforced");
        Check(SourceCharacters(firstInspection) == 32768, @"component UTF16 source budget enforced");
        Check(SourceCharacters(secondInspection) == 16384 && SourceCharacters(firstInspection) + SourceCharacters(secondInspection) == 49152, @"global UTF16 source budget shared across inspections");
        for (NSDictionary *method in firstInspection[@"methods"])
            Check([method[@"source"] length] <= 8192 && [method[@"sourceTruncated"] isEqual:@YES], @"method UTF16 cap and truncation cannot be hidden");
        Check(result[@"sceneNodes"][2][@"control"] != nil && result[@"sceneNodes"][2][@"control"][@"returnInspection"] == nil, @"two inspection cap preserves third ordinary control");
        Check([result[@"controlTrace"][@"truncationReasons"] containsObject:@"native_limit"], @"dropped third inspection marks whole trace partial");
        Check([firstInspection[@"reasons"] containsObject:@"source_limit"] && [firstInspection[@"reasons"] containsObject:@"native_limit"], @"source truncation explicit at inspection level");

        inspection = Inspection();
        NSString *surrogateBoundary = [[@"x" stringByPaddingToLength:8191 withString:@"x" startingAtIndex:0] stringByAppendingString:@"😀end"];
        inspection[@"methods"] = @[@{@"name": @"method", @"source": surrogateBoundary, @"sourceTruncated": @NO}];
        safeInspection = SanitizedInspection(inspection);
        Check([safeInspection[@"methods"][0][@"source"] length] == 8191, @"UTF16 truncation avoids cutting surrogate pair");
        Check([NSJSONSerialization dataWithJSONObject:safeInspection options:0 error:nil] != nil, @"truncated source remains JSON serializable");
        inspection = Inspection(); inspection[@"reasons"] = @[@"read_error", @"read_error", @"accessor_skipped", @"DO_NOT_EXPORT_SECRET"];
        safeInspection = SanitizedInspection(inspection);
        Check([safeInspection[@"reasons"] isEqual:@[@"read_error", @"accessor_skipped", @"native_limit"]], @"reason enums are deduplicated and arbitrary text removed");
        for (id malformed in @[NSNull.null, @YES, @"wrong", @{}]) {
            inspection = Inspection(); inspection[@"fields"] = malformed; inspection[@"methods"] = malformed; inspection[@"stockBadge"] = malformed; inspection[@"reasons"] = malformed;
            safeInspection = SanitizedInspection(inspection);
            Check([safeInspection[@"fields"] count] == 0 && [safeInspection[@"methods"] count] == 0 && [safeInspection[@"truncated"] isEqual:@YES], @"malformed nested types safely omitted and marked partial");
        }
        if (failures) return 1;
        printf("Web probe sanitizer checks passed.\n");
    }
    return 0;
}

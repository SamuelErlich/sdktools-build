const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const factory=vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../Resources/alpaca_fast.js'),'utf8'));
function fixture(){
 const cards=['b','c','d','a'].map((type,i)=>({id:'c'+i,rawID:'raw'+i,type,zone:'board',available:i<3,masked:i===3,selectable:true,
  metadata:{specialType:0},blockedBy:i===3?['c0','c1','c2']:[]}));
 const s={capacity:7,cards,refs:new Map(cards.map(c=>[c.id,c])),tray:[{id:'t0',type:'a'},{id:'t1',type:'a'}]};
 return {cards,s,fast:factory()};
}
for(const count of [1,2,3])test('full four-card mixed proof yields only exposed prefix '+count+' without changing snapshots',()=>{
 const p=fixture(),before=JSON.stringify(p.s),chosen=p.fast.prefix(p.s,p.cards,count);
 assert.deepEqual(Array.from(chosen,c=>c.id),p.cards.slice(0,count).map(c=>c.id));assert.equal(JSON.stringify(p.s),before);
});
test('prefix ends at first unavailable card and never skips ahead to another exposed card',()=>{
 const p=fixture();p.cards=[p.cards[0],p.cards[3],p.cards[1],p.cards[2]];
 p.cards[1].blockedBy=['c0'];p.cards[1].type='e';p.cards[3].type='a';
 const chosen=p.fast.prefix(p.s,p.cards,3);assert.deepEqual(Array.from(chosen,c=>c.id),['c0']);
});
for(const [name,mutate] of [
 ['no completing trio',p=>{p.cards[3].type='z';}],
 ['trio before route end',p=>{p.cards[0].type='a';}],
 ['unproved future blocker',p=>{p.cards[3].blockedBy.push('unknown');}],
 ['future locked card',p=>{p.cards[3].selectable=false;}],
 ['missing rendered identity',p=>{p.s.refs.delete('c2');}],
 ['repeated original identity',p=>{p.cards[1].rawID=p.cards[0].rawID;}],
 ['repeated route card',p=>{p.cards[1]=p.cards[0];}],
 ['disabled first card',p=>{p.cards[0].available=false;}]
])test('prefix refuses the entire route when '+name,()=>{
 const p=fixture();mutate(p);assert.equal(p.fast.prefix(p.s,p.cards,2).length,0);
});
test('prefix refuses a harmless-looking first pair when the complete route would overflow before its trio',()=>{
 const p=fixture();p.s.tray.push({id:'t2',type:'x'},{id:'t3',type:'y'},{id:'t4',type:'z'});
 assert.equal(p.fast.prefix(p.s,p.cards,2).length,0);
});
test('a last-card trio may occupy the seventh transient slot but never an eighth slot',()=>{
 const p=fixture();p.cards=p.cards.slice(1);p.cards[2].blockedBy=[];p.cards[2].available=true;p.cards[2].masked=false;
 p.s.tray.push({id:'t2',type:'x'},{id:'t3',type:'y'});
 assert.equal(p.fast.prefix(p.s,p.cards,3).length,3);
 p.s.tray.push({id:'t4',type:'z'});assert.equal(p.fast.prefix(p.s,p.cards,3).length,0);
});

"""Verify the actual preprocessor removes the early-capture activation code.

This is a build-surface regression check, not an iOS compilation substitute.
The companion Foundation harness executes the resulting class on macOS.
"""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest


class DisabledCardBuildTests(unittest.TestCase):
    def test_paused_class_has_no_native_activation_implementation(self):
        compiler = shutil.which("cc") or shutil.which("clang") or shutil.which("gcc")
        if not compiler:
            self.skipTest("C preprocessor unavailable")
        root = Path(__file__).resolve().parents[1]
        source = root / "Sources/SDKtools/STCardEarlyCapture.m"
        with tempfile.TemporaryDirectory(prefix="sdktools-disabled-headers-") as temporary:
            headers = Path(temporary)
            # Empty declarations are sufficient for preprocessing. UIKit and
            # WebKit are intentionally absent: their branch must be excluded.
            for name in ("Foundation/Foundation.h", "dispatch/dispatch.h"):
                header = headers / name
                header.parent.mkdir(parents=True, exist_ok=True)
                header.write_text("", encoding="utf-8")
            result = subprocess.run(
                [compiler, "-E", "-P", "-x", "c", "-I", str(headers), str(source)],
                capture_output=True, text=True, check=True,
            )
        compiled_branch = result.stdout
        self.assertEqual(compiled_branch.count("@implementation STCardEarlyCapture"), 1)
        self.assertRegex(compiled_branch, r"-\s*\(BOOL\)arm\s*\{\s*return NO;\s*\}")
        self.assertIn('@"feature_disabled"', compiled_branch)
        for forbidden in (
            "addObserver:", "scheduledTimerWithTimeInterval:", "installHooks",
            "class_replaceMethod", "imp_implementationWithBlock", "WKUserScript",
            "WKScriptMessage", "evaluateJavaScript", "receive:", "checkpoint:",
        ):
            self.assertNotIn(forbidden, compiled_branch, forbidden)
        self.assertNotRegex(compiled_branch, re.compile(r"-\s*\([^)]*\)(?:tick|setActive|setRequested)\b"))


if __name__ == "__main__":
    unittest.main()

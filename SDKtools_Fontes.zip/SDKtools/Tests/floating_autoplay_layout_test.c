#include "../Sources/SDKtools/STFloatingAutoplayLayout.h"
#include <assert.h>
#include <float.h>
#include <stdio.h>

static unsigned checks;
static void verify(STFloatingAutoplayLayout layout, double width, double height,
                   double bx, double by, double bw, double bh) {
    assert(isfinite(layout.x) && isfinite(layout.y) &&
           isfinite(layout.width) && isfinite(layout.height)); checks++;
    if (!layout.visible) return;
    assert(layout.width == 44 && layout.height == 44); checks++;
    assert(layout.x >= 0 && layout.y >= 0 && layout.x + layout.width <= width &&
           layout.y + layout.height <= height); checks++;
    assert(layout.x + layout.width <= bx || bx + bw <= layout.x ||
           layout.y + layout.height <= by || by + bh <= layout.y); checks++;
    // The visible 32 pt chip fits inside a single 44 pt accessible target.
    assert(6 + 32 + 6 == layout.width && 6 + 32 + 6 == layout.height); checks++;
}

int main(void) {
    // Actual safe-area sizes: small/notched iPhones, portrait/landscape,
    // tablet, narrow multitasking, and the exact minimum vertical stack.
    const double viewports[][2] = {{304,532},{354,714},{374,750},{734,353},
        {1008,728},{224,304},{94,94}};
    for (unsigned v = 0; v < sizeof(viewports) / sizeof(viewports[0]); v++) {
        double w = viewports[v][0], h = viewports[v][1];
        for (unsigned ix = 0; ix <= 10; ix++) for (unsigned iy = 0; iy <= 10; iy++) {
            double bx = (w - 44) * ix / 10, by = (h - 44) * iy / 10;
            for (unsigned left = 0; left < 2; left++) {
                STFloatingAutoplayLayout s = STFloatingAutoplayFit(w,h,bx,by,44,44,left);
                verify(s,w,h,bx,by,44,44);
                if (v < 6) { assert(s.visible); checks++; }
            }
        }
    }
    STFloatingAutoplayLayout s = STFloatingAutoplayFit(354,714,310,100,44,44,true);
    assert(s.visible && s.x == 260 && s.y == 100); checks++;
    s = STFloatingAutoplayFit(354,714,0,100,44,44,true);
    assert(s.visible && s.x == 50 && s.y == 100); checks++; // Opposite-side fallback.
    s = STFloatingAutoplayFit(354,714,310,100,44,44,false);
    assert(s.visible && s.x == 260 && s.y == 100); checks++;
    s = STFloatingAutoplayFit(94,304,25,0,44,44,false);
    assert(s.visible && s.x == 25 && s.y == 50); checks++; // Neither side fits.
    s = STFloatingAutoplayFit(94,304,25,260,44,44,true);
    assert(s.visible && s.x == 25 && s.y == 210); checks++;
    s = STFloatingAutoplayFit(94,94,25,0,44,44,true);
    assert(s.visible && s.x == 25 && s.y == 50); checks++;
    assert(!STFloatingAutoplayFit(94,93,25,0,44,44,true).visible); checks++;
    assert(!STFloatingAutoplayFit(94,94,25,25,44,44,false).visible); checks++;
    assert(!STFloatingAutoplayFit(354,714,0,0,354,714,true).visible); checks++;

    const double invalid[][6] = {
        {0,714,0,0,44,44}, {354,0,0,0,44,44}, {-1,714,0,0,44,44},
        {354,-1,0,0,44,44}, {43,714,0,0,44,44}, {354,43,0,0,44,44},
        {354,714,0,0,0,44}, {354,714,0,0,44,0}, {354,714,0,0,-1,44},
        {354,714,0,0,44,-1}, {354,714,-1,0,44,44}, {354,714,0,-1,44,44},
        {354,714,311,0,44,44}, {354,714,0,671,44,44},
        {354,714,0,0,355,44}, {354,714,0,0,44,715}
    };
    for (unsigned i = 0; i < sizeof(invalid) / sizeof(invalid[0]); i++) {
        const double *p = invalid[i];
        assert(!STFloatingAutoplayFit(p[0],p[1],p[2],p[3],p[4],p[5],false).visible); checks++;
    }
    const double notFinite[] = {NAN, INFINITY, -INFINITY};
    for (unsigned n = 0; n < 3; n++) for (unsigned field = 0; field < 6; field++) {
        double p[] = {354,714,0,0,44,44}; p[field] = notFinite[n];
        assert(!STFloatingAutoplayFit(p[0],p[1],p[2],p[3],p[4],p[5],true).visible); checks++;
    }
    s = STFloatingAutoplayFit(DBL_MAX,DBL_MAX,0,0,44,44,false);
    verify(s,DBL_MAX,DBL_MAX,0,0,44,44); assert(s.visible); checks++;
    printf("Floating autoplay layout: %u bounds, fallback and touch-gap checks passed\n",checks);
    return 0;
}

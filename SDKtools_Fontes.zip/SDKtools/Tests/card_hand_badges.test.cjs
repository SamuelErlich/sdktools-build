'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {fixture}=require('./card_selected_fixture.cjs');
const {plain}=require('./card_hints_fixture.cjs');
const back=id=>({id,type:0,color:0,num:0});
const none=()=>({id:0,type:0,color:0,num:0});
function badges(f){const layer=f.layer();return layer?layer.children.filter(n=>n.name==='SDKtools Hand Count'):[];}
test('detached hand badges and their text recover without changing the current hand count',()=>{
 for(const target of ['badge','text'])for(const damage of ['detach','destroy']){
  const f=fixture({selected:none(),cards:[back(1)]});f.overlay.tick();const old=badges(f)[0],damaged=target==='badge'?old:old.children[0];
  if(damage==='detach')damaged.removeFromParent();else damaged.destroy();
  const r=f.overlay.tick();assert.equal(r.handTotal,1);assert.equal(r.handUnknown,1);assert.equal(badges(f).length,1,`${target}/${damage}`);
  assert.notEqual(badges(f)[0],old,`${target}/${damage}`);assert.equal(damaged.isValid,false);
  assert.equal(label(f,badges(f)[0]),'1 carta · ?1');f.overlay.clear();
 }
});
function label(f,node){return node.children[0].getComponent(f.cc.Label).string;}
test('dense overlapping hand badge uses current model count, never placed icon count',()=>{
 const f=fixture({selected:none(),cards:Array.from({length:7},(_,i)=>back(i+1))});
 f.first.nodes.forEach((x,i)=>{x.c.node.x=i*30;});
 const before=JSON.stringify(f.store),r=f.overlay.tick();
 assert.equal(r.handsStatus,'ready');assert.equal(r.handTotal,7);assert.equal(r.handUnknown,7);
 assert.ok(r.unknownShown<r.handTotal);assert.equal(badges(f).length,1);assert.equal(label(f,badges(f)[0]),'7 cartas · ?7');
 assert.equal(JSON.stringify(f.store),before);f.overlay.clear();assert.equal(badges(f).length,0);
});
test('selected observation outside hand changes neither hand totals nor knowledge',()=>{
 const f=fixture({selected:{id:81,type:1,color:1,num:4},cards:[back(1),back(2)]});
 f.first.nodes.forEach((x,i)=>{x.c.node.x=i*30;});const r=f.overlay.tick();
 assert.equal(r.handTotal,2);assert.equal(r.handKnown,0);assert.equal(r.handUnknown,2);assert.equal(r.selectedRetained,0);
 assert.equal(label(f,badges(f)[0]),'2 cartas · ?2');f.overlay.clear();
});
test('badge and status update when model length changes despite stale UI fan',()=>{
 const f=fixture({selected:none(),cards:[back(1),back(2),back(3)]});f.first.nodes.forEach((x,i)=>{x.c.node.x=i*30;});
 assert.equal(f.overlay.tick().handTotal,3);f.cloneStore();f.store.gamers[0].cards.pop();
 const r=f.overlay.tick();assert.equal(r.handTotal,2);assert.equal(r.handUnknown,2);
 assert.equal(label(f,badges(f)[0]),'2 cartas · ?2');f.overlay.clear();
});
test('no Label renderer still exports authoritative hand counts and keeps markers',()=>{
 const f=fixture({selected:none(),cards:[back(1)]});delete f.cc.Label;
 const r=f.overlay.tick();assert.equal(r.handTotal,1);assert.equal(r.handUnknown,1);assert.equal(r.status,'ready');assert.equal(badges(f).length,0);f.overlay.clear();
});
test('scene change, hidden document and lease expiry remove every hand badge',()=>{
 for(const action of [f=>f.newScene(),f=>{f.doc.hidden=true;},f=>{f.setTime(700);f.advance(700);}]){
  const f=fixture({selected:none(),cards:[back(1)]});f.overlay.tick();assert.equal(badges(f).length,1);
  const old=badges(f)[0];action(f);f.overlay.tick();assert.equal(old.isValid,false);f.overlay.clear();
 }
});
test('torn model during geometry never publishes a valid count snapshot',()=>{
 const f=fixture({selected:none(),cards:[back(1)]}),node=f.first.nodes[0].c.node,old=node.convertToWorldSpaceAR.bind(node);
 node.convertToWorldSpaceAR=p=>{f.store.gamers[0].cards.push(back(2));return old(p);};
 const r=f.overlay.tick();assert.equal(r.handsStatus,'unavailable');assert.equal(badges(f).length,0);f.overlay.clear();
});
test('sanitized counts contain no reference, UID or card identity',()=>{
 const f=fixture({selected:none(),cards:[back(1)]});const r=plain(f.overlay.tick());
 assert.equal(r.handCounts.length,1);assert.deepEqual(Object.keys(r.handCounts[0]).sort(),['colors','known','selected','slot','special','total','unknown']);
 assert.equal(JSON.stringify(r.handCounts).includes('owner-3'),false);f.overlay.clear();
});



test('language changes update an existing badge without changing cards, knowledge or ownership',()=>{
 const f=fixture({selected:none(),cards:[back(1),back(2)]});f.first.nodes.forEach((x,i)=>{x.c.node.x=i*30;});
 const before=JSON.stringify(f.store),en=f.overlay.tick('en'),badge=badges(f)[0];
 assert.equal(label(f,badge),'2 cards · ?2');
 const pt=f.overlay.tick('pt');assert.equal(badges(f)[0],badge);assert.equal(label(f,badge),'2 cartas · ?2');
 assert.equal(en.handTotal,pt.handTotal);assert.equal(en.handUnknown,pt.handUnknown);assert.equal(JSON.stringify(f.store),before);
 f.overlay.tick('en');assert.equal(label(f,badge),'2 cards · ?2');f.overlay.clear();
});
test('badges preserve the selected language on invalid input and use singular labels',()=>{
 const f=fixture({selected:none(),cards:[back(1)]});f.overlay.tick('en');const badge=badges(f)[0];
 assert.equal(label(f,badge),'1 card · ?1');f.overlay.tick('invalid');assert.equal(label(f,badge),'1 card · ?1');
 f.overlay.tick('pt');assert.equal(label(f,badge),'1 carta · ?1');f.overlay.clear();
});

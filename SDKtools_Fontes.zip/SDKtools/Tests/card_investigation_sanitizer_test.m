#import "../Sources/SDKtools/STCardInvestigationSanitizer.inc"
#import "../Sources/SDKtools/STCardInvestigationBridge.inc"
#include <stdio.h>
static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *message) {
    checks++; if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSMutableDictionary *Card(void) {
    return [@{@"nodeID": @"cpn1", @"parentID": @"cpn2", @"siblingIndex": @0,
        @"frontActive": @NO, @"backActive": @YES, @"identityVerified": @YES,
        @"nodes": @[@{@"nodeID": @"cpn3", @"parentID": @"cpn1", @"branch": @"front", @"path": @[@0],
            @"active": @NO, @"activeInHierarchy": @NO, @"identityVerified": @YES,
            @"frame": @{@"frameID": @"cpf1", @"textureID": @"cpt1", @"nameTag": @"1234abcd",
                @"rect": @{@"x": @0, @"y": @0, @"width": @100, @"height": @140}, @"loaded": @YES}}],
        @"components": @[@{@"componentID": @"cpc1", @"nodeID": @"cpn1", @"className": @"CardItem",
            @"fields": @[@{@"name": @"cardValue", @"kind": @"number", @"value": @7}]}],
        @"local": @{@"x": @10, @"y": @20, @"width": @100, @"height": @140}} mutableCopy];
}
static NSMutableDictionary *Probe(id cards) {
    return [@{@"version": @1, @"status": @"ready", @"reason": @"captured", @"sceneEpoch": @1,
        @"sampleIndex": @1, @"elapsedMs": @250, @"truncated": @NO, @"truncationReasons": @[], @"cards": cards} mutableCopy];
}
int main(void) { @autoreleasepool {
    NSMutableDictionary *card = Card(), *probe = Probe(@[card]);
    probe[@"credential"] = @"private-value"; card[@"playerName"] = @"private-name";
    NSDictionary *safe = STWPSanitizeCardInvestigation(probe), *safeCard = safe[@"cards"][0];
    Check([safeCard[@"nodeID"] isEqual:@"cpn1"], @"probe-local identity preserved");
    Check([safeCard[@"nodes"][0][@"active"] isEqual:@NO], @"inactive front remains marked inactive");
    Check([safeCard[@"identityVerified"] isEqual:@NO] && [safeCard[@"nodes"][0][@"identityVerified"] isEqual:@NO], @"stale frame cannot declare identity verified");
    Check(!safe[@"credential"] && !safeCard[@"playerName"], @"unbounded top-level values removed");
    Check([safeCard[@"nodes"][0][@"frame"][@"nameTag"] isEqual:@"1234abcd"], @"bounded frame tag preserved");
    for (id bad in @[@YES, @0, @2, @"1", NSNull.null]) {
        probe[@"version"] = bad;
        Check([STWPSanitizeCardInvestigation(probe)[@"reason"] isEqual:@"invalid_result"], @"strict version type");
    }
    probe[@"version"] = @1;
    for (id bad in @[@YES, @(-1), @512, @0.5, @"1", @(NAN)]) {
        card[@"siblingIndex"] = bad;
        Check([STWPSanitizeCardInvestigation(probe)[@"cards"] count] == 0, @"invalid card index rejected");
    }
    card[@"siblingIndex"] = @0;
    card[@"nodeID"] = @"n1";
    Check([STWPSanitizeCardInvestigation(probe)[@"cards"] count] == 0, @"scene codec IDs never accepted as card-probe IDs");
    card[@"nodeID"] = @"cpn1";
    NSArray *fields = @[
        @{@"name": @"cardValue", @"kind": @"number", @"value": @4},
        @{@"name": @"playerIndex", @"kind": @"number", @"value": @2},
        @{@"name": @"seatIndex", @"kind": @"number", @"value": @8},
        @{@"name": @"playerCardCount", @"kind": @"number", @"value": @9},
        @{@"name": @"authCard", @"kind": @"number", @"value": @7},
        @{@"name": @"cardValue", @"kind": @"string_omitted", @"value": @"secret-card"},
        @{@"name": @"front", @"kind": @"node_ref", @"ref": @"n4"},
        @{@"name": @"front", @"kind": @"node_ref", @"ref": @"cpn4"},
        @{@"name": @"cardData", @"kind": @"object", @"objectID": @"cpo1", @"fields": @[
            @{@"name": @"rank", @"kind": @"number", @"value": @5},
            @{@"name": @"cardData", @"kind": @"object", @"objectID": @"cpo2", @"fields": @[]}]}];
    card[@"components"] = @[@{@"componentID": @"cpc1", @"nodeID": @"cpn1", @"className": @"CardItem", @"fields": fields}];
    safe = STWPSanitizeCardInvestigation(probe);
    NSArray *output = safe[@"cards"][0][@"components"][0][@"fields"];
    Check(output.count == 5, @"private names, oversized seat and wrong namespace filtered");
    Check([output[1][@"value"] isEqual:@2], @"bounded public seat index survives");
    Check(!output[2][@"value"], @"omitted strings carry no values");
    Check([output[4][@"fields"] count] == 1, @"nested data never recurses beyond depth one");
    NSString *serialized = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:safe options:0 error:nil] encoding:NSUTF8StringEncoding];
    Check([serialized rangeOfString:@"secret-card"].location == NSNotFound, @"no original string leaked");
    for (NSString *name in @[@"tokenCard", @"userValue", @"accountIndex", @"ownerCard", @"cardURL", @"cardSocket", @"serverCard", @"deviceValue", @"nickCount"]) {
        Check(!STCIFieldName(name), @"private field name denied in native sanitizer too");
    }
    for (id value in @[@YES, @(NAN), @(INFINITY), @(-65536), @65536]) {
        Check(STCIFields(@[@{@"name": @"cardValue", @"kind": @"number", @"value": value}], 0, 12).count == 0, @"strict bounded scalar");
    }
    NSArray *idFields = @[@{@"name": @"id", @"kind": @"number", @"value": @321}];
    NSMutableDictionary *cardInfoField = [@{@"name": @"cardInfo", @"kind": @"object", @"objectID": @"cpo1", @"fields": idFields} mutableCopy];
    NSMutableDictionary *cardComponent = [@{@"componentID": @"cpc1", @"nodeID": @"cpn1", @"className": @"Card", @"fields": @[cardInfoField]} mutableCopy];
    Check([STCIComponent(cardComponent, @"cpn1")[@"fields"][0][@"fields"][0][@"value"] isEqual:@321], @"local card id survives only in Card.cardInfo");
    Check(STCIFields(idFields, 1, 8).count == 0, @"generic nested field helper does not gain id permission");
    Check([STCIComponent(cardComponent, nil)[@"fields"][0][@"fields"] count] == 0, @"missing card-root context never enables id");
    cardComponent[@"nodeID"] = @"cpn99";
    Check([STCIComponent(cardComponent, @"cpn1")[@"fields"][0][@"fields"] count] == 0, @"Card component on another node cannot export id");
    NSMutableDictionary *wrongRootCard = Card(); wrongRootCard[@"components"] = @[cardComponent];
    Check([STCICard(wrongRootCard)[@"components"][0][@"fields"][0][@"fields"] count] == 0, @"full sanitizer binds id exception to the actual card root");
    cardComponent[@"nodeID"] = @"cpn1";
    for (NSString *otherClass in @[@"CardItem", @"CardController", @"card"]) {
        cardComponent[@"className"] = otherClass;
        Check([STCIComponent(cardComponent, @"cpn1")[@"fields"][0][@"fields"] count] == 0, @"other component classes cannot export id");
    }
    cardComponent[@"className"] = @"Card";
    for (NSString *otherField in @[@"cardData", @"CardInfo", @"_cardInfo"]) {
        cardInfoField[@"name"] = otherField;
        Check([STCIComponent(cardComponent, @"cpn1")[@"fields"][0][@"fields"] count] == 0, @"id exception requires exact cardInfo field");
    }
    cardInfoField[@"name"] = @"cardInfo";
    cardComponent[@"fields"] = idFields;
    Check([STCIComponent(cardComponent, @"cpn1")[@"fields"] count] == 0, @"Card root id remains denied");
    cardComponent[@"fields"] = @[cardInfoField];
    for (id invalid in @[@YES, @(-1), @65536, @0.5, @"321", @(NAN), @(INFINITY)]) {
        cardInfoField[@"fields"] = @[@{@"name": @"id", @"kind": @"number", @"value": invalid}];
        Check([STCIComponent(cardComponent, @"cpn1")[@"fields"][0][@"fields"] count] == 0, @"card-local id has strict numeric bounds");
    }
    cardInfoField[@"fields"] = @[@{@"name": @"id", @"kind": @"accessor_skipped", @"value": @321}];
    Check([STCIComponent(cardComponent, @"cpn1")[@"fields"][0][@"fields"] count] == 0, @"id accessors do not become card handles");
    NSMutableArray *manyCards = [NSMutableArray array];
    for (NSUInteger i = 0; i < 90; i++) [manyCards addObject:Card()];
    safe = STWPSanitizeCardInvestigation(Probe(manyCards));
    Check([safe[@"cards"] count] <= 64, @"bounded card count");
    Check([NSJSONSerialization dataWithJSONObject:safe options:0 error:nil].length <= 49152, @"native payload budget retained");
    NSMutableArray *manyFields = [NSMutableArray array], *manyComponents = [NSMutableArray array];
    for (NSUInteger i = 0; i < 12; i++) [manyFields addObject:@{@"name": @"cardValueWithAConservativelyBoundedLongFieldName", @"kind": @"number", @"value": @12345}];
    for (NSUInteger i = 0; i < 8; i++) [manyComponents addObject:@{@"componentID": @"cpc1", @"nodeID": @"cpn1", @"className": @"CardItem", @"fields": manyFields}];
    [manyCards removeAllObjects];
    for (NSUInteger i = 0; i < 64; i++) { NSMutableDictionary *large = Card(); large[@"components"] = manyComponents; [manyCards addObject:large]; }
    safe = STWPSanitizeCardInvestigation(Probe(manyCards));
    Check([safe[@"truncated"] isEqual:@YES] && [safe[@"truncationReasons"] containsObject:@"payload_limit"], @"oversized plausible data explicitly clips rather than leaking an unbounded result");
    Check([NSJSONSerialization dataWithJSONObject:safe options:0 error:nil].length <= 49152, @"payload cap includes diagnostic fields");
    card[@"worldOrigin"] = @{@"x": @12, @"y": @34};
    Check([STWPSanitizeCardInvestigation(probe)[@"cards"][0][@"worldOrigin"][@"y"] isEqual:@34], @"verified world geometry retained");
    card[@"worldOrigin"] = @{@"x": @12};
    Check(!STWPSanitizeCardInvestigation(probe)[@"cards"][0][@"worldOrigin"], @"missing world coordinate never invented as zero");
    NSString *script = STWPCardInvestigationCaptureScript(@"native-key", @"candidate-id", @"known-id", @"function(){}", nil);
    Check([script containsString:@"expected='known-id'"] && [script containsString:@"probe_document_changed"], @"known document binding cannot be recreated silently");
    Check([script containsString:@"probe_script_missing"], @"missing packaged probe stays explicit");
    NSDictionary *errorInfo = @{NSLocalizedDescriptionKey: @"PRIVATE-MESSAGE", @"URL": @"https://private.invalid/token", @"credential": @"PRIVATE-TOKEN"};
    NSDictionary *webKitError = STWPWebKitErrorDiagnostic([NSError errorWithDomain:@"WKErrorDomain" code:5 userInfo:errorInfo]);
    Check([webKitError[@"domain"] isEqual:@"WKErrorDomain"] && [webKitError[@"code"] isEqual:@5], @"WebKit unsupported-result code retained without description");
    Check(STWPWebKitErrorDiagnostic([NSError errorWithDomain:@"WKErrorDomain" code:999 userInfo:errorInfo])[@"code"] == NSNull.null, @"unlisted WebKit code omitted");
    NSDictionary *privateError = STWPWebKitErrorDiagnostic([NSError errorWithDomain:@"PRIVATE-DOMAIN" code:321 userInfo:errorInfo]);
    Check([privateError[@"domain"] isEqual:@"other"] && privateError[@"code"] == NSNull.null, @"unknown error domain never exported verbatim");
    NSDictionary *cancelError = STWPWebKitErrorDiagnostic([NSError errorWithDomain:@"NSURLErrorDomain" code:-999 userInfo:errorInfo]);
    Check([cancelError[@"domain"] isEqual:@"NSURLErrorDomain"] && [cancelError[@"code"] isEqual:@(-999)], @"URL cancellation code retained");
    NSString *errorText = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:@[webKitError, privateError, cancelError] options:0 error:nil] encoding:NSUTF8StringEncoding];
    Check([errorText rangeOfString:@"PRIVATE"].location == NSNotFound && [errorText rangeOfString:@"private.invalid"].location == NSNotFound, @"error userInfo, message and URL are absent");
    printf("Card investigation sanitizer: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

// Exact production serializer/writer; synthetic native state, no game/runtime.
// macOS validates JSON/atomic/error paths, not iPhone Data Protection behavior.
#import "../Sources/SDKtools/STCoveredCardReport.inc"
#import <dispatch/dispatch.h>
#include <stdio.h>
#include <assert.h>
// Compile the production API method verbatim with one explicit collaborator:
// its Documents resolver points to a test directory, never the CI user's files.
static NSURL *STCCFixtureDocuments;
@interface STCCReportFileManager : NSObject
+ (instancetype)defaultManager;
- (NSURL *)URLForDirectory:(NSSearchPathDirectory)directory inDomain:(NSSearchPathDomainMask)domain
    appropriateForURL:(NSURL *)url create:(BOOL)create error:(NSError **)error;
@end
@implementation STCCReportFileManager
+ (instancetype)defaultManager {static id manager;if(!manager)manager=[self new];return manager;}
- (NSURL *)URLForDirectory:(NSSearchPathDirectory)directory inDomain:(NSSearchPathDomainMask)domain
    appropriateForURL:(NSURL *)url create:(BOOL)create error:(NSError **)error {
    (void)directory;(void)domain;(void)url;(void)create;if(error)*error=nil;return STCCFixtureDocuments;
}
@end
@interface STRecorder : NSObject
@property BOOL coveredAttemptPending;
@property BOOL coveredAttemptContextLost;
@property(nonatomic,copy) NSDictionary *coveredAttemptDiagnostic;
@property(nonatomic,strong) NSMutableArray *coveredAttemptEvents;
@property NSUInteger forbiddenCalls;
- (NSURL *)writeCoveredAttemptReportWithError:(NSError **)error;
@end
@implementation STRecorder
- (void)pauseAutoplayWithReason:(NSString *)reason {(void)reason;self.forbiddenCalls++;}
- (void)stopRecordingWithReason:(NSString *)reason {(void)reason;self.forbiddenCalls++;}
- (void)markCoveredContextLost {self.forbiddenCalls++;}
- (NSDictionary *)snapshotReport {self.forbiddenCalls++;return @{};}
- (BOOL)isRecording {self.forbiddenCalls++;return YES;}
#define NSFileManager STCCReportFileManager
#include "covered_report_recorder.inc"
#undef NSFileManager
@end
static NSUInteger checks;
#define CHECK(c) do {checks++;assert(c);} while(0)
static NSMutableDictionary *Diagnostic(NSString *status,BOOL pending,BOOL response) {
    NSMutableDictionary *d=[@{@"status":status,@"reason":response?@"server_rejected":@"awaiting_server",@"pending":@(pending),
        @"requestObserved":@YES,@"responseObserved":@(response),@"promiseSettled":@(response),@"effectObserved":@NO,@"attempts":@3} mutableCopy];
    if(response)d[@"serverCode"]=@500;
    return d;
}
static NSDictionary *Decode(NSData *data) {
    CHECK(data.length>0 && data.length<65536);
    NSDictionary *value=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    CHECK([value isKindOfClass:NSDictionary.class]);return value;
}
static BOOL HasPrivateText(NSData *data) {
    NSString *text=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return [text containsString:@"PRIVATE_"] || [text containsString:@"http"] || [text containsString:@"packet_id"] ||
        [text containsString:@"cardID"] || [text containsString:@"message"] || [text containsString:@"secret"];
}
int main(void) { @autoreleasepool {
    NSDictionary *app=@{@"CFBundleIdentifier":@"com.example.fixture",@"CFBundleShortVersionString":@"6.6.2",@"CFBundleVersion":@"132",
        @"ignoredAccount":@"PRIVATE_ACCOUNT"};
    NSError *error=nil;
    NSData *idle=STCCReportData(NO,NO,@{},@[],app,&error);
    CHECK(idle && !error);
    NSDictionary *decoded=Decode(idle),*section=decoded[@"coveredCardExperiment"];
    CHECK([decoded[@"schema"] isEqual:@"SDKtools.CoveredCardReport.v1"]);
    CHECK([decoded[@"toolVersion"] isEqual:@"3.23.6"] && [decoded[@"frameworkBuild"] isEqual:@"56"]);
    CHECK([decoded[@"snapshotOnly"] boolValue] && [decoded[@"lastNativeUpdateOnly"] boolValue]);
    CHECK([section[@"diagnostic"][@"status"] isEqual:@"idle"] && [section[@"events"] count]==0);
    CHECK(![section[@"diagnosticAvailable"] boolValue]);
    CHECK(![section[@"pending"] boolValue] && ![section[@"contextLost"] boolValue]);
    CHECK([decoded[@"appIdentity"] count]==3 && !HasPrivateText(idle));
    NSMutableDictionary *native=Diagnostic(@"uncertain",YES,NO);
    native[@"message"]=@"PRIVATE_MESSAGE";native[@"cardID"]=@"PRIVATE_CARD";native[@"packet_id"]=@987;
    native[@"body"]=@{@"secret":@"PRIVATE_SECRET",@"url":@"https://PRIVATE_HOST"};
    NSMutableArray *events=[NSMutableArray array];
    for(NSUInteger i=0;i<100;i++){NSMutableDictionary *row=[native mutableCopy];row[@"attempts"]=@(i);[events addObject:row];}
    NSDictionary *nativeBefore=[native copy];NSArray *eventsBefore=[events copy];
    NSData *pending=STCCReportData(YES,YES,native,events,app,&error);
    CHECK(pending && !error && !HasPrivateText(pending));
    section=Decode(pending)[@"coveredCardExperiment"];
    CHECK([section[@"pending"] boolValue] && [section[@"contextLost"] boolValue]);
    CHECK([section[@"diagnosticAvailable"] boolValue]);
    CHECK([section[@"diagnostic"][@"status"] isEqual:@"uncertain"]);
    CHECK([section[@"events"] count]==24 && [section[@"events"][0][@"attempts"] isEqual:@76]);
    CHECK([[section[@"events"] lastObject][@"attempts"] isEqual:@99]);
    CHECK([native isEqual:nativeBefore] && [events isEqual:eventsBefore]); // serializer does not modify the latch/history
    CHECK([section[@"diagnostic"] count]==8 && !section[@"diagnostic"][@"message"]);
    native[@"reason"]=@"PRIVATE_REASON";
    section=Decode(STCCReportData(YES,YES,native,@[native],app,&error))[@"coveredCardExperiment"];
    CHECK([section[@"diagnostic"][@"reason"] isEqual:@"unrecognized_reason"]);
    NSMutableDictionary *rejected=Diagnostic(@"rejected",NO,YES);rejected[@"message"]=@"PRIVATE_OLD_SERVER_MESSAGE";
    NSData *rejection=STCCReportData(NO,NO,rejected,@[rejected],app,&error);
    section=Decode(rejection)[@"coveredCardExperiment"];
    CHECK([section[@"diagnostic"][@"serverCode"] isEqual:@500] && !HasPrivateText(rejection));
    CHECK(![section[@"diagnostic"][@"effectObserved"] boolValue]);
    for(id invalid in @[@{},NSNull.null,@[@"PRIVATE_HISTORY"],@{@"status":@"accepted",@"message":@"PRIVATE_500"}]) {
        NSData *data=STCCReportData(YES,YES,invalid,@[invalid],app,&error);
        section=Decode(data)[@"coveredCardExperiment"];
        CHECK([section[@"diagnostic"][@"status"] isEqual:@"uncertain"] && [section[@"events"] count]==0);
        CHECK(![section[@"diagnosticAvailable"] boolValue]);
        CHECK(!section[@"diagnostic"][@"serverCode"] && !HasPrivateText(data));
    }
    for(id bad in @[@YES,@(-1),@1.5,@1000001,@"500",@(INFINITY)]){
        NSMutableDictionary *row=[rejected mutableCopy];row[@"serverCode"]=bad;
        section=Decode(STCCReportData(NO,NO,row,@[row],app,&error))[@"coveredCardExperiment"];
        CHECK(!section[@"diagnostic"][@"serverCode"] && [section[@"events"] count]==0);
    }
    NSDictionary *badApp=@{@"CFBundleIdentifier":@"https://PRIVATE_URL",@"CFBundleVersion":@"PRIVATE SPACE",@"CFBundleShortVersionString":@42};
    decoded=Decode(STCCReportData(NO,NO,nil,nil,badApp,&error));
    CHECK([decoded[@"appIdentity"][@"bundleIdentifier"] isEqual:@"unknown"] && [decoded[@"appIdentity"][@"version"] isEqual:@"unknown"]);
    CHECK([decoded[@"appIdentity"][@"build"] isEqual:@"unknown"]);
    native[@"status"]=@"PRIVATE_CHANGED_AFTER_SNAPSHOT";
    CHECK(!HasPrivateText(pending)); // detached serialized bytes remain unchanged
    section=Decode(STCCReportData(NO,NO,nil,nil,app,&error))[@"coveredCardExperiment"];
    CHECK([section[@"diagnostic"][@"status"] isEqual:@"idle"] && [section[@"events"] count]==0); // restart does not reconstruct old message/code
    NSURL *temporary=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString] isDirectory:YES];
    CHECK([NSFileManager.defaultManager createDirectoryAtURL:temporary withIntermediateDirectories:YES attributes:nil error:nil]);
    STCCFixtureDocuments=temporary;
    STRecorder *recorder=[STRecorder new];
    NSURL *emptyReport=[recorder writeCoveredAttemptReportWithError:&error];
    CHECK(emptyReport.isFileURL && !error && recorder.forbiddenCalls==0);
    NSDictionary *emptySection=Decode([NSData dataWithContentsOfURL:emptyReport])[@"coveredCardExperiment"];
    CHECK([emptySection[@"diagnostic"][@"status"] isEqual:@"idle"] && [emptySection[@"events"] count]==0);
    recorder.coveredAttemptPending=YES;recorder.coveredAttemptContextLost=YES;
    recorder.coveredAttemptDiagnostic=Diagnostic(@"uncertain",YES,NO);
    recorder.coveredAttemptEvents=[NSMutableArray arrayWithObject:recorder.coveredAttemptDiagnostic];
    NSDictionary *storedDiagnostic=recorder.coveredAttemptDiagnostic;
    NSMutableArray *storedEvents=recorder.coveredAttemptEvents;
    NSURL *activeReport=[recorder writeCoveredAttemptReportWithError:&error];
    CHECK(activeReport.isFileURL && !error && recorder.forbiddenCalls==0);
    CHECK(recorder.coveredAttemptPending && recorder.coveredAttemptContextLost);
    CHECK(recorder.coveredAttemptDiagnostic==storedDiagnostic && recorder.coveredAttemptEvents==storedEvents && storedEvents.count==1);
    __block NSURL *backgroundURL=nil;__block NSError *backgroundError=nil;
    dispatch_semaphore_t completed=dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_DEFAULT,0),^{
        backgroundURL=[recorder writeCoveredAttemptReportWithError:&backgroundError];dispatch_semaphore_signal(completed);
    });
    CHECK(dispatch_semaphore_wait(completed,dispatch_time(DISPATCH_TIME_NOW,5*NSEC_PER_SEC))==0);
    CHECK(!backgroundURL && backgroundError.code==1 && [backgroundError.domain isEqual:@"SDKtools.CoveredCardReport"]);
    CHECK(recorder.coveredAttemptPending && recorder.coveredAttemptContextLost && recorder.forbiddenCalls==0);
    NSURL *first=STCCReportWriteData(pending,temporary,&error),*second=STCCReportWriteData(rejection,temporary,&error);
    CHECK(first.isFileURL && second.isFileURL && ![first isEqual:second] && !error);
    CHECK([first.lastPathComponent hasPrefix:@"SDKtools-CoveredCard-"] && [first.pathExtension isEqual:@"json"]);
    CHECK([first.URLByDeletingLastPathComponent.lastPathComponent isEqual:@"SDKtools"]);
    CHECK([[NSData dataWithContentsOfURL:first] isEqual:pending] && [[NSData dataWithContentsOfURL:second] isEqual:rejection]);
    NSNumber *excluded=nil;CHECK([first getResourceValue:&excluded forKey:NSURLIsExcludedFromBackupKey error:nil] && excluded.boolValue);
    for(NSData *bad in @[[NSData data],[NSMutableData dataWithLength:65536],[NSMutableData dataWithLength:65537]]){
        CHECK(!STCCReportWriteData(bad,temporary,&error) && [error.domain isEqual:@"SDKtools.CoveredCardReport"] && error.code==3);
    }
    CHECK(!STCCReportWriteData(idle,[NSURL URLWithString:@"https://PRIVATE_URL"],&error) && error.code==4);
    CHECK(error.userInfo.count==1 && ![error.userInfo.description containsString:@"PRIVATE_"]);
    NSURL *blocked=[temporary URLByAppendingPathComponent:@"blocked" isDirectory:YES];
    CHECK([NSFileManager.defaultManager createDirectoryAtURL:blocked withIntermediateDirectories:YES attributes:nil error:nil]);
    CHECK([@"fixture" writeToURL:[blocked URLByAppendingPathComponent:@"SDKtools"] atomically:YES encoding:NSUTF8StringEncoding error:nil]);
    CHECK(!STCCReportWriteData(idle,blocked,&error) && error.code==5);
    CHECK([NSFileManager.defaultManager removeItemAtURL:temporary error:nil]);
    printf("Covered-card native report privacy/passivity: %lu checks passed\n",(unsigned long)checks);
} return 0; }

const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const api=require('../Resources/LAN/panel.js');
function server(){const calls=[];let next=1,started=0,paused=0,prefs={speedLevel:3,extendedPlanning:false,powersEnabled:false,xrayEnabled:false};
 const state=()=>({version:1,toolVersion:'fixture',frameworkBuild:'0',fresh:true,ageMs:10,phaseRevision:2,autoplayEnabled:started>paused,canStart:true,
   statusText:'Fixture <script>not markup</script>',confirmedMoves:6,mission:{current:1,total:3},superFast:{status:'idle',requests:0,responses:0},preferences:prefs,
   counts:{board:9,tray:1,reserve:2,types:3,sharedCards:1}});
 async function fetch(url,options){calls.push({url,options});let data={ok:true,nextSequence:next},status=200;
  if(url==='/api/pair')data={...data,key:'a'.repeat(64)};
  else if(url==='/api/state')data.state=state();
  else if(url==='/api/control'){const b=JSON.parse(options.body);if(b.sequence!==next){status=409;data={ok:false,reason:'sequence_conflict',nextSequence:next};}
   else{next++;if(b.action==='start')started++;if(b.action==='pause')paused++;if(b.action==='preferences')prefs=b.preferences;data={ok:true,nextSequence:next};}}
  return {ok:status===200,status,text:async()=>JSON.stringify(data)};
 }
 return {fetch,calls,state,get started(){return started;},get paused(){return paused;},get next(){return next;}};
}
test('all five speed profiles keep increasing cadence and maximum respects the chosen card count',()=>{
 assert.deepEqual(api.speeds.map(s=>s.ms),[500,250,100,40,20]);assert.match(api.speeds[4].detail,/quantidade escolhida/);assert.match(api.speeds[4].detail,/aguarda confirmação/);
 const native=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STAutoplayRecorder.inc'),'utf8');
 assert.ok(native.includes('self.superFastEnabled ? 0.02 : self.turboEnabled ? 0.04 : self.autoplaySpeedLevel==1 ? 0.5 : self.autoplaySpeedLevel==2 ? 0.25 : 0.1'));
});
test('counts include shared cards and never turn unknown or stale data into a fake zero',()=>{
 const s=server().state();assert.equal(api.counts(s).total,13);for(const bad of [null,{}, {...s,fresh:false},{...s,counts:{...s.counts,board:NaN}},{...s,counts:{...s.counts,tray:7}},{...s,counts:{...s.counts,board:512}}])assert.equal(api.counts(bad),null);
 assert.equal(api.counts({...s,counts:{board:0,tray:0,reserve:0,types:0,sharedCards:0}}).total,0);
});
test('pairing and state use only relative endpoints with a separate memory-only bearer key',async()=>{
 const s=server(),c=api.client(s.fetch);await assert.rejects(c.pair('12'),/invalid_pairing/);assert.equal(s.calls.length,0);
 await c.pair('12345678');await c.state();assert.equal(s.calls[0].url,'/api/pair');assert.equal(s.calls[0].options.headers['X-SDKTools-Key'],undefined);
 assert.equal(s.calls[1].options.headers['X-SDKTools-Key'],'a'.repeat(64));for(const call of s.calls){assert.equal(call.options.credentials,'omit');assert.equal(call.options.redirect,'error');assert.equal(call.options.cache,'no-store');}
 const source=fs.readFileSync(path.join(__dirname,'../Resources/LAN/panel.js'),'utf8');assert.doesNotMatch(source,/localStorage|sessionStorage|document\.cookie|innerHTML|eval\(/);
});
test('preferences never start Auto and commands are explicit sequence-correlated single posts',async()=>{
 const s=server(),c=api.client(s.fetch);await c.pair('12345678');await c.state();
 for(let n=1;n<=5;n++)await c.command('preferences',api.preferences(n,true,false,true));assert.equal(s.started,0);assert.equal(s.next,6);
 await c.command('start');assert.equal(s.started,1);await c.command('pause');assert.equal(s.paused,1);
 const rows=s.calls.filter(r=>r.url==='/api/control').map(r=>JSON.parse(r.options.body));assert.deepEqual(rows.map(r=>r.sequence),[1,2,3,4,5,6,7]);
 assert.deepEqual(Object.keys(rows[0]).sort(),['action','preferences','sequence']);
});
test('invalid levels, non-booleans and unlisted gameplay commands never send',async()=>{
 const s=server(),c=api.client(s.fetch);await c.pair('12345678');await c.state();const before=s.calls.length;
 for(const n of [0,6,1.5,NaN,'5'])assert.throws(()=>api.preferences(n,true,false,false));
 assert.throws(()=>api.preferences(3,1,false,false));for(const action of ['eval','touch_card','penetrate_zero','fetch','start;'])await assert.rejects(c.command(action),/command_denied/);
 assert.equal(s.calls.length,before);assert.equal(s.started,0);
});
test('an unknown command response is not automatically resent; explicit state read recovers sequence',async()=>{
 const s=server();let lose=true;const c=api.client(async(...args)=>{const response=await s.fetch(...args);if(args[0]==='/api/control'&&lose){lose=false;throw Error('response lost after apply');}return response;});
 await c.pair('12345678');await c.state();await assert.rejects(c.command('start'));assert.equal(s.started,1);
 assert.equal(s.calls.filter(r=>r.url==='/api/control').length,1);await c.state();await c.command('pause');assert.equal(s.started,1);assert.equal(s.paused,1);
 assert.equal(JSON.parse(s.calls.at(-1).options.body).sequence,2);
});
test('overlapping polls and double clicks cannot submit a second command',async()=>{
 const s=server();let release;const c=api.client(async(...args)=>{if(args[0]==='/api/state')await new Promise(resolve=>{release=resolve;});return s.fetch(...args);});
 await c.pair('12345678');const pending=c.state();await assert.rejects(c.command('start'),/command_pending/);await assert.rejects(c.state(),/command_pending/);
 release();await pending;assert.equal(s.started,0);await c.command('start');assert.equal(s.started,1);
});
test('oversized or malformed server responses fail closed',async()=>{
 for(const data of ['x'.repeat(32769),'{}','null','{bad']){const c=api.client(async()=>({ok:true,text:async()=>data}));await assert.rejects(c.pair('12345678'));await assert.rejects(c.state());}
});

test('diagnostic capture and source exports are explicit sequenced commands without starting Auto',async()=>{
 const s=server(),c=api.client(s.fetch);await c.pair('12345678');await c.state();
 for(const action of ['capture_start','capture_stop','report_export','sources_export'])await c.command(action);
 const actions=s.calls.filter(r=>r.url==='/api/control').map(r=>JSON.parse(r.options.body));
 assert.deepEqual(actions.map(r=>r.sequence),[1,2,3,4]);assert.equal(s.started,0);assert.equal(actions.length,4);
});
test('export downloads keep pairing credentials in headers and verify every chunk size',async()=>{
 const s=server(),id='11111111-1111-4111-8111-111111111111',bytes=new Uint8Array(300000).map((_,i)=>i%251),requests=[];
 const c=api.client(async(url,options)=>{
  if(url!=='/api/export')return s.fetch(url,options);requests.push(options);const offset=Number(options.headers['X-SDKTools-Offset']);
  return {ok:true,arrayBuffer:async()=>bytes.slice(offset,offset+262144).buffer};
 });await c.pair('12345678');
 assert.deepEqual(await c.download({id,bytes:bytes.length}),bytes);assert.equal(requests.length,2);
 assert.equal(requests[0].headers['X-SDKTools-Key'],'a'.repeat(64));assert.equal(requests[0].headers['X-SDKTools-Export'],id);
 await assert.rejects(c.download({id:'../../file',bytes:1}));await assert.rejects(c.download({id,bytes:67108865}));
 const bad=api.client(async(url,options)=>url==='/api/pair'?s.fetch(url,options):{ok:true,arrayBuffer:async()=>new ArrayBuffer(0)});
 await bad.pair('12345678');await assert.rejects(bad.download({id,bytes:2}),/invalid_download/);
});
function browser(fetcher){
 const source=fs.readFileSync(path.join(__dirname,'../Resources/LAN/panel.js'),'utf8'),html=fs.readFileSync(path.join(__dirname,'../Resources/LAN/panel.html'),'utf8');
 const nodes=new Map([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],{value:m[1]==='speed'?'3':'',checked:false,hidden:false,disabled:false,textContent:'',handlers:{},addEventListener(n,fn){this.handlers[n]=fn;}}]));
 for(const n of nodes.values())Object.defineProperty(n,'innerHTML',{set(){throw Error('unsafe HTML insertion');}});
 const document={visibilityState:'visible',getElementById:id=>{assert.ok(nodes.has(id),id);return nodes.get(id);},handlers:{},addEventListener(n,fn){this.handlers[n]=fn;}},timers=new Map();let serial=0;
 const context=vm.createContext({document,fetch:fetcher,AbortController,Date,setTimeout(fn,ms){timers.set(++serial,{fn,ms});return serial;},clearTimeout(id){timers.delete(id);}});vm.runInContext(source,context);
 return {nodes,document,timers,async pair(){nodes.get('code').value='12345678';await nodes.get('pair-form').handlers.submit({preventDefault(){}});},click(id){return nodes.get(id).handlers.click();}};
}
test('actual browser controller pairs, displays live counts, applies maximum without starting and can pause',async()=>{
 const s=server(),b=browser(s.fetch);await b.pair();assert.equal(b.nodes.get('board').textContent,'9');assert.equal(b.nodes.get('total').textContent,'13');
 assert.equal(b.nodes.get('status').textContent,'Fixture <script>not markup</script>');assert.equal(b.nodes.get('pairing').hidden,true);
 b.nodes.get('speed').value='5';b.nodes.get('speed').handlers.input();await b.click('apply');assert.equal(s.state().preferences.speedLevel,5);assert.equal(s.started,0);
 await b.click('start');assert.equal(s.started,1);await b.click('pause');assert.equal(s.paused,1);assert.equal(b.nodes.get('auto-state').textContent,'Pausado');
 assert.equal(b.nodes.get('speed-name').textContent,'Máximo');
});
test('browser shows uncertainty and stops polling after losing a command response; no replay',async()=>{
 const s=server(),b=browser(async(...args)=>{const r=await s.fetch(...args);if(args[0]==='/api/control')throw Error('lost');return r;});await b.pair();await b.click('start');
 assert.equal(s.started,1);assert.equal(b.nodes.get('connection').textContent,'Desconectado');assert.match(b.nodes.get('notice').textContent,/Nenhum reenvio/);
 assert.equal(b.timers.size,0);assert.equal(b.nodes.get('start').disabled,true);assert.equal(s.calls.filter(r=>r.url==='/api/control').length,1);
});
test('hiding a paired page requests at most one pause and never starts an action',async()=>{
 const s=server(),b=browser(s.fetch);await b.pair();await b.click('start');b.document.visibilityState='hidden';b.document.handlers.visibilitychange();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(s.started,1);assert.equal(s.paused,1);assert.equal(b.timers.size,0);
});

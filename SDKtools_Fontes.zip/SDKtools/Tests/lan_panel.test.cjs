const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const api=require('../Resources/LAN/panel.js');
function server(overrides={}){const calls=[];let next=1,started=0,paused=0,prefs={speedLevel:3,cardsPerBatch:3,extendedPlanning:false,powersEnabled:false,xrayEnabled:false};
 const state=()=>({version:1,toolVersion:'fixture',frameworkBuild:'0',fresh:true,ageMs:10,phaseRevision:2,autoplayEnabled:started>paused,canStart:true,
   statusText:'Fixture <script>not markup</script>',confirmedMoves:6,mission:{current:1,total:3},superFast:{status:'idle',requests:0,responses:0},preferences:prefs,
   counts:{board:9,tray:1,reserve:2,types:3,sharedCards:1},capture:{recording:false,owned:false},export:{state:'idle'},batchPending:false,...overrides});
 async function fetch(url,options){calls.push({url,options});let data={ok:true,nextSequence:next},status=200;
  if(url==='/api/pair')data={...data,key:'a'.repeat(64)};
  else if(url==='/api/state')data.state=state();
  else if(url==='/api/control'){const b=JSON.parse(options.body);if(b.sequence!==next){status=409;data={ok:false,reason:'sequence_conflict',nextSequence:next};}
   else{next++;if(b.action==='start')started++;if(b.action==='pause')paused++;if(b.action==='preferences')prefs=b.preferences;data={ok:true,nextSequence:next};}}
  return {ok:status===200,status,text:async()=>JSON.stringify(data)};
 }
 return {fetch,calls,state,get started(){return started;},get paused(){return paused;},get next(){return next;}};
}
test('all eight speed profiles keep increasing cadence and maximum respects the chosen card count',()=>{
 assert.deepEqual(api.speeds.map(s=>s.ms),[500,250,100,40,20,10,5,2]);assert.match(api.speeds[4].detail,/quantidade escolhida/);assert.match(api.speeds[4].detail,/aguarda confirmação/);
 const native=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STAutoplayRecorder.inc'),'utf8');
 assert.ok(native.includes('STAutoplayIntervalMilliseconds((unsigned)self.autoplaySpeedLevel)'));
});
test('counts include shared cards and never turn unknown or stale data into a fake zero',()=>{
 const s=server().state();assert.equal(api.counts(s).total,13);for(const bad of [null,{}, {...s,fresh:false},{...s,counts:{...s.counts,board:NaN}},{...s,counts:{...s.counts,tray:7}},{...s,counts:{...s.counts,board:512}}])assert.equal(api.counts(bad),null);
 assert.equal(api.counts({...s,counts:{board:0,tray:0,reserve:0,types:0,sharedCards:0}}).total,0);
});
test('pairing and state use only relative endpoints with a separate memory-only bearer key',async()=>{
 const s=server(),c=api.client(s.fetch);await assert.rejects(c.pair('12'),/invalid_pairing/);assert.equal(s.calls.length,0);
 await c.pair('12345678');await c.state();assert.equal(s.calls[0].url,'/api/pair');assert.equal(s.calls[0].options.headers['X-SDKTools-Key'],undefined);
 assert.equal(s.calls[1].options.headers['X-SDKTools-Key'],'a'.repeat(64));for(const call of s.calls){assert.equal(call.options.credentials,'omit');assert.equal(call.options.redirect,'error');assert.equal(call.options.cache,'no-store');}
 const source=fs.readFileSync(path.join(__dirname,'../Resources/LAN/panel.js'),'utf8');assert.doesNotMatch(source,/localStorage|sessionStorage|document\.cookie|innerHTML|eval\(/);
});
test('preferences never start Auto and commands are explicit sequence-correlated single posts',async()=>{
 const s=server(),c=api.client(s.fetch);await c.pair('12345678');await c.state();
 for(let n=1;n<=8;n++)await c.command('preferences',api.preferences(n,true,false,true));assert.equal(s.started,0);assert.equal(s.next,9);
 await c.command('start');assert.equal(s.started,1);await c.command('pause');assert.equal(s.paused,1);
 const rows=s.calls.filter(r=>r.url==='/api/control').map(r=>JSON.parse(r.options.body));assert.deepEqual(rows.map(r=>r.sequence),[1,2,3,4,5,6,7,8,9,10]);
 assert.deepEqual(Object.keys(rows[0]).sort(),['action','preferences','sequence']);
});
test('invalid levels, non-booleans and unlisted gameplay commands never send',async()=>{
 const s=server(),c=api.client(s.fetch);await c.pair('12345678');await c.state();const before=s.calls.length;
 for(const n of [0,9,1.5,NaN,'5',true,Infinity])assert.throws(()=>api.preferences(n,true,false,false));
 assert.throws(()=>api.preferences(3,1,false,false));for(const action of ['eval','touch_card','penetrate_zero','fetch','start;'])await assert.rejects(c.command(action),/command_denied/);
 assert.equal(s.calls.length,before);assert.equal(s.started,0);
});
test('an unknown command response is not automatically resent; explicit state read recovers sequence',async()=>{
 const s=server();let lose=true;const c=api.client(async(...args)=>{const response=await s.fetch(...args);if(args[0]==='/api/control'&&lose){lose=false;throw Error('response lost after apply');}return response;});
 await c.pair('12345678');await c.state();await assert.rejects(c.command('start'));assert.equal(s.started,1);
 assert.equal(s.calls.filter(r=>r.url==='/api/control').length,1);await c.state();await c.command('pause');assert.equal(s.started,1);assert.equal(s.paused,1);
 assert.equal(JSON.parse(s.calls.at(-1).options.body).sequence,2);
});
test('overlapping polls and double clicks cannot submit a second command',async()=>{
 const s=server();let release;const c=api.client(async(...args)=>{if(args[0]==='/api/state')await new Promise(resolve=>{release=resolve;});return s.fetch(...args);});
 await c.pair('12345678');const pending=c.state();await assert.rejects(c.command('start'),/command_pending/);await assert.rejects(c.state(),/command_pending/);
 release();await pending;assert.equal(s.started,0);await c.command('start');assert.equal(s.started,1);
});
test('oversized or malformed server responses fail closed',async()=>{
 for(const data of ['x'.repeat(32769),'{}','null','{bad']){const c=api.client(async()=>({ok:true,text:async()=>data}));await assert.rejects(c.pair('12345678'));await assert.rejects(c.state());}
});

test('diagnostic capture and source exports are explicit sequenced commands without starting Auto',async()=>{
 const s=server(),c=api.client(s.fetch);await c.pair('12345678');await c.state();
 for(const action of ['capture_start','capture_stop','report_export','sources_export'])await c.command(action);
 const actions=s.calls.filter(r=>r.url==='/api/control').map(r=>JSON.parse(r.options.body));
 assert.deepEqual(actions.map(r=>r.sequence),[1,2,3,4]);assert.equal(s.started,0);assert.equal(actions.length,4);
});
test('export downloads keep pairing credentials in headers and verify every chunk size',async()=>{
 const s=server(),id='11111111-1111-4111-8111-111111111111',bytes=new Uint8Array(300000).map((_,i)=>i%251),requests=[];
 const c=api.client(async(url,options)=>{
  if(url!=='/api/export')return s.fetch(url,options);requests.push(options);const offset=Number(options.headers['X-SDKTools-Offset']);
  return {ok:true,arrayBuffer:async()=>bytes.slice(offset,offset+262144).buffer};
 });await c.pair('12345678');
 assert.deepEqual(await c.download({id,bytes:bytes.length}),bytes);assert.equal(requests.length,2);
 assert.equal(requests[0].headers['X-SDKTools-Key'],'a'.repeat(64));assert.equal(requests[0].headers['X-SDKTools-Export'],id);
 await assert.rejects(c.download({id:'../../file',bytes:1}));await assert.rejects(c.download({id,bytes:67108865}));
 const bad=api.client(async(url,options)=>url==='/api/pair'?s.fetch(url,options):{ok:true,arrayBuffer:async()=>new ArrayBuffer(0)});
 await bad.pair('12345678');await assert.rejects(bad.download({id,bytes:2}),/invalid_download/);
});
function browser(fetcher){
 const source=fs.readFileSync(path.join(__dirname,'../Resources/LAN/panel.js'),'utf8'),html=fs.readFileSync(path.join(__dirname,'../Resources/LAN/panel.html'),'utf8');
 const nodes=new Map([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],{value:m[1]==='speed'?'3':'',checked:false,hidden:false,disabled:false,textContent:'',handlers:{},addEventListener(n,fn){this.handlers[n]=fn;}}]));
 for(const n of nodes.values())Object.defineProperty(n,'innerHTML',{set(){throw Error('unsafe HTML insertion');}});
 const document={visibilityState:'visible',getElementById:id=>{assert.ok(nodes.has(id),id);return nodes.get(id);},handlers:{},addEventListener(n,fn){this.handlers[n]=fn;}},timers=new Map();let serial=0;
 const context=vm.createContext({document,fetch:fetcher,AbortController,Date,setTimeout(fn,ms){timers.set(++serial,{fn,ms});return serial;},clearTimeout(id){timers.delete(id);}});vm.runInContext(source,context);
 return {nodes,document,timers,async pair(){nodes.get('code').value='12345678';await nodes.get('pair-form').handlers.submit({preventDefault(){}});},click(id){return nodes.get(id).handlers.click();},
  async poll(){const entry=[...timers.entries()].find(([,t])=>t.ms===500);assert.ok(entry,'a poll is scheduled');timers.delete(entry[0]);await entry[1].fn();}};
}
test('actual browser controller pairs, displays live counts, applies maximum without starting and can pause',async()=>{
 const s=server(),b=browser(s.fetch);await b.pair();assert.equal(b.nodes.get('board').textContent,'9');assert.equal(b.nodes.get('total').textContent,'13');
 assert.equal(b.nodes.get('status').textContent,'Fixture <script>not markup</script>');assert.equal(b.nodes.get('pairing').hidden,true);
 b.nodes.get('speed').value='5';b.nodes.get('speed').handlers.input();await b.click('apply');assert.equal(s.state().preferences.speedLevel,5);assert.equal(s.started,0);
 await b.click('start');assert.equal(s.started,1);await b.click('pause');assert.equal(s.paused,1);assert.equal(b.nodes.get('auto-state').textContent,'Pausado');
 assert.equal(b.nodes.get('speed-name').textContent,'Máximo');
});
test('browser shows uncertainty and stops polling after losing a command response; no replay',async()=>{
 const s=server(),b=browser(async(...args)=>{const r=await s.fetch(...args);if(args[0]==='/api/control')throw Error('lost');return r;});await b.pair();await b.click('start');
 assert.equal(s.started,1);assert.equal(b.nodes.get('connection').textContent,'Desconectado');assert.match(b.nodes.get('notice').textContent,/Nenhum reenvio/);
 assert.equal(b.timers.size,0);assert.equal(b.nodes.get('start').disabled,true);assert.equal(s.calls.filter(r=>r.url==='/api/control').length,1);
 assert.equal(b.nodes.get('total').textContent,'—');assert.doesNotMatch(b.nodes.get('reading').textContent,/Snapshot|idade/);
 assert.equal(b.nodes.get('auto-state').textContent,'Auto: estado indisponível');
});
test('browser separates selected card count from the active batch and removes completed counts',async()=>{
 const current={preferences:{speedLevel:5,cardsPerBatch:2}},s=server(current),b=browser(s.fetch);await b.pair();
 assert.equal(b.nodes.get('batch').textContent,'Lote: até 2 cartas · aguardando');
 current.batchPending=true;current.superFast={pending:true,status:'submitted',submitted:3,requests:3,responses:1};await b.poll();
 assert.equal(b.nodes.get('batch').textContent,'Lote: até 2 cartas · em curso: pedidos 3/3 · respostas 1');
 current.superFast={...current.superFast,pending:false};await b.poll();
 assert.equal(b.nodes.get('batch').textContent,'Lote: até 2 cartas · em curso: aguardando confirmação');
 current.batchPending=false;current.superFast={...current.superFast,pending:false,status:'confirmed',responses:3};await b.poll();
 assert.equal(b.nodes.get('batch').textContent,'Lote: até 2 cartas · aguardando');
 current.superFast={compatibility:true,status:'blocked',pending:false};await b.poll();
 assert.equal(b.nodes.get('batch').textContent,'Lote: até 2 cartas · indisponível: 1 por vez');
 current.fresh=false;await b.poll();assert.equal(b.nodes.get('batch').textContent,'Lote: sem leitura atual');
});
test('lost poll clears live readings and reconnect restores fresh data without issuing actions',async()=>{
 const s=server();let offline=false;const b=browser(async(...args)=>{if(offline)throw Error('offline');return s.fetch(...args);});await b.pair();offline=true;await b.poll();
 for(const id of ['board','tray','reserve','total','moves','rate'])assert.equal(b.nodes.get(id).textContent,'—',id);
 assert.equal(b.nodes.get('connection').textContent,'Desconectado');assert.equal(b.nodes.get('batch').textContent,'Lote: sem leitura atual');
 assert.equal(b.nodes.get('export-status').textContent,'Estado da captura indisponível; atualize a conexão.');assert.equal(b.timers.size,0);
 offline=false;await b.click('reconnect');await new Promise(resolve=>setImmediate(resolve));
 assert.equal(b.nodes.get('total').textContent,'13');assert.match(b.nodes.get('reading').textContent,/Snapshot 2/);assert.equal(b.nodes.get('connection').textContent,'Pareado · LAN');
 assert.equal(s.calls.filter(r=>r.url==='/api/control').length,0);
});
test('capture controls reflect active recording ownership and export collection',async()=>{
 const current={capture:{recording:true,owned:false}},s=server(current),b=browser(s.fetch);await b.pair();
 for(const id of ['capture-start','capture-stop','report-export','sources-export'])assert.equal(b.nodes.get(id).disabled,true,id);
 current.capture={recording:true,owned:true};await b.poll();assert.equal(b.nodes.get('capture-start').disabled,true);assert.equal(b.nodes.get('capture-stop').disabled,false);
 for(const id of ['report-export','sources-export'])assert.equal(b.nodes.get(id).disabled,false,id);
 current.capture={recording:false,owned:true};await b.poll();assert.equal(b.nodes.get('capture-start').disabled,false);assert.equal(b.nodes.get('capture-stop').disabled,true);
 current.export={state:'collecting'};await b.poll();for(const id of ['capture-start','capture-stop','report-export','sources-export','download'])assert.equal(b.nodes.get(id).disabled,true,id);
});
test('hiding a paired page requests at most one pause and never starts an action',async()=>{
 const s=server(),b=browser(s.fetch);await b.pair();await b.click('start');b.document.visibilityState='hidden';b.document.handlers.visibilitychange();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(s.started,1);assert.equal(s.paused,1);assert.equal(b.timers.size,0);
});
test('hiding during an active download cancels transport and sends exactly one pause after it settles',async()=>{
 const s=server({export:{state:'ready',id:'11111111-1111-4111-8111-111111111111',bytes:300000}});let signal,started;
 const entered=new Promise(resolve=>{started=resolve;}),b=browser(async(url,options)=>{
  if(url!=='/api/export')return s.fetch(url,options);signal=options.signal;started();
  return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true}));
 });await b.pair();await b.click('start');const downloading=b.click('download');await entered;
 b.document.visibilityState='hidden';b.document.handlers.visibilitychange();assert.equal(signal.aborted,true);
 await downloading;assert.equal(s.started,1);assert.equal(s.paused,1);assert.equal(b.nodes.get('auto-state').textContent,'Pausado');assert.equal(b.timers.size,0);
 assert.deepEqual(s.calls.filter(r=>r.url==='/api/control').map(r=>JSON.parse(r.options.body).action),['start','pause']);
});
test('hiding during start waits for its known response before one pause, but never retries a lost command',async()=>{
 for(const lose of [false,true]){const s=server();let release;const b=browser(async(url,options)=>{
   const response=await s.fetch(url,options);if(url==='/api/control'&&JSON.parse(options.body).action==='start')await new Promise((resolve,reject)=>{release=()=>lose?reject(Error('lost')):resolve();});return response;
  });await b.pair();const pending=b.click('start');await new Promise(resolve=>setImmediate(resolve));
  b.document.visibilityState='hidden';b.document.handlers.visibilitychange();assert.equal(s.paused,0);release();await pending;
  assert.equal(s.started,1);assert.equal(s.paused,lose?0:1);assert.equal(b.timers.size,0);
  assert.deepEqual(s.calls.filter(r=>r.url==='/api/control').map(r=>JSON.parse(r.options.body).action),lose?['start']:['start','pause']);
 }
});
test('hiding while a manual pause is awaiting its response never queues another pause',async()=>{
 for(const lose of [false,true]){const s=server();let release;const b=browser(async(url,options)=>{
   const response=await s.fetch(url,options);if(url==='/api/control'&&JSON.parse(options.body).action==='pause'&&!release)await new Promise((resolve,reject)=>{release=()=>lose?reject(Error('lost')):resolve();});return response;
  });await b.pair();await b.click('start');const pending=b.click('pause');await new Promise(resolve=>setImmediate(resolve));
  assert.equal(s.paused,1);b.document.visibilityState='hidden';b.document.handlers.visibilitychange();release();await pending;
  assert.equal(s.paused,1);assert.equal(b.timers.size,0);
  assert.deepEqual(s.calls.filter(r=>r.url==='/api/control').map(r=>JSON.parse(r.options.body)),[{action:'start',sequence:1},{action:'pause',sequence:2}]);
  assert.equal(b.nodes.get('connection').textContent,lose?'Desconectado':'Pareado · LAN');
  assert.equal(b.nodes.get('auto-state').textContent,lose?'Auto: estado indisponível':'Pausado');
 }
});

test('experimental 10, 5 and 2 ms choices round-trip without starting Auto',async()=>{
 const s=server(),c=api.client(s.fetch);await c.pair('12345678');
 for(const [level,ms] of [[6,10],[7,5],[8,2]]){
  assert.equal(api.speeds[level-1].ms,ms);assert.match(api.speeds[level-1].name,/Teste/);
  await c.command('preferences',api.preferences(level,true,false,true));
  assert.equal((await c.state()).preferences.speedLevel,level);assert.equal(s.started,0);
 }
});

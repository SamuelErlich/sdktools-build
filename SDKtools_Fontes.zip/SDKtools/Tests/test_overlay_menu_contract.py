"""Production menu wiring regressions; these do not execute UIKit on Linux."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class OverlayMenuContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / "Sources/SDKtools/STOverlay.m").read_text()
        cls.controller = cls.source.split("@implementation STOverlayController", 1)[1].split("@implementation STOverlay\n", 1)[0]
        cls.owner = cls.source.split("@implementation STOverlay\n", 1)[1]

    def method(self, signature):
        section = self.owner.split(signature + " {", 1)[1]
        return section.split("\n- (", 1)[0]

    def test_xray_refresh_updates_existing_status_and_visibility(self):
        refresh = self.controller.split("- (void)refresh {", 1)[1]
        self.assertIn("self.xrayLabel.hidden=!r.xrayEnabled;", refresh)
        self.assertIn("STSetLabelText(self.xrayLabel,r.xrayStatusText);", refresh)
        self.assertEqual(self.controller.count("[alpaca addArrangedSubview:self.xrayLabel]"), 1)
        # Keep the existing status producer; don't replace observed failures with
        # a generic enabled label or trigger a new game read from the menu.
        self.assertNotRegex(refresh, r"(?:evaluateJavaScript|sampleWebView|snapshot)\s*[:(]")

    def test_complete_batch_status_wraps_inside_existing_capped_scroll_panel(self):
        self.assertIn("self.autoplayLabel.numberOfLines=0;", self.controller)
        self.assertNotIn("self.autoplayLabel.numberOfLines=2;", self.controller)
        self.assertIn("STSetLabelText(self.autoplayLabel,r.autoplayStatusText)", self.controller)
        self.assertIn("self.panelScroll.contentLayoutGuide", self.controller)
        self.assertIn("STCompactMenuFit(safe.size.width,safe.size.height,content.height)", self.controller)

    def test_all_gameplay_speed_preferences_check_live_context_before_mutation(self):
        for name, setter in [("toggleTurbo", "setTurboEnabled:"),
                             ("toggleSuperFast", "setSuperFastEnabled:"),
                             ("toggleExtendedPlanning", "setExtendedPlanning:"),
                             ("toggleAutoPowers", "setPowersEnabled:")]:
            with self.subTest(action=name):
                action = self.method("- (void)" + name)
                self.assertIn("clientAllowsGame:STClientGameAlpaca", action)
                self.assertLess(action.index("clientAllowsGame:STClientGameAlpaca"), action.index(setter))
        super_fast = self.method("- (void)toggleSuperFast")
        self.assertIn("STRecorder.shared.recording || STRecorder.shared.sourceExportBusy", super_fast)

    def test_language_dropdown_does_not_erase_the_selected_language_value(self):
        toggle = self.controller.split("- (void)toggleLanguageMenu {", 1)[1].split("\n- (", 1)[0]
        self.assertNotIn("accessibilityValue=", toggle)
        self.assertIn("UIAccessibilityLayoutChangedNotification", toggle)
        changed = self.controller.split("- (void)languageDidChange:", 1)[1].split("\n- (", 1)[0]
        self.assertIn("STLocalizeAccessibilityValue(self.languageButton,", changed)
        self.assertIn('@"Português":@"English"', changed)

    def test_long_localized_buttons_fit_without_reducing_touch_targets(self):
        helper = self.controller.split("- (UIButton *)button:", 1)[1].split("- (UIButton *)iconButton:", 1)[0]
        self.assertIn("button.titleLabel.adjustsFontSizeToFitWidth=YES", helper)
        scale = re.search(r"minimumScaleFactor=([0-9.]+)", helper)
        self.assertIsNotNone(scale)
        self.assertGreaterEqual(float(scale[1]), 0.8)
        self.assertIn("constraintEqualToConstant:44", helper)

    def test_source_extraction_stays_browser_only(self):
        self.assertNotIn("@selector(exportGameSources)", self.controller)
        panel = (ROOT / "Resources/LAN/panel.html").read_text()
        self.assertIn('id="sources-export"', panel)


if __name__ == "__main__":
    unittest.main()

// Executes the exact extracted production setters; no UIKit/game/network.
#import <Foundation/Foundation.h>
#include <assert.h>
#include <stdio.h>
#include "../Sources/SDKtools/STAutoplaySpeed.h"
@interface STRecorder : NSObject
@property NSUInteger lanBaseSpeed;
@property (nonatomic) BOOL superFastEnabled;
@property (nonatomic) BOOL turboEnabled;
@property BOOL pending;
@property (nonatomic) NSUInteger autoplayCardsPerBatch;
@property BOOL autoplayEnabled;
@property BOOL autoplayFastPending;
@property BOOL autoplayEvaluationMayAct;
@property NSUInteger autoplayResumeGeneration;
@property (nonatomic,strong) NSTimer *autoplayTimer;
@property NSUInteger arms;
@property NSUInteger notifications;
@property(readonly) NSUInteger autoplaySpeedLevel;
- (void)setAutoplaySpeedLevel:(NSUInteger)level;
@end
@implementation STRecorder
@synthesize autoplayCardsPerBatch = _autoplayCardsPerBatch;
@synthesize superFastEnabled = _superFastEnabled, turboEnabled = _turboEnabled;
- (void)ensureAutoplayTimer {self.arms++;}
- (void)notifyChange {self.notifications++;}
#include "lan_speed.inc"
@end
int main(void){@autoreleasepool{
    STRecorder *r=[STRecorder new];r.lanBaseSpeed=3;r.pending=YES;
    for(NSUInteger level=1;level<=8;level++){
        NSUInteger armsBefore=r.arms, noticesBefore=r.notifications;
        [r setAutoplaySpeedLevel:level];assert(r.autoplaySpeedLevel==level);assert(r.pending&&!r.autoplayEnabled);
        assert(r.arms==armsBefore+1 && r.notifications==noticesBefore+1);
        [r setAutoplaySpeedLevel:level]; assert(r.arms==armsBefore+1 && r.notifications==noticesBefore+1);
        assert(r.superFastEnabled==(level>=5));assert(r.turboEnabled==(level==4));
    }
    NSUInteger before=r.notifications;[r setAutoplaySpeedLevel:0];[r setAutoplaySpeedLevel:9];assert(r.notifications==before&&r.pending);
    [r setAutoplaySpeedLevel:8];r.superFastEnabled=NO;assert(r.autoplaySpeedLevel==3&&r.pending&&!r.autoplayEnabled);
    [r setAutoplaySpeedLevel:8];r.superFastEnabled=YES;assert(r.autoplaySpeedLevel==5&&r.pending);
    [r setAutoplaySpeedLevel:8];r.turboEnabled=YES;assert(r.autoplaySpeedLevel==4&&!r.superFastEnabled&&r.pending);
    [r setAutoplaySpeedLevel:8];r.turboEnabled=NO;assert(r.autoplaySpeedLevel==5&&r.pending);
    [r setAutoplaySpeedLevel:3];r.superFastEnabled=NO;assert(r.autoplaySpeedLevel==3);r.turboEnabled=YES;assert(r.autoplaySpeedLevel==4);r.superFastEnabled=YES;assert(r.autoplaySpeedLevel==5);
    // Exercise the production batch setter while an action is pending. It must
    // neither start Auto nor restart timers or release an in-flight batch.
    NSUserDefaults *defaults=NSUserDefaults.standardUserDefaults;
    NSString *key=@"SDKtools.autoplayCardsPerBatch";id saved=[defaults objectForKey:key];
    r.autoplayFastPending=YES;r.autoplayEvaluationMayAct=YES;r.autoplayResumeGeneration=7;
    NSTimer *timer=[NSTimer timerWithTimeInterval:60 repeats:NO block:^(__unused NSTimer *t){}];r.autoplayTimer=timer;
    NSUInteger arms=r.arms;
    for(NSUInteger count=1;count<=3;count++){
        [r setAutoplayCardsPerBatch:count];assert(r.autoplayCardsPerBatch==count);
        assert([defaults integerForKey:key]==(NSInteger)count);
        assert(!r.autoplayEnabled&&r.pending&&r.autoplayFastPending&&r.autoplayEvaluationMayAct);
        assert(r.autoplayResumeGeneration==7&&r.arms==arms&&r.autoplayTimer==timer&&timer.valid);
    }
    before=r.notifications;
    [r setAutoplayCardsPerBatch:3];[r setAutoplayCardsPerBatch:0];
    [r setAutoplayCardsPerBatch:4];[r setAutoplayCardsPerBatch:NSUIntegerMax];
    assert(r.autoplayCardsPerBatch==3&&r.notifications==before&&[defaults integerForKey:key]==3);
    r.autoplayEnabled=YES;[r setAutoplayCardsPerBatch:1];
    assert(r.autoplayEnabled&&r.autoplayFastPending&&r.autoplayEvaluationMayAct&&r.autoplayTimer==timer);
    if(saved)[defaults setObject:saved forKey:key];else [defaults removeObjectForKey:key];
    [timer invalidate];
    fprintf(stdout,"LAN speed and card batch setters: pass; pending latches unchanged\n");
}return 0;}

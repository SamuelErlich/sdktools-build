// Executes the exact extracted production setters; no UIKit/game/network.
#import <Foundation/Foundation.h>
#include <assert.h>
#include <stdio.h>
@interface STRecorder : NSObject
@property NSUInteger lanBaseSpeed;
@property BOOL superFastEnabled;
@property BOOL turboEnabled;
@property BOOL pending;
@property (nonatomic,strong) NSTimer *autoplayTimer;
@property NSUInteger arms;
@property NSUInteger notifications;
@property(readonly) NSUInteger autoplaySpeedLevel;
- (void)setAutoplaySpeedLevel:(NSUInteger)level;
@end
@implementation STRecorder
- (void)ensureAutoplayTimer {self.arms++;}
- (void)notifyChange {self.notifications++;}
#include "lan_speed.inc"
@end
int main(void){@autoreleasepool{
    STRecorder *r=[STRecorder new];r.lanBaseSpeed=3;r.pending=YES;
    for(NSUInteger level=1;level<=5;level++){
        [r setAutoplaySpeedLevel:level];assert(r.autoplaySpeedLevel==level);assert(r.pending);
        assert(r.superFastEnabled==(level==5));assert(r.turboEnabled==(level==4));
    }
    NSUInteger before=r.notifications;[r setAutoplaySpeedLevel:0];[r setAutoplaySpeedLevel:6];assert(r.notifications==before&&r.pending);
    r.superFastEnabled=NO;assert(r.autoplaySpeedLevel==3);r.turboEnabled=YES;assert(r.autoplaySpeedLevel==4);r.superFastEnabled=YES;assert(r.autoplaySpeedLevel==5);
    fprintf(stdout,"LAN speed profile setter: pass; pending latch unchanged\n");
}return 0;}

const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_tool.js'),'utf8');
const plannerSource=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_planner.js'),'utf8');
// Explicit synthetic preimages of layout tags. They are not recovered game names.
const names={bg:'\u0000\u0082\u00e3\u002e\u0048',diamond:'\u0000\u00e8\u00fb\u0069\u0078',mask:'\u0000\u00c6\u00e8\u0030\u00aa',tray:'\u0002\u00f8\u009a\u0044\u00db'};
function makeFixture(records=[{zone:'board',type:'a',x:-80,y:0},{zone:'board',type:'a',x:0,y:0},{zone:'board',type:'a',x:80,y:0}]){
 function Component(){} function Sprite(){} function Button(){} function EventHandler(){}
 function Touch(){} Touch.prototype.setTouchInfo=function(id,x,y){this.id=id;this.x=x;this.y=y;};Touch.prototype.getLocation=function(){return{x:this.x,y:this.y};};
 function EventTouch(touches,bubbles){this._touches=touches;this.bubbles=bubbles;this._eventCode=0;this.touch=null;}
 EventTouch.ENDED=2;EventTouch.prototype._setEventCode=function(code){this._eventCode=code;};EventTouch.prototype.getEventCode=function(){return this._eventCode;};EventTouch.prototype.getTouches=function(){return this._touches;};EventTouch.prototype.getLocation=function(){return this.touch.getLocation();};
 const calls=[],frames=new Map(),cards=[];
 Component.EventHandler=EventHandler;
 EventHandler.prototype.emit=function(args){calls.push({event:this,args});};
 function node(w=20,h=20,kids=[],extra={}){const n={width:w,height:h,x:0,y:0,z:0,anchorX:.5,anchorY:.5,angle:0,scaleX:1,scaleY:1,opacity:255,isValid:true,active:true,activeInHierarchy:true,children:kids,parent:null,comps:[],...extra};for(const c of kids)c.parent=n;n.getComponent=k=>n.comps.find(c=>c.kind===k||c.className===k)||null;n.getComponents=()=>n.comps;n.convertToWorldSpaceAR=p=>({x:n.x+p.x,y:n.y+p.y});return n;}
 function sprite(n,name){if(!frames.has(name))frames.set(name,{name,getRect:()=>({width:120,height:135})});const s={kind:Sprite,node:n,spriteFrame:frames.get(name),enabled:true,enabledInHierarchy:true};n.comps.push(s);return s;}
 const board=node(560,720,[],{y:67}),tray=node(560,80,[],{y:10}),reserve=node(240,90,[],{y:-420.594});
 const trayBg=node(600,130,[tray]);sprite(trayBg,names.tray);
 const boardLayer=node(750,1623.188,[board]),trayLayer=node(750,1623.188,[trayBg]),reserveLayer=node(750,1623.188,[reserve]);
 const game=node(750,1623.188,[boardLayer,trayLayer,reserveLayer]);const root=node(0,0,[game],{active:false});
 for(const r of records){const face=node(80,90);sprite(face,'mock_face_'+r.type);const bg=node(80,90,[face]);sprite(bg,r.backgroundTag==='6be7dcd3'?names.diamond:names.bg);const mask=node(80,90,[],{opacity:128,active:!!r.mask,activeInHierarchy:!!r.mask});sprite(mask,names.mask);
  const card=node(80,90,[bg,node(20,20,[],{active:false,activeInHierarchy:false}),mask,node(20,20,[],{active:false,activeInHierarchy:false}),node(20,20,[],{active:false,activeInHierarchy:false})],{x:r.x||0,y:r.y||0});
  const receiver={kind:Component,className:'MockBlock',isValid:true,node:card,touchBlock(){throw Error('Direct callback forbidden in test');}};card.comps.push(receiver);
  const event=new EventHandler();Object.assign(event,{target:card,component:'MockBlock',handler:'touchBlock',customEventData:''});
  const button={kind:Button,isValid:true,node:card,enabled:true,enabledInHierarchy:true,interactable:!r.mask,clickEvents:[event]};card.comps.push(button);
  const parent=r.zone==='tray'?tray:r.zone==='reserve'?reserve:board;parent.children.push(card);card.parent=parent;cards.push({node:card,button,event,receiver,face,bg,mask,type:r.type,observedID:r.id});
 }
 const cc={ENGINE_VERSION:'2.4.4',Component,Sprite,Button,Touch,Event:{EventTouch,AT_TARGET:2},Node:{EventType:{TOUCH_END:'touchend'}},v2:(x,y)=>({x,y}),js:{getClassName:c=>c.className||'Other'},director:{getScene:()=>root}};
 return{cc,node,sprite,board,tray,reserve,root,game,cards,calls,frames,EventHandler};
}
// The adapter uses performance.now; its embedded planner uses Date.now. Both
// must share controlled time so scheduler delays cannot consume the 8ms budget.
function setup(f,{planner,clockStep=0}={}){let now=0;const win={cc:f.cc};win.top=win;const context=vm.createContext({window:win,document:{visibilityState:'visible',readyState:'complete'},performance:{now:()=>{now+=clockStep;return now;}},Date:{now:()=>now},input:null,planner:planner||null});
 vm.runInContext('var runtime=('+source+')(planner||('+plannerSource+'));',context,{timeout:500});
 return{context,advance:n=>{now+=n;},tick(options={}){context.input={command:'tick',allowAction:true,resumeGeneration:1,...options};return JSON.parse(JSON.stringify(vm.runInContext('runtime(input)',context,{timeout:1000})));}};
}
function reachDispatch(f,rt=setup(f)){assert.equal(rt.tick().status,'waiting_stability');rt.advance(250);assert.equal(rt.tick().reason,'plan_ready');rt.advance(250);const result=rt.tick();assert.equal(result.status,'original_event_dispatched',JSON.stringify(result));return rt;}
function move(f,card,to){const a=card.node.parent.children;a.splice(a.indexOf(card.node),1);to.children.push(card.node);card.node.parent=to;card.node.x=-240+80*(to.children.length-1);card.node.y=0;card.mask.active=false;card.mask.activeInHierarchy=false;}

test('plans on one tick and emits exact registered event with a real engine touch event on following revalidated tick',()=>{const f=makeFixture();reachDispatch(f);assert.equal(f.calls.length,1);assert.equal(f.calls[0].args.length,1);const e=f.calls[0].args[0];assert.ok(e instanceof f.cc.Event.EventTouch);assert.equal(e.target,f.calls[0].event.target);assert.equal(e.currentTarget,e.target);assert.equal(e.type,'touchend');assert.equal(e.getEventCode(),2);assert.equal(e.getTouches()[0],e.touch);assert.equal(e.getLocation().x,e.target.x);assert.equal(e.getLocation().y,e.target.y);});
test('waiting result never repeats even after eight seconds or pause reset resume',()=>{const f=makeFixture(),rt=reachDispatch(f);rt.advance(9000);assert.equal(rt.tick().reason,'confirmation_uncertain');for(const cmd of ['pause','reset'])assert.equal(rt.tick({command:cmd}).awaitingBoardChange,true);rt.advance(1000);assert.equal(rt.tick({resumeGeneration:3}).awaitingBoardChange,true);assert.equal(f.calls.length,1);});
test('same identity in tray and exact correlated state must settle twice before confirmation',()=>{const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);const r=rt.tick();assert.equal(r.status,'move_confirmed');assert.equal(r.confirmedMoves,1);assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,1);});
test('unrelated removal cannot confirm selected card movement',()=>{const f=makeFixture(),rt=reachDispatch(f),other=f.cards.find(c=>c.event!==f.calls[0].event);move(f,other,f.tray);rt.advance(250);assert.equal(rt.tick().status,'waiting_confirmation');assert.equal(f.calls.length,1);});
test('matching trio removal is confirmed only with exact remaining tray and board identities',()=>{const f=makeFixture([{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0},{zone:'tray',type:'a',x:-160,y:0}]),rt=reachDispatch(f);f.board.children=[];f.tray.children=[];for(const c of f.cards)c.node.parent=null;rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);assert.equal(rt.tick().status,'move_confirmed');});
test('throwing original event preserves uncertain pending and never repeats',()=>{const f=makeFixture();f.EventHandler.prototype.emit=function(){f.calls.push('attempt');throw Error('original');};const rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);assert.equal(rt.tick().status,'dispatch_uncertain');rt.advance(10000);assert.equal(rt.tick().awaitingBoardChange,true);assert.equal(f.calls.length,1);});
test('original no-op stays pending with no invented success',()=>{const f=makeFixture(),rt=reachDispatch(f);rt.advance(1000);assert.equal(rt.tick().confirmedMoves,0);});
test('action-disabled ticks never dispatch and discard prepared plan',()=>{const f=makeFixture(),rt=setup(f);assert.equal(rt.tick({allowAction:false}).status,'watching');rt.advance(250);rt.tick();rt.advance(250);rt.tick();assert.equal(rt.tick({allowAction:false}).status,'watching');rt.advance(250);assert.equal(rt.tick().status,'waiting_stability');assert.equal(f.calls.length,0);});
test('changed generation restarts stability without dispatching stale plan',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);assert.equal(rt.tick({resumeGeneration:2}).reason,'observing_board');assert.equal(f.calls.length,0);});
test('changed board after planning invalidates the prepared selection',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();f.cards[0].node.x=-160;rt.advance(250);assert.equal(rt.tick().reason,'observing_board');assert.equal(f.calls.length,0);});
test('only exposed unmasked registered controls can be selected',()=>{const f=makeFixture([{zone:'board',type:'a',x:0,y:0,mask:true},{zone:'board',type:'a',x:0,y:0}]);const rt=reachDispatch(f);assert.equal(f.calls[0].event,f.cards[1].event);assert.equal(rt.tick().awaitingBoardChange,true);});
test('mask and computed overlap disagreement blocks',()=>{const f=makeFixture();f.cards[0].mask.active=true;f.cards[0].mask.activeInHierarchy=true;assert.equal(setup(f).tick().reason,'occlusion_mismatch');assert.equal(f.calls.length,0);});
test('unknown face and changing card effect stop state acquisition',()=>{const f=makeFixture();f.cards[0].face.comps[0].spriteFrame.name='';assert.equal(setup(f).tick().reason,'unknown_card');const g=makeFixture();g.cards[0].node.children[3].active=true;g.cards[0].node.children[3].activeInHierarchy=true;assert.equal(setup(g).tick().reason,'card_effect_active');});
test('full frame object plus full name distinguishes synthetic same-name objects',()=>{const f=makeFixture();const old=f.cards[1].face.comps[0].spriteFrame;f.cards[1].face.comps[0].spriteFrame={...old};let observed;const rt=setup(f,{planner:input=>{observed=input;return{status:'blocked'};}});rt.tick();rt.advance(250);rt.tick();assert.notEqual(observed.cards[0].type,observed.cards[1].type);});
test('disabled control is excluded and malicious planner choice rejected',()=>{const f=makeFixture();f.cards[0].button.interactable=false;const rt=setup(f,{planner:input=>({status:'move',cardID:input.cards[0].id})});rt.tick();rt.advance(250);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);});
test('invalid target or duplicate touchBlock handlers cannot dispatch',()=>{for(const change of[f=>{f.cards[0].event.target=f.root;},f=>{f.cards[0].node.comps.push({...f.cards[0].receiver});}]){const f=makeFixture();change(f);assert.equal(setup(f).tick().status,'blocked');assert.equal(f.calls.length,0);}});
test('custom data and replaced original emitter instance fail closed',()=>{for(const change of[f=>{f.cards[0].event.customEventData='payload';},f=>{f.cards[0].event.emit=()=>{};}]){const f=makeFixture();change(f);assert.equal(setup(f).tick().reason,'event_mismatch');}});
test('modal before action cancels and pauses original event dispatch',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();const modal=f.node(240,102);f.root.children.push(modal);modal.parent=f.root;rt.advance(250);assert.equal(rt.tick().reason,'modal_visible');assert.equal(f.calls.length,0);});
test('unsupported version, hidden document and conflicting versions block',()=>{const f=makeFixture(),rt=setup(f);rt.context.window.CocosEngine='2.4.5';assert.equal(rt.tick().reason,'engine_version');const g=makeFixture(),rg=setup(g);rg.context.document.visibilityState='hidden';assert.equal(rg.tick().reason,'document_unavailable');});
test('offscreen startup tween and tray tween are never actionable',()=>{const f=makeFixture();f.cards[0].node.x=400;assert.equal(setup(f).tick().reason,'animation_active');const g=makeFixture([{zone:'tray',type:'a',x:-240,y:1}]);assert.equal(setup(g).tick().reason,'animation_active');});
test('unknown tray layout, full bar and duplicate board block',()=>{const f=makeFixture();f.tray.width=640;assert.equal(setup(f).tick().reason,'board_ambiguous');const g=makeFixture(Array.from({length:7},(_,i)=>({zone:'tray',type:'a'+i,x:-240+80*i,y:0})));assert.equal(setup(g).tick().reason,'tray_full');const h=makeFixture();const extra=h.node(560,720);h.game.children.push(extra);extra.parent=h.game;assert.equal(setup(h).tick().reason,'board_ambiguous');});
test('snapshot budget exit cannot dispatch',()=>{const f=makeFixture(),rt=setup(f,{clockStep:1});assert.equal(rt.tick().reason,'time_budget');assert.equal(f.calls.length,0);});
test('embedded planner budget still prevents dispatch when its injected clock expires',()=>{const f=makeFixture(),rt=setup(f);let plannerNow=0;rt.context.Date.now=()=>{plannerNow+=8;return plannerNow;};assert.equal(rt.tick().status,'waiting_stability');rt.advance(250);assert.equal(rt.tick().reason,'no_safe_move');assert.equal(f.calls.length,0);});
test('stable replacement scene retires old pending without counting a success or replaying',()=>{const f=makeFixture(),rt=reachDispatch(f),other=makeFixture();rt.context.window.cc=other.cc;rt.advance(250);const r=rt.tick();assert.equal(r.reason,'new_board_stability');assert.equal(r.awaitingBoardChange,true);rt.advance(250);const settled=rt.tick();assert.equal(settled.reason,'new_board_detected');assert.equal(settled.confirmedMoves,0);assert.equal(settled.awaitingBoardChange,false);assert.equal(f.calls.length,1);assert.equal(other.calls.length,0);});
test('resource is bounded and contains no network, captured code execution or injected timer',()=>{assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout)\s*\(/);assert.doesNotMatch(source,/new\s+Function\b/);});

const fixturePath=path.join(__dirname,'fixtures/autoplay-board-observed-v25.json');
test('replays 228 real captured card geometries with explicit synthetic method mocks',()=>{const observed=JSON.parse(fs.readFileSync(fixturePath,'utf8'));assert.equal(observed.sequence,133);const f=makeFixture(observed.cards);let input;const rt=setup(f,{planner:value=>{input=value;return{status:'blocked'};}});const first=rt.tick();assert.equal(first.cardsRead,228,JSON.stringify(first));assert.equal(first.status,'waiting_stability',JSON.stringify(first));rt.advance(250);assert.equal(rt.tick().reason,'no_safe_move');assert.equal(input.cards.length,228);assert.equal(input.cards.filter(c=>c.zone==='board').length,225);assert.equal(input.cards.filter(c=>c.blockedBy.length>0).length,180);assert.equal(input.cards.filter(c=>c.available).length,48);assert.equal(new Set(input.cards.map(c=>c.type)).size,16);assert.equal(input.tray.length,0);assert.equal(input.capacity,7);assert.equal(f.calls.length,0);});

test('transient seventh tray card preserves pending until original trio settles',()=>{
 const records=[...['a','b','b','c','c','d','d','e','e'].map((type,i)=>({zone:'board',type,x:-240+80*(i%7),y:Math.floor(i/7)*90})),...['a','a','b','c','d','e'].map((type,i)=>({zone:'tray',type,x:-240+80*i,y:0}))];
 const f=makeFixture(records),rt=reachDispatch(f),picked=f.cards[0];move(f,picked,f.tray);rt.advance(250);
 const transient=rt.tick();assert.equal(transient.reason,'tray_full');assert.equal(transient.awaitingBoardChange,true);assert.equal(f.calls.length,1);
 for(const c of f.cards.filter(c=>c.type==='a'))c.node.parent=null;
 f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('new board container in same scene retires old pending after stability without replay',()=>{
 const f=makeFixture(),rt=reachDispatch(f),other=makeFixture();f.root.children=[other.game];other.game.parent=f.root;other.cc.director.getScene=()=>f.root;rt.context.window.cc=other.cc;
 rt.advance(250);assert.equal(rt.tick().reason,'new_board_stability');rt.advance(250);const r=rt.tick();assert.equal(r.reason,'new_board_detected');assert.equal(r.confirmedMoves,0);assert.equal(f.calls.length,1);assert.equal(other.calls.length,0);
});

test('real planner and guarded adapter continuously complete two triples with six confirmed original events',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i,y:0})));
 f.EventHandler.prototype.emit=function(args){
  f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);
  const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);
  if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}
  f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 };
 const rt=setup(f);let r,confirmationCount=0;
 for(let i=0;i<100;i++){
  const before=f.calls.length;rt.advance(250);r=rt.tick();assert.ok(f.calls.length-before<=1,'at most one original event per tick');
  assert.notEqual(r.status,'dispatch_uncertain');assert.notEqual(r.reason,'read_error');
  if(r.status==='move_confirmed')confirmationCount++;
  if(r.confirmedMoves===6)break;
 }
 assert.equal(r.confirmedMoves,6);assert.equal(confirmationCount,6);assert.equal(f.calls.length,6);assert.equal(f.board.children.length,0);assert.equal(f.tray.children.length,0);assert.equal(r.awaitingBoardChange,false);
});

const v26Fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v26.json'),'utf8'));
function observedV26(sequence){return v26Fixture.snapshots.find(s=>s.sequence===sequence).cards.map(row=>Object.fromEntries(v26Fixture.columns.map((key,i)=>[key,row[i]])));}
function applyObservedState(f,records){
 for(const parent of [f.board,f.tray,f.reserve])parent.children=[];
 for(const r of records){
  const c=f.cards.find(c=>c.observedID===r.id);assert.ok(c,'captured identity must remain present');assert.equal(c.type,r.type);
  const parent=r.zone==='tray'?f.tray:r.zone==='reserve'?f.reserve:f.board;
  parent.children.push(c.node);c.node.parent=parent;c.node.x=r.x;c.node.y=r.y;
  c.mask.active=r.mask;c.mask.activeInHierarchy=r.mask;c.button.interactable=!r.mask;
 }
}
for(const [seq,board,tray,reserve] of [[2,225,0,0],[30,224,1,0],[51,225,0,0],[120,222,3,0],[147,222,0,3]]){
 test('new real capture seq '+seq+' reads all 225 cards and plans with observed tray/reserve geometry',()=>{
  const records=observedV26(seq),f=makeFixture(records),rt=setup(f);
  const types=new Map();for(const c of records){if(!types.has(c.type))types.set(c.type,new Set());types.get(c.type).add(c.frameID);}
  assert.equal(types.size,16);for(const frames of types.values())assert.equal(frames.size,1,'no cloned SpriteFrame identity is observed per type');
  assert.equal(f.board.children.length,board);assert.equal(f.tray.children.length,tray);assert.equal(f.reserve.children.length,reserve);
  const first=rt.tick();assert.equal(first.status,'waiting_stability',JSON.stringify(first));assert.equal(first.cardsRead,225);assert.equal(first.cardTypesRead,16);
  rt.advance(250);assert.equal(rt.tick().reason,'plan_ready');rt.advance(250);assert.equal(rt.tick().status,'original_event_dispatched');
  assert.equal(f.calls.length,1);assert.equal(f.calls[0].event.target.getComponent(f.cc.Button).interactable,true);
 });
}
test('captured seq 2 to 30 is confirmed using unchanged card identity and actual observed tray/mask changes',()=>{
 const f=makeFixture(observedV26(2)),chosen=f.cards.find(c=>c.observedID==='n920'),index=f.cards.indexOf(chosen);
 const rt=setup(f,{planner:input=>({status:'move',cardID:input.cards[index].id})});reachDispatch(f,rt);
 assert.equal(f.calls[0].event,chosen.event);applyObservedState(f,observedV26(30));
 rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);assert.equal(rt.tick().status,'move_confirmed');
 assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});
test('captured tray-to-reserve power effect never masquerades as an autoplay move confirmation',()=>{
 const f=makeFixture(observedV26(120)),rt=reachDispatch(f);applyObservedState(f,observedV26(147));
 rt.advance(250);const r=rt.tick();assert.equal(r.status,'waiting_confirmation');assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);assert.equal(f.calls.length,1);
});
test('bounded type-count diagnostic resets when complete state is unavailable',()=>{
 const f=makeFixture(),rt=setup(f);assert.equal(rt.tick().cardTypesRead,1);
 f.cards[0].face.comps[0].spriteFrame.name='';const blocked=rt.tick();assert.equal(blocked.reason,'unknown_card');assert.equal(blocked.cardTypesRead,0);
 assert.equal(rt.tick({command:'pause'}).cardTypesRead,0);
});
test('registered callback consuming event.target receives an EventTouch and changes the board once',()=>{
 const f=makeFixture();
 for(const card of f.cards)card.receiver.touchBlock=function(event){
  assert.ok(event instanceof f.cc.Event.EventTouch);assert.equal(event.getEventCode(),2);
  assert.equal(event.target,this.node);assert.equal(event.currentTarget,this.node);move(f,card,f.tray);
 };
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});this.target.getComponent(this.component)[this.handler](...args);};
 const rt=reachDispatch(f);assert.equal(f.tray.children.length,1);rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');
 rt.advance(250);assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});
test('missing touch contract or nonfinite world coordinates blocks before any original event or pending state',()=>{
 for(const change of [f=>{delete f.cc.Touch;},f=>{f.cc.Event.EventTouch.ENDED=0;},f=>{for(const c of f.cards)c.node.convertToWorldSpaceAR=()=>({x:NaN,y:0});},f=>{delete f.cc.Event.EventTouch.prototype._setEventCode;}]){
  const f=makeFixture();change(f);const rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);
  const r=rt.tick();assert.equal(r.reason,'input_event_unavailable');assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,0);
 }
});

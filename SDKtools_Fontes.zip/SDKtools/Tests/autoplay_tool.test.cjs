const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_tool.js'),'utf8');
const plannerSource=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_planner.js'),'utf8');
const xraySource=fs.readFileSync(path.join(__dirname,'../Resources/xray_overlay.js'),'utf8');
// Explicit synthetic preimages of layout tags. They are not recovered game names.
const names={bg:'\u0000\u0082\u00e3\u002e\u0048',diamond:'\u0000\u00e8\u00fb\u0069\u0078',mask:'\u0000\u00c6\u00e8\u0030\u00aa',tray:'\u0002\u00f8\u009a\u0044\u00db',warehouse:'\u442d\u2c08'};
function makeFixture(records=[{zone:'board',type:'a',x:-80,y:0},{zone:'board',type:'a',x:0,y:0},{zone:'board',type:'a',x:80,y:0}]){
 function Component(){} function Sprite(){} function Button(){} function EventHandler(){}
 function Touch(){} Touch.prototype.setTouchInfo=function(id,x,y){this.id=id;this.x=x;this.y=y;};Touch.prototype.getLocation=function(){return{x:this.x,y:this.y};};
 function EventTouch(touches,bubbles){this._touches=touches;this.bubbles=bubbles;this._eventCode=0;this.touch=null;}
 EventTouch.ENDED=2;EventTouch.prototype._setEventCode=function(code){this._eventCode=code;};EventTouch.prototype.getEventCode=function(){return this._eventCode;};EventTouch.prototype.getTouches=function(){return this._touches;};EventTouch.prototype.getLocation=function(){return this.touch.getLocation();};
 const calls=[],frames=new Map(),cards=[],typeIDs=new Map();
 Component.EventHandler=EventHandler;
 EventHandler.prototype.emit=function(args){calls.push({event:this,args});};
 function node(w=20,h=20,kids=[],extra={}){const n={width:w,height:h,x:0,y:0,z:0,anchorX:.5,anchorY:.5,angle:0,scaleX:1,scaleY:1,opacity:255,isValid:true,active:true,activeInHierarchy:true,children:kids,parent:null,comps:[],...extra};for(const c of kids)c.parent=n;n.getComponent=k=>n.comps.find(c=>c.kind===k||c.className===k)||null;n.getComponents=()=>n.comps;n.convertToWorldSpaceAR=p=>({x:n.x+p.x,y:n.y+p.y});return n;}
 function sprite(n,name){if(!frames.has(name))frames.set(name,{name,getRect:()=>({width:120,height:135})});const s={kind:Sprite,node:n,spriteFrame:frames.get(name),enabled:true,enabledInHierarchy:true};n.comps.push(s);return s;}
 const board=node(560,720,[],{y:67}),tray=node(560,80,[],{y:10}),reserve=node(240,90,[],{y:-420.594});
 const trayBg=node(600,130,[tray]);sprite(trayBg,names.tray);
 const boardLayer=node(750,1623.188,[board]),trayLayer=node(750,1623.188,[trayBg]),reserveLayer=node(750,1623.188,[reserve]);
 const game=node(750,1623.188,[boardLayer,trayLayer,reserveLayer]);const root=node(0,0,[game],{active:false});
 for(const r of records){const face=node(80,90);sprite(face,'mock_face_'+r.type);const bg=node(80,90,[face]);sprite(bg,r.backgroundTag==='6be7dcd3'?names.diamond:names.bg);const mask=node(80,90,[],{opacity:128,active:!!r.mask,activeInHierarchy:!!r.mask});sprite(mask,names.mask);
  const card=node(80,90,[bg,node(20,20,[],{active:false,activeInHierarchy:false}),mask,node(20,20,[],{active:false,activeInHierarchy:false}),node(20,20,[],{active:false,activeInHierarchy:false})],{x:r.x||0,y:r.y||0});
  if(!typeIDs.has(r.type))typeIDs.set(r.type,typeIDs.size+1);
  const gridRow=(card.x+240)/5,gridCol=(315-card.y)/4.5,layer=r.layer===undefined?cards.length:r.layer;
  const receiver={kind:Component,className:'Block',isValid:true,node:card,canTouch:r.zone!=='tray'&&!r.mask,isTouched:false,
   blockInfo:{id:r.rawID||`${layer}-${gridRow}-${gridCol}`,type:r.numericType===undefined?typeIDs.get(r.type):r.numericType,state:r.zone==='tray'?1:r.zone==='reserve'?2:0,layer,row:gridRow,col:gridCol},
   BgSprite:bg.comps[0],SkinSprite:face.comps[0],MaskNode:mask,SpecialNode:card.children[1],HotTimeAnimNode:card.children[3],BombAnimNode:card.children[4],
   touchBlock(){throw Error('Direct callback forbidden in test');}};card.comps.push(receiver);
  const event=new EventHandler();Object.assign(event,{target:card,component:'Block',handler:'touchBlock',customEventData:''});
  const button={kind:Button,isValid:true,node:card,enabled:true,enabledInHierarchy:true,interactable:r.zone!=='tray'&&!r.mask,clickEvents:[event]};card.comps.push(button);
  const parent=r.zone==='tray'?tray:r.zone==='reserve'?reserve:board;parent.children.push(card);card.parent=parent;cards.push({node:card,button,event,receiver,face,bg,mask,type:r.type,observedID:r.id});
 }
 const cc={ENGINE_VERSION:'2.4.4',Component,Sprite,Button,Touch,Event:{EventTouch,AT_TARGET:2},Node:{EventType:{TOUCH_END:'touchend'}},v2:(x,y)=>({x,y}),js:{getClassName:c=>c.className||'Other'},director:{getScene:()=>root}};
 return{cc,node,sprite,board,tray,reserve,root,game,cards,calls,frames,EventHandler};
}
// The adapter uses performance.now; its embedded planner uses Date.now. Both
// must share controlled time so scheduler delays cannot consume the 8ms budget.
function setup(f,{planner,clockStep=0,xrayFactory}={}){let now=0;const win={cc:f.cc,...(f.loader?{__require:f.loader}:{})};win.top=win;const context=vm.createContext({window:win,document:{visibilityState:'visible',readyState:'complete'},performance:{now:()=>{now+=clockStep;return now;}},Date:{now:()=>now},input:null,planner:planner||null,xrayFactory:xrayFactory||null});
 vm.runInContext('var runtime=('+source+')(planner||('+plannerSource+'),xrayFactory||('+xraySource+'));',context,{timeout:500});
 return{context,advance:n=>{now+=n;},tick(options={}){context.input={command:'tick',allowAction:true,resumeGeneration:1,...options};return JSON.parse(JSON.stringify(vm.runInContext('runtime(input)',context,{timeout:1000})));}};
}
function reachDispatch(f,rt=setup(f)){assert.equal(rt.tick().status,'waiting_stability');rt.advance(250);assert.equal(rt.tick().reason,'plan_ready');rt.advance(250);const result=rt.tick();assert.equal(result.status,'original_event_dispatched',JSON.stringify(result));return rt;}
function move(f,card,to){const a=card.node.parent.children;a.splice(a.indexOf(card.node),1);to.children.push(card.node);card.node.parent=to;card.node.x=-240+80*(to.children.length-1);card.node.y=0;card.mask.active=false;card.mask.activeInHierarchy=false;card.receiver.blockInfo.state=to===f.tray?1:to===f.reserve?2:0;card.receiver.canTouch=to!==f.tray;card.button.interactable=to!==f.tray;}

function directProof(input,firstID){
 const first=input.cards.find(c=>c.id===firstID),existing=input.tray.filter(c=>c.type===first.type);
 const selected=[first,...input.cards.filter(c=>c.id!==firstID&&c.available&&c.type===first.type)].slice(0,3-existing.length);
 const sequence=selected.map(c=>c.id);return{status:'move',proofKind:'local_trio',cardID:firstID,sequence,actions:sequence.slice(),matchedType:first.type,
  tripleCardIDs:[...existing,...selected].map(c=>c.id),peakTrayCount:input.tray.length+sequence.length};
}
test('plans on one tick and emits exact registered event with a real engine touch event on following revalidated tick',()=>{const f=makeFixture();reachDispatch(f);assert.equal(f.calls.length,1);assert.equal(f.calls[0].args.length,1);const e=f.calls[0].args[0];assert.ok(e instanceof f.cc.Event.EventTouch);assert.equal(e.target,f.calls[0].event.target);assert.equal(e.currentTarget,e.target);assert.equal(e.type,'touchend');assert.equal(e.getEventCode(),2);assert.equal(e.getTouches()[0],e.touch);assert.equal(e.getLocation().x,e.target.x);assert.equal(e.getLocation().y,e.target.y);});
test('waiting result never repeats even after eight seconds or pause reset resume',()=>{const f=makeFixture(),rt=reachDispatch(f);rt.advance(9000);assert.equal(rt.tick().reason,'confirmation_uncertain');for(const cmd of ['pause','reset'])assert.equal(rt.tick({command:cmd}).awaitingBoardChange,true);rt.advance(1000);assert.equal(rt.tick({resumeGeneration:3}).awaitingBoardChange,true);assert.equal(f.calls.length,1);});
test('same identity in tray and exact correlated state must settle twice before confirmation',()=>{const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);const r=rt.tick();assert.equal(r.status,'move_confirmed');assert.equal(r.confirmedMoves,1);assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,1);});
test('unrelated removal cannot confirm selected card movement',()=>{const f=makeFixture(),rt=reachDispatch(f),other=f.cards.find(c=>c.event!==f.calls[0].event);move(f,other,f.tray);rt.advance(250);assert.equal(rt.tick().status,'waiting_confirmation');assert.equal(f.calls.length,1);});
test('matching trio removal is confirmed only with exact remaining tray and board identities',()=>{const f=makeFixture([{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0},{zone:'tray',type:'a',x:-160,y:0}]),rt=reachDispatch(f);f.board.children=[];f.tray.children=[];for(const c of f.cards)c.node.parent=null;rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);assert.equal(rt.tick().status,'move_confirmed');});
test('throwing original event preserves uncertain pending and never repeats',()=>{const f=makeFixture();f.EventHandler.prototype.emit=function(){f.calls.push('attempt');throw Error('original');};const rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);assert.equal(rt.tick().status,'dispatch_uncertain');rt.advance(10000);assert.equal(rt.tick().awaitingBoardChange,true);assert.equal(f.calls.length,1);});
test('original no-op stays pending with no invented success',()=>{const f=makeFixture(),rt=reachDispatch(f);rt.advance(1000);assert.equal(rt.tick().confirmedMoves,0);});
test('action-disabled ticks never dispatch and discard prepared plan',()=>{const f=makeFixture(),rt=setup(f);assert.equal(rt.tick({allowAction:false}).status,'watching');rt.advance(250);rt.tick();rt.advance(250);rt.tick();assert.equal(rt.tick({allowAction:false}).status,'watching');rt.advance(250);assert.equal(rt.tick().status,'waiting_stability');assert.equal(f.calls.length,0);});
test('changed generation restarts stability without dispatching stale plan',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);assert.equal(rt.tick({resumeGeneration:2}).reason,'observing_board');assert.equal(f.calls.length,0);});
test('changed board after planning invalidates the prepared selection',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();f.cards[0].node.x=-160;rt.advance(250);assert.equal(rt.tick().reason,'animation_active');assert.equal(f.calls.length,0);});
test('only exposed unmasked registered controls can be selected',()=>{const f=makeFixture([{zone:'board',type:'a',x:0,y:0,mask:true},{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0}]);const rt=reachDispatch(f);assert.equal(f.calls[0].event,f.cards[1].event);assert.equal(rt.tick().awaitingBoardChange,true);});
test('mask and computed overlap disagreement blocks',()=>{const f=makeFixture();f.cards[0].mask.active=true;f.cards[0].mask.activeInHierarchy=true;assert.equal(setup(f).tick().reason,'occlusion_mismatch');assert.equal(f.calls.length,0);});
test('unknown face and changing card effect stop state acquisition',()=>{const f=makeFixture();f.cards[0].face.comps[0].spriteFrame.name='';assert.equal(setup(f).tick().reason,'unknown_card');const g=makeFixture();g.cards[0].node.children[3].active=true;g.cards[0].node.children[3].activeInHierarchy=true;assert.equal(setup(g).tick().reason,'card_effect_active');});
test('matching uses original numeric block type even when same skin has different SpriteFrame objects',()=>{const f=makeFixture();const old=f.cards[1].face.comps[0].spriteFrame;f.cards[1].face.comps[0].spriteFrame={...old};let observed;const rt=setup(f,{planner:input=>{observed=input;return{status:'blocked'};}});rt.tick();rt.advance(250);rt.tick();assert.equal(observed.cards[0].type,observed.cards[1].type);});
test('disabled control is excluded and malicious planner choice rejected',()=>{const f=makeFixture();f.cards[0].button.interactable=false;f.cards[0].receiver.canTouch=false;const rt=setup(f,{planner:input=>({status:'move',cardID:input.cards[0].id})});rt.tick();rt.advance(250);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);});
test('invalid target or duplicate touchBlock handlers cannot dispatch',()=>{for(const change of[f=>{f.cards[0].event.target=f.root;},f=>{f.cards[0].node.comps.push({...f.cards[0].receiver});}]){const f=makeFixture();change(f);assert.equal(setup(f).tick().status,'blocked');assert.equal(f.calls.length,0);}});
test('custom data and replaced original emitter instance fail closed',()=>{for(const change of[f=>{f.cards[0].event.customEventData='payload';},f=>{f.cards[0].event.emit=()=>{};}]){const f=makeFixture();change(f);assert.equal(setup(f).tick().reason,'event_mismatch');}});
test('modal before action cancels and pauses original event dispatch',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();const modal=f.node(240,102);f.root.children.push(modal);modal.parent=f.root;rt.advance(250);assert.equal(rt.tick().reason,'modal_visible');assert.equal(f.calls.length,0);});
test('unsupported version, hidden document and conflicting versions block',()=>{const f=makeFixture(),rt=setup(f);rt.context.window.CocosEngine='2.4.5';assert.equal(rt.tick().reason,'engine_version');const g=makeFixture(),rg=setup(g);rg.context.document.visibilityState='hidden';assert.equal(rg.tick().reason,'document_unavailable');});
test('offscreen startup tween and tray tween are never actionable',()=>{const f=makeFixture();f.cards[0].node.x=400;assert.equal(setup(f).tick().reason,'animation_active');const g=makeFixture([{zone:'tray',type:'a',x:-240,y:1}]);assert.equal(setup(g).tick().reason,'animation_active');});
test('unknown tray layout, full bar and duplicate board block',()=>{const f=makeFixture();f.tray.width=640;assert.equal(setup(f).tick().reason,'board_ambiguous');const g=makeFixture(Array.from({length:7},(_,i)=>({zone:'tray',type:'a'+i,x:-240+80*i,y:0})));assert.equal(setup(g).tick().reason,'tray_full');const h=makeFixture();const extra=h.node(560,720);h.game.children.push(extra);extra.parent=h.game;assert.equal(setup(h).tick().reason,'board_ambiguous');});
test('snapshot budget exit cannot dispatch',()=>{const f=makeFixture(),rt=setup(f,{clockStep:1});assert.equal(rt.tick().reason,'time_budget');assert.equal(f.calls.length,0);});
test('embedded planner budget still prevents dispatch when its injected clock expires',()=>{const f=makeFixture(),rt=setup(f);let plannerNow=0;rt.context.Date.now=()=>{plannerNow+=8;return plannerNow;};assert.equal(rt.tick().status,'waiting_stability');rt.advance(250);assert.equal(rt.tick().reason,'search_in_progress');assert.equal(f.calls.length,0);});
test('stable replacement scene retires old pending without counting a success or replaying',()=>{const f=makeFixture(),rt=reachDispatch(f),other=makeFixture();rt.context.window.cc=other.cc;rt.advance(250);const r=rt.tick();assert.equal(r.reason,'new_board_stability');assert.equal(r.awaitingBoardChange,true);rt.advance(250);const settled=rt.tick();assert.equal(settled.reason,'new_board_detected');assert.equal(settled.confirmedMoves,0);assert.equal(settled.awaitingBoardChange,false);assert.equal(f.calls.length,1);assert.equal(other.calls.length,0);});
test('resource is bounded and contains no network, captured code execution or injected timer',()=>{assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout)\s*\(/);assert.doesNotMatch(source,/new\s+Function\b/);});

const fixturePath=path.join(__dirname,'fixtures/autoplay-board-observed-v25.json');
test('replays 228 real captured card geometries with explicit synthetic method mocks',()=>{const observed=JSON.parse(fs.readFileSync(fixturePath,'utf8'));assert.equal(observed.sequence,133);const f=makeFixture(observed.cards);let input;const rt=setup(f,{planner:value=>{input=value;return{status:'blocked'};}});const first=rt.tick();assert.equal(first.cardsRead,228,JSON.stringify(first));assert.equal(first.status,'waiting_stability',JSON.stringify(first));rt.advance(250);assert.equal(rt.tick().reason,'no_safe_move');assert.equal(input.cards.length,228);assert.equal(input.cards.filter(c=>c.zone==='board').length,225);assert.equal(input.cards.filter(c=>c.blockedBy.length>0).length,180);assert.equal(input.cards.filter(c=>c.available).length,48);assert.equal(new Set(input.cards.map(c=>c.type)).size,16);assert.equal(input.tray.length,0);assert.equal(input.capacity,7);assert.equal(f.calls.length,0);});

test('transient seventh tray card preserves pending until original trio settles',()=>{
 const records=[...['a','b','b','c','c','d','d','e','e'].map((type,i)=>({zone:'board',type,x:-240+80*(i%7),y:Math.floor(i/7)*90})),...['a','a','b','c','d','e'].map((type,i)=>({zone:'tray',type,x:-240+80*i,y:0}))];
 const f=makeFixture(records),rt=reachDispatch(f),picked=f.cards[0];move(f,picked,f.tray);rt.advance(250);
 const transient=rt.tick();assert.equal(transient.reason,'tray_full');assert.equal(transient.awaitingBoardChange,true);assert.equal(f.calls.length,1);
 for(const c of f.cards.filter(c=>c.type==='a'))c.node.parent=null;
 f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('new board container in same scene retires old pending after stability without replay',()=>{
 const f=makeFixture(),rt=reachDispatch(f),other=makeFixture();f.root.children=[other.game];other.game.parent=f.root;other.cc.director.getScene=()=>f.root;rt.context.window.cc=other.cc;
 rt.advance(250);assert.equal(rt.tick().reason,'new_board_stability');rt.advance(250);const r=rt.tick();assert.equal(r.reason,'new_board_detected');assert.equal(r.confirmedMoves,0);assert.equal(f.calls.length,1);assert.equal(other.calls.length,0);
});

test('real planner and guarded adapter continuously complete two triples with six confirmed original events',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i,y:0})));
 f.EventHandler.prototype.emit=function(args){
  f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);
  const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);
  if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}
  f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 };
 const rt=setup(f);let r,confirmationCount=0;
 for(let i=0;i<100;i++){
  const before=f.calls.length;rt.advance(250);r=rt.tick();assert.ok(f.calls.length-before<=1,'at most one original event per tick');
  assert.notEqual(r.status,'dispatch_uncertain');assert.notEqual(r.reason,'read_error');
  if(r.status==='move_confirmed')confirmationCount++;
  if(r.confirmedMoves===6)break;
 }
 assert.equal(r.confirmedMoves,6);assert.equal(confirmationCount,6);assert.equal(f.calls.length,6);assert.equal(f.board.children.length,0);assert.equal(f.tray.children.length,0);assert.equal(r.awaitingBoardChange,false);
});

const v26Fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v26.json'),'utf8'));
function observedV26(sequence){return v26Fixture.snapshots.find(s=>s.sequence===sequence).cards.map(row=>Object.fromEntries(v26Fixture.columns.map((key,i)=>[key,row[i]])));}
function applyObservedState(f,records){
 for(const parent of [f.board,f.tray,f.reserve])parent.children=[];
 for(const r of records){
  const c=f.cards.find(c=>c.observedID===r.id);assert.ok(c,'captured identity must remain present');assert.equal(c.type,r.type);
  const parent=r.zone==='tray'?f.tray:r.zone==='reserve'?f.reserve:f.board;
  parent.children.push(c.node);c.node.parent=parent;c.node.x=r.x;c.node.y=r.y;
  c.mask.active=r.mask;c.mask.activeInHierarchy=r.mask;c.button.interactable=r.zone!=='tray'&&!r.mask;c.receiver.canTouch=c.button.interactable;c.receiver.blockInfo.state=r.zone==='tray'?1:r.zone==='reserve'?2:0;
 }
}
for(const [seq,board,tray,reserve] of [[2,225,0,0],[30,224,1,0],[51,225,0,0],[120,222,3,0],[147,222,0,3]]){
 test('new real capture seq '+seq+' reads all 225 cards and plans with observed tray/reserve geometry',()=>{
  const records=observedV26(seq),f=makeFixture(records),rt=setup(f);
  const types=new Map();for(const c of records){if(!types.has(c.type))types.set(c.type,new Set());types.get(c.type).add(c.frameID);}
  assert.equal(types.size,16);for(const frames of types.values())assert.equal(frames.size,1,'no cloned SpriteFrame identity is observed per type');
  assert.equal(f.board.children.length,board);assert.equal(f.tray.children.length,tray);assert.equal(f.reserve.children.length,reserve);
  const first=rt.tick();assert.equal(first.status,'waiting_stability',JSON.stringify(first));assert.equal(first.cardsRead,225);assert.equal(first.cardTypesRead,16);
  rt.advance(250);const search=rt.tick();assert.equal(search.reason,'plan_ready');assert.equal(search.planning.state,'proved');assert.equal(search.planning.goal,'next_trio');assert.equal(f.calls.length,0);
 });
}
test('captured local trio prepares while a later manual board change invalidates the old selection',()=>{
 const f=makeFixture(observedV26(2)),chosen=f.cards.find(c=>c.observedID==='n920'),index=f.cards.indexOf(chosen);
 const rt=setup(f,{planner:input=>directProof(input,input.cards[index].id)});rt.tick();rt.advance(100);
 assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);
 applyObservedState(f,observedV26(30));rt.advance(100);assert.equal(rt.tick().reason,'observing_board');assert.equal(rt.tick().confirmedMoves,0);
});
test('three tray-to-reserve power movements cannot masquerade as confirmation of a dispatched board card',()=>{
 const records=[...['a','a','b','b','c','c'].map((type,i)=>({zone:'board',type,x:-240+80*i})),...['a','b','c'].map((type,i)=>({zone:'tray',type,x:-240+80*i}))];
 const f=makeFixture(records),rt=reachDispatch(f);
 for(const card of f.cards.filter(c=>c.node.parent===f.tray))move(f,card,f.reserve);
 rt.advance(100);const r=rt.tick();assert.equal(r.status,'waiting_confirmation');assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);assert.equal(f.calls.length,1);
});
test('bounded type-count diagnostic resets when complete state is unavailable',()=>{
 const f=makeFixture(),rt=setup(f);assert.equal(rt.tick().cardTypesRead,1);
 f.cards[0].face.comps[0].spriteFrame.name='';const blocked=rt.tick();assert.equal(blocked.reason,'unknown_card');assert.equal(blocked.cardTypesRead,0);
 assert.equal(rt.tick({command:'pause'}).cardTypesRead,0);
});
test('registered callback consuming event.target receives an EventTouch and changes the board once',()=>{
 const f=makeFixture();
 for(const card of f.cards)card.receiver.touchBlock=function(event){
  assert.ok(event instanceof f.cc.Event.EventTouch);assert.equal(event.getEventCode(),2);
  assert.equal(event.target,this.node);assert.equal(event.currentTarget,this.node);move(f,card,f.tray);
 };
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});this.target.getComponent(this.component)[this.handler](...args);};
 const rt=reachDispatch(f);assert.equal(f.tray.children.length,1);rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');
 rt.advance(250);assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});
test('missing touch contract or nonfinite world coordinates blocks before any original event or pending state',()=>{
 for(const change of [f=>{delete f.cc.Touch;},f=>{f.cc.Event.EventTouch.ENDED=0;},f=>{for(const c of f.cards)c.node.convertToWorldSpaceAR=()=>({x:NaN,y:0});},f=>{delete f.cc.Event.EventTouch.prototype._setEventCode;}]){
  const f=makeFixture();change(f);const rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);
  const r=rt.tick();assert.equal(r.reason,'input_event_unavailable');assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,0);
 }
});

function terminalTransitionFixture(){
 const f=makeFixture([{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0},{zone:'tray',type:'a',x:-160,y:0},
  ...Array.from({length:18},(_,i)=>({zone:'board',type:i<9?'b':'c',x:-240+80*(i%7),y:-180+90*Math.floor(i/7)}))]);
 const future=f.cards.slice(3);f.board.children=[f.cards[0].node];for(const c of future)c.node.parent=null;
 return{f,replace(reuse=false){f.board.children=[];f.tray.children=[];
  for(const c of f.cards)c.node.parent=null;
  (reuse?f.cards:future).forEach((c,i)=>{f.board.children.push(c.node);c.node.parent=f.board;c.node.x=-240+80*(i%7);c.node.y=-180+90*Math.floor(i/7);c.receiver.blockInfo.state=0;c.receiver.blockInfo.row=(c.node.x+240)/5;c.receiver.blockInfo.col=(315-c.node.y)/4.5;c.receiver.blockInfo.id=`${c.receiver.blockInfo.layer}-${c.receiver.blockInfo.row}-${c.receiver.blockInfo.col}`;c.receiver.canTouch=true;c.button.interactable=true;});
 },modal(){const n=f.node(240,102);f.root.children.push(n);n.parent=f.root;return()=>{f.root.children.splice(f.root.children.indexOf(n),1);n.parent=null;};}};
}
for(const reuse of [false,true])test('terminal modal and large stable refill retires pending in same containers, pooled old identities='+reuse,()=>{
 const t=terminalTransitionFixture(),rt=reachDispatch(t.f),close=t.modal();rt.advance(200);assert.equal(rt.tick().reason,'modal_visible');close();t.replace(reuse);
 rt.advance(200);assert.equal(rt.tick().reason,'new_board_stability');rt.advance(200);const r=rt.tick();
 assert.equal(r.reason,'new_board_detected');assert.equal(r.awaitingBoardChange,false);assert.equal(r.confirmedMoves,0);assert.equal(t.f.calls.length,1);
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(t.f.calls.length,1);
 rt.advance(200);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(t.f.calls.length,2);
});
test('same-container refill without postdispatch modal never retires pending',()=>{
 const t=terminalTransitionFixture(),rt=reachDispatch(t.f);t.replace();rt.advance(10000);const r=rt.tick();
 assert.equal(r.reason,'confirmation_uncertain');assert.equal(r.awaitingBoardChange,true);assert.equal(t.f.calls.length,1);
});
test('same-container refill after modal with nonterminal previous move remains uncertain',()=>{
 const t=terminalTransitionFixture();const third=t.f.tray.children.pop();third.parent=t.f.board;third.x=80;third.y=0;const revived=t.f.cards.find(c=>c.node===third);revived.receiver.blockInfo.state=0;revived.receiver.canTouch=true;revived.button.interactable=true;revived.receiver.blockInfo.row=64;revived.receiver.blockInfo.col=70;revived.receiver.blockInfo.id=`${revived.receiver.blockInfo.layer}-64-70`;t.f.board.children.push(third);const rt=reachDispatch(t.f),close=t.modal();rt.advance(200);rt.tick();close();t.replace();rt.advance(10000);
 assert.equal(rt.tick().reason,'confirmation_uncertain');assert.equal(t.f.calls.length,1);
});
test('modal breaks consecutive confirmation observations',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');const modal=f.node(240,102);f.root.children.push(modal);modal.parent=f.root;
 rt.advance(200);assert.equal(rt.tick().reason,'modal_visible');f.root.children.pop();modal.parent=null;
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(200);assert.equal(rt.tick().status,'move_confirmed');
});
test('pause and resume generation restart proof without discarding the pending action',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');assert.equal(rt.tick({command:'pause'}).awaitingBoardChange,true);
 rt.advance(1000);assert.equal(rt.tick({resumeGeneration:2}).reason,'confirm_stability');rt.advance(200);
 assert.equal(rt.tick({resumeGeneration:2}).status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('confirmed snapshots seed stability but next plan still requires fresh separate dispatch tick',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(200);assert.equal(rt.tick().status,'move_confirmed');
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,1);
 rt.advance(200);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(f.calls.length,2);
});
test('changed confirmed state is observed again before preparing next plan',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);rt.tick();rt.advance(200);rt.tick();f.board.children[0].x=-200;rt.advance(200);
 assert.equal(rt.tick().reason,'animation_active');assert.equal(f.calls.length,1);
});

function addWarehouse(f,card){
 const slots=[-88,0,88].map(x=>f.node(84,94,[],{x})),row=f.node(260,94,slots,{y:8}),panel=f.node(272,126,[row],{x:161,y:-414.594}),layer=f.node(750,1623.188,[panel]);
 f.game.children.push(layer);layer.parent=f.game;const sprite=f.sprite(panel,names.warehouse);sprite.spriteFrame.getRect=()=>({width:272,height:126});
 for(const n of slots){const receiver={kind:f.cc.Component,className:'CommonStoreItem',node:n,isValid:true,isEmpty:true,isSelf:true,onBtnClick(){throw Error('Warehouse must not be clicked');}};
  const event=new f.EventHandler();Object.assign(event,{target:n,component:'CommonStoreItem',handler:'onBtnClick',customEventData:''});
  const button={kind:f.cc.Button,isValid:true,node:n,enabled:true,enabledInHierarchy:true,interactable:true,clickEvents:[event]};n.comps.push(receiver,button);n.receiver=receiver;n.button=button;
 }
 const a=card.node.parent.children;a.splice(a.indexOf(card.node),1);slots[2].children.push(card.node);card.node.parent=slots[2];card.node.x=0;card.node.y=0;slots[2].receiver.isEmpty=false;
 return{slots,row,panel,layer,card};
}
test('settled card in verified CommonStoreItem never blocks as animation and is never selectable',()=>{
 const f=makeFixture(['a','a','a','x'].map((type,i)=>({zone:'board',type,x:-160+80*i,y:0}))),w=addWarehouse(f,f.cards[3]);let input;const rt=setup(f,{planner:s=>{input=s;return directProof(s,s.cards[0].id);}});
 reachDispatch(f,rt);assert.equal(input.cards.length,3);assert.equal(input.tray.length,0);assert.notEqual(f.calls[0].event,w.card.event);assert.equal(rt.tick().cardsRead,3);
});
test('warehouse shape alone without exact component and original registration cannot exempt external card',()=>{
 for(const change of [w=>{w.slots[2].receiver.className='OtherStore';},w=>{w.slots[2].button.clickEvents[0].handler='other';},w=>{w.slots[2].button.clickEvents[0].customEventData='x';},w=>{w.slots[0].x=-87;},w=>{w.row.children.shift();}]){
  const f=makeFixture(),w=addWarehouse(f,f.cards[2]);change(w);const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'external_card');assert.equal(f.calls.length,0);
 }
});
test('moving, masked and duplicate warehouse cards retain animation block',()=>{
 for(const change of [w=>{w.card.node.x=1;},w=>{w.card.mask.active=true;w.card.mask.activeInHierarchy=true;},w=>{w.slots[2].receiver.isEmpty=true;},(w,f)=>{const other=f.cards[1];f.board.children.splice(f.board.children.indexOf(other.node),1);w.slots[2].children.push(other.node);other.node.parent=w.slots[2];}]){
  const f=makeFixture(),w=addWarehouse(f,f.cards[2]);change(w,f);const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'warehouse_card_unsettled');assert.equal(f.calls.length,0);
 }
});
test('warehouse face mutation after plan invalidates selected action',()=>{
 const f=makeFixture(['a','a','a','x'].map((type,i)=>({zone:'board',type,x:-160+80*i,y:0}))),w=addWarehouse(f,f.cards[3]),rt=setup(f);rt.tick();rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');
 w.card.face.comps[0].spriteFrame={name:'other_face',getRect:()=>({width:120,height:135})};rt.advance(200);
 assert.equal(rt.tick().reason,'observing_board');assert.equal(f.calls.length,0);
});
test('animation diagnostic identifies external card without allowing an unknown layout',()=>{
 const f=makeFixture(),card=f.cards[2];f.board.children.pop();f.game.children.push(card.node);card.node.parent=f.game;
 const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'external_card');assert.equal(r.awaitingBoardChange,false);
});
test('settled deterministic fixture at 100ms polling dispatches every400ms after initial move with full confirmation',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i,y:0})));
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);
  const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);
  if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}
  f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 };
 const rt=setup(f),dispatchTimes=[];let result;
 for(let i=0;i<40;i++){rt.advance(100);result=rt.tick();if(result.dispatched)dispatchTimes.push((i+1)*100);if(result.confirmedMoves===6)break;}
 assert.equal(result.confirmedMoves,6);assert.equal(dispatchTimes.length,6);
 assert.deepEqual(dispatchTimes.slice(1).map((time,i)=>time-dispatchTimes[i]),[400,400,400,400,400]);
});
test('replays captured V2.8.1 sequence257 with215 board cards and one stationary warehouse card',()=>{
 const observed=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v29.json'),'utf8'));
 assert.equal(observed.sequence,257);assert.equal(observed.cards.length,215);assert.equal(observed.warehouseCard.id,'n917');
 const f=makeFixture([...observed.cards,{...observed.warehouseCard,zone:'board'}]),warehouse=f.cards.at(-1);addWarehouse(f,warehouse);
 const rt=setup(f),r=rt.tick();assert.equal(r.status,'waiting_stability',JSON.stringify(r));assert.equal(r.cardsRead,215);assert.equal(r.cardTypesRead,16);
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);
});

function enableRenderer(f){
 const graphics=[];
 function decorate(n){
  n.addChild=function(child){if(child.parent)child.removeFromParent(false);this.children.push(child);child.parent=this;};
  n.removeFromParent=function(){if(this.parent){const list=this.parent.children,index=list.indexOf(this);if(index>=0)list.splice(index,1);this.parent=null;}};
  n.destroy=function(){this.isValid=false;};
  n.addComponent=function(kind){const c=new kind();Object.assign(c,{kind,node:this,enabled:true,enabledInHierarchy:true});this.comps.push(c);return c;};
  n.convertToWorldSpaceAR=function(p){let x=p.x,y=p.y,c=this;while(c){x=x*c.scaleX+c.x;y=y*c.scaleY+c.y;c=c.parent;}return{x,y};};
  n.convertToNodeSpaceAR=function(p){const ancestry=[];let c=this;while(c){ancestry.push(c);c=c.parent;}let x=p.x,y=p.y;for(c of ancestry.reverse()){x=(x-c.x)/c.scaleX;y=(y-c.y)/c.scaleY;}return{x,y};};
  for(const child of n.children)decorate(child);return n;
 }
 decorate(f.root);
 function CocosNode(name){const n=decorate(f.node());n.name=name;return n;}CocosNode.EventType=f.cc.Node.EventType;
 function Graphics(){this.paths=[];this.clears=0;graphics.push(this);}
 Graphics.prototype.clear=function(){this.paths=[];this.clears++;};
 Graphics.prototype.moveTo=function(x,y){this.paths.push(['move',x,y]);};
 Graphics.prototype.lineTo=function(x,y){this.paths.push(['line',x,y]);};
 Graphics.prototype.close=function(){this.paths.push(['close']);};Graphics.prototype.stroke=function(){this.paths.push(['stroke']);};Graphics.prototype.roundRect=function(){};Graphics.prototype.fill=function(){};
 f.cc.Node=CocosNode;f.cc.Graphics=Graphics;f.cc.Color=function(r,g,b,a){Object.assign(this,{r,g,b,a});};f.cc.Sprite.SizeMode={CUSTOM:0};
 return{graphics,overlay(){return f.game.children.find(n=>n.name==='SDKtools Card Hints');}};
}
function xrayFixture(){return makeFixture([{zone:'board',type:'a',x:0,y:0,mask:true},{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0}]);}
test('xray-only mode uses actual loaded frame icons and highlights proven trio including tray without dispatching',()=>{
 const f=xrayFixture(),render=enableRenderer(f),originalFrame=f.cards[0].face.comps[0].spriteFrame,rt=setup(f);
 let r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.xray.status,'ready');assert.equal(r.xray.coveredIcons,1);assert.equal(r.xray.matchedBorders,0);assert.equal(r.xray.depthLimit,1);
 rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'plan_ready');assert.equal(r.xray.matchedBorders,3);
 const overlay=render.overlay(),icon=overlay.children[0];assert.equal(overlay.parent,f.game);assert.notEqual(overlay.parent,f.board);
 assert.equal(icon.getComponent(f.cc.Sprite).spriteFrame,originalFrame);assert.equal(icon.width,24);assert.equal(icon.height,27);
 assert.equal(f.cards[0].face.comps[0].spriteFrame,originalFrame);assert.equal(f.cards[0].mask.active,true);assert.equal(f.board.children.length,2);
 const clears=render.graphics[0].clears;
 for(let i=0;i<20;i++){rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'action_disabled');assert.equal(r.cardsRead,3);assert.equal(r.xray.matchedBorders,3);}
 assert.equal(render.graphics[0].clears,clears,'unchanged overlay must not be cleared/rebuilt');assert.equal(f.calls.length,0);
 assert.deepEqual(overlay.comps.map(c=>c.kind),[f.cc.Graphics]);assert.deepEqual(icon.comps.map(c=>c.kind),[f.cc.Sprite]);
});
test('xray follows board ancestor offsets even when card-local signatures do not change',()=>{
 const f=xrayFixture(),render=enableRenderer(f),rt=setup(f);rt.tick({allowAction:false,xrayEnabled:true});rt.advance(100);rt.tick({allowAction:false,xrayEnabled:true});
 const icon=render.overlay().children[0],beforeX=icon.x,beforeY=icon.y,oldPath=render.graphics[0].paths.filter(p=>p[0]==='move')[1].slice();
 f.board.parent.x+=17;f.board.parent.y-=11;rt.advance(100);const r=rt.tick({allowAction:false,xrayEnabled:true});
 assert.equal(r.xray.status,'ready');assert.equal(icon.x,beforeX+17);assert.equal(icon.y,beforeY-11);
 const nextPath=render.graphics[0].paths.filter(p=>p[0]==='move')[1];assert.equal(nextPath[1],oldPath[1]+17);assert.equal(nextPath[2],oldPath[2]-11);assert.equal(f.calls.length,0);
});
test('xray overlay is removed on toggle off, pause, hidden document and modal',()=>{
 for(const change of ['off','pause','hidden','modal']){
  const f=xrayFixture(),render=enableRenderer(f),rt=setup(f);rt.tick({allowAction:false,xrayEnabled:true});assert.ok(render.overlay());
  let options={allowAction:false,xrayEnabled:true};
  if(change==='off')options.xrayEnabled=false;
  if(change==='pause')options.command='pause';
  if(change==='hidden')rt.context.document.visibilityState='hidden';
  if(change==='modal'){const m=f.node(240,102);f.root.children.push(m);m.parent=f.root;}
  const r=rt.tick(options);assert.equal(render.overlay(),undefined,change);assert.equal(r.xray.coveredIcons,0);assert.equal(r.xray.matchedBorders,0);assert.equal(f.calls.length,0);
 }
});
test('xray missing rendering API cannot stop otherwise valid autoplay or alter original sprites',()=>{
 const f=makeFixture(),rt=setup(f);rt.tick({xrayEnabled:true});rt.advance(100);rt.tick({xrayEnabled:true});rt.advance(100);
 const r=rt.tick({xrayEnabled:true});assert.equal(r.status,'original_event_dispatched');assert.equal(r.xray.status,'unavailable');assert.equal(f.calls.length,1);
});
test('xray reads all225 captured cards while showing only depth1 and excludes its own nodes from subsequent snapshots',()=>{
 const f=makeFixture(observedV26(2)),render=enableRenderer(f),rt=setup(f);
 let r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.cardsRead,225);assert.equal(r.xray.coveredIcons,23);assert.equal(render.overlay().children.length,23);
 rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'plan_ready');assert.equal(r.xray.matchedBorders,3);
 rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'action_disabled');assert.equal(r.cardsRead,225);assert.equal(f.calls.length,0);
 assert.equal(f.board.children.length,225);assert.equal(f.tray.children.length,0);
});
test('no complete trio means no arbitrary card event even after repeated ticks',()=>{
 const f=makeFixture([{zone:'board',type:'a',x:-80},{zone:'board',type:'b',x:80}]),rt=setup(f);let r;
 for(let i=0;i<20;i++){rt.advance(100);r=rt.tick();}assert.equal(r.reason,'no_remaining_triples');assert.equal(f.calls.length,0);assert.equal(r.awaitingBoardChange,false);
});
test('adapter independently rejects fabricated trio identifiers, wrong sequence, missing proof and overflow',()=>{
 const changes=[p=>{p.tripleCardIDs[0]='nonexistent';},p=>{p.sequence=[p.sequence[0]];p.actions=p.sequence.slice();},p=>{delete p.sequence;},p=>{p.actions.reverse();},p=>{p.matchedType='wrong';}];
 for(const change of changes){const f=makeFixture(),rt=setup(f,{planner:s=>{const p=directProof(s,s.cards[0].id);change(p);return p;}});rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);}
 const records=[...['a','a','a'].map((type,i)=>({zone:'board',type,x:-80+80*i})),...['b','c','d','e','f'].map((type,i)=>({zone:'tray',type,x:-240+80*i}))];
 const f=makeFixture(records),rt=setup(f,{planner:s=>directProof(s,s.cards[0].id)});rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);
});
test('100ms schedule still needs two fresh observations and a separate revalidation before dispatch',()=>{
 const f=makeFixture(),rt=setup(f);assert.equal(rt.tick().reason,'observing_board');rt.advance(79);assert.equal(rt.tick().reason,'observing_board');
 rt.advance(1);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);rt.advance(100);assert.equal(rt.tick().status,'original_event_dispatched');
 const picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(79);assert.equal(rt.tick().reason,'confirm_stability');
 rt.advance(1);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('proven sequence persists through confirmation without replanning another type mid-trio',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));let plans=0;
 const real=vm.runInNewContext('('+plannerSource+')',{Date:{now:()=>0}}),rt=setup(f,{planner:s=>{plans++;return real(s);}});
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});};
 let r;for(let i=0;i<30;i++){rt.advance(100);r=rt.tick();if(r.confirmedMoves===3)break;}
 assert.equal(r.confirmedMoves,3);assert.equal(plans,1);assert.deepEqual(f.calls.map(c=>f.cards.find(card=>card.event===c.event).type),['a','a','a']);
});
test('xray resource remains bounded without input dispatch or remote asset loading',()=>{
 assert.ok(Buffer.byteLength(xraySource)<65536);assert.doesNotMatch(xraySource,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);
 assert.doesNotMatch(xraySource,/\.emit\s*\(|\.touchBlock\s*\(|\.on\s*\(|addComponent\(\s*cc\.(?:Button|BlockInputEvents)/);
});

const v30Observed=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v30.json'),'utf8'));
for(const observed of v30Observed.snapshots)test('V2.9 capture sequence'+observed.sequence+' reads every card but never selects a nonmatching overflow move',()=>{
 const f=makeFixture(observed.rows),render=enableRenderer(f),rt=setup(f);
 let r=rt.tick({xrayEnabled:true});assert.equal(r.cardsRead,observed.rows.length);assert.equal(r.status,'waiting_stability');
 const hidden=4;assert.equal(r.xray.coveredIcons,hidden);
 for(let i=0;i<5;i++){rt.advance(100);r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'no_complete_solution');assert.equal(r.xray.matchedBorders,0);}
 assert.equal(f.calls.length,0);assert.equal(render.overlay().children.length,hidden);assert.equal(r.awaitingBoardChange,false);
});
test('xray destroys previous game overlay when the live scene is replaced',()=>{
 const f=xrayFixture(),first=enableRenderer(f),rt=setup(f);rt.tick({allowAction:false,xrayEnabled:true});const old=first.overlay();assert.ok(old);
 const replacement=xrayFixture(),second=enableRenderer(replacement);rt.context.window.cc=replacement.cc;rt.advance(100);const r=rt.tick({allowAction:false,xrayEnabled:true});
 assert.equal(first.overlay(),undefined);assert.equal(old.isValid,false);assert.ok(second.overlay());assert.equal(r.xray.status,'ready');assert.equal(f.calls.length,0);assert.equal(replacement.calls.length,0);
});
test('SDK-like node names never exempt an unrelated external game card from validation',()=>{
 const f=makeFixture(),render=enableRenderer(f),card=f.cards[2];f.board.children.pop();f.game.children.push(card.node);card.node.parent=f.game;card.node.name='SDKtools Card Hints';
 const r=setup(f).tick({xrayEnabled:true});assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'external_card');assert.equal(f.calls.length,0);assert.equal(render.graphics.length,0);
});

test('original numeric Block.type determines trio identity across distinct loaded skin frames',()=>{
 const f=makeFixture([{zone:'board',type:'visual_a',numericType:7,x:-80},{zone:'board',type:'visual_b',numericType:7,x:0},{zone:'board',type:'visual_c',numericType:7,x:80}]),rt=reachDispatch(f);
 assert.equal(rt.tick().cardTypesRead,1);assert.equal(f.calls.length,1);
});
test('overlap on the same original numeric layer never creates a blocker',()=>{
 const f=makeFixture([{zone:'board',type:'a',layer:2,x:0},{zone:'board',type:'a',layer:2,x:40},{zone:'board',type:'a',layer:2,x:160}]);
 let input;const rt=setup(f,{planner:s=>{input=s;return{status:'blocked'};}});assert.equal(rt.tick().reason,'observing_board');rt.advance(100);rt.tick();
 assert.deepEqual(Array.from(input.cards,c=>c.blockedBy.length),[0,0,0]);assert.equal(input.cards.every(c=>c.available),true);assert.equal(f.calls.length,0);
});
test('original layer and ID grid override rendering child order for occlusion',()=>{
 const f=makeFixture([{zone:'board',type:'a',layer:3,x:0},{zone:'board',type:'a',layer:1,x:0,mask:true},{zone:'board',type:'a',layer:2,x:160}]);
 let seen;const rt=setup(f,{planner:s=>{seen=s;return{status:'blocked'};}});assert.equal(rt.tick().reason,'observing_board');rt.advance(100);rt.tick();
 assert.deepEqual(Array.from(seen.cards[1].blockedBy),[seen.cards[0].id]);assert.equal(seen.cards[0].available,true);assert.equal(seen.cards[1].available,false);
});
test('Block.blockInfo accessors are never invoked and absent or duplicate original metadata cannot authorize action',()=>{
 for(const change of [f=>{delete f.cards[0].receiver.blockInfo;},f=>{f.cards[1].receiver.blockInfo.id=f.cards[0].receiver.blockInfo.id;},f=>{f.cards[0].receiver.blockInfo.state=3;},f=>{f.cards[0].receiver.blockInfo.type='1';}]){
  const f=makeFixture();change(f);const r=setup(f).tick();assert.equal(r.reason,'unsupported_card_rules');assert.equal(f.calls.length,0);
 }
 const f=makeFixture();let hits=0;Object.defineProperty(f.cards[0].receiver,'blockInfo',{get(){hits++;throw Error('must not call');}});assert.equal(setup(f).tick().reason,'unsupported_card_rules');assert.equal(hits,0);
});
test('original temporary modes and in-flight Block touch stop before a game callback',()=>{
 for(const [name,field] of [['CommonStore','coverNode'],['GameLayer','HotTimeMask'],['Game','WatchMaskNode']]){
  const f=makeFixture(),overlay=f.node();f.game.children.push(overlay);overlay.parent=f.game;f.game.comps.push({className:name,node:f.game,[field]:overlay});
  const r=setup(f).tick();assert.equal(r.reason,'external_mode_active');assert.equal(f.calls.length,0);
 }
 const f=makeFixture();f.cards[0].receiver.isTouched=true;const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'original_touch_pending');assert.equal(f.calls.length,0);
});
test('locked special card is read with its original badge and never selected or assumed to unlock by removing coverage',()=>{
 const f=makeFixture();const card=f.cards[0];card.receiver.blockInfo.special_info={type:1,lock_state:2};card.receiver.SpecialNode.active=true;card.receiver.SpecialNode.activeInHierarchy=true;
 let input;const rt=setup(f,{planner:s=>{input=s;return{status:'blocked',reason:'observed_state_locked'};}});
 assert.equal(rt.tick().cardsRead,3);rt.advance(100);assert.equal(rt.tick().reason,'observed_state_locked');assert.equal(input.cards[0].selectable,false);assert.equal(input.cards[0].available,false);assert.equal(f.calls.length,0);
});
test('reserved cards follow actual original button state without invented layer blockers',()=>{
 const f=makeFixture([{zone:'reserve',type:'a',layer:1,x:-80,y:7},{zone:'reserve',type:'a',layer:2,x:-80,y:14},{zone:'reserve',type:'a',layer:3,x:-80,y:21}]);let input;
 const rt=setup(f,{planner:s=>{input=s;return{status:'blocked'};}});assert.equal(rt.tick().reason,'observing_board');rt.advance(100);rt.tick();
 assert.equal(input.cards.every(c=>c.zone==='reserve'&&c.blockedBy.length===0&&c.available),true);assert.equal(f.calls.length,0);
});
test('local proof persists within each trio and replans after each completed trio',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));let searches=0;
 const originalPlanner=vm.runInNewContext('('+plannerSource+')',{Date:{now:()=>0}}),rt=setup(f,{planner:s=>{searches++;return originalPlanner(s);}});
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});};
 let r;for(let i=0;i<40;i++){rt.advance(100);r=rt.tick();if(r.confirmedMoves===6)break;}
 assert.equal(r.confirmedMoves,6);assert.equal(searches,2);assert.equal(f.board.children.length,0);assert.equal(f.tray.children.length,0);
});
test('local trio is accepted even when another complete trio remains',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i}))),rt=setup(f,{planner:s=>directProof(s,s.cards[0].id)});
 rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'plan_ready');rt.advance(100);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(f.calls.length,1);
});
test('locally proved trios can be completed while an unmatched cooperative residue remains',()=>{
 const f=makeFixture(['a','a','a','b'].map((type,i)=>({zone:'board',type,x:-160+80*i}))),rt=reachDispatch(f);
 assert.equal(rt.tick().planning.goal,'next_trio');assert.equal(rt.tick().planning.residualCards,1);assert.equal(f.calls.length,1);
});
test('xray depth change neither resets an incremental search nor clears an uncertain original event',()=>{
 const f=makeFixture();let searches=0;const actual=vm.runInNewContext('('+plannerSource+')',{Date:{now:()=>0}}),rt=setup(f,{planner:s=>{searches++;return searches<3?{status:'searching',reason:'search_in_progress',stats:{expanded:searches,slices:searches}}:actual(s);}});
 rt.tick({xrayEnabled:true,xrayDepth:1});rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:1}).status,'planning');rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:5}).status,'planning');assert.equal(searches,2);
 rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:3}).reason,'plan_ready');rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:2}).status,'original_event_dispatched');
 rt.advance(9000);const pending=rt.tick({xrayEnabled:true,xrayDepth:4});assert.equal(pending.reason,'confirmation_uncertain');assert.equal(pending.awaitingBoardChange,true);assert.equal(f.calls.length,1);assert.equal(searches,3);
});

test('a special card unlocked by original removeSelf remains readable with four children and can finish a proved trio',()=>{
 const f=makeFixture(),card=f.cards[0],special=card.receiver.SpecialNode;
 card.receiver.blockInfo.special_info={type:1,lock_state:0};card.node.children.splice(card.node.children.indexOf(special),1);special.parent=null;special.active=false;special.activeInHierarchy=false;
 assert.equal(card.node.children.length,4);const rt=reachDispatch(f);assert.equal(rt.tick().cardsRead,3);assert.equal(f.calls.length,1);
});
test('removal of an unrelated card branch or removal of a still-locked badge cannot mimic an unlocked special',()=>{
 for(const branch of ['MaskNode','HotTimeAnimNode','BombAnimNode','SpecialNode']){
  const f=makeFixture(),card=f.cards[0],node=card.receiver[branch];card.receiver.blockInfo.special_info={type:1,lock_state:branch==='SpecialNode'?2:0};
  card.node.children.splice(card.node.children.indexOf(node),1);node.parent=null;
  const r=setup(f).tick();assert.equal(r.reason,'card_geometry');assert.equal(f.calls.length,0);
 }
});
test('original HandArea sorted insertion is confirmed in its exact order, not only by a multiset of IDs',()=>{
 const records=[{zone:'board',type:'a',x:-80},{zone:'board',type:'a',x:0},{zone:'board',type:'b',x:80},{zone:'board',type:'b',x:160},
  {zone:'tray',type:'a',x:-240},{zone:'tray',type:'b',x:-160}];
 const f=makeFixture(records),rt=reachDispatch(f),chosen=f.cards.find(c=>c.event===f.calls[0].event);move(f,chosen,f.tray);
 assert.equal(chosen.type,'a');rt.advance(100);assert.equal(rt.tick().reason,'awaiting_original_result');
 const picked=f.tray.children.pop();f.tray.children.splice(1,0,picked);f.tray.children.forEach((node,i)=>{node.x=-240+80*i;});
 rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(100);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('explicit play generation changes incremental search key while xray depth leaves it identical',()=>{
 const f=makeFixture(),keys=[],rt=setup(f,{planner:s=>{keys.push(s.stateKey);return{status:'blocked',reason:'search_limit_reached'};}});
 rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'search_limit_reached');rt.advance(100);assert.equal(rt.tick({xrayDepth:5}).reason,'search_limit_reached');
 assert.equal(keys[0],keys[1]);rt.tick({command:'pause'});rt.advance(100);assert.equal(rt.tick({resumeGeneration:2}).reason,'observing_board');rt.advance(100);rt.tick({resumeGeneration:2});
 assert.notEqual(keys[2],keys[0]);assert.equal(f.calls.length,0);
});

// V3.2: source-derived contracts, not new telemetry fields or game code.
// Block.getIsSpecialBlock ignores lock_state when special_info.type is zero;
// HandArea/StorageArea never use the pile's layer/row/col/ID grid fields.
function moveButtonsToOriginalBackground(f){
 for(const card of f.cards){card.node.comps.splice(card.node.comps.indexOf(card.button),1);card.bg.comps.push(card.button);card.button.node=card.bg;}
}
test('V3.2 normal special_info with type zero and omitted lock follows the original branch and dispatches',()=>{
 const f=makeFixture();moveButtonsToOriginalBackground(f);
 for(const c of f.cards)c.receiver.blockInfo.special_info={type:0};
 const rt=reachDispatch(f);assert.equal(rt.tick().cardsRead,3);assert.equal(f.calls.length,1);
 assert.equal(f.calls[0].args[0].target,f.cards.find(c=>c.event===f.calls[0].event).bg);
 assert.equal(rt.tick().cardRuleDetail,undefined);
});
test('V3.2 type-zero special metadata never reads an irrelevant lock accessor',()=>{
 const f=makeFixture();let hits=0;
 for(const c of f.cards){c.receiver.blockInfo.special_info={type:0};Object.defineProperty(c.receiver.blockInfo.special_info,'lock_state',{get(){hits++;throw Error('irrelevant field');}});}
 reachDispatch(f);assert.equal(hits,0);assert.equal(f.calls.length,1);
});
test('V3.2 unknown special lock cannot authorize play while valid geometric Xray remains usable',()=>{
 const f=xrayFixture();enableRenderer(f);f.cards[0].receiver.blockInfo.special_info={type:1};
 const rt=setup(f),r=rt.tick({xrayEnabled:true,xrayDepth:1});
 assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,'metadata_special_lock');
 assert.equal(r.xray.status,'ready');assert.ok(r.xray.coveredIcons>0);assert.equal(r.xray.matchedBorders,0);assert.equal(f.calls.length,0);
});
test('V3.2 original ID suffix remains identity while first two grid coordinates determine coverage',()=>{
 const f=makeFixture([{zone:'board',type:'a',x:0,layer:1,mask:true},{zone:'board',type:'a',x:0,layer:2},{zone:'board',type:'a',x:160,layer:1}]);
 f.cards.forEach((c,i)=>{c.receiver.blockInfo.id+='-opaque-'+i;});const rt=reachDispatch(f);
 assert.equal(rt.tick().cardsRead,3);assert.notEqual(f.calls[0].event,f.cards[0].event);
});
test('V3.2 reserve and hand cards need no original pile position or layer metadata',()=>{
 const f=makeFixture([{zone:'reserve',type:'a',x:-80,y:7},{zone:'tray',type:'a',x:-240},{zone:'tray',type:'a',x:-160}]);
 for(const [i,c] of f.cards.entries()){for(const key of ['layer','row','col'])delete c.receiver.blockInfo[key];c.receiver.blockInfo.id='non-pile-'+i;}
 moveButtonsToOriginalBackground(f);const rt=reachDispatch(f);assert.equal(rt.tick().cardsRead,3);assert.equal(f.calls[0].event,f.cards[0].event);
});
test('V3.2 completed reserve-to-hand original action remains confirmable without pile coordinates',()=>{
 const f=makeFixture([{zone:'reserve',type:'a',x:-80,y:7},{zone:'reserve',type:'a',x:0,y:14},{zone:'reserve',type:'a',x:80,y:21}]);
 for(const [i,c] of f.cards.entries()){for(const key of ['layer','row','col'])delete c.receiver.blockInfo[key];c.receiver.blockInfo.id='reserve-'+i;}
 const rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(100);assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});
test('V3.2 visual depth is independent of an unavailable original action registration',()=>{
 const f=xrayFixture();enableRenderer(f);f.cards[0].event.handler='unrelatedHandler';const rt=setup(f);
 const r=rt.tick({xrayEnabled:true,xrayDepth:2});assert.equal(r.reason,'handler_ambiguous');assert.equal(r.xray.status,'ready');
 assert.ok(r.xray.coveredIcons>0);assert.equal(r.xray.depthLimit,2);assert.equal(r.xray.matchedBorders,0);assert.equal(f.calls.length,0);
});
test('V3.2 action metadata rejection keeps only independently verified visual icons without invoking planner',()=>{
 const cases=[['metadata_state',c=>c.receiver.blockInfo.state=3],['metadata_type',c=>c.receiver.blockInfo.type='1'],['touch_flags',c=>delete c.receiver.canTouch],['control_state',c=>c.button.interactable=!c.button.interactable]];
 for(const [detail,change] of cases){const f=xrayFixture();enableRenderer(f);change(f.cards[0]);let plans=0;const rt=setup(f,{planner:()=>{plans++;throw Error('unverified rules');}});
  const r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,detail);assert.equal(r.xray.status,'ready');assert.ok(r.xray.coveredIcons>0);assert.equal(r.xray.matchedBorders,0);assert.equal(plans,0);assert.equal(f.calls.length,0);
 }
});
test('V3.2 uncertain visual grid still blocks Xray instead of inventing a depth',()=>{
 for(const [detail,change] of [['metadata_layer',c=>delete c.receiver.blockInfo.layer],['metadata_position',c=>delete c.receiver.blockInfo.row],['metadata_grid',c=>c.receiver.blockInfo.id='opaque']]){
  const f=xrayFixture();enableRenderer(f);change(f.cards[0]);const r=setup(f).tick({xrayEnabled:true});assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,detail);assert.equal(r.xray.status,'blocked');assert.equal(f.calls.length,0);
 }
});
test('V3.2 granular card diagnostics contain only enums and reset after recovering valid metadata',()=>{
 const cases=[['component',c=>c.receiver.className='Other'],['metadata_missing',c=>delete c.receiver.blockInfo],['metadata_id',c=>c.receiver.blockInfo.id=''],['metadata_special_type',c=>c.receiver.blockInfo.special_info={type:'secret-value',lock_state:0}]];
 for(const [detail,change] of cases){const f=makeFixture();change(f.cards[0]);const r=setup(f).tick();assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,detail);assert.doesNotMatch(JSON.stringify(r),/secret-value|mock_face/);}
 const f=makeFixture(),rt=setup(f);f.cards[0].receiver.blockInfo.state=3;assert.equal(rt.tick().cardRuleDetail,'metadata_state');f.cards[0].receiver.blockInfo.state=0;assert.equal(rt.tick().cardRuleDetail,undefined);rt.advance(100);assert.equal(rt.tick().reason,'plan_ready');
});
test('V3.2 live rule rejection preserves uncertain pending and breaks consecutive confirmation',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');
 f.cards.find(c=>c!==picked).receiver.blockInfo.type='bad';rt.advance(100);let r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,'metadata_type');assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);
 f.cards.find(c=>c!==picked).receiver.blockInfo.type=1;rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(100);assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});

test('V3.2 a special_info accessor is not treated as a missing unlocked value and is never invoked',()=>{
 const f=makeFixture();let hits=0;Object.defineProperty(f.cards[0].receiver.blockInfo,'special_info',{get(){hits++;return {type:1,lock_state:2};}});
 const r=setup(f).tick();assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,'metadata_special_type');assert.equal(hits,0);assert.equal(f.calls.length,0);
});


test('regression: unfinishable locked group no longer stops confirmed progress through two exposed triples',()=>{
 const records=['a','a','a','b','b','b','c','c','c'].map((type,i)=>({zone:'board',type,x:-240+80*(i%7),y:Math.floor(i/7)*100}));
 const f=makeFixture(records);f.cards[6].receiver.blockInfo.special_info={type:1,lock_state:2};f.cards[6].receiver.SpecialNode.active=true;f.cards[6].receiver.SpecialNode.activeInHierarchy=true;
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});};
 const rt=setup(f);let r;
 for(let i=0;i<80;i++){rt.advance(100);r=rt.tick();assert.notEqual(r.reason,'planner_invalid_move');assert.notEqual(r.reason,'confirmation_uncertain');}
 assert.equal(r.confirmedMoves,6);assert.equal(f.calls.length,6);assert.equal(f.board.children.length,3);assert.equal(f.tray.children.length,0);assert.equal(r.reason,'no_complete_solution');assert.equal(r.awaitingBoardChange,false);
});
test('independent replay rejects global-format proof and picks appended beyond the first trio',()=>{
 for(const change of [p=>{p.proofKind='all_observed_triples';},(p,s)=>{p.sequence.push(s.cards[3].id);p.actions=p.sequence.slice();}]){
  const f=makeFixture(['a','a','a','b'].map((type,i)=>({zone:'board',type,x:-160+80*i}))),rt=setup(f,{planner:s=>{const p=directProof(s,s.cards[0].id);change(p,s);return p;}});
  rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);
 }
});

function attachMission(f,type,current=0,total=9){
 const taskNode=f.node(),task={className:'Task',node:taskNode,isValid:true,enabled:true,enabledInHierarchy:true};taskNode.comps.push(task);f.game.children.push(taskNode);taskNode.parent=f.game;
 const layer={className:'GameLayer',node:f.game,isValid:true},game={className:'Game',node:f.root,isValid:true,enabled:true,enabledInHierarchy:true,GameLayer:layer,Task:task};f.root.comps.push(game);
 const store={task_info:{target_block_type:type,current_num:current,total_num:total},pile_blocks:[],hand_blocks:[],storage_blocks:[],isWatcher:false};
 let loads=0;f.loader=name=>{assert.equal(name,'GameStore');loads++;return {default:store};};return {store,task,game,layer,loads:()=>loads};
}
function missionFixture(){return makeFixture([{zone:'board',type:'a',x:-240,numericType:1},{zone:'board',type:'m',x:-80,numericType:2},{zone:'board',type:'m',x:0,numericType:2},{zone:'board',type:'m',x:80,numericType:2},{zone:'tray',type:'a',x:-240,numericType:1},{zone:'tray',type:'a',x:-160,numericType:1}]);}
test('loaded GameStore mission is matched to Block numeric type and prioritized via original event',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=reachDispatch(f);assert.equal(f.calls[0].event,f.cards[1].event);
 const d=rt.tick().planning.mission;assert.deepEqual(d,{status:'priority',targetType:2,current:0,total:9});assert.ok(m.loads()>0);assert.equal(m.store.task_info.current_num,0,'never fabricates mission progress');
});
test('original old Task UI during reward animation cannot override new authoritative Store mission',()=>{
 const f=missionFixture(),m=attachMission(f,2);m.task.curCountLabel={string:'9'};m.task.totalCountLabel={string:'9'};
 reachDispatch(f);assert.equal(f.calls[0].event,f.cards[1].event);
});
test('mission target change between planning and dispatch cancels the prepared action and replans first',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=setup(f);rt.tick();rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');
 m.store.task_info={target_block_type:1,current_num:0,total_num:3};rt.advance(200);const r=rt.tick();assert.equal(r.reason,'plan_ready');assert.equal(f.calls.length,0);
 rt.advance(200);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(f.calls[0].event,f.cards[0].event);
});
test('mission progress changes invalidate prepared routes, not pending actions or confirmation',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=reachDispatch(f),chosen=f.cards.find(c=>c.event===f.calls[0].event);
 m.store.task_info.current_num=3;rt.advance(10000);assert.equal(rt.tick().reason,'confirmation_uncertain');assert.equal(f.calls.length,1);
 move(f,chosen,f.tray);rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(200);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('completed mission and unobserved target use existing normal pair completion',()=>{
 for(const [target,current,total,status] of [[2,9,9,'complete'],[999,0,9,'fallback']]){
  const f=missionFixture();attachMission(f,target,current,total);const rt=reachDispatch(f);assert.equal(f.calls[0].event,f.cards[0].event);assert.equal(rt.tick().planning.mission.status,status);
 }
});
for(const fault of ['missing_loader','throwing_loader','accessor_loader','invalid_info','accessor_info','bad_type','bad_progress','watcher','wrong_layer','wrong_task','duplicate_game','foreign_task'])test('optional mission '+fault+' cannot interrupt or redirect valid normal play',()=>{
 const f=missionFixture(),m=attachMission(f,2);let accessed=0;
 if(fault==='missing_loader')delete f.loader;
 if(fault==='throwing_loader')f.loader=()=>{throw Error('unavailable');};
 if(fault==='invalid_info')m.store.task_info=null;
 if(fault==='accessor_info')Object.defineProperty(m.store,'task_info',{get(){accessed++;throw Error('must not read');}});
 if(fault==='bad_type')m.store.task_info.target_block_type='2';
 if(fault==='bad_progress')m.store.task_info.current_num=-1;
 if(fault==='watcher')m.store.isWatcher=true;
 if(fault==='wrong_layer')m.layer.node=f.board;
 if(fault==='wrong_task')m.task.className='OtherTask';
 if(fault==='duplicate_game')f.root.comps.push({...m.game});
 if(fault==='foreign_task')m.task.node=f.node();
 const rt=setup(f);
 if(fault==='accessor_loader')Object.defineProperty(rt.context.window,'__require',{get(){accessed++;throw Error('must not call');}});
 reachDispatch(f,rt);assert.equal(f.calls[0].event,f.cards[0].event);assert.equal(rt.tick().planning.mission.status,'unavailable');assert.equal(accessed,0);
});
test('mission disappearance before execution cannot dispatch the stale priority card',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=setup(f);rt.tick();rt.advance(200);rt.tick();m.store.task_info=null;
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);rt.advance(200);rt.tick();assert.equal(f.calls[0].event,f.cards[0].event);
});
test('mission reward modal never authorizes auto claiming or spending a power',()=>{
 const f=missionFixture();attachMission(f,2);const alert=f.node();alert.comps.push({className:'TaskFinishAlert',enabled:true,enabledInHierarchy:true});f.root.children.push(alert);alert.parent=f.root;
 const rt=setup(f);assert.equal(rt.tick().reason,'modal_visible');rt.advance(10000);assert.equal(rt.tick().reason,'modal_visible');assert.equal(f.calls.length,0);
});

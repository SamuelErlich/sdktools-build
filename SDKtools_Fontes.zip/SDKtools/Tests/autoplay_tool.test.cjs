const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_tool.js'),'utf8');
const plannerSource=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_planner.js'),'utf8');
const xraySource=fs.readFileSync(path.join(__dirname,'../Resources/xray_overlay.js'),'utf8');
const visualFactorySource='(function(v){return ('+xraySource+')(('+plannerSource+'),v);})';
const extendedSource=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_extended.js'),'utf8');
const powersSource=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_powers.js'),'utf8');
const returnSource=fs.readFileSync(path.join(__dirname,'../Resources/return_tool.js'),'utf8');
const fastSource=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_fast.js'),'utf8');
const phaseSource=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_snapshot.js'),'utf8');
const coveredSource=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_covered.js'),'utf8');
const coopSource=fs.readFileSync(path.join(__dirname,'../Resources/autoplay_coop.js'),'utf8');
const hotTimeSource=fs.readFileSync(path.join(__dirname,'../Resources/alpaca_hottime.js'),'utf8');
// Legacy fixtures use arbitrary type:1 cards; protection is enabled explicitly in HotTime cases.
const permissiveHotTime=()=>({inspect(){},allows:()=>true,diagnostic:()=>({version:1,status:'fixture'}),reset(){}});
// Explicit synthetic preimages of layout tags. They are not recovered game names.
const names={bg:'\u0000\u0082\u00e3\u002e\u0048',diamond:'\u0000\u00e8\u00fb\u0069\u0078',mask:'\u0000\u00c6\u00e8\u0030\u00aa',tray:'\u0002\u00f8\u009a\u0044\u00db',warehouse:'\u442d\u2c08'};
function makeFixture(records=[{zone:'board',type:'a',x:-80,y:0},{zone:'board',type:'a',x:0,y:0},{zone:'board',type:'a',x:80,y:0}]){
 function Component(){} function Sprite(){} function Button(){} function EventHandler(){}
 function Touch(){} Touch.prototype.setTouchInfo=function(id,x,y){this.id=id;this.x=x;this.y=y;};Touch.prototype.getLocation=function(){return{x:this.x,y:this.y};};
 function EventTouch(touches,bubbles){this._touches=touches;this.bubbles=bubbles;this._eventCode=0;this.touch=null;}
 EventTouch.ENDED=2;EventTouch.prototype._setEventCode=function(code){this._eventCode=code;};EventTouch.prototype.getEventCode=function(){return this._eventCode;};EventTouch.prototype.getTouches=function(){return this._touches;};EventTouch.prototype.getLocation=function(){return this.touch.getLocation();};
 const calls=[],frames=new Map(),cards=[],typeIDs=new Map();
 Component.EventHandler=EventHandler;
 EventHandler.prototype.emit=function(args){calls.push({event:this,args});};
 function node(w=20,h=20,kids=[],extra={}){const n={width:w,height:h,x:0,y:0,z:0,anchorX:.5,anchorY:.5,angle:0,scaleX:1,scaleY:1,opacity:255,isValid:true,active:true,activeInHierarchy:true,children:kids,parent:null,comps:[],...extra};for(const c of kids)c.parent=n;n.getComponent=k=>n.comps.find(c=>c.kind===k||c.className===k)||null;n.getComponents=()=>n.comps;n.convertToWorldSpaceAR=p=>({x:n.x+p.x,y:n.y+p.y});return n;}
 function sprite(n,name){if(!frames.has(name))frames.set(name,{name,getRect:()=>({width:120,height:135})});const s={kind:Sprite,node:n,spriteFrame:frames.get(name),enabled:true,enabledInHierarchy:true};n.comps.push(s);return s;}
 const board=node(560,720,[],{y:67}),tray=node(560,80,[],{y:10}),reserve=node(240,90,[],{y:-420.594});
 const trayBg=node(600,130,[tray]);sprite(trayBg,names.tray);
 const boardLayer=node(750,1623.188,[board]),trayLayer=node(750,1623.188,[trayBg]),reserveLayer=node(750,1623.188,[reserve]);
 const game=node(750,1623.188,[boardLayer,trayLayer,reserveLayer]);const root=node(0,0,[game],{active:false});
 for(const r of records){const face=node(80,90);sprite(face,'mock_face_'+r.type);const bg=node(80,90,[face]);sprite(bg,r.backgroundTag==='6be7dcd3'?names.diamond:names.bg);const mask=node(80,90,[],{opacity:128,active:!!r.mask,activeInHierarchy:!!r.mask});sprite(mask,names.mask);
  const card=node(80,90,[bg,node(20,20,[],{active:false,activeInHierarchy:false}),mask,node(20,20,[],{active:false,activeInHierarchy:false}),node(20,20,[],{active:false,activeInHierarchy:false})],{x:r.x||0,y:r.y||0});
  if(!typeIDs.has(r.type))typeIDs.set(r.type,typeIDs.size+1);
  const gridRow=(card.x+240)/5,gridCol=(315-card.y)/4.5,layer=r.layer===undefined?cards.length:r.layer;
  const receiver={kind:Component,className:'Block',isValid:true,node:card,canTouch:r.zone!=='tray'&&!r.mask,isTouched:false,
   blockInfo:{id:r.rawID||`${layer}-${gridRow}-${gridCol}`,type:r.numericType===undefined?typeIDs.get(r.type):r.numericType,state:r.zone==='tray'?1:r.zone==='reserve'?2:0,layer,row:gridRow,col:gridCol},
   BgSprite:bg.comps[0],SkinSprite:face.comps[0],MaskNode:mask,SpecialNode:card.children[1],HotTimeAnimNode:card.children[3],BombAnimNode:card.children[4],
   touchBlock(){throw Error('Direct callback forbidden in test');}};card.comps.push(receiver);
  const event=new EventHandler();Object.assign(event,{target:card,component:'Block',handler:'touchBlock',customEventData:''});
  const button={kind:Button,isValid:true,node:card,enabled:true,enabledInHierarchy:true,interactable:r.zone!=='tray'&&!r.mask,clickEvents:[event]};card.comps.push(button);
  const parent=r.zone==='tray'?tray:r.zone==='reserve'?reserve:board;parent.children.push(card);card.parent=parent;cards.push({node:card,button,event,receiver,face,bg,mask,type:r.type,observedID:r.id});
 }
 const cc={ENGINE_VERSION:'2.4.4',Component,Sprite,Button,Touch,Event:{EventTouch,AT_TARGET:2},Node:{EventType:{TOUCH_END:'touchend'}},v2:(x,y)=>({x,y}),js:{getClassName:c=>c.className||'Other'},director:{getScene:()=>root}};
 return{cc,node,sprite,board,tray,reserve,root,game,cards,calls,frames,EventHandler};
}
// The adapter uses performance.now; its embedded planner uses Date.now. Both
// must share controlled time so scheduler delays cannot consume the 8ms budget.
function setup(f,{planner,clockStep=0,xrayFactory,coveredFactory,phaseFactory=false,fastFactory=false,hotTimeFactory=permissiveHotTime}={}){let now=0;const win={cc:f.cc,...(f.loader?{__require:f.loader}:{})};win.top=win;const context=vm.createContext({window:win,document:{visibilityState:'visible',readyState:'complete'},performance:{now:()=>{now+=clockStep;return now;}},Date:{now:()=>now},setTimeout:()=>1,clearTimeout:()=>{},input:null,planner:planner||null,xrayFactory:xrayFactory||null,coveredFactory:coveredFactory||null,phaseFactory:phaseFactory,fastFactory:fastFactory,hotTimeFactory});
 vm.runInContext('var runtime=('+source+')(planner||('+extendedSource+')(('+plannerSource+')),xrayFactory||('+visualFactorySource+'),('+powersSource+'),('+returnSource+'),coveredFactory===true?('+coveredSource+'):coveredFactory,phaseFactory===true?('+phaseSource+'):null,fastFactory===true?('+fastSource+'):null,('+coopSource+')(('+plannerSource+')),hotTimeFactory===true?('+hotTimeSource+'):hotTimeFactory);',context,{timeout:500});
 return{context,advance:n=>{now+=n;},tick(options={}){context.input={command:'tick',allowAction:true,resumeGeneration:1,...options};return JSON.parse(JSON.stringify(vm.runInContext('runtime(input)',context,{timeout:1000})));}};
}
function reachDispatch(f,rt=setup(f)){assert.equal(rt.tick().status,'waiting_stability');rt.advance(250);assert.equal(rt.tick().reason,'plan_ready');rt.advance(250);const result=rt.tick();assert.equal(result.status,'original_event_dispatched',JSON.stringify(result));return rt;}
function move(f,card,to){const a=card.node.parent.children;a.splice(a.indexOf(card.node),1);to.children.push(card.node);card.node.parent=to;card.node.x=-240+80*(to.children.length-1);card.node.y=0;card.mask.active=false;card.mask.activeInHierarchy=false;card.receiver.blockInfo.state=to===f.tray?1:to===f.reserve?2:0;card.receiver.canTouch=to!==f.tray;card.button.interactable=to!==f.tray;}

function directProof(input,firstID){
 const first=input.cards.find(c=>c.id===firstID),existing=input.tray.filter(c=>c.type===first.type);
 const selected=[first,...input.cards.filter(c=>c.id!==firstID&&c.available&&c.type===first.type)].slice(0,3-existing.length);
 const sequence=selected.map(c=>c.id);return{status:'move',proofKind:'local_trio',cardID:firstID,sequence,actions:sequence.slice(),matchedType:first.type,
  tripleCardIDs:[...existing,...selected].map(c=>c.id),peakTrayCount:input.tray.length+sequence.length};
}
test('plans on one tick and emits exact registered event with a real engine touch event on following revalidated tick',()=>{const f=makeFixture();reachDispatch(f);assert.equal(f.calls.length,1);assert.equal(f.calls[0].args.length,1);const e=f.calls[0].args[0];assert.ok(e instanceof f.cc.Event.EventTouch);assert.equal(e.target,f.calls[0].event.target);assert.equal(e.currentTarget,e.target);assert.equal(e.type,'touchend');assert.equal(e.getEventCode(),2);assert.equal(e.getTouches()[0],e.touch);assert.equal(e.getLocation().x,e.target.x);assert.equal(e.getLocation().y,e.target.y);});
test('waiting result never repeats even after eight seconds or pause reset resume',()=>{const f=makeFixture(),rt=reachDispatch(f);rt.advance(9000);assert.equal(rt.tick().reason,'confirmation_uncertain');for(const cmd of ['pause','reset'])assert.equal(rt.tick({command:cmd}).awaitingBoardChange,true);rt.advance(1000);assert.equal(rt.tick({resumeGeneration:3}).awaitingBoardChange,true);assert.equal(f.calls.length,1);});
test('same identity in tray and exact correlated state must settle twice before confirmation',()=>{const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);const r=rt.tick();assert.equal(r.status,'move_confirmed');assert.equal(r.confirmedMoves,1);assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,1);});
test('unrelated removal cannot confirm selected card movement',()=>{const f=makeFixture(),rt=reachDispatch(f),other=f.cards.find(c=>c.event!==f.calls[0].event);move(f,other,f.tray);rt.advance(250);assert.equal(rt.tick().status,'waiting_confirmation');assert.equal(f.calls.length,1);});
test('matching trio removal is confirmed only with exact remaining tray and board identities',()=>{const f=makeFixture([{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0},{zone:'tray',type:'a',x:-160,y:0}]),rt=reachDispatch(f);f.board.children=[];f.tray.children=[];for(const c of f.cards)c.node.parent=null;rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);assert.equal(rt.tick().status,'move_confirmed');});
test('throwing original event preserves uncertain pending and never repeats',()=>{const f=makeFixture();f.EventHandler.prototype.emit=function(){f.calls.push('attempt');throw Error('original');};const rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);assert.equal(rt.tick().status,'dispatch_uncertain');rt.advance(10000);assert.equal(rt.tick().awaitingBoardChange,true);assert.equal(f.calls.length,1);});
test('original no-op stays pending with no invented success',()=>{const f=makeFixture(),rt=reachDispatch(f);rt.advance(1000);assert.equal(rt.tick().confirmedMoves,0);});
test('action-disabled ticks never dispatch and discard prepared plan',()=>{const f=makeFixture(),rt=setup(f);assert.equal(rt.tick({allowAction:false}).status,'watching');rt.advance(250);rt.tick();rt.advance(250);rt.tick();assert.equal(rt.tick({allowAction:false}).status,'watching');rt.advance(250);assert.equal(rt.tick().status,'waiting_stability');assert.equal(f.calls.length,0);});
test('changed generation restarts stability without dispatching stale plan',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);assert.equal(rt.tick({resumeGeneration:2}).reason,'observing_board');assert.equal(f.calls.length,0);});
test('changed board after planning invalidates the prepared selection',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();f.cards[0].node.x=-160;rt.advance(250);assert.equal(rt.tick().reason,'animation_active');assert.equal(f.calls.length,0);});
test('only exposed unmasked registered controls can be selected',()=>{const f=makeFixture([{zone:'board',type:'a',x:0,y:0,mask:true},{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0}]);const rt=reachDispatch(f);assert.equal(f.calls[0].event,f.cards[1].event);assert.equal(rt.tick().awaitingBoardChange,true);});
test('mask and computed overlap disagreement blocks',()=>{const f=makeFixture();f.cards[0].mask.active=true;f.cards[0].mask.activeInHierarchy=true;assert.equal(setup(f).tick().reason,'occlusion_mismatch');assert.equal(f.calls.length,0);});
test('unknown face and changing card effect stop state acquisition',()=>{const f=makeFixture();f.cards[0].face.comps[0].spriteFrame.name='';assert.equal(setup(f).tick().reason,'unknown_card');const g=makeFixture();g.cards[0].node.children[3].active=true;g.cards[0].node.children[3].activeInHierarchy=true;assert.equal(setup(g).tick().reason,'card_effect_active');});
test('matching uses original numeric block type even when same skin has different SpriteFrame objects',()=>{const f=makeFixture();const old=f.cards[1].face.comps[0].spriteFrame;f.cards[1].face.comps[0].spriteFrame={...old};let observed;const rt=setup(f,{planner:input=>{observed=input;return{status:'blocked'};}});rt.tick();rt.advance(250);rt.tick();assert.equal(observed.cards[0].type,observed.cards[1].type);});
test('disabled control is excluded and malicious planner choice rejected',()=>{const f=makeFixture();f.cards[0].button.interactable=false;f.cards[0].receiver.canTouch=false;const rt=setup(f,{planner:input=>({status:'move',cardID:input.cards[0].id})});rt.tick();rt.advance(250);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);});
test('invalid target or duplicate touchBlock handlers cannot dispatch',()=>{for(const change of[f=>{f.cards[0].event.target=f.root;},f=>{f.cards[0].node.comps.push({...f.cards[0].receiver});}]){const f=makeFixture();change(f);assert.equal(setup(f).tick().status,'blocked');assert.equal(f.calls.length,0);}});
test('custom data and replaced original emitter instance fail closed',()=>{for(const change of[f=>{f.cards[0].event.customEventData='payload';},f=>{f.cards[0].event.emit=()=>{};}]){const f=makeFixture();change(f);assert.equal(setup(f).tick().reason,'event_mismatch');}});
test('modal before action cancels and pauses original event dispatch',()=>{const f=makeFixture(),rt=setup(f);rt.tick();rt.advance(250);rt.tick();const modal=f.node(240,102);f.root.children.push(modal);modal.parent=f.root;rt.advance(250);assert.equal(rt.tick().reason,'modal_visible');assert.equal(f.calls.length,0);});
test('unsupported version, hidden document and conflicting versions block',()=>{const f=makeFixture(),rt=setup(f);rt.context.window.CocosEngine='2.4.5';assert.equal(rt.tick().reason,'engine_version');const g=makeFixture(),rg=setup(g);rg.context.document.visibilityState='hidden';assert.equal(rg.tick().reason,'document_unavailable');});
test('offscreen startup tween and tray tween are never actionable',()=>{const f=makeFixture();f.cards[0].node.x=400;assert.equal(setup(f).tick().reason,'animation_active');const g=makeFixture([{zone:'tray',type:'a',x:-240,y:1}]);assert.equal(setup(g).tick().reason,'animation_active');});
test('unknown tray layout, full bar and duplicate board block',()=>{const f=makeFixture();f.tray.width=640;assert.equal(setup(f).tick().reason,'board_ambiguous');const g=makeFixture(Array.from({length:7},(_,i)=>({zone:'tray',type:'a'+i,x:-240+80*i,y:0})));assert.equal(setup(g).tick().reason,'tray_full');const h=makeFixture();const extra=h.node(560,720);h.game.children.push(extra);extra.parent=h.game;assert.equal(setup(h).tick().reason,'board_ambiguous');});
test('snapshot budget exit cannot dispatch',()=>{const f=makeFixture(),rt=setup(f,{clockStep:1});assert.equal(rt.tick().reason,'time_budget');assert.equal(f.calls.length,0);});
test('embedded planner budget still prevents dispatch when its injected clock expires',()=>{const f=makeFixture(),rt=setup(f);let plannerNow=0;rt.context.Date.now=()=>{plannerNow+=8;return plannerNow;};assert.equal(rt.tick().status,'waiting_stability');rt.advance(250);assert.equal(rt.tick().reason,'search_in_progress');assert.equal(f.calls.length,0);});
test('stable replacement scene retires old pending without counting a success or replaying',()=>{const f=makeFixture(),rt=reachDispatch(f),other=makeFixture();rt.context.window.cc=other.cc;rt.advance(250);const r=rt.tick();assert.equal(r.reason,'new_board_stability');assert.equal(r.awaitingBoardChange,true);rt.advance(250);const settled=rt.tick();assert.equal(settled.reason,'new_board_detected');assert.equal(settled.confirmedMoves,0);assert.equal(settled.awaitingBoardChange,false);assert.equal(f.calls.length,1);assert.equal(other.calls.length,0);});
test('resource is bounded and contains no network, captured code execution or injected timer',()=>{assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout)\s*\(/);assert.doesNotMatch(source,/new\s+Function\b/);});

const fixturePath=path.join(__dirname,'fixtures/autoplay-board-observed-v25.json');
test('replays 228 real captured card geometries with explicit synthetic method mocks',()=>{const observed=JSON.parse(fs.readFileSync(fixturePath,'utf8'));assert.equal(observed.sequence,133);const f=makeFixture(observed.cards);let input;const rt=setup(f,{planner:value=>{input=value;return{status:'blocked'};}});const first=rt.tick();assert.equal(first.cardsRead,228,JSON.stringify(first));assert.equal(first.status,'waiting_stability',JSON.stringify(first));rt.advance(250);assert.equal(rt.tick().reason,'no_safe_move');assert.equal(input.cards.length,228);assert.equal(input.cards.filter(c=>c.zone==='board').length,225);assert.equal(input.cards.filter(c=>c.blockedBy.length>0).length,180);assert.equal(input.cards.filter(c=>c.available).length,48);assert.equal(new Set(input.cards.map(c=>c.type)).size,16);assert.equal(input.tray.length,0);assert.equal(input.capacity,7);assert.equal(f.calls.length,0);});

test('transient seventh tray card preserves pending until original trio settles',()=>{
 const records=[...['a','b','b','c','c','d','d','e','e'].map((type,i)=>({zone:'board',type,x:-240+80*(i%7),y:Math.floor(i/7)*90})),...['a','a','b','c','d','e'].map((type,i)=>({zone:'tray',type,x:-240+80*i,y:0}))];
 const f=makeFixture(records),rt=reachDispatch(f),picked=f.cards[0];move(f,picked,f.tray);rt.advance(250);
 const transient=rt.tick();assert.equal(transient.reason,'tray_full');assert.equal(transient.awaitingBoardChange,true);assert.equal(f.calls.length,1);
 for(const c of f.cards.filter(c=>c.type==='a'))c.node.parent=null;
 f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(250);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('new board container in same scene retires old pending after stability without replay',()=>{
 const f=makeFixture(),rt=reachDispatch(f),other=makeFixture();f.root.children=[other.game];other.game.parent=f.root;other.cc.director.getScene=()=>f.root;rt.context.window.cc=other.cc;
 rt.advance(250);assert.equal(rt.tick().reason,'new_board_stability');rt.advance(250);const r=rt.tick();assert.equal(r.reason,'new_board_detected');assert.equal(r.confirmedMoves,0);assert.equal(f.calls.length,1);assert.equal(other.calls.length,0);
});

test('real planner and guarded adapter continuously complete two triples with six confirmed original events',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i,y:0})));
 f.EventHandler.prototype.emit=function(args){
  f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);
  const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);
  if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}
  f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 };
 const rt=setup(f);let r,confirmationCount=0;
 for(let i=0;i<100;i++){
  const before=f.calls.length;rt.advance(250);r=rt.tick();assert.ok(f.calls.length-before<=1,'at most one original event per tick');
  assert.notEqual(r.status,'dispatch_uncertain');assert.notEqual(r.reason,'read_error');
  if(r.status==='move_confirmed')confirmationCount++;
  if(r.confirmedMoves===6)break;
 }
 assert.equal(r.confirmedMoves,6);assert.equal(confirmationCount,6);assert.equal(f.calls.length,6);assert.equal(f.board.children.length,0);assert.equal(f.tray.children.length,0);assert.equal(r.awaitingBoardChange,false);
});

const v26Fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v26.json'),'utf8'));
function observedV26(sequence){return v26Fixture.snapshots.find(s=>s.sequence===sequence).cards.map(row=>Object.fromEntries(v26Fixture.columns.map((key,i)=>[key,row[i]])));}
function applyObservedState(f,records){
 for(const parent of [f.board,f.tray,f.reserve])parent.children=[];
 for(const r of records){
  const c=f.cards.find(c=>c.observedID===r.id);assert.ok(c,'captured identity must remain present');assert.equal(c.type,r.type);
  const parent=r.zone==='tray'?f.tray:r.zone==='reserve'?f.reserve:f.board;
  parent.children.push(c.node);c.node.parent=parent;c.node.x=r.x;c.node.y=r.y;
  c.mask.active=r.mask;c.mask.activeInHierarchy=r.mask;c.button.interactable=r.zone!=='tray'&&!r.mask;c.receiver.canTouch=c.button.interactable;c.receiver.blockInfo.state=r.zone==='tray'?1:r.zone==='reserve'?2:0;
 }
}
for(const [seq,board,tray,reserve] of [[2,225,0,0],[30,224,1,0],[51,225,0,0],[120,222,3,0],[147,222,0,3]]){
 test('new real capture seq '+seq+' reads all 225 cards and plans with observed tray/reserve geometry',()=>{
  const records=observedV26(seq),f=makeFixture(records),rt=setup(f);
  const types=new Map();for(const c of records){if(!types.has(c.type))types.set(c.type,new Set());types.get(c.type).add(c.frameID);}
  assert.equal(types.size,16);for(const frames of types.values())assert.equal(frames.size,1,'no cloned SpriteFrame identity is observed per type');
  assert.equal(f.board.children.length,board);assert.equal(f.tray.children.length,tray);assert.equal(f.reserve.children.length,reserve);
  const first=rt.tick();assert.equal(first.status,'waiting_stability',JSON.stringify(first));assert.equal(first.cardsRead,225);assert.equal(first.cardTypesRead,16);
  rt.advance(250);const search=rt.tick();assert.equal(search.reason,'plan_ready');assert.equal(search.planning.state,'proved');assert.equal(search.planning.goal,'next_trio');assert.equal(f.calls.length,0);
 });
}
test('captured local trio prepares while a later manual board change invalidates the old selection',()=>{
 const f=makeFixture(observedV26(2)),chosen=f.cards.find(c=>c.observedID==='n920'),index=f.cards.indexOf(chosen);
 const rt=setup(f,{planner:input=>directProof(input,input.cards[index].id)});rt.tick();rt.advance(100);
 assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);
 applyObservedState(f,observedV26(30));rt.advance(100);assert.equal(rt.tick().reason,'observing_board');assert.equal(rt.tick().confirmedMoves,0);
});
test('three tray-to-reserve power movements cannot masquerade as confirmation of a dispatched board card',()=>{
 const records=[...['a','a','b','b','c','c'].map((type,i)=>({zone:'board',type,x:-240+80*i})),...['a','b','c'].map((type,i)=>({zone:'tray',type,x:-240+80*i}))];
 const f=makeFixture(records),rt=reachDispatch(f);
 for(const card of f.cards.filter(c=>c.node.parent===f.tray))move(f,card,f.reserve);
 rt.advance(100);const r=rt.tick();assert.equal(r.status,'waiting_confirmation');assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);assert.equal(f.calls.length,1);
});
test('bounded type-count diagnostic resets when complete state is unavailable',()=>{
 const f=makeFixture(),rt=setup(f);assert.equal(rt.tick().cardTypesRead,1);
 f.cards[0].face.comps[0].spriteFrame.name='';const blocked=rt.tick();assert.equal(blocked.reason,'unknown_card');assert.equal(blocked.cardTypesRead,0);
 assert.equal(rt.tick({command:'pause'}).cardTypesRead,0);
});
test('registered callback consuming event.target receives an EventTouch and changes the board once',()=>{
 const f=makeFixture();
 for(const card of f.cards)card.receiver.touchBlock=function(event){
  assert.ok(event instanceof f.cc.Event.EventTouch);assert.equal(event.getEventCode(),2);
  assert.equal(event.target,this.node);assert.equal(event.currentTarget,this.node);move(f,card,f.tray);
 };
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});this.target.getComponent(this.component)[this.handler](...args);};
 const rt=reachDispatch(f);assert.equal(f.tray.children.length,1);rt.advance(250);assert.equal(rt.tick().reason,'confirm_stability');
 rt.advance(250);assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});
test('missing touch contract or nonfinite world coordinates blocks before any original event or pending state',()=>{
 for(const change of [f=>{delete f.cc.Touch;},f=>{f.cc.Event.EventTouch.ENDED=0;},f=>{for(const c of f.cards)c.node.convertToWorldSpaceAR=()=>({x:NaN,y:0});},f=>{delete f.cc.Event.EventTouch.prototype._setEventCode;}]){
  const f=makeFixture();change(f);const rt=setup(f);rt.tick();rt.advance(250);rt.tick();rt.advance(250);
  const r=rt.tick();assert.equal(r.reason,'input_event_unavailable');assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,0);
 }
});

function terminalTransitionFixture(){
 const f=makeFixture([{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0},{zone:'tray',type:'a',x:-160,y:0},
  ...Array.from({length:18},(_,i)=>({zone:'board',type:i<9?'b':'c',x:-240+80*(i%7),y:-180+90*Math.floor(i/7)}))]);
 const future=f.cards.slice(3);f.board.children=[f.cards[0].node];for(const c of future)c.node.parent=null;
 return{f,replace(reuse=false){f.board.children=[];f.tray.children=[];
  for(const c of f.cards)c.node.parent=null;
  (reuse?f.cards:future).forEach((c,i)=>{f.board.children.push(c.node);c.node.parent=f.board;c.node.x=-240+80*(i%7);c.node.y=-180+90*Math.floor(i/7);c.receiver.blockInfo.state=0;c.receiver.blockInfo.row=(c.node.x+240)/5;c.receiver.blockInfo.col=(315-c.node.y)/4.5;c.receiver.blockInfo.id=`${c.receiver.blockInfo.layer}-${c.receiver.blockInfo.row}-${c.receiver.blockInfo.col}`;c.receiver.canTouch=true;c.button.interactable=true;});
 },modal(){const n=f.node(240,102);f.root.children.push(n);n.parent=f.root;return()=>{f.root.children.splice(f.root.children.indexOf(n),1);n.parent=null;};}};
}
for(const reuse of [false,true])test('terminal modal and large stable refill retires pending in same containers, pooled old identities='+reuse,()=>{
 const t=terminalTransitionFixture(),rt=reachDispatch(t.f),close=t.modal();rt.advance(200);assert.equal(rt.tick().reason,'modal_visible');close();t.replace(reuse);
 rt.advance(200);assert.equal(rt.tick().reason,'new_board_stability');rt.advance(200);const r=rt.tick();
 assert.equal(r.reason,'new_board_detected');assert.equal(r.awaitingBoardChange,false);assert.equal(r.confirmedMoves,0);assert.equal(t.f.calls.length,1);
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(t.f.calls.length,1);
 rt.advance(200);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(t.f.calls.length,2);
});
test('same-container refill without postdispatch modal never retires pending',()=>{
 const t=terminalTransitionFixture(),rt=reachDispatch(t.f);t.replace();rt.advance(10000);const r=rt.tick();
 assert.equal(r.reason,'confirmation_uncertain');assert.equal(r.awaitingBoardChange,true);assert.equal(t.f.calls.length,1);
});
test('same-container refill after modal with nonterminal previous move remains uncertain',()=>{
 const t=terminalTransitionFixture();const third=t.f.tray.children.pop();third.parent=t.f.board;third.x=80;third.y=0;const revived=t.f.cards.find(c=>c.node===third);revived.receiver.blockInfo.state=0;revived.receiver.canTouch=true;revived.button.interactable=true;revived.receiver.blockInfo.row=64;revived.receiver.blockInfo.col=70;revived.receiver.blockInfo.id=`${revived.receiver.blockInfo.layer}-64-70`;t.f.board.children.push(third);const rt=reachDispatch(t.f),close=t.modal();rt.advance(200);rt.tick();close();t.replace();rt.advance(10000);
 assert.equal(rt.tick().reason,'confirmation_uncertain');assert.equal(t.f.calls.length,1);
});
test('modal breaks consecutive confirmation observations',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');const modal=f.node(240,102);f.root.children.push(modal);modal.parent=f.root;
 rt.advance(200);assert.equal(rt.tick().reason,'modal_visible');f.root.children.pop();modal.parent=null;
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(200);assert.equal(rt.tick().status,'move_confirmed');
});
test('pause and resume generation restart proof without discarding the pending action',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');assert.equal(rt.tick({command:'pause'}).awaitingBoardChange,true);
 rt.advance(1000);assert.equal(rt.tick({resumeGeneration:2}).reason,'confirm_stability');rt.advance(200);
 assert.equal(rt.tick({resumeGeneration:2}).status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('confirmed snapshots seed stability but next plan still requires fresh separate dispatch tick',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(200);assert.equal(rt.tick().status,'move_confirmed');
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,1);
 rt.advance(200);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(f.calls.length,2);
});
test('changed confirmed state is observed again before preparing next plan',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);
 rt.advance(200);rt.tick();rt.advance(200);rt.tick();f.board.children[0].x=-200;rt.advance(200);
 assert.equal(rt.tick().reason,'animation_active');assert.equal(f.calls.length,1);
});

function addWarehouse(f,card){
 const slots=[-88,0,88].map(x=>f.node(84,94,[],{x})),row=f.node(260,94,slots,{y:8}),panel=f.node(272,126,[row],{x:161,y:-414.594}),layer=f.node(750,1623.188,[panel]);
 f.game.children.push(layer);layer.parent=f.game;const sprite=f.sprite(panel,names.warehouse);sprite.spriteFrame.getRect=()=>({width:272,height:126});
 for(const n of slots){const receiver={kind:f.cc.Component,className:'CommonStoreItem',node:n,isValid:true,isEmpty:true,isSelf:true,onBtnClick(){throw Error('Warehouse must not be clicked');}};
  const event=new f.EventHandler();Object.assign(event,{target:n,component:'CommonStoreItem',handler:'onBtnClick',customEventData:''});
  const button={kind:f.cc.Button,isValid:true,node:n,enabled:true,enabledInHierarchy:true,interactable:true,clickEvents:[event]};n.comps.push(receiver,button);n.receiver=receiver;n.button=button;
 }
 const a=card.node.parent.children;a.splice(a.indexOf(card.node),1);slots[2].children.push(card.node);card.node.parent=slots[2];card.node.x=0;card.node.y=0;slots[2].receiver.isEmpty=false;
 return{slots,row,panel,layer,card};
}
test('settled card in verified CommonStoreItem never blocks as animation and is never selectable',()=>{
 const f=makeFixture(['a','a','a','x'].map((type,i)=>({zone:'board',type,x:-160+80*i,y:0}))),w=addWarehouse(f,f.cards[3]);let input;const rt=setup(f,{planner:s=>{input=s;return directProof(s,s.cards[0].id);}});
 reachDispatch(f,rt);assert.equal(input.cards.length,3);assert.equal(input.tray.length,0);assert.notEqual(f.calls[0].event,w.card.event);assert.equal(rt.tick().cardsRead,3);
});
test('warehouse shape alone without exact component and original registration cannot exempt external card',()=>{
 for(const change of [w=>{w.slots[2].receiver.className='OtherStore';},w=>{w.slots[2].button.clickEvents[0].handler='other';},w=>{w.slots[2].button.clickEvents[0].customEventData='x';},w=>{w.slots[0].x=-87;},w=>{w.row.children.shift();}]){
  const f=makeFixture(),w=addWarehouse(f,f.cards[2]);change(w);const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'external_card');assert.equal(f.calls.length,0);
 }
});
test('moving, masked and duplicate warehouse cards retain animation block',()=>{
 for(const change of [w=>{w.card.node.x=1;},w=>{w.card.mask.active=true;w.card.mask.activeInHierarchy=true;},w=>{w.slots[2].receiver.isEmpty=true;},(w,f)=>{const other=f.cards[1];f.board.children.splice(f.board.children.indexOf(other.node),1);w.slots[2].children.push(other.node);other.node.parent=w.slots[2];}]){
  const f=makeFixture(),w=addWarehouse(f,f.cards[2]);change(w,f);const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'warehouse_card_unsettled');assert.equal(f.calls.length,0);
 }
});
test('warehouse face mutation after plan invalidates selected action',()=>{
 const f=makeFixture(['a','a','a','x'].map((type,i)=>({zone:'board',type,x:-160+80*i,y:0}))),w=addWarehouse(f,f.cards[3]),rt=setup(f);rt.tick();rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');
 w.card.face.comps[0].spriteFrame={name:'other_face',getRect:()=>({width:120,height:135})};rt.advance(200);
 assert.equal(rt.tick().reason,'observing_board');assert.equal(f.calls.length,0);
});
test('animation diagnostic identifies external card without allowing an unknown layout',()=>{
 const f=makeFixture(),card=f.cards[2];f.board.children.pop();f.game.children.push(card.node);card.node.parent=f.game;
 const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'external_card');assert.equal(r.awaitingBoardChange,false);
});
test('settled deterministic fixture at 100ms polling dispatches every400ms after initial move with full confirmation',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i,y:0})));
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);
  const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);
  if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}
  f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
 };
 const rt=setup(f),dispatchTimes=[];let result;
 for(let i=0;i<40;i++){rt.advance(100);result=rt.tick();if(result.dispatched)dispatchTimes.push((i+1)*100);if(result.confirmedMoves===6)break;}
 assert.equal(result.confirmedMoves,6);assert.equal(dispatchTimes.length,6);
 assert.deepEqual(dispatchTimes.slice(1).map((time,i)=>time-dispatchTimes[i]),[400,400,400,400,400]);
});
test('replays captured V2.8.1 sequence257 with215 board cards and one stationary warehouse card',()=>{
 const observed=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v29.json'),'utf8'));
 assert.equal(observed.sequence,257);assert.equal(observed.cards.length,215);assert.equal(observed.warehouseCard.id,'n917');
 const f=makeFixture([...observed.cards,{...observed.warehouseCard,zone:'board'}]),warehouse=f.cards.at(-1);addWarehouse(f,warehouse);
 const rt=setup(f),r=rt.tick();assert.equal(r.status,'waiting_stability',JSON.stringify(r));assert.equal(r.cardsRead,215);assert.equal(r.cardTypesRead,16);
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);
});

function enableRenderer(f){
 const graphics=[];
 // Keep the real tray background below the board in visual fixtures.
 // Its local child geometry still exercises the original tray reader.
 f.tray.parent.parent.y=-600;
 function decorate(n){
  n.addChild=function(child){if(child.parent)child.removeFromParent(false);this.children.push(child);child.parent=this;};
  n.removeFromParent=function(){if(this.parent){const list=this.parent.children,index=list.indexOf(this);if(index>=0)list.splice(index,1);this.parent=null;}};
  n.destroy=function(){this.isValid=false;};
  n.addComponent=function(kind){const c=new kind();Object.assign(c,{kind,node:this,enabled:true,enabledInHierarchy:true});this.comps.push(c);return c;};
  n.convertToWorldSpaceAR=function(p){let x=p.x,y=p.y,c=this;while(c){x=x*c.scaleX+c.x;y=y*c.scaleY+c.y;c=c.parent;}return{x,y};};
  n.convertToNodeSpaceAR=function(p){const ancestry=[];let c=this;while(c){ancestry.push(c);c=c.parent;}let x=p.x,y=p.y;for(c of ancestry.reverse()){x=(x-c.x)/c.scaleX;y=(y-c.y)/c.scaleY;}return{x,y};};
  for(const child of n.children)decorate(child);return n;
 }
 decorate(f.root);
 function CocosNode(name){const n=decorate(f.node());n.name=name;return n;}CocosNode.EventType=f.cc.Node.EventType;
 function Graphics(){this.paths=[];this.clears=0;graphics.push(this);}
 Graphics.prototype.clear=function(){this.paths=[];this.clears++;};
 Graphics.prototype.moveTo=function(x,y){this.paths.push(['move',x,y]);};
 Graphics.prototype.lineTo=function(x,y){this.paths.push(['line',x,y]);};
 Graphics.prototype.close=function(){this.paths.push(['close']);};Graphics.prototype.stroke=function(){this.paths.push(['stroke']);};Graphics.prototype.roundRect=function(){};Graphics.prototype.fill=function(){};
 f.cc.Node=CocosNode;f.cc.Graphics=Graphics;f.cc.Color=function(r,g,b,a){Object.assign(this,{r,g,b,a});};f.cc.Sprite.SizeMode={CUSTOM:0};
 return{graphics,overlay(){return f.game.children.find(n=>n.name==='SDKtools Card Hints');}};
}
function xrayFixture(){return makeFixture([{zone:'board',type:'a',x:0,y:0,mask:true},{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0}]);}
test('xray-only mode uses actual loaded frame icons and highlights proven trio including tray without dispatching',()=>{
 const f=xrayFixture(),render=enableRenderer(f),originalFrame=f.cards[0].face.comps[0].spriteFrame,rt=setup(f);
 let r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.xray.status,'ready');assert.equal(r.xray.coveredIcons,1);assert.equal(r.xray.matchedBorders,0);assert.equal(r.xray.depthLimit,1);
 rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'plan_ready');assert.equal(r.xray.matchedBorders,3);
 const overlay=render.overlay(),icon=overlay.children[0];assert.equal(overlay.parent,f.game);assert.notEqual(overlay.parent,f.board);
 assert.equal(icon.children.find(n=>n.name==='SDKtools Hint Artwork').getComponent(f.cc.Sprite).spriteFrame,originalFrame);assert.equal(icon.width,18);assert.equal(icon.height,20);
 assert.equal(f.cards[0].face.comps[0].spriteFrame,originalFrame);assert.equal(f.cards[0].mask.active,true);assert.equal(f.board.children.length,2);
 const iconClears=render.graphics.slice(1).map(g=>g.clears);
 for(let i=0;i<20;i++){rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'action_disabled');assert.equal(r.cardsRead,3);assert.equal(r.xray.matchedBorders,3);}
 assert.deepEqual(render.graphics.slice(1).map(g=>g.clears),iconClears,'unchanged badges/counts stay cached while borders repaint');assert.equal(f.calls.length,0);
 assert.deepEqual(overlay.comps.map(c=>c.kind),[f.cc.Graphics]);assert.equal(icon.comps.length,0);
});
test('xray follows board ancestor offsets even when card-local signatures do not change',()=>{
 const f=xrayFixture(),render=enableRenderer(f),rt=setup(f);rt.tick({allowAction:false,xrayEnabled:true});rt.advance(100);rt.tick({allowAction:false,xrayEnabled:true});
 const icon=render.overlay().children[0],beforeX=icon.x,beforeY=icon.y;
 const closest=(x,y)=>render.graphics[0].paths.filter(p=>p[0]==='move').sort((a,b)=>Math.hypot(a[1]-x,a[2]-y)-Math.hypot(b[1]-x,b[2]-y))[0];
 const oldPath=closest(beforeX,beforeY).slice();
 f.board.parent.x+=17;f.board.parent.y-=11;rt.advance(100);const r=rt.tick({allowAction:false,xrayEnabled:true});
 assert.equal(r.xray.status,'ready');assert.equal(icon.x,beforeX+17);assert.equal(icon.y,beforeY-11);
 const nextPath=closest(icon.x,icon.y);assert.equal(nextPath[1],oldPath[1]+17);assert.equal(nextPath[2],oldPath[2]-11);assert.equal(f.calls.length,0);
});
for(const interruption of ['chat','hotTime','power','pause','generation'])test('red borders resume after repeated '+interruption+' interruptions without toggling X-ray',()=>{
 const p=phaseFixture([{zone:'board',type:'a',x:0,y:0,mask:true},{zone:'board',type:'a',x:0,y:0},{zone:'tray',type:'a',x:-240,y:0}]),f=p.f,m=p.m,render=enableRenderer(f),rt=setup(f,{phaseFactory:true}),options={...phaseOptions,resumeGeneration:1,allowAction:false,xrayEnabled:true};
 function ready(){let r;for(let i=0;i<12;i++){rt.advance(100);r=rt.tick(options);if(r.xray.matchedBorders===3)break;}assert.equal(r.xray.matchedBorders,3,JSON.stringify(r));
  const g=render.overlay().getComponent(f.cc.Graphics);assert.equal(g.paths.filter(p=>p[0]==='stroke').length,6);}
 ready();
 for(let cycle=0;cycle<3;cycle++){
  let modal;
  if(interruption==='chat'){modal=f.node(240,102);f.root.children.push(modal);modal.parent=f.root;}
  if(interruption==='hotTime')m.store.isHotTiming=true;
  if(interruption==='power')m.store.isAddingCommonBlock=true;
  if(interruption==='generation')options.resumeGeneration++;
  rt.advance(100);rt.tick({...options,...(interruption==='pause'?{command:'pause'}:{})});
  if(modal){f.root.children.splice(f.root.children.indexOf(modal),1);modal.parent=null;}
  m.store.isHotTiming=false;m.store.isAddingCommonBlock=false;ready();assert.equal(f.calls.length,0);
  render.overlay().getComponent(f.cc.Graphics).clear();ready();
 }
});

test('xray overlay is removed on toggle off, pause, hidden document and modal',()=>{
 for(const change of ['off','pause','hidden','modal']){
  const f=xrayFixture(),render=enableRenderer(f),rt=setup(f);rt.tick({allowAction:false,xrayEnabled:true});assert.ok(render.overlay());
  let options={allowAction:false,xrayEnabled:true};
  if(change==='off')options.xrayEnabled=false;
  if(change==='pause')options.command='pause';
  if(change==='hidden')rt.context.document.visibilityState='hidden';
  if(change==='modal'){const m=f.node(240,102);f.root.children.push(m);m.parent=f.root;}
  const r=rt.tick(options);assert.equal(render.overlay(),undefined,change);assert.equal(r.xray.coveredIcons,0);assert.equal(r.xray.matchedBorders,0);assert.equal(f.calls.length,0);
 }
});
test('xray missing rendering API cannot stop otherwise valid autoplay or alter original sprites',()=>{
 const f=makeFixture(),rt=setup(f);rt.tick({xrayEnabled:true});rt.advance(100);rt.tick({xrayEnabled:true});rt.advance(100);
 const r=rt.tick({xrayEnabled:true});assert.equal(r.status,'original_event_dispatched');assert.equal(r.xray.status,'unavailable');assert.equal(f.calls.length,1);
});
test('xray reads all225 captured cards while showing only depth1 and excludes its own nodes from subsequent snapshots',()=>{
 const f=makeFixture(observedV26(2)),render=enableRenderer(f),rt=setup(f);
 let r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.cardsRead,225);assert.equal(r.xray.coveredIcons,23);
 assert.equal(render.overlay().children.filter(n=>n.name==='SDKtools Hidden Card').length,23);
 const counts=render.overlay().children.find(n=>n.name==='SDKtools Card Counts');assert.ok(counts);assert.equal(counts.children.length,16);
 rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'plan_ready');assert.equal(r.xray.matchedBorders,3);
 rt.advance(100);r=rt.tick({allowAction:false,xrayEnabled:true});assert.equal(r.reason,'action_disabled');assert.equal(r.cardsRead,225);assert.equal(f.calls.length,0);
 assert.equal(f.board.children.length,225);assert.equal(f.tray.children.length,0);
});
test('no complete trio means no arbitrary card event even after repeated ticks',()=>{
 const f=makeFixture([{zone:'board',type:'a',x:-80},{zone:'board',type:'b',x:80}]),rt=setup(f);let r;
 for(let i=0;i<20;i++){rt.advance(100);r=rt.tick();}assert.equal(r.reason,'no_remaining_triples');assert.equal(f.calls.length,0);assert.equal(r.awaitingBoardChange,false);
});
test('adapter independently rejects fabricated trio identifiers, wrong sequence, missing proof and overflow',()=>{
 const changes=[p=>{p.tripleCardIDs[0]='nonexistent';},p=>{p.sequence=[p.sequence[0]];p.actions=p.sequence.slice();},p=>{delete p.sequence;},p=>{p.actions.reverse();},p=>{p.matchedType='wrong';}];
 for(const change of changes){const f=makeFixture(),rt=setup(f,{planner:s=>{const p=directProof(s,s.cards[0].id);change(p);return p;}});rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);}
 const records=[...['a','a','a'].map((type,i)=>({zone:'board',type,x:-80+80*i})),...['b','c','d','e','f'].map((type,i)=>({zone:'tray',type,x:-240+80*i}))];
 const f=makeFixture(records),rt=setup(f,{planner:s=>directProof(s,s.cards[0].id)});rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);
});
test('100ms schedule still needs two fresh observations and a separate revalidation before dispatch',()=>{
 const f=makeFixture(),rt=setup(f);assert.equal(rt.tick().reason,'observing_board');rt.advance(79);assert.equal(rt.tick().reason,'observing_board');
 rt.advance(1);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);rt.advance(100);assert.equal(rt.tick().status,'original_event_dispatched');
 const picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(79);assert.equal(rt.tick().reason,'confirm_stability');
 rt.advance(1);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('proven sequence persists through confirmation without replanning another type mid-trio',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));let plans=0;
 const real=vm.runInNewContext('('+plannerSource+')',{Date:{now:()=>0}}),rt=setup(f,{planner:s=>{plans++;return real(s);}});
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});};
 let r;for(let i=0;i<30;i++){rt.advance(100);r=rt.tick();if(r.confirmedMoves===3)break;}
 assert.equal(r.confirmedMoves,3);assert.equal(plans,1);assert.deepEqual(f.calls.map(c=>f.cards.find(card=>card.event===c.event).type),['a','a','a']);
});
test('xray resource remains bounded without input dispatch or remote asset loading',()=>{
 assert.ok(Buffer.byteLength(xraySource)<65536);assert.doesNotMatch(xraySource,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);
 assert.doesNotMatch(xraySource,/\.emit\s*\(|\.touchBlock\s*\(|\.on\s*\(|addComponent\(\s*cc\.(?:Button|BlockInputEvents)/);
});

const v30Observed=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/autoplay-board-observed-v30.json'),'utf8'));
for(const observed of v30Observed.snapshots)test('V2.9 capture sequence'+observed.sequence+' reads every card but never selects a nonmatching overflow move',()=>{
 const f=makeFixture(observed.rows),render=enableRenderer(f),rt=setup(f);
 let r=rt.tick({xrayEnabled:true});assert.equal(r.cardsRead,observed.rows.length);assert.equal(r.status,'waiting_stability');
 const hidden=4;assert.equal(r.xray.coveredIcons,hidden);
 for(let i=0;i<5;i++){rt.advance(100);r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'no_complete_solution');assert.equal(r.xray.matchedBorders,0);}
 assert.equal(f.calls.length,0);assert.equal(render.overlay().children.filter(n=>n.name==='SDKtools Hidden Card').length,hidden);assert.equal(r.awaitingBoardChange,false);
 const counts=render.overlay().children.find(n=>n.name==='SDKtools Card Counts');assert.ok(counts);
 assert.equal(counts.children.length,new Set(f.cards.map(c=>c.receiver.blockInfo.type)).size);
});
test('xray destroys previous game overlay when the live scene is replaced',()=>{
 const f=xrayFixture(),first=enableRenderer(f),rt=setup(f);rt.tick({allowAction:false,xrayEnabled:true});const old=first.overlay();assert.ok(old);
 const replacement=xrayFixture(),second=enableRenderer(replacement);rt.context.window.cc=replacement.cc;rt.advance(100);const r=rt.tick({allowAction:false,xrayEnabled:true});
 assert.equal(first.overlay(),undefined);assert.equal(old.isValid,false);assert.ok(second.overlay());assert.equal(r.xray.status,'ready');assert.equal(f.calls.length,0);assert.equal(replacement.calls.length,0);
});
test('SDK-like node names never exempt an unrelated external game card from validation',()=>{
 const f=makeFixture(),render=enableRenderer(f),card=f.cards[2];f.board.children.pop();f.game.children.push(card.node);card.node.parent=f.game;card.node.name='SDKtools Card Hints';
 const r=setup(f).tick({xrayEnabled:true});assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'external_card');assert.equal(f.calls.length,0);assert.equal(render.graphics.length,0);
});

test('original numeric Block.type determines trio identity across distinct loaded skin frames',()=>{
 const f=makeFixture([{zone:'board',type:'visual_a',numericType:7,x:-80},{zone:'board',type:'visual_b',numericType:7,x:0},{zone:'board',type:'visual_c',numericType:7,x:80}]),rt=reachDispatch(f);
 assert.equal(rt.tick().cardTypesRead,1);assert.equal(f.calls.length,1);
});
test('overlap on the same original numeric layer never creates a blocker',()=>{
 const f=makeFixture([{zone:'board',type:'a',layer:2,x:0},{zone:'board',type:'a',layer:2,x:40},{zone:'board',type:'a',layer:2,x:160}]);
 let input;const rt=setup(f,{planner:s=>{input=s;return{status:'blocked'};}});assert.equal(rt.tick().reason,'observing_board');rt.advance(100);rt.tick();
 assert.deepEqual(Array.from(input.cards,c=>c.blockedBy.length),[0,0,0]);assert.equal(input.cards.every(c=>c.available),true);assert.equal(f.calls.length,0);
});
test('original layer and ID grid override rendering child order for occlusion',()=>{
 const f=makeFixture([{zone:'board',type:'a',layer:3,x:0},{zone:'board',type:'a',layer:1,x:0,mask:true},{zone:'board',type:'a',layer:2,x:160}]);
 let seen;const rt=setup(f,{planner:s=>{seen=s;return{status:'blocked'};}});assert.equal(rt.tick().reason,'observing_board');rt.advance(100);rt.tick();
 assert.deepEqual(Array.from(seen.cards[1].blockedBy),[seen.cards[0].id]);assert.equal(seen.cards[0].available,true);assert.equal(seen.cards[1].available,false);
});
test('Block.blockInfo accessors are never invoked and absent or duplicate original metadata cannot authorize action',()=>{
 for(const change of [f=>{delete f.cards[0].receiver.blockInfo;},f=>{f.cards[1].receiver.blockInfo.id=f.cards[0].receiver.blockInfo.id;},f=>{f.cards[0].receiver.blockInfo.state=3;},f=>{f.cards[0].receiver.blockInfo.type='1';}]){
  const f=makeFixture();change(f);const r=setup(f).tick();assert.equal(r.reason,'unsupported_card_rules');assert.equal(f.calls.length,0);
 }
 const f=makeFixture();let hits=0;Object.defineProperty(f.cards[0].receiver,'blockInfo',{get(){hits++;throw Error('must not call');}});assert.equal(setup(f).tick().reason,'unsupported_card_rules');assert.equal(hits,0);
});
test('original temporary modes and in-flight Block touch stop before a game callback',()=>{
 for(const [name,field] of [['CommonStore','coverNode'],['GameLayer','HotTimeMask'],['Game','WatchMaskNode']]){
  const f=makeFixture(),overlay=f.node();f.game.children.push(overlay);overlay.parent=f.game;f.game.comps.push({className:name,node:f.game,[field]:overlay});
  const r=setup(f).tick();assert.equal(r.reason,'external_mode_active');assert.equal(f.calls.length,0);
 }
 const f=makeFixture();f.cards[0].receiver.isTouched=true;const r=setup(f).tick();assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'original_touch_pending');assert.equal(f.calls.length,0);
});
test('locked special card is read with its original badge and never selected or assumed to unlock by removing coverage',()=>{
 const f=makeFixture();const card=f.cards[0];card.receiver.blockInfo.special_info={type:1,lock_state:2};card.receiver.SpecialNode.active=true;card.receiver.SpecialNode.activeInHierarchy=true;
 let input;const rt=setup(f,{planner:s=>{input=s;return{status:'blocked',reason:'observed_state_locked'};}});
 assert.equal(rt.tick().cardsRead,3);rt.advance(100);assert.equal(rt.tick().reason,'observed_state_locked');assert.equal(input.cards[0].selectable,false);assert.equal(input.cards[0].available,false);assert.equal(f.calls.length,0);
});
test('reserved cards follow actual original button state without invented layer blockers',()=>{
 const f=makeFixture([{zone:'reserve',type:'a',layer:1,x:-80,y:7},{zone:'reserve',type:'a',layer:2,x:-80,y:14},{zone:'reserve',type:'a',layer:3,x:-80,y:21}]);let input;
 const rt=setup(f,{planner:s=>{input=s;return{status:'blocked'};}});assert.equal(rt.tick().reason,'observing_board');rt.advance(100);rt.tick();
 assert.equal(input.cards.every(c=>c.zone==='reserve'&&c.blockedBy.length===0&&c.available),true);assert.equal(f.calls.length,0);
});
test('local proof persists within each trio and replans after each completed trio',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));let searches=0;
 const originalPlanner=vm.runInNewContext('('+plannerSource+')',{Date:{now:()=>0}}),rt=setup(f,{planner:s=>{searches++;return originalPlanner(s);}});
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});};
 let r;for(let i=0;i<40;i++){rt.advance(100);r=rt.tick();if(r.confirmedMoves===6)break;}
 assert.equal(r.confirmedMoves,6);assert.equal(searches,2);assert.equal(f.board.children.length,0);assert.equal(f.tray.children.length,0);
});
test('local trio is accepted even when another complete trio remains',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i}))),rt=setup(f,{planner:s=>directProof(s,s.cards[0].id)});
 rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'plan_ready');rt.advance(100);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(f.calls.length,1);
});
test('locally proved trios can be completed while an unmatched cooperative residue remains',()=>{
 const f=makeFixture(['a','a','a','b'].map((type,i)=>({zone:'board',type,x:-160+80*i}))),rt=reachDispatch(f);
 assert.equal(rt.tick().planning.goal,'next_trio');assert.equal(rt.tick().planning.residualCards,1);assert.equal(f.calls.length,1);
});
test('xray depth change neither resets an incremental search nor clears an uncertain original event',()=>{
 const f=makeFixture();let searches=0;const actual=vm.runInNewContext('('+plannerSource+')',{Date:{now:()=>0}}),rt=setup(f,{planner:s=>{searches++;return searches<3?{status:'searching',reason:'search_in_progress',stats:{expanded:searches,slices:searches}}:actual(s);}});
 rt.tick({xrayEnabled:true,xrayDepth:1});rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:1}).status,'planning');rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:5}).status,'planning');assert.equal(searches,2);
 rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:3}).reason,'plan_ready');rt.advance(100);assert.equal(rt.tick({xrayEnabled:true,xrayDepth:2}).status,'original_event_dispatched');
 rt.advance(9000);const pending=rt.tick({xrayEnabled:true,xrayDepth:4});assert.equal(pending.reason,'confirmation_uncertain');assert.equal(pending.awaitingBoardChange,true);assert.equal(f.calls.length,1);assert.equal(searches,3);
});

test('a special card unlocked by original removeSelf remains readable with four children and can finish a proved trio',()=>{
 const f=makeFixture(),card=f.cards[0],special=card.receiver.SpecialNode;
 card.receiver.blockInfo.special_info={type:1,lock_state:0};card.node.children.splice(card.node.children.indexOf(special),1);special.parent=null;special.active=false;special.activeInHierarchy=false;
 assert.equal(card.node.children.length,4);const rt=reachDispatch(f);assert.equal(rt.tick().cardsRead,3);assert.equal(f.calls.length,1);
});
test('removal of an unrelated card branch or removal of a still-locked badge cannot mimic an unlocked special',()=>{
 for(const branch of ['MaskNode','HotTimeAnimNode','BombAnimNode','SpecialNode']){
  const f=makeFixture(),card=f.cards[0],node=card.receiver[branch];card.receiver.blockInfo.special_info={type:1,lock_state:branch==='SpecialNode'?2:0};
  card.node.children.splice(card.node.children.indexOf(node),1);node.parent=null;
  const r=setup(f).tick();assert.equal(r.reason,'card_geometry');assert.equal(f.calls.length,0);
 }
});
test('original HandArea sorted insertion is confirmed in its exact order, not only by a multiset of IDs',()=>{
 const records=[{zone:'board',type:'a',x:-80},{zone:'board',type:'a',x:0},{zone:'board',type:'b',x:80},{zone:'board',type:'b',x:160},
  {zone:'tray',type:'a',x:-240},{zone:'tray',type:'b',x:-160}];
 const f=makeFixture(records),rt=reachDispatch(f),chosen=f.cards.find(c=>c.event===f.calls[0].event);move(f,chosen,f.tray);
 assert.equal(chosen.type,'a');rt.advance(100);assert.equal(rt.tick().reason,'awaiting_original_result');
 const picked=f.tray.children.pop();f.tray.children.splice(1,0,picked);f.tray.children.forEach((node,i)=>{node.x=-240+80*i;});
 rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(100);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('explicit play generation changes incremental search key while xray depth leaves it identical',()=>{
 const f=makeFixture(),keys=[],rt=setup(f,{planner:s=>{keys.push(s.stateKey);return{status:'blocked',reason:'search_limit_reached'};}});
 rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'search_limit_reached');rt.advance(100);assert.equal(rt.tick({xrayDepth:5}).reason,'search_limit_reached');
 assert.equal(keys[0],keys[1]);rt.tick({command:'pause'});rt.advance(100);assert.equal(rt.tick({resumeGeneration:2}).reason,'observing_board');rt.advance(100);rt.tick({resumeGeneration:2});
 assert.notEqual(keys[2],keys[0]);assert.equal(f.calls.length,0);
});

// V3.2: source-derived contracts, not new telemetry fields or game code.
// Block.getIsSpecialBlock ignores lock_state when special_info.type is zero;
// HandArea/StorageArea never use the pile's layer/row/col/ID grid fields.
function moveButtonsToOriginalBackground(f){
 for(const card of f.cards){card.node.comps.splice(card.node.comps.indexOf(card.button),1);card.bg.comps.push(card.button);card.button.node=card.bg;}
}
test('V3.2 normal special_info with type zero and omitted lock follows the original branch and dispatches',()=>{
 const f=makeFixture();moveButtonsToOriginalBackground(f);
 for(const c of f.cards)c.receiver.blockInfo.special_info={type:0};
 const rt=reachDispatch(f);assert.equal(rt.tick().cardsRead,3);assert.equal(f.calls.length,1);
 assert.equal(f.calls[0].args[0].target,f.cards.find(c=>c.event===f.calls[0].event).bg);
 assert.equal(rt.tick().cardRuleDetail,undefined);
});
test('V3.2 type-zero special metadata never reads an irrelevant lock accessor',()=>{
 const f=makeFixture();let hits=0;
 for(const c of f.cards){c.receiver.blockInfo.special_info={type:0};Object.defineProperty(c.receiver.blockInfo.special_info,'lock_state',{get(){hits++;throw Error('irrelevant field');}});}
 reachDispatch(f);assert.equal(hits,0);assert.equal(f.calls.length,1);
});
test('V3.2 unknown special lock cannot authorize play while valid geometric Xray remains usable',()=>{
 const f=xrayFixture();enableRenderer(f);f.cards[0].receiver.blockInfo.special_info={type:1};
 const rt=setup(f),r=rt.tick({xrayEnabled:true,xrayDepth:1});
 assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,'metadata_special_lock');
 assert.equal(r.xray.status,'ready');assert.ok(r.xray.coveredIcons>0);assert.equal(r.xray.matchedBorders,0);assert.equal(f.calls.length,0);
});
test('V3.2 original ID suffix remains identity while first two grid coordinates determine coverage',()=>{
 const f=makeFixture([{zone:'board',type:'a',x:0,layer:1,mask:true},{zone:'board',type:'a',x:0,layer:2},{zone:'board',type:'a',x:160,layer:1}]);
 f.cards.forEach((c,i)=>{c.receiver.blockInfo.id+='-opaque-'+i;});const rt=reachDispatch(f);
 assert.equal(rt.tick().cardsRead,3);assert.notEqual(f.calls[0].event,f.cards[0].event);
});
test('V3.2 reserve and hand cards need no original pile position or layer metadata',()=>{
 const f=makeFixture([{zone:'reserve',type:'a',x:-80,y:7},{zone:'tray',type:'a',x:-240},{zone:'tray',type:'a',x:-160}]);
 for(const [i,c] of f.cards.entries()){for(const key of ['layer','row','col'])delete c.receiver.blockInfo[key];c.receiver.blockInfo.id='non-pile-'+i;}
 moveButtonsToOriginalBackground(f);const rt=reachDispatch(f);assert.equal(rt.tick().cardsRead,3);assert.equal(f.calls[0].event,f.cards[0].event);
});
test('V3.2 completed reserve-to-hand original action remains confirmable without pile coordinates',()=>{
 const f=makeFixture([{zone:'reserve',type:'a',x:-80,y:7},{zone:'reserve',type:'a',x:0,y:14},{zone:'reserve',type:'a',x:80,y:21}]);
 for(const [i,c] of f.cards.entries()){for(const key of ['layer','row','col'])delete c.receiver.blockInfo[key];c.receiver.blockInfo.id='reserve-'+i;}
 const rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(100);assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});
test('V3.2 visual depth is independent of an unavailable original action registration',()=>{
 const f=xrayFixture();enableRenderer(f);f.cards[0].event.handler='unrelatedHandler';const rt=setup(f);
 const r=rt.tick({xrayEnabled:true,xrayDepth:2});assert.equal(r.reason,'handler_ambiguous');assert.equal(r.xray.status,'ready');
 assert.ok(r.xray.coveredIcons>0);assert.equal(r.xray.depthLimit,2);assert.equal(r.xray.matchedBorders,0);assert.equal(f.calls.length,0);
});
test('V3.2 action metadata rejection keeps only independently verified visual icons without invoking planner',()=>{
 const cases=[['metadata_state',c=>c.receiver.blockInfo.state=3],['metadata_type',c=>c.receiver.blockInfo.type='1'],['touch_flags',c=>delete c.receiver.canTouch],['control_state',c=>c.button.interactable=!c.button.interactable]];
 for(const [detail,change] of cases){const f=xrayFixture();enableRenderer(f);change(f.cards[0]);let plans=0;const rt=setup(f,{planner:()=>{plans++;throw Error('unverified rules');}});
  const r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,detail);assert.equal(r.xray.status,'ready');assert.ok(r.xray.coveredIcons>0);assert.equal(r.xray.matchedBorders,0);assert.equal(plans,0);assert.equal(f.calls.length,0);
 }
});
test('V3.2 uncertain visual grid still blocks Xray instead of inventing a depth',()=>{
 for(const [detail,change] of [['metadata_layer',c=>delete c.receiver.blockInfo.layer],['metadata_position',c=>delete c.receiver.blockInfo.row],['metadata_grid',c=>c.receiver.blockInfo.id='opaque']]){
  const f=xrayFixture();enableRenderer(f);change(f.cards[0]);const r=setup(f).tick({xrayEnabled:true});assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,detail);assert.equal(r.xray.status,'blocked');assert.equal(f.calls.length,0);
 }
});
test('V3.2 granular card diagnostics contain only enums and reset after recovering valid metadata',()=>{
 const cases=[['component',c=>c.receiver.className='Other'],['metadata_missing',c=>delete c.receiver.blockInfo],['metadata_id',c=>c.receiver.blockInfo.id=''],['metadata_special_type',c=>c.receiver.blockInfo.special_info={type:'secret-value',lock_state:0}]];
 for(const [detail,change] of cases){const f=makeFixture();change(f.cards[0]);const r=setup(f).tick();assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,detail);assert.doesNotMatch(JSON.stringify(r),/secret-value|mock_face/);}
 const f=makeFixture(),rt=setup(f);f.cards[0].receiver.blockInfo.state=3;assert.equal(rt.tick().cardRuleDetail,'metadata_state');f.cards[0].receiver.blockInfo.state=0;assert.equal(rt.tick().cardRuleDetail,undefined);rt.advance(100);assert.equal(rt.tick().reason,'plan_ready');
});
test('V3.2 live rule rejection preserves uncertain pending and breaks consecutive confirmation',()=>{
 const f=makeFixture(),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');
 f.cards.find(c=>c!==picked).receiver.blockInfo.type='bad';rt.advance(100);let r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,'metadata_type');assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);
 f.cards.find(c=>c!==picked).receiver.blockInfo.type=1;rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(100);assert.equal(rt.tick().confirmedMoves,1);assert.equal(f.calls.length,1);
});

test('V3.2 a special_info accessor is not treated as a missing unlocked value and is never invoked',()=>{
 const f=makeFixture();let hits=0;Object.defineProperty(f.cards[0].receiver.blockInfo,'special_info',{get(){hits++;return {type:1,lock_state:2};}});
 const r=setup(f).tick();assert.equal(r.reason,'unsupported_card_rules');assert.equal(r.cardRuleDetail,'metadata_special_type');assert.equal(hits,0);assert.equal(f.calls.length,0);
});


test('regression: unfinishable locked group no longer stops confirmed progress through two exposed triples',()=>{
 const records=['a','a','a','b','b','b','c','c','c'].map((type,i)=>({zone:'board',type,x:-240+80*(i%7),y:Math.floor(i/7)*100}));
 const f=makeFixture(records);f.cards[6].receiver.blockInfo.special_info={type:1,lock_state:2};f.cards[6].receiver.SpecialNode.active=true;f.cards[6].receiver.SpecialNode.activeInHierarchy=true;
 f.EventHandler.prototype.emit=function(args){f.calls.push({event:this,args});const card=f.cards.find(c=>c.event===this);move(f,card,f.tray);const matched=f.cards.filter(c=>c.node.parent===f.tray&&c.type===card.type);if(matched.length===3){for(const c of matched)c.node.parent=null;f.tray.children=f.tray.children.filter(n=>n.parent===f.tray);}f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});};
 const rt=setup(f);let r;
 for(let i=0;i<80;i++){rt.advance(100);r=rt.tick();assert.notEqual(r.reason,'planner_invalid_move');assert.notEqual(r.reason,'confirmation_uncertain');}
 assert.equal(r.confirmedMoves,6);assert.equal(f.calls.length,6);assert.equal(f.board.children.length,3);assert.equal(f.tray.children.length,0);assert.equal(r.reason,'no_complete_solution');assert.equal(r.awaitingBoardChange,false);
});
test('independent replay rejects global-format proof and picks appended beyond the first trio',()=>{
 for(const change of [p=>{p.proofKind='all_observed_triples';},(p,s)=>{p.sequence.push(s.cards[3].id);p.actions=p.sequence.slice();}]){
  const f=makeFixture(['a','a','a','b'].map((type,i)=>({zone:'board',type,x:-160+80*i}))),rt=setup(f,{planner:s=>{const p=directProof(s,s.cards[0].id);change(p,s);return p;}});
  rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'planner_invalid_move');assert.equal(f.calls.length,0);
 }
});

function attachMission(f,type,current=0,total=9){
 const taskNode=f.node(),task={className:'Task',node:taskNode,isValid:true,enabled:true,enabledInHierarchy:true};taskNode.comps.push(task);f.game.children.push(taskNode);taskNode.parent=f.game;
 const layer={className:'GameLayer',node:f.game,isValid:true},game={className:'Game',node:f.root,isValid:true,enabled:true,enabledInHierarchy:true,GameLayer:layer,Task:task};f.root.comps.push(game);
 const store={task_info:{target_block_type:type,current_num:current,total_num:total},pile_blocks:[],hand_blocks:[],storage_blocks:[],isWatcher:false};
 let loads=0;f.loader=name=>{assert.equal(name,'GameStore');loads++;return {default:store};};return {store,task,game,layer,loads:()=>loads};
}
function missionFixture(){return makeFixture([{zone:'board',type:'a',x:-240,numericType:1},{zone:'board',type:'m',x:-80,numericType:2},{zone:'board',type:'m',x:0,numericType:2},{zone:'board',type:'m',x:80,numericType:2},{zone:'tray',type:'a',x:-240,numericType:1},{zone:'tray',type:'a',x:-160,numericType:1}]);}

function attachLiveStore(f) {
 const m=attachMission(f,999);
 Object.assign(m.store,{uid:10,rid:20,start_time:30,state:2,isWatcher:false,isHotTiming:false,
  isAddingCommonBlock:false,isUsingPenetrateProp:false,isCanTouchBlock:true,gamers:[{uid:10,state:1}]});
 m.sync=()=>{
  for(const [field,container] of [['pile_blocks',f.board],['hand_blocks',f.tray],['storage_blocks',f.reserve]])
   m.store[field]=container.children.map(n=>({...f.cards.find(c=>c.node===n).receiver.blockInfo}));
 };
 m.sync();return m;
}
function removeCards(f,cards) {
 for(const c of cards){const p=c.node.parent;if(p)p.children.splice(p.children.indexOf(c.node),1);c.node.parent=null;}
 f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
}

test('global original modes never dispatch a no-op or alternate card action and resume after clearing',()=>{
 for(const [field,value] of [['isHotTiming',true],['isCanTouchBlock',false],['isAddingCommonBlock',true],['isUsingPenetrateProp',true],['isWatcher',true],['state',3]]){
  const f=makeFixture(),m=attachLiveStore(f),rt=setup(f);const original=m.store[field];m.store[field]=value;
  for(let i=0;i<4;i++){rt.advance(100);const r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'external_mode_active',field);assert.equal(r.awaitingBoardChange,false);}
  assert.equal(f.calls.length,0,field);m.store[field]=original;
  reachDispatch(f,rt);assert.equal(f.calls.length,1,field);
 }
});

test('global mode starting after plan invalidates it before dispatch',()=>{
 const f=makeFixture(),m=attachLiveStore(f),rt=setup(f);rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'plan_ready');
 m.store.isHotTiming=true;rt.advance(100);assert.equal(rt.tick().reason,'external_mode_active');assert.equal(f.calls.length,0);
 m.store.isHotTiming=false;reachDispatch(f,rt);
});

test('HotTime consumes pending card and hand: stable same-round Store/scene reconciliation resumes without counting a move',()=>{
 const f=makeFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i}))),m=attachLiveStore(f);
 enableRenderer(f);const rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);
 m.store.isHotTiming=true;assert.equal(rt.tick().reason,'external_mode_active');
 removeCards(f,f.cards.filter(c=>c.type===picked.type));m.sync();m.store.isHotTiming=false;
 rt.advance(100);assert.equal(rt.tick().reason,'board_resync_stability');rt.advance(100);
 const resumed=rt.tick();assert.equal(resumed.reason,'board_resynced');assert.equal(resumed.confirmedMoves,0);assert.equal(resumed.awaitingBoardChange,false);assert.equal(f.calls.length,1);
 rt.advance(100);assert.equal(rt.tick({xrayEnabled:true}).xray.matchedBorders,3);
 rt.advance(100);assert.equal(rt.tick({xrayEnabled:true}).dispatched,true);assert.equal(f.calls.length,2);assert.notEqual(f.calls[1].event,picked.event);
});

test('unrelated board change cannot strand a consumed pending card verified by live Store',()=>{
 const f=makeFixture(['a','a','a','b'].map((type,i)=>({zone:'board',type,x:-160+80*i}))),m=attachLiveStore(f),rt=reachDispatch(f);
 const picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);removeCards(f,[f.cards[3]]);m.sync();
 rt.advance(100);assert.equal(rt.tick().reason,'board_resync_stability');rt.advance(100);assert.equal(rt.tick().reason,'board_resynced');assert.equal(f.calls.length,1);
});

test('resynchronization rejects stale Store, another round, still-selectable identity and breaks on interrupted observations',()=>{
 for(const fault of ['stale','round','still_present','interrupted','pause']){
  const f=makeFixture(),m=attachLiveStore(f),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);
  if(fault!=='still_present')removeCards(f,[picked]);
  if(fault!=='stale')m.sync();if(fault==='round')m.store.start_time++;
  rt.advance(100);let r=rt.tick();
  if(fault==='interrupted' || fault==='pause'){
   assert.equal(r.reason,'board_resync_stability');
   if(fault==='pause')rt.tick({command:'pause'});
   else {m.store.isHotTiming=true;rt.tick();m.store.isHotTiming=false;}
   rt.advance(100);assert.equal(rt.tick().reason,'board_resync_stability');rt.advance(100);assert.equal(rt.tick().reason,'board_resynced');
  }else {rt.advance(10000);r=rt.tick();assert.equal(r.awaitingBoardChange,true,fault);assert.equal(r.confirmedMoves,0);}
  assert.equal(f.calls.length,1,fault);
 }
});

test('live Store identity reuse, duplicate entries, foreign zones and mismatched types cannot retire a pending action',()=>{
 for(const fault of ['reused','duplicate','zone','type','player','room']){
  const f=makeFixture(),m=attachLiveStore(f),rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event),raw=picked.receiver.blockInfo.id;
  removeCards(f,[picked]);m.sync();
  if(fault==='reused'){f.cards[1].receiver.blockInfo.id=raw;m.sync();}
  if(fault==='duplicate')m.store.pile_blocks.push({...m.store.pile_blocks[0]});
  if(fault==='zone')m.store.pile_blocks[0].state=1;
  if(fault==='type')m.store.pile_blocks[0].type=33;
  if(fault==='player'){m.store.uid=11;m.store.gamers=[{uid:11,state:1}];}
  if(fault==='room')m.store.rid++;
  rt.advance(100);rt.tick();rt.advance(10000);assert.equal(rt.tick().awaitingBoardChange,true,fault);assert.equal(f.calls.length,1,fault);
 }
});

// A watched table uses the same visible containers, while GameStore's arrays
// may still describe our own table. No synthetic watched-player UID is assumed.
function enterAllyView(f,m,{mask=true,canTouch=false}={}){
 const previous={watcher:m.store.isWatcher,canTouch:m.store.isCanTouchBlock,mask:m.game.WatchMaskNode};
 const controls=f.cards.map(c=>[c,c.receiver.canTouch,c.button.interactable]);
 const watchMask=f.node();if(mask){f.root.children.push(watchMask);watchMask.parent=f.root;m.game.WatchMaskNode=watchMask;}
 m.store.isWatcher=true;m.store.isCanTouchBlock=canTouch;
 for(const c of f.cards){c.receiver.canTouch=false;c.button.interactable=false;}
 return()=>{
  m.store.isWatcher=previous.watcher;m.store.isCanTouchBlock=previous.canTouch;
  if(previous.mask===undefined)delete m.game.WatchMaskNode;else m.game.WatchMaskNode=previous.mask;
  if(watchMask.parent){watchMask.parent.children.splice(watchMask.parent.children.indexOf(watchMask),1);watchMask.parent=null;}
  for(const [c,touch,interactable] of controls){c.receiver.canTouch=touch;c.button.interactable=interactable;}
 };
}
test('ally X-ray shows loaded covered-card icons with WatchMask and disabled input, never actions or trio borders',()=>{
 for(const mask of [false,true]){
  const f=xrayFixture(),m=attachLiveStore(f),render=enableRenderer(f),restore=enterAllyView(f,m,{mask});
  const originals=f.cards.map(c=>[c.face.comps[0].spriteFrame,c.mask.active]),rt=setup(f);
  for(let i=0;i<6;i++){
   rt.advance(100);const r=rt.tick({xrayEnabled:true,allowAction:true,powersEnabled:true,cooperativePlanning:true,
    requirePhaseSnapshot:true,superFastEnabled:true,coveredAttempt:true,penetrateAttempt:true});
   assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);
   assert.equal(r.xray.matchedBorders,0);assert.equal(r.dispatched,false);assert.equal(r.confirmedMoves,0);
   assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,0);
  }
  const icon=render.overlay().children[0];
  assert.equal(icon.children.find(n=>n.name==='SDKtools Hint Artwork').getComponent(f.cc.Sprite).spriteFrame,originals[0][0]);
  assert.equal(f.cards[0].mask.active,originals[0][1]);assert.equal(m.store.isWatcher,true);restore();
 }
});
for(const [width,height] of [[560,720],[560,80],[240,90],[240,102]])test('original spectator mask cannot be mistaken for gameplay geometry '+width+'x'+height,()=>{
 const f=xrayFixture(),m=attachLiveStore(f);enableRenderer(f);enterAllyView(f,m);m.game.WatchMaskNode.width=width;m.game.WatchMaskNode.height=height;
 const rt=setup(f),options={xrayEnabled:true,allowAction:true,requirePhaseSnapshot:true,cooperativePlanning:true,superFastEnabled:true};
 for(let i=0;i<5;i++){rt.advance(100);const r=rt.tick(options);assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);assert.equal(r.dispatched,false);}
 assert.equal(f.calls.length,0);assert.equal(m.game.WatchMaskNode.active,true);assert.equal(m.store.isWatcher,true);
});

test('ally X-ray follows the currently displayed frames despite stale own Store and replaces its previous artwork',()=>{
 const f=xrayFixture(),m=attachLiveStore(f),render=enableRenderer(f),rt=setup(f),opts={xrayEnabled:true,allowAction:false};
 rt.tick(opts);const ownFrame=f.cards[0].face.comps[0].spriteFrame;
 const storeBefore=JSON.stringify([m.store.pile_blocks,m.store.hand_blocks,m.store.storage_blocks]);enterAllyView(f,m);
 for(const c of f.cards)c.receiver.blockInfo={...c.receiver.blockInfo,id:c.receiver.blockInfo.id+'-ally',type:77};
 const allyFrame={name:'ally_current_loaded_face',getRect:()=>({width:120,height:135})};f.cards[0].face.comps[0].spriteFrame=allyFrame;
 rt.advance(100);let r=rt.tick(opts);assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);
 const displayed=()=>render.overlay().children[0].children.find(n=>n.name==='SDKtools Hint Artwork').getComponent(f.cc.Sprite).spriteFrame;
 assert.equal(displayed(),allyFrame);assert.notEqual(displayed(),ownFrame);
 const nextFrame={name:'second_ally_loaded_face',getRect:()=>({width:120,height:135})};f.cards[0].face.comps[0].spriteFrame=nextFrame;
 rt.advance(100);r=rt.tick(opts);assert.equal(r.xray.coveredIcons,1);assert.equal(displayed(),nextFrame);
 assert.equal(JSON.stringify([m.store.pile_blocks,m.store.hand_blocks,m.store.storage_blocks]),storeBefore);assert.equal(f.calls.length,0);
});
test('ally X-ray preserves the toggle and returning to our table requires fresh stability before any action',()=>{
 const f=xrayFixture(),m=attachLiveStore(f);enableRenderer(f);const rt=setup(f),opts={xrayEnabled:true,allowAction:false};
 rt.tick(opts);rt.advance(100);assert.equal(rt.tick(opts).xray.matchedBorders,3);
 const restore=enterAllyView(f,m);rt.advance(100);assert.equal(rt.tick({...opts,allowAction:true}).xray.coveredIcons,1);
 restore();rt.advance(1000);let r=rt.tick({xrayEnabled:true});
 assert.equal(r.reason,'observing_board');assert.equal(r.dispatched,false);assert.equal(r.xray.matchedBorders,0);
 rt.advance(79);r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'observing_board');assert.equal(f.calls.length,0);
 rt.advance(1);r=rt.tick({xrayEnabled:true});assert.equal(r.reason,'plan_ready');assert.equal(r.xray.matchedBorders,3);assert.equal(f.calls.length,0);
 rt.advance(100);assert.equal(rt.tick({xrayEnabled:true}).dispatched,true);assert.equal(f.calls.length,1);
});
test('ally X-ray does not confirm a pending own move from a matching-looking watched table',()=>{
 const f=makeFixture(),m=attachLiveStore(f);enableRenderer(f);const rt=reachDispatch(f),picked=f.cards.find(c=>c.event===f.calls[0].event);
 const restore=enterAllyView(f,m);move(f,picked,f.tray);
 for(let i=0;i<5;i++){
  rt.advance(1000);const r=rt.tick({xrayEnabled:true,allowAction:true});
  assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(r.dispatched,false);
 }
 assert.equal(f.calls.length,1);restore();rt.advance(100);let r=rt.tick({xrayEnabled:true,allowAction:false});
 assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);
 rt.advance(100);r=rt.tick({xrayEnabled:true,allowAction:false});assert.equal(r.confirmedMoves,1);assert.equal(f.calls.length,1);
});
test('ally X-ray cannot retire an own pending move after a complete watched-scene replacement',()=>{
 const f=makeFixture(),m=attachLiveStore(f),rt=reachDispatch(f),ally=xrayFixture(),a=attachLiveStore(ally);
 enableRenderer(ally);enterAllyView(ally,a);rt.context.window.cc=ally.cc;rt.context.window.__require=ally.loader;
 for(let i=0;i<5;i++){
  rt.advance(1000);const r=rt.tick({xrayEnabled:true});assert.equal(r.xray.status,'ready',JSON.stringify(r));
  assert.equal(r.xray.coveredIcons,1);assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(ally.calls.length,0);
 }
 rt.context.window.cc=f.cc;rt.context.window.__require=f.loader;rt.advance(100);
 const own=rt.tick({allowAction:false});assert.equal(own.awaitingBoardChange,true);assert.equal(own.confirmedMoves,0);assert.equal(f.calls.length,1);
});
test('ally X-ray still clears on HotTime, common selection, modal, hidden document, toggle off and pause',()=>{
 for(const mode of ['hot_flag','hot_mask','common_selection','modal','hidden','off','pause']){
  const f=xrayFixture(),m=attachLiveStore(f),render=enableRenderer(f);enterAllyView(f,m);const rt=setup(f),opts={xrayEnabled:true};
  assert.equal(rt.tick(opts).xray.coveredIcons,1,mode);
  if(mode==='hot_flag')m.store.isHotTiming=true;
  if(mode==='common_selection')m.store.isAddingCommonBlock=true;
  if(mode==='hot_mask'){const n=f.node();f.game.children.push(n);n.parent=f.game;m.layer.HotTimeMask=n;f.game.comps.push(m.layer);}
  if(mode==='modal'){const n=f.node(240,102);f.root.children.push(n);n.parent=f.root;}
  if(mode==='hidden')rt.context.document.visibilityState='hidden';
  if(mode==='off')opts.xrayEnabled=false;
  if(mode==='pause')opts.command='pause';
  rt.advance(100);const r=rt.tick(opts);assert.equal(r.xray.coveredIcons,0,mode);assert.equal(r.xray.matchedBorders,0,mode);
  assert.equal(render.overlay(),undefined,mode);assert.equal(f.calls.length,0,mode);
 }
});

test('uncertain dispatch does not erase independently revalidated X-ray trio guidance or resend',()=>{
 const f=xrayFixture();enableRenderer(f);const rt=reachDispatch(f),opts={xrayEnabled:true};
 rt.advance(100);rt.tick(opts);rt.advance(100);const r=rt.tick(opts);
 assert.equal(r.awaitingBoardChange,true);assert.equal(r.xray.matchedBorders,3);assert.equal(f.calls.length,1);
 rt.advance(10000);assert.equal(rt.tick(opts).xray.matchedBorders,3);assert.equal(f.calls.length,1);
});
test('loaded GameStore mission is matched to Block numeric type and prioritized via original event',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=reachDispatch(f);assert.equal(f.calls[0].event,f.cards[1].event);
 const d=rt.tick().planning.mission;assert.deepEqual(d,{status:'priority',targetType:2,current:0,total:9});assert.ok(m.loads()>0);assert.equal(m.store.task_info.current_num,0,'never fabricates mission progress');
});
test('original old Task UI during reward animation cannot override new authoritative Store mission',()=>{
 const f=missionFixture(),m=attachMission(f,2);m.task.curCountLabel={string:'9'};m.task.totalCountLabel={string:'9'};
 reachDispatch(f);assert.equal(f.calls[0].event,f.cards[1].event);
});
test('mission target change between planning and dispatch cancels the prepared action and replans first',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=setup(f);rt.tick();rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');
 m.store.task_info={target_block_type:1,current_num:0,total_num:3};rt.advance(200);const r=rt.tick();assert.equal(r.reason,'plan_ready');assert.equal(f.calls.length,0);
 rt.advance(200);assert.equal(rt.tick().status,'original_event_dispatched');assert.equal(f.calls[0].event,f.cards[0].event);
});
test('mission progress changes invalidate prepared routes, not pending actions or confirmation',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=reachDispatch(f),chosen=f.cards.find(c=>c.event===f.calls[0].event);
 m.store.task_info.current_num=3;rt.advance(10000);assert.equal(rt.tick().reason,'confirmation_uncertain');assert.equal(f.calls.length,1);
 move(f,chosen,f.tray);rt.advance(200);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(200);assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);
});
test('completed mission and unobserved target use existing normal pair completion',()=>{
 for(const [target,current,total,status] of [[2,9,9,'complete'],[999,0,9,'fallback']]){
  const f=missionFixture();attachMission(f,target,current,total);const rt=reachDispatch(f);assert.equal(f.calls[0].event,f.cards[0].event);assert.equal(rt.tick().planning.mission.status,status);
 }
});
for(const fault of ['missing_loader','throwing_loader','accessor_loader','invalid_info','accessor_info','bad_type','bad_progress','watcher','wrong_layer','wrong_task','duplicate_game','foreign_task'])test('optional mission '+fault+' cannot interrupt or redirect valid normal play',()=>{
 const f=missionFixture(),m=attachMission(f,2);let accessed=0;
 if(fault==='missing_loader')delete f.loader;
 if(fault==='throwing_loader')f.loader=()=>{throw Error('unavailable');};
 if(fault==='invalid_info')m.store.task_info=null;
 if(fault==='accessor_info')Object.defineProperty(m.store,'task_info',{get(){accessed++;throw Error('must not read');}});
 if(fault==='bad_type')m.store.task_info.target_block_type='2';
 if(fault==='bad_progress')m.store.task_info.current_num=-1;
 if(fault==='watcher')m.store.isWatcher=true;
 if(fault==='wrong_layer')m.layer.node=f.board;
 if(fault==='wrong_task')m.task.className='OtherTask';
 if(fault==='duplicate_game')f.root.comps.push({...m.game});
 if(fault==='foreign_task')m.task.node=f.node();
 const rt=setup(f);
 if(fault==='accessor_loader')Object.defineProperty(rt.context.window,'__require',{get(){accessed++;throw Error('must not call');}});
 if(fault==='watcher'){assert.equal(rt.tick().reason,'external_mode_active');assert.equal(f.calls.length,0);return;}
 reachDispatch(f,rt);assert.equal(f.calls[0].event,f.cards[0].event);assert.equal(rt.tick().planning.mission.status,'unavailable');assert.equal(accessed,0);
});
test('mission disappearance before execution cannot dispatch the stale priority card',()=>{
 const f=missionFixture(),m=attachMission(f,2),rt=setup(f);rt.tick();rt.advance(200);rt.tick();m.store.task_info=null;
 rt.advance(200);assert.equal(rt.tick().reason,'plan_ready');assert.equal(f.calls.length,0);rt.advance(200);rt.tick();assert.equal(f.calls[0].event,f.cards[0].event);
});
test('mission reward modal never authorizes auto claiming or spending a power',()=>{
 const f=missionFixture();attachMission(f,2);const alert=f.node();alert.comps.push({className:'TaskFinishAlert',enabled:true,enabledInHierarchy:true});f.root.children.push(alert);alert.parent=f.root;
 const rt=setup(f);assert.equal(rt.tick().reason,'modal_visible');rt.advance(10000);assert.equal(rt.tick().reason,'modal_visible');assert.equal(f.calls.length,0);
});


// V3.20 opt-in cadence and staged power integration. This uses the actual
// original-event adapter, actual originalPower wrapper and simulated game UI.
test('Turbo requires fresh plan and two stable observations, but accepts 40ms instead of 80ms',()=>{
 for(const turboEnabled of [false,true]){
  const f=makeFixture(),rt=setup(f),opts={turboEnabled};rt.tick(opts);rt.advance(40);
  assert.equal(rt.tick(opts).reason,turboEnabled?'plan_ready':'observing_board');
  assert.equal(f.calls.length,0);rt.advance(40);rt.tick(opts);
  assert.equal(f.calls.length,turboEnabled?1:0);
 }
});
test('preference changes never erase a dispatched uncertain card latch',()=>{
 const f=makeFixture(),rt=reachDispatch(f);
 for(const o of [{turboEnabled:true},{extendedPlanning:true},{powersEnabled:true},{turboEnabled:true,extendedPlanning:true,powersEnabled:true}]){
  rt.advance(10000);assert.equal(rt.tick(o).awaitingBoardChange,true);assert.equal(f.calls.length,1);
 }
});
test('actual extended planner supplies multi-trio telemetry and still dispatches only one original card per evaluation',()=>{
 const f=makeFixture(Array.from({length:9},(_,i)=>({zone:'board',type:'abc'[Math.floor(i/3)],x:-240+80*(i%7),y:100*Math.floor(i/7)}))),rt=setup(f);
 let r;for(let i=0;i<50;i++){rt.advance(100);r=rt.tick({extendedPlanning:true});if(f.calls.length)break;}
 assert.equal(f.calls.length,1);assert.equal(r.planning.goal,'multi_trio');assert.ok(r.planning.lookaheadTriples>=2);
 assert.equal(r.awaitingBoardChange,true);
});
function powerFixture({counts=[1,1,1],fail=false,effect=true,boardTypes=['x','x','x'],handTypes=['a','b','c','d','e','f']}={}){
 const f=makeFixture([...boardTypes.map((type,i)=>({zone:'board',type,x:-240+160*i})),...handTypes.map((type,i)=>({zone:'tray',type,x:-240+80*i}))]);
 const m=attachMission(f,999);Object.assign(m.store,{state:2,start_time:100,rid:5,uid:7,gamers:[{uid:7,state:1}],
  isHotTiming:false,isAddingCommonBlock:false,isUsingPenetrateProp:false,isCanTouchBlock:true,last_block:{id:f.cards.at(-1).receiver.blockInfo.id,state:0}});
 const icons=['\u0000w\u00cc\u0081r','\u0000w\u00cc\u0081s','\u0000w\u00cc\u0081p'];
 const infos=counts.map((count,type)=>({id:'power'+type,type,count})),props=[],row=f.node(292,90);
 for(let i=0;i<3;i++){
  const icon=f.node(80,90);f.sprite(icon,icons[i]);const n=f.node(80,90,[icon],{x:[-106,0,106][i]});row.children.push(n);n.parent=row;
  const prop={className:'Prop',kind:f.cc.Component,node:n,isValid:true,id:infos[i].id,type:i,num:counts[i],propInfo:infos[i],onUseProp(){throw Error('direct forbidden');}};
  props.push(prop);n.comps.push(prop);const event=new f.EventHandler();Object.assign(event,{target:n,component:'Prop',handler:'onUseProp',customEventData:''});
  icon.comps.push({kind:f.cc.Button,node:icon,isValid:true,enabled:true,enabledInHierarchy:true,interactable:true,clickEvents:[event]});
 }
 const areaNode=f.node(20,20,[row]);f.game.children.push(areaNode);areaNode.parent=f.game;
 m.layer.PropArea={className:'PropArea',isValid:true,node:areaNode,AreaNode:row};m.store.props_blocks=infos;
 const socket={socket:{readyState:1},rid:5,uid:7};f.loader=name=>({default:name==='GameStore'?m.store:name==='Socket'?socket:null});
 let popup=null;
 function addPopup(info){
  const buttonNode=f.node(240,102),target=f.node(600,500,[buttonNode]),event=new f.EventHandler();
  Object.assign(event,{target,component:'UsePropAlert',handler:'onBtnUseClick',customEventData:''});
  const button={kind:f.cc.Button,node:buttonNode,isValid:true,enabled:true,enabledInHierarchy:true,interactable:true,clickEvents:[event]};
  const receiver={className:'UsePropAlert',isValid:true,node:target,propInfo:{...info},useButton:button,onBtnUseClick(){throw Error('direct forbidden');}};
  buttonNode.comps.push(button);target.comps.push(receiver);f.root.children.push(target);target.parent=f.root;
  popup={target,receiver,button};return popup;
 }
 function close(){if(popup){f.root.children.splice(f.root.children.indexOf(popup.target),1);popup.target.parent=null;popup=null;}}
 f.EventHandler.prototype.emit=function(args){
  f.calls.push({event:this,args});
  if(this.handler==='onUseProp'){const prop=props.find(p=>p.node===this.target);addPopup(prop.propInfo);return;}
  if(this.handler==='onBtnUseClick'){
   const type=popup.receiver.propInfo.type;close();if(fail)throw Error('after submission');if(!effect)return;
   infos[type].count--;props[type].num--;
   if(type===0){for(const c of f.cards.filter(c=>c.node.parent===f.tray).slice(0,3))move(f,c,f.reserve);}
   if(type===1){const c=f.cards.find(c=>c.receiver.blockInfo.id===m.store.last_block.id);move(f,c,f.board);
    c.node.x=(c.receiver.blockInfo.row*5)-240;c.node.y=315-(c.receiver.blockInfo.col*4.5);}
   if(type===2){const c=f.cards[0];c.receiver.blockInfo.type=999;}
   f.tray.children.forEach((n,i)=>{n.x=-240+80*i;});
  }
 };
 return {f,m,props,infos,row,socket,get popup(){return popup;},close};
}
const powerOptions={powersEnabled:true};
function startPower(p,opts=powerOptions){const rt=setup(p.f);rt.tick(opts);rt.advance(100);const r=rt.tick(opts);return {rt,r};}
test('owned emergency Storage uses separate original open/confirm events then exact stable effect; not counted as a card move',()=>{
 const p=powerFixture(),{rt,r}=startPower(p);assert.equal(r.reason,'power_popup_opened',JSON.stringify(r));assert.equal(p.f.calls.length,1);
 rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_requested');assert.equal(p.f.calls.length,2);
 rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_stability');rt.advance(100);
 const done=rt.tick(powerOptions);assert.equal(done.reason,'power_effect_confirmed');assert.equal(done.powers.confirmed,1);assert.equal(done.confirmedMoves,0);
 assert.equal(done.awaitingBoardChange,false);assert.equal(p.infos[0].count,0);
 for(let i=0;i<6;i++){rt.advance(100);rt.tick(powerOptions);}
 assert.equal(p.f.calls.filter(c=>c.event.handler!=='touchBlock').length,2,'no repeated spending before a confirmed normal move');
 assert.equal(p.f.calls.filter(c=>c.event.handler==='touchBlock').length,1,'recovery resumes a normal proved card, not a second power');
});
test('disabled powers and read-only Xray never open or consume inventory',()=>{
 for(const opts of [{},{powersEnabled:false},{powersEnabled:true,allowAction:false,xrayEnabled:true}]){
  const p=powerFixture(),{rt}=startPower(p,opts);rt.advance(100);rt.tick(opts);assert.equal(p.f.calls.length,0);assert.equal(p.infos[0].count,1);
 }
});
test('zero inventory cannot purchase or open empty power; Withdraw selected when Storage unavailable',()=>{
 const none=powerFixture({counts:[0,0,0]});startPower(none);assert.equal(none.f.calls.length,0);
 const p=powerFixture({counts:[0,1,1],boardTypes:['a','a']}),{rt,r}=startPower(p);assert.equal(r.reason,'power_popup_opened');assert.equal(r.powers.type,1);
 rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_requested');rt.advance(100);rt.tick(powerOptions);rt.advance(100);
 assert.equal(rt.tick(powerOptions).reason,'power_effect_confirmed');assert.equal(p.infos[1].count,0);
});
test('Refresh is fallback and needs both consumption and changed non-hand types',()=>{
 const p=powerFixture({counts:[0,0,1]}),{rt,r}=startPower(p);assert.equal(r.powers.type,2);rt.advance(100);rt.tick(powerOptions);
 rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_stability');rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_confirmed');
});
test('disabled or paused after popup open never confirms; changing preference does not replay opening',()=>{
 for(const option of [{powersEnabled:false},{allowAction:false,powersEnabled:true}]){
  const p=powerFixture(),{rt}=startPower(p);rt.advance(100);const r=rt.tick(option);assert.equal(r.reason,'power_paused');assert.equal(r.awaitingBoardChange,true);
  assert.equal(p.f.calls.length,1);assert.equal(p.infos[0].count,1);
 }
});
test('a manually confirmed power opened before pause is reconciled after resume without another confirmation',()=>{
 for(const options of [{},{counts:[0,1,1],boardTypes:['a','a']},{counts:[0,0,1]}]){
  const p=powerFixture(options),{rt,r}=startPower(p);assert.equal(r.reason,'power_popup_opened');
  rt.tick({command:'pause'});rt.advance(100);
  p.popup.button.clickEvents[0].emit([]);rt.advance(5000);
  const resumed=rt.tick(powerOptions);assert.equal(resumed.reason,'power_effect_pending');
  rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_stability');
  rt.advance(100);const done=rt.tick(powerOptions);
  assert.equal(done.reason,'power_effect_confirmed');assert.equal(done.powers.confirmed,1);
  assert.equal(done.awaitingBoardChange,false);assert.equal(p.f.calls.length,2,'one opener and one manual confirmation only');
 }
});
test('an opening power stock decrement alone never confirms a manual effect or resends the popup',()=>{
 const p=powerFixture(),{rt}=startPower(p);p.close();p.infos[0].count--;p.props[0].num--;
 rt.advance(5000);const r=rt.tick({...powerOptions,allowAction:false});assert.equal(r.reason,'power_effect_pending');
 for(let i=0;i<4;i++){rt.advance(10000);const pending=rt.tick(powerOptions);assert.equal(pending.awaitingBoardChange,true);assert.equal(pending.powers.confirmed,0);}
 assert.equal(p.f.calls.length,1);
});
test('uncertain power timeout and exception never resend after pause/resume/options changes',()=>{
 for(const fail of [false,true]){
  const p=powerFixture({fail,effect:false}),{rt}=startPower(p);rt.advance(100);const sent=rt.tick(powerOptions);
  assert.equal(sent.status,fail?'dispatch_uncertain':'original_event_dispatched');
  rt.tick({command:'pause'});for(let i=0;i<5;i++){rt.advance(10000);const r=rt.tick({...powerOptions,resumeGeneration:3,turboEnabled:true});assert.equal(r.awaitingBoardChange,true);}
  assert.equal(p.f.calls.length,2);assert.equal(p.infos[0].count,1);
 }
});
test('round/room/store changes cannot confirm a different context popup or consume another power',()=>{
 for(const change of [p=>p.m.store.start_time++,p=>p.m.store.rid++,p=>p.m.store.uid++,p=>p.m.store.isWatcher=true,p=>p.popup.receiver.propInfo.type=2,
  p=>p.socket.socket={readyState:1},p=>p.socket.rid++,p=>p.socket.uid++]){
  const p=powerFixture(),{rt}=startPower(p);change(p);rt.advance(100);rt.tick(powerOptions);assert.equal(p.f.calls.length,1);assert.equal(p.infos[0].count,1);
 }
});
test('power opening requires the original transport player to match the observed store player',()=>{
 for(const uid of [undefined,8,'7',NaN]){
  const p=powerFixture();p.socket.uid=uid;startPower(p);assert.equal(p.f.calls.length,0);
 }
});
test('power opening requires the original transport room to match the observed store room',()=>{
 for(const rid of [undefined,50,'5',NaN]){
  const p=powerFixture();p.socket.rid=rid;startPower(p);assert.equal(p.f.calls.length,0);
 }
});
test('transport player change interrupts consecutive power-effect observations',()=>{
 const p=powerFixture(),{rt}=startPower(p);rt.advance(100);rt.tick(powerOptions);
 rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_stability');
 p.socket.uid=8;rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_context_unavailable');
 p.socket.uid=7;rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_stability');
 rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_confirmed');assert.equal(p.f.calls.length,2);
});
test('unrelated board movement or stock decrement alone is not a confirmed power effect',()=>{
 for(const change of [p=>{p.infos[0].count--;p.props[0].num--;},p=>move(p.f,p.f.cards[1],p.f.reserve)]){
  const p=powerFixture({effect:false}),{rt}=startPower(p);rt.advance(100);rt.tick(powerOptions);change(p);rt.advance(100);rt.tick(powerOptions);rt.advance(10000);
  const r=rt.tick(powerOptions);assert.equal(r.powers.confirmed,0);assert.equal(r.awaitingBoardChange,true);assert.equal(p.f.calls.length,2);
 }
});
test('manual stock/component divergence and wrong game state prevent opening a power',()=>{
 for(const change of [p=>p.props[0].num++,p=>p.m.store.state=4,p=>p.m.store.isWatcher=true,p=>p.m.store.isHotTiming=true]){
  const p=powerFixture();change(p);startPower(p);assert.equal(p.f.calls.length,0);
 }
});
test('native bridge template constructs the exact new runtime with all three options enabled',()=>{
 const bridge=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STAutoplayBridge.inc'),'utf8');
 const template=bridge.match(/NSString \*wrapped[\s\S]*?@"([^"\n]+)"/)[1];
 const f=makeFixture(),window={cc:f.cc};window.top=window;
 const context=vm.createContext({window,document:{visibilityState:'visible',readyState:'complete'},performance:{now:()=>0},Date:{now:()=>0}});
 const replacements=['__SDK_test','document',source,extendedSource,plannerSource,visualFactorySource,powersSource,returnSource,coveredSource,phaseSource,fastSource,coopSource,plannerSource,permissiveHotTime.toString(),'true','false','false','true','false','1','true','true','false','1','1'];
 let i=0;const script=template.replace(/%@|%ld|%lu/g,()=>replacements[i++]);assert.equal(i,replacements.length);
 const r=vm.runInContext(script,context,{timeout:500});assert.equal(r.runtimeDocumentID,'document');assert.equal(r.status,'waiting_stability');
});
test('intelligent rescue never spends Storage or Withdraw when no possible trio would be enabled',()=>{
 const p=powerFixture({counts:[1,1,0],boardTypes:['z']}),{rt}=startPower(p);
 for(let i=0;i<5;i++){rt.advance(100);rt.tick(powerOptions);}assert.equal(p.f.calls.length,0);assert.equal(p.infos[0].count,1);
});
test('original power opener throwing after popup creation cannot be followed by automatic confirmation',()=>{
 const p=powerFixture(),emit=p.f.EventHandler.prototype.emit;p.f.EventHandler.prototype.emit=function(args){emit.call(this,args);if(this.handler==='onUseProp')throw Error('uncertain open');};
 const {rt}=startPower(p);assert.equal(p.f.calls.length,1);for(let i=0;i<5;i++){rt.advance(1000);const r=rt.tick(powerOptions);assert.equal(r.awaitingBoardChange,true);}
 assert.equal(p.f.calls.length,1);assert.equal(p.infos[0].count,1);
});
test('ready normal trio always takes precedence over spending an emergency power',()=>{
 const p=powerFixture({boardTypes:['a','a','a'],handTypes:['a','a','b','c','d','e']}),{rt,r}=startPower(p);
 assert.equal(r.reason,'plan_ready');rt.advance(100);assert.equal(rt.tick(powerOptions).status,'original_event_dispatched');
 assert.equal(p.f.calls.length,1);assert.equal(p.f.calls[0].event.handler,'touchBlock');assert.equal(p.infos[0].count,1);
});
test('Turbo, extended search and owned powers operate together and preserve exactly-once dispatch',()=>{
 const p=powerFixture(),opts={turboEnabled:true,extendedPlanning:true,powersEnabled:true}, {rt,r}=startPower(p,opts);
 assert.equal(r.reason,'power_popup_opened');rt.advance(40);assert.equal(rt.tick(opts).reason,'power_requested');
 rt.advance(40);assert.equal(rt.tick(opts).reason,'power_effect_stability');rt.advance(80);assert.equal(rt.tick(opts).reason,'power_effect_confirmed');
 let out;for(let i=0;i<35;i++){const old=p.f.calls.length;rt.advance(40);out=rt.tick(opts);assert.ok(p.f.calls.length-old<=1);if(p.f.calls.length>2)break;}
 assert.equal(p.f.calls.length,3);assert.equal(p.f.calls.at(-1).event.handler,'touchBlock');assert.equal(out.awaitingBoardChange,true);
 assert.equal(p.infos[0].count,0);assert.equal(p.infos[1].count,1);assert.equal(p.infos[2].count,1);
});
test('incomplete snapshot breaks consecutive power-effect stability instead of reporting early success',()=>{
 const p=powerFixture(),{rt}=startPower(p);rt.advance(100);rt.tick(powerOptions);rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_stability');
 p.f.tray.children[0].y=1;rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'animation_active');p.f.tray.children[0].y=0;
 rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_stability');rt.advance(100);assert.equal(rt.tick(powerOptions).reason,'power_effect_confirmed');
});

const coveredOptions={allowAction:false,xrayEnabled:true,xrayDepth:1};
function coveredAdapterFixture(records){
 const f=makeFixture(records||[{zone:'board',type:'a',x:0,mask:true,layer:0},{zone:'board',type:'b',x:0,layer:1},
  {zone:'tray',type:'a',x:-240},{zone:'tray',type:'a',x:-160}]);
 const m=attachLiveStore(f);enableRenderer(f);
 const ctl={active:false,calls:0,observations:0,selected:null,
  state:{status:'idle',reason:'not_armed',pending:false,requestObserved:false,responseObserved:false,promiseSettled:false,effectObserved:false,attempts:0},
  busy(){return this.active;},diagnostic(){return {...this.state};},invalidate(){},
  block(reason){if(!this.active)this.state={status:'blocked',reason,pending:false,requestObserved:false,responseObserved:false,promiseSettled:false,effectObserved:false,attempts:this.calls};},
  observe(s){this.observations++;this.last=s;},
  dispatch(s,card,invoke){this.calls++;this.selected=card;this.active=true;
   this.state={status:'submitted',reason:'awaiting_server',pending:true,requestObserved:true,responseObserved:false,promiseSettled:false,effectObserved:false,attempts:this.calls};invoke();return true;}
 };
 const rt=setup(f,{coveredFactory:()=>ctl});return {f,m,ctl,rt};
}
test('covered experiment stays off until one manual click and preserves original covered state',()=>{
 const p=coveredAdapterFixture();for(let i=0;i<8;i++){p.rt.tick(coveredOptions);p.rt.advance(100);}
 assert.equal(p.ctl.calls,0);assert.equal(p.f.calls.length,0);
 const r=p.rt.tick({...coveredOptions,coveredAttempt:true});assert.equal(r.dispatched,true);
 assert.equal(p.ctl.calls,1);assert.equal(p.f.calls[0].event,p.f.cards[0].event);
 assert.ok(p.f.calls[0].args[0] instanceof p.f.cc.Event.EventTouch);
 assert.equal(p.f.cards[0].receiver.canTouch,false);assert.equal(p.f.cards[0].button.interactable,false);assert.equal(p.f.cards[0].mask.active,true);
});
test('covered preflight never queues the click for a later stable tick',()=>{
 const p=coveredAdapterFixture();const r=p.rt.tick({...coveredOptions,coveredAttempt:true});
 assert.equal(r.covered.reason,'observing_board');assert.equal(r.dispatched,false);
 p.rt.advance(100);p.rt.tick(coveredOptions);p.rt.advance(100);p.rt.tick(coveredOptions);assert.equal(p.ctl.calls,0);
 assert.equal(p.rt.tick({...coveredOptions,coveredAttempt:true}).dispatched,true);
});
test('covered pending excludes Auto powers and repeated clicks across pause reset resume and Xray off',()=>{
 const p=coveredAdapterFixture();p.rt.tick(coveredOptions);p.rt.advance(100);p.rt.tick({...coveredOptions,coveredAttempt:true});
 for(const opts of [{allowAction:true,powersEnabled:true},{...coveredOptions,coveredAttempt:true},{command:'pause'},{command:'reset'},{allowAction:true,resumeGeneration:9,xrayEnabled:false}]){
  p.rt.advance(100);assert.equal(p.rt.tick(opts).awaitingBoardChange,true);
 }
 assert.equal(p.ctl.calls,1);assert.equal(p.f.calls.length,1);assert.equal(p.rt.tick().confirmedMoves,0);
});
test('covered manual preflight requires Xray and explicitly disabled normal Auto',()=>{
 for(const opts of [{allowAction:true,xrayEnabled:true},{allowAction:false,xrayEnabled:false}]){
  const p=coveredAdapterFixture();p.rt.tick(coveredOptions);p.rt.advance(100);
  assert.equal(p.rt.tick({...opts,coveredAttempt:true}).dispatched,false);assert.equal(p.ctl.calls,0);assert.equal(p.f.calls.length,0);
 }
});
test('covered click cannot overlap a normal original action latch',()=>{
 const p=coveredAdapterFixture();reachDispatch(p.f,p.rt);p.rt.advance(100);
 assert.equal(p.rt.tick({...coveredOptions,coveredAttempt:true}).covered.reason,'original_pending');assert.equal(p.ctl.calls,0);assert.equal(p.f.calls.length,1);
});
test('covered ordinary-card rule and registered control contract remain required',()=>{
 for(const fault of ['special','disabled','target']){
  const p=coveredAdapterFixture();
  if(fault==='special')p.f.cards[0].receiver.blockInfo.special_info={type:1,lock_state:0};
  if(fault==='disabled')p.f.cards[0].button.enabled=false;
  if(fault==='target')p.f.cards[0].event.target=p.f.root;
  p.rt.tick(coveredOptions);p.rt.advance(100);assert.equal(p.rt.tick({...coveredOptions,coveredAttempt:true}).dispatched,false,fault);assert.equal(p.ctl.calls,0,fault);
 }
});
test('terminal covered polling never dispatches a normal action on the same evaluation',()=>{
 const p=coveredAdapterFixture();p.rt.tick(coveredOptions);p.rt.advance(100);p.rt.tick({...coveredOptions,coveredAttempt:true});
 p.ctl.observe=function(){this.active=false;this.state={...this.state,status:'accepted',reason:'server_200',pending:false,responseObserved:true,promiseSettled:true,serverCode:200};};
 const r=p.rt.tick({allowAction:true});assert.equal(r.dispatched,false);assert.equal(r.covered.pending,false);assert.equal(p.f.calls.length,1);
});
test('missing covered observer never emits an experimental event',()=>{
 const f=xrayFixture();attachLiveStore(f);enableRenderer(f);const rt=setup(f);rt.tick(coveredOptions);rt.advance(100);
 const r=rt.tick({...coveredOptions,coveredAttempt:true});assert.equal(r.dispatched,false);assert.equal(r.covered.reason,'observer_unavailable');assert.equal(f.calls.length,0);
});
test('covered depth setting bounds candidate selection even when a deeper card completes the hand trio',()=>{
 for(const depth of [1,2]){
  const p=coveredAdapterFixture([{zone:'board',type:'a',x:0,mask:true,layer:0},{zone:'board',type:'b',x:0,mask:true,layer:1},
   {zone:'board',type:'c',x:0,layer:2},{zone:'tray',type:'a',x:-240},{zone:'tray',type:'a',x:-160}]);
  const opts={...coveredOptions,xrayDepth:depth};p.rt.tick(opts);p.rt.advance(100);
  assert.equal(p.rt.tick({...opts,coveredAttempt:true}).dispatched,true);
  assert.equal(p.ctl.selected.rawID,p.f.cards[depth===1?1:0].receiver.blockInfo.id);
 }
});
test('covered candidate cannot fill the hand to a losing unmatched capacity',()=>{
 const records=[{zone:'board',type:'z',x:0,mask:true,layer:0},{zone:'board',type:'b',x:0,layer:1}];
 for(let i=0;i<6;i++)records.push({zone:'tray',type:'hand'+i,x:-240+80*i});
 const p=coveredAdapterFixture(records);p.rt.tick(coveredOptions);p.rt.advance(100);
 const r=p.rt.tick({...coveredOptions,coveredAttempt:true});assert.equal(r.dispatched,false);assert.equal(r.covered.reason,'no_covered_card');assert.equal(p.ctl.calls,0);
});

function liveCoveredFixture(){
 const p=coveredAdapterFixture(),listeners=new Map(),wire=[];
 const ws={readyState:1,url:'wss://fixture.invalid/ws',send(data){wire.push(JSON.parse(data));},
  addEventListener(name,fn){if(!listeners.has(name))listeners.set(name,new Set());listeners.get(name).add(fn);},
  removeEventListener(name,fn){listeners.get(name)?.delete(fn);}};
 const socket={uid:10,rid:20,socket:ws,responseMap:{},packetId:1,
  send(command,param={}){return new Promise((resolve,reject)=>{this.responseMap[this.packetId]={resolve,reject};ws.send(JSON.stringify({packet_id:this.packetId,command,param:{...param,uid:this.uid,rid:this.rid}}));this.packetId++;});},
  TouchBlock(id,state){return this.send('CMD_TOUCH_BLOCK',{block_id:id,block_state:state});},
  UseProp(id,blockID){return this.send('CMD_USE_PROP',{prop_id:id,block_id:blockID});},
  onMessage(e){const v=JSON.parse(e.data),entry=this.responseMap[v.packet_id];if(entry)(v.code===200?entry.resolve:entry.reject)(v.data);}
 };
 p.f.loader=name=>({default:name==='Socket'?socket:name==='GameStore'?p.m.store:null});
 p.f.EventHandler.prototype.emit=function(args){p.f.calls.push({event:this,args});const c=p.f.cards.find(c=>c.event===this);move(p.f,c,p.f.tray);p.m.sync();socket.TouchBlock(c.receiver.blockInfo.id,0).catch(()=>{});};
 p.rt=setup(p.f,{coveredFactory:true});
 return {...p,wire,socket,reply(code){const e={isTrusted:true,target:ws,data:JSON.stringify({packet_id:wire[0].packet_id,code,data:{}})};socket.onMessage(e);for(const fn of listeners.get('message')||[])fn(e);}};
}
test('real covered coordinator + adapter requires original packet ACK and Promise, not optimistic hand movement',async()=>{
 const p=liveCoveredFixture();p.rt.tick(coveredOptions);p.rt.advance(100);
 let r=p.rt.tick({...coveredOptions,coveredAttempt:true});assert.equal(r.dispatched,true);assert.equal(r.covered.requestObserved,true);assert.equal(p.wire.length,1);
 p.rt.advance(100);r=p.rt.tick({allowAction:true});assert.equal(r.covered.pending,true);assert.equal(r.covered.responseObserved,false);assert.equal(p.f.calls.length,1);
 p.reply(200);await new Promise(resolve=>setImmediate(resolve));
 p.rt.advance(100);r=p.rt.tick(coveredOptions);assert.equal(r.covered.status,'accepted');assert.equal(r.covered.pending,true);
 p.rt.advance(100);r=p.rt.tick(coveredOptions);assert.equal(r.covered.pending,false);assert.equal(r.covered.effectObserved,true);assert.equal(r.confirmedMoves,0);assert.equal(p.f.calls.length,1);
});
test('real covered observer uncertainty survives reset, visual change and repeated manual request',()=>{
 const p=liveCoveredFixture();p.rt.tick(coveredOptions);p.rt.advance(100);p.rt.tick({...coveredOptions,coveredAttempt:true});
 p.rt.advance(16000);let r=p.rt.tick(coveredOptions);assert.equal(r.covered.status,'uncertain');assert.equal(r.covered.pending,true);
 p.rt.tick({command:'reset'});p.rt.advance(100);r=p.rt.tick({...coveredOptions,coveredAttempt:true,resumeGeneration:99});
 assert.equal(r.covered.pending,true);assert.equal(p.wire.length,1);assert.equal(p.f.calls.length,1);
});

const penetrateOptions={...coveredOptions,penetrateAttempt:true};
function livePenetrateFixture(){
 const p=liveCoveredFixture();p.m.store.props_blocks=[{id:'3-10',type:3,count:0}];return p;
}
test('zero-stock Penetrate is inert until explicit click, then calls only original UseProp once without mutating local stock or flags',()=>{
 const p=livePenetrateFixture(),before=JSON.stringify(p.m.store.props_blocks);
 p.rt.tick(coveredOptions);p.rt.advance(100);const r=p.rt.tick(penetrateOptions);
 assert.equal(r.dispatched,true);assert.equal(r.covered.kind,'penetrate_zero');assert.equal(r.covered.phase,'response');
 assert.equal(p.wire.length,1);assert.equal(p.wire[0].command,'CMD_USE_PROP');
 assert.deepEqual(p.wire[0].param,{prop_id:'3-10',block_id:p.f.cards[0].receiver.blockInfo.id,uid:10,rid:20});
 assert.equal(p.f.calls.length,0,'does not emit a TouchBlock or power popup event');
 assert.equal(JSON.stringify(p.m.store.props_blocks),before);assert.equal(p.m.store.isUsingPenetrateProp,false);
 assert.equal(p.f.cards[0].receiver.canTouch,false);assert.equal(p.f.cards[0].mask.active,true);
 for(let i=0;i<8;i++){p.rt.advance(100);p.rt.tick({...penetrateOptions,allowAction:true,powersEnabled:true});}
 assert.equal(p.wire.length,1);assert.equal(p.rt.tick(coveredOptions).covered.attempts,1);
});
for(const fault of ['missing','positive','duplicate','foreign_id','string_count','wrong_type','too_many_rows'])test('zero-stock Penetrate preflight '+fault+' emits nothing and never invents a power ID',()=>{
 const p=livePenetrateFixture();
 if(fault==='missing')p.m.store.props_blocks=[];
 if(fault==='positive')p.m.store.props_blocks[0].count=1;
 if(fault==='duplicate')p.m.store.props_blocks.push({...p.m.store.props_blocks[0]});
 if(fault==='foreign_id')p.m.store.props_blocks[0].id='3-foreign';
 if(fault==='string_count')p.m.store.props_blocks[0].count='0';
 if(fault==='wrong_type')p.m.store.props_blocks[0].type=2;
 if(fault==='too_many_rows')for(let i=0;i<16;i++)p.m.store.props_blocks.push({id:'2-'+i,type:2,count:0});
 p.rt.tick(coveredOptions);p.rt.advance(100);const r=p.rt.tick(penetrateOptions);
 assert.equal(r.dispatched,false);assert.equal(r.covered.kind,'penetrate_zero');assert.equal(r.covered.phase,'blocked');
 assert.equal(r.covered.pending,false);assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0);
});
test('zero-stock Penetrate click never queues through initial unstable board or conflicts with TouchBlock intent',()=>{
 const p=livePenetrateFixture();assert.equal(p.rt.tick(penetrateOptions).dispatched,false);
 p.rt.advance(100);p.rt.tick(coveredOptions);assert.equal(p.wire.length,0);
 assert.equal(p.rt.tick({...penetrateOptions,coveredAttempt:true}).dispatched,false);assert.equal(p.wire.length,0);
});
test('zero-stock Penetrate rejection is a known negative result; stable original board permits completion, no retry',async()=>{
 const p=livePenetrateFixture();p.rt.tick(coveredOptions);p.rt.advance(100);p.rt.tick(penetrateOptions);
 p.reply(500);await new Promise(resolve=>setImmediate(resolve));
 let r=p.rt.tick(coveredOptions);assert.equal(r.covered.responseOutcome,'rejected');assert.equal(r.covered.phase,'recovery');
 p.rt.advance(100);r=p.rt.tick(coveredOptions);assert.equal(r.covered.pending,false);assert.equal(r.covered.serverCode,500);
 assert.equal(r.covered.phase,'complete');assert.equal(r.confirmedMoves,0);assert.equal(p.wire.length,1);
});
test('Penetrate 200 is not a granted power without a corresponding observed effect',async()=>{
 const p=livePenetrateFixture();p.rt.tick(coveredOptions);p.rt.advance(100);p.rt.tick(penetrateOptions);
 p.reply(200);await new Promise(resolve=>setImmediate(resolve));
 p.rt.tick(coveredOptions);p.rt.advance(100);let r=p.rt.tick(coveredOptions);
 assert.equal(r.covered.responseOutcome,'accepted');assert.equal(r.covered.pending,true);assert.equal(r.covered.effectObserved,false);
 p.rt.advance(16000);r=p.rt.tick(coveredOptions);assert.equal(r.covered.reason,'recovery_timeout');assert.equal(r.covered.pending,true);
 assert.equal(p.wire.length,1);assert.equal(p.f.calls.length,0);
 move(p.f,p.f.cards[0],p.f.tray);p.m.sync();p.rt.tick(coveredOptions);p.rt.advance(100);r=p.rt.tick(coveredOptions);
 assert.equal(r.covered.effectObserved,true);assert.equal(r.covered.pending,false);assert.equal(p.wire.length,1);
});
test('known 500 survives delayed rollback beyond old response deadline instead of becoming response_timeout',async()=>{
 const p=liveCoveredFixture();p.rt.tick(coveredOptions);p.rt.advance(100);p.rt.tick({...coveredOptions,coveredAttempt:true});
 p.reply(500);await new Promise(resolve=>setImmediate(resolve));p.rt.advance(16000);
 let r=p.rt.tick(coveredOptions);assert.equal(r.covered.responseOutcome,'rejected');assert.equal(r.covered.status,'rejected');assert.equal(r.covered.reason,'recovery_timeout');
 assert.equal(r.covered.pending,true);assert.equal(p.wire.length,1);
 const c=p.f.cards[0];move(p.f,c,p.f.board);c.node.x=0;c.node.y=0;c.mask.active=c.mask.activeInHierarchy=true;
 c.receiver.canTouch=false;c.button.interactable=false;p.m.sync();p.rt.tick(coveredOptions);p.rt.advance(100);r=p.rt.tick(coveredOptions);
 assert.equal(r.covered.pending,false);assert.equal(r.covered.responseOutcome,'rejected');assert.equal(p.wire.length,1);
});

// Stage-one phase snapshot integration. No device, network or compiler involved.
function phaseFixture(records){
 const f=makeFixture(records),m=attachLiveStore(f);
 Object.assign(m.store,{props_blocks:[{id:'power-private',type:2,count:1}],common_blocks:[],mode:0,total_num:f.cards.length});
 const ws={readyState:1},socket={uid:10,rid:20,socket:ws,responseMap:{}};
 f.loader=name=>({default:name==='Socket'?socket:name==='GameStore'?m.store:null});
 return {f,m,socket,rt:setup(f,{phaseFactory:true})};
}
function cooperativeFixture(){
 const p=phaseFixture([{zone:'board',type:'a',x:-80},{zone:'board',type:'x',x:240},{zone:'tray',type:'a',x:-240},{zone:'tray',type:'a',x:-160}]),w=addWarehouse(p.f,p.f.cards[0]);
 const owner={className:'CommonStore',node:w.layer,isValid:true,selfIndex:0,itemsNode:w.row};w.layer.comps.push(owner);p.m.layer.CommonStore=owner;
 p.m.store.common_blocks=w.slots.map((n,i)=>({lock_state:2,block:i===2?p.f.cards[0].receiver.blockInfo:null}));
 w.slots.forEach((n,i)=>Object.assign(n.receiver,{commonStore:owner,commonBlock:p.m.store.common_blocks[i],isSelf:i===0,isEmpty:i!==2}));
 p.f.cards[0].receiver.blockInfo.state=3;p.m.store.gamers[0].current_progress=80;p.m.sync();return {...p,w};
}
test('native cooperative profile picks helpful allied card once then waits for exact settled effect',()=>{
 const p=cooperativeFixture(),options={requirePhaseSnapshot:true,cooperativePlanning:true};let result;
 for(let i=0;i<8;i++){result=p.rt.tick(options);if(result.dispatched)break;p.rt.advance(100);}
 assert.equal(result.reason,'cooperative_requested',JSON.stringify(result));assert.equal(p.f.calls.length,1);assert.equal(p.f.calls[0].event,p.f.cards[0].event);
 for(let i=0;i<5;i++){p.rt.advance(100);assert.equal(p.rt.tick(options).awaitingBoardChange,true);}assert.equal(p.f.calls.length,1);
 move(p.f,p.f.cards[0],p.f.tray);removeCards(p.f,[p.f.cards[0],p.f.cards[2],p.f.cards[3]]);p.w.slots[2].receiver.isEmpty=true;p.m.store.common_blocks[2].block=null;p.m.sync();
 for(let i=0;i<8;i++){p.rt.advance(100);result=p.rt.tick(options);if(result.reason==='cooperative_confirmed')break;}
 assert.equal(result.reason,'cooperative_confirmed',JSON.stringify(result));assert.equal(result.cooperative.confirmed,1);assert.equal(result.confirmedMoves,1);assert.equal(p.f.calls.length,1);
});
const phaseOptions={requirePhaseSnapshot:true};
function readyPhase(p){p.rt.tick(phaseOptions);p.rt.advance(100);p.rt.tick(phaseOptions);p.rt.advance(100);return p.rt.tick({command:'phase_snapshot'});}
test('phase snapshot reaches stable complete local census and passes a detached snapshot to planner',()=>{
 const p=phaseFixture();let input;
 p.rt=setup(p.f,{phaseFactory:true,planner:s=>{input=s;return {status:'blocked'};}});
 const r=readyPhase(p);assert.equal(r.phaseSnapshotSummary.status,'ready',JSON.stringify(r));
 assert.equal(r.phaseSnapshot.cards.length,3);assert.equal(r.phaseSnapshot.serverConfirmed,false);
 p.rt.tick(phaseOptions);assert.equal(input.phaseSnapshot.schema,'SDKtools.AlpacaPhaseSnapshot.v1');assert.equal(p.f.calls.length,0);
});
test('snapshot command never dispatches, invokes power, changes preferences or clears a prepared plan',()=>{
 const p=phaseFixture();let r;
 for(let i=0;i<5;i++){r=p.rt.tick(phaseOptions);if(r.reason==='plan_ready')break;p.rt.advance(100);}
 assert.equal(r.reason,'plan_ready');
 const read=p.rt.tick({command:'phase_snapshot',allowAction:true,powersEnabled:true,coveredAttempt:true,resumeGeneration:99});
 assert.equal(read.phaseSnapshotSummary.status,'ready');assert.equal(p.f.calls.length,0);
 p.rt.advance(100);r=p.rt.tick(phaseOptions);assert.equal(r.dispatched,true);assert.equal(p.f.calls.length,1);
});
for(const [label,mutate] of [
 ['inventory',p=>p.m.store.props_blocks[0].count++],['mission',p=>p.m.store.task_info.current_num++],
 ['mode',p=>p.m.store.mode=1],['phase',p=>p.m.store.total_num++],
 ['socket replacement',p=>p.socket.socket={readyState:1}],['response map replacement',p=>p.socket.responseMap={}],
 ['round',p=>p.m.store.start_time++],['stock identity',p=>p.m.store.props_blocks[0].id='changed-private']
])test('prepared plan invalidates on '+label+' even when visible cards remain unchanged',()=>{
 const p=phaseFixture();let r;
 for(let i=0;i<5;i++){r=p.rt.tick(phaseOptions);if(r.reason==='plan_ready')break;p.rt.advance(100);}
 assert.equal(r.reason,'plan_ready');const before=p.rt.tick({command:'phase_snapshot'}).phaseSnapshotSummary;
 mutate(p);p.rt.advance(100);r=p.rt.tick(phaseOptions);
 assert.equal(r.dispatched,false);assert.equal(p.f.calls.length,0);assert.equal(r.phaseSnapshotSummary.complete,false);
 assert.ok(r.phaseSnapshotSummary.revision>before.revision);
});
test('HotTime clears current snapshot and requires fresh stable observations on returning',()=>{
 const p=phaseFixture();readyPhase(p);p.m.store.isHotTiming=true;
 let r=p.rt.tick(phaseOptions);assert.equal(r.phaseSnapshotSummary.complete,false);assert.equal(r.reason,'external_mode_active');
 p.m.store.isHotTiming=false;p.rt.advance(100);r=p.rt.tick(phaseOptions);assert.equal(r.phaseSnapshotSummary.status,'waiting');assert.equal(p.f.calls.length,0);
 p.rt.advance(100);r=p.rt.tick(phaseOptions);assert.equal(r.phaseSnapshotSummary.complete,true);
});
test('missing snapshot reader and incomplete inventory never silently fall back to action',()=>{
 for(const missing of ['reader','inventory']){
  const p=phaseFixture();if(missing==='reader')p.rt=setup(p.f);else delete p.m.store.props_blocks;
  for(let i=0;i<6;i++){p.rt.advance(100);const r=p.rt.tick(phaseOptions);assert.equal(r.reason,'phase_snapshot_unavailable');assert.equal(r.dispatched,false);}
  assert.equal(p.f.calls.length,0);
 }
});
test('pending original action survives missing snapshot data, pause, reset and read-only commands',()=>{
 const p=phaseFixture();let r;
 for(let i=0;i<8;i++){p.rt.advance(100);r=p.rt.tick(phaseOptions);if(r.dispatched)break;}
 assert.equal(r.dispatched,true);delete p.m.store.props_blocks;
 for(const cmd of ['phase_snapshot','pause','reset','tick']){p.rt.advance(100);r=p.rt.tick({...phaseOptions,command:cmd});if(cmd!=='phase_snapshot')assert.equal(r.awaitingBoardChange,true);}
 assert.equal(p.f.calls.length,1);
 const chosen=p.f.cards.find(c=>c.event===p.f.calls[0].event);move(p.f,chosen,p.f.tray);p.m.sync();
 p.rt.advance(100);r=p.rt.tick(phaseOptions);assert.equal(r.reason,'confirm_stability');
 p.rt.advance(100);r=p.rt.tick(phaseOptions);assert.equal(r.reason,'board_change_confirmed');assert.equal(r.confirmedMoves,1);
 assert.equal(r.phaseSnapshotSummary.complete,false);assert.equal(p.f.calls.length,1);
});
test('post-validation Store mutation in generated touch aborts dispatch before original event',()=>{
 const p=phaseFixture();const location=p.f.cards[0].node.convertToWorldSpaceAR;
 p.f.cards[0].node.convertToWorldSpaceAR=function(v){p.m.store.props_blocks[0].count++;return location(v);};
 for(let i=0;i<10;i++){p.rt.advance(100);p.rt.tick(phaseOptions);}
 assert.equal(p.f.calls.length,0);
});
test('snapshot read error drops current state but does not consume the pending action',()=>{
 const p=phaseFixture();let r;for(let i=0;i<8;i++){p.rt.advance(100);r=p.rt.tick(phaseOptions);if(r.dispatched)break;}
 p.rt.context.document.visibilityState='hidden';r=p.rt.tick({command:'phase_snapshot'});
 assert.equal(r.phaseSnapshot,null);assert.equal(r.phaseSnapshotSummary.complete,false);
 p.rt.context.document.visibilityState='visible';r=p.rt.tick(phaseOptions);assert.equal(r.awaitingBoardChange,true);assert.equal(p.f.calls.length,1);
});

test('phase snapshot includes all 228 observed geometries, not only exposed cards',()=>{
 const records=JSON.parse(fs.readFileSync(fixturePath,'utf8')).cards,p=phaseFixture(records),r=readyPhase(p);
 assert.equal(r.phaseSnapshotSummary.status,'ready',JSON.stringify(r.phaseSnapshotSummary));
 assert.equal(r.phaseSnapshot.counts.board,225);assert.equal(r.phaseSnapshot.counts.reserve,3);
 assert.equal(r.phaseSnapshot.cards.filter(c=>c.blockedBy.length).length,180);assert.equal(p.f.calls.length,0);
});

test('exact native bridge with real phase factory and all three options can prepare then dispatch once',()=>{
 const bridge=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STAutoplayBridge.inc'),'utf8'),template=bridge.match(/NSString \*wrapped[\s\S]*?@"([^"\n]+)"/)[1];
 const p=phaseFixture(),window={cc:p.f.cc,__require:p.f.loader};window.top=window;let now=0;
 const ctx=vm.createContext({window,document:{visibilityState:'visible',readyState:'complete'},performance:{now:()=>now},Date:{now:()=>now}});
 const values=['__SDK_phase_test','document',source,extendedSource,plannerSource,visualFactorySource,powersSource,returnSource,coveredSource,phaseSource,fastSource,coopSource,plannerSource,permissiveHotTime.toString(),'true','false','false','true','false','1','true','true','false','1','1'];
 let i=0;const script=template.replace(/%@|%ld|%lu/g,()=>values[i++]);assert.equal(i,25);
 let r;for(let n=0;n<10;n++){now+=100;r=vm.runInContext(script,ctx,{timeout:1000});if(r.dispatched)break;}
 assert.equal(r.phaseSnapshotSummary.status,'ready');assert.equal(r.status,'original_event_dispatched');assert.equal(p.f.calls.length,1);
 now+=100;r=vm.runInContext(script,ctx,{timeout:1000});assert.equal(r.awaitingBoardChange,true);assert.equal(p.f.calls.length,1);
});

test('lean native ticks reuse the original runtime and reject missing or changed documents without another event',()=>{
 const bridge=fs.readFileSync(path.join(__dirname,'../Sources/SDKtools/STAutoplayBridge.inc'),'utf8');
 const full=bridge.match(/NSString \*wrapped[\s\S]*?@"([^"\n]+)"/)[1];
 const lean=bridge.split('// Hot path:',2)[1].match(/@"([^"\n]+)"/)[1];
 const p=phaseFixture(),window={cc:p.f.cc,__require:p.f.loader};window.top=window;let now=0;
 const ctx=vm.createContext({window,document:{visibilityState:'visible',readyState:'complete'},performance:{now:()=>now},Date:{now:()=>now}});
 const flags=['true','false','false','false','false','1','false','false','false','1','1'];
 function script(template,values){let i=0;const s=template.replace(/%@|%ld|%lu/g,()=>values[i++]);assert.equal(i,values.length);return s;}
 const bootstrap=script(full,['__SDK_hot','document-hot',source,extendedSource,plannerSource,visualFactorySource,powersSource,returnSource,coveredSource,phaseSource,fastSource,coopSource,plannerSource,permissiveHotTime.toString(),...flags]);
 const tick=script(lean,['__SDK_hot','document-hot',...flags]);
 assert.ok(Buffer.byteLength(tick)<1600);assert.ok(Buffer.byteLength(bootstrap)>100000);
 now+=100;vm.runInContext(bootstrap,ctx,{timeout:1000});const owner=window.__SDK_hot;
 let result;for(let n=0;n<10;n++){now+=100;result=vm.runInContext(tick,ctx,{timeout:1000});if(result.dispatched)break;}
 assert.equal(result.status,'original_event_dispatched');assert.equal(p.f.calls.length,1);assert.equal(window.__SDK_hot,owner);
 const wrong=script(lean,['__SDK_hot','different-document',...flags]);
 assert.equal(vm.runInContext(wrong,ctx),null);assert.equal(p.f.calls.length,1);assert.equal(window.__SDK_hot,owner);
 assert.equal(vm.runInNewContext(tick,{window:{}}),null);assert.equal(p.f.calls.length,1);
});



test('incomplete read-only observation breaks pending confirmation consecutiveness without clearing latch',()=>{
 const p=phaseFixture();let r;for(let i=0;i<8;i++){p.rt.advance(100);r=p.rt.tick(phaseOptions);if(r.dispatched)break;}
 move(p.f,p.f.cards.find(c=>c.event===p.f.calls[0].event),p.f.tray);p.m.sync();p.rt.advance(100);
 assert.equal(p.rt.tick(phaseOptions).reason,'confirm_stability');p.rt.context.document.visibilityState='hidden';
 assert.equal(p.rt.tick({command:'phase_snapshot'}).phaseSnapshot,null);p.rt.context.document.visibilityState='visible';p.rt.advance(100);
 r=p.rt.tick(phaseOptions);assert.equal(r.reason,'confirm_stability');assert.equal(r.awaitingBoardChange,true);assert.equal(p.f.calls.length,1);
 p.rt.advance(100);assert.equal(p.rt.tick(phaseOptions).reason,'board_change_confirmed');
});

// Super Fast protocol fixture: synthetic original events, no live server/device.
function superFixture(records){
 const p=phaseFixture(records),listeners=new Map(),wire=[],promises=[];
 const ws={readyState:1,url:'wss://fixture.invalid/ws',send(raw){wire.push(JSON.parse(raw));},
  addEventListener(n,fn){if(!listeners.has(n))listeners.set(n,new Set());listeners.get(n).add(fn);},
  removeEventListener(n,fn){listeners.get(n)?.delete(fn);}};
 const socket={uid:10,rid:20,socket:ws,responseMap:{},packetId:1,
  send(command,param={}){const id=this.packetId++,promise=new Promise((resolve,reject)=>{this.responseMap[id]={resolve,reject};});ws.send(JSON.stringify({packet_id:id,command,param:{...param,uid:this.uid,rid:this.rid}}));promises.push(promise);return promise;},
  TouchBlock(id,state){return this.send('CMD_TOUCH_BLOCK',{block_id:id,block_state:state});},
  onMessage(e){const d=JSON.parse(e.data),entry=this.responseMap[d.packet_id];if(entry)(d.code===200?entry.resolve:entry.reject)(d.data);}};
 // Match the shipped packetId convention: the increment happens after send.
 socket.send=function(command,param={}){const id=this.packetId,promise=new Promise((resolve,reject)=>{this.responseMap[id]={resolve,reject};ws.send(JSON.stringify({packet_id:id,command,param:{...param,uid:this.uid,rid:this.rid}}));this.packetId++;});promises.push(promise);return promise;};
 p.f.loader=name=>({default:name==='Socket'?socket:name==='GameStore'?p.m.store:null});
 p.f.EventHandler.prototype.emit=function(args){p.f.calls.push({event:this,args});const card=p.f.cards.find(c=>c.event===this),state=card.receiver.blockInfo.state;
  move(p.f,card,p.f.tray);const trio=p.f.cards.filter(c=>c.node.parent===p.f.tray&&c.type===card.type);
  if(trio.length===3)removeCards(p.f,trio);p.f.tray.children.forEach((n,i)=>n.x=-240+80*i);p.m.sync();
  const promise=socket.TouchBlock(card.receiver.blockInfo.id,state);p.f.lastReturned=promise;promise.catch(()=>{});
 };
 p.rt=setup(p.f,{phaseFactory:true,fastFactory:true});
 return {...p,socket,ws,wire,promises,listeners,reply(index,code=200,{trusted=true,settle=true}={}){const e={isTrusted:trusted,target:ws,data:JSON.stringify({packet_id:wire[index].packet_id,code,data:{}})};
   if(settle)socket.onMessage(e);for(const fn of listeners.get('message')||[])fn(e);},
  listenerCount:()=>Array.from(listeners.values()).reduce((n,set)=>n+set.size,0)};
}
const superOptions={...phaseOptions,superFastEnabled:true};
function dispatchSuper(p,options=superOptions){let r;for(let i=0;i<12;i++){p.rt.advance(20);r=p.rt.tick(options);if(r.dispatched)return r;}assert.fail(JSON.stringify(r));}
async function settleSuper(p,indices=p.wire.map((_,i)=>i)){for(const i of indices)p.reply(i);await new Promise(resolve=>setImmediate(resolve));}
function finishSuper(p,options=superOptions){let r;for(let i=0;i<12;i++){p.rt.advance(20);r=p.rt.tick(options);if(r.status==='move_confirmed')return r;}return r;}
test('Super Fast issues the three exact registered original events in a single tick; no direct calls or game writes',()=>{
 const p=superFixture(),stock=JSON.stringify(p.m.store.props_blocks),flags=p.m.store.isCanTouchBlock;
 const original=p.socket.TouchBlock,send=p.ws.send,r=dispatchSuper(p);
 assert.equal(r.superFast.submitted,3);assert.equal(r.superFast.requests,3);assert.equal(p.f.calls.length,3);assert.equal(p.wire.length,3);
 assert.equal(p.socket.TouchBlock,original);assert.equal(p.ws.send,send);assert.equal(p.f.lastReturned,p.promises.at(-1));
 assert.deepEqual(p.wire.map(v=>v.param.block_state),[0,0,0]);assert.equal(new Set(p.wire.map(v=>v.param.block_id)).size,3);
 assert.equal(JSON.stringify(p.m.store.props_blocks),stock);assert.equal(p.m.store.isCanTouchBlock,flags);
 assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);assert.equal(r.superFast.effectObserved,false);
});
test('pending Auto batch keeps fresh borders for the next trio without releasing or repeating its requests',()=>{
 const p=superFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));enableRenderer(p.f);p.rt=setup(p.f,{phaseFactory:true,fastFactory:true});
 const options={...superOptions,xrayEnabled:true};dispatchSuper(p,options);let r;
 for(let i=0;i<12;i++){p.rt.advance(100);r=p.rt.tick(options);}
 assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(p.f.calls.length,3);assert.equal(p.wire.length,3);
 assert.equal(r.xray.status,'ready');assert.equal(r.xray.matchedBorders,3);
 p.m.store.isHotTiming=true;p.rt.advance(100);assert.equal(p.rt.tick(options).xray.matchedBorders,0);
 p.m.store.isHotTiming=false;for(let i=0;i<12;i++){p.rt.advance(100);r=p.rt.tick(options);}
 assert.equal(r.xray.matchedBorders,3);assert.equal(p.wire.length,3);assert.equal(r.awaitingBoardChange,true);
 p.rt.advance(16000);for(let i=0;i<5;i++){p.rt.advance(100);r=p.rt.tick(options);}
 assert.equal(r.reason,'super_fast_uncertain');assert.equal(r.xray.matchedBorders,3);assert.equal(r.superFast.pending,true);
 assert.equal(r.confirmedMoves,0);assert.equal(p.wire.length,3);assert.equal(p.f.calls.length,3);
});

test('optimistic trio disappearance and two ACKs cannot release the three-card batch',async()=>{
 const p=superFixture();dispatchSuper(p);assert.equal(p.f.board.children.length,0);await settleSuper(p,[0,2]);
 for(let i=0;i<10;i++){p.rt.advance(100);const r=p.rt.tick(superOptions);assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(p.wire.length,3);}
 p.reply(1);await new Promise(resolve=>setImmediate(resolve));const r=finishSuper(p);
 assert.equal(r.reason,'super_fast_confirmed');assert.equal(r.confirmedMoves,3);assert.equal(r.superFast.effectObserved,true);assert.equal(p.listenerCount(),0);
});
test('all three matching ACKs and original Promise settlements confirm exactly three once',async()=>{
 const p=superFixture();dispatchSuper(p);await settleSuper(p,[2,0,1]);const r=finishSuper(p);
 assert.equal(r.superFast.status,'confirmed');assert.equal(r.superFast.responses,3);assert.equal(r.superFast.settled,3);assert.equal(r.confirmedMoves,3);
 for(let i=0;i<4;i++){p.rt.advance(100);assert.equal(p.rt.tick(superOptions).confirmedMoves,3);}assert.equal(p.wire.length,3);
});
test('fake untrusted ACK or response without original Promise settlement never confirms',async()=>{
 for(const fault of ['untrusted','unsettled']){
  const p=superFixture();dispatchSuper(p);p.reply(0,200,fault==='untrusted'?{trusted:false}:{settle:false});p.reply(1);p.reply(2);await new Promise(resolve=>setImmediate(resolve));
  for(let i=0;i<5;i++){p.rt.advance(100);assert.equal(p.rt.tick(superOptions).awaitingBoardChange,true);}
  assert.equal(p.wire.length,3);assert.equal(p.rt.tick(superOptions).confirmedMoves,0);
 }
});
for(const cardsPerBatch of [2,3])for(const interruption of ['own','ally','modal'])test('accepted '+cardsPerBatch+'-card batch resumes after late '+interruption+' effect observation without repeating requests',async()=>{
 const p=superFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i}))),options={...phaseOptions,cardsPerBatch};
 dispatchSuper(p,options);await settleSuper(p);let restore,modal;
 if(interruption==='ally')restore=enterAllyView(p.f,p.m);
 if(interruption==='modal'){modal=p.f.node(240,102);p.f.root.children.push(modal);modal.parent=p.f.root;}
 p.rt.advance(16000);let r=p.rt.tick(options);
 assert.equal(r.superFast.status,'waiting_effect');assert.equal(r.superFast.pending,true);assert.equal(r.superFast.accepted,cardsPerBatch);assert.equal(r.confirmedMoves,0);
 if(restore)restore();if(modal){p.f.root.children.splice(p.f.root.children.indexOf(modal),1);modal.parent=null;}
 for(let i=0;i<12;i++){p.rt.advance(100);r=p.rt.tick({...options,allowAction:false,resumeGeneration:8});if(r.confirmedMoves===cardsPerBatch)break;}
 assert.equal(r.confirmedMoves,cardsPerBatch,JSON.stringify(r));assert.equal(r.awaitingBoardChange,false);assert.equal(p.wire.length,cardsPerBatch);assert.equal(p.f.calls.length,cardsPerBatch);
});

test('accepted late effect wait still latches permanently on context replacement',async()=>{
 for(const fault of ['socket','map','round']){
  const p=superFixture();dispatchSuper(p);await settleSuper(p);p.rt.advance(16000);
  assert.equal(p.rt.tick({...superOptions,allowAction:false}).superFast.status,'waiting_effect');
  if(fault==='socket')p.socket.socket={...p.ws};if(fault==='map')p.socket.responseMap={};if(fault==='round')p.m.store.start_time++;
  for(let i=0;i<10;i++){p.rt.advance(100);const r=p.rt.tick(superOptions);assert.equal(r.superFast.status,'uncertain',fault);assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);}
  assert.equal(p.wire.length,3);assert.equal(p.f.calls.length,3);
 }
});
test('untrusted or unsettled response cannot become an accepted late effect wait',async()=>{
 for(const fault of ['untrusted','unsettled']){
  const p=superFixture();dispatchSuper(p);p.reply(0,200,fault==='untrusted'?{trusted:false}:{settle:false});p.reply(1);p.reply(2);await new Promise(resolve=>setImmediate(resolve));
  p.rt.advance(16000);const r=p.rt.tick(superOptions);assert.equal(r.superFast.status,'uncertain',fault);assert.equal(r.confirmedMoves,0);assert.equal(r.awaitingBoardChange,true);assert.equal(p.wire.length,3);
 }
});
test('server 500, response timeout and context replacement block any repeat or fourth event',async()=>{
 for(const fault of ['500','timeout','socket','map','round']){
  const p=superFixture();dispatchSuper(p);
  if(fault==='500'){p.reply(0,500);await new Promise(resolve=>setImmediate(resolve));}
  if(fault==='timeout')p.rt.advance(16000);
  if(fault==='socket')p.socket.socket={...p.ws};
  if(fault==='map')p.socket.responseMap={};
  if(fault==='round')p.m.store.start_time++;
  for(const cmd of ['tick','pause','reset','tick']){p.rt.advance(100);p.rt.tick({...superOptions,command:cmd});}
  const r=p.rt.tick(superOptions);assert.equal(r.superFast.status,'uncertain',fault);assert.equal(r.awaitingBoardChange,true);assert.equal(p.wire.length,3);assert.equal(p.listenerCount(),0);
 }
});
test('turning Super Fast off or pausing cannot discard submitted requests',async()=>{
 const p=superFixture();dispatchSuper(p);p.rt.tick({...superOptions,command:'pause'});
 for(let i=0;i<3;i++){p.rt.advance(100);const r=p.rt.tick({...phaseOptions,superFastEnabled:false});assert.equal(r.awaitingBoardChange,true);assert.equal(p.wire.length,3);}
 await settleSuper(p);const r=finishSuper(p,{...phaseOptions,superFastEnabled:false,allowAction:false});assert.equal(r.confirmedMoves,3);assert.equal(p.wire.length,3);
});
test('an uncertain batch may read fresh visuals but cannot release requests, and hidden context clears them',()=>{
 const p=superFixture();let shown=false,renders=0,clears=0;
 p.rt=setup(p.f,{phaseFactory:true,fastFactory:true,xrayFactory:()=>({
  render(){shown=true;renders++;return {status:'ready',coveredIcons:0,matchedBorders:0};},
  clear(){shown=false;clears++;},owns(){return false;}
 })});
 const options={...superOptions,xrayEnabled:true};dispatchSuper(p,options);
 assert.ok(shown&&renders>0);const before=clears,painted=renders;
 p.rt.advance(16000);
 for(let i=0;i<3;i++){
  const r=p.rt.tick(options);assert.equal(r.reason,'super_fast_uncertain');
  assert.equal(r.xray.status,'ready');assert.equal(shown,true);assert.ok(renders>painted);
  assert.equal(r.awaitingBoardChange,true);assert.equal(r.superFast.pending,true);
  assert.equal(r.confirmedMoves,0);assert.equal(p.wire.length,3);
 }
 p.rt.context.document.visibilityState='hidden';const hidden=p.rt.tick(options);
 assert.equal(hidden.xray.status,'blocked');assert.equal(shown,false);assert.ok(clears>before);assert.equal(p.wire.length,3);assert.equal(hidden.awaitingBoardChange,true);
});
test('if original flags close after first event the batch stops at a tracked prefix',async()=>{
 const p=superFixture(),emit=p.f.EventHandler.prototype.emit;p.f.EventHandler.prototype.emit=function(args){emit.call(this,args);p.m.store.isCanTouchBlock=false;};
 const r=dispatchSuper(p);assert.equal(r.superFast.submitted,1);assert.equal(p.wire.length,1);p.m.store.isCanTouchBlock=true;
 await settleSuper(p);const done=finishSuper(p,{...superOptions,allowAction:false});assert.equal(done.confirmedMoves,1);assert.equal(done.superFast.reason,'prefix_confirmed');assert.equal(p.wire.length,1);
});
test('wire mismatch is observed, original forwarding happens once, no later card dispatched',()=>{
 const p=superFixture();p.socket.TouchBlock=function(id,state){return this.send('CMD_TOUCH_BLOCK',{block_id:'foreign-fixture',block_state:state});};
 const r=dispatchSuper(p);assert.equal(r.superFast.status,'uncertain');assert.equal(p.wire.length,1);assert.equal(r.awaitingBoardChange,true);assert.equal(p.listenerCount(),0);
});
test('Super Fast takes one or two cards if existing tray already supplies the rest of the trio',async()=>{
 for(const n of [1,2]){
  const records=[...Array.from({length:n},(_,i)=>({zone:'board',type:'a',x:-80+80*i})),...Array.from({length:3-n},(_,i)=>({zone:'tray',type:'a',x:-240+80*i}))],p=superFixture(records);
  const r=dispatchSuper(p);assert.equal(r.superFast.submitted,n);await settleSuper(p);assert.equal(finishSuper(p).confirmedMoves,n);assert.equal(p.f.tray.children.length,0);
 }
});
test('ready exposed mission trio is selected before non-mission trio in Super Fast',()=>{
 const p=superFixture(['a','a','a','m','m','m'].map((type,i)=>({zone:'board',type,x:-240+80*i,numericType:type==='m'?2:1})));p.m.store.task_info.target_block_type=2;
 dispatchSuper(p);const selected=p.wire.map(v=>p.f.cards.find(c=>c.receiver.blockInfo.id===v.param.block_id).type);assert.deepEqual(selected,['m','m','m']);
});
test('Super Fast never selects a covered tail, disabled, locked or unproved card',()=>{
 for(const mode of ['covered','disabled','locked','nontrio']){
  const records=mode==='covered'?[{zone:'board',type:'a',x:0,mask:true},{zone:'board',type:'a',x:0},{zone:'board',type:'a',x:80}]:undefined,p=superFixture(records);
  if(mode==='disabled'){p.f.cards[0].button.interactable=false;p.f.cards[0].receiver.canTouch=false;}
  if(mode==='locked'){p.f.cards[0].receiver.blockInfo.special_info={type:1,lock_state:2};p.m.sync();}
  if(mode==='nontrio'){p.f.cards[1].receiver.blockInfo.type=9;p.m.sync();}
  for(let i=0;i<12;i++){p.rt.advance(100);const r=p.rt.tick(superOptions);assert.ok(!r.superFast||r.superFast.submitted<=(mode==='covered'?2:0),mode);}
  if(mode==='covered'){assert.ok(p.wire.length<=2);assert.ok(p.wire.every(v=>v.param.block_id!==p.f.cards[0].receiver.blockInfo.id));}else assert.equal(p.wire.length,0,mode);
 }
});
test('two complete batches remain serialized; no fourth request before first batch acknowledgement',async()=>{
 const p=superFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));
 dispatchSuper(p);for(let i=0;i<5;i++){p.rt.advance(100);p.rt.tick(superOptions);}assert.equal(p.wire.length,3);
 await settleSuper(p,[0,1,2]);assert.equal(finishSuper(p).confirmedMoves,3);
 dispatchSuper(p);assert.equal(p.wire.length,6);await settleSuper(p,[3,4,5]);assert.equal(finishSuper(p).confirmedMoves,6);
});
function sparseReserve(p){
 for(const c of p.f.cards.filter(c=>c.node.parent===p.f.reserve)){
  const row=c.receiver.blockInfo,position=row.storage_info||(row.storage_info={layer:0,index:p.f.reserve.children.indexOf(c.node)});
  c.node.x=80*position.index-80;c.node.y=7*position.layer;
 }
 const sync=p.m.sync;p.m.sync=()=>{sync();const flat=p.m.store.storage_blocks,matrix=[];
  for(const row of flat){const pos=row.storage_info;if(!matrix[pos.layer])matrix[pos.layer]=[null,null,null];matrix[pos.layer][pos.index]=row;}
  if(!matrix.length)matrix.push([null,null,null]);p.m.store.storage_blocks=matrix;};p.m.sync();
}
for(const [name,options] of [['Normal',phaseOptions],['Turbo',{...phaseOptions,turboEnabled:true}],['Extended',{...phaseOptions,extendedPlanning:true}],['Super Fast',superOptions]])
 test(name+' captures real sparse-reserve card after Storage power; X-ray marks the accessible trio',()=>{
  const p=superFixture([{zone:'reserve',type:'a',rawID:'stored-original'},{zone:'tray',type:'a',x:-240},{zone:'tray',type:'a',x:-160}]);sparseReserve(p);enableRenderer(p.f);
  p.rt=setup(p.f,{phaseFactory:true,fastFactory:true});let r;
  for(let i=0;i<12;i++){p.rt.advance(100);r=p.rt.tick({...options,xrayEnabled:true,allowAction:false});if(r.reason==='plan_ready')break;}
  assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.matchedBorders,3);assert.equal(r.phaseSnapshotSummary.complete,true);
  p.rt.advance(100);r=p.rt.tick({...options,xrayEnabled:true});assert.equal(r.dispatched,true,JSON.stringify(r));assert.equal(p.wire.length,1);assert.equal(p.wire[0].param.block_state,2);
 });
test('masked reserves get read-only X-ray badges from storage metadata without inventing selectable blockers',()=>{
 const p=superFixture([{zone:'reserve',type:'a',rawID:'stored-low',mask:true},{zone:'reserve',type:'b',rawID:'stored-high'},{zone:'board',type:'c',x:-80}]);
 p.f.cards[0].receiver.blockInfo.storage_info={layer:0,index:1};p.f.cards[1].receiver.blockInfo.storage_info={layer:1,index:1};sparseReserve(p);enableRenderer(p.f);
 p.rt=setup(p.f,{phaseFactory:true,fastFactory:true,planner:()=>({status:'blocked'})});let r;
 for(let i=0;i<5;i++){p.rt.advance(100);r=p.rt.tick({...phaseOptions,allowAction:false,xrayEnabled:true});}
 assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);assert.equal(r.phaseSnapshotSummary.complete,true);assert.equal(p.wire.length,0);
 const read=p.rt.tick({command:'phase_snapshot'}),low=read.phaseSnapshot.cards.find(c=>c.zone==='reserve'&&c.masked);
 assert.equal(low.storageVerified,true);assert.equal(low.available,false);assert.deepEqual(low.blockedBy,[]);assert.equal(low.hintBlockedBy.length,1);
});

test('Storage power stack without dark masks still renders all verified hidden reserve cards',()=>{
 const p=superFixture([{zone:'reserve',type:'a',rawID:'stored-low'},{zone:'reserve',type:'b',rawID:'stored-middle'},
  {zone:'reserve',type:'c',rawID:'stored-top'},{zone:'board',type:'d',x:-80}]);
 p.f.cards.slice(0,3).forEach((c,i)=>{c.receiver.blockInfo.storage_info={layer:i,index:0};});sparseReserve(p);enableRenderer(p.f);
 p.rt=setup(p.f,{phaseFactory:true,fastFactory:true,planner:()=>({status:'blocked'})});let r;
 for(let i=0;i<5;i++){p.rt.advance(100);r=p.rt.tick({...phaseOptions,allowAction:false,xrayEnabled:true,xrayDepth:4});}
 assert.equal(r.xray.coveredIcons,2);assert.equal(r.phaseSnapshotSummary.complete,true);assert.equal(p.wire.length,0);
 const snapshot=p.rt.tick({command:'phase_snapshot'}).phaseSnapshot;
 const reserve=snapshot.cards.filter(c=>c.zone==='reserve');
 assert.ok(reserve.every(c=>!c.masked&&c.available&&c.blockedBy.length===0),'visual hints do not rewrite original touch rules');
 assert.deepEqual(reserve.map(c=>c.occlusionDepth),[2,1,0]);
 assert.equal(r.reserveXray.geometricCovered,2);assert.equal(r.reserveXray.masked,0);assert.equal(r.reserveXray.verified,3);
});
test('unknown reserve stack position never invents X-ray position or a move, and does not erase board hints',()=>{
 const p=superFixture([{zone:'reserve',type:'a',rawID:'stored-unknown',mask:true},{zone:'board',type:'b',x:0,mask:true},{zone:'board',type:'c',x:0}]);enableRenderer(p.f);
 p.rt=setup(p.f,{phaseFactory:true,fastFactory:true,planner:()=>({status:'blocked'})});let r;
 for(let i=0;i<5;i++){p.rt.advance(100);r=p.rt.tick({...phaseOptions,allowAction:false,xrayEnabled:true});}
 assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);assert.equal(r.xray.hiddenByLayout,1);assert.equal(p.wire.length,0);
});
test('in-flight reserve coordinates do not become a valid stable storage card',()=>{
 const p=superFixture([{zone:'reserve',type:'a',rawID:'storage'}]);sparseReserve(p);p.f.cards[0].node.y=1;
 const r=p.rt.tick(superOptions);assert.equal(r.reason,'animation_active');assert.equal(r.animationDetail,'reserve_metadata');assert.equal(p.wire.length,0);
});

for(const fault of ['disabled','lock','frame'])test('late '+fault+' on second card stops at exactly one original event',async()=>{
 const p=superFixture(),emit=p.f.EventHandler.prototype.emit;p.f.EventHandler.prototype.emit=function(args){emit.call(this,args);const second=p.f.cards[1];
  if(fault==='disabled'){second.button.interactable=false;second.receiver.canTouch=false;}
  if(fault==='lock'){second.receiver.blockInfo.special_info={type:1,lock_state:1};p.m.sync();}
  if(fault==='frame')second.face.comps[0].spriteFrame={name:'changed',getRect:()=>({width:120,height:135})};};
 const r=dispatchSuper(p);assert.equal(r.superFast.submitted,1);assert.equal(r.superFast.status,'submitted');assert.equal(p.wire.length,1);
});
test('sparse reservations remain complete after removing one and retaining explicit null cells',()=>{
 const p=superFixture([{zone:'reserve',type:'a',rawID:'r0'},{zone:'reserve',type:'b',rawID:'r1'},{zone:'reserve',type:'c',rawID:'r2'}]);sparseReserve(p);
 removeCards(p.f,[p.f.cards[1]]);p.m.sync();assert.equal(p.m.store.storage_blocks[0][1],null);
 let r;for(let i=0;i<4;i++){p.rt.advance(100);r=p.rt.tick({...phaseOptions,allowAction:false});}
 assert.equal(r.phaseSnapshotSummary.complete,true,JSON.stringify(r));assert.equal(r.phaseSnapshotSummary.counts.reserve,2);assert.equal(p.wire.length,0);
});
test('Withdraw returning a card to Pile is readable again in all modes after actual coordinates settle',()=>{
 for(const opts of [phaseOptions,{...phaseOptions,turboEnabled:true},{...phaseOptions,extendedPlanning:true},superOptions]){
  const p=superFixture([{zone:'tray',type:'a',x:-240,rawID:'0-48-70'},{zone:'tray',type:'a',x:-160,rawID:'1-64-70'},{zone:'tray',type:'a',x:-80,rawID:'2-80-70'}]);
  for(const c of p.f.cards){move(p.f,c,p.f.board);const row=c.receiver.blockInfo;row.layer=p.f.cards.indexOf(c);row.row=48+16*row.layer;row.col=70;c.node.x=5*row.row-240;c.node.y=0;}
  p.m.sync();let r;for(let i=0;i<12;i++){p.rt.advance(100);r=p.rt.tick(opts);if(r.dispatched)break;}
  assert.equal(r.dispatched,true,JSON.stringify(r));assert.ok(p.wire.every(v=>v.param.block_state===0));
 }
});

test('no snapshot reader never authorizes either burst or compatibility original event',()=>{
 const p=superFixture();p.rt=setup(p.f,{fastFactory:true});
 for(let i=0;i<12;i++){p.rt.advance(100);p.rt.tick(superOptions);}assert.equal(p.wire.length,0);assert.equal(p.listenerCount(),0);
});
test('original event exception keeps any possible first request pending and never continues the batch',()=>{
 const p=superFixture(),emit=p.f.EventHandler.prototype.emit;p.f.EventHandler.prototype.emit=function(args){emit.call(this,args);throw Error('fixture event failed after request');};
 const r=dispatchSuper(p);assert.equal(r.superFast.status,'uncertain');assert.equal(p.wire.length,1);
 for(let i=0;i<3;i++){p.rt.advance(1000);p.rt.tick(superOptions);}assert.equal(p.wire.length,1);
});
test('three ACKs before Promise settlement alone do not count a confirmed card',async()=>{
 const p=superFixture();dispatchSuper(p);for(let i=0;i<3;i++)p.reply(i,200,{settle:false});
 p.rt.advance(100);let r=p.rt.tick(superOptions);assert.equal(r.confirmedMoves,0);assert.equal(r.superFast.settled,0);
 for(let i=0;i<3;i++)p.socket.onMessage({data:JSON.stringify({packet_id:p.wire[i].packet_id,code:200,data:{}})});
 await new Promise(resolve=>setImmediate(resolve));r=finishSuper(p);assert.equal(r.confirmedMoves,3);
});
test('read-only snapshot command never triggers a second batch while first is pending',()=>{
 const p=superFixture();dispatchSuper(p);for(let i=0;i<5;i++){p.rt.advance(100);p.rt.tick({command:'phase_snapshot',superFastEnabled:true,allowAction:true});}
 assert.equal(p.wire.length,3);assert.equal(p.rt.tick(superOptions).awaitingBoardChange,true);
});

test('ally/HotTime changes after accepted batch resynchronize without inventing our move count',async()=>{
 const p=superFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));
 dispatchSuper(p);await settleSuper(p);removeCards(p.f,[p.f.cards[3]]);p.m.sync();
 let r;for(let i=0;i<8;i++){p.rt.advance(100);r=p.rt.tick({...superOptions,allowAction:false});if(r.superFast.status==='resynced')break;}
 assert.equal(r.superFast.status,'resynced',JSON.stringify(r));assert.equal(r.awaitingBoardChange,false);assert.equal(r.confirmedMoves,0);assert.equal(p.wire.length,3);
});
test('final accepted trio can settle against stable bound self-Win state when normal input is disabled',async()=>{
 const p=superFixture();dispatchSuper(p);await settleSuper(p);p.m.store.gamers[0].state=3;
 p.rt.advance(100);let r=p.rt.tick(superOptions);assert.equal(r.awaitingBoardChange,true);
 p.rt.advance(100);r=p.rt.tick(superOptions);assert.equal(r.reason,'super_fast_confirmed',JSON.stringify(r));assert.equal(r.confirmedMoves,3);assert.equal(r.superFast.reason,'win_confirmed');assert.equal(p.wire.length,3);
});
test('accepted final trio can verify stable Win after the effect deadline',async()=>{
 const p=superFixture();dispatchSuper(p);await settleSuper(p);p.m.store.gamers[0].state=3;p.rt.advance(16000);
 let r=p.rt.tick(superOptions);assert.equal(r.awaitingBoardChange,true);assert.equal(r.superFast.status,'waiting_effect');
 p.rt.advance(100);r=p.rt.tick(superOptions);assert.equal(r.confirmedMoves,3);assert.equal(r.superFast.reason,'win_confirmed');assert.equal(r.awaitingBoardChange,false);assert.equal(p.wire.length,3);
});
test('a Win label alone without the three ACKs never clears an outstanding batch',async()=>{
 const p=superFixture();dispatchSuper(p);await settleSuper(p,[0,1]);p.m.store.gamers[0].state=3;
 for(let i=0;i<5;i++){p.rt.advance(100);const r=p.rt.tick(superOptions);assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);}assert.equal(p.wire.length,3);
});

test('accepted terminal batch survives modal and same-container level replacement without replay',async()=>{
 const records=[...['a','a','a'].map((type,i)=>({zone:'board',type,x:-80+80*i})),...Array.from({length:18},(_,i)=>({zone:'board',type:'b',x:-240+80*(i%7),y:-180+90*Math.floor(i/7)}))],p=superFixture(records);
 const future=p.f.cards.slice(3);removeCards(p.f,future);p.m.sync();dispatchSuper(p);await settleSuper(p);
 const modal=p.f.node(240,102);p.f.root.children.push(modal);modal.parent=p.f.root;p.rt.advance(100);assert.equal(p.rt.tick(superOptions).reason,'modal_visible');
 p.f.root.children.splice(p.f.root.children.indexOf(modal),1);modal.parent=null;
 for(const c of future){p.f.board.children.push(c.node);c.node.parent=p.f.board;}p.m.sync();
 const r=finishSuper(p,{...superOptions,allowAction:false});assert.equal(r.confirmedMoves,3,JSON.stringify(r));assert.equal(r.awaitingBoardChange,false);assert.equal(p.wire.length,3);
});

test('equivalent Store sync on every poll cannot keep a valid initial exposed trio stuck forever',()=>{
 const p=superFixture();let r;
 for(let n=0;n<30;n++){
  for(const name of ['pile_blocks','hand_blocks','storage_blocks','props_blocks','common_blocks'])p.m.store[name]=p.m.store[name].slice();
  p.rt.advance(20);r=p.rt.tick(superOptions);if(r.dispatched)break;
 }
 assert.equal(r.dispatched,true,JSON.stringify(r));assert.equal(p.wire.length,3);
});

// A capability failure is not a server refusal and must not trap the planner.
function reachCapabilityFailure(p,options=superOptions){let r;for(let i=0;i<15;i++){p.rt.advance(20);r=p.rt.tick(options);if(r.reason==='super_fast_compatibility'||r.superFast?.status==='uncertain')return r;}assert.fail(JSON.stringify(r));}
for(const wrapping of ['rest','default'])test('Super Fast observes actual two arguments through '+wrapping+' function rather than Function.length',async()=>{
 const p=superFixture(),original=p.socket.TouchBlock;
 p.socket.TouchBlock=wrapping==='rest'?function(...args){return original.apply(this,args);}:function(id=undefined,state=undefined){return original.call(this,id,state);};
 assert.equal(p.socket.TouchBlock.length,0);const wrapped=p.socket.TouchBlock,r=dispatchSuper(p);
 assert.equal(r.superFast.requests,3);assert.equal(r.superFast.compatibility,false);assert.equal(p.socket.TouchBlock,wrapped);
 assert.equal(p.f.lastReturned,p.promises.at(-1));await settleSuper(p);assert.equal(finishSuper(p).confirmedMoves,3);
});
for(const cooperativePlanning of [false,true])for(const capability of ['hooks','event_api','timers'])test('preflight '+capability+' failure sends nothing then uses existing serial original-event path '+cooperativePlanning,()=>{
 const p=superFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i}))),op=p.socket.TouchBlock,send=p.ws.send;
 if(capability==='hooks')Object.defineProperty(p.ws,'send',{writable:false,configurable:true});
 if(capability==='event_api')delete p.ws.addEventListener;
 if(capability==='timers')p.rt.context.setTimeout=undefined;
 const failed=reachCapabilityFailure(p,{...superOptions,cooperativePlanning});
 assert.equal(failed.phaseSnapshotSummary.complete,true);assert.equal(failed.superFast.observerIssue,capability);
 assert.equal(failed.superFast.compatibility,true);assert.equal(failed.superFast.submitted,0);assert.equal(failed.superFast.requests,0);
 assert.equal(failed.superFast.pending,false);assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0);assert.equal(p.listenerCount(),0);
 assert.equal(p.socket.TouchBlock,op);assert.equal(p.ws.send,send);
 let r;for(let i=0;i<150;i++){
  const before=p.wire.length;p.rt.advance(20);r=p.rt.tick({...superOptions,cooperativePlanning});
  assert.ok(p.wire.length-before<=1,'never a blind trio');assert.equal(r.superFast.submitted,0);
  if(r.confirmedMoves===6)break;
 }
 assert.equal(r.confirmedMoves,6,JSON.stringify(r));assert.equal(p.wire.length,6);assert.equal(r.superFast.batches,0);assert.equal(p.listenerCount(),0);
 assert.equal(p.f.board.children.length,0);assert.equal(p.f.tray.children.length,0);
});
test('compatibility is observation-only while paused or exporting, and retains the ordinary no-op pending latch',()=>{
 const p=superFixture();Object.defineProperty(p.ws,'send',{writable:false,configurable:true});reachCapabilityFailure(p);
 for(const options of [{allowAction:false},{command:'pause'},{command:'phase_snapshot',allowAction:true}]){
  for(let i=0;i<10;i++){p.rt.advance(20);p.rt.tick({...superOptions,...options});}assert.equal(p.wire.length,0);
 }
 p.f.EventHandler.prototype.emit=function(args){p.f.calls.push({event:this,args});};
 let r;for(let i=0;i<12;i++){p.rt.advance(20);r=p.rt.tick({...superOptions,resumeGeneration:2});if(r.dispatched)break;}
 assert.equal(p.f.calls.length,1);assert.equal(r.awaitingBoardChange,true);
 for(let i=0;i<12;i++){p.rt.advance(1000);r=p.rt.tick({...superOptions,resumeGeneration:2});}
 assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(p.f.calls.length,1);assert.equal(p.wire.length,0);
});
test('compatibility stops on changed context instead of using stale permission to send',()=>{
 const p=superFixture();Object.defineProperty(p.ws,'send',{writable:false,configurable:true});reachCapabilityFailure(p);p.socket.uid=99;
 for(let i=0;i<12;i++){p.rt.advance(20);const r=p.rt.tick(superOptions);assert.notEqual(r.dispatched,true);assert.equal(r.superFast.compatibility,false);}
 assert.equal(p.wire.length,0);
});
test('failed hook restoration remains uncertain even with zero outbound events and never falls back',()=>{
 const p=superFixture();let reads=0;
 p.socket.socket=new Proxy(p.ws,{getOwnPropertyDescriptor(target,key){if(key==='send'&&++reads===2){p.socket.TouchBlock=function foreign(){};throw Error('fixture shadow conflict');}return Reflect.getOwnPropertyDescriptor(target,key);}});
 const r=reachCapabilityFailure(p);assert.equal(r.superFast.reason,'observer_restore_failed');assert.equal(r.superFast.observerIssue,'restore');
 assert.equal(r.superFast.pending,true);assert.equal(r.superFast.submitted,0);assert.equal(r.superFast.compatibility,false);assert.equal(p.wire.length,0);
 for(const command of ['tick','pause','reset','tick']){p.rt.advance(1000);const next=p.rt.tick({...superOptions,command});assert.equal(next.superFast.pending,true);}
 assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0);
});
test('compatibility cooldown re-probes observer after normal pending movement settles, never mid-action',async()=>{
 const p=superFixture();Object.defineProperty(p.ws,'send',{writable:false,configurable:true});reachCapabilityFailure(p);
 const one=dispatchSuper(p);assert.equal(p.wire.length,1);assert.equal(one.superFast.requests,0);assert.equal(one.awaitingBoardChange,true);
 Object.defineProperty(p.ws,'send',{writable:true});
 // Finish the existing normal move before any burst can be considered.
 let normal;for(let i=0;i<15;i++){p.rt.advance(20);normal=p.rt.tick({...superOptions,allowAction:false});if(normal.status==='move_confirmed')break;}
 assert.equal(normal.confirmedMoves,1);assert.equal(p.wire.length,1);p.rt.advance(3100);
 const burst=dispatchSuper(p);assert.equal(burst.superFast.requests,2);assert.equal(burst.superFast.compatibility,false);assert.equal(p.wire.length,3);
 await settleSuper(p,[1,2]);assert.equal(finishSuper(p).confirmedMoves,3);
});
test('500 timeout and request mismatch never enable preflight compatibility after a possible event',async()=>{
 for(const mode of ['500','timeout','mismatch']){
  const p=superFixture();if(mode==='mismatch')p.socket.TouchBlock=function(id,state){return this.send('CMD_TOUCH_BLOCK',{block_id:'foreign-fixture',block_state:state});};
  dispatchSuper(p);if(mode==='500'){p.reply(0,500);await new Promise(resolve=>setImmediate(resolve));}if(mode==='timeout')p.rt.advance(16000);
  const sent=p.wire.length;
  for(let i=0;i<15;i++){p.rt.advance(1000);const r=p.rt.tick(superOptions);assert.equal(r.superFast.pending,true);assert.equal(r.superFast.compatibility,false);assert.equal(p.wire.length,sent);}
 }
});
test('listener rollback failure before any original event remains latched rather than claiming compatibility',()=>{
 const p=superFixture();Object.defineProperty(p.ws,'send',{writable:false,configurable:true});
 p.ws.removeEventListener=function(){throw Error('fixture cannot restore observation');};
 const r=reachCapabilityFailure(p);assert.equal(r.superFast.status,'uncertain');assert.equal(r.superFast.reason,'observer_restore_failed');
 assert.equal(r.superFast.pending,true);assert.equal(r.superFast.compatibility,false);assert.equal(p.wire.length,0);
 for(let i=0;i<10;i++){p.rt.advance(1000);p.rt.tick(superOptions);}assert.equal(p.f.calls.length,0);
});
test('new preflight failure is not hidden behind a previous confirmed batch diagnostic',async()=>{
 const p=superFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));
 dispatchSuper(p);await settleSuper(p);assert.equal(finishSuper(p).superFast.status,'confirmed');
 Object.defineProperty(p.ws,'send',{writable:false,configurable:true});
 const r=reachCapabilityFailure(p);assert.equal(r.superFast.status,'blocked');assert.equal(r.superFast.reason,'observer_unavailable');
 assert.equal(r.superFast.observerIssue,'hooks');assert.equal(r.superFast.submitted,0);assert.equal(r.superFast.requests,0);
 assert.equal(r.superFast.confirmedCards,3);assert.equal(r.superFast.batches,1);assert.equal(p.wire.length,3);
});

test('ally X-ray bypasses covered-operation polling and preserves its original pending request',()=>{
 const p=coveredAdapterFixture();p.rt.tick(coveredOptions);p.rt.advance(100);
 assert.equal(p.rt.tick({...coveredOptions,coveredAttempt:true}).dispatched,true);
 const before=p.ctl.observations;enterAllyView(p.f,p.m);
 for(let i=0;i<5;i++){
  p.rt.advance(1000);const r=p.rt.tick({...coveredOptions,allowAction:true,coveredAttempt:true,penetrateAttempt:true,powersEnabled:true});
  assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);assert.equal(r.xray.matchedBorders,0);
  assert.equal(r.covered.pending,true);assert.equal(r.covered.effectObserved,false);assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);
 }
 assert.equal(p.ctl.observations,before,'a watched table must not be passed to the own request coordinator');
 assert.equal(p.ctl.calls,1);assert.equal(p.f.calls.length,1);
});
test('ally X-ray stays available before a pending power popup branch without confirming or reopening it',()=>{
 const p=powerFixture(),{rt,r}=startPower(p);assert.equal(r.reason,'power_popup_opened');p.close();
 enableRenderer(p.f);enterAllyView(p.f,p.m);
 for(let i=0;i<5;i++){
  rt.advance(1000);const out=rt.tick({...powerOptions,xrayEnabled:true});assert.equal(out.xray.status,'ready',JSON.stringify(out));
  assert.equal(out.xray.matchedBorders,0);assert.equal(out.awaitingBoardChange,true);assert.equal(out.powers.confirmed,0);assert.equal(out.confirmedMoves,0);
 }
 assert.equal(p.f.calls.length,1);assert.equal(p.infos[0].count,1);assert.equal(p.popup,null);
});
for(const mode of ['acknowledged','uncertain'])test('ally X-ray renders with a '+mode+' Super Fast batch and never settles it against the watched table',async()=>{
 const records=[...['a','a','a'].map((type,i)=>({zone:'board',type,x:-240+80*i})),
  {zone:'board',type:'b',x:160,y:180,mask:true,layer:3},{zone:'board',type:'b',x:160,y:180,layer:4}];
 const p=superFixture(records);enableRenderer(p.f);dispatchSuper(p);
 if(mode==='acknowledged')await settleSuper(p);
 else {p.rt.advance(16000);assert.equal(p.rt.tick(superOptions).superFast.status,'uncertain');}
 enterAllyView(p.f,p.m);
 for(let i=0;i<5;i++){
  p.rt.advance(1000);const r=p.rt.tick({...superOptions,xrayEnabled:true,cooperativePlanning:true,powersEnabled:true});
  assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);assert.equal(r.xray.matchedBorders,0);
  assert.equal(r.awaitingBoardChange,true);assert.equal(r.superFast.pending,true);assert.equal(r.superFast.effectObserved,false);
  assert.equal(r.confirmedMoves,0);assert.equal(r.dispatched,false);assert.equal(p.wire.length,3);assert.equal(p.f.calls.length,3);
 }
});
for(const [intent,kind] of [['coveredAttempt','touch'],['penetrateAttempt','penetrate_zero']])test('ally X-ray rejects manual '+kind+' intent without creating a pending operation',()=>{
 const p=livePenetrateFixture();enterAllyView(p.f,p.m);
 const r=p.rt.tick({...coveredOptions,[intent]:true});assert.equal(r.xray.status,'ready',JSON.stringify(r));assert.equal(r.xray.coveredIcons,1);
 assert.equal(r.covered.kind,kind);assert.equal(r.covered.pending,false);assert.equal(r.covered.reason,'external_mode_active');
 assert.equal(r.dispatched,false);assert.equal(r.awaitingBoardChange,false);assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0);
});
test('ally X-ray cannot confirm or repeat a pending cooperative warehouse pickup',()=>{
 const p=cooperativeFixture(),opts={requirePhaseSnapshot:true,cooperativePlanning:true};enableRenderer(p.f);let r;
 for(let i=0;i<8;i++){r=p.rt.tick(opts);if(r.dispatched)break;p.rt.advance(100);}
 assert.equal(r.reason,'cooperative_requested',JSON.stringify(r));assert.equal(p.f.calls.length,1);enterAllyView(p.f,p.m);
 for(let i=0;i<5;i++){
  p.rt.advance(1000);r=p.rt.tick({...opts,xrayEnabled:true});assert.equal(r.xray.status,'ready',JSON.stringify(r));
  assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(r.cooperative.confirmed,0);assert.equal(r.dispatched,false);
 }
 assert.equal(p.f.calls.length,1);
});
test('ally X-ray with the real required phase reader invalidates own phase data while keeping visible hints',()=>{
 const p=phaseFixture([{zone:'board',type:'a',x:0,mask:true},{zone:'board',type:'a',x:0},{zone:'tray',type:'a',x:-240}]);
 const render=enableRenderer(p.f),opts={...phaseOptions,allowAction:false,xrayEnabled:true};let r;
 for(let i=0;i<4;i++){p.rt.advance(100);r=p.rt.tick(opts);}
 assert.equal(r.phaseSnapshotSummary.status,'ready',JSON.stringify(r));enterAllyView(p.f,p.m);
 p.rt.advance(100);r=p.rt.tick({...opts,allowAction:true});assert.equal(r.xray.status,'ready');assert.equal(r.xray.coveredIcons,1);
 assert.equal(r.xray.matchedBorders,0);assert.equal(r.phaseSnapshotSummary.complete,false);assert.equal(r.phaseSnapshotSummary.status,'unavailable');
 const read=p.rt.tick({command:'phase_snapshot'});assert.equal(read.phaseSnapshot,null);assert.equal(read.phaseSnapshotSummary.complete,false);
 assert.ok(render.overlay());assert.equal(p.f.calls.length,0);
});
test('ally X-ray rejects a global watcher flag without ownership of the displayed GameLayer',()=>{
 for(const fault of ['missing_game','duplicate_game','foreign_layer','invalid_game']){
  const f=xrayFixture(),m=attachLiveStore(f),render=enableRenderer(f);enterAllyView(f,m);
  if(fault==='missing_game')f.root.comps.splice(f.root.comps.indexOf(m.game),1);
  if(fault==='duplicate_game')f.root.comps.push({...m.game});
  if(fault==='foreign_layer')m.game.GameLayer={...m.layer,node:f.node()};
  if(fault==='invalid_game')m.game.isValid=false;
  const r=setup(f).tick({xrayEnabled:true});assert.equal(r.xray.coveredIcons,0,fault);assert.notEqual(r.xray.status,'ready',fault);
  assert.equal(render.overlay(),undefined,fault);assert.equal(r.dispatched,false,fault);assert.equal(f.calls.length,0,fault);
 }
});

// Explicit menu quantity is independent from the timer's Super Fast cadence.
function batchOptions(cardsPerBatch,superFastEnabled=false){return {...phaseOptions,cooperativePlanning:true,superFastEnabled,cardsPerBatch};}
for(const superFastEnabled of [false,true])for(const count of [1,2,3])test('explicit '+count+' cards with Super Fast '+superFastEnabled+' sends at most that many in one evaluation',()=>{
 const p=superFixture(),r=dispatchSuper(p,batchOptions(count,superFastEnabled));
 assert.equal(p.f.calls.length,count);assert.equal(p.wire.length,count);assert.equal(r.awaitingBoardChange,true);
 assert.equal(r.superFast.submitted,count===1?0:count);assert.equal(r.confirmedMoves,0);
});
test('two-card prefix waits for both replies, confirms two, then revalidates and completes the remaining card',async()=>{
 const p=superFixture(),options=batchOptions(2);dispatchSuper(p,options);
 assert.equal(p.f.tray.children.length,2);assert.equal(p.f.board.children.length,1);
 await settleSuper(p,[0]);
 for(let i=0;i<5;i++){p.rt.advance(100);const r=p.rt.tick(options);assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(p.wire.length,2);}
 await settleSuper(p,[1]);const first=finishSuper(p,options);
 assert.equal(first.confirmedMoves,2);assert.equal(first.superFast.reason,'prefix_confirmed');assert.equal(p.listenerCount(),0);
 const next=dispatchSuper(p,options);assert.equal(next.superFast.submitted,1);assert.equal(p.wire.length,3);assert.equal(p.f.tray.children.length,0);
 await settleSuper(p,[2]);const last=finishSuper(p,options);assert.equal(last.confirmedMoves,3);assert.equal(last.awaitingBoardChange,false);assert.equal(p.wire.length,3);
});
test('quantity change cannot forget an in-flight batch and affects only the next dispatch',async()=>{
 const p=superFixture(['a','a','a','b','b','b'].map((type,i)=>({zone:'board',type,x:-240+80*i})));
 dispatchSuper(p,batchOptions(3));
 for(const count of [1,2,3,1]){p.rt.advance(100);const r=p.rt.tick(batchOptions(count));assert.equal(r.superFast.pending,true);assert.equal(r.superFast.submitted,3);assert.equal(r.confirmedMoves,0);assert.equal(p.wire.length,3);}
 await settleSuper(p);assert.equal(finishSuper(p,batchOptions(1)).confirmedMoves,3);
 dispatchSuper(p,batchOptions(1));assert.equal(p.wire.length,4);assert.equal(p.f.tray.children.length,1);
});
test('changing quantity after planning invalidates the cached three-card dispatch',()=>{
 const p=superFixture();let r;
 for(let i=0;i<12;i++){p.rt.advance(100);r=p.rt.tick(batchOptions(3));if(r.reason==='plan_ready')break;}
 assert.equal(r.reason,'plan_ready');assert.equal(p.wire.length,0);
 p.rt.advance(100);r=p.rt.tick(batchOptions(2));assert.equal(r.dispatched,false);assert.equal(p.wire.length,0);
 dispatchSuper(p,batchOptions(2));assert.equal(p.wire.length,2);
});
for(const value of [0,4,-1,2.5,'2',true,null,NaN,Infinity,{},[2]])test('invalid cardsPerBatch '+String(value)+' falls back to a single serial card',()=>{
 const p=superFixture(),r=dispatchSuper(p,batchOptions(value,true));assert.equal(p.wire.length,1);assert.equal(r.superFast.submitted,0);assert.equal(r.awaitingBoardChange,true);
});
test('two-card selection cannot use a valid prefix of a trio that would overflow the tray',()=>{
 const records=[...['a','a','a'].map((type,i)=>({zone:'board',type,x:-80+80*i})),...['b','c','d','e','f'].map((type,i)=>({zone:'tray',type,x:-240+80*i}))],p=superFixture(records);
 for(let i=0;i<12;i++){p.rt.advance(100);const r=p.rt.tick(batchOptions(2));assert.equal(r.dispatched,false);}
 assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0);
});
for(const count of [2,3])test('selected '+count+' stays read-only while paused and while viewing an ally',()=>{
 const p=superFixture(),options=batchOptions(count);
 for(let i=0;i<8;i++){p.rt.advance(100);const r=p.rt.tick({...options,allowAction:false});assert.equal(r.dispatched,false);}
 p.rt.tick({...options,command:'pause'});assert.equal(p.wire.length,0);
 enterAllyView(p.f,p.m);
 for(let i=0;i<8;i++){p.rt.advance(100);const r=p.rt.tick(options);assert.equal(r.dispatched,false);assert.equal(r.confirmedMoves,0);}
 assert.equal(p.wire.length,0);assert.equal(p.f.calls.length,0);
});
test('two-card pending prefix survives pause and ally view without confirming against the watched table',async()=>{
 const p=superFixture(),options=batchOptions(2);dispatchSuper(p,options);p.rt.tick({...options,command:'pause'});
 await settleSuper(p);enterAllyView(p.f,p.m);
 for(let i=0;i<5;i++){p.rt.advance(100);const r=p.rt.tick({...options,cardsPerBatch:3});assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);assert.equal(r.superFast.submitted,2);}
 assert.equal(p.wire.length,2);
});
test('two-card mode retains serial capability fallback without sending an unobserved pair',()=>{
 const p=superFixture(),options=batchOptions(2);Object.defineProperty(p.ws,'send',{writable:false,configurable:true});
 const failed=reachCapabilityFailure(p,options);assert.equal(failed.superFast.compatibility,true);assert.equal(p.wire.length,0);
 let r;for(let i=0;i<100;i++){const before=p.wire.length;p.rt.advance(100);r=p.rt.tick(options);assert.ok(p.wire.length-before<=1);if(r.confirmedMoves===3)break;}
 assert.equal(r.confirmedMoves,3);assert.equal(p.wire.length,3);assert.equal(r.superFast.batches,0);
});

function hotTicks(rt,options={},count=8){let r;for(let i=0;i<count;i++){rt.advance(100);r=rt.tick(options);}return r;}
function mixedHotCards(){return ['diamond','diamond','diamond','other','other','other'].map((type,i)=>({zone:'board',type,numericType:type==='diamond'?1:2,x:-240+80*i}));}
function attachHotBar(f,m,value=.8){
 function ProgressBar(){}ProgressBar.prototype=Object.create(f.cc.Component.prototype);f.cc.ProgressBar=ProgressBar;
 for(const c of [m.game,m.layer]){Object.setPrototypeOf(c,f.cc.Component.prototype);if(!c.node.comps.includes(c))c.node.comps.push(c);c.node._components=c.node.comps;}
 const handNode=f.tray.parent.parent,barNode=f.node(100,12);handNode.children.push(barNode);barNode.parent=handNode;
 const hand=Object.assign(new f.cc.Component(),{className:'HandArea',node:handNode,isValid:true,AreaNode:f.tray});
 handNode.comps.push(hand);handNode._components=handNode.comps;m.layer.HandArea=hand;
 const bar=Object.assign(new ProgressBar(),{className:'cc.ProgressBar',node:barNode,isValid:true,enabledInHierarchy:true,'_N$progress':value});
 barNode.comps.push(bar);barNode._components=barNode.comps;hand.HotTimeProgressBar=bar;
 Object.defineProperty(bar,'progress',{get(){throw Error('public progress getter forbidden');},set(){throw Error('progress write forbidden');}});return bar;
}
test('HotTime real guard locks only planner diamond clones, retains blocker graph and continues other trios',()=>{
 const f=makeFixture(mixedHotCards());let input;const rt=setup(f,{hotTimeFactory:true,planner:s=>{input=s;return directProof(s,s.cards.find(c=>c.selectable).id);}});
 reachDispatch(f,rt);assert.equal(input.cards.length,6);assert.ok(input.cards.filter(c=>c.type==='type:1').every(c=>c.selectable===false));
 assert.ok(input.cards.filter(c=>c.type==='type:2').every(c=>c.selectable===true));assert.equal(f.calls[0].event,f.cards[3].event);
 assert.ok(f.cards.every(c=>c.receiver.canTouch&&c.button.interactable));assert.ok(input.cards.every(c=>Array.isArray(c.blockedBy)));
 const g=makeFixture([{zone:'board',type:'other',numericType:2,x:0,mask:true,layer:0},{zone:'board',type:'diamond',numericType:1,x:0,layer:1},
  {zone:'tray',type:'other',numericType:2,x:-240},{zone:'tray',type:'other',numericType:2,x:-160}]);let graph;
 const gr=setup(g,{hotTimeFactory:true,planner:s=>{graph=s;return {status:'blocked',reason:'no_complete_solution'};}});hotTicks(gr);
 const diamond=graph.cards.find(c=>c.type==='type:1'),covered=graph.cards.find(c=>c.type==='type:2');assert.deepEqual(Array.from(covered.blockedBy),[diamond.id]);assert.equal(diamond.selectable,false);assert.equal(g.calls.length,0);
});
for(const factory of [true,null,()=>{throw Error('missing');}])test('HotTime blocks diamond-only Auto with real, absent or failed guard '+String(factory),()=>{
 const f=makeFixture(),rt=setup(f,{hotTimeFactory:factory}),r=hotTicks(rt,{powersEnabled:true});
 assert.equal(r.reason,'diamond_charge_unavailable');assert.equal(r.hotTime.chargePercent,null);assert.equal(r.dispatched,false);assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,0);
 f.cards[0].event.emit([]);assert.equal(f.calls.length,1,'original manual controls are unchanged');
});
test('HotTime observed percentage is diagnostic only, expires on pause/failed reads and never authorizes a diamond',()=>{
 const f=makeFixture(),m=attachLiveStore(f),bar=attachHotBar(f,m,.8),rt=setup(f,{hotTimeFactory:true});let r=hotTicks(rt);
 assert.equal(r.reason,'diamond_charge_unverified');assert.equal(r.hotTime.chargePercent,80);assert.equal(r.hotTime.trioChargePercent,null);assert.equal(r.hotTime.thresholdPercent,null);
 assert.equal(rt.tick({command:'pause'}).hotTime.chargePercent,null);hotTicks(rt);bar.node.active=false;bar.node.activeInHierarchy=false;
 r=rt.tick();assert.equal(r.hotTime.chargePercent,null);bar.node.active=true;bar.node.activeInHierarchy=true;bar['_N$progress']=1;
 r=hotTicks(rt);assert.equal(r.hotTime.chargePercent,100);assert.equal(r.reason,'diamond_charge_unverified');assert.equal(f.calls.length,0);
 rt.context.document.visibilityState='hidden';assert.equal(rt.tick().hotTime.chargePercent,null);
});
test('HotTime leaves X-ray-only diamond hints and prevents their cached route when Auto becomes active',()=>{
 const f=xrayFixture();enableRenderer(f);const rt=setup(f,{hotTimeFactory:true}),options={allowAction:false,xrayEnabled:true};
 rt.tick(options);rt.advance(100);assert.equal(rt.tick(options).xray.matchedBorders,3);
 let r=hotTicks(rt,{xrayEnabled:true});assert.equal(r.reason,'diamond_charge_unavailable');assert.equal(f.calls.length,0);
 r=hotTicks(rt,options);assert.equal(r.xray.matchedBorders,3);assert.equal(f.calls.length,0);
});
test('HotTime real guard does not affect explicit manual covered-card action',()=>{
 const p=coveredAdapterFixture();p.rt=setup(p.f,{hotTimeFactory:true,coveredFactory:()=>p.ctl});p.rt.tick(coveredOptions);p.rt.advance(100);
 const r=p.rt.tick({...coveredOptions,coveredAttempt:true});assert.equal(r.dispatched,true);assert.equal(p.ctl.selected.type,'type:1');assert.equal(p.f.calls.length,1);
});
test('HotTime rejects a planner route that ignores the locked diamond clones',()=>{
 const f=makeFixture(),rt=setup(f,{hotTimeFactory:true,planner:s=>directProof(s,s.cards[0].id)}),r=hotTicks(rt);
 assert.equal(r.reason,'diamond_charge_unavailable');assert.equal(f.calls.length,0);assert.equal(r.awaitingBoardChange,false);
});
test('HotTime protection cannot consume auto powers merely because diamond routes are blocked',()=>{
 const p=powerFixture(),stock=JSON.stringify(p.infos),rt=setup(p.f,{hotTimeFactory:true}),r=hotTicks(rt,powerOptions);
 assert.equal(r.reason,'diamond_charge_unavailable');assert.equal(p.f.calls.length,0);assert.equal(p.popup,null);assert.equal(JSON.stringify(p.infos),stock);
});
for(const cooperativePlanning of [false,true])for(const count of [1,2,3])test('HotTime keeps non-diamond capture active for batch '+count+' cooperative='+cooperativePlanning,()=>{
 const p=superFixture(mixedHotCards());p.rt=setup(p.f,{hotTimeFactory:true,phaseFactory:true,fastFactory:true});
 const r=dispatchSuper(p,{...phaseOptions,cooperativePlanning,cardsPerBatch:count});assert.equal(p.wire.length,count);assert.equal(r.dispatched,true);
 assert.ok(p.f.calls.every(c=>p.f.cards.find(card=>card.event===c.event).receiver.blockInfo.type===2));assert.ok(p.f.cards.slice(0,3).every(c=>c.node.parent===p.f.board));
});
test('HotTime rechecks cached routes and the final single event without creating a false pending action',()=>{
 for(const duringInput of [false,true]){const f=makeFixture();let permit=true;const guard=()=>({...permissiveHotTime(),allows:()=>permit,diagnostic:()=>({reason:'diamond_charge_unavailable'})});
  const rt=setup(f,{hotTimeFactory:guard});rt.tick();rt.advance(100);assert.equal(rt.tick().reason,'plan_ready');
  if(duringInput){for(const c of f.cards)c.node.convertToWorldSpaceAR=p=>{permit=false;return {x:c.node.x+p.x,y:c.node.y+p.y};};}else permit=false;
  rt.advance(100);const r=rt.tick();assert.equal(r.reason,'diamond_charge_unavailable');assert.equal(r.awaitingBoardChange,false);assert.equal(f.calls.length,0);
 }
});
test('HotTime checks every batch event and preserves requests already pending when later cards become protected',()=>{
 const p=superFixture();let permit=true;const emit=p.f.EventHandler.prototype.emit;p.f.EventHandler.prototype.emit=function(args){emit.call(this,args);permit=false;};
 p.rt=setup(p.f,{phaseFactory:true,fastFactory:true,hotTimeFactory:()=>({...permissiveHotTime(),allows:()=>permit,diagnostic:()=>({reason:'diamond_charge_unavailable'})})});
 const r=dispatchSuper(p);assert.equal(r.superFast.submitted,1);assert.equal(p.wire.length,1);assert.equal(r.awaitingBoardChange,true);
 hotTicks(p.rt,superOptions);assert.equal(p.wire.length,1);assert.equal(p.rt.tick({...superOptions,command:'pause'}).awaitingBoardChange,true);
});
test('HotTime never changes a pending snapshot or discards an already emitted original event',()=>{
 const f=makeFixture();let permit=true;const rt=setup(f,{hotTimeFactory:()=>({...permissiveHotTime(),allows:()=>permit,diagnostic:()=>({reason:'diamond_charge_unavailable'})})});
 reachDispatch(f,rt);permit=false;assert.equal(hotTicks(rt).awaitingBoardChange,true);assert.equal(rt.tick({command:'pause'}).awaitingBoardChange,true);
 const picked=f.cards.find(c=>c.event===f.calls[0].event);move(f,picked,f.tray);rt.advance(100);assert.equal(rt.tick().reason,'confirm_stability');rt.advance(100);
 assert.equal(rt.tick().status,'move_confirmed');assert.equal(f.calls.length,1);assert.equal(hotTicks(rt).reason,'diamond_charge_unavailable');
});
test('HotTime excludes allied warehouse diamonds but still permits a helpful non-diamond supply',()=>{
 for(const numericType of [1,2]){const p=cooperativeFixture();for(const c of [p.f.cards[0],p.f.cards[2],p.f.cards[3]])c.receiver.blockInfo.type=numericType;
  p.f.cards[1].receiver.blockInfo.type=9;p.m.sync();p.rt=setup(p.f,{phaseFactory:true,hotTimeFactory:true});const r=hotTicks(p.rt,{...phaseOptions,cooperativePlanning:true});
  if(numericType===1){assert.equal(r.reason,'diamond_charge_unavailable');assert.equal(p.f.calls.length,0);assert.equal(r.awaitingBoardChange,false);}
  else{assert.equal(p.f.calls.length,1);assert.equal(p.f.calls[0].event,p.f.cards[0].event);assert.equal(r.awaitingBoardChange,true);}
 }
});

function blockedTrioBatchFixture(blockers=3){
 const records=[{zone:'board',type:'target',numericType:2,x:0,mask:true,layer:0},
  ...Array.from({length:blockers},(_,i)=>({zone:'board',type:'blocker'+i,numericType:3+i,x:-30+i*30,layer:1})),
  {zone:'tray',type:'target',numericType:2,x:-240},{zone:'tray',type:'target',numericType:2,x:-160}];
 const p=superFixture(records);p.rt=setup(p.f,{phaseFactory:true,fastFactory:true,hotTimeFactory:true});return p;
}
for(const quantity of [2,3])for(const scheme of ['ws','wss'])test('batch '+quantity+' uses the unchanged original '+scheme+' socket in one evaluation despite callback cost',async()=>{
 const p=superFixture(mixedHotCards()),emit=p.f.EventHandler.prototype.emit,url=scheme+'://fixture.invalid/original?room=20';p.ws.url=url;
 p.rt=setup(p.f,{phaseFactory:true,fastFactory:true,hotTimeFactory:true});
 p.f.EventHandler.prototype.emit=function(args){emit.call(this,args);p.rt.advance(8);};
 const r=dispatchSuper(p,batchOptions(quantity));
 assert.equal(p.wire.length,quantity);assert.equal(r.superFast.submitted,quantity);assert.equal(r.superFast.requests,quantity);
 assert.equal(r.superFast.responses,0);assert.equal(r.superFast.settled,0);assert.equal(r.awaitingBoardChange,true);
 assert.equal(new Set(p.wire.map(v=>v.packet_id)).size,quantity);assert.equal(p.ws.url,url);assert.equal(p.socket.socket,p.ws);
 assert.ok(p.f.cards.slice(0,3).every(c=>c.node.parent===p.f.board),'protected diamonds remain on the board');
 await settleSuper(p);const done=finishSuper(p,{...batchOptions(quantity),allowAction:false});assert.equal(done.confirmedMoves,quantity);
});
for(const url of ['https://fixture.invalid/ws','ws://user@fixture.invalid/ws','wss://fixture.invalid/ws#fragment','ws://fixture.invalid/has space','wss://fixture.invalid\\bad'])test('malformed original transport never authorizes a batch or compatibility: '+url,()=>{
 const p=superFixture();p.ws.url=url;let r;
 for(let i=0;i<12;i++){p.rt.advance(100);r=p.rt.tick(batchOptions(3));}
 assert.equal(p.wire.length,0);assert.equal(r.superFast.observerIssue,'transport');assert.equal(r.superFast.compatibility,false);assert.equal(r.awaitingBoardChange,false);
});
for(const cooperativePlanning of [false,true])for(const quantity of [1,2,3])test('real planner submits '+quantity+' exposed mixed blockers with cooperative='+cooperativePlanning+' without preparing its covered tail',()=>{
 const p=blockedTrioBatchFixture(3),covered=p.f.cards[0];
 covered.node.convertToWorldSpaceAR=()=>{throw Error('future covered card must not get an input event');};
 const r=dispatchSuper(p,{...batchOptions(quantity),cooperativePlanning});
 assert.equal(p.wire.length,quantity);assert.equal(r.dispatched,true);assert.equal(covered.node.parent,p.f.board);
 assert.equal(covered.receiver.canTouch,false);assert.equal(covered.mask.active,true);
 assert.ok(p.wire.every(v=>v.param.block_id!==covered.receiver.blockInfo.id));
 assert.equal(new Set(p.wire.map(v=>p.f.cards.find(c=>c.receiver.blockInfo.id===v.param.block_id).type)).size,quantity);
 assert.equal(r.superFast.submitted,quantity===1?0:quantity);
});
test('real two-blocker route batches both exposed cards and waits for every reply before confirming its unmatched prefix',async()=>{
 const p=blockedTrioBatchFixture(2),options=batchOptions(2),r=dispatchSuper(p,options);
 assert.equal(r.superFast.submitted,2);assert.equal(p.f.tray.children.length,4);assert.equal(p.f.cards[0].node.parent,p.f.board);
 await settleSuper(p,[1]);
 for(let i=0;i<5;i++){p.rt.advance(100);const waiting=p.rt.tick(options);assert.equal(waiting.awaitingBoardChange,true);assert.equal(waiting.confirmedMoves,0);}
 assert.equal(p.wire.length,2);await settleSuper(p,[0]);
 // Simulate the original occlusion refresh once both blockers have left.
 p.f.cards[0].mask.active=false;p.f.cards[0].mask.activeInHierarchy=false;p.f.cards[0].receiver.canTouch=true;p.f.cards[0].button.interactable=true;p.m.sync();
 const done=finishSuper(p,{...options,allowAction:false});assert.equal(done.confirmedMoves,2);assert.equal(done.superFast.reason,'prefix_confirmed');
 assert.equal(done.awaitingBoardChange,false);assert.equal(p.wire.length,2);
 const last=dispatchSuper(p,options);assert.equal(last.superFast.submitted,1);assert.equal(p.wire.length,3);
 await settleSuper(p,[2]);assert.equal(finishSuper(p,{...options,allowAction:false}).confirmedMoves,3);
});
test('mixed batch rejection keeps all invoked requests pending without retrying or sending its covered tail',async()=>{
 const p=blockedTrioBatchFixture(3),options=batchOptions(3);dispatchSuper(p,options);await settleSuper(p,[0]);p.reply(1,500);await new Promise(resolve=>setImmediate(resolve));
 for(const command of ['tick','pause','reset','tick']){p.rt.advance(100);const r=p.rt.tick({...options,command});assert.equal(r.awaitingBoardChange,true);assert.equal(r.confirmedMoves,0);}
 assert.equal(p.wire.length,3);assert.equal(p.f.cards[0].node.parent,p.f.board);assert.equal(p.rt.tick(options).superFast.status,'uncertain');
});

test('three-card mixed prefix confirms as a prefix and not a completed trio',async()=>{
 const p=blockedTrioBatchFixture(3),options=batchOptions(3);dispatchSuper(p,options);await settleSuper(p);
 p.f.cards[0].mask.active=false;p.f.cards[0].mask.activeInHierarchy=false;p.f.cards[0].receiver.canTouch=true;p.f.cards[0].button.interactable=true;p.m.sync();
 const r=finishSuper(p,{...options,allowAction:false});assert.equal(r.confirmedMoves,3);assert.equal(r.superFast.reason,'prefix_confirmed');assert.equal(p.f.tray.children.length,5);
});

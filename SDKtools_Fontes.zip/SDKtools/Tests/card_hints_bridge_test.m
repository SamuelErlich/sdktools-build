#import "../Sources/SDKtools/STCardSamplerMenu.h"
// macOS/Foundation harness executing the exact production bridge and sanitizer.
// Only UIKit/WebKit surfaces are replaced; physical completions stay manual.
#import "../Sources/SDKtools/STCardHintsSanitizer.inc"
#import "../Sources/SDKtools/STCardFeaturePolicy.h"
#import <dispatch/dispatch.h>
#include <stdio.h>

typedef NS_ENUM(NSInteger, UIApplicationState) { UIApplicationStateActive, UIApplicationStateInactive };
@interface UIApplication : NSObject
@property UIApplicationState applicationState;
+ (instancetype)sharedApplication;
@end
@implementation UIApplication
+ (instancetype)sharedApplication { static UIApplication *app; static dispatch_once_t once; dispatch_once(&once, ^{ app = [UIApplication new]; }); return app; }
@end

@interface WKWebView : NSObject
@property (nonatomic, strong) NSObject *window;
@property (nonatomic) BOOL hidden;
@property (nonatomic) double alpha;
@property (nonatomic) BOOL throwsOnSubmission;
@property (nonatomic) NSUInteger submissions;
@property (nonatomic, copy) NSString *lastScript;
@property (nonatomic, copy) void (^completion)(id, NSError *);
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id, NSError *))completion;
- (void)complete:(id)result error:(NSError *)error;
@end
@implementation WKWebView
- (instancetype)init { if ((self = [super init])) { _window = [NSObject new]; _alpha = 1; } return self; }
- (void)evaluateJavaScript:(NSString *)script completionHandler:(void (^)(id, NSError *))completion {
    self.submissions++; self.lastScript = script;
    if (self.throwsOnSubmission) @throw [NSException exceptionWithName:@"MockSubmission" reason:nil userInfo:nil];
    self.completion = completion;
}
- (void)complete:(id)result error:(NSError *)error {
    void (^callback)(id, NSError *) = self.completion; self.completion = nil;
    if (callback) callback(result, error);
}
@end

@interface STWPContext : NSObject
@property (nonatomic, weak) WKWebView *webView;
@property (nonatomic, copy) NSString *namespaceKey;
@property (nonatomic, copy) NSString *contextID;
@property (nonatomic, copy) NSString *webViewID;
@property (nonatomic) NSUInteger visualSessionGeneration;
@property (nonatomic) BOOL retireAfterCleanup;
@end
@implementation STWPContext
@end

@interface STWebProbe : NSObject
@property BOOL inFlight;
@property BOOL cleaning;
@property BOOL acting;
@property BOOL autoplayActing;
@property BOOL cardHintsActing;
@property NSUInteger requestSerial;
@property (nonatomic, copy) NSString *cardHintsScript;
@property (nonatomic, copy) NSString *cardRootScript;
@property (nonatomic, copy) NSString *cardSamplerScript;
@property (nonatomic, strong) NSMutableArray *cleanupQueue;
@property (nonatomic, strong) NSMutableArray *visualCleanupQueue;
@property (nonatomic, strong) NSMutableArray<STWPContext *> *cardHintsCleanupQueue;
@property (nonatomic, strong) NSMapTable<WKWebView *, STWPContext *> *cardHintsContexts;
@property (nonatomic, strong) NSMutableDictionary *counters;
- (void)count:(NSString *)key;
- (void)drainCleanup;
- (void)drainCardHintsCleanup;
- (void)hideCardHints;
- (BOOL)performCardHintsInWebView:(WKWebView *)webView sessionGeneration:(NSUInteger)sessionGeneration
    validateContext:(BOOL (^)(void))validateContext update:(void (^)(NSDictionary<NSString *, id> *result))update;
@end
@implementation STWebProbe
- (instancetype)init {
    if ((self = [super init])) {
        _cardRootScript = @"function(){return {};}";
        _cardSamplerScript = @"function(){return {};}";
        _cardHintsScript = @"function(){return {tick:function(){},clear:function(){},owns:function(){}};}";
        _cardHintsContexts = [NSMapTable weakToStrongObjectsMapTable];
        _cardHintsCleanupQueue = [NSMutableArray array];
        _cleanupQueue = [NSMutableArray array]; _visualCleanupQueue = [NSMutableArray array];
        _counters = [NSMutableDictionary dictionary];
    } return self;
}
- (void)count:(NSString *)key { self.counters[key] = @([self.counters[key] unsignedIntegerValue] + 1); }
- (void)drainCleanup { if (!self.inFlight) [self drainCardHintsCleanup]; }
#include "../Sources/SDKtools/STCardHintsBridge.inc"
@end

static NSUInteger checks, failures;
static void Check(BOOL condition, NSString *message) {
    checks++; if (!condition) { failures++; fprintf(stderr, "FAIL: %s\n", message.UTF8String); }
}
static NSMutableDictionary *Result(NSString *documentID) {
    return [@{@"version": @1, @"status": @"ready", @"reason": @"hints_ready", @"shown": @3,
        @"unknown": @2, @"unavailable": @1, @"runtimeDocumentID": documentID ?: @""} mutableCopy];
}
int main(void) { @autoreleasepool {
    NSMutableDictionary *data = Result(@"document");
    data[@"privateFace"] = @"never-export"; data[@"physicalPending"] = @YES; data[@"readOnly"] = @NO;
    NSDictionary *safe = STWPSanitizeCardHints(data);
    Check([safe[@"shown"] isEqual:@3] && [safe[@"unknown"] isEqual:@2] && [safe[@"unavailable"] isEqual:@1], @"observed counts retained");
    Check(!safe[@"privateFace"] && !safe[@"runtimeDocumentID"] && ![safe[@"physicalPending"] boolValue] && [safe[@"readOnly"] boolValue], @"page cannot export faces or own native lock");
    for (NSString *key in @[@"shown", @"unknown", @"unavailable"]) {
        for (id bad in @[@YES, @(-1), @0.25, @257, @(NAN), @(INFINITY), @"3", NSNull.null]) {
            NSMutableDictionary *row = Result(nil); row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"status"] isEqual:@"error"], @"invalid count rejected");
        }
        NSMutableDictionary *row = Result(nil); [row removeObjectForKey:key];
        Check([STWPSanitizeCardHints(row)[@"status"] isEqual:@"error"], @"missing count rejected");
    }
    Check([safe[@"unknownShown"] isEqual:@0] && [safe[@"special"] isEqual:@0] && [safe[@"candidates"] isEqual:@0], @"old v1 results receive zero color extensions");
    NSMutableDictionary *colors = Result(nil);
    colors[@"unknownShown"] = @2; colors[@"special"] = @1; colors[@"candidates"] = @1;
    Check([STWPSanitizeCardHints(colors)[@"unknownShown"] isEqual:@2], @"color extensions retained");
    for (NSString *key in @[@"unknownShown", @"special", @"candidates"]) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @"1", NSNull.null]) {
            NSMutableDictionary *row = [colors mutableCopy]; row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"invalid color extension rejected");
        }
        NSMutableDictionary *row = [colors mutableCopy]; row[key] = @4;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"inconsistent color count rejected");
    }
    NSMutableDictionary *overflow = [colors mutableCopy]; overflow[@"shown"] = @256;
    Check([STWPSanitizeCardHints(overflow)[@"reason"] isEqual:@"invalid_result"], @"total marker count bounded");
    for (id invalid in @[@YES, @0, @2, @"1"]) {
        NSMutableDictionary *row = Result(nil); row[@"version"] = invalid;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"version cannot be coerced");
    }
    data[@"reason"] = @"arbitrary-user-text";
    Check([STWPSanitizeCardHints(data)[@"reason"] isEqual:@"unrecognized_reason"], @"reason allowlist enforced");
    for (NSString *reason in @[@"hints_ready", @"hidden_faces_unknown", @"no_verified_cards", @"scene_unavailable",
        @"unsupported_engine", @"hidden_document", @"layout_limited", @"read_budget", @"renderer_unavailable",
        @"invalid_card_layout", @"stale_scene", @"lease_expired", @"document_changed", @"namespace_conflict"]) {
        data[@"reason"] = reason;
        Check([STWPSanitizeCardHints(data)[@"reason"] isEqual:reason], @"known bounded reason retained");
    }


    // Current-hand census is independent of partial rendered-node counters.
    Check([safe[@"handsStatus"] isEqual:@"unavailable"] && [safe[@"handCounts"] count] == 0 &&
        [safe[@"handTotal"] isEqual:@0] && [safe[@"handKnown"] isEqual:@0] && [safe[@"handUnknown"] isEqual:@0],
        @"legacy renderer cannot manufacture a current-hand total from markers");
    NSMutableDictionary *handsResult = Result(nil);
    NSMutableDictionary *firstHand = [@{@"slot": @0, @"total": @4, @"known": @2, @"unknown": @2, @"special": @1,
        @"colors": @[@1, @1, @0, @0, @0], @"selected": @1, @"uid": @"PRIVATE", @"cardID": @98} mutableCopy];
    NSDictionary *secondHand = @{@"slot": @2, @"total": @3, @"known": @1, @"unknown": @2, @"special": @0,
        @"colors": @[@0, @0, @1, @0, @0], @"selected": @0};
    [handsResult addEntriesFromDictionary:@{@"handsStatus": @"ready", @"handCounts": @[firstHand, secondHand],
        @"handTotal": @7, @"handKnown": @3, @"handUnknown": @4}];
    NSDictionary *safeHands = STWPSanitizeCardHints(handsResult);
    Check([safeHands[@"status"] isEqual:@"ready"] && [safeHands[@"handTotal"] isEqual:@7] &&
        [safeHands[@"handKnown"] isEqual:@3] && [safeHands[@"handUnknown"] isEqual:@4] &&
        [safeHands[@"shown"] isEqual:@3], @"current hands stay independent of partial visible markers");
    NSDictionary *safeFirst = [safeHands[@"handCounts"] firstObject];
    Check(safeFirst.count == 7 && !safeFirst[@"uid"] && !safeFirst[@"cardID"] &&
        [safeFirst[@"colors"] isEqual:@[@1, @1, @0, @0, @0]], @"hand boundary rebuilds an ID-free numeric whitelist");
    firstHand[@"total"] = @256;
    Check([safeFirst[@"total"] isEqual:@4], @"sanitized hand counters do not retain mutable page dictionaries");
    firstHand[@"total"] = @4;
    NSMutableArray *mutableHandColors = [firstHand[@"colors"] mutableCopy]; firstHand[@"colors"] = mutableHandColors;
    NSDictionary *isolatedHands = STWPSanitizeCardHints(handsResult); mutableHandColors[0] = @99;
    Check([[[isolatedHands[@"handCounts"] firstObject][@"colors"] firstObject] isEqual:@1],
        @"sanitized color arrays are rebuilt rather than retaining mutable page arrays");
    firstHand[@"colors"] = @[@1, @1, @0, @0, @0];
    for (NSString *key in @[@"handsStatus", @"handCounts", @"handTotal", @"handKnown", @"handUnknown"]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; [row removeObjectForKey:key];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"partial hand schema is rejected, not treated as legacy");
    }
    for (id bad in @[@YES, @1, @"root_ready", @"PRIVATE", NSNull.null]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handsStatus"] = bad;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand status is a closed enum");
    }
    for (NSString *key in @[@"handTotal", @"handKnown", @"handUnknown"]) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @(NAN), @(INFINITY), @"1", NSNull.null]) {
            NSMutableDictionary *row = [handsResult mutableCopy]; row[key] = bad;
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand totals are bounded integers without coercion");
        }
        NSMutableDictionary *row = [handsResult mutableCopy]; row[key] = @0;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"reported hand totals must equal their rows");
    }
    for (id bad in @[@YES, @0, @{}, NSNull.null]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = bad;
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand counts must be an array");
    }
    for (id bad in @[@YES, @0, @[], NSNull.null]) {
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[bad];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand rows must be dictionaries");
    }
    for (NSString *key in @[@"slot", @"total", @"known", @"unknown", @"special", @"colors", @"selected"]) {
        NSMutableDictionary *hand = [firstHand mutableCopy]; [hand removeObjectForKey:key];
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"every current-hand field is required");
    }
    for (NSString *key in @[@"slot", @"total", @"known", @"unknown", @"special", @"selected"]) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @(NAN), @(INFINITY), @"1", NSNull.null]) {
            NSMutableDictionary *hand = [firstHand mutableCopy]; hand[key] = bad;
            NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand row counters are bounded integers without coercion");
        }
    }
    NSMutableDictionary *slotEight = [firstHand mutableCopy]; slotEight[@"slot"] = @8;
    NSMutableDictionary *invalidHands = [handsResult mutableCopy]; invalidHands[@"handCounts"] = @[slotEight, secondHand];
    Check([STWPSanitizeCardHints(invalidHands)[@"reason"] isEqual:@"invalid_result"], @"slot eight is outside the zero-to-seven contract");
    NSMutableDictionary *duplicate = [secondHand mutableCopy]; duplicate[@"slot"] = @0;
    invalidHands[@"handCounts"] = @[firstHand, duplicate];
    Check([STWPSanitizeCardHints(invalidHands)[@"reason"] isEqual:@"invalid_result"], @"duplicate slots cannot double-count a hand");
    invalidHands[@"handCounts"] = @[firstHand, secondHand, firstHand, secondHand, firstHand, secondHand, firstHand, secondHand, firstHand];
    Check([STWPSanitizeCardHints(invalidHands)[@"reason"] isEqual:@"invalid_result"], @"more than eight rows is rejected before traversal");
    for (id bad in @[@YES, @0, @{}, NSNull.null, @[@0, @0, @0, @0], @[@0, @0, @0, @0, @0, @0]]) {
        NSMutableDictionary *hand = [firstHand mutableCopy]; hand[@"colors"] = bad;
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"colors is exactly five counters");
    }
    for (NSUInteger index = 0; index < 5; index++) {
        for (id bad in @[@YES, @(-1), @0.5, @257, @(NAN), @(INFINITY), @"1", NSNull.null]) {
            NSMutableArray *colors = [firstHand[@"colors"] mutableCopy]; colors[index] = bad;
            NSMutableDictionary *hand = [firstHand mutableCopy]; hand[@"colors"] = colors;
            NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
            Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"each color count rejects invalid numeric representations");
        }
    }
    for (NSDictionary *mismatch in @[@{@"total": @5}, @{@"known": @3}, @{@"unknown": @3},
        @{@"special": @0}, @{@"selected": @3}, @{@"colors": @[@1, @0, @0, @0, @0]}]) {
        NSMutableDictionary *hand = [firstHand mutableCopy]; [hand addEntriesFromDictionary:mismatch];
        NSMutableDictionary *row = [handsResult mutableCopy]; row[@"handCounts"] = @[hand, secondHand];
        Check([STWPSanitizeCardHints(row)[@"reason"] isEqual:@"invalid_result"], @"hand partitions, color sum, special and selected invariants are enforced");
    }
    NSMutableDictionary *zeroHands = Result(nil);
    [zeroHands addEntriesFromDictionary:@{@"handsStatus": @"unavailable", @"handCounts": @[], @"handTotal": @0, @"handKnown": @0, @"handUnknown": @0}];
    Check([STWPSanitizeCardHints(zeroHands)[@"status"] isEqual:@"ready"], @"explicit unavailable census is valid only as empty and zero");
    NSDictionary *emptyHand = @{@"slot": @0, @"total": @0, @"known": @0, @"unknown": @0, @"special": @0,
        @"colors": @[@0, @0, @0, @0, @0], @"selected": @0};
    zeroHands[@"handCounts"] = @[emptyHand];
    Check([STWPSanitizeCardHints(zeroHands)[@"reason"] isEqual:@"invalid_result"], @"unavailable cannot smuggle even a zero-count hand");
    zeroHands[@"handsStatus"] = @"ready";
    NSMutableArray *eightHands = [NSMutableArray array];
    for (NSUInteger slot = 0; slot < 8; slot++) {
        NSMutableDictionary *hand = [emptyHand mutableCopy]; hand[@"slot"] = @(slot); [eightHands addObject:hand];
    }
    zeroHands[@"handCounts"] = eightHands;
    Check([STWPSanitizeCardHints(zeroHands)[@"handCounts"] count] == 8, @"eight unique zero-count hands are accepted");
    NSMutableDictionary *fullHand = [emptyHand mutableCopy]; fullHand[@"total"] = @256; fullHand[@"unknown"] = @256;
    zeroHands[@"handCounts"] = @[fullHand]; zeroHands[@"handTotal"] = @256; zeroHands[@"handUnknown"] = @256;
    Check([STWPSanitizeCardHints(zeroHands)[@"handTotal"] isEqual:@256], @"bounded current-hand census accepts the exact total limit");
    fullHand[@"unknown"] = @0; fullHand[@"known"] = @256; fullHand[@"special"] = @256;
    fullHand[@"selected"] = @256; fullHand[@"colors"] = @[@256, @0, @0, @0, @0];
    zeroHands[@"handKnown"] = @256; zeroHands[@"handUnknown"] = @0;
    Check([STWPSanitizeCardHints(zeroHands)[@"handKnown"] isEqual:@256], @"all-known special and selected counters accept their inclusive upper limit");
    fullHand[@"unknown"] = @256; fullHand[@"known"] = @0; fullHand[@"special"] = @0;
    fullHand[@"selected"] = @0; fullHand[@"colors"] = @[@0, @0, @0, @0, @0];
    zeroHands[@"handKnown"] = @0; zeroHands[@"handUnknown"] = @256;
    NSMutableDictionary *extraHand = [emptyHand mutableCopy]; extraHand[@"slot"] = @1; extraHand[@"total"] = @1; extraHand[@"unknown"] = @1;
    zeroHands[@"handCounts"] = @[fullHand, extraHand];
    Check([STWPSanitizeCardHints(zeroHands)[@"reason"] isEqual:@"invalid_result"], @"sum of individually valid hand rows cannot exceed 256");
    NSDictionary *invalidReset = STWPSanitizeCardHints(zeroHands);
    Check([invalidReset[@"handsStatus"] isEqual:@"unavailable"] && [invalidReset[@"handCounts"] count] == 0 &&
        [invalidReset[@"handTotal"] isEqual:@0], @"malformed census returns no stale or partial hand counts");

    #include "card_sampler_native_cases.inc"

    STWebProbe *probe = [STWebProbe new]; WKWebView *view = [WKWebView new];
    NSMutableDictionary *rootResult = Result(nil);
    rootResult[@"rootStatus"] = @"root_ready"; rootResult[@"rootBound"] = @3;
    rootResult[@"rootKnown"] = @2; rootResult[@"rootUnknown"] = @1; rootResult[@"rootShown"] = @1; rootResult[@"rootUnbound"] = @0;
    rootResult[@"rootReferences"] = @"PRIVATE";
    NSDictionary *safeRoot = STWPSanitizeCardHints(rootResult);
    Check([safeRoot[@"rootShown"] isEqual:@1] && !safeRoot[@"rootReferences"], @"only root counters cross native boundary");
    rootResult[@"rootKnown"] = @4;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"root totals must agree");
    rootResult[@"rootKnown"] = @2; rootResult[@"rootShown"] = @3;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"drawn root count cannot exceed verified root colors");
    rootResult[@"rootShown"] = @YES;
    Check([STWPSanitizeCardHints(rootResult)[@"reason"] isEqual:@"invalid_result"], @"root counter cannot be a coerced boolean");
    __block NSUInteger validations = 0, updates = 0;
    __block NSDictionary *blocked;
    BOOL (^valid)(void) = ^{ validations++; return YES; };
    void (^update)(NSDictionary *) = ^(NSDictionary *r) { updates++; blocked = r; };
    for (NSUInteger i = 0; i < 3; i++) {
        Check(![probe performCardHintsInWebView:view sessionGeneration:i validateContext:valid update:update], @"direct hints API rejects paused feature");
        Check([blocked[@"reason"] isEqual:@"feature_disabled"] && ![blocked[@"physicalPending"] boolValue], @"rejection is immediate and holds no physical lock");
    }
    Check(updates == 3 && validations == 0 && view.submissions == 0 && !probe.inFlight,
        @"repeated hints calls cannot validate context, inject scripts or schedule WebKit");
    Check(probe.cardHintsContexts.count == 0 && probe.requestSerial == 0 && probe.counters.count == 0,
        @"rejection allocates no runtime, request or retained diagnostics");
    probe.inFlight = YES; probe.acting = YES;
    Check(![probe performCardHintsInWebView:view sessionGeneration:4 validateContext:valid update:update] &&
        probe.inFlight && probe.acting && view.submissions == 0, @"disabled hints preserve another operation's lock");
    probe.inFlight = NO; probe.acting = NO;
    probe.cardHintsScript = nil; probe.cardRootScript = nil;
    Check(![probe performCardHintsInWebView:view sessionGeneration:5 validateContext:valid update:update] &&
        [blocked[@"reason"] isEqual:@"feature_disabled"], @"feature policy is enforced before resource or context checks");
    [probe hideCardHints];
    Check(view.submissions == 0 && !probe.inFlight, @"stopping an unused renderer is inert");

    // Preserve cleanup for an already-owned legacy context. No production
    // activation path in this build can create this fixture's context.
    STWPContext *context = [STWPContext new]; context.webView = view;
    context.namespaceKey = @"__SDKtools_cards_test"; context.contextID = @"known-document";
    [probe.cardHintsContexts setObject:context forKey:view];
    probe.inFlight = YES;
    [probe hideCardHints];
    Check(probe.cardHintsCleanupQueue.count == 1 && view.submissions == 0,
        @"cleanup waits for the actual physical operation to finish");
    Check(![probe performCardHintsInWebView:view sessionGeneration:6 validateContext:valid update:update] &&
        probe.cardHintsCleanupQueue.count == 1 && view.submissions == 0,
        @"disabled entry does not drain pending cleanup as a hidden side effect");
    probe.inFlight = NO; [probe drainCleanup];
    Check(probe.inFlight && probe.cleaning && view.submissions == 1 && [view.lastScript containsString:@"s.runtime.clear()"],
        @"explicit cleanup still removes the SDK-owned renderer after lock release");
    [view complete:@YES error:nil];
    Check(!probe.inFlight && !probe.cleaning && [context.contextID isEqual:@"known-document"],
        @"cleanup completion preserves document identity and releases the physical lock");
    view.throwsOnSubmission = YES; [probe hideCardHints];
    Check(probe.inFlight && probe.cleaning, @"throwing cleanup does not invent cancellation acknowledgment");
    printf("Card hints bridge: %lu checks, %lu failures\n", (unsigned long)checks, (unsigned long)failures);
    return failures ? 1 : 0;
} }

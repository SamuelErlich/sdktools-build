"""Trust-boundary source checks supplement the native KeyAuth lifecycle tests."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class KeyAuthContract(unittest.TestCase):
 def test_native_client_uses_public_configuration_and_os_keychain(self):
  s=(ROOT/'Sources/SDKtools/STLicenseManager.m').read_text(encoding='utf-8')
  for token in ['Weplaysdk','Jdh0dfFTTT','@"1.0"','SecItemCopyMatching','SecItemUpdate','SecItemAdd','SecItemDelete','kSecAttrAccessibleWhenUnlockedThisDeviceOnly']:
   self.assertIn(token,s)
  for token in ['NSUserDefaults','UIPasteboard','NSLog','SellerKey','AppSecret']:
   self.assertNotIn(token,s)
 def test_signatures_and_time_are_checked_before_json_is_trusted(self):
  s=(ROOT/'Sources/SDKtools/STLicenseManager.m').read_text(encoding='utf-8')
  self.assertIn('STKeyAuthVerifyEd25519',s)
  self.assertIn('x-signature-ed25519',s);self.assertIn('x-signature-timestamp',s)
  self.assertLess(s.index('STKeyAuthVerifyEd25519'),s.index('JSONObjectWithData'))
  self.assertIn('completionHandler(nil)',s)
 def test_no_authentication_data_is_added_to_exports(self):
  for name in ['STLANRecorder.inc','STCoveredCardReport.inc','STRecorder.m']:
   s=(ROOT/'Sources/SDKtools'/name).read_text(encoding='utf-8')
   self.assertNotIn('@"licenseKey":',s);self.assertNotIn('@"keyauthSession":',s)
if __name__=='__main__':unittest.main()

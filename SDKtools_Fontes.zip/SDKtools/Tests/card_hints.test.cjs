const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_hints.js'),'utf8');
const BASE_NAME=String.fromCharCode(65,18,178,215,49),ALT_BACK_NAME=String.fromCharCode(67,37,243,108,163);
function setup(){
 let time=0,nextRAF=0,currentRoot;const created=[],scheduled=new Map();
 class Color{constructor(r=255,g=255,b=255,a=255){Object.assign(this,{r,g,b,a});}}
 class Node{
  constructor(name){Object.assign(this,{name,x:0,y:0,width:10,height:10,scaleX:1,scaleY:1,angle:0,anchorX:.5,anchorY:.5,zIndex:0,active:true,isValid:true,opacity:255,color:new Color(),children:[],parent:null,comps:[],group:'default'});created.push(this);}
  get activeInHierarchy(){return this.parent?this.active&&this.parent.activeInHierarchy:true;}
  addChild(n){if(n.parent)n.removeFromParent();n.parent=this;this.children.push(n);}
  removeFromParent(){if(this.parent){this.parent.children.splice(this.parent.children.indexOf(this),1);this.parent=null;}}
  destroy(){this.isValid=false;this.children.forEach(c=>c.destroy());}
  addComponent(C){const c=new C();c.node=this;this.comps.push(c);return c;}
  getComponent(C){return this.comps.find(c=>c instanceof C)||null;}
  convertToWorldSpaceAR(p){let n=this,x=p.x,y=p.y;while(n){const a=n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=x*n.scaleX,yy=y*n.scaleY;x=c*xx-s*yy+n.x;y=s*xx+c*yy+n.y;n=n.parent;}return{x,y};}
  convertToNodeSpaceAR(p){const chain=[];let n=this,x=p.x,y=p.y;while(n){chain.push(n);n=n.parent;}for(n of chain.reverse()){x-=n.x;y-=n.y;const a=-n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=c*x-s*y,yy=s*x+c*y;x=xx/n.scaleX;y=yy/n.scaleY;}return{x,y};}
 }
 class Sprite{constructor(){this.enabled=true;this.type=0;this.trim=true;}get enabledInHierarchy(){return this.enabled&&this.node.activeInHierarchy;}}Sprite.Type={SIMPLE:0};Sprite.SizeMode={CUSTOM:0};
 class Graphics{constructor(){this.commands=[];this.clears=0;}clear(){this.commands=[];this.clears++;}moveTo(x,y){this.commands.push(['M',x,y]);}lineTo(x,y){this.commands.push(['L',x,y]);}close(){this.commands.push(['Z']);}fill(){this.commands.push(['fill']);}stroke(){this.commands.push(['stroke']);}}
 const cc={Node,Sprite,Graphics,Color,ENGINE_VERSION:'2.4.5',v2:(x,y)=>({x,y}),director:{getScene:()=>currentRoot},Canvas:{instance:{node:null}}};
 const doc={hidden:false,visibilityState:'visible',querySelector:()=>({getBoundingClientRect:()=>({width:390,height:693.16})})};
 const win={cc,CocosEngine:'2.4.5',performance:{now:()=>time},requestAnimationFrame:fn=>{scheduled.set(++nextRAF,fn);return nextRAF;},cancelAnimationFrame:id=>scheduled.delete(id)};
 const context={window:win,document:doc,Map,WeakMap,Set,WeakSet,Date};vm.createContext(context);
 const overlay=vm.runInContext(source,context)();
 function newScene(){const scene=new Node('Scene');scene.active=false;const canvas=new Node('Canvas');canvas.width=1500;canvas.height=2666;scene.addChild(canvas);currentRoot=scene;cc.Canvas.instance.node=canvas;return {scene,canvas};}
 const initial=newScene();
 function frame(name,rect){const texture={loaded:true};return{name,getRect:()=>({x:rect[0],y:rect[1],width:rect[2],height:rect[3]}),getTexture:()=>texture};}
 function art(name,parent,w,h,fr){const n=new Node(name);n.width=w;n.height=h;parent.addChild(n);const sp=n.addComponent(Sprite);sp.spriteFrame=fr;return n;}
 function card({x=0,y=-850,face=true,alternateBack=false,parent=cc.Canvas.instance.node}={}){
  const n=new Node('Card');Object.assign(n,{width:224,height:295,x,y,scaleX:.8,scaleY:.8});parent.addChild(n);
  const shadow=new Node('Shadow');shadow.active=false;n.addChild(shadow);
  const base=art('Base',n,216,286,frame(BASE_NAME,[909,212,216,286]));
  const front=new Node('Front');front.width=224;front.height=295;front.active=face;n.addChild(front);
  const color=art('Color',front,210,280,frame('frontColor',[1590,212,210,280]));
  const decoration=new Node('Decoration');decoration.active=false;front.addChild(decoration);
  const symbol=art('Symbol',front,175,209,frame('frontSymbol',[1834,228,175,209]));
  const extra=new Node('Extra');extra.active=false;front.addChild(extra);
  const back=art('Back',n,224,295,alternateBack?frame(ALT_BACK_NAME,[1138,212,210,280]):frame('',[1357,208,224,295]));back.active=!face;
  return{node:n,base,front,color,symbol,back};
 }
 function hints(){const l=cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Faces');return l?l.children.filter(n=>n.name==='SDKtools Visible Card'):[];}
 function layer(){return cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Faces');}
 function advance(ms){time+=ms;const q=[...scheduled.values()];scheduled.clear();q.forEach(fn=>fn(time));}
 return{cc,doc,win,context,overlay,frame,card,hints,layer,advance,created,scheduled,initial,newScene,now:()=>time};
}
function plain(v){return JSON.parse(JSON.stringify(v));}

test('verified visible front renders its own real composite even with scene.active=false',()=>{
 const f=setup(),c=f.card();assert.equal(f.initial.scene.active,false);assert.equal(f.initial.scene.activeInHierarchy,true);
 assert.equal(c.back.getComponent(f.cc.Sprite).enabledInHierarchy,false);
 const r=f.overlay.tick();assert.deepEqual(plain(r),{version:1,status:'ready',reason:'hints_ready',shown:1,unknown:0,unavailable:0});
 const parts=f.hints()[0].children;assert.equal(parts.length,3);assert.deepEqual(parts.map(n=>n.getComponent(f.cc.Sprite).spriteFrame),[c.base,c.color,c.symbol].map(n=>n.getComponent(f.cc.Sprite).spriteFrame));
});
test('inactive back is not read or required for a visible front',()=>{
 const f=setup(),c=f.card();c.back.getComponent=()=>{throw Error('inactive back must not be inspected');};
 assert.equal(f.overlay.tick().shown,1);
});
test('both verified back styles remain unknown without reading their inactive fronts',()=>{
 const f=setup(),a=f.card({x:-200,face:false}),b=f.card({x:200,face:false,alternateBack:true});
 for(const c of [a,b])Object.defineProperty(c.front,'children',{get(){throw Error('inactive fronts are not evidence');}});
 assert.deepEqual(plain(f.overlay.tick()),{version:1,status:'ready',reason:'hidden_faces_unknown',shown:0,unknown:2,unavailable:0});assert.equal(f.hints().length,0);
});
test('no asset catalogue is inspected to assign a back identity',()=>{
 const f=setup();f.card({face:false});Object.defineProperty(f.cc,'assetManager',{get(){throw Error('catalogue read');}});Object.defineProperty(f.win,'__require',{get(){throw Error('module read');}});
 assert.equal(f.overlay.tick().unknown,1);
});
test('a frame name hash alone never recognizes a back',()=>{
 const f=setup(),c=f.card({face:false});c.back.getComponent(f.cc.Sprite).spriteFrame=f.frame('',[0,0,1090,1090]);const r=f.overlay.tick();assert.equal(r.unknown,0);assert.equal(r.shown,0);
});
test('front/back transitions remove hints immediately without cached hidden identity',()=>{
 const f=setup(),c=f.card();assert.equal(f.overlay.tick().shown,1);const old=f.hints()[0];c.front.active=false;c.back.active=true;const r=f.overlay.tick();assert.equal(r.shown,0);assert.equal(r.unknown,1);assert.equal(old.isValid,false);
 c.front.active=true;c.back.active=false;c.symbol.getComponent(f.cc.Sprite).spriteFrame=f.frame('replacement',[1,1,175,209]);assert.equal(f.overlay.tick().shown,1);assert.equal(f.hints()[0].children[2].getComponent(f.cc.Sprite).spriteFrame,c.symbol.getComponent(f.cc.Sprite).spriteFrame);
});
test('twenty CSS-pixel hint tracks translation and keeps source artwork unchanged',()=>{
 const f=setup(),c=f.card();const before=JSON.stringify({x:c.node.x,y:c.node.y,children:c.node.children.length,scale:c.node.scaleX,frame:c.symbol.getComponent(f.cc.Sprite).spriteFrame.name});f.overlay.tick();const hint=f.hints()[0],oldX=hint.x,oldY=hint.y;
 const width=hint.children[1].width*hint.children[1].scaleX;assert.ok(Math.abs(width/1500*390-20*210/224)<1e-8);
 c.node.x+=100;c.node.y+=50;f.advance(40);assert.equal(f.hints()[0],hint);assert.ok(Math.abs(hint.x-oldX-100)<1e-8);assert.ok(Math.abs(hint.y-oldY-50)<1e-8);
 c.node.x-=100;c.node.y-=50;assert.equal(JSON.stringify({x:c.node.x,y:c.node.y,children:c.node.children.length,scale:c.node.scaleX,frame:c.symbol.getComponent(f.cc.Sprite).spriteFrame.name}),before);
});
test('unchanged snapshots reuse nodes, frame objects and graphics without redraw',()=>{
 const f=setup();f.card();f.overlay.tick();const nodes=f.created.slice(),g=f.hints()[0].getComponent(f.cc.Graphics),count=g.clears;
 for(let i=0;i<5;i++){f.advance(40);f.overlay.tick();}assert.deepEqual(f.created,nodes);assert.equal(g.clears,count);
});
test('latest sibling on a discard pile wins even if an older card is lower',()=>{
 const f=setup(),old=f.card({x:0,y:0}),top=f.card({x:0,y:10});old.node.scaleX=old.node.scaleY=.7;top.node.scaleX=top.node.scaleY=.8;
 const r=f.overlay.tick();assert.equal(r.shown,1);assert.equal(r.unavailable,1);assert.equal(f.hints()[0].children[2].getComponent(f.cc.Sprite).spriteFrame,top.symbol.getComponent(f.cc.Sprite).spriteFrame);
});
test('explicit zIndex precedes sibling order when selecting the topmost discard',()=>{
 const f=setup(),high=f.card({y:0}),low=f.card({y:0});high.node.zIndex=5;low.node.zIndex=0;const r=f.overlay.tick();assert.equal(r.shown,1);assert.equal(f.hints()[0].children[2].getComponent(f.cc.Sprite).spriteFrame,high.symbol.getComponent(f.cc.Sprite).spriteFrame);
});
test('a verified back above a front suppresses its underlying front hint',()=>{
 const f=setup();f.card({y:0});f.card({y:0,face:false});const r=f.overlay.tick();assert.equal(r.shown,0);assert.equal(r.unknown,1);assert.equal(r.unavailable,1);
});
test('layout culling does not create and destroy rejected nodes every frame',()=>{
 const f=setup();f.card({x:0});f.card({x:50});f.overlay.tick();const count=f.created.length;for(let i=0;i<5;i++)f.advance(40);assert.equal(f.created.length,count);assert.equal(f.hints().length,1);
});
test('lease expiration cleans stale hints without a native callback',()=>{
 const f=setup();f.card();f.overlay.tick();const old=f.layer();assert.equal(f.scheduled.size,1);f.advance(601);assert.equal(old.isValid,false);assert.equal(f.layer(),undefined);assert.equal(f.scheduled.size,0);
});
test('native heartbeat renews lease and clear remains idempotent and restartable',()=>{
 const f=setup();f.card();f.overlay.tick();f.advance(400);f.overlay.tick();f.advance(400);assert.equal(f.hints().length,1);f.overlay.clear();f.overlay.clear();assert.equal(f.scheduled.size,0);assert.equal(f.layer(),undefined);assert.equal(f.overlay.tick().shown,1);
});
test('document hiding or replacement clears RAF work and owned nodes',()=>{
 for(const replace of [false,true]){const f=setup();f.card();f.overlay.tick();const old=f.layer();if(replace)f.context.document={...f.doc};else f.doc.hidden=true;f.advance(40);assert.equal(old.isValid,false);assert.equal(f.scheduled.size,0);}
});
test('scene change clears old tree automatically and next tick creates fresh hints',()=>{
 const f=setup();f.card();f.overlay.tick();const old=f.layer();f.newScene();f.card();f.advance(40);assert.equal(old.isValid,false);assert.equal(f.hints().length,0);assert.equal(f.overlay.tick().shown,1);
});
test('engine mismatch is explicit and destroys previously shown hints',()=>{
 const f=setup();f.card();f.overlay.tick();f.cc.ENGINE_VERSION='2.4.4';const r=f.overlay.tick();assert.equal(r.status,'unsupported');assert.equal(r.reason,'unsupported_engine');assert.equal(f.hints().length,0);
});
test('invalid front composite fails closed with no guessed symbol',()=>{
 const f=setup(),c=f.card();c.symbol.active=false;const r=f.overlay.tick();assert.equal(r.status,'error');assert.equal(r.reason,'invalid_card_layout');assert.equal(r.shown,0);
});
test('unknown cards and known fronts can coexist with an explicit count',()=>{
 const f=setup();f.card({x:-250});f.card({x:250,face:false});const r=f.overlay.tick();assert.equal(r.status,'ready');assert.equal(r.reason,'hidden_faces_unknown');assert.equal(r.shown,1);assert.equal(r.unknown,1);
});
test('SDK nodes are excluded and ownership never includes original game nodes',()=>{
 const f=setup(),c=f.card();f.overlay.tick();assert.equal(f.overlay.owns(c.node),false);assert.equal(f.overlay.owns(f.layer()),true);assert.equal(f.overlay.owns(f.hints()[0]),true);assert.equal(f.overlay.owns(null),false);
 const n=new f.cc.Node('SDKtools unrelated overlay');n.width=224;n.height=295;f.initial.scene.addChild(n);Object.defineProperty(n,'children',{get(){throw Error('other SDK nodes should not be scanned');}});assert.equal(f.overlay.tick().shown,1);
});
test('runtime has no namespace mutation, network calls, action dispatch or catalogue scan',()=>{
 assert.ok(Buffer.byteLength(source)<65536);assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);assert.doesNotMatch(source,/\.emit\s*\(|\.on\s*\(|touchBlock|assetManager|__require|window\.[A-Za-z_$]+\s*=/);
 const f=setup(),keys=Object.keys(f.win);f.card();f.overlay.tick();assert.deepEqual(Object.keys(f.win),keys);assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>!n.comps.some(c=>/Button|Collider|BlockInput/.test(c.constructor.name))));
});

test('overlay inherits the active Canvas camera group and coordinate transform',()=>{
 const f=setup();f.initial.canvas.group='UI';f.initial.canvas.x=137;f.initial.canvas.y=49;f.initial.canvas.scaleX=.9;f.initial.canvas.scaleY=.9;const c=f.card({x:100,y:-500});const r=f.overlay.tick();assert.equal(r.shown,1);assert.equal(f.layer().parent,f.initial.canvas);assert.equal(f.layer().group,'UI');assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>n.group==='UI'));assert.ok(Math.abs(f.hints()[0].x-c.node.x)<1e-8);
});

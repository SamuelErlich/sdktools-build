const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../Resources/card_hints.js'),'utf8');
const BASE_NAME=String.fromCharCode(65,18,178,215,49),ALT_BACK_NAME=String.fromCharCode(67,37,243,108,163);
function setup({viewportWidth=390}={}){
 let time=0,nextRAF=0,currentRoot;const created=[],scheduled=new Map();
 class Color{constructor(r=255,g=255,b=255,a=255){Object.assign(this,{r,g,b,a});}}
 class Node{
  constructor(name){Object.assign(this,{name,x:0,y:0,width:10,height:10,scaleX:1,scaleY:1,angle:0,anchorX:.5,anchorY:.5,zIndex:0,active:true,isValid:true,opacity:255,color:new Color(),children:[],parent:null,comps:[],group:'default'});this._components=this.comps;created.push(this);}
  get activeInHierarchy(){return this.parent?this.active&&this.parent.activeInHierarchy:true;}
  addChild(n){if(n.parent)n.removeFromParent();n.parent=this;this.children.push(n);}
  removeFromParent(){if(this.parent){this.parent.children.splice(this.parent.children.indexOf(this),1);this.parent=null;}}
  destroy(){this.isValid=false;this.children.forEach(c=>c.destroy());}
  addComponent(C){const c=new C();c.node=this;this.comps.push(c);return c;}
  getComponent(C){return this.comps.find(c=>c instanceof C)||null;}
  convertToWorldSpaceAR(p){let n=this,x=p.x,y=p.y;while(n){const a=n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=x*n.scaleX,yy=y*n.scaleY;x=c*xx-s*yy+n.x;y=s*xx+c*yy+n.y;n=n.parent;}return{x,y};}
  convertToNodeSpaceAR(p){const chain=[];let n=this,x=p.x,y=p.y;while(n){chain.push(n);n=n.parent;}for(n of chain.reverse()){x-=n.x;y-=n.y;const a=-n.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),xx=c*x-s*y,yy=s*x+c*y;x=xx/n.scaleX;y=yy/n.scaleY;}return{x,y};}
 }
 class Sprite{constructor(){this.enabled=true;this.type=0;this.trim=true;}get enabledInHierarchy(){return this.enabled&&this.node.activeInHierarchy;}}Sprite.Type={SIMPLE:0};Sprite.SizeMode={CUSTOM:0};
 class Graphics{constructor(){this.commands=[];this.clears=0;}clear(){this.commands=[];this.clears++;}moveTo(x,y){this.commands.push(['M',x,y]);}lineTo(x,y){this.commands.push(['L',x,y]);}close(){this.commands.push(['Z']);}fill(){this.commands.push(['fill']);}stroke(){this.commands.push(['stroke']);}circle(x,y,r){this.commands.push(['circle',x,y,r]);}}
 const cc={Node,Sprite,Graphics,Color,ENGINE_VERSION:'2.4.5',v2:(x,y)=>({x,y}),director:{getScene:()=>currentRoot},Canvas:{instance:{node:null}}};
 const doc={hidden:false,visibilityState:'visible',querySelector:()=>({getBoundingClientRect:()=>({width:viewportWidth,height:viewportWidth*2666/1500})})};
 const win={cc,CocosEngine:'2.4.5',performance:{now:()=>time},requestAnimationFrame:fn=>{scheduled.set(++nextRAF,fn);return nextRAF;},cancelAnimationFrame:id=>scheduled.delete(id)};
 const context={window:win,document:doc,Map,WeakMap,Set,WeakSet,Date};vm.createContext(context);
 const overlay=vm.runInContext(source,context)();
 function newScene(){const scene=new Node('Scene');scene.active=false;const canvas=new Node('Canvas');canvas.width=1500;canvas.height=2666;scene.addChild(canvas);currentRoot=scene;cc.Canvas.instance.node=canvas;return {scene,canvas};}
 const initial=newScene();
 function frame(name,rect){const texture={loaded:true};return{name,getRect:()=>({x:rect[0],y:rect[1],width:rect[2],height:rect[3]}),getTexture:()=>texture};}
 function art(name,parent,w,h,fr){const n=new Node(name);n.width=w;n.height=h;parent.addChild(n);const sp=n.addComponent(Sprite);sp.spriteFrame=fr;return n;}
 function card({x=0,y=-850,face=true,alternateBack=false,parent=cc.Canvas.instance.node}={}){
  const n=new Node('Card');Object.assign(n,{width:224,height:295,x,y,scaleX:.8,scaleY:.8});parent.addChild(n);
  const shadow=new Node('Shadow');shadow.active=false;n.addChild(shadow);
  const base=art('Base',n,216,286,frame(BASE_NAME,[909,212,216,286]));
  const front=new Node('Front');front.width=224;front.height=295;front.active=face;n.addChild(front);
  const color=art('Color',front,210,280,frame('card_bg_red',[1590,212,210,280]));
  const decoration=new Node('Decoration');decoration.active=false;front.addChild(decoration);
  const symbol=art('Symbol',front,175,209,frame('num3_red',[1834,228,175,209]));
  const extra=new Node('Extra');extra.active=false;front.addChild(extra);
  const back=art('Back',n,224,295,alternateBack?frame(ALT_BACK_NAME,[1138,212,210,280]):frame('',[1357,208,224,295]));back.active=!face;
  return{node:n,base,front,color,symbol,back};
 }
 function hints(){const l=cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Colors');return l?l.children.filter(n=>n.name==='SDKtools Card Color'):[];}
 function layer(){return cc.Canvas.instance.node.children.find(n=>n.name==='SDKtools Card Colors');}
 function advance(ms){time+=ms;const q=[...scheduled.values()];scheduled.clear();q.forEach(fn=>fn(time));}
 return{cc,doc,win,context,overlay,frame,card,hints,layer,advance,created,scheduled,initial,newScene,viewportWidth,now:()=>time};
}
function plain(v){return JSON.parse(JSON.stringify(v));}
function attachCard(f,c,info={type:1,color:1,num:3},className='Card'){
 const component={__classname__:className,cardInfo:info,skinNode:c.front,bgSprite:c.color.getComponent(f.cc.Sprite),typeSprite:c.symbol.getComponent(f.cc.Sprite),backSprite:c.back.getComponent(f.cc.Sprite)};
 c.node._components.push(component);return component;
}
function currentArt(f,c,bg='card_bg_red',symbol='num3_red'){
 c.color.getComponent(f.cc.Sprite).spriteFrame=f.frame(bg,[1590,212,210,280]);
 c.symbol.getComponent(f.cc.Sprite).spriteFrame=f.frame(symbol,[1834,228,175,209]);
}
function hintBounds(f,hint){
 const unit=1500/f.viewportWidth,hw=11*unit,hh=11*unit;
 return{left:hint.x-hw,right:hint.x+hw,bottom:hint.y-hh,top:hint.y+hh};
}
function intersects(a,b){return a.left<b.right&&a.right>b.left&&a.bottom<b.top&&a.top>b.bottom;}
function cardBounds(f,card){
 const n=card.node,points=[[-112,-147.5],[112,-147.5],[112,147.5],[-112,147.5]].map(([x,y])=>f.layer().convertToNodeSpaceAR(n.convertToWorldSpaceAR({x,y})));
 return{left:Math.min(...points.map(p=>p.x)),right:Math.max(...points.map(p=>p.x)),bottom:Math.min(...points.map(p=>p.y)),top:Math.max(...points.map(p=>p.y))};
}

function graphic(f,index=0){return f.hints()[index].getComponent(f.cc.Graphics);}
function counts(r){return [r.shown,r.unknown,r.unavailable,r.unknownShown,r.special,r.candidates];}
test('visible color uses graphics only and leaves source artwork untouched',()=>{
 const f=setup(),c=f.card(),before=c.node.children.slice();assert.equal(f.overlay.tick().shown,1);
 assert.equal(f.hints()[0].children.length,0);assert.deepEqual(c.node.children,before);
 assert.deepEqual(plain(graphic(f).fillColor),{r:230,g:93,b:148,a:255});assert.ok(graphic(f).commands.some(c=>c[0]==='circle'));
});
test('all four semantic colors and color-blind marks follow source palette',()=>{
 const palette=[[230,93,148],[17,135,255],[254,200,100],[175,226,77]],names=['red','blue','yellow','green'];
 names.forEach((name,i)=>{const f=setup(),c=f.card();attachCard(f,c,{type:1,color:i+1});currentArt(f,c,'card_bg_'+name,'num9_'+name);
 assert.equal(f.overlay.tick().shown,1);assert.deepEqual(plain(graphic(f).fillColor),{r:palette[i][0],g:palette[i][1],b:palette[i][2],a:255});
 assert.equal(graphic(f).commands.filter(c=>c[0]==='L').length,i+2);});
});
test('color reading does not require a number or decode card IDs',()=>{
 for(const num of [undefined,NaN,0,99]){const f=setup(),c=f.card();attachCard(f,c,{id:99999999,type:1,color:1,num});currentArt(f,c);assert.equal(f.overlay.tick().shown,1);}
});
test('both back styles draw unknown rings without reading inactive artwork',()=>{
 const f=setup();for(const alternateBack of [false,true]){const c=f.card({x:alternateBack?250:-250,face:false,alternateBack});Object.defineProperty(c.front,'children',{get(){throw Error('inactive art');}});}
 assert.deepEqual(counts(f.overlay.tick()),[0,2,0,2,0,0]);assert.equal(f.hints().length,2);
});
test('Back with retained color remains unknown and is counted only as a candidate',()=>{
 for(const face of [false,true]){const f=setup(),c=f.card({face});attachCard(f,c,{type:0,color:2,num:9});Object.defineProperty(c.front,'children',{get(){throw Error('stale');}});
 assert.deepEqual(counts(f.overlay.tick()),[0,1,0,1,0,1]);}
});
test('hidden non-Back component does not establish a fresh store binding',()=>{
 const f=setup(),c=f.card({face:false});attachCard(f,c);currentArt(f,c);assert.deepEqual(counts(f.overlay.tick()),[0,1,0,1,0,1]);assert.equal(c.front.active,false);
});
test('specials are multicolor even if the active table color has a value',()=>{
 for(const [type,symbol] of [[4,'change_color'],[6,'inc4'],[10,'throw_pot']]){const f=setup(),c=f.card();attachCard(f,c,{type,color:4});currentArt(f,c,'card_bg_special',symbol);assert.deepEqual(counts(f.overlay.tick()),[1,0,0,0,1,0]);assert.equal(graphic(f).commands.filter(c=>c[0]==='fill').length,5);}
});
test('absent component uses only agreeing known visible frame colors',()=>{
 for(const [bg,symbol] of [['card_bg_red','num3_blue'],['unrelated','num3_red'],['card_bg_red','unknown_red'],['card_bg_special','num3_red']]){
 const f=setup(),c=f.card();currentArt(f,c,bg,symbol);assert.equal(f.overlay.tick().shown,0);}
});
test('present malformed semantics never fall back to stale artwork',()=>{
 for(const info of [null,{}, {type:'1',color:1},{type:11,color:1},{type:1,color:0},{type:1,color:5},{type:1,color:NaN}]){const f=setup(),c=f.card();attachCard(f,c,info);assert.equal(f.overlay.tick().unavailable,1);}
});
test('game accessors are not executed for semantic fields',()=>{
 for(const key of ['cardInfo','type','color','bgSprite']){const f=setup(),c=f.card(),component=attachCard(f,c);let calls=0;
 Object.defineProperty(['type','color'].includes(key)?component.cardInfo:component,key,{get(){calls++;throw Error('getter');}});assert.equal(f.overlay.tick().shown,0);assert.equal(calls,0);}
});
test('cross-card structural references are rejected',()=>{
 const f=setup(),a=f.card({x:-250}),b=f.card({x:250}),component=attachCard(f,a);component.bgSprite=b.color.getComponent(f.cc.Sprite);
 assert.equal(f.overlay.tick().unavailable,1);assert.equal(f.overlay.tick().shown,1);
});
test('asynchronous color loads stay suppressed until state and both frames agree',()=>{
 const f=setup(),c=f.card(),component=attachCard(f,c);assert.equal(f.overlay.tick().shown,1);const old=f.hints()[0];
 component.cardInfo={type:1,color:2};assert.equal(f.overlay.tick().shown,0);assert.equal(old.isValid,false);
 currentArt(f,c,'card_bg_blue','num3_red');assert.equal(f.overlay.tick().shown,0);
 currentArt(f,c,'card_bg_blue','num7_blue');assert.equal(f.overlay.tick().shown,1);
});
test('same-color type/number changes do not require an exact face identity',()=>{
 const f=setup(),c=f.card();attachCard(f,c,{type:2,color:1,num:999});assert.equal(f.overlay.tick().shown,1);
});
test('node reuse never retains previous color through Back or object replacement',()=>{
 const f=setup(),c=f.card(),comp=attachCard(f,c,{id:7,type:1,color:1});f.overlay.tick();const hint=f.hints()[0];
 comp.cardInfo={id:99,type:0,color:1};c.front.active=false;c.back.active=true;f.advance(40);assert.equal(f.hints()[0],hint);assert.equal(f.overlay.tick().shown,0);assert.equal(f.overlay.tick().unknownShown,1);
 comp.cardInfo={id:99,type:1,color:4};c.front.active=true;c.back.active=false;assert.equal(f.overlay.tick().shown,0);
 currentArt(f,c,'card_bg_green','num8_green');assert.equal(f.overlay.tick().shown,1);assert.deepEqual(plain(graphic(f).fillColor),{r:175,g:226,b:77,a:255});
});
test('state changes during geometry computation cannot publish stale color',()=>{
 const f=setup(),c=f.card(),component=attachCard(f,c),original=c.node.convertToWorldSpaceAR.bind(c.node);let changed=false;
 c.node.convertToWorldSpaceAR=p=>{if(!changed){changed=true;component.cardInfo={type:1,color:2};}return original(p);};assert.equal(f.overlay.tick().shown,0);
});
test('actual shifted atlas coordinates recognize bases and backs',()=>{
 const f=setup(),a=f.card({x:-250}),b=f.card({x:250,face:false});
 for(const c of [a,b])c.base.getComponent(f.cc.Sprite).spriteFrame=f.frame(BASE_NAME,[1111,212,216,286]);
 b.back.getComponent(f.cc.Sprite).spriteFrame=f.frame('',[1559,208,224,295]);assert.deepEqual(counts(f.overlay.tick()),[1,1,0,1,0,0]);
});
test('wrong base names dimensions and hierarchies do not match',()=>{
 for(const mode of ['name','size','structure']){const f=setup(),c=f.card();c.base.getComponent(f.cc.Sprite).spriteFrame=f.frame(mode==='name'?'unrelated':BASE_NAME,[1111,212,mode==='size'?217:216,286]);if(mode==='structure')c.node.addChild(new f.cc.Node('extra'));assert.equal(f.overlay.tick().shown,0);}
});
test('unloaded or disagreeing current frames remove color markers',()=>{
 const f=setup(),c=f.card();f.overlay.tick();c.symbol.getComponent(f.cc.Sprite).spriteFrame.getTexture=()=>({loaded:false});assert.equal(f.overlay.tick().shown,0);assert.equal(f.hints().length,0);
});
test('known and unknown cards have independent counts and reusable graphics',()=>{
 const f=setup();f.card({x:-250});f.card({x:250,face:false});assert.deepEqual(counts(f.overlay.tick()),[1,1,0,1,0,0]);
 const nodes=f.created.slice(),clears=f.hints().map(n=>n.getComponent(f.cc.Graphics).clears);for(let i=0;i<5;i++)f.advance(40);assert.deepEqual(f.created,nodes);assert.deepEqual(f.hints().map(n=>n.getComponent(f.cc.Graphics).clears),clears);
});
test('eighteen CSS-pixel markers follow translation without modifying originals',()=>{
 const f=setup(),c=f.card();f.overlay.tick();const h=f.hints()[0],x=h.x,y=h.y,g=graphic(f);assert.ok(g.commands.some(c=>c[0]==='circle'&&Math.abs(c[3]/(1500/390)-9)<1e-8));
 c.node.x+=100;c.node.y+=50;f.advance(40);assert.equal(f.hints()[0],h);assert.ok(Math.abs(h.x-x-100)<1e-8);assert.ok(Math.abs(h.y-y-50)<1e-8);assert.equal(c.node.children.length,4);
});
test('rotated card leader remains attached to its transformed top edge',()=>{
 const f=setup({viewportWidth:414}),c=f.card({x:80,y:-600});c.node.angle=17;assert.equal(f.overlay.tick().shown,1);const h=f.hints()[0],g=graphic(f),end={x:h.x+g.commands[1][1],y:h.y+g.commands[1][2]};
 const p=c.node.convertToNodeSpaceAR(f.layer().convertToWorldSpaceAR(end));assert.ok(Math.abs(p.y-147.5)<1e-8);assert.ok(p.x>=-112&&p.x<=112);assert.equal(intersects(hintBounds(f,h),cardBounds(f,c)),false);
});
test('nearby dots never overlap other dots or original cards',()=>{
 const f=setup(),cards=[f.card({x:0}),f.card({x:50})];assert.equal(f.overlay.tick().shown,2);const boxes=f.hints().map(h=>hintBounds(f,h));assert.equal(intersects(boxes[0],boxes[1]),false);for(const b of boxes)for(const c of cards)assert.equal(intersects(b,cardBounds(f,c)),false);
});
test('crowded and offscreen placements are omitted and counted without node churn',()=>{
 const f=setup();for(let i=0;i<12;i++)f.card({x:i*8});let r=f.overlay.tick();assert.ok(r.shown>0&&r.shown<12);assert.equal(r.shown+r.unavailable,12);const nodes=f.created.slice();f.advance(40);assert.deepEqual(f.created,nodes);
 const off=setup();off.card({x:3000,y:0});assert.equal(off.overlay.tick().unavailable,1);assert.equal(off.hints().length,0);
});
test('topmost back occludes an older discard front',()=>{
 const f=setup();f.card({y:0});f.card({y:0,face:false});assert.deepEqual(counts(f.overlay.tick()),[0,1,1,1,0,0]);
});
test('z order and latest sibling determine discard occlusion',()=>{
 for(const high of [false,true]){const f=setup(),a=f.card({y:0}),b=f.card({y:0});currentArt(f,b,'card_bg_blue','num3_blue');if(high)a.node.zIndex=5;const r=f.overlay.tick();assert.equal(r.shown,1);assert.equal(r.unavailable,1);assert.equal(graphic(f).fillColor.b,high?148:255);}
});
test('viewport edge keeps markers on screen',()=>{
 const f=setup({viewportWidth:414});f.card({x:650,y:1170});assert.equal(f.overlay.tick().shown,1);const b=hintBounds(f,f.hints()[0]);assert.ok(b.left>=-750&&b.right<=750&&b.bottom>=-1333&&b.top<=1333);
});
test('lease expiry removes known and unknown markers',()=>{
 const f=setup();f.card({x:-250});f.card({x:250,face:false});f.overlay.tick();const old=f.layer();f.advance(601);assert.equal(old.isValid,false);assert.equal(f.layer(),undefined);assert.equal(f.scheduled.size,0);
});
test('native heartbeat renews lease and clear is restartable and idempotent',()=>{
 const f=setup();f.card();f.overlay.tick();f.advance(400);f.overlay.tick();f.advance(400);assert.equal(f.hints().length,1);f.overlay.clear();f.overlay.clear();assert.equal(f.scheduled.size,0);assert.equal(f.overlay.tick().shown,1);
});
test('document hiding replacement scene changes and engine mismatch clear overlays',()=>{
 for(const mode of ['hidden','document','scene','engine']){const f=setup();f.card();f.overlay.tick();const old=f.layer();if(mode==='hidden')f.doc.hidden=true;if(mode==='document')f.context.document={...f.doc};if(mode==='scene')f.newScene();if(mode==='engine')f.cc.ENGINE_VERSION='2.4.4';f.advance(40);assert.equal(old.isValid,false);assert.equal(f.scheduled.size,0);}
});
test('camera group and canvas transforms are inherited',()=>{
 const f=setup();Object.assign(f.initial.canvas,{group:'UI',x:137,y:49,scaleX:.9,scaleY:.9});f.card();assert.equal(f.overlay.tick().shown,1);assert.equal(f.layer().group,'UI');assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>n.group==='UI'));
});
test('no network namespace writes gameplay dispatch catalogue or other SDK reads',()=>{
 assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);assert.doesNotMatch(source,/\.emit\s*\(|\.on\s*\(|assetManager|__require|window\.[A-Za-z_$]+\s*=/);
 const f=setup(),c=f.card(),keys=Object.keys(f.win);const other=new f.cc.Node('SDKtools unrelated');f.initial.canvas.addChild(other);Object.defineProperty(other,'children',{get(){throw Error('unrelated SDK');}});assert.equal(f.overlay.tick().shown,1);assert.deepEqual(Object.keys(f.win),keys);assert.equal(f.overlay.owns(c.node),false);assert.equal(f.overlay.owns(f.layer()),true);
});
test('bounded scene scans and malformed layouts fail closed',()=>{
 const f=setup();f.card();f.overlay.tick();for(let i=0;i<513;i++)f.initial.canvas.addChild(new f.cc.Node('unrelated'));assert.equal(f.overlay.tick().status,'error');assert.equal(f.layer(),undefined);
 const empty=setup();assert.equal(empty.overlay.tick().reason,'no_verified_cards');
});

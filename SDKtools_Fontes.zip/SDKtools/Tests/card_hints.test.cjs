const test=require('node:test');
const assert=require('node:assert/strict');
const {setup,plain,attachCard,currentArt,graphic,counts,hintBounds,intersects,cardBounds,source,BASE_NAME,ALT_BACK_NAME}=require('./card_hints_fixture.cjs');
test('visible color uses graphics only and leaves source artwork untouched',()=>{
 const f=setup(),c=f.card(),before=c.node.children.slice();assert.equal(f.overlay.tick().shown,1);
 assert.equal(f.hints()[0].children.length,0);assert.deepEqual(c.node.children,before);
 assert.deepEqual(plain(graphic(f).fillColor),{r:230,g:93,b:148,a:255});assert.ok(graphic(f).commands.some(c=>c[0]==='circle'));
});
test('all four semantic colors and color-blind marks follow source palette',()=>{
 const palette=[[230,93,148],[17,135,255],[254,200,100],[175,226,77]],names=['red','blue','yellow','green'];
 names.forEach((name,i)=>{const f=setup(),c=f.card();attachCard(f,c,{type:1,color:i+1});currentArt(f,c,'card_bg_'+name,'num9_'+name);
 assert.equal(f.overlay.tick().shown,1);assert.deepEqual(plain(graphic(f).fillColor),{r:palette[i][0],g:palette[i][1],b:palette[i][2],a:255});
 assert.equal(graphic(f).commands.filter(c=>c[0]==='L').length,i+2);});
});
test('color reading does not require a number or decode card IDs',()=>{
 for(const num of [undefined,NaN,0,99]){const f=setup(),c=f.card();attachCard(f,c,{id:99999999,type:1,color:1,num});currentArt(f,c);assert.equal(f.overlay.tick().shown,1);}
});
test('both back styles draw unknown rings without reading inactive artwork',()=>{
 const f=setup();for(const alternateBack of [false,true]){const c=f.card({x:alternateBack?250:-250,face:false,alternateBack});Object.defineProperty(c.front,'children',{get(){throw Error('inactive art');}});}
 assert.deepEqual(counts(f.overlay.tick()),[0,2,0,2,0,0]);assert.equal(f.hints().length,2);
});
test('Back with retained color remains unknown and is counted only as a candidate',()=>{
 for(const face of [false,true]){const f=setup(),c=f.card({face});attachCard(f,c,{type:0,color:2,num:9});Object.defineProperty(c.front,'children',{get(){throw Error('stale');}});
 assert.deepEqual(counts(f.overlay.tick()),[0,1,0,1,0,1]);}
});
test('hidden non-Back component does not establish a fresh store binding',()=>{
 const f=setup(),c=f.card({face:false});attachCard(f,c);currentArt(f,c);assert.deepEqual(counts(f.overlay.tick()),[0,1,0,1,0,1]);assert.equal(c.front.active,false);
});
test('specials are multicolor even if the active table color has a value',()=>{
 for(const [type,symbol] of [[4,'change_color'],[6,'inc4'],[10,'throw_pot']]){const f=setup(),c=f.card();attachCard(f,c,{type,color:4});currentArt(f,c,'card_bg_special',symbol);assert.deepEqual(counts(f.overlay.tick()),[1,0,0,0,1,0]);assert.equal(graphic(f).commands.filter(c=>c[0]==='fill').length,5);}
});
test('absent component uses only agreeing known visible frame colors',()=>{
 for(const [bg,symbol] of [['card_bg_red','num3_blue'],['unrelated','num3_red'],['card_bg_red','unknown_red'],['card_bg_special','num3_red']]){
 const f=setup(),c=f.card();currentArt(f,c,bg,symbol);assert.equal(f.overlay.tick().shown,0);}
});
test('present malformed semantics never fall back to stale artwork',()=>{
 for(const info of [null,{}, {type:'1',color:1},{type:11,color:1},{type:1,color:0},{type:1,color:5},{type:1,color:NaN}]){const f=setup(),c=f.card();attachCard(f,c,info);assert.equal(f.overlay.tick().unavailable,1);}
});
test('game accessors are not executed for semantic fields',()=>{
 for(const key of ['cardInfo','type','color','bgSprite']){const f=setup(),c=f.card(),component=attachCard(f,c);let calls=0;
 Object.defineProperty(['type','color'].includes(key)?component.cardInfo:component,key,{get(){calls++;throw Error('getter');}});assert.equal(f.overlay.tick().shown,0);assert.equal(calls,0);}
});
test('cross-card structural references are rejected',()=>{
 const f=setup(),a=f.card({x:-250}),b=f.card({x:250}),component=attachCard(f,a);component.bgSprite=b.color.getComponent(f.cc.Sprite);
 assert.equal(f.overlay.tick().unavailable,1);assert.equal(f.overlay.tick().shown,1);
});
test('asynchronous color loads stay suppressed until state and both frames agree',()=>{
 const f=setup(),c=f.card(),component=attachCard(f,c);assert.equal(f.overlay.tick().shown,1);const old=f.hints()[0];
 component.cardInfo={type:1,color:2};assert.equal(f.overlay.tick().shown,0);assert.equal(old.isValid,false);
 currentArt(f,c,'card_bg_blue','num3_red');assert.equal(f.overlay.tick().shown,0);
 currentArt(f,c,'card_bg_blue','num7_blue');assert.equal(f.overlay.tick().shown,1);
});
test('same-color type/number changes do not require an exact face identity',()=>{
 const f=setup(),c=f.card();attachCard(f,c,{type:2,color:1,num:999});assert.equal(f.overlay.tick().shown,1);
});
test('node reuse never retains previous color through Back or object replacement',()=>{
 const f=setup(),c=f.card(),comp=attachCard(f,c,{id:7,type:1,color:1});f.overlay.tick();const hint=f.hints()[0];
 comp.cardInfo={id:99,type:0,color:1};c.front.active=false;c.back.active=true;f.advance(40);assert.equal(f.hints()[0],hint);assert.equal(f.overlay.tick().shown,0);assert.equal(f.overlay.tick().unknownShown,1);
 comp.cardInfo={id:99,type:1,color:4};c.front.active=true;c.back.active=false;assert.equal(f.overlay.tick().shown,0);
 currentArt(f,c,'card_bg_green','num8_green');assert.equal(f.overlay.tick().shown,1);assert.deepEqual(plain(graphic(f).fillColor),{r:175,g:226,b:77,a:255});
});
test('state changes during geometry computation cannot publish stale color',()=>{
 const f=setup(),c=f.card(),component=attachCard(f,c),original=c.node.convertToWorldSpaceAR.bind(c.node);let changed=false;
 c.node.convertToWorldSpaceAR=p=>{if(!changed){changed=true;component.cardInfo={type:1,color:2};}return original(p);};assert.equal(f.overlay.tick().shown,0);
});
test('actual shifted atlas coordinates recognize bases and backs',()=>{
 const f=setup(),a=f.card({x:-250}),b=f.card({x:250,face:false});
 for(const c of [a,b])c.base.getComponent(f.cc.Sprite).spriteFrame=f.frame(BASE_NAME,[1111,212,216,286]);
 b.back.getComponent(f.cc.Sprite).spriteFrame=f.frame('',[1559,208,224,295]);assert.deepEqual(counts(f.overlay.tick()),[1,1,0,1,0,0]);
});
test('wrong base names dimensions and hierarchies do not match',()=>{
 for(const mode of ['name','size','structure']){const f=setup(),c=f.card();c.base.getComponent(f.cc.Sprite).spriteFrame=f.frame(mode==='name'?'unrelated':BASE_NAME,[1111,212,mode==='size'?217:216,286]);if(mode==='structure')c.node.addChild(new f.cc.Node('extra'));assert.equal(f.overlay.tick().shown,0);}
});
test('unloaded or disagreeing current frames remove color markers',()=>{
 const f=setup(),c=f.card();f.overlay.tick();c.symbol.getComponent(f.cc.Sprite).spriteFrame.getTexture=()=>({loaded:false});assert.equal(f.overlay.tick().shown,0);assert.equal(f.hints().length,0);
});
test('known and unknown cards have independent counts and reusable graphics',()=>{
 const f=setup();f.card({x:-250});f.card({x:250,face:false});assert.deepEqual(counts(f.overlay.tick()),[1,1,0,1,0,0]);
 const nodes=f.created.slice(),clears=f.hints().map(n=>n.getComponent(f.cc.Graphics).clears);for(let i=0;i<5;i++)f.advance(40);assert.deepEqual(f.created,nodes);assert.deepEqual(f.hints().map(n=>n.getComponent(f.cc.Graphics).clears),clears);
});
test('detached or destroyed color markers recover on the next unchanged observation',()=>{
 for(const damage of ['detach','destroy','component']){
  const f=setup(),card=f.card();f.overlay.tick();const old=f.hints()[0];
  if(damage==='detach')old.removeFromParent();else if(damage==='destroy')old.destroy();else old.getComponent(f.cc.Graphics).isValid=false;
  assert.equal(f.overlay.tick().shown,1);assert.equal(f.hints().length,1,damage);
  assert.notEqual(f.hints()[0],old,damage);assert.equal(old.isValid,false);
  assert.equal(f.hints()[0].parent,f.layer());assert.ok(graphic(f).commands.length);assert.ok(card.node.isValid);f.overlay.clear();
 }
});
test('eighteen CSS-pixel markers follow translation without modifying originals',()=>{
 const f=setup(),c=f.card();f.overlay.tick();const h=f.hints()[0],x=h.x,y=h.y,g=graphic(f);assert.ok(g.commands.some(c=>c[0]==='circle'&&Math.abs(c[3]/(1500/390)-9)<1e-8));
 c.node.x+=100;c.node.y+=50;f.advance(40);assert.equal(f.hints()[0],h);assert.ok(Math.abs(h.x-x-100)<1e-8);assert.ok(Math.abs(h.y-y-50)<1e-8);assert.equal(c.node.children.length,4);
});
test('rotated card leader remains attached to its transformed top edge',()=>{
 const f=setup({viewportWidth:414}),c=f.card({x:80,y:-600});c.node.angle=17;assert.equal(f.overlay.tick().shown,1);const h=f.hints()[0],g=graphic(f),end={x:h.x+g.commands[1][1],y:h.y+g.commands[1][2]};
 const p=c.node.convertToNodeSpaceAR(f.layer().convertToWorldSpaceAR(end));assert.ok(Math.abs(p.y-147.5)<1e-8);assert.ok(p.x>=-112&&p.x<=112);assert.equal(intersects(hintBounds(f,h),cardBounds(f,c)),false);
});
test('nearby dots never overlap other dots or original cards',()=>{
 const f=setup(),cards=[f.card({x:0}),f.card({x:50})];assert.equal(f.overlay.tick().shown,2);const boxes=f.hints().map(h=>hintBounds(f,h));assert.equal(intersects(boxes[0],boxes[1]),false);for(const b of boxes)for(const c of cards)assert.equal(intersects(b,cardBounds(f,c)),false);
});
test('crowded and offscreen placements are omitted and counted without node churn',()=>{
 const f=setup();for(let i=0;i<12;i++)f.card({x:i*8});let r=f.overlay.tick();assert.ok(r.shown>0&&r.shown<12);assert.equal(r.shown+r.unavailable,12);const nodes=f.created.slice();f.advance(40);assert.deepEqual(f.created,nodes);
 const off=setup();off.card({x:3000,y:0});assert.equal(off.overlay.tick().unavailable,1);assert.equal(off.hints().length,0);
});
test('topmost back occludes an older discard front',()=>{
 const f=setup();f.card({y:0});f.card({y:0,face:false});assert.deepEqual(counts(f.overlay.tick()),[0,1,1,1,0,0]);
});
test('z order and latest sibling determine discard occlusion',()=>{
 for(const high of [false,true]){const f=setup(),a=f.card({y:0}),b=f.card({y:0});currentArt(f,b,'card_bg_blue','num3_blue');if(high)a.node.zIndex=5;const r=f.overlay.tick();assert.equal(r.shown,1);assert.equal(r.unavailable,1);assert.equal(graphic(f).fillColor.b,high?148:255);}
});
test('viewport edge keeps markers on screen',()=>{
 const f=setup({viewportWidth:414});f.card({x:650,y:1170});assert.equal(f.overlay.tick().shown,1);const b=hintBounds(f,f.hints()[0]);assert.ok(b.left>=-750&&b.right<=750&&b.bottom>=-1333&&b.top<=1333);
});
test('lease expiry removes known and unknown markers',()=>{
 const f=setup();f.card({x:-250});f.card({x:250,face:false});f.overlay.tick();const old=f.layer();f.advance(601);assert.equal(old.isValid,false);assert.equal(f.layer(),undefined);assert.equal(f.scheduled.size,0);
});
test('native heartbeat renews lease and clear is restartable and idempotent',()=>{
 const f=setup();f.card();f.overlay.tick();f.advance(400);f.overlay.tick();f.advance(400);assert.equal(f.hints().length,1);f.overlay.clear();f.overlay.clear();assert.equal(f.scheduled.size,0);assert.equal(f.overlay.tick().shown,1);
});
test('document hiding replacement scene changes and engine mismatch clear overlays',()=>{
 for(const mode of ['hidden','document','scene','engine']){const f=setup();f.card();f.overlay.tick();const old=f.layer();if(mode==='hidden')f.doc.hidden=true;if(mode==='document')f.context.document={...f.doc};if(mode==='scene')f.newScene();if(mode==='engine')f.cc.ENGINE_VERSION='2.4.4';f.advance(40);assert.equal(old.isValid,false);assert.equal(f.scheduled.size,0);}
});
test('camera group and canvas transforms are inherited',()=>{
 const f=setup();Object.assign(f.initial.canvas,{group:'UI',x:137,y:49,scaleX:.9,scaleY:.9});f.card();assert.equal(f.overlay.tick().shown,1);assert.equal(f.layer().group,'UI');assert.ok(f.created.filter(n=>f.overlay.owns(n)).every(n=>n.group==='UI'));
});
test('no network namespace writes gameplay dispatch catalogue or other SDK reads',()=>{
 assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|eval|setInterval|setTimeout|loadRemote)\s*\(/);assert.doesNotMatch(source,/\.emit\s*\(|\.on\s*\(|assetManager|__require|window\.[A-Za-z_$]+\s*=/);
 const f=setup(),c=f.card(),keys=Object.keys(f.win);const other=new f.cc.Node('SDKtools unrelated');f.initial.canvas.addChild(other);Object.defineProperty(other,'children',{get(){throw Error('unrelated SDK');}});assert.equal(f.overlay.tick().shown,1);assert.deepEqual(Object.keys(f.win),keys);assert.equal(f.overlay.owns(c.node),false);assert.equal(f.overlay.owns(f.layer()),true);
});
test('bounded scene scans and malformed layouts fail closed',()=>{
 const f=setup();f.card();f.overlay.tick();for(let i=0;i<513;i++)f.initial.canvas.addChild(new f.cc.Node('unrelated'));assert.equal(f.overlay.tick().status,'error');assert.equal(f.layer(),undefined);
 const empty=setup();assert.equal(empty.overlay.tick().reason,'no_verified_cards');
});

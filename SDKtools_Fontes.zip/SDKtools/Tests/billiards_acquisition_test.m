#import "../Sources/SDKtools/STBilliardsLiveSnapshot.h"
#include <stdio.h>
static NSUInteger checks,failures;
static void Check(BOOL ok,NSString *why){checks++;if(!ok){failures++;fprintf(stderr,"FAIL %s\n",why.UTF8String);}}
int main(void){@autoreleasepool{
    NSMutableDictionary *point=[@{@"tag":@1,@"number":@0,@"world":@{@"x":@1,@"y":@0,@"z":@2}} mutableCopy];
    NSMutableDictionary *acq=[@{@"schemaVersion":@1,@"frameFound":@YES,@"positions":@[point],@"private":@"SECRET"} mutableCopy];
    NSMutableDictionary *raw=[@{@"format":@"SDKtools.BilliardsLive",@"schemaVersion":@1,@"status":@"not_ready",@"reason":@"not_local_turn",@"acquisition":acq,@"segments":@[@{}]} mutableCopy];
    NSDictionary *safe=STBilliardsSanitizeSnapshot(raw,NULL);
    Check([safe[@"acquisition"][@"positionCount"] isEqual:@1],@"position survives non-drawable report");
    Check(![safe[@"prediction"][@"available"] boolValue] && [safe[@"segments"] count]==0,@"diagnostic cannot authorize rendering");
    Check(!safe[@"acquisition"][@"private"],@"unknown field omitted");
    acq[@"positions"]=@[point,point];Check(!STBilliardsSanitizeSnapshot(raw,NULL)[@"acquisition"],@"duplicate identity invalidates diagnostic");
    acq[@"positions"]=@[point];point[@"world"]=@{@"x":@(NAN),@"y":@0,@"z":@2};Check(!STBilliardsSanitizeSnapshot(raw,NULL)[@"acquisition"],@"nonfinite position rejected");
    point[@"world"]=@{@"x":@1,@"y":@0,@"z":@2};acq[@"frameFound"]=@NO;
    Check(!STBilliardsSanitizeSnapshot(raw,NULL)[@"acquisition"],@"positions without frame rejected");
    acq[@"positions"]=@[];Check([STBilliardsSanitizeSnapshot(raw,NULL)[@"acquisition"][@"positionCount"] isEqual:@0],@"frame absence recorded explicitly");
    printf("Billiards acquisition: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);return failures?1:0;
}}

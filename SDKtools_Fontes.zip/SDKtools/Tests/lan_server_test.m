// Executes the production parser, auth, sequence and nonblocking TCP server.
// Loopback and synthetic callbacks only; never connects to a game server.
#import "../Sources/SDKtools/STLANServer.m"
#include <assert.h>
#include <stdio.h>
static NSUInteger checks=0;
#define CHECK(...) do{checks++;assert((__VA_ARGS__));}while(0)
static NSDictionary *Exchange(STLANServer *server, NSString *method, NSString *path, NSDictionary *extra, id body) {
    NSURL *url=[NSURL URLWithString:server.URLString];NSData *payload=body?[NSJSONSerialization dataWithJSONObject:body options:0 error:NULL]:NSData.data;
    NSMutableString *head=[NSMutableString stringWithFormat:@"%@ %@ HTTP/1.1\r\nHost: %@:%@\r\n",method,path,url.host,url.port];
    NSMutableDictionary *headers=[@{@"Origin":server.URLString} mutableCopy];if(body){headers[@"Content-Length"]=@(payload.length).stringValue;headers[@"Content-Type"]=@"application/json";}[headers addEntriesFromDictionary:extra ?: @{}];
    for(NSString *key in headers)[head appendFormat:@"%@: %@\r\n",key,headers[key]];[head appendString:@"\r\n"];
    NSMutableData *request=[[head dataUsingEncoding:NSUTF8StringEncoding] mutableCopy];[request appendData:payload];
    dispatch_semaphore_t done=dispatch_semaphore_create(0);__block NSData *reply=nil;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{@autoreleasepool{
        int fd=socket(AF_INET,SOCK_STREAM,0);int yes=1;setsockopt(fd,SOL_SOCKET,SO_NOSIGPIPE,&yes,sizeof(yes));struct timeval timeout={3,0};setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
        struct sockaddr_in a={0};a.sin_len=sizeof(a);a.sin_family=AF_INET;a.sin_port=htons(url.port.unsignedShortValue);inet_pton(AF_INET,url.host.UTF8String,&a.sin_addr);
        if(connect(fd,(struct sockaddr *)&a,sizeof(a))==0){NSUInteger sent=0;while(sent<request.length){ssize_t n=send(fd,(const char *)request.bytes+sent,request.length-sent,0);if(n<=0)break;sent+=(NSUInteger)n;}
            shutdown(fd,SHUT_WR); // A valid request must survive TCP half-close.
            NSMutableData *data=[NSMutableData data];unsigned char bytes[4096];ssize_t n;while((n=recv(fd,bytes,sizeof(bytes),0))>0)[data appendBytes:bytes length:(NSUInteger)n];reply=[data copy];}
        close(fd);dispatch_semaphore_signal(done);
    }});
    BOOL finished=NO;NSTimeInterval deadline=STLANTime()+5;while(STLANTime()<deadline){if(dispatch_semaphore_wait(done,DISPATCH_TIME_NOW)==0){finished=YES;break;}[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:.005]];}
    CHECK(finished&&reply.length>0);NSString *raw=[[NSString alloc] initWithData:reply encoding:NSUTF8StringEncoding];CHECK(raw!=nil);
    NSArray *parts=[raw componentsSeparatedByString:@"\r\n\r\n"];CHECK(parts.count==2);NSArray *line=[[parts[0] componentsSeparatedByString:@"\r\n"].firstObject componentsSeparatedByString:@" "];
    NSDictionary *json=[NSJSONSerialization JSONObjectWithData:[parts[1] dataUsingEncoding:NSUTF8StringEncoding] options:0 error:NULL];
    return @{@"status":@([line[1] integerValue]),@"json":json ?: @{},@"raw":raw};
}
int main(void){@autoreleasepool{
    NSUInteger error=0;NSString *valid=@"GET / HTTP/1.1\r\nHost: 127.0.0.1:1234\r\n\r\n";
    CHECK(STLANParseRequest([valid dataUsingEncoding:NSASCIIStringEncoding],&error)!=nil&&error==0);
    CHECK(!STLANParseRequest([@"GET / HTTP/1.1\r\nHost:" dataUsingEncoding:NSASCIIStringEncoding],&error)&&error==0);
    for(NSString *bad in @[@"GET / HTTP/1.1\r\nHost: a\r\nHost: a\r\n\r\n",@"POST /api/control HTTP/1.1\r\nHost: a\r\nContent-Length: 0\r\nTransfer-Encoding: chunked\r\n\r\n",@"GET /../private HTTP/1.1\r\nHost: a\r\n\r\n",[valid stringByAppendingString:valid],@"GET / HTTP/1.1\r\nHost: a\r\nContent-Length: -1\r\n\r\n"]){error=0;CHECK(!STLANParseRequest([bad dataUsingEncoding:NSASCIIStringEncoding],&error)&&error>0);}
    CHECK(!STLANCommand(nil));
    for(id invalid in @[NSNull.null,@"not a dictionary",@[],@1])CHECK(!STLANCommand(invalid));
    CHECK(STLANCommand(@{@"sequence":@1,@"action":@"start"})!=nil);
    CHECK(STLANCommand(@{@"sequence":@2,@"action":@"pause"})!=nil);
    for(NSString *action in @[@"capture_start",@"capture_stop",@"report_export",@"sources_export"]){
        CHECK(STLANCommand(@{@"sequence":@1,@"action":action})!=nil);
        CHECK(!STLANCommand(@{@"sequence":@1,@"action":action,@"path":@"/private"}));
    }
    NSString *exportID=@"11111111-1111-4111-8111-111111111111";
    CHECK(STLANDownloadRequest(@{@"x-sdktools-export":exportID,@"x-sdktools-offset":@"0"})!=nil);
    CHECK(!STLANDownloadRequest(@{@"x-sdktools-export":@"../../file",@"x-sdktools-offset":@"0"}));
    for(NSString *offset in @[@"-1",@"1.5",@"67108865",@"",@"12x"])
        CHECK(!STLANDownloadRequest(@{@"x-sdktools-export":exportID,@"x-sdktools-offset":offset}));
    CHECK(!STLANCommand(@{@"sequence":@YES,@"action":@"start"}));CHECK(!STLANCommand(@{@"sequence":@1,@"action":@"eval"}));
    CHECK(!STLANCommand(@{@"sequence":@1,@"action":@"start",@"card_id":@1}));
    CHECK(STLANCommand(@{@"sequence":@1,@"action":@"preferences",@"preferences":@{@"speedLevel":@8,@"extendedPlanning":@YES,@"powersEnabled":@NO,@"xrayEnabled":@YES}})!=nil);
    CHECK(!STLANCommand(@{@"sequence":@1,@"action":@"preferences",@"preferences":@{@"speedLevel":@9,@"extendedPlanning":@YES,@"powersEnabled":@NO,@"xrayEnabled":@YES}}));
    for(id invalid in @[NSNull.null,@"not preferences",@[],@1])CHECK(!STLANCommand(@{@"sequence":@1,@"action":@"preferences",@"preferences":invalid}));
    CHECK(!STLANCommand(@{@"sequence":@1,@"action":@"preferences",@"preferences":@{@"speedLevel":@YES,@"extendedPlanning":@YES,@"powersEnabled":@NO,@"xrayEnabled":@YES}}));
    CHECK(!STLANCommand(@{@"sequence":@1,@"action":@"preferences",@"preferences":@{@"speedLevel":@5,@"extendedPlanning":@1,@"powersEnabled":@NO,@"xrayEnabled":@YES}}));
    CHECK(!STLANCommand(@{@"sequence":@1,@"action":@"preferences",@"preferences":@{@"speedLevel":@5,@"extendedPlanning":@YES,@"powersEnabled":@NO,@"xrayEnabled":@YES,@"extra":@YES}}));
    CHECK(!STLANRequestOrigin(@{@"host":@"127.0.0.1:1234",@"origin":@"https://evil.invalid"},@"127.0.0.1:1234",YES));
    CHECK(!STLANRequestOrigin(@{@"host":@"rebinding.invalid",@"origin":@"http://127.0.0.1:1234"},@"127.0.0.1:1234",YES));
    CHECK(!STLANRequestOrigin(@{@"host":@"127.0.0.1:1234"},@"127.0.0.1:1234",YES));
    STLANServer *server=[STLANServer new];__block NSUInteger commands=0,stops=0;
    NSDictionary *assets=@{@"/":[@"fixture panel" dataUsingEncoding:NSUTF8StringEncoding],@"/panel.js":NSData.data,@"/panel.css":NSData.data};
    CHECK([server startAtAddress:@"127.0.0.1" assets:assets secret:[@"a" stringByPaddingToLength:64 withString:@"a" startingAtIndex:0] state:^{return @{@"version":@1,@"fixture":@YES};} command:^NSDictionary *(NSDictionary *command){CHECK(NSThread.isMainThread);
        if([command[@"action"] isEqual:@"download"])return @{@"ok":@YES,@"data":[@"fixture-json" dataUsingEncoding:NSUTF8StringEncoding]};
        commands++;return @{@"ok":@YES,@"reason":@"fixture"};} stopped:^{stops++;} error:NULL]);
    CHECK([Exchange(server,@"GET",@"/",nil,nil)[@"status"] isEqual:@200]);
    CHECK([Exchange(server,@"GET",@"/api/state",nil,nil)[@"status"] isEqual:@401]);
    CHECK([Exchange(server,@"GET",@"/api/export",nil,nil)[@"status"] isEqual:@401]);
    NSDictionary *pair=Exchange(server,@"POST",@"/api/pair",nil,@{@"code":server.pairingCode});CHECK([pair[@"status"] isEqual:@200]);CHECK(server.paired);
    NSString *key=pair[@"json"][@"key"];CHECK(key.length==64);NSDictionary *auth=@{@"X-SDKTools-Key":key};
    NSDictionary *reading=Exchange(server,@"GET",@"/api/state",auth,nil);CHECK([reading[@"json"][@"state"][@"fixture"] boolValue]);CHECK(!reading[@"json"][@"key"]);CHECK(!reading[@"json"][@"code"]);
    CHECK([Exchange(server,@"GET",@"/api/export",auth,nil)[@"status"] isEqual:@400]);
    NSDictionary *download=Exchange(server,@"GET",@"/api/export",@{@"X-SDKTools-Key":key,@"X-SDKTools-Export":exportID,@"X-SDKTools-Offset":@"0"},nil);
    CHECK([download[@"status"] isEqual:@200]);CHECK([download[@"raw"] hasSuffix:@"fixture-json"]);CHECK(commands==0);
    CHECK([Exchange(server,@"POST",@"/api/control",auth,@{@"sequence":@1,@"action":@"start"})[@"status"] isEqual:@200]);CHECK(commands==1);
    CHECK([Exchange(server,@"POST",@"/api/control",auth,@{@"sequence":@1,@"action":@"start"})[@"status"] isEqual:@409]);CHECK(commands==1);
    NSDictionary *hostile=@{@"X-SDKTools-Key":key,@"Origin":@"http://other.invalid"};
    CHECK([Exchange(server,@"POST",@"/api/control",hostile,@{@"sequence":@2,@"action":@"start"})[@"status"] isEqual:@403]);CHECK(commands==1);
    CHECK([Exchange(server,@"POST",@"/api/control",auth,@{@"sequence":@2,@"action":@"pause"})[@"status"] isEqual:@200]);CHECK(commands==2);
    CHECK([Exchange(server,@"POST",@"/api/control",auth,@{@"sequence":@3,@"action":@"touch_card"})[@"status"] isEqual:@400]);CHECK(commands==2);
    // Idle lease expiry revokes the endpoint and invokes the main-thread stop callback.
    dispatch_sync(server.queue,^{server.lastSeen=STLANTime()-10;});
    NSTimeInterval deadline=STLANTime()+3;while(server.active&&STLANTime()<deadline)[[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:.01]];
    CHECK(!server.active&&stops==1);CHECK(server.URLString.length==0&&server.pairingCode.length==0);[server stop];CHECK(stops==1);
    dispatch_sync(server.queue,^{CHECK(server.peers.count==0&&server.secret==nil&&server.listener==nil&&server.watchdog==nil);});
    fprintf(stdout,"LAN parser/socket/auth/lease: %lu checks passed\n",(unsigned long)checks);
}return 0;}

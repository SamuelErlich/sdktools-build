"""Portable trust-boundary contracts; Apple fixtures execute the real methods."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class LicenseFeatureGates(unittest.TestCase):
    def read(self, name):
        return (ROOT / 'Sources/SDKtools' / name).read_text(encoding='utf-8')

    def test_action_bridge_keeps_revoked_observation_and_late_callbacks(self):
        source = self.read('STAutoplayBridge.inc')
        submission, callback = source.split('[webView evaluateJavaScript:wrapped completionHandler:', 1)
        self.assertTrue('STLicenseAllowsFeatures()' in submission)
        self.assertIn('allowAction || coveredAttempt || penetrateAttempt || xrayEnabled', submission)
        self.assertNotIn('STLicenseAllowsFeatures()', callback)
        self.assertIn('validateObservation && validateObservation()', callback)

    def test_revoked_serial_and_power_observation_remains_bounded(self):
        source = self.read('STAutoplayRecorder.inc')
        self.assertTrue('- (BOOL)autoplayHasPendingObservation {' in source)
        self.assertIn('original_event_dispatched', source)
        self.assertIn('self.autoplayPowersDiagnostic', source)
        self.assertIn('MAX(interval,0.1)', source)
        self.assertIn('actionAllowed && !STLicenseAllowsFeatures()', source)

    def test_billiards_revocation_preserves_the_lua_pending_latch(self):
        source = self.read('STBilliardsRuntime.m')
        self.assertTrue('- (void)licenseChanged:' in source)
        method = source.split('- (void)licenseChanged:', 1)[1].split('\n- (', 1)[0]
        self.assertIn('_automationMode=0', method)
        self.assertNotIn('executeCommand:@"stop"', method)
        self.assertNotIn('self.automationMode=', method)
        self.assertIn('executeCommand:@"suspend"', method)

    def test_recorder_revocation_does_not_discard_physical_latches(self):
        source = self.read('STRecorder.m')
        self.assertTrue('- (void)licenseChanged:' in source)
        method = source.split('- (void)licenseChanged:', 1)[1].split('\n- (', 1)[0]
        for forbidden in ('actionContextGeneration++', 'autoplaySerial++', 'returnActionSerial++',
                          'autoplayFastPending=NO', 'coveredAttemptPending=NO', 'autoplayBusy=NO',
                          'returnActionBusy=NO'):
            self.assertNotIn(forbidden, method)
        self.assertIn('stopLANSharing', method)
        self.assertIn('ensureAutoplayTimer', method)

    def test_queued_lan_commands_and_new_exports_recheck_authorization(self):
        adapter = self.read('STLANRecorder.inc')
        command = adapter.split('- (NSDictionary *)lanApplyValidatedCommand:', 1)[1]
        self.assertLess(command.index('STLicenseAllowsFeatures()'), command.index('lanDownloadChunk:'))
        self.assertIn('@[@"pause",@"capture_stop"]', command)
        source = self.read('STRecorder.m')
        for signature in ('exportCurrentGameSourcesWithCompletion:', 'exportBilliardsResourcesWithCompletion:'):
            method = source.split('- (void)' + signature, 1)[1].split('\n- (', 1)[0]
            self.assertIn('if (!STLicenseAllowsFeatures())', method)
            self.assertIn('STLicenseAllowsFeatures() &&', method)
            self.assertIn('self.licenseFeatureGeneration == licenseGeneration', method)

    def test_privileged_vm_calls_keep_identity_and_cleanup_available(self):
        method = self.read('STBilliardsLuaBridge.m').split('+ (NSDictionary *)executeCommand:', 1)[1]
        self.assertIn('@[@"identify",@"stop",@"suspend"]', method)
        self.assertLess(method.index('STLicenseAllowsFeatures()'), method.index('STLuaBridgeBusy = YES'))


if __name__ == '__main__':
    unittest.main()

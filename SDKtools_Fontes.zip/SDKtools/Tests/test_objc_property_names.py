"""Focused ARC naming regression check; this is not an Apple SDK compilation.

The V3.3 build failed on synthesized object properties named ``newGame*``.
Inspect ordinary property declarations with object ownership or ``id`` types,
including an explicit getter name. This deliberately is not an Objective-C
parser and does not validate method bodies, types, availability or linking.
"""
from pathlib import Path
import re
import unittest


_NON_CODE = re.compile(
    r'//[^\n]*|/\*[\s\S]*?\*/|@?"(?:\\[\s\S]|[^"\\])*"|'
    r"'(?:\\[\s\S]|[^'\\])*'"
)
_PROPERTY = re.compile(
    r'@property\b\s*(?:\((?P<attributes>[^)]*)\))?\s*(?P<body>[^;]+);'
)
_OWNERSHIP = re.compile(r'(?:^|,)\s*(?:strong|copy|weak|retain)\s*(?=,|$)')
_OWNED_FAMILY = re.compile(r'^_*(?:new|copy|mutableCopy|alloc|init)(?![a-z])')


def prohibited_object_getters(source):
    """Return (line, property name, effective getter) for the risky names."""
    # Keep source offsets/newlines so failures identify the actual declaration.
    code = _NON_CODE.sub(lambda m: re.sub(r'[^\n]', ' ', m.group()), source)
    findings = []
    for declaration in _PROPERTY.finditer(code):
        attributes = declaration.group('attributes') or ''
        body = declaration.group('body')
        if not (_OWNERSHIP.search(attributes) or re.search(r'\bid\b', body)):
            continue
        name_match = re.search(r'([A-Za-z_]\w*)\s*$', body)
        if not name_match:
            continue
        name = name_match.group(1)
        getter_match = re.search(r'\bgetter\s*=\s*([A-Za-z_]\w*)\b', attributes)
        getter = getter_match.group(1) if getter_match else name
        if _OWNED_FAMILY.match(getter):
            findings.append((code.count('\n', 0, declaration.start()) + 1, name, getter))
    return findings


class ObjCPropertyNamingTests(unittest.TestCase):
    def test_real_v33_properties_include_twelve_build_errors_and_readonly_getter(self):
        properties = [
            ('strong', 'UIButton *', 'newGameButton'),
            ('strong', 'UIButton *', 'newGameConfirmButton'),
            ('strong', 'UILabel *', 'newGameLabel'),
            ('strong', 'NSTimer *', 'newGameDetectionTimer'),
            ('copy', 'NSString *', 'newGameState'),
            ('copy', 'NSString *', 'newGameLastGate'),
            ('strong', 'NSNumber *', 'newGameType'),
            ('weak', 'WKWebView *', 'newGameWebView'),
            ('weak', 'UIViewController *', 'newGameController'),
            ('copy', 'NSURL *', 'newGameDocumentURL'),
            ('copy', 'NSDictionary *', 'newGameIdentity'),
            ('copy', 'NSString *', 'newGameProbeContextID'),
            ('copy, readonly', 'NSString *', 'newGameStatusText'),
        ]
        source = '\n'.join(f'@property (nonatomic, {attr}) {kind}{name};'
                           for attr, kind, name in properties)
        findings = prohibited_object_getters(source)
        self.assertEqual(len(findings), 13)
        self.assertEqual([item[1] for item in findings], [item[2] for item in properties])
        self.assertEqual(prohibited_object_getters(source.replace('newGame', 'detectedGame')), [])

    def test_family_prefixes_honor_lowercase_boundary_and_leading_underscores(self):
        unsafe = ['new', 'newGame', '_newGame', '__copyItem', 'copy',
                  'mutableCopyBuffer', 'allocThing', 'initThing']
        safe = ['newspaper', 'copying', 'mutableCopying', 'allocate', 'initialize',
                'renewGame', 'detectedGameState', 'getNewGame']
        for name in unsafe + safe:
            with self.subTest(name=name):
                found = prohibited_object_getters(f'@property (strong) NSObject *{name};')
                self.assertEqual(bool(found), name in unsafe)

    def test_ownership_attributes_are_not_mistaken_for_getter_names(self):
        for attribute in ('strong', 'copy', 'weak', 'retain'):
            with self.subTest(attribute=attribute):
                self.assertEqual(prohibited_object_getters(
                    f'@property (nonatomic, {attribute}) NSObject *safeValue;'), [])
                self.assertEqual(len(prohibited_object_getters(
                    f'@property (nonatomic, {attribute}) NSObject *newValue;')), 1)

    def test_id_and_protocol_qualified_id_are_objects_without_ownership_attribute(self):
        source = ('@property id newValue;\n'
                  '@property (nonatomic, readonly) id<NSCopying> copyValue;\n'
                  '@property (nonatomic, assign) id _allocValue;')
        self.assertEqual([x[1] for x in prohibited_object_getters(source)],
                         ['newValue', 'copyValue', '_allocValue'])

    def test_scalar_properties_and_methods_are_outside_the_object_property_check(self):
        source = ('@property (nonatomic) BOOL newGameCaptureScoped;\n'
                  '@property (nonatomic) NSTimeInterval newGameDetectionStartedAt;\n'
                  '- (void)newGameDetectionTick;\n'
                  '- (BOOL)newGameContextIsCurrent;\n'
                  '- (instancetype)init;')
        self.assertEqual(prohibited_object_getters(source), [])

    def test_effective_custom_getter_controls_the_family(self):
        source = ('@property (copy, getter=newValue) NSString *safeName;\n'
                  '@property (strong, getter = detectedValue) NSObject *newName;\n'
                  '@property (getter=copyValue, readonly) id value;')
        self.assertEqual(prohibited_object_getters(source),
                         [(1, 'safeName', 'newValue'), (3, 'value', 'copyValue')])

    def test_comments_and_string_literals_do_not_create_false_declarations(self):
        source = r'''
// @property (strong) NSObject *newComment;
/* @property (copy) NSString *copyComment; */
NSString *literal = @"@property (weak) NSObject *newString;";
const char *escaped = "quoted \" @property id allocString;";
char quote = '"';
@property (nonatomic, /* new value */ copy) NSString *safeValue;
'''
        self.assertEqual(prohibited_object_getters(source), [])

    def test_multiline_declarations_preserve_reported_line_numbers(self):
        source = ('/* an example\n@property id newIgnored;\n*/\n'
                  '@property (nonatomic,\n copy, readonly)\n NSString *newStatus;\n')
        self.assertEqual(prohibited_object_getters(source), [(4, 'newStatus', 'newStatus')])

    def test_repository_object_property_getters_avoid_owned_method_families(self):
        root = Path(__file__).resolve().parents[1] / 'Sources'
        files = sorted(p for p in root.rglob('*') if p.suffix in {'.h', '.m', '.inc'})
        self.assertTrue(files, 'source scan must not silently check an empty tree')
        findings = []
        for path in files:
            for line, name, getter in prohibited_object_getters(path.read_text()):
                findings.append(f'{path.relative_to(root)}:{line}: {name} uses getter {getter}')
        self.assertEqual(findings, [], '\n'.join(findings))


if __name__ == '__main__':
    unittest.main()

'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {setup}=require('./card_sampler_fixture.cjs');
const {plain}=require('./card_hints_fixture.cjs');
const back=id=>({id,type:0,color:0,num:0});
const blue=id=>({id,type:1,color:2,num:9});
function colors(f){const r=f.sampler.stats();assert.equal(r.handsStatus,'ready');return plain(r.handCounts[0].colors);}
function transient(f){f.Card.prototype.setup=function(info){this.cardInfo=info;info.type=0;info.color=0;info.num=0;};}

test('direct census works with no visible Card nodes and without walking the scene',()=>{
 const f=setup({cards:[blue(1),back(2)]});for(const x of f.first.nodes)x.c.node.removeFromParent();
 const r=f.sampler.tick();assert.equal(r.samplerStatus,'sampling');assert.equal(r.samplerHooks,3);assert.equal(r.handTotal,2);assert.equal(r.handKnown,1);assert.equal(r.handUnknown,1);f.sampler.clear();
});
test('setup hook copies a transient face before the original reuses and zeros its argument',()=>{
 const f=setup();transient(f);f.sampler.tick();const arg=blue(98);f.first.nodes[0].component.setup(arg);
 assert.equal(arg.color,0);assert.deepEqual(colors(f),[0,0,1,0,0]);assert.equal(f.sampler.stats().samplerHiddenKnown,1);
 assert.equal(f.sampler.stats().samplerSetups,1);assert.equal(f.store.gamers[0].cards[0].color,0);
 const binding=f.sampler.resolve(f.first.nodes[0].c.node,f.first.nodes[0].component);assert.equal(binding.color,2);assert.equal(f.sampler.valid(binding,f.first.nodes[0].c.node),true);f.sampler.clear();
});
test('sync hook captures input before normalization without requesting a new sync',()=>{
 const f=setup();f.store.sync=function(payload){this.gamers=payload.gamers;for(const g of this.gamers)for(const c of g.cards){c.type=0;c.color=0;c.num=0;}};
 f.sampler.tick();f.store.sync({gamers:[{uid:'owner-3',cards:[blue(98)]}]});
 assert.deepEqual(colors(f),[0,0,1,0,0]);assert.equal(f.sampler.stats().samplerSyncs,1);assert.equal(f.sampler.stats().samplerHiddenKnown,1);f.sampler.clear();
});
test('current model is copied directly into the menu on every manual tick',()=>{
 const f=setup();f.sampler.tick();f.store.gamers[0].cards.push(back(46));const r=f.sampler.tick();assert.equal(r.handTotal,2);assert.equal(r.handUnknown,2);assert.equal(r.samplerSamples,2);f.sampler.clear();
});
test('pending selected outside every hand does not leak into a guessed hand',()=>{
 const f=setup({selected:{id:81,type:1,color:1,num:4}});const r=f.sampler.tick();assert.equal(r.handKnown,0);assert.equal(r.samplerHiddenKnown,0);assert.equal(r.samplerRetained,0);f.sampler.clear();
});
test('selected field can disappear between native polls: event hook retains only the observed current hand',()=>{
 const f=setup();f.sampler.tick();f.store.sync({select_give_card:blue(98)});f.store.sync({select_give_card:{id:0,type:0,color:0,num:0}});
 const r=f.sampler.tick();assert.equal(r.handKnown,1);assert.equal(r.handCounts[0].selected,1);assert.equal(r.samplerSyncs,2);f.sampler.clear();
});
test('look_over_cards is observed locally, without invoking its gameplay action',()=>{
 const f=setup();f.sampler.tick();f.store.updatePushMessage({look_over_cards:[blue(98)]});assert.equal(f.sampler.tick().handKnown,1);assert.equal(f.sampler.stats().handCounts[0].selected,0);f.sampler.clear();
});
test('original this, arguments, return value and exactly-once execution are preserved',()=>{
 const f=setup();let calls=0;const answer=Promise.resolve('same');f.store.sync=function(){calls++;assert.equal(this,f.store);assert.equal(arguments[1],42);return answer;};
 f.sampler.tick();assert.equal(f.store.sync({},42),answer);assert.equal(calls,1);f.sampler.clear();
});
test('original exceptions propagate unchanged and uncommitted faces are not retained',()=>{
 const f=setup();const error=Error('original');let calls=0;f.Card.prototype.setup=function(){calls++;throw error;};f.sampler.tick();
 assert.throws(()=>f.first.nodes[0].component.setup(blue(98)),e=>e===error);assert.equal(calls,1);assert.equal(f.sampler.stats().handKnown,0);f.sampler.clear();
});
test('observer failures cannot prevent the original gameplay method',()=>{
 const f=setup();let calls=0;f.store.sync=function(){calls++;return 123;};f.sampler.tick();
 const bad=new Proxy({}, {getOwnPropertyDescriptor(){throw Error('observer');}});assert.equal(f.store.sync(bad),123);assert.equal(calls,1);assert.ok(f.sampler.stats().samplerErrors);f.sampler.clear();
});
test('clear restores exact own descriptors and inherited method lookup',()=>{
 const f=setup();const original=f.store.sync;delete f.store.sync;const proto=Object.create(Object.getPrototypeOf(f.store));proto.sync=original;Object.setPrototypeOf(f.store,proto);
 const descriptor=Object.getOwnPropertyDescriptor(f.Card.prototype,'setup');f.sampler.tick();assert.ok(Object.hasOwn(f.store,'sync'));
 f.sampler.clear();assert.equal(Object.hasOwn(f.store,'sync'),false);assert.equal(f.store.sync,original);assert.deepEqual(Object.getOwnPropertyDescriptor(f.Card.prototype,'setup'),descriptor);assert.equal(f.intervals.size,0);
});
test('failed installation rolls back every hook already installed',()=>{
 const f=setup();const sync=f.store.sync;Object.defineProperty(f.Card.prototype,'setup',{writable:false,configurable:false,value:f.Card.prototype.setup});
 const r=f.sampler.tick();assert.equal(r.samplerStatus,'error');assert.equal(r.samplerHooks,0);assert.equal(f.store.sync,sync);assert.equal(f.intervals.size,0);f.sampler.clear();
});
test('lease expiry makes wrappers inert and timer restores them',()=>{
 const f=setup();const original=f.store.sync;f.sampler.tick();f.setTime(601);f.store.sync({select_give_card:blue(98)});assert.equal(f.sampler.stats().samplerSyncs,0);
 f.fireTimers();assert.equal(f.store.sync,original);assert.equal(f.sampler.stats().samplerRetained,0);assert.equal(f.intervals.size,0);
});
test('foreign method replacement is not overwritten during cleanup',()=>{
 const f=setup();f.sampler.tick();const foreign=function(){};f.store.sync=foreign;const r=f.sampler.tick();assert.equal(r.samplerReason,'hook_replaced');assert.equal(f.store.sync,foreign);assert.equal(r.samplerHooks,0);f.sampler.clear();
});
test('round change, owner transfer, removal, scene change and socket change discard retained faces',()=>{
 const changes=[f=>{f.store.start_time++;},f=>{f.store.gamers[0].uid='new';},f=>{f.store.gamers[0].cards=[];},f=>{f.newScene();},f=>{f.socket.socket={};}];
 for(const change of changes){const f=setup();transient(f);f.sampler.tick();f.first.nodes[0].component.setup(blue(98));assert.equal(f.sampler.stats().samplerHiddenKnown,1);change(f);
  const r=f.sampler.tick();assert.equal(r.samplerHiddenKnown,0);f.sampler.clear();}
});
test('removed and reinserted IDs cannot resurrect a remembered face',()=>{
 const f=setup();transient(f);f.sampler.tick();f.first.nodes[0].component.setup(blue(98));f.store.sync({gamers:[{uid:'owner-3',cards:[]}]});f.store.sync({gamers:[{uid:'owner-3',cards:[back(98)]}]});
 assert.equal(f.sampler.tick().handKnown,0);f.sampler.clear();
});
test('conflicting faces retire a cache entry for this round',()=>{
 const f=setup();transient(f);f.sampler.tick();f.first.nodes[0].component.setup(blue(98));f.first.nodes[0].component.setup({id:98,type:1,color:4,num:2});assert.equal(f.sampler.stats().handKnown,0);f.sampler.clear();
});
test('unknown fields, duplicate IDs/owners and overlarge arrays are unavailable, not valid zeros',()=>{
 for(const change of [f=>{f.store.gamers[0].cards=[back(98),back(98)];},f=>{f.store.gamers.push({...f.store.gamers[0]});},f=>{f.store.gamers[0].cards=Array.from({length:257},(_,i)=>back(i+1));},f=>{f.store.start_time=0;}]){
  const f=setup();change(f);assert.equal(f.sampler.tick().handsStatus,undefined);f.sampler.clear();
 }
});
test('unsupported registry/engine cannot install or import unproven modules',()=>{
 for(const change of [f=>{f.cc.ENGINE_VERSION='3.0';},f=>{f.cc.js.getClassByName=()=>null;},f=>{f.modules.Card=function Wrong(){};}]){const f=setup();change(f);assert.equal(f.sampler.tick().samplerHooks,0);f.sampler.clear();}
});
test('current hand matching rejects wrong owner, incomplete UI and residual hidden artwork values',()=>{
 for(const change of [f=>{f.first.hand.uid='wrong';},f=>{f.store.gamers[0].cards.push(back(46));},f=>{f.first.nodes[0].component.cardInfo.color=4;}]){
  const f=setup();transient(f);f.sampler.tick();f.first.nodes[0].component.setup(blue(98));change(f);assert.equal(f.sampler.resolve(f.first.nodes[0].c.node,f.first.nodes[0].component),null);f.sampler.clear();
 }
});
test('bounded stats export only numeric aggregates and enums, never IDs or user data',()=>{
 const f=setup();transient(f);f.sampler.tick();f.first.nodes[0].component.setup(blue(98));const r=plain(f.sampler.stats()),text=JSON.stringify(r);
 assert.ok(!text.includes('owner-3'));assert.ok(!text.includes('"id"'));assert.ok(!text.includes('"uid"'));assert.ok(!text.includes('node'));assert.equal(r.handCounts[0].selected,0);f.sampler.clear();
});
test('instrumentation never invokes any request, sync, play or reveal on its own',()=>{
 const f=setup();for(const name of ['send','sync','play','selectColor','endLookOver'])f.socket[name]=()=>{throw Error('network action');};
 const before=JSON.stringify(f.store.gamers);for(let i=0;i<10;i++){f.setTime(i*100);assert.equal(f.sampler.tick().handTotal,1);}assert.equal(JSON.stringify(f.store.gamers),before);assert.equal(f.sampler.stats().samplerSyncs,0);f.sampler.clear();
});

test('unbound/foreign-owner setup data cannot be assigned to a current hand by ID alone',()=>{
 for(const change of [f=>{f.first.hand.uid='wrong';},f=>{f.first.nodes[0].c.node.removeFromParent();}]){
  const f=setup();transient(f);f.sampler.tick();change(f);f.first.nodes[0].component.setup(blue(98));assert.equal(f.sampler.stats().handKnown,0);f.sampler.clear();
 }
});
test('borrowed Store method never observes another receiver as the real Store',()=>{
 const f=setup();f.sampler.tick();f.store.sync.call({}, {select_give_card:blue(98)});assert.equal(f.sampler.stats().samplerSyncs,0);assert.equal(f.sampler.stats().handKnown,0);f.sampler.clear();
});
test('120 second fact age cannot be renewed by polling a hidden model',()=>{
 const f=setup();transient(f);f.sampler.tick();f.first.nodes[0].component.setup(blue(98));
 for(let t=500;t<=120000;t+=500){f.setTime(t);assert.equal(f.sampler.tick().handKnown,1);}f.setTime(120001);assert.equal(f.sampler.tick().handKnown,0);f.sampler.clear();
});

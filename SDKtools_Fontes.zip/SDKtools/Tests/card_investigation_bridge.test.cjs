'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Sources/SDKtools/STCardInvestigationBridge.inc'), 'utf8');
const template = source.match(/return \[NSString stringWithFormat:\s*@"([^"\n]+)"/)[1];
const scene = '(function(){sceneFactories++;return function(options){sceneCalls++;if(options.traceControls)throw Error("controls forbidden");return {version:2,status:"cocos2_scene_captured",sceneNodes:[]};};})()';
const cards = '(function(){cardFactories++;var i=0;return function(){cardCalls++;return {version:1,status:"ready",reason:"captured",sampleIndex:++i,cards:[]};};})()';
function fixture() { return vm.createContext({ window: {}, sceneFactories:0, cardFactories:0, sceneCalls:0, cardCalls:0 }); }
function sample(ctx, expected = '', candidate = 'doc1', cardScript = cards) {
  const values = ['__SDKtools_capture_test', expected, candidate, scene, cardScript];
  let index = 0;
  const script = template.replace(/%@/g, () => values[index++]);
  assert.equal(index, values.length);
  return vm.runInContext(script, ctx);
}
test('both read-only probes share a document but preserve independent runtime closures', () => {
  const ctx = fixture();
  const first = sample(ctx);
  assert.equal(first.contextID, 'doc1');
  assert.equal(first.cardInvestigation.sampleIndex, 1);
  const second = sample(ctx, 'doc1', 'unused-candidate');
  assert.equal(second.contextID, 'doc1');
  assert.equal(second.cardInvestigation.sampleIndex, 2);
  assert.equal(ctx.sceneFactories, 1); assert.equal(ctx.cardFactories, 1);
  const descriptor = Object.getOwnPropertyDescriptor(ctx.window, '__SDKtools_capture_test');
  assert.equal(descriptor.enumerable, false); assert.equal(descriptor.writable, false);
});
test('same-URL document reload cannot read either new scene before explicit recapture', () => {
  const ctx = fixture(); sample(ctx); ctx.window = {};
  const result = sample(ctx, 'doc1', 'doc2');
  assert.equal(result.status, 'probe_document_changed');
  assert.equal(result.contextID, 'doc1');
  assert.equal(ctx.sceneCalls, 1); assert.equal(ctx.cardCalls, 1);
  assert.equal(ctx.window.__SDKtools_capture_test, undefined);
});
test('an initial namespace accessor is neither invoked nor overwritten', () => {
  const ctx = fixture(); let calls = 0;
  Object.defineProperty(ctx.window, '__SDKtools_capture_test', { get() { calls++; return {}; } });
  assert.equal(sample(ctx).status, 'probe_namespace_conflict');
  assert.equal(calls, 0); assert.equal(ctx.sceneFactories, 0); assert.equal(ctx.cardFactories, 0);
});
test('foreign context identity stops both captures without invoking replaced runtime', () => {
  const ctx = fixture(); sample(ctx);
  Object.defineProperty(ctx.window, '__SDKtools_capture_test', {value:{owner:'__SDKtools_capture_test',contextID:'foreign',capture(){throw Error('forbidden');},cardProbe(){throw Error('forbidden');}}});
  assert.equal(sample(ctx, 'doc1').status, 'probe_document_changed');
  assert.equal(ctx.sceneCalls, 1); assert.equal(ctx.cardCalls, 1);
});
test('card read failure is bounded and does not discard valid structural evidence', () => {
  const ctx = fixture();
  const result = sample(ctx, '', 'doc1', 'function(){throw new Error("private text must not escape");}');
  assert.equal(result.status, 'cocos2_scene_captured');
  assert.equal(result.cardInvestigation.reason, 'read_error');
  assert.equal(JSON.stringify(result).includes('private'), false);
});
test('missing card resource can be reported without pretending any identities were read', () => {
  const ctx = fixture();
  const fallback = source.match(/NSString \*fallback = @"([^"\n]+)"/)[1];
  const result = sample(ctx, '', 'doc1', fallback);
  assert.equal(result.cardInvestigation.status, 'error');
  assert.equal(result.cardInvestigation.reason, 'probe_script_missing');
});

'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../Sources/SDKtools/STCardInvestigationBridge.inc'), 'utf8');
const formatBody = source.match(/return \[NSString stringWithFormat:([\s\S]*?)\n\s*namespaceKey/)[1];
const template = [...formatBody.matchAll(/@"((?:\\.|[^"\\])*)"/g)].map(match => JSON.parse('"' + match[1] + '"')).join('');
const scene = '(function(){sceneFactories++;return function(options){sceneCalls++;if(options.traceControls)throw Error("controls forbidden");return {version:2,status:"cocos2_scene_captured",sceneNodes:[]};};})()';
const cards = '(function(){cardFactories++;var i=0;return function(){cardCalls++;return {version:1,status:"ready",reason:"captured",sampleIndex:++i,cards:[]};};})';
function fixture() { return vm.createContext({ window: {}, sceneFactories:0, cardFactories:0, sceneCalls:0, cardCalls:0 }); }
function sample(ctx, expected = '', candidate = 'doc1', cardScript = cards, sceneScript = scene) {
  const values = ['__SDKtools_capture_test', expected, sceneScript, cardScript, candidate];
  let index = 0;
  const script = template.replace(/%@/g, () => values[index++]);
  assert.equal(index, values.length);
  return vm.runInContext(script, ctx);
}
test('both read-only probes share a document but preserve independent runtime closures', () => {
  const ctx = fixture();
  const first = sample(ctx);
  assert.equal(first.contextID, 'doc1');
  assert.equal(first.cardInvestigation.sampleIndex, 1);
  const second = sample(ctx, 'doc1', 'unused-candidate');
  assert.equal(second.contextID, 'doc1');
  assert.equal(second.cardInvestigation.sampleIndex, 2);
  assert.equal(ctx.sceneFactories, 1); assert.equal(ctx.cardFactories, 1);
  const descriptor = Object.getOwnPropertyDescriptor(ctx.window, '__SDKtools_capture_test');
  assert.equal(descriptor.enumerable, false); assert.equal(descriptor.writable, false);
});
test('same-URL document reload cannot read either new scene before explicit recapture', () => {
  const ctx = fixture(); sample(ctx); ctx.window = {};
  const result = sample(ctx, 'doc1', 'doc2');
  assert.equal(result.status, 'probe_document_changed');
  assert.equal(result.contextID, 'doc1');
  assert.equal(ctx.sceneCalls, 1); assert.equal(ctx.cardCalls, 1);
  assert.equal(ctx.window.__SDKtools_capture_test, undefined);
});
test('an initial namespace accessor is neither invoked nor overwritten', () => {
  const ctx = fixture(); let calls = 0;
  Object.defineProperty(ctx.window, '__SDKtools_capture_test', { get() { calls++; return {}; } });
  assert.equal(sample(ctx).status, 'probe_namespace_conflict');
  assert.equal(calls, 0); assert.equal(ctx.sceneFactories, 0); assert.equal(ctx.cardFactories, 0);
});
test('foreign context identity stops both captures without invoking replaced runtime', () => {
  const ctx = fixture(); sample(ctx);
  Object.defineProperty(ctx.window, '__SDKtools_capture_test', {value:{owner:'__SDKtools_capture_test',contextID:'foreign',capture(){throw Error('forbidden');},cardProbe(){throw Error('forbidden');}}});
  assert.equal(sample(ctx, 'doc1').status, 'probe_document_changed');
  assert.equal(ctx.sceneCalls, 1); assert.equal(ctx.cardCalls, 1);
});
test('card read failure is bounded and does not discard valid structural evidence', () => {
  const ctx = fixture();
  const result = sample(ctx, '', 'doc1', 'function(){return function(){throw new Error("private text must not escape");};}');
  assert.equal(result.status, 'cocos2_scene_captured');
  assert.equal(result.cardInvestigation.reason, 'read_error');
  assert.equal(JSON.stringify(result).includes('private'), false);
});
test('missing card resource can be reported without pretending any identities were read', () => {
  const ctx = fixture();
  const fallback = source.match(/NSString \*fallback = @"([^"\n]+)"/)[1];
  const result = sample(ctx, '', 'doc1', fallback);
  assert.equal(result.cardInvestigation.status, 'error');
  assert.equal(result.cardInvestigation.reason, 'probe_script_missing');
});

// Regression fixture uses both unmodified production resources. Card capture
// must be an object before the WebKit boundary, not just JSON.stringify-able:
// JSON.stringify silently discards functions and would hide the V3.5.1 defect.
const realScene = fs.readFileSync(path.join(__dirname, '../Resources/scene_probe.js'), 'utf8');
const realCards = fs.readFileSync(path.join(__dirname, '../Resources/card_probe.js'), 'utf8');
function realFixture() {
  let time = 0;
  class Node {
    constructor(name) { Object.assign(this, {name, x:0, y:0, width:10, height:10, scaleX:1, scaleY:1, angle:0, anchorX:.5, anchorY:.5, zIndex:0, active:true, isValid:true, opacity:255, children:[], parent:null, _components:[]}); }
    get activeInHierarchy() { return this.parent ? this.active && this.parent.activeInHierarchy : true; }
    addChild(child) { child.parent = this; this.children.push(child); }
    getComponent(Type) { return this._components.find(component => component instanceof Type) || null; }
    convertToWorldSpaceAR(point) { let x=point.x,y=point.y; for(let node=this;node;node=node.parent){x=x*node.scaleX+node.x;y=y*node.scaleY+node.y;} return {x,y}; }
  }
  class Sprite { constructor(node, frame) { this.node=node; this.spriteFrame=frame; this.enabled=true; } }
  Sprite.prototype.__classname__ = 'cc.Sprite';
  const root = new Node('Scene'), canvas = new Node('Canvas');
  Object.assign(canvas, {width:1500,height:2666}); root.addChild(canvas);
  const cc={Node,Sprite,ENGINE_VERSION:'2.4.5',director:{getScene:()=>root},Canvas:{instance:{node:canvas}},v2:(x,y)=>({x,y})};
  const texture={loaded:true};
  function frame(name, rect) { return {name,getRect:()=>({x:rect[0],y:rect[1],width:rect[2],height:rect[3]}),getTexture:()=>texture}; }
  function art(name,parent,width,height,frameValue) { const node=new Node(name);Object.assign(node,{width,height});parent.addChild(node);node._components.push(new Sprite(node,frameValue));return node; }
  const card=new Node('Card');Object.assign(card,{width:224,height:295,x:42,y:-850});canvas.addChild(card);
  const shadow=new Node('Shadow');shadow.active=false;card.addChild(shadow);
  art('Base',card,216,286,frame(String.fromCharCode(65,18,178,215,49),[909,212,216,286]));
  const front=new Node('Front');Object.assign(front,{width:224,height:295,active:false});card.addChild(front);
  art('Color',front,210,280,frame('frontColor',[1590,212,210,280]));front.addChild(new Node('Decoration'));
  art('Symbol',front,175,209,frame('frontSymbol',[1834,228,175,209]));
  art('Back',card,224,295,frame('',[1357,208,224,295]));
  const domCanvas={width:1500,height:2666,getBoundingClientRect:()=>({x:0,y:0,width:390,height:693.16})};
  const document={readyState:'complete',hidden:false,visibilityState:'visible',querySelectorAll:selector=>selector==='canvas'?[domCanvas]:[],querySelector:()=>domCanvas};
  const window={cc,CocosEngine:'2.4.5',innerWidth:390,innerHeight:693.16,devicePixelRatio:3,performance:{now:()=>time}};
  return {context:vm.createContext({window,document,performance:window.performance}),card,advance:ms=>{time+=ms;}};
}
function assertPlainSerializable(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number') { assert.ok(Number.isFinite(value)); return; }
  assert.equal(typeof value, 'object', 'WebKit result cannot contain function/undefined/symbol/bigint');
  assert.ok(!seen.has(value), 'WebKit result cannot be cyclic'); seen.add(value);
  for (const descriptor of Object.values(Object.getOwnPropertyDescriptors(value))) {
    assert.ok(Object.hasOwn(descriptor, 'value'), 'WebKit result cannot expose accessors');
    assertPlainSerializable(descriptor.value, seen);
  }
  seen.delete(value);
}
test('real scene and card resources cross the native wrapper as complete serializable data', () => {
  const f=realFixture(), result=sample(f.context,'','native-doc',realCards,realScene);
  assert.match(result.status,/^cocos2_scene_/);
  assert.equal(typeof result.cardInvestigation,'object');
  assert.equal(result.cardInvestigation.status,'ready');
  assert.equal(result.cardInvestigation.cards.length,1);
  assertPlainSerializable(result);
  const encoded=JSON.stringify(result), decoded=JSON.parse(encoded);
  assert.equal(decoded.cardInvestigation.cards.length,1);
  assert.ok(encoded.includes('"cardInvestigation"'));
});
test('real resources initialize the card factory once and retain IDs across sampling', () => {
  const f=realFixture(), a=sample(f.context,'','native-doc',realCards,realScene);
  const namespace=f.context.window.__SDKtools_capture_test, closure=namespace.cardProbe;
  f.advance(500);
  const b=sample(f.context,'native-doc','unused-id',realCards,realScene);
  assert.equal(f.context.window.__SDKtools_capture_test.cardProbe,closure);
  assert.equal(b.contextID,'native-doc');
  assert.equal(a.cardInvestigation.sampleIndex,1); assert.equal(b.cardInvestigation.sampleIndex,2);
  assert.equal(b.cardInvestigation.elapsedMs,500);
  assert.equal(b.cardInvestigation.sceneEpoch,a.cardInvestigation.sceneEpoch);
  assert.equal(b.cardInvestigation.cards[0].nodeID,a.cardInvestigation.cards[0].nodeID);
  assert.equal(b.cardInvestigation.cards[0].nodes.find(node=>node.frame).frame.frameID,a.cardInvestigation.cards[0].nodes.find(node=>node.frame).frame.frameID);
  assertPlainSerializable(b);
});
test('real resources do not read a replacement same-URL document implicitly', () => {
  const f=realFixture();sample(f.context,'','native-doc',realCards,realScene);
  f.context.window={...f.context.window};
  const result=sample(f.context,'native-doc','new-id',realCards,realScene);
  assert.equal(result.status,'probe_document_changed');
  assert.equal(f.context.window.__SDKtools_capture_test,undefined);
  assertPlainSerializable(result);
});
test('function or unsupported nested return values cannot escape the card boundary', () => {
  for(const expression of ['function(){}','{version:1,bad:function(){}}','{version:1,bad:undefined}','{version:1,bad:NaN}','{version:1,bad:1n}','[1,2]','null']) {
    const ctx=fixture(), result=sample(ctx,'','doc1','function(){return function(){return '+expression+';};}');
    assert.equal(result.cardInvestigation.reason,'read_error',expression);
    assertPlainSerializable(result);
  }
});
test('cyclic card output and accessors are rejected without invoking getters', () => {
  const ctx=fixture();ctx.getterCalls=0;
  const getter=sample(ctx,'','doc1','function(){return function(){return {version:1,get privateValue(){getterCalls++;return "secret";}};};}');
  assert.equal(getter.cardInvestigation.reason,'read_error');assert.equal(ctx.getterCalls,0);
  const cyclic=sample(fixture(),'','doc1','function(){return function(){var x={};x.self=x;return x;};}');
  assert.equal(cyclic.cardInvestigation.reason,'read_error');assertPlainSerializable(cyclic);
});
test('invalid scene values also produce a serializable result with native context intact', () => {
  const result=sample(fixture(),'','doc1',cards,'function(){return {version:2,bad:function(){}};}');
  assert.equal(result.status,'invalid_probe_result');assert.equal(result.contextID,'doc1');
  assertPlainSerializable(result);
});

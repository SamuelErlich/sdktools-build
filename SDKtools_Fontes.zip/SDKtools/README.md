# SDKtools V3.13 US: Alpaca e identificação de minigames

Fontes para WePlay US **6.6.2, build 132**, SDKtools **3.13, build 28**.
O pacote entrega fontes e um workflow de compilação. Não contém um IPA novo compilado: framework ARM64 e integração dependem de macOS/Xcode; assinatura e teste no iPhone continuam pendentes.

## O que mudou

- Menu com Crazy Alpaca: autoplay, raio X, profundidade, armazém e poderes preservados. Os 13 arquivos centrais são comparados por SHA-256 com a V3.12 recebida.
- Aba Cartas removida. A preferência antiga que selecionava essa aba é migrada para Alpaca.
- Rotinas de cores, injeção de raiz, investigação e captura de entrada de Ah, minha carta bloqueadas por política compilada. O coletor de entrada não instala hooks, timers nem observers nesta build. A mudança não depende de uma preferência do usuário.
- Fontes e testes históricos de Cartas mantidos para retomada futura. Sua presença no ZIP ou framework não significa que as funções estejam ativas.
- Em **Suporte**, identificação nativa de outro minigame e captura manual do contexto identificado. A identificação não reconhece o nome do jogo automaticamente.

## Bilhar: o que já sabemos

Os dois exports disponíveis contêm somente Alpaca (`gameID=60`, Cocos Creator 2.4.4) e Ah, minha carta (`gameID=2007`, Cocos Creator 2.4.5). Os 15 arquivos JavaScript embutidos conferem com seus hashes. Não há referência comprovada ao bilhar nem catálogo de outros IDs nesse material. Ocorrências de `pool` são objetos/memória do engine.

A análise completa está em `Analysis/V3_13-billiards-discovery.md` e `.json`. O IPA original não estava disponível nesta revisão: os dados sobre sua identidade e o carregador nativo vêm dos registros anteriores incluídos nos fontes. A ausência de bilhar nos exports não prova sua ausência no aplicativo.

O mecanismo existente lê `WPCocosGameViewController.gameType` após verificar sua assinatura ABI. Duas observações estáveis de controlador, WebView, tipo e documento habilitam a confirmação. Antes dessa confirmação, a identificação não avalia JavaScript. A captura posterior fica vinculada a esse contexto e encerra quando ele muda.

Não foi atribuído um ID de bilhar nem criado um módulo de bilhar. Se esse minigame usar outro contêiner, a identificação Cocos pode não encontrá-lo.

## Próxima coleta no aparelho

1. Gere e instale a V3.13 pelo fluxo abaixo.
2. Abra o bilhar no WePlay já instalado, caso esteja disponível na sua conta/região.
3. No menu, abra **Suporte → Identificar outro minigame**. Aguarde o carregamento e volte ao menu.
4. Quando aparecer o tipo detectado, confira se continua no bilhar e toque **Capturar jogo identificado**.
5. Jogue por 30–60 segundos. Toque **Parar diagnóstico → Exportar relatório**.
6. Envie o JSON e informe em texto o nome mostrado no jogo. Uma captura de tela do título ajuda a relacionar o tipo nativo ao nome.

Se a detecção não encontrar o jogo, não escolha outro como substituto: envie o status exibido e a imagem do minigame. Isso indica que falta examinar seu contêiner. Não há evidência, até agora, de necessidade de comprar outro IPA. O IPA base que você já possui pode ser reutilizado/reanexado para ampliar a análise estática.

O JSON usa `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.13.0`. Veja `moduleAvailability` e `newGameCapture.identity`. `gameTypeSource=observed_native_getter` identifica a origem do número; `titleConfidence=unknown` impede tratar o número como nome confirmado. As rotinas antigas de exportação dos arquivos de jogo continuam restritas aos pacotes já reconhecidos; a descoberta não amplia essa permissão automaticamente.

## Compilar e instalar

1. Coloque o novo `SDKtools_Fontes.zip` na raiz do repositório, sem extrair o ZIP interno.
2. Coloque o `compilar.yml` do mesmo pacote em `.github/workflows/compilar.yml`. Faça commit dos dois juntos.
3. Reutilize a Release `base-us-6.6.2`, com `WePlay_US_6.6.2_base.ipa`.
4. Inicie uma nova execução de **Actions → Compilar SDKtools US**, com `base_source=release` e `release_tag=base-us-6.6.2`.
5. Baixe **SDKtools-v3.13-US-IPA**, extraia e assine `WePlay_US_6.6.2_SDKtools_v3_13_unsigned.ipa` e os componentes incorporados pelo seu fluxo habitual.
6. Confira **V3.13 · Crazy Alpaca** no menu e valide Alpaca antes da nova coleta.

O workflow verifica versão, tamanho, SHA-256, caminhos e manifesto dos fontes antes de executá-los. O IPA base também precisa corresponder ao tamanho e SHA-256 registrados em `config/base_identity.json`. Um re-run de job antigo não substitui uma nova execução do commit atualizado.

## Validação e limites

`Validation/V3_13-validation.json` registra os testes executados e hashes entregues. Os manifestos anteriores são históricos. Os testes JavaScript de Cartas verificam fontes preservados e não significam reativação.

A build macOS executa testes Foundation das APIs bloqueadas, compila com o SDK iPhoneOS e verifica o framework antes da integração. Aqui não foi executada compilação Apple, assinatura, instalação nem teste real no iPhone. Não há confirmação de disponibilidade do bilhar ou de seu ID até chegar uma observação do jogo aberto.

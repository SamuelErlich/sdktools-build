# SDKtools V1

Menu de diagnóstico para o WePlay 6.12.0, build 275, com foco no caminho até Crazy Alpaca / Sheep. O framework fica em um botão discreto e arrastável. Esta primeira versão registra observações para orientar as próximas ferramentas.

## O que está implementado

- Menu UIKit escuro com detalhes laranja e vermelho, sem tomar a janela principal do app.
- Gravação iniciada pelo usuário: toques agrupáveis por ID e fase, posições, orientação, controladores e hierarquia estrutural de views.
- Snapshots periódicos de navegação, inclusive quando não há toques.
- Marcadores manuais de chegada ao Crazy Alpaca e início da partida.
- Gravação de tela opcional pelo ReplayKit, sem microfone, com prévia e compartilhamento do iOS. O áudio do app pode fazer parte do vídeo.
- Exportação local de JSON. Nenhum envio automático.
- Observação limitada da WebView do contêiner Cocos identificado: canvas e, se exposta uma versão compatível do Cocos Creator 2.x, nós ativos da cena, geometria e metadados de sprites.

O gravador não executa jogadas e não modifica o tabuleiro. Raio X, solução de cartas e autoplay ainda não estão implementados. Os dados do pacote não demonstram sequer se o modo pretendido usa pares ou trincas; a gravação precisa confirmar a regra.

## O que a análise do IPA encontrou

O nome interno Sheep está associado a alpacas em traduções e em um recurso visual. Chamadas nativas passam `gameType=60` ao caminho de Sheep. A tela inicial prepara Cocos, e o contêiner do jogo usa WKWebView. O JavaScript específico do tabuleiro não foi encontrado no IPA; há infraestrutura para carregar recursos posteriormente.

A presença de Unity no aplicativo foi examinada separadamente. Ela não identifica o motor do tabuleiro Sheep. Os achados e seus limites estão em [Analysis/WePlay-CrazyAlpaca.md](Analysis/WePlay-CrazyAlpaca.md) e [Analysis/Unity-Sheep.md](Analysis/Unity-Sheep.md).

O JSON não declara automaticamente que uma tela é Crazy Alpaca. A confirmação exige a navegação, os marcadores e o vídeo da mesma sessão. O contêiner Cocos pode hospedar outros jogos.

## Primeira captura no iPhone

1. Abra o app já instalado e chegue à tela anterior à entrada no Crazy Alpaca.
2. Toque no botão do SDKtools. Mantenha **Incluir vídeo da tela** ligado e toque em **Gravar caminho e partida**. Aceite a solicitação de gravação do iOS, se aparecer.
3. Feche o menu, navegue até Crazy Alpaca, entre numa partida e faça algumas jogadas. Os toques no próprio SDKtools ficam separados da gravação de toques do jogo.
4. Se possível, abra o menu nos momentos correspondentes e use **Cheguei ao Crazy Alpaca** e **Marcar início da partida**. São marcadores manuais; eles não acionam o jogo.
5. Toque em **Parar captura**. Salve ou compartilhe o vídeo na prévia do iOS e, depois, use **Exportar relatório JSON**. Envie os dois arquivos juntos para análise.

A captura tem limite de 180 segundos ou 300 amostras de toque. Um contato costuma gerar pelo menos `began` e `ended`; arrastos geram mais amostras. Se precisar mostrar outro trecho, exporte a sessão antes de começar a próxima.

Se o vídeo estiver indisponível, grave o JSON e faça uma gravação de tela pelo iPhone. Anote qual vídeo corresponde ao JSON. Nenhuma proteção de captura do app é removida. Caso a tela apareça vazia ou protegida, isso deverá ser informado no teste.

## Como interpretar o relatório

O formato é `SDKtools.Capture`, `schemaVersion=1`. `sessionID` identifica a sessão. O tempo dos eventos é monotônico, em milissegundos desde o início da captura. `startedAtUTC` é apenas a referência de data/hora.

`touches` contém fases e IDs, `snapshots` contém observações de UIKit, `markers` contém marcações, e `webSamples` contém o resultado da observação WebKit/Cocos. Um nó de cena ativo não prova que a carta esteja desobstruída ou clicável. O índice do nó pertence àquela amostra, não é um ID permanente de carta.

Coordenadas UIKit são pontos da janela. Canvas usa pixels de seu buffer e retângulos CSS. Nós Cocos usam unidades locais e mundiais do motor. Não misture esses espaços nem use as coordenadas como replay automático.

`frameNameTag` é um hash curto do nome público do sprite. Não é o nome da carta, uma garantia de identidade visual nem prova de par válido. `occlusionResolved=false` e `cardRulesKnown=false` preservam essa distinção.

O probe não lê textos, cookies, armazenamento local, mensagens, credenciais ou conteúdo de requisições. Versões de Cocos não suportadas, canvas em iframe e API não exposta ficam explicitamente sem leitura de cena. A confirmação visual vem do vídeo que o usuário decide compartilhar.

## Compilação

No Windows, use o GitHub Actions conforme o guia que acompanha a entrega. O ZIP de fontes e `compilar.yml` formam um par: o workflow valida SHA-256 e tamanho antes de abrir os fontes.

Em macOS com Xcode e SDK iOS:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/base.ipa --framework dist/SDKtools.framework --output dist/WePlay_6.12.0_SDKtools_v1_unsigned.ipa
```

A base precisa corresponder exatamente a `config/base_identity.json`. Use o IPA original extraído do RAR, antes de reassiná-lo. O integrador acrescenta a dependência do SDKtools no espaço validado do cabeçalho e conserva segmentos e bytes de código. Se uma precondição falhar, a integração é recusada.

O resultado do workflow é um IPA **sem assinatura**, para assinatura posterior pelo usuário. O projeto não inclui certificados, perfis, chaves, o IPA original ou recursos comerciais extraídos.

## Validação e limites

Foram feitos testes portáveis do parser, do empacotamento e do probe JavaScript, além de revisão do código. O executável real passou pelo preflight e pela verificação da folga no cabeçalho. Não houve compilação com SDK Apple nem execução do SDKtools no iPhone neste ambiente. O primeiro build do Actions e a primeira captura no aparelho são verificações pendentes.

Para executar os testes portáveis:

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/scene_probe.test.cjs
```

Referências técnicas consultadas:

- [Apple ReplayKit](https://developer.apple.com/documentation/replaykit/rpscreenrecorder)
- [Apple UIWindowScene](https://developer.apple.com/documentation/uikit/uiwindowscene)
- [Cocos Creator 2.4 Director](https://docs.cocos.com/creator/2.4/api/en/classes/Director.html)
- [Cocos Creator 2.4 Scene e Node](https://docs.cocos.com/creator/2.4/api/en/classes/Scene.html)
- [GitHub Actions runner images](https://github.com/actions/runner-images)

As APIs Cocos 2.x e 3.x não são intercambiáveis. Se a captura identificar outra versão, adapte o observador ao contrato dessa versão antes de ampliar a leitura.

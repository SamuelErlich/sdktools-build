# SDKtools V3.3.1 US

Correção de compilação para WePlay US 6.6.2 build 132, com identificação **3.3.1 / build 17**. O hotfix renomeia propriedades Objective-C que conflitam com a convenção de memória da família `new` sob ARC. Preserva a lógica da V3.3: próximo trio com análise local, Raio X compacto, captura explícita de outro jogo e controles originais de poderes e armazém.

Substitua o ZIP de fontes e o workflow pelo par deste pacote e inicie uma execução nova no Actions. Os resultados desta versão devem ser consultados no manifesto final do pacote. A compilação Apple e o comportamento no iPhone precisam ser confirmados nesta versão.

## Falha de compilação corrigida

O log enviado da V3.3 registra **12 erros de compilação**: três em `STOverlay.m` e nove em `STRecorder.m`. As propriedades de objeto com prefixo `newGame` geravam getters que o compilador interpreta como pertencentes à família Cocoa `new`. A correção troca esses nomes internos e suas referências; não muda a lógica dos recursos nem o formato público do relatório. A análise está em `Analysis/V3_3_1-build-fix.json`.

Naquela execução, Xcode **16.4 / 16F6** e SDK iPhoneOS **18.5** passaram pelos 50 testes Python, 319 testes JavaScript e testes nativos antes de falhar na compilação do framework. Esse resultado pertence à V3.3: não comprova compilação ou execução da V3.3.1. O novo pacote ainda precisa concluir o Actions e ser validado no iPhone. O log tem 89.149 bytes e SHA-256 `906448336f2a05a1f94d6ea3258747e17e9fa62fc8d920fef2d48ef00e59891e`.

## Evidência recebida da V3.2

A mensagem no print mostra que a política anterior aguardava uma rota completa. O JSON recebido contém 96 eventos recentes, todos com autoplay desligado e Raio X ligado; não permite reproduzir uma sequência de jogadas automáticas. Nesses eventos, o Raio X chegou a desenhar 32 ícones com profundidade 2, o que orientou a redução da sobreposição visual. Duas buscas atingiram o limite de cálculo, sem comprovar ausência de um trio viável. A análise e os limites estão em `Analysis/V3_3-capture.json` e `Analysis/V3_3-autoplay.json`.

## Falha investigada na V3.1

O relatório da V3.1 analisado na atualização anterior registrou três recusas `unsupported_card_rules`, sem planejamento nem jogadas enviadas. A mensagem genérica não dizia qual campo falhou; o contador zero só era atualizado ao terminar a leitura completa e não comprova ausência de cartas. As amostras não incluem os valores de `blockInfo`.

A comparação adicional com o JavaScript original identificou exigências do leitor que não correspondem às regras do jogo: estado de bloqueio obrigatório mesmo para carta sem efeito especial, identificador com exatamente três partes e dados de posição do tabuleiro exigidos também na barra e na reserva. O campo específico que provocou a falha no iPhone não ficou registrado na V3.1. As evidências e limites estão em `Analysis/V3_2-original-rules.json`.

O Raio X compartilha essa leitura: uma rejeição retirava os indicadores antes de desenhá-los. No relatório recebido, ele estava desligado e a profundidade salva era 5; portanto, a falha de desenho com o recurso ativado ainda precisa de confirmação no aparelho.

Na V3.2, cartas sem efeito especial não precisam de `lock_state`, o ID mantém eventuais partes adicionais e a leitura de posição segue a área da carta: mesa, barra ou reserva. A validação da profundidade continua obrigatória. Uma impossibilidade de executar a jogada não apaga mais os ícones quando a leitura visual está completa e validada; nesse caso, a borda de combinação fica ausente até existir rota executável. O diagnóstico diferencia o campo rejeitado por códigos fechados, sem exportar valores de IDs ou conteúdo arbitrário. O relatório mantém a última leitura em `reading`, com status, motivo, contagens e, quando aplicável, `cardRuleDetail` e `animationDetail`. O histórico conserva até 96 mudanças de estado, ações e atualizações do Raio X, incluindo ligar, desligar e mudar a profundidade mesmo sem autoplay.

## Menu

O menu principal reúne **Iniciar autoplay**, **Raio X**, **Meu armazém** e os atalhos dos poderes. Exportação, relatório e gravação ficam recolhidos em **Dados e captura**.

### Autoplay

O autoplay procura o próximo trio completo, analisando alternativas e o efeito local sobre as cartas acessíveis e a capacidade da barra. Ele deixa de exigir uma solução para toda a mesa antes da primeira ação. A sequência escolhida precisa fechar uma combinação e passar pela simulação local; não é uma escolha aleatória de cartas.

Primeiro compara trios diretos por tipo, espaço livre na barra, próximas combinações expostas e desbloqueios. Se nenhum direto for viável, procura uma sequência de desbloqueio até o primeiro trio. A busca usa fatias de até 8 ms ou 600 nós, com limite total padrão de 20 mil nós e 6 mil estados memorizados. O caminho até o primeiro trio respeita os espaços livres da barra. Se o orçamento terminar com uma sequência já comprovada, ela pode ser usada; sem trio validado, aguarda. Após completar a combinação, lê novamente e planeja o próximo trio.

Cada movimento continua usando o controle original e precisa de confirmação antes do seguinte. Mudanças no tabuleiro exigem nova leitura e validação. Não são inventadas cartas ausentes nem antecipados eventos do servidor; a análise local não comprova que toda a partida será vencida.

O intervalo desejado de leitura permanece em **100 ms**; o tempo real entre jogadas depende da animação e da confirmação do jogo. Há uma avaliação em andamento e uma ação por avaliação. Uma ação de resultado incerto continua sendo observada, sem repetição por tempo esgotado.

**Pausar**, tocar manualmente no jogo, iniciar uma captura ou colocar o app em segundo plano interrompem a automação. Toque em **Iniciar autoplay** para continuar. Usar um poder ou abrir o armazém também exige interromper as jogadas automáticas.

### Raio X

O Raio X usa as imagens das cartas já carregadas e identificadas na cena. **Camadas abaixo** permite escolher de **1 a 5**: 1 é a primeira camada coberta; valores maiores incluem as camadas até a profundidade escolhida. O padrão é 1 e a preferência fica salva. Os números indicam profundidade de cobertura, não um número presumido pelo lugar na tela.

Os ícones ficam ancorados nas cartas de origem, com até dois ícones de 24 × 27 por âncora e número de camada em fonte 12. Quando mais cartas elegíveis compartilham a mesma âncora, **+N** informa quantas ficaram omitidas pelo espaço disponível. A faixa ocupa no máximo 76 × 31 junto à borda inferior da carta; excesso e colisões são contabilizados em `hiddenByLayout`. A borda verde destaca a próxima combinação validada, incluindo cartas já na barra quando a sequência cabe. Cartas cobertas fora da profundidade selecionada não recebem uma borda solta.

O desenho usa nós próprios que não recebem toques nem alteram as cartas do jogo. Cena incompleta, movimentos e janelas sobrepostas impedem uma leitura confiável; falhas restritas ao controle da jogada não apagam os ícones quando a leitura visual e as relações de cobertura estão completas. A posição visual ainda precisa de validação no iPhone.

### Capturar Ah, minha carta

Em **Dados e captura → Capturar novo jogo**, feche o menu e abra **Ah, minha carta**. O SDKtools observa a transição por até 120 segundos e identifica o contêiner nativo com seu `gameType` real. O número não é usado para adivinhar o nome. Quando o jogo correto estiver visível, toque em **É Ah, minha carta · capturar** para confirmar e começar o relatório. Jogue por cerca de **30–60 segundos**, toque em **Parar** e depois em **Exportar relatório**. Se também quiser um vídeo, use a gravação de tela do iOS.

Essa modalidade grava somente o JSON, sem iniciar vídeo pelo interruptor de captura. Fica limitada ao controlador e à `WKWebView` identificados. Trocar de jogo ou de documento encerra o escopo. Lobby, chat e login ficam fora dessa modalidade. O relatório distingue a identificação observada da correspondência visual confirmada por você; a engine é a que o probe realmente reconhecer. Se a estrutura da cena não for suportada, o relatório informa **Cena indisponível**.

Os limites são 180 segundos, 300 amostras de toque, 720 amostras web e 32 MiB de JSON. A observação inicial consulta a cada 0,5 segundo e não identifica Crazy Alpaca como o novo jogo. Autoplay e poderes continuam restritos ao Crazy Alpaca; a nova opção coleta dados para analisar o outro jogo.

### Meu armazém e poderes

**Meu armazém** procura o slot identificado pelo próprio jogo como seu e chama o botão original uma vez. O slot precisa estar vazio, desbloqueado e com o controle habilitado. O atalho recusa donos ambíguos, slot ocupado, janela já aberta e contexto diferente. A regra de espectador permanece com o callback original. O envio do evento não comprova que a janela abriu.

Não há alteração de estoque, desbloqueio de armazém, resposta de servidor ou uso ilimitado. Os três atalhos de poderes seguem a posição original: **Esquerdo**, **Central** e **Direito**. Confira o nome e o estoque na janela do jogo antes de usar **Confirmar poder aberto**. Os efeitos e o consumo continuam sob as regras originais.

### Exportação JavaScript

A correção de Documents/Caches da V3.0 foi confirmada por um novo relatório exportado: **7 arquivos JavaScript completos, somando 5.364.812 bytes**, com metadados estáveis durante a leitura. O SHA-256 do JSON recebido é `ae2d416e6b90ca841b87fa37a86e040d4524e7c104efe83e0f05f5829c7dc593`. Esses arquivos originais foram usados para análise e não fazem parte deste pacote. Isso comprova a coleta daquela sessão, não o estado atual no aparelho.

O exportador agora recebe as pastas **Documents e Caches** fornecidas pelo sistema, localiza somente o pacote do documento atual e compara o recurso com o getter original do jogo 60. Não há busca em outros diretórios. Permanecem a rejeição de links, caminhos fora do pacote, arquivos alterados durante a leitura e documentos remotos.

A exportação lê fontes JavaScript estáticos; não executa esses arquivos nem envia os dados pela rede. O JSON descreve os bytes presentes no disco, sem afirmar que são os mesmos já executados na sessão. Os resultados da análise estática do código original ficam descritos em `Analysis/V3_1-original-rules.json`, com 31 trechos referenciados por intervalos de bytes e hashes, sem incluir os arquivos comerciais completos. Uma função cliente identificada não comprova sozinha as regras do servidor.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use o IPA original antes de assinar. O integrador exige SDKtools **3.3.1 build 17** e rejeita outra base ou versão do framework.

## Atualizar pelo Windows e GitHub

1. Extraia o pacote recebido.
2. Substitua `SDKtools_Fontes.zip` na raiz do repositório. Envie esse ZIP interno sem extrair.
3. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` do mesmo pacote. Faça commit dos dois arquivos.
4. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
5. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova.
6. Baixe **SDKtools-v3.3.1-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v3_3_1_unsigned.ipa` no GBox.
7. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V3.3.1** no menu.

ZIP e workflow formam um par verificado por tamanho e SHA-256. Se aparecer “ZIP e workflow não correspondem”, substitua ambos e inicie outra execução. O certificado fica no GBox. A opção `secret_url` usa `SDKTOOLS_BASE_IPA_URL` como link HTTPS direto para a mesma base original.

## Testar e enviar os relatórios

1. Entre no Crazy Alpaca e aguarde o tabuleiro carregar.
2. Abra **Dados e captura → Exportar código do jogo**. Salve `SDKtools-GameSources-….json` na folha de compartilhamento.
3. Se houver erro, envie a mensagem e use **Exportar relatório**, mesmo sem ter gravado uma captura. O diagnóstico inclui a pasta reconhecida e a etapa de falha, sem expor o caminho completo ou os valores da URL.
4. Para testar autoplay e Raio X, mantenha a captura do SDKtools parada. Acompanhe as primeiras jogadas e os destaques. Para filmar a automação, use a gravação de tela do iOS.
5. Se o autoplay aguardar sem jogar, exporte o relatório antes de iniciar outra captura. O histórico conserva até 96 eventos recentes.
6. Para registrar um poder ou o armazém, pause o autoplay, abra **Dados e captura**, ative o rastreamento e grave a ação manual com o estado anterior e posterior. Depois pare e exporte `SDKtools-Capture-….json`.

O exportador limita cada arquivo a 16 MiB, o conteúdo lido a 32 MiB e o JSON final a 64 MiB. Fontes ausentes, ilegíveis, alterados ou acima dos limites aparecem como coleta parcial ou falha, nunca como exportação completa.

## Formatos e limites

As capturas usam `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.3.1`. Os nomes legados `returnTrace` e `returnInspection` continuam por compatibilidade e não identificam automaticamente o poder Retornar. Fontes estáticos usam `SDKtools.GameSources`, `schemaVersion=1`.

A captura registra toques observados, estrutura UIKit e amostras Cocos. Limites: 180 segundos, 300 amostras de toque, 720 leituras WebView ou 32 MiB de JSON compacto. O alvo de 250 ms da captura manual é separado do ciclo de autoplay e não garante quatro amostras por segundo. Cenas parciais não comprovam remoção de cartas; IDs de nós e frames são locais ao contexto.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

O decoder acima é para capturas de cena. A inspeção é limitada aos componentes identificados; trechos truncados ou ambíguos são marcados. Métodos capturados não são executados para investigá-los. Os arquivos em `Analysis/` preservam achados e limitações; os manifestos de versões anteriores só validam suas próprias versões.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v3_3_1_unsigned.ipa
```

A validação local do hotfix registrou **319 testes JavaScript**, **58 testes Python aprovados** e **1 teste exclusivo de macOS não executado**, além de **161 verificações C**, sem falhas. Os testes Python incluem nove verificações da convenção de nomes que causou o erro. O build executa esses testes e os testes Foundation antes de compilar o framework. O resultado requer assinatura no GBox. Os resultados finais estão em `Validation/V3_3_1-validation.json` e `VALIDACAO_PACOTE.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
bash scripts/test_native_action_policy.sh
bash scripts/test_game_source_export.sh
bash scripts/test_new_game_capture.sh
```

Compilação Apple, testes Foundation, assinatura e execução real não foram realizadas no ambiente Linux de preparação. Os testes simulados não comprovam funcionamento perfeito, velocidade real ou alinhamento visual no aparelho.

## Dados e compatibilidade

Os fontes não incluem certificado, IPA original, vídeo, capturas privadas completas nem os sete arquivos JavaScript comerciais exportados. Os relatórios não são enviados automaticamente. A exportação lê somente fontes `.js` da raiz local verificada; não lê cookies, credenciais ou clipboard. Os próprios arquivos JavaScript podem conter literais do aplicativo.

A compatibilidade foi definida para esta base e os componentes observados em Cocos 2.4.4. Recursos carregados dinamicamente podem mudar sem alteração da versão do IPA.

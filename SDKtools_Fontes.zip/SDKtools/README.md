# SDKtools 4.0.7 / build 82 — Dois trios e velocidade experimental

Selecione **6** no menu Alpaca para enviar dois trios expostos na mesma avaliação,
somente com bandeja vazia. As seis cartas cabem antes de qualquer animação remover
um trio. Tipos iguais também são aceitos; cartas cobertas, especiais ou bloqueadas
não entram nesse lote. Sem os dois trios seguros, o fluxo anterior continua com
até três cartas, sempre revalidando os controles e esperando confirmação.

A barra inclui **Teste0,5ms** e **Super0,05ms** como intervalos solicitados de consulta.
Não garantem essas frequências reais no iPhone nem pulam ACKs/animações. O padrão
continua100ms. No painel web, “último envio” mede só observação e chamadas locais,
sem ACK/animação; é diferente da cadência solicitada e de cartas confirmadas/minuto.
Os modos menores continuam disponíveis; cadências menores podem elevar o consumo.

Menu compacto, PT/EN e correções de reserva/refresh preservados. Detalhes em
`Analysis/V4_0_7-six-card-speed.md`. Teste físico e cadência no aparelho pendentes.

## Histórico preservado — não descreve a versão atual

# SDKtools 4.0.6 / build 81 — Reserva e retomada após refresh

O Auto normal considera as cartas acima na mesma coluna da reserva, mesmo
quando o jogo deixa a máscara/controle inferior liberado. A sugestão Raio X
usa esse mesmo grafo: com seis cartas na bandeja, milho sob queijo não é uma
jogada válida; com cinco, pode retirar queijo antes de completar milho.
O espaço é simulado em cada passo, antes do primeiro trio.

Reconstruir objetos visuais na mesma partida preserva a espera pelas respostas.
Lotes aceitos só liberam a pendência após a leitura completa/coerente do efeito,
sem reenviar cartas ou inventar confirmações. No modo de uma carta, a troca do
identificador visual também não libera uma carta ainda pendente na origem.
Erros, respostas ausentes e troca real de partida/conexão continuam bloqueados.

Menu compacto e velocidades da V4.0.5 preservados. Detalhes e limites em
`Analysis/V4_0_6-refresh-recovery.md`. Teste físico pendente.

## Histórico preservado — não descreve a versão atual

# SDKtools 4.0.5 / build 80 — Menu compacto e velocidade de teste

Auto, Raio X, Plano e Poderes ficam em uma faixa de atalhos diretos.
O popup usa no máximo 264 × 340 pt; detalhes ficam na rolagem. Um único
Play/Pause flutuante tem ícone de 32 pt e área de toque de 44 pt.
A barra reúne 500/250/100/40/20 ms e os testes 10/5/2 ms. O valor é o
intervalo solicitado de consulta, sem promessa de cartas por segundo.
Ajustar a barra não inicia o Auto; as confirmações e travas continuam ativas.
O padrão permanece Normal (100 ms); os testes são selecionados explicitamente.

Planejamento e consumo de poderes continuam opções independentes. O atalho
LAN fica no rodapé; detalhes aparecem somente durante compartilhamento.
Testes internos e exportação de código ficam fora do menu do cliente;
o coletor e o painel web preservam as APIs e ferramentas de diagnóstico.
Marca, fontes, PT/EN, seleção de 1–3 cartas, quatro camadas e controles
manuais permanecem disponíveis. Bilhar ganha a mesma faixa de atalhos.

Ver `Analysis/V4_0_5-compact-controls.md`. Validação física pendente.

## Histórico preservado — não descreve a versão atual

# SDKtools 4.0.4 / build 79 — Todas as cartas no Auto

Por pedido do usuário, a restrição de diamantes foi removida. Todas as cartas
elegíveis participam dos trios, lotes de 1/2/3, poderes e ajuda pelo armazém.
A barra de carga é somente diagnóstico: ausência/falha/valor alto não
bloqueiam diamantes. Controles, mesa própria, capacidade, prova de trio e
confirmação das ações originais continuam sendo exigidos.

O planejamento busca avançar o máximo com as cartas disponíveis; não há
taxa de vitória ou percentual de conclusão medidos. Detalhes em
`Analysis/V4_0_4-all-cards.md`. Teste físico pendente.

## Histórico preservado — não descreve a versão atual

# SDKtools 4.0.3 / build 78 — Espera do Auto e aliados com mão cheia

O aviso intermediário de demora do WebKit mantém a intenção de Play
enquanto a avaliação ainda detém o bloqueio físico. Nenhuma outra jogada
é enviada até seu retorno. Retorno final incerto continua pausando;
pausa manual permanece respeitada. O estado de espera aparece em PT/EN.

Raio X dos aliados com exatamente sete cartas na mão passa a permanecer
visível. A sugestão de trio agora recebe prova visual independente também
na mesa do aliado; mudanças na mesa exigem nova prova. Auto continua
restrito ao próprio jogo, e a mão própria cheia
continua bloqueando ações. Detalhes: `Analysis/V4_0_3-table-watch.md`.
Teste físico pendente; o JSON atual do incidente ainda não foi recebido.

## Histórico preservado — não descreve a versão atual

# SDKtools 4.0.2 / build 77 — Retomada do Auto e Raio X dos aliados

Corrige o Play que ficava bloqueado após um lote aceito pelo jogo cuja
observação demorasse mais de 15 segundos. O lote permanece pendente até
revalidar seu efeito, sem repetir cartas. Respostas ausentes ou divergentes
e troca de contexto continuam bloqueando qualquer reenvio.

O Raio X reconhece a máscara original de espectador sem confundi-la com
mesa, bandeja, reserva ou popup. Outras janelas continuam suspendendo a
leitura. Aliados recebem somente visualização; Auto continua no seu jogo.
Detalhes: `Analysis/V4_0_2-resume-watch.md`. Teste físico pendente.

## Histórico preservado — não descreve a versão atual

# SDKtools 4.0.1 / build 76 — Contornos do Raio X durante o Auto

Corrige os contornos que desapareciam após limpeza/ocultação do Graphics e
nas esperas de lotes, armazém ou poderes do Auto. O próximo trio recebe prova
visual independente, com mesa estável e fase válida; as requisições do Auto
continuam aguardando suas próprias confirmações. Não há toque adicional.
Os contornos são refeitos sem recriar miniícones/contagens válidos.

Chat, HotTime, pausa e contexto inválido ainda ocultam indicações enquanto não
há leitura válida; elas são recalculadas ao retomar. Sem prova de trio não se
mostra uma borda antiga. Ver `Analysis/V4_0_1-xray-persistence.md`.
Teste físico continua pendente; a CI Apple será registrada fora deste manifesto.

## Histórico preservado — não descreve a versão atual

# SDKtools 4.0.0 / build 75 — V4 consolidada após auditoria

Esta versão reúne as correções confirmadas na revisão do menu, autoplay,
ponte WebKit, Raio X, painel do navegador, exportações e integração do IPA.
O relatório detalhado está em `Analysis/V4_0_0-audit.md`; a relação de arquivos,
os testes e os hashes estão em `Validation/V4_0_0-validation.json`.

- Menu: status do Raio X visível, status do Auto completo, contexto revalidado
  no Super Fast e ajustes de texto/acessibilidade.
- Auto: retoma a observação após confirmar um poder manualmente durante a pausa,
  verifica jogador/sala do socket e reconcilia callbacks atrasados sem travar o lote.
- Visuais: recria indicadores e contagens removidos da cena, mesmo sem mudança
  nas cartas observadas.
- Navegador: contagem correta do lote, leituras antigas removidas na desconexão,
  controles de captura coerentes e pausa ao ocultar durante um download.
- Ferramentas: erros de captura malformada tratados, metadados de versão alinhados,
  payload de hints Mach-O preservado e caminhos ZIP ambíguos recusados.

Validação local: **1.162 testes JavaScript aprovados; 178 testes Python executados,
177 aprovados e 1 ignorado por exigir Foundation/macOS**. Verificações adicionais
C/Lua e simulações estão discriminadas no relatório. Isto não substitui a
compilação Apple nem testes no iPhone, ainda pendentes nesta entrega.

Preservados: lote selecionável de 1/2/3 cartas, pausa/play flutuantes, contornos
vermelhos, lista lateral de contagens e Raio X da mesa visualizada. As requisições
continuam individuais, com confirmações próprias; o cliente original não oferece
um envio atômico de várias cartas. Não foi medido o tempo real até 50–60%.

**Diamantes:** permanece a proteção conservadora da 3.23.23: o Auto não coleta
diamantes em nenhuma porcentagem. O ganho por trio não está comprovado no código
original, portanto o limite exato de “falta um trio” continua desconhecido.
A leitura da carga é apenas observacional; ações manuais/aliados podem alterá-la.

Extração de fontes permanece exclusiva do painel no navegador. Base original:
Release `base-us-6.6.2`, WePlay US 6.6.2/build 132, arm64/iOS 15.
Use o ZIP de fontes e `compilar.yml` da V4 juntos. Saída prevista do workflow:
`WePlay_US_6.6.2_SDKtools_v4_0_0_unsigned.ipa`, ainda exigindo assinatura.

## Histórico preservado — não descreve a versão atual

# SDKtools 3.23.24 / build 74 — Captura em lote corrigida

A seleção de 2/3 cartas passa a enviar, na mesma execução JavaScript, o prefixo
atualmente disponível da rota comprovada. As cartas desse prefixo podem ter
tipos diferentes. A continuação da rota pode conter cartas ainda cobertas;
essas cartas aguardam uma nova leitura, sem impedir o lote já disponível.

Três restrições do SDK foram identificadas: `ws://` original caía no modo
individual; a rota inteira precisava estar descoberta e caber em um trio
homogêneo; e 4 ms de trabalho do primeiro callback já cortavam os seguintes.
A atualização aceita `ws://` e `wss://` do mesmo socket original e remove o
corte de 4 ms, mantendo o limite de até três callbacks originais por execução.

O limite selecionado e a quantidade enviada por um lote pendente aparecem no
status, mesmo com Super Fast desligado. Uma incompatibilidade que exige modo
individual fica explícita. Super Fast continua sendo a preferência de cadência.

Cada carta mantém sua própria requisição e confirmação. Não há endpoint atômico
de múltiplas cartas no código original. A rota inteira ainda precisa provar o
próximo trio e respeitar a capacidade; somente o prefixo exposto é enviado.
Pausas, respostas pendentes, mudanças de cena e a proteção dos diamantes da
3.23.23 continuam valendo. Se só uma carta da rota estiver disponível, a captura
segue individual até uma nova leitura permitir outro lote.

Os testes locais reproduzem as restrições anteriores e verificam envios na mesma
execução. Não medem o tempo real até 50–60% no aparelho. Compilação Apple e teste
físico permanecem pendentes. Base original: Release `base-us-6.6.2`.
Ver `Analysis/V3_23_24-batch-capture.md` e `Validation/V3_23_24-validation.json`.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.23 / build 73 — Proteção de diamantes no Auto

O Auto passa a tratar cartas `type:1` como diamantes protegidos. A restrição
vale para a mesa, a reserva, grupos de 1/2/3 cartas e a coleta automática no
armazém compartilhado. Outros tipos continuam elegíveis pelas regras originais.
Os diamantes permanecem no grafo de bloqueios: o planejador não considera que
retirá-los é permitido nem que cartas abaixo deles ficaram livres.

**Limitação explícita:** o código original informa a carga atual, mas não o ganho
por trio de diamantes. Não é possível comprovar o limite exato de “falta um trio”.
Nesta versão conservadora, o Auto não coleta diamantes em nenhuma porcentagem.
Isso também vale quando a barra está indisponível ou parece desativada. Não há
calibração automática que arrisque completar a barra para descobrir o ganho.

A leitura de `HandArea.HotTimeProgressBar` acrescenta a porcentagem observada ao
diagnóstico quando a identidade do componente e a cena são verificadas. Ganho
por trio e limite permanecem explicitamente desconhecidos. Não há novo botão
no menu mobile. Toques manuais, testes explicitamente solicitados, contagens e
o Raio X continuam independentes da proteção de seleção automática.

A proteção não impede que um aliado, uma ação manual ou outro evento do servidor
carregue o poder. Pedidos anteriores já enviados continuam sendo confirmados;
a restrição não os cancela nem autoriza reenvio.

Fontes preparadas para o IPA original da Release `base-us-6.6.2`.
Compilação Apple e teste físico continuam pendentes.
Ver `Analysis/V3_23_23-diamond-hottime-guard.md` e
`Validation/V3_23_23-validation.json`.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.22 / build 72 — Lista na lateral esquerda

A lista do Raio X passa para a **lateral esquerda, começando perto do topo**,
conforme os quadrados vermelhos da imagem enviada pelo usuário. Cada posição
mostra o ícone original com a quantidade abaixo, em uma coluna compacta.

A contagem continua incluindo mesa, reserva e bandeja da mesa visualizada,
com todas as profundidades carregadas. Não inclui o armazém compartilhado.
A lista respeita a área do jogo e os limites das cartas; não captura toques.
As versões anteriores de Pausar/Play, 1/2/3 cartas e vermelho neon estão incluídas.

Fontes preparadas para o IPA original da Release `base-us-6.6.2`.
Build Apple e conferência visual no iPhone ainda pendentes.
Ver `Analysis/V3_23_22-left-count-list.md` e
`Validation/V3_23_22-validation.json`.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.21 / build 71 — Lista lateral de cartas

Com o Raio X ligado, uma lista lateral mostra o **ícone original e a quantidade**
de cada tipo de carta presente na mesa exibida. A lista acompanha a própria
mesa ou a mesa de um aliado que estiver sendo visualizada.

O total soma mesa, reserva e bandeja, incluindo cartas cobertas de todas as
profundidades carregadas. Não inclui o armazém compartilhado, mesas de outros
jogadores fora da visualização ou cartas ainda não carregadas. Mover uma carta
para a bandeja mantém o total; remover um trio reduz a contagem daquele tipo.

A coluna usa a margem livre ao lado da mesa. Sem espaço suficiente ou com
dados incompletos, a lista é ocultada para não apresentar totais parciais.
Não captura toques e usa os ícones já existentes no jogo. A seleção 1/2/3,
Pausar/Play flutuantes e bordas vermelho neon continuam incluídos.

Fontes preparadas para o IPA original da Release `base-us-6.6.2`.
Build Apple e teste físico ainda pendentes. Ver
`Analysis/V3_23_21-card-count-sidebar.md` e
`Validation/V3_23_21-validation.json`.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.20 / build 70 — Cartas por vez

O menu do Alpaca oferece **1 / 2 / 3** em **Cartas por vez**, logo abaixo do
Auto. A opção define o máximo de cartas expostas enviadas em cada grupo.
O padrão é 1; a escolha fica salva. Selecionar uma quantidade não inicia o Auto.

Com 2 ou 3, o fluxo valida a combinação completa e envia somente até o limite
escolhido. Aguarda as confirmações e a atualização da mesa antes de prosseguir.
Pode jogar menos cartas se a combinação precisar de menos, se o jogo impedir
outro toque ou se apenas o modo serial estiver disponível. Cartas cobertas e
retiradas do armazém continuam seguindo seus próprios limites.

A quantidade é independente da velocidade: Turbo/Super Fast mudam a cadência,
e o seletor define quantas cartas podem sair por vez. Alterações durante um
envio valem para os próximos grupos; não cancelam nem repetem o grupo pendente.
Inclui o Raio X dos aliados, os controles flutuantes e as bordas vermelho neon.

Fontes preparadas para compilação com o IPA original da Release
`base-us-6.6.2`. Build Apple e teste físico ainda pendentes.
Ver `Analysis/V3_23_20-cards-per-batch.md` e
`Validation/V3_23_20-validation.json` para escopo e resultados locais.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.19 / build 69 — Destaque vermelho neon

As bordas das combinações indicadas pelo Raio X passam a vermelho neon
`#FF1830`, com contorno externo vermelho escuro para contraste.
O destaque vale para as cartas visíveis e para os ícones de cartas cobertas.

Substituir o ZIP de fontes e o workflow juntos. O novo IPA ainda precisa
ser compilado no Actions e validado no iPhone.
Ver Analysis/V3_23_19-neon-red.md e Validation/V3_23_19-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.18 / build 68 — Pausar e retomar fora do menu

Depois de ativar o Auto no Alpaca, dois botões ficam ao lado do ícone
flutuante: Pausar e Play. Eles acompanham o ícone quando ele é arrastado,
usam as cores do menu e mantêm área de toque de 44 × 44 pontos.

Os controles permanecem durante a pausa para permitir retomar sem abrir o
menu. São ocultados com o menu aberto, ao sair do Alpaca ou em segundo plano.
Play usa as verificações originais de início; pausar preserva ações pendentes.
A correção do Raio X dos aliados da 3.23.17 está incluída.

Fontes e workflow devem ser substituídos juntos. Compilação Apple e teste
físico continuam necessários. Ver Analysis/V3_23_18-floating-autoplay.md e
Validation/V3_23_18-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.17 / build 67 — Raio X dos aliados

Corrige o desaparecimento do Raio X ao assistir à mesa de um aliado.
Os ícones seguem as cartas da mesa exibida e a profundidade selecionada.
Planos e marcações de trio da própria mesa não são reutilizados no aliado.

Assistir é uma leitura visual: Auto, poderes e comandos experimentais não
são enviados nessa mesa. Pendências existentes são preservadas; ao voltar,
a própria mesa precisa estabilizar novamente antes de retomar as ações.

Fontes preparadas sobre a 3.23.16/build 66. O novo IPA ainda exige compilação
macOS/Xcode e validação no iPhone. Ver Analysis/V3_23_17-ally-xray.md e
Validation/V3_23_17-validation.json. Substituir ZIP e workflow juntos.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.16 / build 66 — Auto cooperativo

O Auto usa uma arrancada com comparação de continuação após o próximo trio.
Na fase final (75% informado pelo jogo ou poucas cartas), amplia a busca.
Quando falta uma rota, aguarda ajuda no armazém e recebe automaticamente
somente cartas de aliados que participem de um trio verificado.

O modo Máximo executa a rota escolhida quando compatível; não escolhe um trio
antes da estratégia. Cada retirada do armazém usa o touchBlock registrado do
próprio jogo, com slot/contexto revalidados e confirmação estável do efeito.
Chat, pausa e timeout preservam pendências, sem repetir a retirada.

Use o Auto normal. Planejamento ampliado continua permitindo busca mais longa
antes da fase final. Poderes mantêm a preferência anterior; nenhuma compra ou
mensagem automática foi adicionada. O diagnóstico cooperativo aparece nos JSONs.
As mensagens de espera/recebimento têm tradução PT/EN. Não há custo de tokens
por jogada. O avanço depende da partida e da ajuda; 70–80% e 100% não são garantias.

Validação física PC/iPhone pendente. Build/manifestos da CI e validação da
entrega estão fora do pacote, no contexto do projeto. Ver Analysis/V3_23_16-cooperative-auto.md.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.15 / build 65 — reserva e diagnóstico pelo navegador

Corrige o Raio X das pilhas criadas pelo poder de Armazenar: a profundidade
passa a usar a sobreposição verificada, mesmo sem máscara escura. Mantém
disponibilidade, comandos originais e limite visual de quatro camadas.

O painel LAN permite Capturar partida, Parar captura, Gerar relatório,
Extrair fontes e Baixar JSON diretamente no PC. A captura pausa Auto e Raio X;
registre a partida manualmente antes/depois de usar o poder. Os metadados
observados das cartas continuam sendo gravados. Para um problema no Auto,
gere também o relatório logo após a falha, antes de iniciar nova captura.

O download exige pareamento, usa apenas o arquivo JSON recém-exportado,
limite de 64 MiB e blocos de 256 KiB. Não aceita caminho de arquivo,
JavaScript ou comando do protocolo do jogo pelo navegador. O painel continua
restrito à rede Wi-Fi privada, com o aviso de HTTP sem criptografia existente.

Validação física PC/iPhone pendente. Compilação e testes Apple devem ocorrer
no repositório oficial usando o ZIP e workflow correspondentes.
Ver Analysis/V3_23_15-reserve-web.md e Validation/V3_23_15-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.14 / build 64 — correção da compilação LAN

Corrige os dois erros Clang confirmados no diagnóstico da 3.23.13: acesso
`value.count` sobre `id` no parser LAN. Após validar o tipo em runtime, o parser
agora usa uma referência `NSDictionary *` explícita; preferências também são
validadas antes de acessar propriedades. A whitelist, os limites, o pareamento
e as verificações de sequência/Host/Origin permanecem intactos.

Adicionados casos nativos de formatos inválidos e um contrato portátil de
tipagem. JS/Lua de gameplay, painel web, servidor TCP, fluxo Auto/Super Fast,
Bilhar e Cartas foram preservados byte a byte em relação à 3.23.13.

O log recebido confirma os testes anteriores ao erro, mas não a compilação do
framework. Esta entrega ainda exige NOVA execução macOS/iPhoneOS e teste real
PC/iPhone. Substituir juntos o ZIP e o workflow atualizados, nunca só um deles.
Ver Analysis/V3_23_14-lan-build-fix.md e Validation/V3_23_14-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.13 / build 63 — controle LAN do Alpaca

Controle opcional pelo navegador do PC, na mesma rede Wi-Fi privada. O iPhone
continua executando a partida e usando a sessão original; o navegador controla
as preferências do SDKtools e o início/pausa do Auto. Não é cliente independente
WePlay, streaming de tela nem seleção manual de cartas nesta versão.

- Painel com mesa, bandeja, reserva, cartas compartilhadas no total, tipos,
  missão disponível, jogadas confirmadas localmente e estado do Super Fast.
- Cinco níveis: Baixo 500ms, Moderado 250ms, Normal 100ms, Turbo 40ms e Máximo
  20ms/Super Fast. São cadências de avaliação, não garantias de cartas/segundo.
- Planejamento ampliado, poderes do estoque e Raio X configuráveis. Aplicar
  opções não inicia o Auto. ACKs, estabilidade e latches pendentes permanecem.
- Botão Browser control no menu Alpaca: URL HTTP local e PIN de 8 dígitos.
  Um navegador por sessão, 5 tentativas de pareamento, 2 minutos para conectar.
- Sessão pareada exige heartbeat; ~8s sem contato revogam o acesso e pausam
  Auto que tenha sido iniciado remotamente. Background/inatividade encerram LAN.

ATENÇÃO: HTTP SEM CRIPTOGRAFIA. Pareamento não é proteção contra sniffing na
rede. Usar somente Wi-Fi privado confiável; sem VPN, relay, UPnP ou portas no
roteador. O listener usa IPv4 privado do en0, porta efêmera e endereço explícito,
nunca 0.0.0.0. Não implementa IPv6-only/Bonjour. Não copia tokens do WePlay.

Controles remotos aceitos: start, pause, preferences. Sem eval, pacotes de jogo,
IDs arbitrários, cartas cobertas, estoque zero ou comandos experimentais. O
estado exportado ao painel é fechado; snapshots incompletos/velhos mostram —,
não zeros inventados. A sessão da rede tem credencial própria, em memória.

Bilhar, Cartas e os algoritmos JS de gameplay da 3.23.12 foram preservados.
Fontes e testes locais não provam compilação Apple nem funcionamento no iPhone.
Ver Analysis/V3_23_13-lan-control.md, Validation/V3_23_13-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.12 / build 62 — compatibilidade Super Fast

O relatório da 3.23.11/build 61 mostra snapshot completo, mas o coordenador
Super Fast foi recusado no preflight (`observer_unavailable`, zero eventos e
zero pedidos). Não houve recusa do servidor nesse lote. A captura não revela
qual requisito falhou; `action_disabled` é somente a última leitura exportada.

O preflight agora identifica o requisito por enumeração fechada. Não exige
`Function.length === 2`: funções com rest/default/wrapper podem ter length 0,
mas a observação continua exigindo os dois argumentos reais, pacote correlato,
Promise original e ACK confiável para confirmar a rajada.

Se transporte/API/hooks/timer não suportarem o observador, e somente quando
nenhum evento foi invocado e todos os hooks foram restaurados, segue pelo Auto
original, UMA carta por vez, aguardando seu efeito estável. O menu indica
"Super Fast: compatível, 1 por vez". A capacidade é reavaliada após 3 segundos
ou mudança de contexto; nunca se envia um trio sem observador. A confirmação
local do Auto normal NÃO é ACK do servidor nem vitória garantida.

500, timeout, pedido incerto, lote parcial, contexto perdido ou falha de
restauração NÃO autorizam esse fallback. As proteções da 3.23.11, o Raio X,
os poderes, Bilhar e Cartas foram preservados. Não há alteração de permissão,
estado do jogo, estoque ou fabricação de pacotes.

Testes locais cobrem os dois caminhos. Compilação Apple, assinatura e teste
físico da 3.23.12 permanecem pendentes. Não é garantia de três cartas simultâneas
em todo runtime nem de ausência de outros bugs no aparelho.

Ver Analysis/V3_23_12-super-fast-compatibility.md e Validation/V3_23_12-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.11 / build 61 — retomada Auto/Raio X

Corrige a confusão entre avaliação física em andamento e avaliação capaz de
jogar: uma leitura somente Raio X não desabilita mais o botão Auto nem aparece
como ação enviada. Play apenas arma intenção; não inicia outra avaliação até
terminar a leitura atual. Uma avaliação capaz de agir, timeout incerto, carta
experimental ou contexto perdido continuam com seus bloqueios preservados.

Após o primeiro bootstrap confirmado no documento, ticks nativos usam comando
curto e o runtime já vinculado, sem reenviar todos os scripts a cada 20/40/100ms.
Namespace/documento ausente ou diferente retorna falha fechada; nunca recria
silenciosamente um runtime que possa esquecer uma requisição pendente.

O snapshot não perde estabilidade por simples troca de arrays do Store de
conteúdo equivalente ENTRE leituras completas. Identidade de sessão, conteúdo,
locks, missões, estoque e trocas DURANTE aquisição continuam sendo validados.
A prova exige duas leituras coerentes e estáveis por ao menos 80ms.

O relatório somente leitura agora preserva os resumos sanitizados do snapshot
e do lote Super Fast. O menu distingue falha de sincronização de leitura lenta.
Não inclui IDs de cartas/pacotes, credenciais ou vídeo do usuário no pacote.

Bilhar, Cartas, lógicas de poderes e protocolo Super Fast não foram alterados.
A causa exata de toda espera vista no vídeo não está comprovada sem o JSON
interno. Há regressões reproduzíveis corrigidas; não há promessa de vitória,
latência ou ausência de outros bugs no aparelho. Compilação Apple e execução
física da 3.23.11 permanecem pendentes até nova evidência.

Ver Analysis/V3_23_11-runtime-recovery.md e Validation/V3_23_11-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.10 / build 60 — correção de compilação nativa

Corrige o erro `expected identifier` do job 118084139639 / execução 39259788092
(Xcode 16.4, SDK 18.5). O primeiro if de markCoveredContextLost tinha um `&&`
fora dos parênteses; também dependia indevidamente do lote Super Fast.
A guarda volta a consultar apenas o estado de tentativa coberta. O estado
Super Fast permanece no seu coordenador independente, sem liberar pendências.

Sem mudanças de algoritmo JS, Bilhar ou Cartas. Regressão Foundation cobre
combinações de pendência/perda de contexto dos dois coordenadores e idempotência.
Ver Analysis/V3_23_10-build-fix.md e Validation/V3_23_10-validation.json.
Compilação Apple e integração do novo pacote ainda exigem nova execução do CI.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.9 / build 59 — Alpaca Super Fast

Super Fast opt-in: até três cartas expostas do mesmo tipo por ciclo, via eventos
originais do jogo. Exige snapshot completo, ACK individual e efeito confirmado.
Falha 500, resposta incerta ou perda de contexto bloqueiam novas ações; não
fabrica pacotes, não libera cartas cobertas e não altera estoque do servidor.

Corrige leitura e Raio X das reservas elevadas pelo poder quando há geometria
verificada; células nulas de storage_blocks são aceitas conservadoramente.
Mission priority e fallback para o planejador normal são preservados.

Menu Alpaca → engrenagem → Super Fast (desativado por padrão). Habilitar Auto
separadamente. Normal, Turbo, planejamento e poderes continuam disponíveis.
Bilhar e Cartas mantêm os módulos anteriores sem mudança de algoritmo.

Leia Analysis/V3_23_9-super-fast.md e Validation/V3_23_9-validation.json.
Fontes e workflow são pareados por SHA-256; compilação Apple, assinatura e teste
físico são etapas separadas. Não há garantia de vitória ou de latência no aparelho.

## Histórico preservado — não descreve o estado atual

# SDK Client 3.23.8 / build 58 — autenticação e transporte

Auditoria em Analysis/V3_23_8-authentication.md. SDKtools não tem autenticação de
conta própria: usa a sessão existente do host. Nova guarda WSS para os dois testes
experimentais, build CI read-only e publisher separado/manual na branch padrão.
Nenhum token extraído, backend contornado ou binário proprietário patchado.

Editor offline: scripts/game_request_preview.py. Não envia nem aceita credenciais.
Leia SDK_CLIENT.md para escopo e limites. Fontes + workflow, não IPA compilado.
Atualizar SDKtools_Fontes.zip na raiz e .github/workflows/compilar.yml juntos.

## Histórico preservado — artefatos/versões abaixo não são a entrega atual

# SDK Client 3.23.7 / build 57 — Penetrate experimental

**Alpaca → engrenagem → Testar Penetrate (estoque 0)**: uma tentativa manual pela
função original, somente com a linha real de poder verificada e estoque zero.
Não concede poder nem garante aceitação do servidor. Auto OFF e Raio X ON.
Sem alteração de estoque, compra, repetição automática ou envio de pacote próprio.

Corrigida a perda da classificação de recusa 500 durante recuperação tardia.
Exportação do relatório preservada e ampliada com observação fechada da leitura.
Leia SDK_CLIENT.md e Analysis/V3_23_7-penetrate-zero.md.

Pacote de **fontes + workflow**, não IPA compilado. Testes portáteis e hashes em
Validation/V3_23_7-validation.json; compilação Apple e validação física pendentes.
ZIP na raiz e workflow em .github/workflows/compilar.yml precisam ser atualizados
juntos no novo commit. Bilhar e Cartas não recebem alterações de algoritmo.

## Histórico preservado — versões/artefatos abaixo não são a entrega atual

# SDK Client 3.23.6 / build56 — relatório do teste

Leia SDK_CLIENT.md e Analysis/V3_23_6-covered-report.md. O botão Exportar relatório do teste gera um JSON nativo pequeno e somente leitura, inclusive com resultado pendente. Fontes/workflow não equivalem a IPA compilado ou teste físico.

## Histórico preservado

# SDK Client 3.23.5 / build 55 — Camadas experimental

**Estado atual:** fontes 3.23.5/build 55 baseados no marco imutável 3.23.4/build 54. Leia `SDK_CLIENT.md` e `Analysis/V3_23_5-covered-card.md` para uso, protocolo e limites do botão manual **Testar 1 carta coberta**. Compilação Apple, assinatura e validação no iPhone precisam de evidência própria da nova versão; não são comprovadas por este README.

## README histórico 3.22.1 / build 49 — preservado para continuidade

O conteúdo abaixo descreve a entrega antiga e não é o estado atual de versão, IPA disponível ou recursos do menu.

Fontes para WePlay **US 6.6.2/build 132**, com o menu SDK Client da 3.22.0 e seleção de idioma. Esta entrega de fontes acrescenta português e inglês à interface; mantém os contratos e algoritmos dos minijogos.

**O último IPA compilado e recebido continua sendo o 3.22.0/build 48, sem assinatura.** A 3.22.1/build 49 só pode ser apresentada como IPA disponível depois que a CI Apple gerar, integrar e verificar seu próprio artefato. Alterar estes fontes não atualiza o IPA anterior.

## Escolher o idioma

Abra o menu SDK Client e escolha **English** ou **Português** em **Language / Idioma**. A mudança atualiza os textos existentes, incluindo avisos, estados e acessibilidade, e salva a preferência neste aplicativo. Não é necessário fechar a partida ou reiniciar o menu.

Na primeira abertura, o menu procura português ou inglês entre os idiomas preferidos do aparelho. Se não encontrar nenhum, usa inglês. Uma escolha salva tem prioridade. Essa configuração traduz o SDK Client; não altera o idioma do próprio WePlay, nomes recebidos do jogo ou a identidade da marca.

Trocar o idioma não executa controles de jogo, não inicia uma leitura e não rearma automações. Os rótulos English e Português permanecem reconhecíveis nas duas opções.

## Usar o menu

O minijogo identificado fica primeiro e libera seus controles. Os outros permanecem recolhidos e indisponíveis. O menu cliente não exibe os antigos botões de exportação, diagnóstico ou captura.

No **Bilhar / Billiards**, o guia mostra a trajetória estimada da mesa atual. **Aim** ajusta direção e força sem disparar; **Auto** pode solicitar a tacada original, uma vez por tentativa autorizada, somente na partida atual. Toque manual, reabertura do menu e segundo plano pausam a automação. Bola na mão exige colocação manual. Rearmar é uma ação explícita; não há fila ou revanche automática.

O Alpaca conserva missão primeiro, Turbo, planejamento ampliado, poderes existentes opcionais, profundidade do raio X e demais controles da base. O uso automático de poderes pode consumir o estoque existente. Cartas conserva os marcadores da informação recebida; cartas ou cores desconhecidas continuam indicadas como desconhecidas.

## Física e limites do Bilhar

O modelo usa o impulso original `0.031*p*sqrt(p/CUE_POWER_MAX)`, geometria e propriedades físicas lidas da sessão, busca limitada de força, trajetórias diretas ou uma tabela, oclusão e proteção da bola 8. A calibração só ajusta o lançamento após três trechos qualificados, com ganho entre 0,9 e 1,1. Os casts vivos confirmam rota e primeiro contato.

A previsão é aproximada e não reproduz todo o solver PhysX. Sem rota confirmada, aguarda. Spin selecionado, tutorial/offline e contratos incompatíveis não entram na automação normal. Veja `Analysis/V3_21_0-billiards-strategy.md` para os limites da base.

## Compilação e entrega

O workflow oficial compila **`SDKtools_Fontes.zip`**, não a pasta de trabalho. Manifesto, versão, hash, tamanho do ZIP e workflow devem corresponder entre si. A base continua `release_tag=base-us-6.6.2` no repositório `SamuelErlich/sdktools-build`.

A saída esperada após a compilação da nova versão é `WePlay_US_6.6.2_SDKtools_v3_22_1_unsigned.ipa`. Esse nome é o destino planejado, não comprovação de que o IPA já existe. A instalação exige assinatura posterior.

Os testes do catálogo e do empacotador rodam em Python. A execução do catálogo Objective-C, a compilação UIKit e o framework arm64 exigem macOS/Xcode. Preferência persistida, VoiceOver, layout em telas pequenas e a troca de idioma durante estados reais precisam de teste no iPhone. Veja `SDK_CLIENT.md` e `Analysis/V3_22_1-localization.md`.

# SDKtools V3.6 US

Menu por módulos para WePlay US **6.6.2 build 132**, SDKtools **3.6 / build 21**. Crazy Alpaca e Ah, minha carta ficam separados; as opções de diagnóstico ficam em Suporte, recolhidas por padrão. A V3.6 também corrige o retorno da ponte JavaScript que impedia a leitura de cartas na V3.5.1.

## Instalar pelo Windows e GitHub

1. Extraia o pacote recebido. Substitua `SDKtools_Fontes.zip` na raiz do repositório, sem extrair esse ZIP interno.
2. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` do mesmo pacote. Faça commit dos **dois arquivos**.
3. Mantenha a Release `base-us-6.6.2` e o arquivo `WePlay_US_6.6.2_base.ipa`.
4. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova.
5. Ao concluir, baixe **SDKtools-v3.6-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v3_6_unsigned.ipa` no GBox.
6. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V3.6** no menu.

ZIP e workflow formam um par verificado por tamanho e SHA-256. Se aparecer “ZIP e workflow não correspondem”, substitua ambos e inicie outra execução. O certificado continua no GBox.

## O que mudou

O seletor **Alpaca / Cartas** abre os módulos **Crazy Alpaca** e **Ah, minha carta**. Suporte é opcional e fica recolhido, com apenas **Iniciar diagnóstico / Parar diagnóstico** e **Exportar relatório**. Abrir Suporte não inicia gravação. As funções de cada módulo continuam condicionadas ao jogo e ao contexto observados.

A ponte de investigação avaliava uma expressão cujo resultado era uma função JavaScript; esse resultado não é transportável para o código nativo pelo WebKit. A correção executa a fábrica antes de solicitar o resultado serializável. Testes usam os recursos reais do pacote. A correção ainda precisa ser confirmada no aparelho.

A leitura de Ah, minha carta passa a considerar o significado de `Card.cardInfo` identificado na análise estática. O tipo `Back=0` permanece desconhecido. Quando o componente está presente, os valores e os nomes dos frames da frente precisam corresponder, inclusive após compor o ícone; estados inválidos ou frames antigos são recusados. Sem esse componente, permanece somente a leitura de uma frente visível comprovada. A ferramenta usa os frames da própria carta, sem consultar catálogo ou GameStore, e não promete revelar as cartas de outros jogadores.

## Usar as ferramentas

**Crazy Alpaca:** autoplay, Raio X, Meu armazém e atalhos dos poderes. O autoplay procura o próximo trio com análise local de capacidade da barra e desbloqueios, confirma cada movimento e replaneja depois do trio. Não exige resolver toda a mesa antes de jogar, nem garante vitória. Toque manual, pausa, captura ou segundo plano interrompem a automação. A velocidade real depende das animações e confirmações do jogo.

**Raio X:** escolha de 1 a 5 camadas abaixo, cumulativas. Os ícones ficam ancorados nas cartas, com número de profundidade e até dois ícones por âncora; `+N` indica omissões por espaço. A borda verde destaca a combinação validada. Leituras incompletas ou em movimento exigem nova observação.

**Ah, minha carta:** selecione **Cartas** e ative **Ver cartas** somente depois de entrar no jogo. O recurso exige `gameType=2007`, WebView/documento estáveis e Cocos 2.4.5. Janelas sobrepostas limpam os indicadores; mudança de contexto, captura ou segundo plano desativam a ferramenta. O diagnóstico distingue cartas mostradas, desconhecidas e indisponíveis.

**Meu armazém e poderes:** usam os controles originais e suas condições de disponibilidade. O envio do evento não confirma que a janela abriu ou que o efeito foi aplicado. Não há alteração de estoque, resposta de servidor, desbloqueio de armazém ou uso ilimitado.

## Suporte e captura opcional

Para verificar a correção, use Ver cartas durante uma partida e confira se os indicadores acompanham as cartas sem apresentar erro de leitura. Se houver falha, abra Suporte e exporte o relatório antes de iniciar outra captura.

Para investigar Ah, minha carta, selecione **Cartas**, abra **Suporte** e toque em **Iniciar diagnóstico**. Jogue por **30–60 segundos**, incluindo distribuição, compra, troca e descarte. Toque em **Parar diagnóstico → Exportar relatório** e envie o JSON. Vídeo pela gravação de tela do iOS é opcional.

No módulo **Cartas**, o diagnóstico usa a investigação restrita ao jogo 2007: até 90 segundos ou 200 amostras, com alvo de 500 ms entre leituras. No módulo **Alpaca**, inicia a captura comum. Mudança de controlador, documento, WebView ou segundo plano encerra a investigação de cartas; janelas pausam a coleta. Referências locais de diagnóstico não equivalem a identidades comprovadas de cartas.

Os antigos controles Investigar cartas, Capturar novo jogo, exportação de código e gravação de vídeo não ocupam o novo menu. A exportação estática de fontes permanece no projeto, sem executar JavaScript comercial. Nenhum código original exportado é distribuído neste pacote.

## Base e compilação

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use a base original antes de assinar. O integrador exige SDKtools **3.6 build 21**.

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v3_6_unsigned.ipa
```

A suíte local da V3.6 passou com **392 testes JavaScript, 58 testes Python e 179 verificações C**, sem falhas; um teste Python exclusivo de macOS foi ignorado. Os registros ficam em `Validation/V3_6-validation.json` e `VALIDACAO_PACOTE.json`. A compilação Apple, os testes Foundation e o funcionamento no iPhone precisam ser confirmados nesta versão. Os testes locais não comprovam alinhamento visual, velocidade real ou funcionamento perfeito no aparelho.

## Dados e histórico

As capturas mantêm `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.6.0`; os fontes estáticos usam `SDKtools.GameSources`, `schemaVersion=1`. Os relatórios não são enviados automaticamente. O pacote não inclui o IPA base, certificado, capturas privadas completas ou arquivos comerciais JavaScript dos jogos.

`Analysis/V3_6-capture-failure.json` registra os relatórios da V3.5.1; `Analysis/V3_6-card-contract.json` resume a análise estática das cartas com hashes e offsets, sem reproduzir os fontes originais. `Analysis/` também preserva evidências sanitizadas e limites das versões anteriores. Manifestos antigos validam somente suas próprias versões. As correções anteriores de compilação permanecem no projeto. Recursos do jogo carregados dinamicamente podem mudar sem alteração da versão do IPA.

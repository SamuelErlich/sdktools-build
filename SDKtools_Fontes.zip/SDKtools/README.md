# SDKtools V3.19.2 US — correção da guia durante a mira

WePlay US **6.6.2/build132**. SDKtools **3.19.2/build38**.

A V3.19.2 corrige a dependência que fazia toda a guia desaparecer quando a previsão física de parada ficava indisponível. A leitura da mesa e a guia de direção agora funcionam com a barra de força zerada. Quando a força atual e o perfil físico são aceitos, entra a previsão finita da V3.19, com suas marcações de parada.

## O que a captura confirmou

O JSON enviado tem 98 amostras, todas com potência atual zero. Mesa, câmera, turno local e 16 bolas foram encontrados. Em 95 amostras, `physics_profile_mismatch` impediu qualquer cálculo; três também apresentaram mira temporariamente desatualizada. Não houve tacada nessa captura.

Massa, amortecimento, tensor de inércia, gravidade e passo físico exportados eram compatíveis com as tolerâncias. Outros campos usados pelo teste de perfil não foram exportados, então o JSON antigo não revela qual deles provocou a rejeição.

O callback XLua encontrado na própria base monta representações como `FreezePositionY: 4`, enquanto o comparador anterior só reconhecia o nome simples ou o número. A compatibilidade foi corrigida para enums tipados e representações exatas conhecidas. Isso corrige um defeito concreto, mas não prova qual campo recusou aquela sessão: a nova captura passa a registrar esses campos e o primeiro motivo de divergência.

## Como a guia funciona agora

| Situação | Resultado esperado |
|---|---|
| Mira válida e força ainda zerada | Guia de direção visível; mensagem **Guia de direção · ajuste a força**. |
| Força escolhida e parâmetros físicos compatíveis | Previsão finita, considerando desaceleração, colisões, rebates e encaçapamento. |
| Perfil incompatível, dados físicos ausentes ou efeito não suportado | Guia de direção; mensagem **Guia de direção · parada indisponível**. |
| Simulação finita completa | Círculos tracejados nas posições finais estimadas das bolas que ficam na mesa. |
| Simulação finita interrompida por limite ou contato incerto | Trajetória parcial sem marcador de falsa parada. |
| Bolas em movimento, vez adversária, troca de cena ou mira inválida | Guia oculta conforme as proteções existentes. |

A guia de direção usa geometria limitada a dois rebates por bola, 24 segmentos, 32 consultas e 16 eventos, com horizonte geométrico normalizado de 12. Esse horizonte não representa segundos nem distância de parada. Esse modo não inventa força e não gera posições finais.

A previsão finita mantém passo de 0,02 s, até 15 segundos, 750 passos, 64 eventos, 96 consultas, 48 segmentos e seis rebates por bola. Os cálculos usam cópias do estado; não aplicam força nem mudam posições do jogo.

## Teste no aparelho

1. Confirme **V3.19.2** no menu e entre numa partida normal de bilhar.
2. Na sua vez, com as bolas paradas, ative **Ativar leitura do bilhar** e recolha o menu.
3. Mova a mira com a barra de força zerada. Confira a guia de direção.
4. Mantenha o seletor de efeito centralizado. Puxe a barra de força e segure por um instante; a previsão de parada entra quando os parâmetros físicos são aceitos.
5. Grave da mira até as bolas pararem e exporte a leitura logo depois. Se a mensagem continuar indicando parada indisponível, o JSON agora informa os valores que impediram esse cálculo.

Exportar interrompe a leitura. Reativar inicia outra captura. O relatório preserva até 120 amostras, respeita 4 MiB e mantém a associação entre mira, movimento e repouso quando observada no mesmo contexto.

## Compilar

1. Atualize `SDKtools_Fontes.zip` na raiz do repositório e `.github/workflows/compilar.yml` com os arquivos desta mesma entrega.
2. Faça commit e inicie uma **nova execução** de “Compilar SDKtools US”. Reexecutar o job antigo usa os arquivos antigos.
3. Use `base_source=release`, `release_tag=base-us-6.6.2`, asset `WePlay_US_6.6.2_base.ipa`.
4. Depois do build aprovado, baixe e assine `WePlay_US_6.6.2_SDKtools_v3_19_2_unsigned.ipa`.

Este pacote contém fontes, workflow e análise. Não contém IPA já compilado ou assinado. A compilação Apple e os testes Foundation precisam executar no workflow macOS.

## Diagnóstico

`prediction.model=geometric` e `chainVersion=1` identificam a guia de direção. Esse resultado não contém posições de repouso. `model=finite` e `chainVersion=2` identificam a previsão de parada; `complete=true` significa apenas que a simulação terminou.

`physics.reason`, `mismatchField` e `mismatchBallTag`, quando presentes, explicam o primeiro impedimento. `balls[].physicalProfile` registra dimensões, centros, limite angular, constraints e propriedades dos materiais quando disponíveis. Enums são convertidos para valores escalares antes da serialização. Campos ausentes continuam ausentes; dados diagnósticos não autorizam desenho por si próprios.

Nos estados sem guia, o bloco `observedDynamics` pode preservar a dinâmica validada das bolas. As verificações de identidade, contexto, movimento e viewport continuam sendo aplicadas.

## Precisão e preservação

A calibração anterior confirmou trechos de deslizamento e rolamento nas quatro capturas, mas a previsão de uma tacada inteira continua sendo uma estimativa. A ordem dos contatos, efeitos e correções de posição/direção executadas pelo jogo ainda limitam a precisão. O modo finito continua destinado ao perfil suportado da partida normal e ao seletor de efeito centralizado.

Alpaca, os recursos JavaScript, a ponte ARM64/Lua e as políticas de identidade e viewport foram preservados. Cartas continua desativado. Relatórios anteriores permanecem como histórico; veja `Analysis/V3_19_2-*` e `Validation/V3_19_2-validation.json` para esta correção.

## Validação desta entrega

- 84 testes Python passaram; um teste de interoperabilidade Foundation exige macOS e foi pulado.
- 68 testes Lua/Python passaram, incluindo força zero, força ausente, perfil divergente, enums tipados/XLua e limites da guia.
- 196 verificações da política C passaram.
- Oito saídas reais do produtor Lua passaram pela política C de pontos/viewport. A fixture que usa as posições da captura gerou sete segmentos dentro de 1242 × 2688; sua direção de mira e seus limites de mesa são mocks declarados, porque esses valores não estavam no JSON antigo.
- Os testes Foundation foram ampliados e estão incluídos no workflow, mas não foram executados neste ambiente Linux. O pacote ainda precisa ser compilado no macOS e testado no iPhone.

O solver finito, a política de viewport e o desenho dos marcadores de parada foram preservados. Este conjunto comprova as regressões locais; não comprova a precisão de uma tacada completa nem a exibição no aparelho.

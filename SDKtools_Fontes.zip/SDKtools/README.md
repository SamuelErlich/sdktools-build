# SDKtools V2.8.1 US

Correção de compilação para WePlay US 6.6.2 build 132. O teste C do exportador falhou no Actions macOS porque a seleção de recursos POSIX ocultou declarações usadas pelo código Darwin. A V2.8.1 ajusta essa seleção e atualiza a identificação para **2.8.1 / build 11**. As funcionalidades da V2.8 são mantidas.

Substitua os dois arquivos do pacote e inicie uma execução nova no Actions. A correção ainda precisa passar pelo compilador Apple; os testes feitos em Linux não substituem essa etapa. O diagnóstico está em `Analysis/V2_8_1-build-fix.md`.

## Funcionalidades mantidas da V2.8

**Exportar código do jogo** gera um JSON separado com fontes JavaScript estáticos do Crazy Alpaca no cache local verificado. O exportador lê os arquivos; não executa o código nem faz requisições de rede. Essa coleta permite procurar a implementação completa de `UseProp` e suas dependências quando os arquivos necessários estiverem disponíveis.

A captura de cena passa a separar os componentes do armazém dos componentes do poder e da reserva. O `CommonStoreItem` observado nas capturas é um caminho diferente da reserva alterada por `Prop.Storage`. A presença do componente não demonstra quem é seu proprietário nem autoriza concluir que todos os armazéns podem ser abertos.

**Uso ilimitado e abertura de todos os armazéns não estão implementados.** O corpo completo de `UseProp`, sua autoridade de consumo e a regra de abertura ainda não foram recuperados. Os novos coletores preparam a evidência necessária para a próxima análise; não representam uma liberação do estoque ou da interface.

O autoplay mantém a leitura das cartas carregadas, planejamento de trios e confirmação de cada movimento. Os três atalhos de poderes abrem os controles originais, e **Confirmar poder atual** continua dependendo de janela identificada, botão habilitado e estoque positivo. Efeito e consumo permanecem com o jogo. Não há garantia de vitória, ausência de falhas ou acesso a cartas ainda não carregadas.

Os arquivos em `Analysis/` registram os achados. Manifestos anteriores validam suas próprias versões. As capturas privadas completas e os arquivos do jogo recebidos não fazem parte destes fontes.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use o IPA original antes de assinar. O integrador exige SDKtools **2.8.1 build 11** e rejeita outra base ou versão do framework.

## Atualizar pelo Windows e GitHub

1. Extraia o pacote recebido.
2. Substitua `SDKtools_Fontes.zip` na raiz do repositório. Envie esse ZIP interno sem extrair.
3. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` do mesmo pacote. Faça commit dos dois arquivos.
4. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
5. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova.
6. Baixe **SDKtools-v2.8.1-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v2_8_1_unsigned.ipa` no GBox.
7. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V2.8.1** no menu.

ZIP e workflow formam um par verificado por tamanho e SHA-256. Se aparecer “ZIP e workflow não correspondem”, substitua ambos e inicie outra execução. O certificado fica no GBox. A opção `secret_url` usa `SDKTOOLS_BASE_IPA_URL` como link HTTPS direto para a mesma base original.

## Coletar os dois relatórios

Pause o autoplay e entre no Crazy Alpaca. Aguarde o tabuleiro carregar antes de começar.

1. Ative **Rastrear poderes e armazém** e inicie a captura manual do SDKtools.
2. Abra cada poder disponível, deixe a confirmação original aberta por um segundo, confirme manualmente e aguarde o efeito e a atualização do estoque. Registre também uma tentativa bloqueada se o estoque chegar a zero.
3. Mostre os armazéns e abra os controles originais que estiverem disponíveis. Registre antes e depois de colocar ou retirar uma peça. Informe qual armazém você considera seu e quais pertencem aos aliados; essa associação ainda precisa ser confirmada pelos dados.
4. Pare a captura e exporte **SDKtools-Capture-….json**.
5. Com o Crazy Alpaca ainda aberto, toque em **Exportar código do jogo** e salve **SDKtools-GameSources-….json** pela folha de compartilhamento.
6. Envie os dois arquivos e descreva brevemente os poderes usados e os armazéns mostrados.

A exportação de código é separada da captura. Ela depende de uma página local do jogo identificado e dos arquivos presentes no cache. Se aparecer um erro ou uma coleta parcial, envie a mensagem e os arquivos produzidos; isso não comprova que a lógica ausente seja local ou remota.

O exportador limita cada arquivo JavaScript a 16 MiB, o conteúdo lido a 32 MiB e o JSON final a 64 MiB. Arquivos ilegíveis, modificados durante a leitura, fora da raiz verificada ou que excedam os limites não são tratados como fontes completas.

## Autoplay e poderes existentes

Entre no tabuleiro e inicie o autoplay. Acompanhe o status e as primeiras jogadas. **Pausar**, um toque manual no jogo ou a ida para segundo plano interrompem a automação; inicie novamente para continuar.

Para usar um poder, pause o autoplay, abra o atalho e confira a janela original. Confirme nessa janela ou toque em **Confirmar poder atual** enquanto ela estiver aberta. Aguarde o efeito no tabuleiro. Estoque zero ou botão original desabilitado impedem a confirmação. Feche uma janela anterior antes de abrir outra.

Se o autoplay não agir, exporte o relatório diretamente. Ele conserva até 96 eventos recentes sem iniciar a gravação do SDKtools. A gravação do SDKtools pausa e bloqueia o autoplay; para filmar a automação, use a gravação de tela do iOS.

## Formatos e limites

As capturas continuam em `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=2.8.1`. Os nomes legados `returnTrace` e `returnInspection` são mantidos por compatibilidade e não identificam automaticamente Retornar. O JSON de fontes estáticas usa `SDKtools.GameSources`, `schemaVersion=1`. Seus arquivos mostram os bytes presentes no disco; isso não comprova quais fontes já foram executados na sessão.

A captura registra toques observados, estrutura UIKit e amostras Cocos. Limites: 180 segundos, 300 amostras de toque, 720 leituras WebView ou 32 MiB de JSON compacto. O alvo de 250 ms não garante quatro amostras por segundo. Cenas parciais não comprovam remoção de cartas; IDs de nós e frames são locais ao contexto.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

O decoder acima é para capturas de cena. A inspeção é limitada aos componentes identificados; trechos truncados ou ambíguos são marcados. Nenhum método capturado é executado para investigá-lo.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v2_8_1_unsigned.ipa
```

O build executa testes Python, JavaScript, testes portáveis do código C compartilhado e testes Foundation antes de compilar o framework. O resultado requer assinatura no GBox. Os resultados finais estão em `Validation/V2_8_1-validation.json` e `VALIDACAO_PACOTE.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
bash scripts/test_native_action_policy.sh
bash scripts/test_game_source_export.sh
```

Os testes portáveis verificam contratos e componentes compartilhados com o código do aparelho. Compilação Apple, testes Foundation, assinatura e execução real não foram realizadas no ambiente Linux de preparação. A validação no iPhone depende do Actions e do aparelho.

## Dados e compatibilidade

Os fontes não incluem certificado, IPA original, vídeo ou capturas privadas completas. Os relatórios não são enviados automaticamente. A exportação nova lê somente fontes `.js` da raiz local verificada do jogo; não lê cookies, credenciais ou clipboard. Os arquivos JavaScript podem conter literais do próprio aplicativo.

A compatibilidade foi definida para esta base e os componentes observados em Cocos 2.4.4. Recursos carregados dinamicamente podem mudar sem alteração da versão do IPA.

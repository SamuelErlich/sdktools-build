# SDKtools V2.7 US

Menu flutuante para WePlay US 6.6.2 build 132. Esta versão corrige o bloqueio nativo que impedia o autoplay de chegar à leitura do tabuleiro e adiciona atalhos para os três poderes originais. O funcionamento no iPhone precisa ser confirmado após o build.

## Correções e poderes

Os relatórios V2.6 registraram tentativas barradas por `native_context_transitioning` ou `native_context_unavailable`, antes da execução do leitor de cartas. A V2.7 corrige a seleção da janela do jogo e mantém a intenção de iniciar durante transições temporárias identificadas. O relatório registra o motivo de espera e o resultado de cada tentativa.

Também foi corrigido o argumento do evento de seleção: o callback Cocos recebe agora um EventTouch construído com o alvo da carta, em vez do objeto Button. Esse erro foi identificado no código; o bloqueio nativo impedia observá-lo nos relatórios.

O autoplay lê as cartas carregadas, verifica a barra, calcula trios e aguarda a confirmação de cada movimento. Cartas cobertas só podem ser usadas no planejamento quando seus dados estão presentes. O sistema espera estados completos e estáveis antes de agir. Não há garantia de vitória nem de conhecimento de cartas ainda não criadas ou enviadas pelo jogo.

O menu oferece acesso aos três poderes da linha original e uma confirmação explícita do poder aberto. A confirmação exige a janela original, botão habilitado e estoque positivo. O efeito e o consumo continuam sendo executados pelo jogo. Abrir a janela não equivale a usar o poder; enviar a confirmação não comprova que o efeito terminou.

Nos estados completos recebidos, o poder central devolveu uma carta da barra ao tabuleiro, o da direita embaralhou as faces e o da esquerda transferiu três cartas para a reserva. Esses são efeitos observados do jogo original, não testes da nova integração no aparelho.

A identidade dos poderes pode mudar conforme o conjunto disponível. Por isso, posição e desenho não bastam para chamá-los de Retornar, Embaralhar ou Eliminar. A janela original informa o poder selecionado.

**Uso ilimitado não está implementado.** Os novos JSONs mostram estados e consumo observado, mas não contêm o código completo da regra de consumo. A coleta foi ampliada para registrar os campos e a confirmação relevantes. Alterar somente o número exibido não produziria estoque real.

Os arquivos em `Analysis/` resumem a evidência. Relatórios e manifestos antigos descrevem suas próprias versões e podem conter hipóteses posteriormente corrigidas. As capturas completas recebidas não estão neste pacote.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use o IPA original antes de assinar. O integrador exige SDKtools **2.7 build 9** e rejeita outra base ou versão do framework.

## Atualizar pelo Windows e GitHub

1. Extraia o pacote recebido.
2. Substitua `SDKtools_Fontes.zip` na raiz do repositório. Envie esse ZIP interno sem extrair.
3. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` do mesmo pacote. Faça commit dos dois arquivos.
4. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
5. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova.
6. Baixe **SDKtools-v2.7-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v2_7_unsigned.ipa` no GBox.
7. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V2.7** no menu.

ZIP e workflow formam um par verificado por tamanho e SHA-256. Se aparecer “ZIP e workflow não correspondem”, substitua ambos e inicie uma nova execução. O certificado fica no GBox. A opção `secret_url` usa `SDKTOOLS_BASE_IPA_URL` como link HTTPS direto para a mesma base original.

## Testar no iPhone

Entre em Crazy Alpaca, aguarde o tabuleiro carregar e inicie o autoplay. Acompanhe as primeiras jogadas e o status. Uma espera transitória pode terminar automaticamente. **Pausar**, um toque manual no jogo ou a ida para segundo plano interrompem a automação; inicie novamente para continuar.

Para usar um poder, pause o autoplay, abra o atalho desejado e confira a janela original. Confirme nessa janela ou toque em **Confirmar poder atual** no menu enquanto ela estiver aberta. Aguarde o efeito no tabuleiro. Estoque zero ou botão original desabilitado impedem a confirmação. Feche uma janela anterior antes de abrir outra.

Se o autoplay não agir, **exporte o relatório diretamente**. Ele conserva até 96 eventos recentes sem precisar iniciar a gravação do SDKtools. A gravação do SDKtools pausa e bloqueia o autoplay; use a gravação de tela do iOS para filmar a automação.

Para investigar os poderes, faça uma captura manual separada com **Rastrear poderes** ativo. Abra a confirmação, aguarde um segundo, use o poder e registre o efeito e a contagem. Se houver estoque zero, registre a tentativa bloqueada também. Exporte esse segundo JSON e informe qual poder foi usado.

## Relatórios

Formato `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=2.7.0`. Os nomes legados `returnTrace` e `returnInspection` permanecem por compatibilidade e não identificam automaticamente Retornar.

A captura registra toques observados, estrutura UIKit e amostras Cocos. Limites: 180 segundos, 300 amostras de toque, 720 leituras WebView ou 32 MiB de JSON compacto. O intervalo alvo de 250 ms não garante quatro amostras por segundo. Cenas parciais não comprovam remoção de cartas; IDs de nós e frames são locais ao contexto.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

A inspeção de poderes limita métodos, campos escalares e contador aos componentes identificados. Ela não executa métodos capturados nem recupera automaticamente todas as dependências. Dados truncados e ambíguos são marcados.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v2_7_unsigned.ipa
```

O build executa testes Python, JavaScript, a política nativa portátil em C e testes Foundation antes de compilar o framework. O resultado requer assinatura no GBox. Os números finais estão em `Validation/V2_7-validation.json` e `VALIDACAO_PACOTE.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
bash scripts/test_native_action_policy.sh
```

Os testes portáveis cobrem contratos, dados simulados e política de seleção de contexto. Compilação Apple, testes Foundation, assinatura e execução real não foram realizadas no ambiente Linux de preparação. A validação no aparelho depende do Actions e do iPhone.

## Dados e compatibilidade

Os fontes não incluem certificado, IPA original, vídeo ou capturas privadas completas. A coleta não envia relatórios automaticamente nem lê credenciais, cookies, clipboard ou conteúdo geral de campos de texto. Trechos de código capturado podem conter literais.

A compatibilidade foi definida para esta base e os componentes observados em Cocos 2.4.4. O jogo carrega recursos dinamicamente; mudanças nesses recursos podem exigir nova análise sem alteração da versão do IPA.

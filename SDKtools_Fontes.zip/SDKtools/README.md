# SDKtools V3.12 US: captura desde a entrada

Fontes para WePlay US **6.6.2, build 132**, SDKtools **3.12, build 27**.
Este pacote contém fontes, testes e workflow de compilação. O framework ARM64 e o IPA dependem de macOS/Xcode. A execução no iPhone continua sendo uma etapa separada.

## O que esta versão faz

O novo botão **Cartas → Capturar desde a entrada** prepara a observação antes de abrir Ah, minha carta. A espera pela próxima entrada dura até 120 segundos. Quando o documento do jogo inicia a comunicação com o coletor, começa uma janela de até 90 segundos. O script limita seus eventos a 90 segundos desde sua própria inicialização; os relógios nativo e JavaScript são informados separadamente.

O script entra por `WKUserScript` em `atDocumentStart` e acompanha o carregamento do pacote principal. Os observadores dos métodos do jogo só são instalados depois do aceite nativo para aquela WebView. Esse aceite é assíncrono: se a cena ou conexão avançar antes dele, o relatório informa cobertura parcial. Configurar `atDocumentStart` sozinho não comprova que a primeira resposta foi capturada. Não exige uma carta visual para começar. A nova captura não recarrega a partida nem envia comandos de compra, sincronização, escolha de jogador ou revelação por conta própria.

O botão **Capturar partida aberta** mantém o coletor anterior. Ele é útil para comparar o estado atual, mas não comprova a cobertura da entrada. **Injetar cores**, **Reler raiz** e **Ativar cores** mantêm o comportamento da V3.11. As candidatas do novo relatório não são usadas automaticamente para pintar cartas.

## Como fazer a captura de 90 segundos

1. Instale a V3.12 e confira o número no menu.
2. Se estiver dentro de Ah, minha carta, saia primeiro. No lobby, abra **Cartas → Capturar desde a entrada** e então entre no jogo. O SDK não força a saída nem reinicia a página.
3. Entre no jogo dentro de 120 segundos. A espera não consome os 90 segundos de coleta.
4. Jogue normalmente durante a captura. Compra, descarte, seleção de carta e efeitos de olhar/trocar cartas são úteis quando acontecerem na partida. Não é preciso provocar comandos extras.
5. Mantenha o jogo em primeiro plano. Aguarde o status de encerramento automático, que pode levar cerca de 92 segundos após a entrada para receber o último lote.
6. Toque **Exportar origem** e envie o JSON completo. Se houver erro ou nenhuma leitura, exporte também: o motivo faz parte do relatório.

Parar ou exportar antes do encerramento automático pode deixar o último lote em trânsito. O relatório marca essa limitação. Uma nova captura da entrada substitui a anterior na memória, portanto exporte antes de preparar outra.

## A pista encontrada na captura enviada

A captura V3.11 enviada dura 90,003643 segundos e contém 67 respostas decodificadas. Em duas respostas `CMD_SYNC`, `select_give_card` continha uma face conhecida e a mão possuía o mesmo ID com `type/color/num` zerados. Os objetos eram diferentes. A informação apareceu em apenas uma sincronização em cada ocorrência.

A V3.12 registra essa coincidência em `sideChannelCandidates`, com `confidence=candidate` e `relation=same_response_id_only`. Isso conserva uma pista transitória sem transformá-la em prova de identidade. O campo lateral pode ter outra função, estar associado à seleção de outro jogador ou ser um estado de transição; o contrato precisa ser confirmado antes de qualquer marcador.

As 807 observações de mão zerada no resolvedor daquela captura são observações repetidas, referentes a 26 IDs distintos, e não 807 cartas diferentes. Nos 59 pares de Store e 36 pares de `Card.setup` comparados, não houve mudança nos campos exportados. Portanto, essa leitura não demonstrou uma rotina local apagando as cores entre esses dois pontos.

A análise sanitizada está em `Analysis/V3_12-input-capture.json` e `.md`. A captura original e identificadores de jogadores não entram neste pacote.

## Caminho e responsabilidades do código

| Arquivo | Responsabilidade |
|---|---|
| `STCardEarlyCapture.h/.m` | Preparar o documento da WebView, conferir o controlador nativo/gameType 2007, receber lotes e aplicar limites. |
| `STCardEarlyRecorder.inc` | Integrar início, parada e status ao gravador existente. |
| `card_early.js` | Observar carregamento, socket, respostas decodificadas, Store, mãos, componentes e argumentos de textura. |
| `STCardEarlySanitizer.inc` | Aceitar somente os campos estruturais definidos no contrato. |
| `scripts/analyze_card_early.py` | Ler o JSON exportado e separar cobertura, valores conhecidos, desconhecidos e candidatas. |

A instalação nativa verifica o ABI do getter `gameType` e dos métodos de preparação do controlador. Os métodos originais continuam sendo chamados uma vez. Não são usados endereços ARM64 fixos. Caso o contrato não corresponda, o relatório deve indicar falha de instalação em vez de seguir outro jogo.

No JavaScript, a referência armazenada por `socket.onmessage = onMessage.bind(this)` exige instalar a observação antes da conexão. Uma conexão preexistente deve ser marcada como cobertura parcial. As reconexões recebem uma geração própria.

O fluxo acompanha o argumento já decodificado entregue ao resolvedor original. Também observa pushes antes do tratamento e as sincronizações solicitadas pelo próprio jogo. Os valores são copiados no momento da observação. As referências de objetos e nós viram aliases locais, válidos somente dentro daquele documento.

`CardSkinManager.setCardBg` e `setCardType` recebem a cor pronta. A observação inclui a entrada e a conclusão assíncrona. Uma mudança de associação entre carta e sprite durante o carregamento é marcada como vínculo obsoleto; textura antiga não é uma cor confirmada.

## Como interpretar o JSON

O formato externo permanece `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.12.0`. A nova coleta fica em **`cardEarly`**. Os campos legados `cardFlow`, `durationSeconds` e `webSamples` descrevem a captura convencional e podem estar vazios ou pertencer a uma captura convencional anterior. Para a nova coleta, use os tempos e a geração de `cardEarly`.

Verifique primeiro status, motivo de parada, marcos de instalação e perdas. Dentro de `samples[].observation`, `milestones` indica se houve instalação antes da cena/socket/primeira sincronização; `gaps` registra lacunas; `counters` informa respostas, eventos perdidos e truncamentos. `hasInitialSync` exige a resposta do primeiro pedido `CMD_SYNC` observado em contexto de instalação precoce; uma segunda resposta não substitui uma primeira perdida. `native.finalDrainConfirmed` informa se o lote final foi recebido sem perdas identificadas.

| Evidência | O que permite concluir |
|---|---|
| Resposta decodificada com cor válida | Esse valor passou por aquele ponto e momento. |
| Mesma resposta com `select_give_card` conhecido e mão zerada com mesmo ID | Coincidência candidata que precisa de confirmação de vínculo. |
| Store/componente com objeto atual e associação válida | Vínculo local mais forte, ainda limitado ao contexto observado. |
| Cor da rodada ou carta especial | Não determina a cor de todas as cartas da mão. |
| Zero em todos os pontos observados | Valor desconhecido naquela cobertura, sem prova de ausência universal no cliente. |
| `dropped`, truncamento, instalação tardia ou lote final ausente | Captura parcial. Não tratar ausência de registro como ausência de informação. |

O relatório não declara `hiddenIdentitiesProven=true`. A V3.12 prepara uma investigação verificável; não garante que o servidor envie as cores dos adversários.

Para gerar um resumo local:

```bash
python3 scripts/analyze_card_early.py --input /caminho/SDKtools-Capture.json --output /caminho/resumo.json
```

## Limites e preservação

A coleta nova tem duração máxima de 90 segundos de eventos por documento, até 4096 eventos, lotes limitados e orçamento total limitado. A comunicação JavaScript → nativo usa um handler com resposta e uma autorização de curta duração. O coletor restaura os métodos que ainda são seus ao encerrar, perder a comunicação ou sair da página. Não faz avaliações JavaScript concorrentes com `STWebProbe`.

Somente a WebView vinculada ao controlador do jogo 2007 é aceita. Nenhum conteúdo de chat, token, credencial, URL ou payload bruto é exportado. O código não altera valores `type`, `color`, `num`, cartas, regras ou estoque.

Os 13 arquivos centrais do Alpaca são comparados por SHA-256 com a V3.11. Autoplay, raio X, profundidades, armazém e poderes ficam preservados. O menu compartilhado bloqueia outras capturas e ferramentas enquanto esta coleta está ativa.

## Compilar e instalar

1. Substitua `SDKtools_Fontes.zip` na raiz do repositório, sem extrair o ZIP interno.
2. Substitua `.github/workflows/compilar.yml` pelo arquivo do mesmo pacote. Faça commit dos dois juntos.
3. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
4. Inicie uma nova execução de **Actions → Compilar SDKtools US**, `base_source=release`, `release_tag=base-us-6.6.2`.
5. Baixe **SDKtools-v3.12-US-IPA**, extraia e assine `WePlay_US_6.6.2_SDKtools_v3_12_unsigned.ipa`, incluindo os componentes incorporados.
6. Confira **V3.12** no menu antes de coletar.

O workflow confere tamanho, SHA-256 e manifesto dos fontes antes de executar os scripts. Um ZIP de outra versão é recusado. Não basta repetir um job antigo: inicie uma execução com os dois arquivos novos.

Os resultados efetivamente executados ficam em `Validation/V3_12-validation.json`. Testes portáteis, compilação Apple, assinatura e execução no aparelho são registrados separadamente. Manifestos de versões anteriores são históricos.

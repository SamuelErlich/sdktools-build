# SDKtools V3.14 US — recursos do bilhar

Fontes para WePlay US **6.6.2, build 132**, SDKtools **3.14, build 29**.

A V3.14 acrescenta **Suporte → Exportar recursos do bilhar**. O botão reúne os manifestos locais e os pacotes de cena, modelos, prefabs, materiais de física e `cres` que o jogo já baixou. O caminho foi confirmado no ARM64 desta base. A coleta usa arquivos locais e não depende da WebView.

Esta versão prepara a análise necessária para o trainer. **Ainda não identifica bolas em movimento, não desenha uma linha de previsão e não executa tacadas.** Os arquivos de cache também não comprovam qual versão está carregada na partida atual.

## Descobertas

- A captura enviada mostra `UnityDefaultViewController`, `UnityView` e `CAMetalLayer`. Os toques registrados são posições do dedo; não são posições das bolas.
- O IPA contém `LoadingBilliard.unity` e `billiard_asset_records_ios.svga`. O catálogo é protobuf `Recordconfig.AssetBundleRecords`.
- No catálogo embutido, `gameId=20` e `version=1047`. **20 identifica o catálogo de recursos; o `gameType` nativo e o `sceneType` da partida continuam sem confirmação.**
- São 14 pacotes declarados, ausentes como arquivos no IPA. Os cinco grupos selecionados somam 293.452 bytes na revisão embutida. A revisão instalada pode ser diferente.
- A resolução nativa de `persistentDataPath` usa Documents. Os pacotes ficam em `Documents/AssetBundles`; existe também um caminho legado em `Library/UnityCache/Shared`.
- `.lz4` resulta de recompressão Unity. Seu hash pode diferir do arquivo original indicado no catálogo.

Evidências e limites estão em `Analysis/V3_14-billiards-unity.md` e `Analysis/V3_14-evidence/`. As análises anteriores permanecem como histórico.

## Próxima exportação no iPhone

1. Compile e instale a V3.14 pelo fluxo abaixo.
2. Abra o **bilhar** e aguarde o carregamento da mesa.
3. Abra **Suporte → Exportar recursos do bilhar**. Aguarde sem mudar de tela.
4. Salve ou compartilhe o JSON gerado e envie-o para continuar a análise.

Não é necessário repetir 90 segundos de toques para essa exportação. Ela procura os arquivos já baixados. Se não encontrar recursos, gera um diagnóstico com contagens e motivos disponíveis. Ausência no cache não demonstra impossibilidade de leitura nem necessidade de comprar outro IPA.

O formato novo é `SDKtools.BilliardsResources`, schema 1, `toolVersion=3.14.0`. Os recursos ficam separados do relatório comum `SDKtools.Capture`. `filesExported` não significa bolas identificadas.

## Preservação e escopo

Crazy Alpaca mantém os 13 arquivos centrais idênticos à V3.13, conferidos por SHA-256. Cartas continua sem aba e com `ST_CARD_GAME_FEATURE_ENABLED=0`.

A exportação é manual e limitada aos catálogos de bilhar e às famílias `cres`, `scene`, `prefabs`, `physicmaterials` e `model`. Ela não executa scripts, não chama métodos Unity, não modifica o cache e não faz downloads. Registra os bytes, seu SHA-256, a origem relativa, limites e alterações detectadas durante a leitura.

## Compilar e instalar

1. Substitua `SDKtools_Fontes.zip` na raiz do repositório pelo ZIP interno deste pacote.
2. Substitua `.github/workflows/compilar.yml` pelo arquivo pareado. Faça commit dos dois juntos.
3. Reutilize a Release `base-us-6.6.2`, com `WePlay_US_6.6.2_base.ipa`.
4. Inicie uma **nova execução** de **Actions → Compilar SDKtools US**, com `base_source=release` e `release_tag=base-us-6.6.2`.
5. Baixe **SDKtools-v3.14-US-IPA**, extraia e assine `WePlay_US_6.6.2_SDKtools_v3_14_unsigned.ipa` e seus componentes pelo fluxo habitual.
6. Confira V3.14 no menu, valide Alpaca e faça a exportação do bilhar.

O workflow confere versão e SHA-256 dos fontes antes de executá-los, valida o IPA base e executa os testes Apple antes da compilação ARM64. Uma execução antiga de Actions usa o commit antigo.

## Validação e limites

O pacote contém **fontes e workflow**, não um IPA novo já compilado. `Validation/V3_14-validation.json` registra os testes executados. Compilação Apple, assinatura e execução no iPhone permanecem etapas a realizar no ambiente apropriado.

Após a exportação será possível examinar os pacotes e procurar componentes, raios das bolas, escala e materiais físicos. Leitura em tempo real, câmera e regras de colisão ainda precisarão ser confirmadas antes de chamar o lineguide de funcional.

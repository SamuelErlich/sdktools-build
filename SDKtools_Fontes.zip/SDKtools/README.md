# SDK Client 3.23.15 / build 65 — reserva e diagnóstico pelo navegador

Corrige o Raio X das pilhas criadas pelo poder de Armazenar: a profundidade
passa a usar a sobreposição verificada, mesmo sem máscara escura. Mantém
disponibilidade, comandos originais e limite visual de quatro camadas.

O painel LAN permite Capturar partida, Parar captura, Gerar relatório,
Extrair fontes e Baixar JSON diretamente no PC. A captura pausa Auto e Raio X;
registre a partida manualmente antes/depois de usar o poder. Os metadados
observados das cartas continuam sendo gravados. Para um problema no Auto,
gere também o relatório logo após a falha, antes de iniciar nova captura.

O download exige pareamento, usa apenas o arquivo JSON recém-exportado,
limite de 64 MiB e blocos de 256 KiB. Não aceita caminho de arquivo,
JavaScript ou comando do protocolo do jogo pelo navegador. O painel continua
restrito à rede Wi-Fi privada, com o aviso de HTTP sem criptografia existente.

Validação física PC/iPhone pendente. Compilação e testes Apple devem ocorrer
no repositório oficial usando o ZIP e workflow correspondentes.
Ver Analysis/V3_23_15-reserve-web.md e Validation/V3_23_15-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.14 / build 64 — correção da compilação LAN

Corrige os dois erros Clang confirmados no diagnóstico da 3.23.13: acesso
`value.count` sobre `id` no parser LAN. Após validar o tipo em runtime, o parser
agora usa uma referência `NSDictionary *` explícita; preferências também são
validadas antes de acessar propriedades. A whitelist, os limites, o pareamento
e as verificações de sequência/Host/Origin permanecem intactos.

Adicionados casos nativos de formatos inválidos e um contrato portátil de
tipagem. JS/Lua de gameplay, painel web, servidor TCP, fluxo Auto/Super Fast,
Bilhar e Cartas foram preservados byte a byte em relação à 3.23.13.

O log recebido confirma os testes anteriores ao erro, mas não a compilação do
framework. Esta entrega ainda exige NOVA execução macOS/iPhoneOS e teste real
PC/iPhone. Substituir juntos o ZIP e o workflow atualizados, nunca só um deles.
Ver Analysis/V3_23_14-lan-build-fix.md e Validation/V3_23_14-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.13 / build 63 — controle LAN do Alpaca

Controle opcional pelo navegador do PC, na mesma rede Wi-Fi privada. O iPhone
continua executando a partida e usando a sessão original; o navegador controla
as preferências do SDKtools e o início/pausa do Auto. Não é cliente independente
WePlay, streaming de tela nem seleção manual de cartas nesta versão.

- Painel com mesa, bandeja, reserva, cartas compartilhadas no total, tipos,
  missão disponível, jogadas confirmadas localmente e estado do Super Fast.
- Cinco níveis: Baixo 500ms, Moderado 250ms, Normal 100ms, Turbo 40ms e Máximo
  20ms/Super Fast. São cadências de avaliação, não garantias de cartas/segundo.
- Planejamento ampliado, poderes do estoque e Raio X configuráveis. Aplicar
  opções não inicia o Auto. ACKs, estabilidade e latches pendentes permanecem.
- Botão Browser control no menu Alpaca: URL HTTP local e PIN de 8 dígitos.
  Um navegador por sessão, 5 tentativas de pareamento, 2 minutos para conectar.
- Sessão pareada exige heartbeat; ~8s sem contato revogam o acesso e pausam
  Auto que tenha sido iniciado remotamente. Background/inatividade encerram LAN.

ATENÇÃO: HTTP SEM CRIPTOGRAFIA. Pareamento não é proteção contra sniffing na
rede. Usar somente Wi-Fi privado confiável; sem VPN, relay, UPnP ou portas no
roteador. O listener usa IPv4 privado do en0, porta efêmera e endereço explícito,
nunca 0.0.0.0. Não implementa IPv6-only/Bonjour. Não copia tokens do WePlay.

Controles remotos aceitos: start, pause, preferences. Sem eval, pacotes de jogo,
IDs arbitrários, cartas cobertas, estoque zero ou comandos experimentais. O
estado exportado ao painel é fechado; snapshots incompletos/velhos mostram —,
não zeros inventados. A sessão da rede tem credencial própria, em memória.

Bilhar, Cartas e os algoritmos JS de gameplay da 3.23.12 foram preservados.
Fontes e testes locais não provam compilação Apple nem funcionamento no iPhone.
Ver Analysis/V3_23_13-lan-control.md, Validation/V3_23_13-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.12 / build 62 — compatibilidade Super Fast

O relatório da 3.23.11/build 61 mostra snapshot completo, mas o coordenador
Super Fast foi recusado no preflight (`observer_unavailable`, zero eventos e
zero pedidos). Não houve recusa do servidor nesse lote. A captura não revela
qual requisito falhou; `action_disabled` é somente a última leitura exportada.

O preflight agora identifica o requisito por enumeração fechada. Não exige
`Function.length === 2`: funções com rest/default/wrapper podem ter length 0,
mas a observação continua exigindo os dois argumentos reais, pacote correlato,
Promise original e ACK confiável para confirmar a rajada.

Se transporte/API/hooks/timer não suportarem o observador, e somente quando
nenhum evento foi invocado e todos os hooks foram restaurados, segue pelo Auto
original, UMA carta por vez, aguardando seu efeito estável. O menu indica
"Super Fast: compatível, 1 por vez". A capacidade é reavaliada após 3 segundos
ou mudança de contexto; nunca se envia um trio sem observador. A confirmação
local do Auto normal NÃO é ACK do servidor nem vitória garantida.

500, timeout, pedido incerto, lote parcial, contexto perdido ou falha de
restauração NÃO autorizam esse fallback. As proteções da 3.23.11, o Raio X,
os poderes, Bilhar e Cartas foram preservados. Não há alteração de permissão,
estado do jogo, estoque ou fabricação de pacotes.

Testes locais cobrem os dois caminhos. Compilação Apple, assinatura e teste
físico da 3.23.12 permanecem pendentes. Não é garantia de três cartas simultâneas
em todo runtime nem de ausência de outros bugs no aparelho.

Ver Analysis/V3_23_12-super-fast-compatibility.md e Validation/V3_23_12-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.11 / build 61 — retomada Auto/Raio X

Corrige a confusão entre avaliação física em andamento e avaliação capaz de
jogar: uma leitura somente Raio X não desabilita mais o botão Auto nem aparece
como ação enviada. Play apenas arma intenção; não inicia outra avaliação até
terminar a leitura atual. Uma avaliação capaz de agir, timeout incerto, carta
experimental ou contexto perdido continuam com seus bloqueios preservados.

Após o primeiro bootstrap confirmado no documento, ticks nativos usam comando
curto e o runtime já vinculado, sem reenviar todos os scripts a cada 20/40/100ms.
Namespace/documento ausente ou diferente retorna falha fechada; nunca recria
silenciosamente um runtime que possa esquecer uma requisição pendente.

O snapshot não perde estabilidade por simples troca de arrays do Store de
conteúdo equivalente ENTRE leituras completas. Identidade de sessão, conteúdo,
locks, missões, estoque e trocas DURANTE aquisição continuam sendo validados.
A prova exige duas leituras coerentes e estáveis por ao menos 80ms.

O relatório somente leitura agora preserva os resumos sanitizados do snapshot
e do lote Super Fast. O menu distingue falha de sincronização de leitura lenta.
Não inclui IDs de cartas/pacotes, credenciais ou vídeo do usuário no pacote.

Bilhar, Cartas, lógicas de poderes e protocolo Super Fast não foram alterados.
A causa exata de toda espera vista no vídeo não está comprovada sem o JSON
interno. Há regressões reproduzíveis corrigidas; não há promessa de vitória,
latência ou ausência de outros bugs no aparelho. Compilação Apple e execução
física da 3.23.11 permanecem pendentes até nova evidência.

Ver Analysis/V3_23_11-runtime-recovery.md e Validation/V3_23_11-validation.json.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.10 / build 60 — correção de compilação nativa

Corrige o erro `expected identifier` do job 118084139639 / execução 39259788092
(Xcode 16.4, SDK 18.5). O primeiro if de markCoveredContextLost tinha um `&&`
fora dos parênteses; também dependia indevidamente do lote Super Fast.
A guarda volta a consultar apenas o estado de tentativa coberta. O estado
Super Fast permanece no seu coordenador independente, sem liberar pendências.

Sem mudanças de algoritmo JS, Bilhar ou Cartas. Regressão Foundation cobre
combinações de pendência/perda de contexto dos dois coordenadores e idempotência.
Ver Analysis/V3_23_10-build-fix.md e Validation/V3_23_10-validation.json.
Compilação Apple e integração do novo pacote ainda exigem nova execução do CI.

## Histórico preservado — não descreve a versão atual

# SDK Client 3.23.9 / build 59 — Alpaca Super Fast

Super Fast opt-in: até três cartas expostas do mesmo tipo por ciclo, via eventos
originais do jogo. Exige snapshot completo, ACK individual e efeito confirmado.
Falha 500, resposta incerta ou perda de contexto bloqueiam novas ações; não
fabrica pacotes, não libera cartas cobertas e não altera estoque do servidor.

Corrige leitura e Raio X das reservas elevadas pelo poder quando há geometria
verificada; células nulas de storage_blocks são aceitas conservadoramente.
Mission priority e fallback para o planejador normal são preservados.

Menu Alpaca → engrenagem → Super Fast (desativado por padrão). Habilitar Auto
separadamente. Normal, Turbo, planejamento e poderes continuam disponíveis.
Bilhar e Cartas mantêm os módulos anteriores sem mudança de algoritmo.

Leia Analysis/V3_23_9-super-fast.md e Validation/V3_23_9-validation.json.
Fontes e workflow são pareados por SHA-256; compilação Apple, assinatura e teste
físico são etapas separadas. Não há garantia de vitória ou de latência no aparelho.

## Histórico preservado — não descreve o estado atual

# SDK Client 3.23.8 / build 58 — autenticação e transporte

Auditoria em Analysis/V3_23_8-authentication.md. SDKtools não tem autenticação de
conta própria: usa a sessão existente do host. Nova guarda WSS para os dois testes
experimentais, build CI read-only e publisher separado/manual na branch padrão.
Nenhum token extraído, backend contornado ou binário proprietário patchado.

Editor offline: scripts/game_request_preview.py. Não envia nem aceita credenciais.
Leia SDK_CLIENT.md para escopo e limites. Fontes + workflow, não IPA compilado.
Atualizar SDKtools_Fontes.zip na raiz e .github/workflows/compilar.yml juntos.

## Histórico preservado — artefatos/versões abaixo não são a entrega atual

# SDK Client 3.23.7 / build 57 — Penetrate experimental

**Alpaca → engrenagem → Testar Penetrate (estoque 0)**: uma tentativa manual pela
função original, somente com a linha real de poder verificada e estoque zero.
Não concede poder nem garante aceitação do servidor. Auto OFF e Raio X ON.
Sem alteração de estoque, compra, repetição automática ou envio de pacote próprio.

Corrigida a perda da classificação de recusa 500 durante recuperação tardia.
Exportação do relatório preservada e ampliada com observação fechada da leitura.
Leia SDK_CLIENT.md e Analysis/V3_23_7-penetrate-zero.md.

Pacote de **fontes + workflow**, não IPA compilado. Testes portáteis e hashes em
Validation/V3_23_7-validation.json; compilação Apple e validação física pendentes.
ZIP na raiz e workflow em .github/workflows/compilar.yml precisam ser atualizados
juntos no novo commit. Bilhar e Cartas não recebem alterações de algoritmo.

## Histórico preservado — versões/artefatos abaixo não são a entrega atual

# SDK Client 3.23.6 / build56 — relatório do teste

Leia SDK_CLIENT.md e Analysis/V3_23_6-covered-report.md. O botão Exportar relatório do teste gera um JSON nativo pequeno e somente leitura, inclusive com resultado pendente. Fontes/workflow não equivalem a IPA compilado ou teste físico.

## Histórico preservado

# SDK Client 3.23.5 / build 55 — Camadas experimental

**Estado atual:** fontes 3.23.5/build 55 baseados no marco imutável 3.23.4/build 54. Leia `SDK_CLIENT.md` e `Analysis/V3_23_5-covered-card.md` para uso, protocolo e limites do botão manual **Testar 1 carta coberta**. Compilação Apple, assinatura e validação no iPhone precisam de evidência própria da nova versão; não são comprovadas por este README.

## README histórico 3.22.1 / build 49 — preservado para continuidade

O conteúdo abaixo descreve a entrega antiga e não é o estado atual de versão, IPA disponível ou recursos do menu.

Fontes para WePlay **US 6.6.2/build 132**, com o menu SDK Client da 3.22.0 e seleção de idioma. Esta entrega de fontes acrescenta português e inglês à interface; mantém os contratos e algoritmos dos minijogos.

**O último IPA compilado e recebido continua sendo o 3.22.0/build 48, sem assinatura.** A 3.22.1/build 49 só pode ser apresentada como IPA disponível depois que a CI Apple gerar, integrar e verificar seu próprio artefato. Alterar estes fontes não atualiza o IPA anterior.

## Escolher o idioma

Abra o menu SDK Client e escolha **English** ou **Português** em **Language / Idioma**. A mudança atualiza os textos existentes, incluindo avisos, estados e acessibilidade, e salva a preferência neste aplicativo. Não é necessário fechar a partida ou reiniciar o menu.

Na primeira abertura, o menu procura português ou inglês entre os idiomas preferidos do aparelho. Se não encontrar nenhum, usa inglês. Uma escolha salva tem prioridade. Essa configuração traduz o SDK Client; não altera o idioma do próprio WePlay, nomes recebidos do jogo ou a identidade da marca.

Trocar o idioma não executa controles de jogo, não inicia uma leitura e não rearma automações. Os rótulos English e Português permanecem reconhecíveis nas duas opções.

## Usar o menu

O minijogo identificado fica primeiro e libera seus controles. Os outros permanecem recolhidos e indisponíveis. O menu cliente não exibe os antigos botões de exportação, diagnóstico ou captura.

No **Bilhar / Billiards**, o guia mostra a trajetória estimada da mesa atual. **Aim** ajusta direção e força sem disparar; **Auto** pode solicitar a tacada original, uma vez por tentativa autorizada, somente na partida atual. Toque manual, reabertura do menu e segundo plano pausam a automação. Bola na mão exige colocação manual. Rearmar é uma ação explícita; não há fila ou revanche automática.

O Alpaca conserva missão primeiro, Turbo, planejamento ampliado, poderes existentes opcionais, profundidade do raio X e demais controles da base. O uso automático de poderes pode consumir o estoque existente. Cartas conserva os marcadores da informação recebida; cartas ou cores desconhecidas continuam indicadas como desconhecidas.

## Física e limites do Bilhar

O modelo usa o impulso original `0.031*p*sqrt(p/CUE_POWER_MAX)`, geometria e propriedades físicas lidas da sessão, busca limitada de força, trajetórias diretas ou uma tabela, oclusão e proteção da bola 8. A calibração só ajusta o lançamento após três trechos qualificados, com ganho entre 0,9 e 1,1. Os casts vivos confirmam rota e primeiro contato.

A previsão é aproximada e não reproduz todo o solver PhysX. Sem rota confirmada, aguarda. Spin selecionado, tutorial/offline e contratos incompatíveis não entram na automação normal. Veja `Analysis/V3_21_0-billiards-strategy.md` para os limites da base.

## Compilação e entrega

O workflow oficial compila **`SDKtools_Fontes.zip`**, não a pasta de trabalho. Manifesto, versão, hash, tamanho do ZIP e workflow devem corresponder entre si. A base continua `release_tag=base-us-6.6.2` no repositório `SamuelErlich/sdktools-build`.

A saída esperada após a compilação da nova versão é `WePlay_US_6.6.2_SDKtools_v3_22_1_unsigned.ipa`. Esse nome é o destino planejado, não comprovação de que o IPA já existe. A instalação exige assinatura posterior.

Os testes do catálogo e do empacotador rodam em Python. A execução do catálogo Objective-C, a compilação UIKit e o framework arm64 exigem macOS/Xcode. Preferência persistida, VoiceOver, layout em telas pequenas e a troca de idioma durante estados reais precisam de teste no iPhone. Veja `SDK_CLIENT.md` e `Analysis/V3_22_1-localization.md`.

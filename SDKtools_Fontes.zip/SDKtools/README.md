# SDKtools V3.5.1 US

Correção de compilação para WePlay US 6.6.2 build 132, com identificação **3.5.1 / build 20**. Corrige o tipo de retorno de um bloco no teste Foundation de Ver cartas e alinha a assinatura usada pelo teste. Preserva a lógica e o diagnóstico da V3.5, incluindo Investigar cartas e a exportação de JavaScript do jogo 2007. Esta versão ainda não comprova a identidade das cartas ocultas.

Substitua o ZIP de fontes e o workflow pelo par deste pacote e inicie uma execução nova no Actions. Os resultados desta versão devem ser consultados no manifesto final do pacote. A compilação Apple e o comportamento no iPhone precisam ser confirmados nesta versão.

## Falha de build corrigida na V3.5.1

O log da V3.5 interrompeu o build em `Tests/card_hints_bridge_test.m:141`: um bloco foi inferido como `int (^)(void)`, enquanto a função exigia `BOOL (^)(void)`. A correção declara o retorno `BOOL` explicitamente. Também alinha a declaração do parâmetro `NSDictionary` à assinatura genérica da implementação, removendo o aviso correspondente. Os recursos JavaScript e a lógica do aplicativo são preservados.

Antes da falha, aquela execução com Xcode **16.4 / 16F6**, SDK iPhoneOS **18.5**, aprovou **59 testes Python sem skips**, **373 JavaScript**, **179 verificações C**, **286 verificações do codec**, o sanitizador web e **237 verificações da ponte de autoplay**. Isso não comprova o framework compilado: o teste de Ver cartas não chegou a executar, e os testes Foundation posteriores de investigação e exportação também ficaram pendentes.

O log tem **91.597 bytes**, SHA-256 `9e0053d588f699f712080b8d89ee39e49b5ab318ed403b17d8670d4c55814ec7`. A análise está em `Analysis/V3_5_1-build-fix.json`. A V3.5.1 precisa completar uma **nova execução do Actions**, os testes restantes e a validação no iPhone.

## Investigar cartas — recurso preservado da V3.5

Na seção **Ah, minha carta**, **Investigar cartas** inicia uma captura de diagnóstico somente do jogo `2007` observado. O botão muda para **Parar investigação**. Esta coleta registra estruturas e referências locais para análise; não confirma identidades de cartas ocultas.

Para preparar os dois arquivos:

1. Entre em **Ah, minha carta** e, se possível, inicie **Investigar cartas** antes da distribuição das cartas.
2. Feche o menu e jogue por **30–60 segundos**, registrando a distribuição e ações de compra, troca e descarte.
3. Toque em **Parar investigação**. Abra **Dados e captura → Exportar relatório** e salve `SDKtools-Capture-….json`.
4. No mesmo jogo, use **Dados e captura → Exportar código do jogo** e salve `SDKtools-GameSources-….json`. A exportação lê os fontes estáticos e mantém o relatório anterior.
5. Envie os **dois JSONs**. Um vídeo da tela do iOS é opcional.

A investigação termina ao atingir **90 segundos ou 200 amostras**. A frequência desejada é uma amostra a cada **500 ms**, sem garantia de ritmo exato. Janelas sobrepostas pausam a coleta; segundo plano ou mudança de controlador, WebView ou documento encerram o escopo. Autoplay e indicadores visuais devem permanecer interrompidos durante a captura.

O relatório mantém a investigação no bloco separado `cardInvestigation`. Referências `cpn`, `cpf`, `cpt`, `cpc`, `cpo` e `sceneEpoch` são locais à coleta, não identificadores semânticos de cartas. Valores observados precisam ser comparados ao longo das ações; ainda são necessários os novos relatórios do dispositivo.

O probe inclui ramos ativos e inativos dentro de limites, sem ativá-los. Uma frente inativa pode conter um padrão ou um estado antigo; o relatório mantém `identityVerified=false` e `hiddenIdentitiesProven=false`. Campos de componentes são observações sem semântica confirmada. A ausência de um campo também não prova inexistência, pois há limites e flags de truncamento. A revisão está em `Analysis/V3_5-card-probe-review.md`.

## Correção de compilação preservada da V3.3.1

O log enviado da V3.3 registra **12 erros de compilação**: três em `STOverlay.m` e nove em `STRecorder.m`. As propriedades de objeto com prefixo `newGame` geravam getters que o compilador interpreta como pertencentes à família Cocoa `new`. A correção troca esses nomes internos e suas referências; não muda a lógica dos recursos nem o formato público do relatório. A análise está em `Analysis/V3_3_1-build-fix.json`.

Naquela execução, Xcode **16.4 / 16F6** e SDK iPhoneOS **18.5** passaram pelos 50 testes Python, 319 testes JavaScript e testes nativos antes de falhar na compilação do framework. Esse resultado pertence à V3.3: não comprova compilação ou execução desta V3.5.1. O novo pacote ainda precisa concluir o Actions e ser validado no iPhone. O log tem 89.149 bytes e SHA-256 `906448336f2a05a1f94d6ea3258747e17e9fa62fc8d920fef2d48ef00e59891e`.

## Evidência recebida da V3.2

A mensagem no print mostra que a política anterior aguardava uma rota completa. O JSON recebido contém 96 eventos recentes, todos com autoplay desligado e Raio X ligado; não permite reproduzir uma sequência de jogadas automáticas. Nesses eventos, o Raio X chegou a desenhar 32 ícones com profundidade 2, o que orientou a redução da sobreposição visual. Duas buscas atingiram o limite de cálculo, sem comprovar ausência de um trio viável. A análise e os limites estão em `Analysis/V3_3-capture.json` e `Analysis/V3_3-autoplay.json`.

## Falha investigada na V3.1

O relatório da V3.1 analisado na atualização anterior registrou três recusas `unsupported_card_rules`, sem planejamento nem jogadas enviadas. A mensagem genérica não dizia qual campo falhou; o contador zero só era atualizado ao terminar a leitura completa e não comprova ausência de cartas. As amostras não incluem os valores de `blockInfo`.

A comparação adicional com o JavaScript original identificou exigências do leitor que não correspondem às regras do jogo: estado de bloqueio obrigatório mesmo para carta sem efeito especial, identificador com exatamente três partes e dados de posição do tabuleiro exigidos também na barra e na reserva. O campo específico que provocou a falha no iPhone não ficou registrado na V3.1. As evidências e limites estão em `Analysis/V3_2-original-rules.json`.

O Raio X compartilha essa leitura: uma rejeição retirava os indicadores antes de desenhá-los. No relatório recebido, ele estava desligado e a profundidade salva era 5; portanto, a falha de desenho com o recurso ativado ainda precisa de confirmação no aparelho.

Na V3.2, cartas sem efeito especial não precisam de `lock_state`, o ID mantém eventuais partes adicionais e a leitura de posição segue a área da carta: mesa, barra ou reserva. A validação da profundidade continua obrigatória. Uma impossibilidade de executar a jogada não apaga mais os ícones quando a leitura visual está completa e validada; nesse caso, a borda de combinação fica ausente até existir rota executável. O diagnóstico diferencia o campo rejeitado por códigos fechados, sem exportar valores de IDs ou conteúdo arbitrário. O relatório mantém a última leitura em `reading`, com status, motivo, contagens e, quando aplicável, `cardRuleDetail` e `animationDetail`. O histórico conserva até 96 mudanças de estado, ações e atualizações do Raio X, incluindo ligar, desligar e mudar a profundidade mesmo sem autoplay.

## Menu

No topo do menu, a seção **Ah, minha carta** contém **Investigar cartas** e **Ver cartas**. A seção do Crazy Alpaca reúne **Iniciar autoplay**, **Raio X**, **Meu armazém** e os atalhos dos poderes. Exportação, relatório e gravação ficam recolhidos em **Dados e captura**.

### Ver cartas — Ah, minha carta

Entre em **Ah, minha carta**, abra o menu e ative **Ver cartas** na seção de mesmo nome, no topo. O botão muda para **Ocultar cartas** quando ativado. O recurso começa somente quando você o ativa e exige o contêiner `WPCocosGameViewController` com `gameType=2007`, documento e WebView estáveis, e Cocos **2.4.5** verificado.

A leitura mostra somente ícones reais anexados ao ramo ativo da própria carta. Um ícone compacto aparece acima da carta, reutilizando os SpriteFrames reais da composição da frente. Ícones que colidiriam com outros ou pertencem a cartas cobertas são omitidos. Os nós são reutilizados na atualização ao vivo, sem deduzir faces a partir do lugar ocupado na mesa. Um verso de adversário sem identidade comprovada continua **desconhecido**. O botão não promete revelar cartas ocultas nem transforma uma imagem de verso em identidade.

Uma janela sobreposta pausa a leitura e limpa os indicadores. Trocar de contexto, colocar o app em segundo plano ou iniciar uma captura desativa o recurso. Para retomar, volte ao jogo e ative o botão novamente. A ferramenta é visual e permanece separada do autoplay do Crazy Alpaca.

O diagnóstico distingue `shown`, `unknown` e `unavailable`, com status e motivo de leitura. Os arquivos `Analysis/V3_4-card-hints-capture.json` e `.md` descrevem a evidência recebida: 260 amostras da captura com identidade nativa confirmada e 204 de outra captura compatível. Esses dados não incluem as frentes inativas e não garantem por si só uma estrutura válida no jogo em execução. O título Ah, minha carta foi confirmado pelo usuário; não foi reconhecido automaticamente pelo nome.

### Autoplay

O autoplay procura o próximo trio completo, analisando alternativas e o efeito local sobre as cartas acessíveis e a capacidade da barra. Ele deixa de exigir uma solução para toda a mesa antes da primeira ação. A sequência escolhida precisa fechar uma combinação e passar pela simulação local; não é uma escolha aleatória de cartas.

Primeiro compara trios diretos por tipo, espaço livre na barra, próximas combinações expostas e desbloqueios. Se nenhum direto for viável, procura uma sequência de desbloqueio até o primeiro trio. A busca usa fatias de até 8 ms ou 600 nós, com limite total padrão de 20 mil nós e 6 mil estados memorizados. O caminho até o primeiro trio respeita os espaços livres da barra. Se o orçamento terminar com uma sequência já comprovada, ela pode ser usada; sem trio validado, aguarda. Após completar a combinação, lê novamente e planeja o próximo trio.

Cada movimento continua usando o controle original e precisa de confirmação antes do seguinte. Mudanças no tabuleiro exigem nova leitura e validação. Não são inventadas cartas ausentes nem antecipados eventos do servidor; a análise local não comprova que toda a partida será vencida.

O intervalo desejado de leitura permanece em **100 ms**; o tempo real entre jogadas depende da animação e da confirmação do jogo. Há uma avaliação em andamento e uma ação por avaliação. Uma ação de resultado incerto continua sendo observada, sem repetição por tempo esgotado.

**Pausar**, tocar manualmente no jogo, iniciar uma captura ou colocar o app em segundo plano interrompem a automação. Toque em **Iniciar autoplay** para continuar. Usar um poder ou abrir o armazém também exige interromper as jogadas automáticas.

### Raio X

O Raio X usa as imagens das cartas já carregadas e identificadas na cena. **Camadas abaixo** permite escolher de **1 a 5**: 1 é a primeira camada coberta; valores maiores incluem as camadas até a profundidade escolhida. O padrão é 1 e a preferência fica salva. Os números indicam profundidade de cobertura, não um número presumido pelo lugar na tela.

Os ícones ficam ancorados nas cartas de origem, com até dois ícones de 24 × 27 por âncora e número de camada em fonte 12. Quando mais cartas elegíveis compartilham a mesma âncora, **+N** informa quantas ficaram omitidas pelo espaço disponível. A faixa ocupa no máximo 76 × 31 junto à borda inferior da carta; excesso e colisões são contabilizados em `hiddenByLayout`. A borda verde destaca a próxima combinação validada, incluindo cartas já na barra quando a sequência cabe. Cartas cobertas fora da profundidade selecionada não recebem uma borda solta.

O desenho usa nós próprios que não recebem toques nem alteram as cartas do jogo. Cena incompleta, movimentos e janelas sobrepostas impedem uma leitura confiável; falhas restritas ao controle da jogada não apagam os ícones quando a leitura visual e as relações de cobertura estão completas. A posição visual ainda precisa de validação no iPhone.

### Capturar Ah, minha carta

Em **Dados e captura → Capturar novo jogo**, feche o menu e abra **Ah, minha carta**. O SDKtools observa a transição por até 120 segundos e identifica o contêiner nativo com seu `gameType` real. O número não é usado para adivinhar o nome. Quando o jogo correto estiver visível, toque em **É Ah, minha carta · capturar** para confirmar e começar o relatório. Jogue por cerca de **30–60 segundos**, toque em **Parar** e depois em **Exportar relatório**. Se também quiser um vídeo, use a gravação de tela do iOS.

Essa modalidade grava somente o JSON, sem iniciar vídeo pelo interruptor de captura. Fica limitada ao controlador e à `WKWebView` identificados. Trocar de jogo ou de documento encerra o escopo. Lobby, chat e login ficam fora dessa modalidade. O relatório distingue a identificação observada da correspondência visual confirmada por você; a engine é a que o probe realmente reconhecer. Se a estrutura da cena não for suportada, o relatório informa **Cena indisponível**.

Os limites são 180 segundos, 300 amostras de toque, 720 amostras web e 32 MiB de JSON. A observação inicial consulta a cada 0,5 segundo e não identifica Crazy Alpaca como o novo jogo. Autoplay e poderes continuam restritos ao Crazy Alpaca; a nova opção coleta dados para analisar o outro jogo.

### Meu armazém e poderes

**Meu armazém** procura o slot identificado pelo próprio jogo como seu e chama o botão original uma vez. O slot precisa estar vazio, desbloqueado e com o controle habilitado. O atalho recusa donos ambíguos, slot ocupado, janela já aberta e contexto diferente. A regra de espectador permanece com o callback original. O envio do evento não comprova que a janela abriu.

Não há alteração de estoque, desbloqueio de armazém, resposta de servidor ou uso ilimitado. Os três atalhos de poderes seguem a posição original: **Esquerdo**, **Central** e **Direito**. Confira o nome e o estoque na janela do jogo antes de usar **Confirmar poder aberto**. Os efeitos e o consumo continuam sob as regras originais.

### Exportação JavaScript — jogos 60 e 2007

No histórico do Crazy Alpaca (jogo 60), a correção de Documents/Caches da V3.0 foi confirmada por um relatório exportado: **7 arquivos JavaScript completos, somando 5.364.812 bytes**, com metadados estáveis durante a leitura. O SHA-256 do JSON recebido é `ae2d416e6b90ca841b87fa37a86e040d4524e7c104efe83e0f05f5829c7dc593`. Esses arquivos originais foram usados para análise e não fazem parte deste pacote. Isso comprova a coleta daquela sessão, não o estado atual no aparelho.

O botão **Exportar código do jogo** agora atende os tipos nativos verificados **60 e 2007**. A coleta usa o documento local observado no WebView confirmado e as âncoras **Documents e Caches** fornecidas pelo sistema. O getter de recursos existente permanece específico do jogo 60; para 2007, a seleção parte do documento atual, sem chamar um getter por analogia. Formatos de pasta `2007_game` e `dev_2007_game` são permitidos, mas sua presença não foi comprovada pelos relatórios anteriores. Não há busca em outros diretórios. Permanecem a rejeição de links, caminhos fora do pacote, arquivos alterados durante a leitura e documentos remotos.

A revisão das 464 amostras anteriores identificou documentos locais, sem URLs ou caminhos completos. A tentativa registrada em `jogando.json` terminou com erro 21 antes do getter e do exportador; isso não demonstrava falha no sistema de arquivos. A evidência e seus limites estão em `Analysis/V3_5-source-export-evidence.json` e `Analysis/V3_5-source-export-review.md`. A nova elegibilidade do diretório e a exportação de 2007 precisam ser verificadas no aparelho.

A exportação lê fontes JavaScript estáticos; não executa esses arquivos nem envia os dados pela rede. O JSON descreve os bytes presentes no disco, sem afirmar que são os mesmos já executados na sessão. Os resultados da análise estática do código original ficam descritos em `Analysis/V3_1-original-rules.json`, com 31 trechos referenciados por intervalos de bytes e hashes, sem incluir os arquivos comerciais completos. Uma função cliente identificada não comprova sozinha as regras do servidor.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use o IPA original antes de assinar. O integrador exige SDKtools **3.5.1 build 20** e rejeita outra base ou versão do framework.

## Atualizar pelo Windows e GitHub

1. Extraia o pacote recebido.
2. Substitua `SDKtools_Fontes.zip` na raiz do repositório. Envie esse ZIP interno sem extrair.
3. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` do mesmo pacote. Faça commit dos dois arquivos.
4. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
5. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova.
6. Baixe **SDKtools-v3.5.1-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v3_5_1_unsigned.ipa` no GBox.
7. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V3.5.1** no menu.

ZIP e workflow formam um par verificado por tamanho e SHA-256. Se aparecer “ZIP e workflow não correspondem”, substitua ambos e inicie outra execução. O certificado fica no GBox. A opção `secret_url` usa `SDKTOOLS_BASE_IPA_URL` como link HTTPS direto para a mesma base original.

## Testar e enviar os relatórios

1. Entre no Crazy Alpaca e aguarde o tabuleiro carregar.
2. Abra **Dados e captura → Exportar código do jogo**. Salve `SDKtools-GameSources-….json` na folha de compartilhamento.
3. Se houver erro, envie a mensagem e use **Exportar relatório**, mesmo sem ter gravado uma captura. O diagnóstico inclui a pasta reconhecida e a etapa de falha, sem expor o caminho completo ou os valores da URL.
4. Para testar autoplay e Raio X, mantenha a captura do SDKtools parada. Acompanhe as primeiras jogadas e os destaques. Para filmar a automação, use a gravação de tela do iOS.
5. Se o autoplay aguardar sem jogar, exporte o relatório antes de iniciar outra captura. O histórico conserva até 96 eventos recentes.
6. Para registrar um poder ou o armazém, pause o autoplay, abra **Dados e captura**, ative o rastreamento e grave a ação manual com o estado anterior e posterior. Depois pare e exporte `SDKtools-Capture-….json`.

O exportador limita cada arquivo a 16 MiB, o conteúdo lido a 32 MiB e o JSON final a 64 MiB. Fontes ausentes, ilegíveis, alterados ou acima dos limites aparecem como coleta parcial ou falha, nunca como exportação completa.

## Formatos e limites

As capturas usam `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.5.1`. Os nomes legados `returnTrace` e `returnInspection` continuam por compatibilidade e não identificam automaticamente o poder Retornar. Fontes estáticos usam `SDKtools.GameSources`, `schemaVersion=1`.

A captura comum registra toques observados, estrutura UIKit e amostras Cocos; a investigação de cartas usa os limites próprios descritos acima. Limites da captura comum: 180 segundos, 300 amostras de toque, 720 leituras WebView ou 32 MiB de JSON compacto. O alvo de 250 ms da captura manual é separado do ciclo de autoplay e não garante quatro amostras por segundo. Cenas parciais não comprovam remoção de cartas; IDs de nós e frames são locais ao contexto.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

O decoder acima é para capturas de cena. A inspeção é limitada aos componentes identificados; trechos truncados ou ambíguos são marcados. Métodos capturados não são executados para investigá-los. Os arquivos em `Analysis/` preservam achados e limitações; os manifestos de versões anteriores só validam suas próprias versões.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v3_5_1_unsigned.ipa
```

A validação local da V3.5.1 passou com **373 testes JavaScript, 58 testes Python e 179 verificações C**; um teste Python exclusivo de macOS foi ignorado neste ambiente. O build executa testes Python, JavaScript, verificações C e testes Foundation, incluindo Ver cartas e investigação de cartas, antes de compilar o framework. Os testes Foundation exigem macOS e não foram executados localmente. O resultado requer assinatura no GBox. Os resultados finais estão em `Validation/V3_5_1-validation.json` e `VALIDACAO_PACOTE.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
bash scripts/test_native_action_policy.sh
bash scripts/test_game_source_export.sh
bash scripts/test_new_game_capture.sh
```

Compilação Apple, testes Foundation, assinatura e execução real não foram realizadas no ambiente Linux de preparação. Os testes simulados não comprovam funcionamento perfeito, velocidade real ou alinhamento visual no aparelho.

## Dados e compatibilidade

Os fontes não incluem certificado, IPA original, vídeo, capturas privadas completas nem os sete arquivos JavaScript comerciais exportados. Os relatórios não são enviados automaticamente. A exportação lê somente fontes `.js` da raiz local verificada; não lê cookies, credenciais ou clipboard. Os próprios arquivos JavaScript podem conter literais do aplicativo.

A compatibilidade foi definida para esta base: ferramentas Crazy Alpaca sobre os componentes observados em Cocos 2.4.4 e Ver cartas com verificação de Cocos 2.4.5 no jogo 2007. Recursos carregados dinamicamente podem mudar sem alteração da versão do IPA.

# SDK Client 3.23.6 / build56 — relatório do teste

Leia SDK_CLIENT.md e Analysis/V3_23_6-covered-report.md. O botão Exportar relatório do teste gera um JSON nativo pequeno e somente leitura, inclusive com resultado pendente. Fontes/workflow não equivalem a IPA compilado ou teste físico.

## Histórico preservado

# SDK Client 3.23.5 / build 55 — Camadas experimental

**Estado atual:** fontes 3.23.5/build 55 baseados no marco imutável 3.23.4/build 54. Leia `SDK_CLIENT.md` e `Analysis/V3_23_5-covered-card.md` para uso, protocolo e limites do botão manual **Testar 1 carta coberta**. Compilação Apple, assinatura e validação no iPhone precisam de evidência própria da nova versão; não são comprovadas por este README.

## README histórico 3.22.1 / build 49 — preservado para continuidade

O conteúdo abaixo descreve a entrega antiga e não é o estado atual de versão, IPA disponível ou recursos do menu.

Fontes para WePlay **US 6.6.2/build 132**, com o menu SDK Client da 3.22.0 e seleção de idioma. Esta entrega de fontes acrescenta português e inglês à interface; mantém os contratos e algoritmos dos minijogos.

**O último IPA compilado e recebido continua sendo o 3.22.0/build 48, sem assinatura.** A 3.22.1/build 49 só pode ser apresentada como IPA disponível depois que a CI Apple gerar, integrar e verificar seu próprio artefato. Alterar estes fontes não atualiza o IPA anterior.

## Escolher o idioma

Abra o menu SDK Client e escolha **English** ou **Português** em **Language / Idioma**. A mudança atualiza os textos existentes, incluindo avisos, estados e acessibilidade, e salva a preferência neste aplicativo. Não é necessário fechar a partida ou reiniciar o menu.

Na primeira abertura, o menu procura português ou inglês entre os idiomas preferidos do aparelho. Se não encontrar nenhum, usa inglês. Uma escolha salva tem prioridade. Essa configuração traduz o SDK Client; não altera o idioma do próprio WePlay, nomes recebidos do jogo ou a identidade da marca.

Trocar o idioma não executa controles de jogo, não inicia uma leitura e não rearma automações. Os rótulos English e Português permanecem reconhecíveis nas duas opções.

## Usar o menu

O minijogo identificado fica primeiro e libera seus controles. Os outros permanecem recolhidos e indisponíveis. O menu cliente não exibe os antigos botões de exportação, diagnóstico ou captura.

No **Bilhar / Billiards**, o guia mostra a trajetória estimada da mesa atual. **Aim** ajusta direção e força sem disparar; **Auto** pode solicitar a tacada original, uma vez por tentativa autorizada, somente na partida atual. Toque manual, reabertura do menu e segundo plano pausam a automação. Bola na mão exige colocação manual. Rearmar é uma ação explícita; não há fila ou revanche automática.

O Alpaca conserva missão primeiro, Turbo, planejamento ampliado, poderes existentes opcionais, profundidade do raio X e demais controles da base. O uso automático de poderes pode consumir o estoque existente. Cartas conserva os marcadores da informação recebida; cartas ou cores desconhecidas continuam indicadas como desconhecidas.

## Física e limites do Bilhar

O modelo usa o impulso original `0.031*p*sqrt(p/CUE_POWER_MAX)`, geometria e propriedades físicas lidas da sessão, busca limitada de força, trajetórias diretas ou uma tabela, oclusão e proteção da bola 8. A calibração só ajusta o lançamento após três trechos qualificados, com ganho entre 0,9 e 1,1. Os casts vivos confirmam rota e primeiro contato.

A previsão é aproximada e não reproduz todo o solver PhysX. Sem rota confirmada, aguarda. Spin selecionado, tutorial/offline e contratos incompatíveis não entram na automação normal. Veja `Analysis/V3_21_0-billiards-strategy.md` para os limites da base.

## Compilação e entrega

O workflow oficial compila **`SDKtools_Fontes.zip`**, não a pasta de trabalho. Manifesto, versão, hash, tamanho do ZIP e workflow devem corresponder entre si. A base continua `release_tag=base-us-6.6.2` no repositório `SamuelErlich/sdktools-build`.

A saída esperada após a compilação da nova versão é `WePlay_US_6.6.2_SDKtools_v3_22_1_unsigned.ipa`. Esse nome é o destino planejado, não comprovação de que o IPA já existe. A instalação exige assinatura posterior.

Os testes do catálogo e do empacotador rodam em Python. A execução do catálogo Objective-C, a compilação UIKit e o framework arm64 exigem macOS/Xcode. Preferência persistida, VoiceOver, layout em telas pequenas e a troca de idioma durante estados reais precisam de teste no iPhone. Veja `SDK_CLIENT.md` e `Analysis/V3_22_1-localization.md`.

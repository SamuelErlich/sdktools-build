# SDKtools V3.19.5 US — select_give_card

WePlay US 6.6.2/build132. SDKtools 3.19.5/build41, sobre a V3.19.4.

## Solução implementada

Os marcadores aprendem passivamente as faces que o próprio cliente recebe em `select_give_card`. Se a carta aparece de forma única numa mão oculta, a informação é conservada por até 120 s, somente naquela rodada, conexão e dono. O marcador exige vínculo atual com a mão e o nó; nenhum campo original da carta é alterado.

Anel branco externo identifica essa origem. As outras cartas continuam desconhecidas: **não é revelação de toda a mão inicial** nem fórmula de ID para cor.

## Usar

Entre numa rodada nova de Ah, minha carta e ative **Marcadores de cores antes das compras**. Não arme a captura inicial ao mesmo tempo, pois os modos continuam separados. Deixe o modo observar as compras normais; não é necessário nem implementado enviar comandos adicionais.

O painel informa quantas cores marcadas vieram de `select_give_card`. Para diagnóstico, o relatório traz `selectedKnown`, `selectedRetained`, `selectedRejected` e `selectedShown`. Se não houve exposição do campo enquanto o modo estava ativo, ele não inventará a face.

## Compilar

Atualize juntos `SDKtools_Fontes.zip` e `.github/workflows/compilar.yml`. Execute **Compilar SDKtools US** no branch/commit novo, `base_source=release`, `release_tag=base-us-6.6.2`.

Produto: `WePlay_US_6.6.2_SDKtools_v3_19_5_unsigned.ipa`. Precisa de assinatura para instalar. Compilação e replay não equivalem a validação da nova leitura no iPhone.

Alpaca, a física de Bilhar e seus recursos permanecem preservados. Consulte `Analysis/V3_19_5-select-give.md` e `Validation/V3_19_5-validation.json`.

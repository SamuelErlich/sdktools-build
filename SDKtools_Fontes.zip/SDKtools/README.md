# SDKtools V3.19.1 US — previsão de parada no bilhar

WePlay US **6.6.2/build132**. SDKtools **3.19.1/build37**.

## Correção da compilação V3.19.1

A execução V3.19 parou em uma expectativa antiga do teste: exigia três segmentos, embora a simulação finita produza cinco, incluindo as paradas. O teste foi ajustado para selecionar a caçapa pela identidade da bola e continua exigindo rejeição para o ponto fora da tela. A física e o desenho da V3.19 foram preservados.

Atualize fontes e workflow juntos e inicie uma nova execução; reexecutar o job antigo usa os arquivos antigos. Veja `Analysis/V3_19_1-build-fix.md` e `Validation/V3_19_1-validation.json`.

A V3.19.1 usa a força selecionada para estimar trajetórias e posições de parada. A simulação acompanha bolas atingidas, colisões, rebates e encaçapamentos até o repouso ou um limite explícito. Quando termina, desenha um círculo tracejado com a identificação de cada bola na posição final estimada.

**A precisão da tacada completa ainda não está 100% calibrada.** Os quatro arquivos recebidos confirmam a desaceleração e permitem conferir as paradas de trechos já em rolamento. Eles não registram a força numérica escolhida nem a velocidade angular necessária para validar toda a previsão desde antes do disparo. Esta versão acrescenta essas leituras e preserva a observação da parada para a comparação seguinte.

## O que os quatro arquivos mostraram

| Arquivo recebido | Evidência utilizada | Cuidado na comparação |
|---|---|---|
| 01 — tentativa de colisão vermelha/amarela | Colisões e paradas de quatro bolas | Movimento posterior à troca de turno excluído. |
| 02 — segunda tentativa de colisão | Outra sequência de colisões e rebates | O vídeo tem duas tacadas; o par guardado no JSON corresponde à segunda. |
| 03 — rebate na tabela | Mudanças de direção, deslizamento e rolamento | A reflexão geométrica simples não explica toda a resposta. |
| 04 — tacada direta | Parada da branca e encaçapamento da verde | A última posição da verde no JSON precede a caçapa. |

Foram encontrados **453 intervalos compatíveis com rolamento** e **oito com deslizamento**. A cada passo de 0,02 s, o rolamento observado multiplica a velocidade por 0,99. Nos trechos de deslizamento selecionados há também uma perda equivalente a 9,81 × 0,02 antes desse fator. Nas 12 caudas de rolamento analisadas, a distância calculada até o corte difere da observada em aproximadamente 0,000035 a 0,000804 unidade do mundo. **Esse resultado se refere às caudas medidas, não à exatidão de tacadas completas.**

## Cálculo incluído

- Lê `gameView.powerSld.value/max` durante a mira e a constante de potência vigente. `frame.powerValue` pode guardar a tacada anterior e não substitui a barra atual.
- Reconstrói o impulso da partida normal: `0.031 × p × sqrt(p / CUE_POWER_MAX)`, dividido pela massa viva para obter velocidade. Inclui o torque interno existente mesmo com o seletor de efeito centralizado.
- Lê massa, amortecimento linear/angular, tensor de inércia, velocidade angular, gravidade e passo físico. Só aceita o perfil físico suportado; campos ausentes não recebem força arbitrária.
- Simula deslizamento e rolamento com vetores de velocidade e rotação, colisões entre bolas e resposta às bordas. Consulta a geometria existente e avança cópias locais do estado.
- Limita o cálculo a 15 segundos, 750 passos, 64 eventos, 96 consultas à mesa, 48 segmentos e seis rebates por bola. Contatos simultâneos ou geometria incerta podem encerrar a continuação.
- Desenha a parada somente quando o cálculo inteiro termina. Bolas encaçapadas recebem resultado próprio; um ponto onde o orçamento acabou não vira marcador de repouso.

Os coeficientes de materiais vêm do cache 1084 recuperado, identificados como `materialSource=cache1084_profile`. Materiais compartilhados disponíveis são conferidos; conflito observado interrompe a previsão. Essa origem não significa que todos os materiais foram lidos ao vivo.

## Como usar

1. Entre no bilhar e espere sua vez, com as bolas paradas.
2. Ative **Ativar leitura do bilhar** e recolha o menu.
3. Mire e **puxe a barra de força acima da zona mínima**. Mantenha-a pressionada por um instante para a leitura acompanhar o valor.
4. Veja a trajetória mudar com a força e os círculos tracejados indicarem as paradas estimadas. A branca recebe **B**; as demais mantêm número e cor.
5. Solte para executar a tacada. A guia desaparece durante o movimento.
6. Para conferir o resultado, grave da escolha da força até as bolas pararem e exporte a leitura logo depois.

Sem força selecionada, o menu pede **Ajuste a força para prever a parada**. Ao encerrar por limite, mostra **Previsão de parada parcial**, sem círculos de parada. Um término normal mostra **Parada estimada · N bolas**.

Nesta versão, use o seletor de efeito centralizado. Efeito escolhido fora do centro e a física diferente do tutorial não recebem uma previsão final validada. A leitura segue as verificações de identidade, cena, turno e atualidade.

Exportar interrompe a leitura. Reativar inicia uma captura nova. O relatório preserva até 120 amostras e respeita 4 MiB. `lastShotObservation` mantém a mira, primeiro/último movimento e primeiro repouso integral observado fora desse anel, quando a associação é possível. Mudança de contexto/turno ou falta de dados encerra o registro como incompleto.

## Compilar e instalar

1. Atualize `SDKtools_Fontes.zip` na raiz do repositório e `.github/workflows/compilar.yml` com o par desta entrega.
2. Faça commit e inicie uma **nova execução** de “Compilar SDKtools US”. Reexecutar um job antigo utiliza o commit antigo.
3. Use `base_source=release`, `release_tag=base-us-6.6.2` e o asset `WePlay_US_6.6.2_base.ipa`.
4. Após aprovação do build, baixe `WePlay_US_6.6.2_SDKtools_v3_19_1_unsigned.ipa` e assine pelo fluxo habitual.
5. Confirme **V3.19.1** no menu.

Este pacote contém **fontes e workflow**, sem IPA já compilado ou assinado. Os testes Foundation e a compilação com SDK Apple precisam executar no workflow macOS. Resultados locais e essa distinção constam de `Validation/V3_19_1-validation.json`.

## Contrato do diagnóstico

| Campo | Significado |
|---|---|
| `prediction.chainVersion=2`, `model=finite` | Previsão temporal com desaceleração. |
| `prediction.complete` | Cálculo terminou com todas as bolas afetadas em repouso ou encaçapadas. Não mede acurácia. |
| `prediction.durationSeconds`, `stepCount` | Tempo simulado e quantidade de passos. |
| `prediction.finalStates[]` | Tag, posição e resultado `rest`, `pocket` ou `unknown`. |
| `prediction.truncated`, `reason` | Motivo de previsão parcial. |
| `segments[].ballTag`, `hitBallTag`, `timeSeconds` | Identidade da trajetória, alvo e instante previsto. |
| `physics` | Inputs/parâmetros observados e disponibilidade. |
| `balls[].velocity`, `angularVelocity`, `mass`, `inertiaTensor` | Dinâmica por bola, quando validada. |
| `observedDynamics` | Observação validada em estados sem guia; não autoriza desenho. |
| `lastShotObservation` | Associação de mira, movimento e parada real; pode permanecer incompleta. |

## Limites e continuidade

A transição angular, contatos simultâneos, resposta dos cantos, efeitos escolhidos pelo jogador e correções de posição/direção do Lua original ainda limitam a precisão da tacada completa. A V3.19.1 não reproduz integralmente o solver Unity nem todos esses callbacks. Não apresentar `complete=true` como prova de acerto físico.

Alpaca e os 11 recursos JavaScript foram preservados por comparação de conteúdo. **Cartas continua desativado.** A ponte ARM64/Lua e as proteções de contexto, atualidade e viewport permanecem. A previsão não executa tacadas nem escreve posições, velocidades, força ou materiais do jogo.

Os relatórios `Analysis/V3_19-*` descrevem fórmulas recuperadas, observações das quatro capturas e limites. Relatórios anteriores ficam como histórico, com sua versão original.

## Testes locais

Passaram 61 testes Lua, 28 de empacotamento, nove de propriedades Objective-C e 196 verificações da política C. Os testes Lua executam o núcleo de produção em 11 cenários derivados das capturas, com fases angulares declaradas como hipótese; quatro deles verificam parada com tolerância de 0,002 unidade. Isso valida os trechos condicionados à fase, sem provar a tacada inteira. Os testes Foundation incluem os produtores Lua reais e regressões para identidade, rotação e turno; a execução desses testes exige macOS e permanece pendente.

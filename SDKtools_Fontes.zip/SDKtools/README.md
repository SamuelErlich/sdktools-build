# SDKtools V3.17 US — leitura pelos módulos carregados do bilhar

WePlay US **6.6.2/build132**. SDKtools **3.17/build33**.

A captura real V3.16 localizou a cena `BilliardInGame` e os módulos canônicos `Billiard/Lua/Const/Enum` e `Billiard/Lua/Const/Const`, ambos com `GameType` observado igual a 1003. As tabelas não estavam disponíveis por `rawget` nos globais usados pelo leitor. Por isso, todas as 120 amostras preservadas pararam em `billiards_contract_mismatch`, antes do frame e das bolas.

Esta revisão acrescenta o caminho de leitura pelos módulos já presentes em `package.loaded`. A correção é baseada nessa captura; o funcionamento no aparelho ainda precisa ser confirmado com o novo JSON.

## O que mudou

- O leitor prefere o par global completo e válido. Na ausência dele, procura apenas as duas chaves canônicas já carregadas. Valores globais parciais precisam corresponder às mesmas tabelas do cache; conflitos interrompem a leitura.
- Confere os dois `GameType` e o descritor original da cena: `Game/BiFrameLogic` ou `Game/BiTutorialLogic`, com `PkgName=Billiard`. Passa a tabela original ao gerenciador existente.
- Resolve `Core.logicMgr` e seu método `get` por campos crus ou herança de tabelas limitada. Não executa callbacks funcionais `__index` para resolver esse caminho. Não chama `require`/`Init`, não fabrica descritores e não escreve `Enum`/`Const` no jogo.
- O novo bloco `resolution` registra a origem escolhida, tipos observados, validação do contrato e resultado da chamada ao gerenciador. O bloco `environment` anterior permanece disponível.
- Uma chamada ao gerenciador pode terminar normalmente e devolver `nil`: nesse caso, `frameCallSucceeded=true` e `frameType=nil` significam **frame indisponível**, não partida lida.

O método existente `manager:get` continua sendo chamado, uma vez por amostra que passe as validações. Seu código interno não foi recuperado; não há prova de que ele nunca inicialize um objeto em caso de ausência. A cena de bilhar precisa estar carregada antes dessa chamada. Os fontes recuperados mostram que o jogo normalmente obtém frame e tutorial durante a inicialização da partida.

O diagnóstico nunca autoriza a guia. Todas as verificações posteriores de frame, câmera, cena, identidade das bolas, movimento e mira continuam obrigatórias.

## Como compilar

1. Atualize `SDKtools_Fontes.zip` na raiz do repositório e `.github/workflows/compilar.yml` com os arquivos desta mesma entrega.
2. Faça commit dos dois juntos e inicie uma **nova execução** de “Compilar SDKtools US”. Reexecutar um job antigo usa o commit antigo.
3. Use `base_source=release` e `release_tag=base-us-6.6.2`, com `WePlay_US_6.6.2_base.ipa`.
4. Após o build passar, baixe `WePlay_US_6.6.2_SDKtools_v3_17_unsigned.ipa` e assine pelo fluxo habitual. Confira **V3.17** no menu.

Este pacote contém fontes e workflow; não contém IPA compilado. O build Apple e a assinatura precisam ocorrer no fluxo acima. Se o build falhar, envie o log completo.

## Próxima captura

1. Entre no bilhar e aguarde a mesa carregar.
2. Na sua vez, com as bolas paradas, toque em **Ativar leitura do bilhar**.
3. Recolha o menu, ajuste a mira lentamente e permaneça na mesa por cerca de **10 segundos**. Não precisa fazer uma tacada para verificar essa etapa.
4. Tire um print da mesa e outro do menu com versão e mensagem.
5. Toque em **Exportar leitura do bilhar** e envie o arquivo `SDKtools-BilliardsLive-....json` com os prints.

Exportar interrompe a leitura. Reativar limpa o histórico anterior. Mesmo sem guia, o JSON deve indicar a primeira etapa que não passou. Não precisa repetir os bundles nem uma captura de 90 segundos.

## Como interpretar

| Campo | Significado |
|---|---|
| `resolution.source=package_loaded` | O contrato foi selecionado a partir do par canônico no cache. |
| `resolution.contractStatus=selected` | Tipos, GameTypes e descritor passaram na validação. Não comprova frame. |
| `frameCallAttempted` / `frameCallSucceeded` | A chamada foi tentada / terminou sem erro Lua. |
| `frameType=table` e `gates.hasFrame=true` | Retorno aceito como frame pelo leitor. |
| `gates.hasCamera=true` | Identificador de câmera encontrado; outras verificações ainda podem falhar. |
| `balls` e `reason` | Identidades/dados disponíveis e ponto de interrupção. Snapshots incompletos preservam apenas identidades de bolas. |
| `rendering.available=true` | A camada nativa aceitou aquela guia para desenho; um print ainda é necessário para conferir alinhamento. |

`resourceGameId=20` e `gameType=1003` no topo continuam sendo identificadores do contrato estático. Os GameTypes em `environment` e `resolution` são observações quando presentes. O scan de módulos é limitado e não determina sozinho a seleção.

## Preservação e limites

Crazy Alpaca, os 11 recursos JavaScript, a ponte ARM64/Lua e a correção numérica V3.15.1 foram preservados. Cartas continua desativado.

Esta revisão não altera a física geométrica. Permanece a pendência das caçapas em layer19: a consulta atual usa mask1, que não inclui essa camada. A guia ainda não é um simulador completo de efeito, força, atrito ou resultado final. Depois de confirmar frame/bolas, é necessário corrigir e validar a consulta de caçapas e conferir o alinhamento no aparelho antes de considerar o trainer concluído.

Os testes Lua usam objetos Unity sintéticos. Eles comprovam o comportamento nesses cenários, não a execução no WePlay. Os testes Foundation foram ampliados para o workflow macOS, mas não foram executados neste ambiente Linux. Veja `Validation/V3_17-validation.json`, `Validation/V3_17-test-results.txt` e `Analysis/V3_17-resolution-contract.md`.

# SDKtools V2.2 US

Menu flutuante e captura de diagnóstico para a base US recebida. A captura é iniciada pelo usuário e reúne toques, estrutura UIKit, observações Cocos e vídeo opcional pelo ReplayKit. Esta versão não implementa raio X, solução de cartas ou autoplay.

## O que mudou

A captura real da V2.1 confirmou o funcionamento da correção da raiz: 196 de 199 respostas continham a cena. O tabuleiro cheio, porém, ultrapassou o limite de 768 nós. Em uma leitura havia 225 filhos no contêiner observado e somente 181 foram percorridos. Foram 140 amostras parciais: 132 pelo limite de nós e oito pelo orçamento de tempo. Essas contagens descrevem objetos da cena, não cartas identificadas.

A V2.2 faz três ajustes:

- Amplia o limite para 1.536 nós, 4.096 visitas e 4.096 itens na fila. Mantém profundidade 24, até 512 filhos por nó e orçamento cooperativo de 10 ms. Os cortes continuam explícitos.
- Lê metadados de cada frame de sprite uma vez por observação, aproveitando o resultado para sprites que compartilham o frame. A próxima observação refaz a leitura, para não congelar dados que mudaram.
- Remove o segundo controle de intervalo de 245 ms. A cadência fica a cargo do timer de 250 ms; o bloqueio de avaliações simultâneas continua. Na captura anterior, 178 tentativas foram barradas pelo segundo controle e o intervalo mediano ficou em 499 ms. A relação com a tolerância do timer é uma explicação sustentada pelo código, ainda a confirmar no aparelho.

O relatório passa a usar diferenças por campo entre observações, com quadros completos periódicos e referências para cenas idênticas. Uma simulação offline desse formato sobre a captura V2.1 reduziu o JSON reserializado em aproximadamente 76%, preservando as 199 listas de nós. Isso não mede o tamanho ou desempenho de uma futura captura V2.2: esta também poderá observar mais nós e mais vezes por segundo.

O teste sintético com 225 contêineres percorre 982 nós, incluindo 675 sprites, sem corte. O mesmo teste era cortado pela V2.1. A cobertura real e o desempenho da V2.2 ainda precisam ser confirmados no iPhone.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

A verificação exige o IPA original antes de assinar no GBox. O framework também verifica a identidade do app ao iniciar. US é o identificador observado; região, servidores e modos dependem do aplicativo e da conta. A base asiática não é intercambiável.

## Atualização no Windows pelo GitHub

O ZIP de fontes e o workflow entregues juntos formam um par verificado por tamanho e SHA-256.

1. Envie `SDKtools_Fontes.zip`, sem extrair, à raiz do repositório, substituindo o anterior.
2. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` deste pacote e faça commit das duas mudanças.
3. Mantenha a Release `base-us-6.6.2` com o asset original `WePlay_US_6.6.2_base.ipa`. Não é necessário apagar ou criar outra Release.
4. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova; reexecutar um job antigo pode usar fontes antigos.
5. Baixe o artifact **SDKtools-v2.2-US-IPA**, extraia seu ZIP e importe `WePlay_US_6.6.2_SDKtools_v2_2_unsigned.ipa` no GBox.
6. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Confirme **Diagnóstico V2.2** no menu após instalar.

O workflow não precisa do certificado de assinatura no GitHub. A opção alternativa `secret_url` usa o secret `SDKTOOLS_BASE_IPA_URL` com link HTTPS direto para a mesma base.

## Validar no aparelho

Grave uma sessão de 45 a 60 segundos que inclua o tabuleiro cheio. Mantenha **Incluir vídeo da tela** ligado, inicie **Gravar caminho e partida**, feche o menu e jogue normalmente. Pare a captura, salve o vídeo na prévia do iOS e exporte o JSON da mesma sessão. Se ReplayKit não estiver disponível, use a gravação de tela do iPhone e identifique o par.

As marcações **Cheguei ao Crazy Alpaca** e **Marcar início da partida** são manuais. Não acionam nem identificam automaticamente o jogo. Exporte antes de iniciar outra sessão.

A captura termina ao alcançar 180 segundos, 300 amostras de toque ou 32 MiB de JSON compacto. Há limite de 720 tentativas de leitura WebView. Um contato normalmente produz `began` e `ended`; arrastos geram eventos adicionais. O alvo de 250 ms não garante 4 Hz; carga, avaliações pendentes e limites podem diminuir a frequência. O orçamento do arquivo não é um teto de memória RAM.

## Formato do relatório

`SDKtools.Capture`, `schemaVersion=3`, `toolVersion=2.2.0`. O recurso de observação JavaScript mantém seu próprio `version=2`, pois continua retornando o mesmo tipo de observação completa antes da compactação nativa.

- `touches`: contatos observados, exceto menu SDKtools e entradas de texto.
- `snapshots`: estrutura UIKit, sem texto ou valores de campos.
- `markers`: marcações do usuário e ciclo do vídeo.
- `webSamples`: horários, contexto, geometria DOM, diagnósticos Cocos e nós completos, referenciados ou em diferenças.

O decoder `scripts/decode_capture.py` lê os formatos 2 e 3. Por padrão exporta JSONL: uma linha de cabeçalho e uma por amostra expandida. Também aceita `--format json`. Recusa sobrescrever a entrada ou um arquivo existente.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

Cada amostra tem um dos formatos:

| `sceneNodesEncoding` | Conteúdo |
|---|---|
| `full` | `sceneNodes` contém a lista completa daquela observação, que ainda pode estar marcada como parcial pelo percurso. |
| `reference` | `sceneNodesRefSequence` aponta para uma amostra anterior `full` ou `delta` no mesmo contexto. A lista é idêntica; horários e diagnósticos atuais continuam próprios. |
| `delta` | A referência aponta para a base; `sceneNodesDelta` aplica as alterações abaixo. |

`sceneNodesDelta.version=1`. `order` contém todos os IDs presentes na observação atual, em ordem exata. `added` contém linhas completas de novos IDs. `changed` contém `{nodeID, set, unset}`: `set` substitui campos de primeiro nível, inclusive objetos completos; `unset` remove campos. `null` continua um valor explícito, diferente de campo ausente. `nodeID` não pode ser alterado por um patch. Os índices `index`, `parent` e `parentID` são preservados, inclusive quando mudam com a ordem.

IDs ausentes de `order` estão ausentes somente daquela observação. Isso não significa carta removida do jogo, especialmente quando a coleta é parcial. Há quadro completo em novo contexto e no máximo a cada 20 posições de amostra; a cadeia de dependências tem no máximo 19 ligações. Uma referência nunca aponta para outra referência. Uma diferença maior que o quadro completo é substituída pelo quadro completo. O estado só avança depois de a amostra ser aceita no orçamento do relatório.

Diagnósticos de falha sem dados de cena são preservados como diagnósticos. Não viram cena vazia nem podem servir de base para uma referência.

A raiz de `director.getScene()` é estrutural: seus flags podem ser `false` ou `null` e não bloqueiam a travessia. Os descendentes inativos continuam filtrados. `descendantNodeCount`, `spriteNodeCount`, `truncated` e `truncationReasons` permitem distinguir ausência de elementos, indisponibilidade e captura parcial.

IDs de nós, frames e texturas pertencem ao contexto da WebView. `frameNameTag` é um hash de nome público, sem significado universal de carta. Nós ativos não provam visibilidade, ausência de sobreposição ou possibilidade de toque. `occlusionResolved=false` e `cardRulesKnown=false` continuam explícitos. O JSON não confirma conteúdo oculto nem regras de jogo.

UIKit usa pontos; canvas tem buffer e retângulo CSS; Cocos usa unidades locais e mundiais; o vídeo pode ter outra resolução. Compare esses espaços após conversão. O relógio é monotônico em milissegundos desde o início; `startedAtUTC` é a referência de data.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v2_2_unsigned.ipa
```

O build executa os testes Python, JavaScript e o teste nativo Foundation do codec antes de compilar o framework iPhoneOS. O integrador exige SDKtools 2.2 build 4 e a base exata, acrescenta a dependência do framework na folga verificada do cabeçalho e preserva os segmentos e bytes de código. O IPA de saída precisa de assinatura posterior.

Os testes portáveis e a reconstrução offline foram executados neste ambiente. A compilação Apple, o teste nativo Foundation e a execução V2.2 no iPhone ficam pendentes do Actions e do aparelho. A captura recebida comprova execução da V2.1, não da V2.2. Detalhes em `Validation/V2_2-validation.json` e `Analysis/Captura-US-V2_1-20261014.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
```

## Limites da observação

O observador não lê textos, cookies, armazenamento local, credenciais, clipboard ou payloads de rede. Não envia relatórios automaticamente, troca delegates do WebKit ou modifica protótipos e objetos da cena. Guarda apenas seu estado em namespace próprio, com tentativa de limpeza após avaliações pendentes. Não inclui certificados, o IPA original ou recursos comerciais extraídos.

A correspondência Crazy Alpaca/Lhama Maluca/Sheep exige concordância de navegação, marcação e vídeo. O caminho estático US está em `Analysis/WePlay-US-CrazyAlpaca.md`; o histórico asiático é somente referência histórica. Cocos 2.x e 3.x não são intercambiáveis: APIs ausentes produzem observação indisponível.

# SDKtools V3.16 US — diagnóstico do ambiente do bilhar

WePlay US **6.6.2/build132**. SDKtools **3.16/build32**.

A captura V3.15.1 mostrou execução da ponte Lua e acesso à cena BilliardInGame, mas as 120 amostras preservadas pararam em `billiards_contract_mismatch`, antes das bolas. O probe procurava Enum/Const diretamente na raiz. Repetir a mesma captura não acrescentaria a informação que falta.

Esta revisão acrescenta um diagnóstico estrutural para identificar onde os módulos já carregados guardam suas tabelas. Ela não escolhe automaticamente outro ambiente nem representa uma correção comprovada da guia.

## O que mudou

O novo objeto `environment` registra tipos crus e resolvidos por tabelas, presença de metatable, módulos Billiard já presentes em package.loaded e ambientes `_ENV` de funções carregadas quando a introspecção está disponível. Registra GameType somente quando observado, com origem e limites explícitos. Não exporta objetos vivos, endereços ou valores de jogadores.

O diagnóstico segue apenas __index que seja tabela; callbacks __index funcionais ficam marcados como bloqueados. Não executa require, inicializadores ou funções dos módulos. Pode apontar um ambiente candidato que ainda exige validação para acessar a partida.

A validação nativa foi ampliada para preservar esses campos no JSON. Um diagnóstico fora do contrato é removido; ele nunca libera a guia. O contrato original de cena/frame/câmera/bolas continua necessário.

O botão passa a se chamar **Ativar leitura do bilhar**. Quando o bloqueio de ambiente ocorre e o novo diagnóstico está presente, o menu informa **Diagnóstico do ambiente coletado. Exporte a leitura do bilhar.** Isso confirma a coleta do diagnóstico, não a leitura das bolas.

## Como compilar

1. Substitua `SDKtools_Fontes.zip` na raiz do repositório.
2. Substitua `.github/workflows/compilar.yml` pelo arquivo desta mesma entrega.
3. Faça commit dos dois juntos e inicie uma **nova execução** de “Compilar SDKtools US”. Reexecutar um job antigo usa o commit antigo.
4. Use `base_source=release` e `release_tag=base-us-6.6.2`, com `WePlay_US_6.6.2_base.ipa`.
5. Após o build passar, baixe `WePlay_US_6.6.2_SDKtools_v3_16_unsigned.ipa`, confira o hash e assine pelo fluxo habitual. Confira **V3.16** no menu.

Este pacote contém fontes e workflow. Não contém um IPA já compilado. O build Apple, assinatura e execução desta revisão dependem das etapas acima. A dependência Lua de testes é preparada pelo workflow e não é embutida no aplicativo.

## Captura que precisamos agora

1. Abra uma partida de bilhar e aguarde a mesa carregar.
2. Abra o menu SDKtools e toque em **Ativar leitura do bilhar**.
3. Recolha o menu e permaneça na mesa por cerca de **10 segundos**. Para este diagnóstico, não é necessário fazer uma tacada nem gravar90segundos.
4. Abra o menu e tire um print da versão e da mensagem exibida.
5. Toque em **Exportar leitura do bilhar**, salve e envie o arquivo `SDKtools-BilliardsLive-....json`, junto com o print. Envie também o log do build se houver falha.

Exportar interrompe o leitor. Uma nova ativação limpa o histórico anterior. Mesmo que a guia não apareça, o JSON é o resultado necessário desta etapa. Não é preciso repetir a exportação dos cinco bundles de recursos já recebidos.

## Como interpretar o novo relatório

- `environment.globals`: compara presença crua com resolução estrutural. `function_index_blocked` indica que a resolução depende de callback não executado pelo diagnóstico.
- `environment.modules`: nomes/tipos/origem e status da observação de _ENV; entradas somente de módulos já carregados.
- `environment.environments`: candidatos deduplicados, tipos de Core/Enum/Const/BiLogic, manager e descritores. `contractValid` indica compatibilidade estrutural observada; não prova uma partida ativa.
- `scanTruncated`, `modulesTruncated`, `environmentsTruncated`: indicam cobertura parcial. Ausência em scan incompleto não prova ausência no processo.
- `resourceGameId=20` e `gameType=1003` do snapshot continuam identificadores do contrato estático. Os GameTypes no bloco environment são observados quando presentes. O cabeçalho da captura registra essa distinção.

O contrato exato está em `Analysis/V3_16-environment-contract.md`. Os testes incluem um ambiente alternativo sintético e verificam que ele permanece apenas diagnóstico, sem liberar a guia.

## Preservação e limites

Crazy Alpaca e os 11 recursos JavaScript foram preservados. Cartas continua desativado. A correção numérica da V3.15.1 foi mantida. A ponte ARM64/Lua, os limites de leitura e a física geométrica não foram substituídos.

A pendência conhecida das caçapas em layer19 continua aberta: a consulta atual da guia usa mask1. Ela ocorre depois da resolução de ambiente e não explica o bloqueio capturado. Após obter dados válidos de frame/bolas, ainda será necessário validar identidade de rodada, câmera, projeção, camadas/triggers e rebotes no aparelho.

Veja `Validation/V3_16-validation.json` e `Validation/V3_16-test-results.txt` para os testes efetivamente realizados e seus limites. Os registros V3.15/V3.15.1 permanecem como histórico, sem serem apresentados como testes novos.

Limite adicional: uma máscara __metatable que seja tabela pode ocultar a estrutura real sem ser distinguível pela API padrão. Por isso, ausência no diagnóstico não prova ausência no processo.

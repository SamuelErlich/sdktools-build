# SDKtools V2.6 US

Menu flutuante para WePlay US 6.6.2 build 132. Esta versão acrescenta autoplay com leitura do tabuleiro em execução e corrige a identificação do poder central. O funcionamento da integração no iPhone ainda precisa ser confirmado.

## O que mudou

O autoplay consulta as peças carregadas na cena Cocos, considera a barra e procura uma sequência de jogadas. O acesso a peças cobertas depende dos dados que o jogo já mantém nessa cena. Isso não significa conhecimento de cartas ainda não carregadas, de conteúdo que o servidor não enviou ou do tabuleiro inteiro em qualquer fase.

A execução depende da identificação dos componentes e eventos originais. Estados incompletos, mudanças de cena e controles ambíguos não podem virar cliques presumidos. Ativar autoplay não garante vitória, ausência de falhas ou comportamento confirmado no aparelho.

O vídeo e os quatro relatórios V2.5 corrigiram uma conclusão anterior: **o poder central mostrado no vídeo é Embaralhar, não Retornar**. O atalho deve ser tratado como **poder central atual**. A posição e o desenho de um botão não identificam, sozinhos, a habilidade executada.

Em uma captura, `Prop` recebeu `count` e copiou esse valor para `num` e para o texto numérico. A contagem observada passou de 1 para 0. `onUseProp` abriu `showUsePropAlert(this.propInfo)`. Esses métodos não revelaram a regra completa de consumo nem a confirmação do efeito. **Uso ilimitado não está implementado.** Alterar apenas o número exibido não comprovaria alteração real do estoque.

As capturas e o vídeo originais não fazem parte deste pacote. Os arquivos em `Analysis/` resumem os achados. Relatórios antigos são históricos e podem conter hipóteses posteriormente corrigidas; use os achados V2.6 e esta documentação para interpretar o poder central.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use o IPA original antes de assinar no GBox. A base asiática e um IPA já modificado ou assinado não substituem essa base. O integrador exige o framework SDKtools 2.6 build 8.

## Atualizar pelo Windows e GitHub

1. Extraia o pacote recebido no computador.
2. Envie `SDKtools_Fontes.zip`, sem abrir esse ZIP interno, para a raiz do repositório e substitua o anterior.
3. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` recebido no mesmo pacote. Faça commit das duas mudanças antes de compilar.
4. Mantenha a Release `base-us-6.6.2` e o arquivo original `WePlay_US_6.6.2_base.ipa`. Não apague a Release nem troque a base.
5. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova; reexecutar um job antigo pode usar fontes antigos.
6. Baixe o artifact **SDKtools-v2.6-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v2_6_unsigned.ipa` no GBox.
7. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V2.6** no menu.

O workflow confere tamanho e SHA-256 do ZIP e dos fontes. Por isso, ZIP e YAML precisam ser enviados juntos. O certificado de assinatura não precisa ir ao GitHub. A alternativa `base_source=secret_url` usa `SDKTOOLS_BASE_IPA_URL`, com link HTTPS direto para a mesma base original.

## Uso e verificação no aparelho

Entre em Crazy Alpaca, aguarde o tabuleiro carregar e toque em **Iniciar** no autoplay. Observe a primeira sequência antes de deixá-lo continuar. Toque em **Pausar** para assumir o controle. Um toque manual no jogo ou a ida do app para segundo plano pausa a automação; toque em **Iniciar** para continuar. Habilitado não significa que um toque já tenha sido enviado ou aceito.

Para investigar uma parada do autoplay, **exporte o relatório diretamente**, sem iniciar a gravação do SDKtools. O histórico do autoplay é independente dessa gravação e conserva até 96 eventos recentes. Se for preciso detalhar a cena, mantenha o autoplay pausado, inicie uma captura manual com **Rastrear poderes**, demonstre a situação e exporte um segundo JSON. A gravação do SDKtools pausa o autoplay, e a automação não pode começar enquanto essa gravação estiver ativa. Para mostrar o autoplay funcionando, use a gravação de tela do próprio iOS. Não há promessa de leitura de cartas ainda não carregadas nem de 100% de acerto.

Para estudar os poderes, ative **Rastrear poderes** antes do uso. Deixe a confirmação original aberta por um segundo, confirme manualmente e aguarde o efeito. Registre também uma tentativa quando o estoque chegar a zero. Informe qual poder foi usado e o que mudou no tabuleiro; a posição central pode representar habilidades diferentes.

O atalho de poder abre a confirmação original. Não confirma automaticamente nem aumenta estoque. Termine ou feche uma janela original aberta antes de pedir outro atalho.

## Relatórios e limites

Formato `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=2.6.0`. O nome legado `returnTrace` é mantido por compatibilidade; não garante que o poder observado seja Retornar. O mesmo cuidado vale para `returnInspection` e relatórios históricos.

Os relatórios incluem contatos observados, estrutura UIKit, marcações e amostras da cena Cocos. A gravação tem limite de 180 segundos, 300 amostras de toque, 720 leituras WebView ou 32 MiB de JSON compacto. O alvo de leitura de 250 ms não garante quatro amostras por segundo.

O decoder expande cenas completas, referenciadas e por diferenças, preservando contexto e sequência:

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

Uma cena pode estar parcial. Ausência de nó não comprova carta removida. IDs de nós, frames e texturas são locais ao contexto. Um hash de frame não é identificador universal de carta. UIKit usa pontos, Cocos usa unidades locais e mundiais, e o vídeo pode ter outra resolução.

A inspeção de poderes é ativada separadamente e limita código, campos escalares e contador numérico aos componentes identificados. Ela não executa os métodos capturados. Trechos truncados e leituras ambíguas são marcados. A inspeção não recupera automaticamente todas as dependências de uma função.

## Compilação e níveis de teste

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v2_6_unsigned.ipa
```

O build executa testes Python, JavaScript e nativos Foundation antes de compilar o framework. O IPA gerado ainda precisa ser assinado. Os números finais dos testes portáveis estão em `Validation/V2_6-validation.json`; arquivos `V2_5-validation.json` e anteriores registram outras versões, não validam V2.6.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
```

Os testes locais verificam dados simulados e contratos dos componentes. Compilação com SDK da Apple, assinatura, instalação e execução real são etapas diferentes. Não foram realizadas no ambiente Linux de preparação deste pacote. A validação real depende do Actions e do iPhone.

## Privacidade e escopo

Os fontes não incluem certificado, IPA original, vídeo de partida ou capturas privadas. A coleta não envia relatórios automaticamente, não lê credenciais, cookies, clipboard ou conteúdo geral de entradas de texto. Código capturado no rastreamento pode conter literais. Autoplay e o atalho de poder são ações separadas da captura e precisam ser ativados pelo usuário.

A compatibilidade foi definida para a base indicada e os componentes observados em Cocos 2.4.4. Mudanças no jogo carregado dinamicamente podem exigir nova análise, mesmo que a versão do IPA continue igual.

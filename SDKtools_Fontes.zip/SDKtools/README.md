# SDKtools V3.18.1 US — guias ampliadas do bilhar

WePlay US **6.6.2/build132**. SDKtools **3.18.1/build35**.

A leitura da V3.17 funcionou nas capturas recebidas: frame, câmera e 16 bolas foram encontrados, e o usuário confirmou a guia na tela. A primeira captura mostra a limitação anterior: a linha da bola atingida chega à bola seguinte e termina. A V3.18.1 amplia essa previsão para continuar a cadeia de colisões.

## Correção da compilação V3.18.1

O log da execução 38940653922 parou nos testes Foundation: 2.589 verificações, seis falhas no cenário de três bolas. A causa estava na mesa simulada do teste: a caçapa ficava sempre oito unidades à frente de cada origem. No terceiro segmento, isso gerava y=2160 numa tela de altura1920. A validação nativa rejeitou esse ponto corretamente.

A caçapa do cenário agora fica em uma posição fixa, z=8, que projeta y=1760. Os testes conferem todos os extremos dentro da tela e continuam exigindo rejeição para o antigo ponto fora dela. A física, o desenho, a leitura e as proteções do aplicativo continuam iguais à V3.18; somente a identificação da versão mudou no código de produção.

## O que mudou na guia

- As bolas atingidas recebem trajetórias próprias. A previsão avança cópias das posições de todas as bolas no mesmo relógio, inclusive quando duas bolas previstas em movimento se encontram.
- A guia continua após colisões e rebates, até 48 segmentos, 64 eventos, 96 consultas à mesa e seis reflexões por bola. Limites e contatos ambíguos encerram a previsão com indicação de trecho parcial.
- As consultas incluem agora a camada das caçapas. As seis caçapas são classificadas pelo contrato recuperado; o tecido da mesa é excluído. Essa correção ainda precisa de confirmação no aparelho.
- A branca usa guia branca. Cada bola numerada mantém uma cor de guia ao longo dos rebates, com setas de direção, círculos nos contatos previstos e destaque nas bolas envolvidas.
- O JSON identifica a bola de cada segmento e a próxima bola atingida. A validação nativa confere essas identidades antes do desenho.
- O exportador guarda a última mira válida seguida de movimento no mesmo contexto em até um segundo, quando observada. Mantém o relatório abaixo de 4 MiB, descartando primeiro as amostras antigas quando necessário.

O visual usa linhas, setas e marcações de contato no estilo solicitado. Não foi fornecida uma referência visual do SDKPool para reproduzir exatamente sua aparência.

## Como compilar

1. Atualize `SDKtools_Fontes.zip` na raiz do repositório e `.github/workflows/compilar.yml` com os arquivos desta mesma entrega.
2. Faça commit dos dois juntos e inicie uma **nova execução** de “Compilar SDKtools US”. Reexecutar um job antigo utiliza o commit antigo.
3. Use `base_source=release`, `release_tag=base-us-6.6.2` e o asset `WePlay_US_6.6.2_base.ipa`.
4. Após o build passar, baixe `WePlay_US_6.6.2_SDKtools_v3_18_1_unsigned.ipa` e assine pelo fluxo habitual.
5. Confira **V3.18.1** no menu do aparelho.

Esta entrega contém fontes e workflow. **Não contém um IPA compilado.** O build Apple e a assinatura precisam ocorrer no fluxo acima. Se o build falhar, envie o log completo.

## Como verificar no bilhar

1. Entre na partida e aguarde sua vez, com as bolas paradas.
2. Toque em **Ativar leitura do bilhar** e recolha o menu.
3. Aponte para uma bola que possa atingir outra. Confira a guia da branca, as linhas das bolas seguintes e os rebates.
4. Tire um print **antes da tacada**. Para comparar o movimento real, grave um vídeo curto da mira até as colisões, se possível.
5. Faça a tacada e toque em **Exportar leitura do bilhar** logo após as bolas pararem.
6. Envie o JSON e o print. Um segundo caso mirando na tabela ajuda a conferir o rebate.

Exportar interrompe a leitura. Reativar limpa o histórico anterior. Não precisa repetir os bundles nem a captura de 90 segundos. A mensagem “parcial” aparece quando um limite ou contato incerto encerra a continuação; o motivo fica no JSON.

## Campos úteis

| Campo | Significado |
|---|---|
| `prediction.chainVersion=1` | Contrato da previsão em sequência; modelo `geometric`. |
| `segments[].ballTag` | Bola cujo centro percorre o segmento; tag 1 é a branca. |
| `segments[].hitBallTag` | Próxima bola tocada, presente quando `terminal=ball`. |
| `segments[].eventIndex` | Evento que encerrou o segmento; não representa segundos. |
| `prediction.affectedBallCount` | Bolas que receberam movimento previsto, incluindo a branca. |
| `prediction.truncated` / `reason` | Indicação e motivo de uma previsão parcial. |
| `rendering.available` | A camada nativa aceitou o snapshot para desenho. |
| `lastAimBeforeMotion` | Mira recente e primeiro movimento no mesmo contexto, ou `null`. |
| `counts.exportTrimmedSamples` | Amostras antigas retiradas para respeitar o tamanho do arquivo. |

`lastAimBeforeMotion` registra proximidade temporal e contexto. Não comprova que a mira foi enviada ao jogo ou que a previsão acertou. A segunda captura V3.17 perdeu o início da tacada; por isso foi acrescentada essa referência.

## Preservação e limites

Alpaca, os 11 recursos JavaScript, a ponte ARM64/Lua, as políticas numéricas e o caminho de aquisição/resolução que funcionou foram preservados. **Cartas continua desativado.**

A simulação usa geometria ideal de bolas de mesma massa, velocidades normalizadas e reflexões. Não modela integralmente força, efeito, atrito ou posições finais. A guia desaparece durante o movimento e continua sujeita às verificações de cena, câmera, identidade, mira e atualidade dos dados. As posições previstas ficam em tabelas próprias; a rotina não altera posições, velocidades ou força do jogo.

O método existente `manager:get` continua sendo chamado uma vez por amostra que passe o contrato. Seu código interno não foi recuperado; seu comportamento interno de inicialização permanece desconhecido.

## Validação desta entrega

- **56 testes Lua**, incluindo posições extraídas da captura real, **28 testes de empacotamento** e **9 testes de propriedades Objective-C** passaram neste ambiente. Também passaram as 196 verificações C da política de leitura.
- O cenário extraído da captura reproduziu os contatos iniciais branca→13→14 dentro de 0,002 unidade do mundo dos contatos exportados anteriormente. Isso confere a geometria inicial, não o resultado de uma tacada.
- Testes Foundation para o contrato e o exportador foram incluídos no build macOS; **não executados aqui**.
- A V3.18.1 ainda precisa compilar com o SDK Apple e ser testada no iPhone. O custo das consultas ampliadas, o visual, caçapas e a precisão da sequência ainda precisam dessa verificação.

Veja `Analysis/V3_18-chain-contract.md`, `Analysis/V3_18-capture-findings.md`, `Validation/V3_18_1-validation.json`, `Validation/V3_18_1-test-results.txt` e `Analysis/V3_18_1-build-fix.md`. Relatórios anteriores foram mantidos como histórico.

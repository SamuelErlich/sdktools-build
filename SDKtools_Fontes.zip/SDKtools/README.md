# SDKtools V3.0 US

Atualização para WePlay US 6.6.2 build 132, com identificação **3.0 / build 13**. O foco desta versão é formar trios com uma sequência conferida, acelerar a leitura do autoplay, mostrar as cartas cobertas identificadas e corrigir a pasta usada pela exportação JavaScript.

Substitua o ZIP de fontes e o workflow pelo par deste pacote e inicie uma execução nova no Actions. Os testes portáveis verificam os componentes alterados. A compilação Apple e o comportamento no iPhone ainda precisam ser confirmados nesta versão.

## Menu

O menu principal reúne **Iniciar autoplay**, **Raio X**, **Meu armazém** e os atalhos dos poderes. Exportação, relatório e gravação ficam recolhidos em **Dados e captura**.

### Autoplay

O planejamento lê todas as cartas identificáveis no tabuleiro, reserva e barra inferior. Uma jogada só é enviada quando existe uma sequência legal que termina em um trio e cabe na barra em cada etapa. O adapter confere a sequência novamente antes de chamar o evento original da carta. Mudanças no tabuleiro invalidam um plano antigo.

O ciclo nativo passa a consultar a página a cada **100 ms**. Essa é a frequência desejada de leitura; o intervalo entre cartas depende da animação e da confirmação do jogo. O código não acelera o relógio nem altera as animações do aplicativo. Há no máximo uma avaliação em andamento e uma ação por avaliação.

A automação confirma o resultado antes do movimento seguinte. Uma ação de resultado incerto continua sendo observada e nunca é repetida por tempo esgotado. Quando não há um trio comprovado dentro dos limites da busca, o autoplay aguarda. A busca não é uma prova de que a partida inteira será vencida.

**Pausar**, tocar manualmente no jogo, iniciar uma captura ou colocar o app em segundo plano interrompem a automação. Toque novamente em **Iniciar autoplay** para continuar. Usar um poder ou abrir o armazém também exige interromper as jogadas automáticas.

### Raio X

O Raio X usa as imagens das cartas já carregadas e identificadas na cena. Ícones pequenos mostram cartas cobertas. A borda verde indica as três cartas do trio validado, incluindo cartas já presentes na barra, quando a sequência cabe na capacidade observada.

A visualização usa nós próprios, não altera as cartas do jogo e não recebe toques. Em cena incompleta, durante movimentos ou com uma janela sobre a partida, os destaques são retirados até a próxima leitura válida. Cartas ausentes da cena ou não reconhecidas não são inventadas.

### Meu armazém e poderes

**Meu armazém** procura o slot identificado pelo próprio jogo como seu e chama o botão original uma vez. O slot precisa estar vazio, desbloqueado e com o controle habilitado. O atalho recusa donos ambíguos, slot ocupado, janela já aberta e contexto diferente. A regra de espectador permanece com o callback original. O envio do evento não comprova que a janela abriu.

Não há alteração de estoque, desbloqueio de armazém, resposta de servidor ou uso ilimitado. Os três atalhos de poderes seguem a posição original: **Esquerdo**, **Central** e **Direito**. Confira o nome e o estoque na janela do jogo antes de usar **Confirmar poder aberto**. Os efeitos e o consumo continuam sob as regras originais.

### Exportação JavaScript

A análise anterior interpretou incorretamente o valor nativo 9 como a pasta Caches. Esse valor corresponde a Documents. Os novos relatórios registram um caminho nativo válido fora de Caches, o que sustenta a correção. O caminho completo do aparelho não foi incluído nos relatórios.

O exportador agora recebe as pastas **Documents e Caches** fornecidas pelo sistema, localiza somente o pacote do documento atual e compara o recurso com o getter original do jogo 60. Não há busca em outros diretórios. Permanecem a rejeição de links, caminhos fora do pacote, arquivos alterados durante a leitura e documentos remotos.

A exportação lê fontes JavaScript estáticos; não executa esses arquivos nem envia os dados pela rede. O JSON descreve os bytes presentes no disco, sem afirmar que são os mesmos já executados na sessão. A implementação completa de `UseProp` e suas dependências ainda depende de exportação bem-sucedida no aparelho.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use o IPA original antes de assinar. O integrador exige SDKtools **3.0 build 13** e rejeita outra base ou versão do framework.

## Atualizar pelo Windows e GitHub

1. Extraia o pacote recebido.
2. Substitua `SDKtools_Fontes.zip` na raiz do repositório. Envie esse ZIP interno sem extrair.
3. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` do mesmo pacote. Faça commit dos dois arquivos.
4. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
5. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova.
6. Baixe **SDKtools-v3.0-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v3_0_unsigned.ipa` no GBox.
7. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V3.0** no menu.

ZIP e workflow formam um par verificado por tamanho e SHA-256. Se aparecer “ZIP e workflow não correspondem”, substitua ambos e inicie outra execução. O certificado fica no GBox. A opção `secret_url` usa `SDKTOOLS_BASE_IPA_URL` como link HTTPS direto para a mesma base original.

## Testar e enviar os relatórios

1. Entre no Crazy Alpaca e aguarde o tabuleiro carregar.
2. Abra **Dados e captura → Exportar código do jogo**. Salve `SDKtools-GameSources-….json` na folha de compartilhamento.
3. Se houver erro, envie a mensagem e use **Exportar relatório**, mesmo sem ter gravado uma captura. O diagnóstico inclui a pasta reconhecida e a etapa de falha, sem expor o caminho completo ou os valores da URL.
4. Para testar autoplay e Raio X, mantenha a captura do SDKtools parada. Acompanhe as primeiras jogadas e os destaques. Para filmar a automação, use a gravação de tela do iOS.
5. Se o autoplay aguardar sem jogar, exporte o relatório antes de iniciar outra captura. O histórico conserva até 96 eventos recentes.
6. Para registrar um poder ou o armazém, pause o autoplay, abra **Dados e captura**, ative o rastreamento e grave a ação manual com o estado anterior e posterior. Depois pare e exporte `SDKtools-Capture-….json`.

O exportador limita cada arquivo a 16 MiB, o conteúdo lido a 32 MiB e o JSON final a 64 MiB. Fontes ausentes, ilegíveis, alterados ou acima dos limites aparecem como coleta parcial ou falha, nunca como exportação completa.

## Formatos e limites

As capturas usam `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.0.0`. Os nomes legados `returnTrace` e `returnInspection` continuam por compatibilidade e não identificam automaticamente o poder Retornar. Fontes estáticos usam `SDKtools.GameSources`, `schemaVersion=1`.

A captura registra toques observados, estrutura UIKit e amostras Cocos. Limites: 180 segundos, 300 amostras de toque, 720 leituras WebView ou 32 MiB de JSON compacto. O alvo de 250 ms da captura manual é separado do ciclo de autoplay e não garante quatro amostras por segundo. Cenas parciais não comprovam remoção de cartas; IDs de nós e frames são locais ao contexto.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

O decoder acima é para capturas de cena. A inspeção é limitada aos componentes identificados; trechos truncados ou ambíguos são marcados. Métodos capturados não são executados para investigá-los. Os arquivos em `Analysis/` preservam achados e limitações; os manifestos de versões anteriores só validam suas próprias versões.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v3_0_unsigned.ipa
```

O build executa testes Python, JavaScript, testes portáveis do código C compartilhado e testes Foundation antes de compilar o framework. O resultado requer assinatura no GBox. Os resultados finais estão em `Validation/V3_0-validation.json` e `VALIDACAO_PACOTE.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
bash scripts/test_native_action_policy.sh
bash scripts/test_game_source_export.sh
```

Compilação Apple, testes Foundation, assinatura e execução real não foram realizadas no ambiente Linux de preparação. Os testes simulados não comprovam funcionamento perfeito, velocidade real ou alinhamento visual no aparelho.

## Dados e compatibilidade

Os fontes não incluem certificado, IPA original, vídeo ou capturas privadas completas. Os relatórios não são enviados automaticamente. A exportação lê somente fontes `.js` da raiz local verificada; não lê cookies, credenciais ou clipboard. Os próprios arquivos JavaScript podem conter literais do aplicativo.

A compatibilidade foi definida para esta base e os componentes observados em Cocos 2.4.4. Recursos carregados dinamicamente podem mudar sem alteração da versão do IPA.

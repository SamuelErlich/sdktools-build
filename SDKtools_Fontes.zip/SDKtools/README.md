# SDKtools V3.8 US — Exportador da origem das cartas

Fontes para WePlay US **6.6.2 build 132**, SDKtools **3.8 / build 23**. Esta versão acrescenta uma captura explícita do caminho das cartas antes de `GameStore.gamers[].cards` e antes do componente visual. Crazy Alpaca e o renderizador de cores da V3.7 foram preservados.

O pacote contém fontes e workflow pareados. A compilação Apple, assinatura, instalação e validação da V3.8 no iPhone ainda são necessárias.

## Compilar e instalar

1. Substitua `SDKtools_Fontes.zip` na raiz do repositório, sem extrair o ZIP interno.
2. Substitua `.github/workflows/compilar.yml` pelo workflow deste mesmo pacote. Faça commit dos dois arquivos.
3. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
4. Inicie uma nova execução de **Actions → Compilar SDKtools US → Run workflow**, com `base_source=release` e `release_tag=base-us-6.6.2`.
5. Baixe **SDKtools-v3.8-US-IPA**, extraia o ZIP e assine `WePlay_US_6.6.2_SDKtools_v3_8_unsigned.ipa` no GBox, incluindo os componentes incorporados.
6. Confira **V3.8** no menu instalado.

ZIP e workflow são conferidos por tamanho e SHA-256. O certificado permanece no seu ambiente. O pacote não contém IPA comercial, certificado, capturas privadas ou JavaScript original do jogo.

## Usar o novo exportador

1. Entre em uma partida de **Ah, minha carta**, `gameType=2007`.
2. No menu SDKtools, abra **Cartas → Rastrear origem das cartas**.
3. Jogue por **30–60 segundos**, incluindo compra e descarte por outros jogadores. A coleta desativa os indicadores de cores durante o diagnóstico, como já fazia a investigação visual.
4. Depois da jogada que deseja registrar, aguarde cerca de dois segundos. Toque **Parar rastreamento → Exportar origem**.
5. Envie o arquivo `SDKtools-Capture-….json` para análise. Exportar também encerra uma coleta ativa. Não inicie outra captura antes de exportar: uma nova captura substitui a anterior na memória.

O status deve mostrar **Rastreando origem · N eventos**. Se informar origem indisponível ou observadores encerrados, exporte mesmo assim: o JSON contém o motivo. Cada captura dura no máximo 90 s, com até 200 leituras nativas e drenagem alvo a cada 500 ms. Não há envio automático do relatório.

## Pontos observados

| Etapa no JSON | Origem |
|---|---|
| `socket_sync_result` | Resposta já decodificada de uma chamada `Socket.sync` feita pelo jogo; antes da continuação do chamador |
| `push_input` | Argumento do handler original de um evento de partida permitido, antes de repassá-lo |
| `store_input` / `store_after` | Entrada de `GameStore.sync` e estado imediatamente após a chamada original |
| `store_update_input` / `store_update_after` | Entrada de `GameStore.updatePushMessage` e estado após a chamada original |
| `store_snapshot` | Estado que já existia quando os observadores foram instalados |
| `card_setup_input` / `card_setup_after` | Entrada de `Card.setup` e seu `cardInfo` após a chamada original |

A seção `cardFlow.samples[].observation.events` é independente de `cardInvestigation`, que continua registrando a parte visual. `sequence` ordena os eventos no documento; `callID` liga o antes/depois de uma chamada. Entre chamadas, compare o ID da carta, a zona e `objectID`.

Cada carta contém apenas os campos numéricos válidos `id`, `type`, `color`, `num`, além da zona e índices locais. `present` é uma máscara: 1=id, 2=type, 4=color, 8=num. Campo ausente ou inválido não vira zero. Os limites de exportação (id 0–65535, type 0–10, color 0–4, num 0–99) são limites de diagnóstico, não prova de todas as regras do jogo.

`fo…` identifica uma referência local de objeto e `fn…` um nó local. Eles não equivalem aos IDs `cpo…`, `cpn…` ou `n…` das outras leituras. `slot` é o índice em `gamers`, não um usuário nem uma posição visual estável. `round` conta mudanças observadas em `start_time`; não é um número de rodada confirmado pelo servidor.

Os códigos permitidos em `pushEvent` são os eventos 1–19 conhecidos do bundle analisado, exceto 14 (texto rápido). Exemplos: 4=TakeCard, 5=GiveCard, 12=GameOver, 18=GiveGamerCard. Presentes, texto, nomes de usuários, tokens, URLs, IDs de jogadores e mensagens brutas não são exportados.

## Como interpretar a próxima captura

- Se uma carta já vier com `type=0,color=0,num=0` em `socket_sync_result` e mantiver esses valores no Store e no componente, o ocultamento precede o Store nesse caminho observado. Isso não prova sozinho em qual ponto do servidor ou transporte ocorreu.
- Se a resposta tiver cor válida e o Store ou o componente mudar para zero, compare o mesmo ID/objeto e os eventos intermediários para localizar a mudança.
- Se não houver eventos da resposta, houve limite, incompatibilidade ou nenhuma nova sincronização após ativar. Um snapshot inicial não substitui a resposta recebida anteriormente.
- IDs não são uma fórmula de cor. Dados de uma carta já descartada não comprovam a cor de outra carta fechada.

O rastreador observa apenas as chamadas realizadas pelo jogo após a ativação. Não faz chamadas adicionais de sincronização, não modifica cartas, não intercepta tráfego bruto e não recupera respostas anteriores. Adiciona temporariamente wrappers e uma reação à Promise original de `Socket.sync`; devolve o mesmo retorno/Promise e preserva argumentos, receptor e exceções. Essa instrumentação tem custo de execução e ainda precisa ser validada no aparelho.

A instalação exige Cocos 2.4.5, um componente Card já presente e os três exports conhecidos correspondentes. Se o contrato não corresponder, registra indisponibilidade. Só resolve os módulos conhecidos; não enumera nem varre outros módulos. Uma mudança de documento/cena, segundo plano, método substituído, limite de eventos, ou ausência de heartbeat por 1,8 s encerra os observadores. Na remoção, somente wrappers que ainda pertencem ao SDK são restaurados.

Limites: 256 cartas por evento, oito posições de mão, fila de 96 eventos/256 KiB, 4.096 eventos totais, alvo de até 3 ms por cópia, 48 KiB por drenagem JavaScript e 64 KiB após saneamento nativo. `truncated`, `dropped`, `errors`, `queued` e `nativeOmittedEvents` tornam omissões visíveis. Um trecho ainda na fila pode ser perdido ao parar ou sair da tela. Ausência de informação não demonstra ausência no cliente.

## Funções preservadas

**Alpaca:** autoplay, Raio X com profundidades 1–5, Meu armazém e atalhos de poderes mantêm a implementação anterior. A lista de hashes está em `Analysis/V3_8-card-flow.json`.

**Cores das cartas:** `Ativar cores` mantém os marcadores da V3.7: vermelho=1, azul=2, amarelo=3, verde=4; multicolorido para especiais; cinza com × para desconhecidas. O novo exportador não passa a mostrar cores ocultas. A captura V3.7 analisada registrou 374 observações de versos com os quatro campos presentes, mas type/color/num zerados.

**Suporte:** mantém o diagnóstico visual comum e a exportação do relatório. Abrir o menu não inicia coleta.

## Base e validação

Base: `com.wejoy.weplay.us`, 6.6.2/132, `Payload/weplay-us.app/weplay-us`, mínimo iOS 15; IPA de 408919954 bytes, SHA-256 `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4`.

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v3_8_unsigned.ipa
```

Resultados atuais: `Validation/V3_8-validation.json` e `VALIDACAO_PACOTE.json`. O workflow também exige os novos testes Foundation do saneamento de cardFlow. Os testes portáteis não equivalem a compilação Apple nem teste real do WebKit no iPhone. Manifestos anteriores são históricos.

Formato: `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.8.0`; a nova seção é aditiva. O código comercial analisado tem SHA-256 registrado em `Analysis/V3_8-card-flow.json`; equivalência byte a byte com o bundle carregado na próxima partida não está estabelecida. Recursos remotos podem mudar sem alteração do IPA.

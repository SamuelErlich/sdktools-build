# SDKtools V3.15.1 US — correção de validação numérica

Fontes para **WePlay US 6.6.2, build 132**; SDKtools **3.15.1, build 31**.

A V3.15.1 corrige a validação de identificadores numéricos no snapshot do bilhar. O build anterior parou no teste `overflow identity rejected`, antes de gerar o IPA. O patch separa a conferência de números com e sem sinal, preserva IDs negativos válidos e rejeita valores fora dos limites antes de convertê-los. Os testes incluem os limites numéricos e identificam o campo quando uma validação falha.

**A compilação Apple desta revisão e o funcionamento no iPhone ainda precisam ser confirmados.** O ZIP contém fontes e workflow para uma nova execução do build. Esta correção não representa validação da guia em uma partida real.

A nova captura V3.14 forneceu os cinco bundles completos da revisão 1084. O código Lua recuperado confirmou o caminho da partida, as bolas, a direção do taco e as consultas físicas da linha auxiliar. `resourceGameId=20` identifica os recursos; `GameType=1003` é o identificador declarado no módulo Lua do bilhar.

A base V3.15 implementou uma ponte nativa para observar o ambiente Lua existente, um leitor de bolas ao vivo, uma guia geométrica independente e a exportação de diagnóstico. A V3.15.1 mantém esse módulo e corrige o bloqueio da validação numérica.

## Novo módulo Bilhar

- Leitura de até 16 bolas com identidade, posição de mundo, projeção da câmera e estado de movimento.
- Guia pela direção atual do taco, com contato inicial em bola e rebotes limitados nos colisores reais da mesa.
- Retirada da guia quando o estado é inválido, a cena muda, a tacada começa, o aplicativo vai ao fundo ou o snapshot vence.
- Relatório JSON com estado da ponte e da última leitura para investigar bloqueios concretos.
- Exportação de recursos da V3.14 preservada para analisar revisões futuras.

A previsão é geométrica: não simula integralmente efeito, força, atrito, rolamento, correções do servidor ou a cadeia completa de bolas em movimento. Ela não executa tacadas nem garante a posição final.

## Uso após compilar e instalar

1. Abra o bilhar e aguarde a mesa aparecer.
2. No menu SDKtools, ative o módulo **Bilhar** e aguarde o estado informado.
3. Durante a mira, confira os marcadores, a direção da primeira linha e os pontos de contato com bolas e bordas.
4. Se não houver leitura ou a guia ficar desalinhada, exporte o diagnóstico do bilhar e envie o JSON. Ele registra o ponto da falha sem exigir outra gravação de 90 segundos.
5. Ao voltar ao Alpaca, encerre o Bilhar e ative os controles habituais do Alpaca.

O relatório técnico histórico em `Analysis/V3_15-billiards-live.md` explica o caminho, os IDs, as unidades, a previsão e os limites. A validação desta revisão fica em `Validation/V3_15_1-validation.json`; os relatórios anteriores permanecem como registro da versão a que se referem.

A análise posterior dos assets encontrou caçapas na camada de colisão 19, ausente na máscara usada pela consulta da guia. Essa pendência da previsão permanece separada desta correção de build e ainda precisa de ajuste e confirmação no aparelho. A linha não deve ser tratada como previsão garantida de encaçapamento.

## Compilação pelo GitHub

1. Substitua **SDKtools_Fontes.zip** na raiz do repositório pelo ZIP interno desta entrega.
2. Substitua **.github/workflows/compilar.yml** pelo arquivo desta mesma entrega. Faça commit dos dois juntos; o workflow rejeita um par de versões diferentes.
3. Reutilize a Release **base-us-6.6.2**, com **WePlay_US_6.6.2_base.ipa**. Não precisa comprar outro IPA.
4. Inicie uma **nova execução** de **Actions → Compilar SDKtools US**, com `base_source=release` e `release_tag=base-us-6.6.2`.
5. O workflow testa, compila ARM64, integra e publica o IPA sem assinatura em uma nova **Release**. O resumo do job informa o link; o artefato do Actions continua como alternativa.
6. Baixe **WePlay_US_6.6.2_SDKtools_v3_15_1_unsigned.ipa**, confira o SHA-256 publicado e assine pelo fluxo habitual. Confira **V3.15.1** no menu.

Uma execução antiga usa o commit antigo. O pacote não contém um IPA novo já compilado nem a base. A nova dependência Lua 5.3.6 do workflow serve apenas para testar o leitor no macOS; seus bytes são conferidos antes de compilar e ela não é embutida no aplicativo.

Para compilar manualmente no macOS, primeiro prepare a biblioteca de testes com `scripts/prepare_lua_test_library.py --output-directory CAMINHO_NOVO`, exporte `SDKTOOLS_LUA_LIBRARY` com o caminho retornado e execute `bash scripts/build_framework.sh`.

## Preservação

Os 13 arquivos centrais do **Crazy Alpaca** e os 11 recursos JavaScript existentes permanecem idênticos à V3.14. **Cartas continua desativado**, com `ST_CARD_GAME_FEATURE_ENABLED=0`.

O Bilhar lê o estado vivo e desenha sua própria camada. Não chama manualmente `AuxiliaryLineBehavior:updateAuxiliary()`, não altera as habilidades `Const.HAS_*`, não escreve a posição ou a velocidade das bolas e não envia comandos de tacada. Isso evita que a previsão interfira nas correções físicas do jogo original.

## Continuar em outro chat

Envie esta entrega completa, o IPA base original US 6.6.2/132, a captura original de recursos V3.14 e o resultado da nova execução do build. Se a V3.15.1 já foi testada no aparelho, envie também seu novo relatório JSON. A evidência estática confirma o caminho de código; a confirmação de leitura e alinhamento ao vivo depende desse teste.

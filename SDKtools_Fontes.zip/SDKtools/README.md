# SDKtools V3.19.3 US — correção do empacotamento

WePlay US 6.6.2/build132. SDKtools 3.19.3/build39.

A V3.19.2 passou pelos testes nativos, mas a montagem parou porque o leitor do bilhar cresceu para 75.363 bytes e o integrador ainda impunha 65.536 bytes. A V3.19.3 aceita até 128 KiB para esse Lua, conforme o limite que já existia na ponte nativa. Os demais recursos continuam com seus limites anteriores.

O funcionamento do bilhar permanece igual ao da V3.19.2: guia de direção com força zero ou física indisponível; previsão finita quando a força atual e o perfil físico são aceitos; marcadores de parada somente quando a simulação finita termina. A guia geométrica não indica o ponto final da tacada. Alpaca preservado, Cartas desativado.

## Compilar

1. Extraia a entrega e atualize SDKtools_Fontes.zip na raiz do repositório.
2. Atualize .github/workflows/compilar.yml com o arquivo desta mesma entrega.
3. Faça commit e inicie uma nova execução de Compilar SDKtools US. Reexecutar o job antigo usa o commit antigo.
4. Use base_source=release e release_tag=base-us-6.6.2. O asset continua WePlay_US_6.6.2_base.ipa.
5. Após o build aprovado, baixe e assine WePlay_US_6.6.2_SDKtools_v3_19_3_unsigned.ipa.

A entrega contém fontes, workflow e diagnóstico. Não contém um IPA já compilado ou assinado.

## Testar no aparelho

Confirme V3.19.3 no menu. Na sua vez, com as bolas paradas, ative a leitura e recolha o menu. Mova a mira com força zero para conferir a guia. Depois centralize o seletor de efeito, puxe a barra e segure para conferir a estimativa de parada. Se a parada continuar indisponível, exporte a leitura: physics.mismatchField, mismatchBallTag e balls[].physicalProfile ajudam a identificar o primeiro bloqueio.

## Validação

Foram executados 89 testes Python: 88 passaram e um exige macOS/Foundation. A nova regressão integra todos os recursos reais em um IPA sintético e confere os bytes resultantes nas duas estruturas de pasta aceitas. Também verifica limites, arquivos vazios, duplicados e UTF-8 inválido. Não há alterações de lógica no código nativo ou Lua; apenas o integrador e suas regressões receberam correção funcional.

O log enviado do build anterior mostra 68 testes Lua, 491 testes JavaScript e 3.020 verificações de snapshot nativo sem falha. A compilação Apple da V3.19.3 e o teste no iPhone ainda dependem da nova execução. Precisão de uma tacada inteira continua sendo estimada; esta correção não altera a calibração.

Consulte Analysis/V3_19_3-build-fix.md e Validation/V3_19_3-validation.json. Relatórios anteriores ficam preservados como histórico. O recurso Lua mantém o cabeçalho de sua revisão 3.19.2 porque foi preservado byte a byte.

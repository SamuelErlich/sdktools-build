# SDKtools V2.5 US

Menu flutuante para WePlay US 6.6.2 build132, com captura e atalho para a confirmação original de Retornar.

## O que esta versão entrega

A V2.5 amplia o estudo do limite de Retornar. **Ainda não implementa uso ilimitado.** A análise nativa localizou o carregamento dos recursos do jogo em cache: `WPDownloadManager.gameResDownloadPath:` → `web-mobile/index.html` → WKWebView. O atualizador baixa um pacote `game-js.zip`. Os scripts do tabuleiro não foram encontrados entre os scripts nomeados do IPA, e os JSONs V2.3 não continham o número do estoque nem o código da confirmação. Isso não determina se a regra é local ou validada remotamente.

**Rastrear poderes** agora inclui uma inspeção restrita de Retornar: número do badge identificado, campos numéricos/booleanos relevantes e código local dos métodos do componente e da confirmação candidata. A leitura ocorre somente após ativar o rastreamento, reconhecer a fileira original e concluir a cena sem ambiguidade. A coleta não executa esses métodos, não altera o contador e não substitui o efeito do jogo.

**Retornar: abrir confirmação** continua localizando o controle original e enviando uma vez seu evento registrado `onUseProp`. Você confirma **Usar item** no jogo. O atalho independe da gravação. Confirmação automática e uso ilimitado continuam ausentes; a integração ainda precisa de teste no iPhone.

Os relatórios V2.3 confirmaram três retornos em uma partida e um em outra, com a mesma peça voltando à posição original. O contador foi localizado como candidato pela geometria, mas seu componente Label e valor ainda precisam da captura V2.5. Não foram reaproveitados os campos `maxUndoTimes` encontrados em classes de desenho, que não têm vínculo demonstrado com Crazy Alpaca.

A análise estática e as lacunas estão em `Analysis/Return-limit-investigation.json`.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

A verificação exige o IPA original antes de assinar no GBox. O framework também verifica a identidade do app ao iniciar. US é o identificador observado; região, servidores e modos dependem do aplicativo e da conta. A base asiática não é intercambiável.

## Atualização no Windows pelo GitHub

O ZIP de fontes e o workflow entregues juntos formam um par verificado por tamanho e SHA-256.

1. Envie `SDKtools_Fontes.zip`, sem extrair, à raiz do repositório, substituindo o anterior.
2. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` deste pacote e faça commit das duas mudanças.
3. Mantenha a Release `base-us-6.6.2` com o asset original `WePlay_US_6.6.2_base.ipa`. Não é necessário apagar ou criar outra Release.
4. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova; reexecutar um job antigo pode usar fontes antigos.
5. Baixe o artifact **SDKtools-v2.5-US-IPA**, extraia seu ZIP e importe `WePlay_US_6.6.2_SDKtools_v2_5_unsigned.ipa` no GBox.
6. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Confirme **V2.5** no menu após instalar.

O workflow não precisa do certificado de assinatura no GitHub. A opção alternativa `secret_url` usa o secret `SDKTOOLS_BASE_IPA_URL` com link HTTPS direto para a mesma base.

## Captura necessária para estudar o limite

1. Entre no Crazy Alpaca e ative **Rastrear poderes** antes de usar Retornar. Pode deixar o vídeo desligado.
2. Deixe a tela parada por cerca de um segundo para registrar o estado inicial.
3. Coloque uma peça na barra. Abra Retornar pelo controle original ou pelo atalho do SDKtools.
4. Deixe a confirmação aberta por cerca de um segundo, confirme **Usar item** e aguarde a peça voltar.
5. Repita enquanto o jogo permitir. Quando o estoque ou o limite impedir outro uso, registre uma tentativa adicional e mantenha a mensagem visível por um segundo.
6. Pare e exporte o JSON. Informe quantas vezes o poder funcionou e o que apareceu na tentativa bloqueada. Não é necessário vídeo para ler o código e os números coletados.

A captura pretendida é de 60–90 segundos. O máximo continua 180 segundos, 300 amostras de toque ou 32 MiB de JSON compacto; até 720 leituras WebView. O alvo de 250 ms não garante 4 Hz. Exporte antes de iniciar outra sessão.

A próxima análise vai correlacionar a condição de entrada, a confirmação, a mudança do contador e o efeito no tabuleiro. A presença de uma função ou de um número isolado não comprova que modificar esse valor removeria a regra completa.

Com uma janela original aberta, termine ou feche essa janela antes de solicitar o atalho novamente. Uma operação WebKit pendente mantém seu bloqueio até o callback real; timeout não provoca repetição automática.

## Formato do relatório

`SDKtools.Capture`, `schemaVersion=3`, `toolVersion=2.5.0`. O recurso de observação JavaScript mantém seu próprio `version=2`, pois continua retornando o mesmo tipo de observação completa antes da compactação nativa.

- `touches`: contatos observados, exceto menu SDKtools e entradas de texto.
- `snapshots`: estrutura UIKit, sem texto ou valores de campos.
- `markers`: marcações do usuário e ciclo do vídeo.
- `webSamples`: horários, contexto, geometria DOM, diagnósticos Cocos e nós completos, referenciados ou em diferenças.

O decoder `scripts/decode_capture.py` lê os formatos 2 e 3. Por padrão exporta JSONL: uma linha de cabeçalho e uma por amostra expandida. Também aceita `--format json`. Recusa sobrescrever a entrada ou um arquivo existente.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

O campo legado `returnTrace` acompanha a coleta de controles dos poderes. `controlTrace.scope=non_board_ui_controls` explicita seu foco. Botões de peças com um único evento `touchBlock`, na geometria observada, são contados em `skippedBoardButtonCount` e não ocupam os 64 registros detalhados. As peças continuam presentes na geometria da cena.

Os eventos incluem `resolvedComponent` e `resolution`. Uma função encontrada em um único componente é uma resolução de método, não prova de que a função foi executada. Componentes ambíguos permanecem sem resolução. Os argumentos personalizados são representados somente por presença, tipo e comprimento; seu conteúdo não é exportado.

Os limites continuam em 64 controles, 8 componentes e 8 eventos por controle, identificadores de até 96 caracteres e orçamento cooperativo de 10 ms. O atalho tem uma leitura separada, limitada e sincronizada com a captura. Resultados de envio, rejeição e envio incerto são distintos. A análise dos quatro retornos e das falhas anteriores está em `Analysis/Retornar-evidence-v23.json`.

`control.returnInspection` mantém o código junto ao nó para aproveitar a compactação por diferenças. A inspeção informa `role`, `component`, `stockBadge`, `fields`, `methods`, `truncated` e `reasons`. `confirmation_candidate` significa vínculo candidato pela geometria e pelo evento registrado, não efeito confirmado. Valores não numéricos do badge são descartados. Campos são escalares relevantes, sem percorrer modelos, credenciais ou armazenamento.

O código é limitado a dois componentes por amostra, 16 métodos por componente, 8.192 unidades UTF-16 por método, 32.768 por componente e 49.152 no total. Trechos cortados são marcados. Getters de campos e métodos não são executados; uma leitura de propriedade ausente ou ambígua não vira valor zero. O código de uma função pode citar dependências externas que ainda não estejam disponíveis, portanto a inspeção não garante recuperação completa da regra.

Cada amostra tem um dos formatos:

| `sceneNodesEncoding` | Conteúdo |
|---|---|
| `full` | `sceneNodes` contém a lista completa daquela observação, que ainda pode estar marcada como parcial pelo percurso. |
| `reference` | `sceneNodesRefSequence` aponta para uma amostra anterior `full` ou `delta` no mesmo contexto. A lista é idêntica; horários e diagnósticos atuais continuam próprios. |
| `delta` | A referência aponta para a base; `sceneNodesDelta` aplica as alterações abaixo. |

`sceneNodesDelta.version=1`. `order` contém todos os IDs presentes na observação atual, em ordem exata. `added` contém linhas completas de novos IDs. `changed` contém `{nodeID, set, unset}`: `set` substitui campos de primeiro nível, inclusive objetos completos; `unset` remove campos. `null` continua um valor explícito, diferente de campo ausente. `nodeID` não pode ser alterado por um patch. Os índices `index`, `parent` e `parentID` são preservados, inclusive quando mudam com a ordem.

IDs ausentes de `order` estão ausentes somente daquela observação. Isso não significa carta removida do jogo, especialmente quando a coleta é parcial. Há quadro completo em novo contexto e no máximo a cada 20 posições de amostra; a cadeia de dependências tem no máximo 19 ligações. Uma referência nunca aponta para outra referência. Uma diferença maior que o quadro completo é substituída pelo quadro completo. O estado só avança depois de a amostra ser aceita no orçamento do relatório.

Diagnósticos de falha sem dados de cena são preservados como diagnósticos. Não viram cena vazia nem podem servir de base para uma referência.

A raiz de `director.getScene()` é estrutural: seus flags podem ser `false` ou `null` e não bloqueiam a travessia. Os descendentes inativos continuam filtrados. `descendantNodeCount`, `spriteNodeCount`, `truncated` e `truncationReasons` permitem distinguir ausência de elementos, indisponibilidade e captura parcial.

IDs de nós, frames e texturas pertencem ao contexto da WebView. `frameNameTag` é um hash de nome público, sem significado universal de carta. Nós ativos não provam visibilidade, ausência de sobreposição ou possibilidade de toque. `occlusionResolved=false` e `cardRulesKnown=false` continuam explícitos. O JSON não confirma conteúdo oculto nem regras de jogo.

UIKit usa pontos; canvas tem buffer e retângulo CSS; Cocos usa unidades locais e mundiais; o vídeo pode ter outra resolução. Compare esses espaços após conversão. O relógio é monotônico em milissegundos desde o início; `startedAtUTC` é a referência de data.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v2_5_unsigned.ipa
```

O build executa os testes Python, JavaScript e os testes nativos Foundation do codec e do sanitizador antes de compilar o framework iPhoneOS. O integrador exige SDKtools 2.5 build 7 e a base exata, acrescenta a dependência do framework na folga verificada do cabeçalho e preserva os segmentos e bytes de código. O IPA de saída precisa de assinatura posterior.

Os testes portáveis verificam contratos do atalho, bloqueios, despacho único, variações reais de atlas e coleta dos popups. A compilação Apple, os testes nativos Foundation e a execução V2.5 no iPhone dependem do Actions e do aparelho. Os relatórios recebidos comprovam a execução da V2.3, não desta integração. Detalhes em `Validation/V2_5-validation.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
```

## Limites da observação

A captura não lê texto geral da interface, cookies, armazenamento local, credenciais, clipboard ou payloads de rede. No rastreamento explícito, a exceção é o badge numérico de Retornar e o código local limitado dos controles identificados; o código pode conter literais. A captura não dispara ações. O atalho **Retornar: abrir confirmação** é separado e exige um toque explícito no menu; ele chama somente o evento original do controle validado. Não confirma automaticamente, não altera estoque e não reposiciona peças. Relatórios não são enviados automaticamente. Os fontes não incluem certificados, o IPA original ou recursos comerciais extraídos.

A correspondência Crazy Alpaca/Lhama Maluca/Sheep exige concordância de navegação, marcação e vídeo. O caminho estático US está em `Analysis/WePlay-US-CrazyAlpaca.md`; o histórico asiático é somente referência histórica. Cocos 2.x e 3.x não são intercambiáveis: APIs ausentes produzem observação indisponível.

## Contrato consultado

A API oficial do Cocos 2.4 expõe `Button.clickEvents` e os campos de `Component.EventHandler`. Os relatórios V2.3 identificaram o evento `onUseProp`. O atalho usa o emissor do evento original e valida novamente o controle em execução; não chama um nome de método presumido.

- https://docs.cocos.com/creator/2.4/api/en/classes/Button.html
- https://docs.cocos.com/creator/2.4/api/en/classes/Component.EventHandler.html

- https://docs.cocos.com/creator/2.4/api/en/classes/Label.html

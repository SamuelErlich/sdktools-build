# SDKtools V3.1 US

Atualização para WePlay US 6.6.2 build 132, com identificação **3.1 / build 14**. O foco desta versão é ampliar o planejamento por rotas e permitir escolher a profundidade das cartas cobertas no Raio X. O menu preserva os controles de autoplay, poderes e armazém.

Substitua o ZIP de fontes e o workflow pelo par deste pacote e inicie uma execução nova no Actions. Os resultados desta versão devem ser consultados no manifesto final do pacote. A compilação Apple e o comportamento no iPhone precisam ser confirmados nesta versão.

## Menu

O menu principal reúne **Iniciar autoplay**, **Raio X**, **Meu armazém** e os atalhos dos poderes. Exportação, relatório e gravação ficam recolhidos em **Dados e captura**.

### Autoplay

O planejamento lê todas as cartas identificáveis no tabuleiro, reserva e barra inferior e procura uma rota completa para o estado observado. Quando a quantidade de cada tipo é múltipla de três, a rota precisa zerar as cartas e a barra. Quando há sobras por tipo, ela precisa formar o máximo de trios permitido pela contagem de cada tipo naquele conjunto, deixando menos de três cartas de cada tipo; a última ação precisa completar o último trio. Isso evita aceitar apenas uma combinação imediata que comprometa o restante da rota.

Antes de agir, o adapter simula novamente a rota inteira, conferindo ordem de desbloqueio, capacidade da barra e remoção de trios. Depois de cada evento original da carta, a ação seguinte depende da confirmação do resultado. Mudanças externas exigem nova validação; se a rota deixar de cumprir o objetivo, o cálculo recomeça. O término da rota local não equivale à vitória confirmada pelo jogo.

O ciclo nativo passa a consultar a página a cada **100 ms**. Essa é a frequência desejada de leitura; o intervalo entre cartas depende da animação e da confirmação do jogo. O código não acelera o relógio nem altera as animações do aplicativo. Há no máximo uma avaliação em andamento e uma ação por avaliação.

A busca conserva seu progresso entre consultas: por padrão, o orçamento de busca por fatia é de 8 ms ou 600 nós, com limite total de 120 mil nós. A leitura e a validação do estado também consomem tempo. **Auto calculando a saída** indica o cálculo em andamento. Sem uma rota completa comprovada, nenhum movimento é enviado. Se o limite for atingido ou o estado observado não tiver solução dentro das regras aceitas, o autoplay informa o motivo e aguarda mudança do estado ou um novo início. A busca é limitada e pode deixar de encontrar uma rota existente.

Uma ação de resultado incerto continua sendo observada e nunca é repetida por tempo esgotado. O plano abrange somente as cartas carregadas e verificadas, sem inventar cartas ocultas ausentes, antecipar eventos do servidor ou garantir a vitória.

**Pausar**, tocar manualmente no jogo, iniciar uma captura ou colocar o app em segundo plano interrompem a automação. Toque novamente em **Iniciar autoplay** para continuar. Usar um poder ou abrir o armazém também exige interromper as jogadas automáticas.

### Raio X

O Raio X usa as imagens das cartas já carregadas e identificadas na cena. Ao ativá-lo, o controle **Camadas abaixo** permite escolher de **1 a 5**: 1 mostra a primeira camada coberta; valores maiores incluem as camadas até a profundidade escolhida. O padrão é 1 e a seleção fica salva no dispositivo. Cada ícone mostra a arte da carta e seu número de profundidade. A profundidade vem das relações de cobertura verificadas, não de uma posição presumida na tela.

Os indicadores são distribuídos sem sobreposição dentro da área observada; quando um indicador precisa se afastar da carta, uma linha o liga à origem. Se não houver espaço para todos, a limitação é registrada no diagnóstico. A borda verde indica a próxima combinação da rota validada, incluindo cartas já presentes na barra, quando a sequência cabe na capacidade observada. Para uma carta coberta, a borda fica no indicador visível; camadas fora da seleção ou indicadores sem espaço não recebem uma borda solta. Por isso, menos de três bordas podem estar visíveis.

A visualização usa nós próprios, não altera as cartas do jogo e não recebe toques. Em cena incompleta, durante movimentos ou com uma janela sobre a partida, os destaques são retirados até a próxima leitura válida. Cartas ausentes da cena ou não reconhecidas não são inventadas.

### Meu armazém e poderes

**Meu armazém** procura o slot identificado pelo próprio jogo como seu e chama o botão original uma vez. O slot precisa estar vazio, desbloqueado e com o controle habilitado. O atalho recusa donos ambíguos, slot ocupado, janela já aberta e contexto diferente. A regra de espectador permanece com o callback original. O envio do evento não comprova que a janela abriu.

Não há alteração de estoque, desbloqueio de armazém, resposta de servidor ou uso ilimitado. Os três atalhos de poderes seguem a posição original: **Esquerdo**, **Central** e **Direito**. Confira o nome e o estoque na janela do jogo antes de usar **Confirmar poder aberto**. Os efeitos e o consumo continuam sob as regras originais.

### Exportação JavaScript

A correção de Documents/Caches da V3.0 foi confirmada por um novo relatório exportado: **7 arquivos JavaScript completos, somando 5.364.812 bytes**, com metadados estáveis durante a leitura. O SHA-256 do JSON recebido é `ae2d416e6b90ca841b87fa37a86e040d4524e7c104efe83e0f05f5829c7dc593`. Esses arquivos originais foram usados para análise e não fazem parte deste pacote. Isso comprova a coleta daquela sessão, não o estado atual no aparelho.

O exportador agora recebe as pastas **Documents e Caches** fornecidas pelo sistema, localiza somente o pacote do documento atual e compara o recurso com o getter original do jogo 60. Não há busca em outros diretórios. Permanecem a rejeição de links, caminhos fora do pacote, arquivos alterados durante a leitura e documentos remotos.

A exportação lê fontes JavaScript estáticos; não executa esses arquivos nem envia os dados pela rede. O JSON descreve os bytes presentes no disco, sem afirmar que são os mesmos já executados na sessão. Os resultados da análise estática do código original ficam descritos em `Analysis/V3_1-original-rules.json`, com 31 trechos referenciados por intervalos de bytes e hashes, sem incluir os arquivos comerciais completos. Uma função cliente identificada não comprova sozinha as regras do servidor.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

Use o IPA original antes de assinar. O integrador exige SDKtools **3.1 build 14** e rejeita outra base ou versão do framework.

## Atualizar pelo Windows e GitHub

1. Extraia o pacote recebido.
2. Substitua `SDKtools_Fontes.zip` na raiz do repositório. Envie esse ZIP interno sem extrair.
3. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` do mesmo pacote. Faça commit dos dois arquivos.
4. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
5. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova.
6. Baixe **SDKtools-v3.1-US-IPA**. Extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v3_1_unsigned.ipa` no GBox.
7. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Instale e confira **V3.1** no menu.

ZIP e workflow formam um par verificado por tamanho e SHA-256. Se aparecer “ZIP e workflow não correspondem”, substitua ambos e inicie outra execução. O certificado fica no GBox. A opção `secret_url` usa `SDKTOOLS_BASE_IPA_URL` como link HTTPS direto para a mesma base original.

## Testar e enviar os relatórios

1. Entre no Crazy Alpaca e aguarde o tabuleiro carregar.
2. Abra **Dados e captura → Exportar código do jogo**. Salve `SDKtools-GameSources-….json` na folha de compartilhamento.
3. Se houver erro, envie a mensagem e use **Exportar relatório**, mesmo sem ter gravado uma captura. O diagnóstico inclui a pasta reconhecida e a etapa de falha, sem expor o caminho completo ou os valores da URL.
4. Para testar autoplay e Raio X, mantenha a captura do SDKtools parada. Acompanhe as primeiras jogadas e os destaques. Para filmar a automação, use a gravação de tela do iOS.
5. Se o autoplay aguardar sem jogar, exporte o relatório antes de iniciar outra captura. O histórico conserva até 96 eventos recentes.
6. Para registrar um poder ou o armazém, pause o autoplay, abra **Dados e captura**, ative o rastreamento e grave a ação manual com o estado anterior e posterior. Depois pare e exporte `SDKtools-Capture-….json`.

O exportador limita cada arquivo a 16 MiB, o conteúdo lido a 32 MiB e o JSON final a 64 MiB. Fontes ausentes, ilegíveis, alterados ou acima dos limites aparecem como coleta parcial ou falha, nunca como exportação completa.

## Formatos e limites

As capturas usam `SDKtools.Capture`, `schemaVersion=3`, `toolVersion=3.1.0`. Os nomes legados `returnTrace` e `returnInspection` continuam por compatibilidade e não identificam automaticamente o poder Retornar. Fontes estáticos usam `SDKtools.GameSources`, `schemaVersion=1`.

A captura registra toques observados, estrutura UIKit e amostras Cocos. Limites: 180 segundos, 300 amostras de toque, 720 leituras WebView ou 32 MiB de JSON compacto. O alvo de 250 ms da captura manual é separado do ciclo de autoplay e não garante quatro amostras por segundo. Cenas parciais não comprovam remoção de cartas; IDs de nós e frames são locais ao contexto.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

O decoder acima é para capturas de cena. A inspeção é limitada aos componentes identificados; trechos truncados ou ambíguos são marcados. Métodos capturados não são executados para investigá-los. Os arquivos em `Analysis/` preservam achados e limitações; os manifestos de versões anteriores só validam suas próprias versões.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v3_1_unsigned.ipa
```

O build executa testes Python, JavaScript, testes portáveis do código C compartilhado e testes Foundation antes de compilar o framework. O resultado requer assinatura no GBox. Os resultados finais estão em `Validation/V3_1-validation.json` e `VALIDACAO_PACOTE.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
bash scripts/test_native_action_policy.sh
bash scripts/test_game_source_export.sh
```

Compilação Apple, testes Foundation, assinatura e execução real não foram realizadas no ambiente Linux de preparação. Os testes simulados não comprovam funcionamento perfeito, velocidade real ou alinhamento visual no aparelho.

## Dados e compatibilidade

Os fontes não incluem certificado, IPA original, vídeo, capturas privadas completas nem os sete arquivos JavaScript comerciais exportados. Os relatórios não são enviados automaticamente. A exportação lê somente fontes `.js` da raiz local verificada; não lê cookies, credenciais ou clipboard. Os próprios arquivos JavaScript podem conter literais do aplicativo.

A compatibilidade foi definida para esta base e os componentes observados em Cocos 2.4.4. Recursos carregados dinamicamente podem mudar sem alteração da versão do IPA.

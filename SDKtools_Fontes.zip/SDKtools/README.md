# SDKtools V3.11 US — Injetar cores e reler raiz

Fontes para WePlay US **6.6.2 build 132**, SDKtools **3.11 / build 26**. O botão nativo **Injetar cores** chama a ponte existente, instala a rotina JavaScript na WebView e solicita leitura imediata. Depois passa a **Reler raiz**, que solicita outra leitura sem reinstalar a rotina. A trava existente permite somente uma avaliação física por vez; se ocupada, o botão aguarda a conclusão.

A rotina associa cada carta ao objeto atual no Store, à mão e ao nó visual. Uma carta com frente oculta só recebe marcador colorido quando existe cor válida no componente e o vínculo com a raiz atual está confirmado. `type=0` e campos zerados continuam desconhecidos. A escrita instala o runtime e desenha nós pertencentes ao SDK; não altera os campos do jogo para inventar uma cor.

Crazy Alpaca e o exportador de respostas V3.10 foram preservados. Este pacote contém **fontes e workflow**, ainda sem compilação Apple, assinatura ou validação da V3.11 no iPhone.

## Usar Injetar cores e Reler raiz

Entre em Ah, minha carta e abra **SDKtools → Cartas → Injetar cores**. O painel fecha e a leitura é solicitada imediatamente. Ao abrir o menu novamente, **Reler raiz** força uma nova leitura do estado atual pela mesma ponte. **Desativar cores** encerra os marcadores. A atualização automática continua enquanto a função está ativa e o contexto permanece válido.

A associação exige o mesmo objeto em `Card.cardInfo` e `GameStore.gamers[].cards`, além de `HandArea.gamer`, `HandArea.uid` e `HandArea.itemsNode` compatíveis com a mão atual. ID igual sozinho, campos copiados ou textura antiga não bastam. O vínculo é rechecado após a leitura da geometria e após criar o marcador. Troca de objeto, mão, array, índice, valores, cena ou rodada invalida a leitura anterior. A lista raiz é refeita em cada ciclo, sem guardar cores históricas por ID ou nó.

O relatório de suporte inclui `rootStatus`, `rootBound`, `rootKnown`, `rootUnknown`, `rootUnbound` e `rootShown`. São contagens do ciclo atual; `rootKnown` pode incluir cartas próprias/já conhecidas e não comprova que todas as mãos fechadas foram reveladas. Referências de objetos e UIDs não são exportados. O diagnóstico de captura de 90 segundos abaixo continua separado e desativa os indicadores enquanto coleta.

## Caminho nativo e conferência da V3.9

`STOverlay.injectCardRoot` → `STRecorder.injectCardColorsAndReadRoot` → ativação ou `cardHintsTick` → `STWebProbe.performCardHintsInWebView…` → `WKWebView.evaluateJavaScript:completionHandler:` → `card_hints.tick` → `card_root.resolve`.

Esse caminho foi conferido e implementado nos fontes. O build existente compila para **arm64-apple-ios15.0**. O material V3.9 disponível contém fontes e workflow, sem framework compilado. Portanto, a conferência desse trecho no binário ARM64 V3.9 continua pendente do framework/IPA correspondente. O IPA base não serve como prova do framework V3.9.

## Compilar e instalar

1. Substitua `SDKtools_Fontes.zip` na raiz do repositório, sem extrair o ZIP interno.
2. Substitua `.github/workflows/compilar.yml` pelo workflow deste mesmo pacote. Faça commit dos dois arquivos.
3. Mantenha a Release `base-us-6.6.2` com `WePlay_US_6.6.2_base.ipa`.
4. Inicie uma nova execução de **Actions → Compilar SDKtools US → Run workflow**, com `base_source=release` e `release_tag=base-us-6.6.2`.
5. Baixe **SDKtools-v3.11-US-IPA**, extraia o ZIP e assine `WePlay_US_6.6.2_SDKtools_v3_11_unsigned.ipa` no GBox, incluindo os componentes incorporados.
6. Confira **V3.11** no menu instalado.

ZIP e workflow são conferidos por tamanho e SHA-256. O pacote não contém IPA comercial, certificado, capturas privadas ou JavaScript original do jogo.

## Capturar

1. Entre em uma partida de **Ah, minha carta**, `gameType=2007`.
2. Abra **SDKtools → Cartas → Capturar cores (inject)**.
3. Jogue por 30–60 segundos, incluindo compra, descarte e ações de punição/troca quando ocorrerem. O limite é 90 segundos. A coleta desativa temporariamente os indicadores visuais, como no diagnóstico anterior.
4. Após a jogada desejada, aguarde cerca de dois segundos e toque **Parar rastreamento → Exportar origem**.
5. Envie `SDKtools-Capture-….json`. Exportar encerra a coleta; uma nova captura substitui a anterior na memória, portanto exporte antes de reiniciar.

O status mostra **Inject de cores · N respostas · N eventos**. **Coleta parcial** significa que o observador da entrada não pôde ser instalado; os outros pontos continuam disponíveis. Zero respostas não prova ausência de dados no servidor ou no cliente. Exporte também se houver erro, pois o motivo é incluído. A drenagem alvo ocorre a cada 500 ms, até 200 leituras nativas. Não há envio automático.

## Caminho observado

| Etapa | Dado observado |
|---|---|
| `socket_decoded_response` | Argumento do resolvedor após JSON/Brotli original, antes das continuações de Promise; `command` identifica uma resposta permitida |
| `socket_sync_result` | Retorno da sincronização iniciada pelo próprio jogo |
| `push_input` | Evento de partida permitido antes do handler original |
| `store_input` / `store_after` | Entrada e estado após `GameStore.sync` |
| `store_update_input` / `store_update_after` | Entrada e estado após `GameStore.updatePushMessage` |
| `store_snapshot` | Estado existente na ativação |
| `card_setup_input` / `card_setup_after` | Entrada de `Card.setup` e `cardInfo` após a chamada |

Comandos observados: `CMD_SYNC`, `CMD_ENTER_GAME`, `CMD_PLAY_CARD`, `CMD_SELECT_COLOR`, `CMD_DOUBT`, `CMD_CHOOSE_GAMER`, `CMD_END_LOOK_OVER`, `CMD_GIVE_CARD`, `CMD_UNO`, `CMD_CATCH` e `CMD_CANCEL_AUTO`. São somente respostas a chamadas que o jogo já faz após a ativação; nenhuma requisição é gerada pelo inject.

| Caminho | Zona no relatório |
|---|---|
| `gamers[].cards` | `hand`, com `slot` local |
| `cards` / `card` | `event` / `draw` |
| `look_over_cards` / `select_give_card` | `look_over` / `selected` |
| `punish.cards` | `punish`, com slot somente se identificado |
| `punish_list[].cards` | `punish_list`, com `group` e slot quando identificado |
| `rank_infos[].cards` | `result_rank`, com `group` |
| `game_over_info.rank_infos[].cards` | `result_sync`, com `group` |

Os caminhos aninhados são concretos no bundle analisado, mas sua presença/cor em uma nova partida ainda precisa ser medida. O original trata `punish_list[].cards` no fluxo de dúvida e `punish.cards` nos fluxos de seleção/entrega; isso não demonstra acesso às mãos dos oponentes.

## Ler as cores

A seção é `cardFlow.samples[].observation`, versão **3**. Cada carta preserva campos numéricos válidos `id`, `type`, `color`, `num`, sua zona e índices locais. `present` é uma máscara: 1=id, 2=type, 4=color, 8=num. Campo ausente ou inválido não vira zero. Limites de exportação: id 0–65535, type 0–10, color 0–4, num 0–99; não são prova de todas as regras do jogo.

| `colorState` | Interpretação |
|---|---|
| `known` | Tipo colorido válido e cor 1–4; número não é necessário |
| `special` | Tipo 4, 6 ou 10 com cor 0–4; não equivale a uma cor fixa |
| `unknown` | Verso (`type=0`) sem cor residual válida |
| `candidate` | Cor não zero com verso ou tipo ausente; apenas pista |
| `unavailable` | Informação insuficiente ou inválida |

Mapa: **1 vermelho, 2 azul, 3 amarelo, 4 verde**. Zero exige considerar o tipo. `selectedColor` é a cor do evento/estado, não a de cada carta; não é gerada a partir de `Card.setup`. `eventCardType` também é metadado de evento. `colorCounts` conta observações repetidas naquele evento, não cartas únicas nem oponentes revelados. Classificações e totais são recalculados após saneamento nativo.

`payloadFields` e `resultFields` distinguem contêiner ausente, nulo, array, objeto, inválido e accessor. Uma lista vazia tem `presence=array,count=0`. Getters não são executados para extrair os campos. `group` é um índice local, não um assento. Para punições, UID duplicado ou desconhecido deixa slot ausente; nenhum UID é exportado.

`sequence` ordena o registro e `callID` liga o antes/depois de uma chamada. `objectID` (`fo…`) e `nodeID` (`fn…`) são aliases locais, distintos dos aliases da investigação visual. `slot` usa a ordem de gamers, não uma posição fixa de avatar. `round` conta mudanças observadas de start_time, não um identificador de rodada do servidor. O inject não reutiliza cores históricas nem interpreta ID como fórmula de cor.

`afterGameOver` registra se o evento 12 foi observado desde o início local; falso não prova partida ativa quando a captura começou tarde. `observedState` vem do payload ou do Store; estado 7 corresponde a Ended no bundle analisado. Resultados do snapshot inicial podem estar antigos. Uma carta revelada somente no resultado não comprova disponibilidade durante o jogo.

## Evidência e limites

Na captura V3.9 mais recente, 23 respostas foram observadas sem falhas do decoder. As 260 observações de cartas fechadas nesse ponto já continham type/color/num zerados. O novo inject amplia os caminhos e comandos examinados para verificar outras entradas; não transforma esses zeros em cores reais. Nenhuma garantia de x-ray completo decorre desta versão.

A instalação exige Cocos 2.4.5, Card presente e contratos conhecidos de Card/GameStore/Socket. Usa a decodificação original: Base64 e Brotli são etapas de codificação/compressão, não demonstração de uma cifra de cartas quebrada. Os marcadores estruturais de onMessage não provam identidade byte a byte do bundle remoto. Métodos nativos de WebView confirmam o caminho de carregamento/execução JavaScript; símbolos AES no IPA não estabelecem ligação com essas cartas.

Os wrappers mantêm argumentos, receptor, retorno/Promise e exceções. O resolvedor é restaurado antes da chamada original. Cena/documento alterado, segundo plano, método substituído, limite de eventos ou ausência de heartbeat por 1,8 s encerram os observadores. Ao remover, somente wrappers ainda pertencentes ao SDK são restaurados. Requisições anteriores à ativação não são recuperadas. O custo e o comportamento real do WebKit ainda exigem teste no aparelho.

Limites: 16 descritores de payload, 19 de resultado, 32 resolvedores pendentes, 256 cartas por evento, oito jogadores, fila de 96 eventos/256 KiB, 4.096 eventos totais, alvo de 3 ms por cópia, 48 KiB por drenagem e 64 KiB após saneamento nativo. Conferir `truncated`, `dropped`, `errors`, `queued`, `decoderMissed` e `nativeOmittedEvents`. Parar pode perder o trecho ainda não drenado.

## Preservação e validação

Crazy Alpaca: autoplay, Raio X, profundidades, armazém e poderes preservados. Os hashes dos 13 arquivos Alpaca estão em `Analysis/V3_11-card-flow.json`. O renderizador de cartas agora aceita também o vínculo atual com a raiz, mantendo a paleta, posicionamento, limpeza e limite de duração do marcador.

Base: `com.wejoy.weplay.us`, 6.6.2/132, `Payload/weplay-us.app/weplay-us`, mínimo iOS 15. IPA de 408919954 bytes; SHA-256 `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4`.

Validação local: 465 testes Node, 58 Python aprovados (um exclusivo de macOS não executado), 179 verificações C. O observador de respostas permanece byte a byte igual à V3.10, que já passou em 22 casos do Socket original com transporte simulado em JSON/Brotli. Foram adicionados 18 testes da raiz e um da composição real da injeção. Testes Foundation do comando nativo e da ponte serão exigidos no workflow Apple; não foram executados localmente. Esses resultados não substituem compilação, assinatura ou teste no iPhone.

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v3_11_unsigned.ipa
```

Relatórios: `Validation/V3_11-validation.json`, `Analysis/V3_11-card-flow.json` e `VALIDACAO_PACOTE.json`. Manifestos anteriores são históricos. Formato geral `SDKtools.Capture`, schemaVersion 3, toolVersion 3.11.0; observação cardFlow versão 3. Fontes comerciais e capturas originais ficam fora do pacote.

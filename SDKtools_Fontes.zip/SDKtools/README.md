# SDKtools V2 US

Menu e gravador de diagnóstico adaptados ao IPA US recebido. O botão flutuante abre o menu; a captura começa somente por ação do usuário. O framework não executa jogadas nem altera cartas. Raio X, solução do tabuleiro e autoplay não fazem parte desta versão.

## Base exata

| Campo | Alvo |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 do IPA | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

O build verifica o arquivo original, antes de qualquer assinatura no GBox. O framework também verifica bundle, versão, build e nome do executável ao iniciar. Uma base diferente não será aceita automaticamente.

US é o identificador observado do pacote. Há tradução portuguesa, mas a disponibilidade de regiões, servidores e modos depende do aplicativo e da conta.

## Mudanças da V2

- Captura Cocos separada da hierarquia UIKit, com alvo de uma leitura a cada 250 ms e somente uma avaliação JavaScript em andamento. UIKit mantém intervalo de 1 segundo. Esses intervalos não são garantia de desempenho no aparelho.
- Percurso da cena priorizando peças candidatas e seus descendentes. O limite anterior de 120 nós não alcançava os sprites internos de tabuleiros densos.
- Até 768 nós emitidos, 1.536 visitas, 512 filhos por nó, profundidade 24 e orçamento cooperativo de 10 ms. Cortes e erros ficam explícitos no relatório. Ainda pode haver captura parcial.
- IDs opacos de nós, frames e texturas estáveis durante o contexto de captura. Recarregar a página, substituir a WebView ou iniciar outra sessão exige considerar o contexto.
- Geometria e regiões do atlas dos sprites, sem atribuir nomes de cartas automaticamente. Os grupos visuais identificados nos vídeos anteriores valem apenas para aquelas capturas.
- Limite de 32 MiB de dados compactos e referências para cenas repetidas, reduzindo o tamanho do relatório. A captura pode encerrar antes de 180 segundos por limite de dados ou de eventos.

O novo executável preserva Sheep com `gameType=60` e o caminho Cocos/WKWebView. Algumas estruturas mudaram em relação à base asiática. A análise atual está em [Analysis/WePlay-US-CrazyAlpaca.md](Analysis/WePlay-US-CrazyAlpaca.md). Os relatórios anteriores foram preservados exclusivamente em `Analysis/Historico-Asia` e não descrevem a nova base.

## Atualizar pelo GitHub no Windows

O arquivo `SDKtools_Fontes.zip` e o workflow `compilar.yml` entregues juntos formam um par. O workflow verifica tamanho e SHA-256 dos fontes.

1. Envie o novo `SDKtools_Fontes.zip`, sem extrair, à raiz do repositório, substituindo o anterior.
2. Substitua `.github/workflows/compilar.yml` pelo novo `compilar.yml`. Faça commit das duas mudanças.
3. Extraia o RAR US recebido e renomeie o IPA original para `WePlay_US_6.6.2_base.ipa`. Não use um IPA que já passou pelo GBox.
4. Em **Releases → Draft a new release**, crie a tag `base-us-6.6.2`, selecione `main` e anexe `WePlay_US_6.6.2_base.ipa`. Publique a Release no seu repositório privado. A Release asiática pode permanecer.
5. Em **Actions → Compilar SDKtools US → Run workflow**, selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova; reexecutar um job antigo pode usar fontes antigos.
6. Ao terminar, baixe **SDKtools-v2-US-IPA** em Artifacts, extraia o ZIP e importe `WePlay_US_6.6.2_SDKtools_v2_unsigned.ipa` no GBox. Assine o app e os componentes incorporados, preservando `com.wejoy.weplay.us`.

O workflow não precisa de certificado ou chave de assinatura no GitHub. Há também a opção `secret_url`, que usa um link HTTPS direto no secret `SDKTOOLS_BASE_IPA_URL`.

## Primeira captura da versão US

1. Abra o app e chegue à tela anterior ao Crazy Alpaca.
2. Abra o SDKtools, mantenha **Incluir vídeo da tela** ligado e toque em **Gravar caminho e partida**. Aceite o pedido do iOS, se aparecer.
3. Feche o menu, entre no Crazy Alpaca e jogue por aproximadamente **30 a 45 segundos**, incluindo a transição para o tabuleiro mais cheio quando possível.
4. Os botões **Cheguei ao Crazy Alpaca** e **Marcar início da partida** acrescentam marcações manuais; não acionam o jogo.
5. Pare a captura, salve o vídeo na prévia do iOS e exporte o relatório JSON. Envie os dois arquivos da mesma sessão juntos.

A sessão encerra ao atingir 180 segundos, 300 amostras de toque ou o orçamento de 32 MiB de dados compactos. Há ainda um teto de 720 tentativas de leitura WebView por sessão. Um contato normalmente gera `began` e `ended`; arrastos geram mais amostras. Exporte antes de iniciar outra sessão.

Se ReplayKit não estiver disponível, use a gravação de tela do iPhone junto com a captura JSON e identifique o par de arquivos. A primeira captura US ainda precisa confirmar o motor, a cobertura e o desempenho reais. Os vídeos anteriores confirmaram trincas nas sessões observadas; isso não prova todas as regras e variantes do novo pacote.

## Interpretar o JSON

O formato é `SDKtools.Capture`, `schemaVersion=2`, versão da ferramenta `2.0.0`. `sessionID` identifica a sessão. Os tempos dos eventos usam relógio monotônico, em milissegundos desde o início; `startedAtUTC` é a referência de data e hora.

`touches` registra contatos e fases, `snapshots` registra UIKit, `markers` registra marcações e `webSamples` contém observações WebKit/Cocos. O contêiner Cocos é compartilhado entre jogos, portanto seu nome não confirma Crazy Alpaca sozinho. A navegação, a marcação do usuário e o vídeo precisam concordar.

Os índices e relações `parent` pertencem a uma amostra. IDs de nó, frame e textura só devem ser comparados no mesmo contexto. Quando uma amostra possui `sceneNodesRefSequence`, sua lista de nós é a de uma amostra completa anterior, aceita no mesmo contexto; não interprete uma lista ausente como tabuleiro vazio. As estatísticas e os horários da amostra atual continuam valendo.

`frameNameTag` é um hash curto do nome público do sprite. Não é identidade universal de carta. Nós ativos também não demonstram visibilidade integral, ausência de sobreposição ou possibilidade de toque. `occlusionResolved=false` e `cardRulesKnown=false` mantêm esses limites explícitos. `truncationReasons` informa por que o percurso ficou parcial.

UIKit usa pontos, o canvas tem tamanho de buffer e retângulos CSS, e Cocos usa coordenadas locais e mundiais. Vídeos podem ter outra resolução. Esses espaços precisam ser transformados antes de qualquer comparação geométrica.

O observador não lê textos de tela, cookies, armazenamento local, mensagens, credenciais ou conteúdo de requisições. Não envia relatórios automaticamente, troca delegates do WebKit ou modifica protótipos e objetos da cena. Somente seu estado de observação é guardado em um namespace próprio na página; ao encerrar, o gravador tenta removê-lo depois que qualquer avaliação pendente terminar.

## Compilar localmente em macOS

Requer Xcode com SDK iPhoneOS:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v2_unsigned.ipa
```

O integrador valida `config/base_identity.json`, acrescenta a dependência do framework na folga verificada do cabeçalho e conserva segmentos e bytes de código. O resultado é um IPA sem assinatura, para assinatura posterior. O projeto não inclui certificados, chaves, o IPA original ou recursos comerciais extraídos.

## Validação

Foram executados testes portáveis do parser, do empacotamento e do probe JavaScript, além da análise estática do novo IPA e revisão dos fontes. Os resultados estão em `Validation/V2-validation.json`.

Não houve compilação V2 com SDK Apple nem execução V2 no iPhone neste ambiente. O build no Actions, a instalação e a captura no aparelho ainda precisam ser confirmados. Testes com cenas simuladas não medem desempenho real do iPhone.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/scene_probe.test.cjs
```

Referências: [Apple ReplayKit](https://developer.apple.com/documentation/replaykit/rpscreenrecorder), [Apple WKWebView](https://developer.apple.com/documentation/webkit/wkwebview), [Cocos 2.4 Node](https://docs.cocos.com/creator/2.4/api/en/classes/Node.html), [Cocos 2.4 SpriteFrame](https://docs.cocos.com/creator/2.4/api/en/classes/SpriteFrame.html).

As APIs Cocos 2.x e 3.x não são intercambiáveis. Versão incompatível ou API não exposta deve produzir observação indisponível, não dados inventados.

# SDKtools V3.19.4 US — Alpaca, Bilhar e Cartas

Base: SDKtools V3.19.3/build39, WePlay US 6.6.2/build132.
Esta atualização: SDKtools 3.19.4/build40, Cartas/gameType2007 reativado.

Alpaca e a lógica de Bilhar são preservados. O empacotamento continua aceitando o Lua de Bilhar de até 128 KiB.

## Compilar

Atualize juntos `SDKtools_Fontes.zip` e `.github/workflows/compilar.yml` do mesmo pacote. Inicie uma execução nova de **Compilar SDKtools US**, selecionando o commit/branch novo, `base_source=release` e `release_tag=base-us-6.6.2`. Não reexecute um job de versão antiga.

O produto esperado é `WePlay_US_6.6.2_SDKtools_v3_19_4_unsigned.ipa`. O workflow também guarda diagnóstico e framework. O IPA não é assinado pelo workflow; precisa de assinatura compatível para instalar.

## Cartas

- **Capturar Cartas desde a entrada:** armar no lobby, entrar no jogo e capturar até 90 s. O painel mostra histórico de argumentos de cor recebidos; parar e exportar o JSON.
- **Ativar marcadores de cores:** usar separadamente da captura, já dentro de Ah, minha carta. X cinza significa desconhecida; indisponibilidade não deve virar cor adivinhada.
- **Exportar JS baixado do jogo:** exportação explícita dos recursos locais permitidos, não recuperação garantida de todo o código original.

Os marcadores e a captura não ficam ativos simultaneamente nesta revisão. Uma carta oculta só pode ter cor conhecida se o cliente realmente possui o dado e o vínculo atual foi validado. Não há fórmula comprovada ID→cor.

## Preservação e testes

Consulte `Analysis/V3_19_4-cards.md` e `Validation/V3_19_4-validation.json`. Os documentos de versões anteriores são históricos e não descrevem o estado atual de Cartas.

Os testes portáteis e a compilação Apple são verificações distintas da execução no iPhone. Confirmar cores e alinhamento em uma partida real antes de considerar a funcionalidade validada em dispositivo.

# SDKtools V2.3 US

Menu flutuante e captura de diagnóstico para WePlay US 6.6.2 build132.

## Retornar: estado desta entrega

A primeira entrada em Ferramentas é **Retornar: rastrear ação**. Ela inicia ou aproveita a captura atual para observar os componentes e eventos dos controles enquanto você usa o poder original. Não executa Retornar pelo menu e não altera o estoque. **Retornar ilimitado ainda não está implementado.**

As capturas V2.2 comprovaram dois retornos: a última peça saiu da barra e voltou à posição anterior no tabuleiro. Elas não continham o nome do callback, os argumentos ou a regra de consumo. Esta versão coleta os descritores necessários para procurar essa ligação, sem mover sprites para simular o efeito.

O rastreamento é opcional. A gravação comum mantém a observação de geometria; somente a opção Retornar acrescenta metadados limitados de controles. Nenhum callback é executado, nenhum listener é substituído e nenhum objeto do jogo é alterado.

## Base exata

| Campo | Valor |
|---|---|
| Bundle | `com.wejoy.weplay.us` |
| Versão / build | `6.6.2` / `132` |
| App / executável | `Payload/weplay-us.app` / `weplay-us` |
| iOS mínimo | `15.0` |
| IPA original | `408919954` bytes |
| SHA-256 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |

A verificação exige o IPA original antes de assinar no GBox. O framework também verifica a identidade do app ao iniciar. US é o identificador observado; região, servidores e modos dependem do aplicativo e da conta. A base asiática não é intercambiável.

## Atualização no Windows pelo GitHub

O ZIP de fontes e o workflow entregues juntos formam um par verificado por tamanho e SHA-256.

1. Envie `SDKtools_Fontes.zip`, sem extrair, à raiz do repositório, substituindo o anterior.
2. Substitua `.github/workflows/compilar.yml` pelo `compilar.yml` deste pacote e faça commit das duas mudanças.
3. Mantenha a Release `base-us-6.6.2` com o asset original `WePlay_US_6.6.2_base.ipa`. Não é necessário apagar ou criar outra Release.
4. Abra **Actions → Compilar SDKtools US → Run workflow**. Selecione `main`, `base_source=release` e `release_tag=base-us-6.6.2`. Inicie uma execução nova; reexecutar um job antigo pode usar fontes antigos.
5. Baixe o artifact **SDKtools-v2.3-US-IPA**, extraia seu ZIP e importe `WePlay_US_6.6.2_SDKtools_v2_3_unsigned.ipa` no GBox.
6. Assine o app e os componentes incorporados, mantendo `com.wejoy.weplay.us`. Confirme **Diagnóstico V2.3** no menu após instalar.

O workflow não precisa do certificado de assinatura no GitHub. A opção alternativa `secret_url` usa o secret `SDKTOOLS_BASE_IPA_URL` com link HTTPS direto para a mesma base.

## Validar no aparelho

Entre na partida antes de iniciar. Abra SDKtools e toque **Retornar: rastrear ação**. Se não houver captura em andamento, a opção inicia uma, respeitando a escolha de incluir vídeo. Se já estiver gravando, preserva os dados e ativa o rastreamento. O menu fecha para você continuar.

1. Coloque uma ou duas peças na barra.
2. Abra o **Retornar central do próprio jogo** e confirme o uso disponível.
3. Aguarde a peça voltar ao tabuleiro.
4. Se o item já estiver sem estoque, mostre também o popup desse estado. Não compre itens para o teste.
5. Pare após aproximadamente 30–45 segundos e envie o JSON e o vídeo da mesma sessão.

É uma observação manual, não um teste de uma ação ilimitada. A execução no iPhone ainda precisa confirmar se o jogo expõe os eventos via `cc.Button`; controles implementados por outro mecanismo podem exigir outra etapa de identificação. Uma ausência em uma cena parcial não prova ausência do controle.

As marcações **Cheguei ao Crazy Alpaca** e **Marcar início da partida** são manuais. Não acionam nem identificam automaticamente o jogo. Exporte antes de iniciar outra sessão.

A captura termina ao alcançar 180 segundos, 300 amostras de toque ou 32 MiB de JSON compacto. Há limite de 720 tentativas de leitura WebView. Um contato normalmente produz `began` e `ended`; arrastos geram eventos adicionais. O alvo de 250 ms não garante 4 Hz; carga, avaliações pendentes e limites podem diminuir a frequência. O orçamento do arquivo não é um teto de memória RAM.

## Formato do relatório

`SDKtools.Capture`, `schemaVersion=3`, `toolVersion=2.3.0`. O recurso de observação JavaScript mantém seu próprio `version=2`, pois continua retornando o mesmo tipo de observação completa antes da compactação nativa.

- `touches`: contatos observados, exceto menu SDKtools e entradas de texto.
- `snapshots`: estrutura UIKit, sem texto ou valores de campos.
- `markers`: marcações do usuário e ciclo do vídeo.
- `webSamples`: horários, contexto, geometria DOM, diagnósticos Cocos e nós completos, referenciados ou em diferenças.

O decoder `scripts/decode_capture.py` lê os formatos 2 e 3. Por padrão exporta JSONL: uma linha de cabeçalho e uma por amostra expandida. Também aceita `--format json`. Recusa sobrescrever a entrada ou um arquivo existente.

```bash
python3 scripts/decode_capture.py captura.json cenas.jsonl
python3 scripts/decode_capture.py captura.json captura_expandida.json --format json
```

Com o rastreamento de Retornar ligado, `returnTrace` informa intenção, duração inicial e contagens de coleta, sem declarar execução do poder. Cada observação pode incluir `controlTrace`; nós de controles podem conter `control` com tipos de componentes, estado do botão e descritores dos eventos. `handlerResolved` significa que uma função foi encontrada, não que foi chamada ou que implementa Retornar.

Os limites são 64 controles, 8 componentes e 8 eventos por controle, com identificadores de até 96 caracteres. Argumentos personalizados são representados somente por presença, tipo e comprimento; seu conteúdo não é exportado. `return_visual_candidate` é uma pista visual composta a ser conferida com o vídeo. Os eventos podem apontar para nós fora do recorte observado. O custo adicional usa o mesmo orçamento cooperativo de 10 ms e pode aumentar as amostras parciais; `controlTrace.truncated` explicita a incompletude.

Cada amostra tem um dos formatos:

| `sceneNodesEncoding` | Conteúdo |
|---|---|
| `full` | `sceneNodes` contém a lista completa daquela observação, que ainda pode estar marcada como parcial pelo percurso. |
| `reference` | `sceneNodesRefSequence` aponta para uma amostra anterior `full` ou `delta` no mesmo contexto. A lista é idêntica; horários e diagnósticos atuais continuam próprios. |
| `delta` | A referência aponta para a base; `sceneNodesDelta` aplica as alterações abaixo. |

`sceneNodesDelta.version=1`. `order` contém todos os IDs presentes na observação atual, em ordem exata. `added` contém linhas completas de novos IDs. `changed` contém `{nodeID, set, unset}`: `set` substitui campos de primeiro nível, inclusive objetos completos; `unset` remove campos. `null` continua um valor explícito, diferente de campo ausente. `nodeID` não pode ser alterado por um patch. Os índices `index`, `parent` e `parentID` são preservados, inclusive quando mudam com a ordem.

IDs ausentes de `order` estão ausentes somente daquela observação. Isso não significa carta removida do jogo, especialmente quando a coleta é parcial. Há quadro completo em novo contexto e no máximo a cada 20 posições de amostra; a cadeia de dependências tem no máximo 19 ligações. Uma referência nunca aponta para outra referência. Uma diferença maior que o quadro completo é substituída pelo quadro completo. O estado só avança depois de a amostra ser aceita no orçamento do relatório.

Diagnósticos de falha sem dados de cena são preservados como diagnósticos. Não viram cena vazia nem podem servir de base para uma referência.

A raiz de `director.getScene()` é estrutural: seus flags podem ser `false` ou `null` e não bloqueiam a travessia. Os descendentes inativos continuam filtrados. `descendantNodeCount`, `spriteNodeCount`, `truncated` e `truncationReasons` permitem distinguir ausência de elementos, indisponibilidade e captura parcial.

IDs de nós, frames e texturas pertencem ao contexto da WebView. `frameNameTag` é um hash de nome público, sem significado universal de carta. Nós ativos não provam visibilidade, ausência de sobreposição ou possibilidade de toque. `occlusionResolved=false` e `cardRulesKnown=false` continuam explícitos. O JSON não confirma conteúdo oculto nem regras de jogo.

UIKit usa pontos; canvas tem buffer e retângulo CSS; Cocos usa unidades locais e mundiais; o vídeo pode ter outra resolução. Compare esses espaços após conversão. O relógio é monotônico em milissegundos desde o início; `startedAtUTC` é a referência de data.

## Compilação e validação

Em macOS com Xcode:

```bash
bash scripts/build_framework.sh
python3 scripts/integrate_ipa.py --ipa /caminho/WePlay_US_6.6.2_base.ipa --framework dist/SDKtools.framework --output dist/WePlay_US_6.6.2_SDKtools_v2_3_unsigned.ipa
```

O build executa os testes Python, JavaScript e os testes nativos Foundation do codec e do sanitizador antes de compilar o framework iPhoneOS. O integrador exige SDKtools 2.3 build 5 e a base exata, acrescenta a dependência do framework na folga verificada do cabeçalho e preserva os segmentos e bytes de código. O IPA de saída precisa de assinatura posterior.

Os testes portáveis verificam a observação opt-in, limites, privacidade e ausência de execução de callbacks. A compilação Apple, o teste nativo Foundation e a execução V2.3 no iPhone dependem do Actions e do aparelho. Os relatórios recebidos comprovam a execução da V2.2; não validam esta atualização. Detalhes em `Validation/V2_3-validation.json` e `Analysis/Retornar-evidence-v22.json`.

```bash
python3 -m unittest discover -s Tests -p 'test_*.py' -v
node --test Tests/*.test.cjs
```

## Limites da observação

O observador não lê textos, cookies, armazenamento local, credenciais, clipboard ou payloads de rede. Não envia relatórios automaticamente, troca delegates do WebKit ou modifica protótipos e objetos da cena. Guarda apenas seu estado em namespace próprio, com tentativa de limpeza após avaliações pendentes. Não inclui certificados, o IPA original ou recursos comerciais extraídos.

A correspondência Crazy Alpaca/Lhama Maluca/Sheep exige concordância de navegação, marcação e vídeo. O caminho estático US está em `Analysis/WePlay-US-CrazyAlpaca.md`; o histórico asiático é somente referência histórica. Cocos 2.x e 3.x não são intercambiáveis: APIs ausentes produzem observação indisponível.

## Contrato consultado

A API oficial do Cocos 2.4 expõe `Button.clickEvents` e os campos de `Component.EventHandler`. Isso orienta a coleta, mas não identifica o handler específico de Retornar nem garante que ele esteja configurado nessa API.

- https://docs.cocos.com/creator/2.4/api/en/classes/Button.html
- https://docs.cocos.com/creator/2.4/api/en/classes/Component.EventHandler.html

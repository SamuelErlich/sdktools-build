/* Bounded Cocos 2.4.4 adapter. Original events only; no transport/stock writes. */
(function (plan, makeXray, makePowers, originalPower, makeCovered, makePhaseSnapshot, makeFast, coop) {
  'use strict';
  if(!coop || ['validateRoute','insertAndMatch','begin','observe','busy','freeze','diagnostic'].some(function(k){return typeof coop[k]!=='function';}))coop=null;
  var ids = new WeakMap(), frameIDs = new WeakMap(), nextID = 1, nextFrame = 1;
  var stable = null, planned = null, pending = null, route = null, generation = null, confirmed = 0, cardsRead = 0, cardTypesRead = 0;
  var observedMissionKey=null, missionState={status:'unavailable'};
  var reserveDiagnostic={status:'unavailable'};
  var batchSize=1, xrayDepth=1, planningState={state:'blocked',nodes:0,slices:0}, xray = null, xrayWanted = false, xrayState = {status:'off',coveredIcons:0,matchedBorders:0};
  try { if (typeof makeXray === 'function') xray = makeXray(); } catch (_) {}
  var powers=null, preferenceKey=null;
  try { if(typeof makePowers==='function')powers=makePowers(originalPower); }catch(_){}
  var covered=null, coveredRequestKind='touch';
  try { if(typeof makeCovered==='function'){
    var coordinator=makeCovered();
    if(coordinator && ['dispatch','observe','invalidate','busy','diagnostic','block'].every(function(k){return typeof coordinator[k]==='function';}))covered=coordinator;
  }}catch(_){}
  var fast=null;
  try{if(typeof makeFast==='function'){var f=makeFast();if(f&&['plan','dispatch','observe','busy','diagnostic','invalidate'].every(function(k){return typeof f[k]==='function';}))fast=f;}}catch(_){}
  var phase=null, phaseRequired=false, phaseRevision=null;
  try{if(typeof makePhaseSnapshot==='function'){
    var reader=makePhaseSnapshot();
    if(reader&&['observe','invalidate','diagnostic','current'].every(function(k){return typeof reader[k]==='function';}))phase=reader;
  }}catch(_){}
  function phaseDiagnostic(){return phase?phase.diagnostic():{version:1,status:'unavailable',reason:'reader_unavailable',revision:0,scope:0,complete:false,serverConfirmed:false};}
  function invalidatePhase(reason){if(phase)phase.invalidate(reason);}
  function refreshPhase(s){
    if(!phase)return !phaseRequired;
    var ready=phase.observe(s,{window:window,document:document,loader:ownData(window,'__require'),generation:generation,checkBudget:function(){return clock()-started<LIMITS.budgetMs;}},clock());
    var d=phase.diagnostic(),key=String(d.scope)+':'+String(d.revision);
    if(key!==phaseRevision){phaseRevision=key;stable=null;planned=null;route=null;planningState={state:'blocked',nodes:0,slices:0};}
    s.phaseSnapshot=phase.current();s.phaseBaseSignature=s.phaseBaseSignature||s.signature;s.signature=s.phaseBaseSignature+'|phase:'+key;
    return ready;
  }
  // Read-only: no overlay work, preferences, input, power popup or pending reconciliation.
  function readPhaseOnly(){
    rejection=null;started=clock();cardsRead=0;cardTypesRead=0;
    try{if(!phase)return {version:1,phaseSnapshot:null,phaseSnapshotSummary:phaseDiagnostic()};refreshPhase(snapshot());}
    catch(_){if(fast)fast.invalidate(rejection);invalidatePhase(rejection==='external_mode_active'?'external_mode_active':'observation_interrupted');stable=null;planned=null;route=null;
      if(pending){pending.confirmation=null;pending.replacement=null;pending.resync=null;}}
    return {version:1,phaseSnapshot:phase?phase.current():null,phaseSnapshotSummary:phaseDiagnostic()};
  }
  function coveredDiagnostic(){return covered?covered.diagnostic():{status:'blocked',reason:'observer_unavailable',pending:false,
    requestObserved:false,responseObserved:false,promiseSettled:false,effectObserved:false,attempts:0,
    kind:coveredRequestKind,responseOutcome:'unknown',phase:'blocked'};}
  var LIMITS = { nodes: 4096, children: 512, cards: 512, depth: 24, components: 32, budgetMs: 18 };
  var rejection = null, animationDetail = null, cardRuleDetail = null, started = 0;
  function object(x) { return x !== null && (typeof x === 'object' || typeof x === 'function'); }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  function clock() { return typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now(); }
  function abort(reason) { rejection = reason; throw Error('SDKtools guard'); }
  function animation(reason) { animationDetail = reason; abort('animation_active'); }
  function cardRule(detail) { cardRuleDetail=detail; abort('unsupported_card_rules'); }
  function budget() { if (clock() - started >= LIMITS.budgetMs) abort('time_budget'); }
  function id(x) { if (!ids.has(x)) ids.set(x, 'c' + nextID++); return ids.get(x); }
  function size(n, w, h) { return n.width === w && n.height === h; }
  function visible(n, root) { return object(n) && n.isValid === true && n.activeInHierarchy === true &&
    (n === root || n.active === true) && num(n.opacity) && n.opacity > 0 && n.opacity <= 255; }
  function children(n) { var a = n.children; if (!Array.isArray(a)) abort('invalid_scene');
    if (a.length > LIMITS.children) abort('scan_limit'); return a; }
  function version(cc) { var a = cc.ENGINE_VERSION, b = window.CocosEngine;
    return typeof a === 'string' && typeof b === 'string' && a !== b ? null : typeof a === 'string' ? a : b; }
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length && i < 128; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
  function result(status, reason, dispatched) { var output = { version: 1, status: status, reason: reason,
    cardsRead: cardsRead, cardTypesRead: cardTypesRead, confirmedMoves: confirmed, dispatched: dispatched === true,
    awaitingBoardChange: pending !== null || !!(powers && powers.busy()) || !!(covered && covered.busy()) || !!(fast&&fast.busy()) || !!(coop&&coop.busy()) };
    output.xray = xrayState; output.reserveXray=reserveDiagnostic; output.planning=Object.assign({},planningState,{mission:missionState});
    if(coop)output.cooperative=coop.diagnostic();
    output.powers=powers?powers.diagnostic():{status:'unavailable',confirmed:0};
    output.covered=coveredDiagnostic();
    if(fast)output.superFast=fast.diagnostic();
    if(phase||phaseRequired)output.phaseSnapshotSummary=phaseDiagnostic();
    if (animationDetail) output.animationDetail = animationDetail;
    if (cardRuleDetail) output.cardRuleDetail = cardRuleDetail;
    return output; }
  function transform(n) { return num(n.x) && num(n.y) && n.angle === 0 && n.scaleX === 1 && n.scaleY === 1 &&
    n.anchorX === 0.5 && n.anchorY === 0.5 && (!num(n.z) || n.z === 0); }
  function frame(n, cc) { if (typeof n.getComponent !== 'function') abort('sprite_unavailable');
    var s = n.getComponent(cc.Sprite), f = s && s.spriteFrame;
    if (!object(s) || s.enabled !== true || s.enabledInHierarchy !== true || !object(f) ||
        typeof f.name !== 'string' || !f.name || f.name.length > 256 || typeof f.getRect !== 'function') abort('unknown_card');
    var r = f.getRect(); if (!object(r) || r.width !== 120 || r.height !== 135) abort('unknown_card');
    return f; }
  function action(card, cc, emitter, records, requireEnabled) {
    var nodes = [card.node], a = children(card.node), matches = [];
    for (var i = 0; i < a.length; i++) if (visible(a[i], null)) nodes.push(a[i]);
    for (var j = 0; j < nodes.length; j++) {
      var n = nodes[j]; if (typeof n.getComponent !== 'function') abort('button_unavailable');
      var b = n.getComponent(cc.Button); if (!b) continue;
      var events = b.clickEvents;
      if (!Array.isArray(events) || events.length !== 1 || !events[0] || events[0].handler !== 'touchBlock') continue;
      matches.push({button:b,event:events[0],node:n});
    }
    if (matches.length !== 1) abort('handler_ambiguous');
    var m = matches[0], b = m.button, e = m.event, target = e.target;
    if (b.isValid !== true || b.node !== m.node || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype, e) ||
        e.emit !== emitter || e.customEventData !== '' || !object(target) || !records.has(target) ||
        (target !== card.node && target.parent !== card.node) || typeof target.getComponents !== 'function') abort('event_mismatch');
    if (requireEnabled && (b.enabled !== true || b.enabledInHierarchy !== true || b.interactable !== true)) abort('disabled_control');
    var components = target.getComponents(cc.Component), found = [];
    if (!Array.isArray(components) || components.length > LIMITS.components) abort('handler_unavailable');
    for (var k = 0; k < components.length; k++) {
      var c = components[k]; if (c && typeof c.touchBlock === 'function') found.push(c);
    }
    if (found.length !== 1 || found[0].isValid !== true || found[0].node !== target || found[0].touchBlock.length > 2) abort('handler_ambiguous');
    // If the public registration exposes a name, ensure it resolves to the same receiver.
    if (typeof e.component === 'string' && e.component &&
        (typeof target.getComponent !== 'function' || target.getComponent(e.component) !== found[0])) abort('event_mismatch');
    return {button:b,event:e,receiver:found[0],enabled:b.enabled === true && b.enabledInHierarchy === true && b.interactable === true};
  }
  function inputEvent(cc, button) {
    // CCButton._onTouchEnded forwards EventTouch to clickEvents. Its separate
    // node.emit('click', button) API is not the registered component callback.
    // Cocos 2.4 CCEvent.js initializes _eventCode through _setEventCode; only
    // this newly allocated event is changed, never a real input or game node.
    var n=button.node, EventTouch=cc.Event && cc.Event.EventTouch;
    if (typeof cc.Touch !== 'function' || typeof EventTouch !== 'function' ||
        EventTouch.ENDED !== 2 || cc.Event.AT_TARGET !== 2 || !cc.Node || !cc.Node.EventType ||
        cc.Node.EventType.TOUCH_END !== 'touchend' || typeof cc.v2 !== 'function' ||
        typeof n.convertToWorldSpaceAR !== 'function') abort('input_event_unavailable');
    var point=n.convertToWorldSpaceAR(cc.v2(0,0));
    if (!object(point) || !num(point.x) || !num(point.y)) abort('input_event_unavailable');
    var touch=new cc.Touch();
    if (!object(touch) || typeof touch.setTouchInfo !== 'function') abort('input_event_unavailable');
    touch.setTouchInfo(0,point.x,point.y);
    var event=new EventTouch([touch],true), proto=EventTouch.prototype;
    if (!object(event) || !object(proto) || !Object.prototype.isPrototypeOf.call(proto,event) ||
        typeof proto._setEventCode !== 'function' || typeof event.getEventCode !== 'function' ||
        typeof event.getTouches !== 'function' || typeof event.getLocation !== 'function') abort('input_event_unavailable');
    event.touch=touch; event.currentTouch=touch;
    event.target=n; event.currentTarget=n; event.type=cc.Node.EventType.TOUCH_END; event.eventPhase=cc.Event.AT_TARGET;
    proto._setEventCode.call(event,EventTouch.ENDED);
    var location=event.getLocation(), touches=event.getTouches();
    if (event.target !== n || event.currentTarget !== n || event.touch !== touch ||
        event.getEventCode() !== EventTouch.ENDED || event.type !== 'touchend' ||
        !Array.isArray(touches) || touches.length !== 1 || touches[0] !== touch ||
        !object(location) || location.x !== point.x || location.y !== point.y) abort('input_event_unavailable');
    return event;
  }
  function parkedWarehouseCard(card,cc,root,emitter,records,gameLayer) {
    var slot=card.parent, row=slot && slot.parent, panel=row && row.parent;
    if (!slot || !row || !panel || !size(slot,84,94) || !size(row,260,94) || !size(panel,272,126) ||
        !panel.parent || panel.parent.parent !== gameLayer || !records.has(panel) ||
        !transform(slot) || !transform(row) || !transform(panel) || row.x !== 0 || row.y !== 8 ||
        typeof panel.getComponent !== 'function') return null;
    var ps=panel.getComponent(cc.Sprite), pf=ps && ps.spriteFrame;
    if (!ps || ps.enabled !== true || ps.enabledInHierarchy !== true || !pf || typeof pf.name !== 'string' ||
        hash(pf.name) !== 'd0a9f790' || typeof pf.getRect !== 'function') return null;
    var pr=pf.getRect(); if (!pr || pr.width !== 272 || pr.height !== 126) return null;
    var slots=children(row), signature=[], found=false;
    if (slots.length !== 3) return null;
    for (var i=0;i<slots.length;i++) {
      budget(); var n=slots[i];
      if (!visible(n,root) || !records.has(n) || n.parent !== row || !size(n,84,94) || !transform(n) ||
          n.x !== -88+88*i || n.y !== 0 || typeof n.getComponents !== 'function' || typeof n.getComponent !== 'function') return null;
      var components=n.getComponents(cc.Component), matches=[];
      if (!Array.isArray(components) || components.length > LIMITS.components) return null;
      for (var j=0;j<components.length;j++) if (components[j] && typeof components[j].onBtnClick === 'function') matches.push(components[j]);
      if (matches.length !== 1 || cc.js.getClassName(matches[0]) !== 'CommonStoreItem') return null;
      var c=matches[0], b=n.getComponent(cc.Button), events=b && b.clickEvents, e=Array.isArray(events) && events.length === 1 && events[0];
      if (!c || c.isValid !== true || c.node !== n || typeof c.isSelf !== 'boolean' || typeof c.isEmpty !== 'boolean' ||
          typeof c.onBtnClick !== 'function' || c.onBtnClick.length !== 0 || !b || b.isValid !== true || b.node !== n ||
          !e || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype,e) || e.emit !== emitter ||
          e.handler !== 'onBtnClick' || e.target !== n || e.customEventData !== '' ||
          (typeof e.component === 'string' && e.component && n.getComponent(e.component) !== c)) return null;
      var possible=children(n).filter(function(child){return visible(child,root) && size(child,80,90) && children(child).length === 5;});
      if (possible.length > 1 || c.isEmpty !== (possible.length === 0)) animation('warehouse_card_unsettled');
      signature.push(id(n),c.isSelf,c.isEmpty);
      if (n === slot) {
        if (possible.length !== 1 || possible[0] !== card) animation('warehouse_card_unsettled');
        found=true;
      }
    }
    if (!found || !transform(card) || card.x !== 0 || card.y !== 0) animation('warehouse_card_unsettled');
    var parts=children(card), bg=parts[0], faces=children(bg);
    if (!visible(bg,root) || !transform(bg) || !size(bg,80,90) || faces.length !== 1 ||
        parts.slice(1).some(function(n){return visible(n,root);})) animation('warehouse_card_unsettled');
    var background=frame(bg,cc), tag=hash(background.name), face=faces[0];
    if ((tag !== 'a78ac5ca' && tag !== '6be7dcd3') || !visible(face,root) || !size(face,80,90) || !transform(face)) animation('warehouse_card_unsettled');
    var f=frame(face,cc); if (!frameIDs.has(f)) frameIDs.set(f,'f'+nextFrame++);
    // Membership only. Warehouse ownership never authorizes a click here.
    signature.push(id(card),frameIDs.get(f),f.name,card.x,card.y);
    return signature;
  }
  function clearXray(status) {
    try { if (xray && typeof xray.clear === 'function') xray.clear(); } catch (_) {}
    xrayState={status:status || 'off',coveredIcons:0,matchedBorders:0};
  }
  function showXray(s, proof) {
    if (!xrayWanted) { clearXray('off'); return; }
    if (!xray || typeof xray.render !== 'function') { clearXray('unavailable'); return; }
    try {
      var rendered=xray.render(s,proof,{depth:xrayDepth});
      xrayState=rendered && rendered.status === 'ready' ? {status:'ready',
        coveredIcons:Math.max(0,Math.min(512,rendered.coveredIcons|0)),
        matchedBorders:Math.max(0,Math.min(3,rendered.matchedBorders|0)),depthLimit:xrayDepth,
        hiddenByDepth:Math.max(0,Math.min(512,rendered.hiddenByDepth|0)),hiddenByLayout:Math.max(0,Math.min(512,rendered.hiddenByLayout|0)),
        labelMode:['none','cocos_label','vector_digits'].indexOf(rendered.labelMode) >= 0 ? rendered.labelMode : 'none'} : {status:'unavailable',coveredIcons:0,matchedBorders:0};
    } catch (_) { clearXray('unavailable'); }
  }
  // HandArea.calculateInsertIndex/findThreeBlock: group insertion followed
  // by the first adjacent equal trio, matching the original local rule.
  function insertAndMatch(bar,card){return coop.insertAndMatch(bar,card);}
  function validateRoute(s,decision,checkMarker){return coop?coop.validateRoute(s,decision,checkMarker,budget):null;}
  function plannerDiagnostic(decision,state) {
    var stats=object(decision) && object(decision.stats) ? decision.stats : {};
    planningState={state:state,nodes:num(stats.expanded) ? Math.max(0,Math.min(1000000,Math.floor(stats.expanded))) : 0,
      slices:num(stats.slices) ? Math.max(0,Math.min(1000000,Math.floor(stats.slices))) : 0};
    ['lookaheadDepth','lookaheadTriples','lookaheadNodes','lookaheadSlices'].forEach(function(k){
      if(integer(stats[k],0,12000))planningState[k]=stats[k];
    });
    if (['searching','priority','fallback'].indexOf(stats.missionStatus)>=0 && missionState.status!=='unavailable' && missionState.status!=='complete')
      missionState.status=stats.missionStatus;
    if(['dead_end','unknown','proved','clear'].indexOf(stats.continuation)>=0)planningState.continuation=stats.continuation;
    if (stats.goal === 'next_trio' || stats.goal === 'multi_trio') planningState.goal=stats.goal;
    if (num(stats.residualCards)) planningState.residualCards=Math.max(0,Math.min(512,Math.floor(stats.residualCards)));
    if (route) { planningState.goal=stats.goal==='multi_trio'?'multi_trio':'next_trio'; planningState.residualCards=route.residualCards; }
  }
  function ownData(o,key) {
    if (!object(o)) return undefined;
    var descriptor=Object.getOwnPropertyDescriptor(o,key);
    return descriptor && Object.prototype.hasOwnProperty.call(descriptor,'value') ? descriptor.value : undefined;
  }
  function integer(v,min,max) { return num(v) && Math.floor(v) === v && v >= min && v <= max; }
  function watchedStore() {
    try { var loader=ownData(window,'__require'),store=typeof loader==='function'&&ownData(loader('GameStore'),'default');
      return ownData(store,'isWatcher')===true?store:null;
    } catch (_) { return null; }
  }
  function readPlayState(cc,games,gameLayer,records,visualStore) {
    if (games.length !== 1) return null;
    var game=games[0], layer=ownData(game,'GameLayer'), loader=ownData(window,'__require'), store;
    if (game.isValid !== true || !records.has(game.node) || !layer || layer.node !== gameLayer ||
        layer.isValid !== true || cc.js.getClassName(layer) !== 'GameLayer' || typeof loader !== 'function') return null;
    var parent=gameLayer;
    for(var depth=0;parent && parent!==game.node && depth<=LIMITS.depth;depth++)parent=records.get(parent);
    if(parent!==game.node)return null;
    try { store=ownData(loader('GameStore'),'default'); } catch (_) { return null; }
    if(!object(store))return null;
    if(visualStore){
      if(store!==visualStore || ownData(store,'isWatcher')!==true || ownData(store,'state')!==2 ||
          ['isHotTiming','isAddingCommonBlock','isUsingPenetrateProp'].some(function(k){return ownData(store,k)!==false;}))abort('external_mode_active');
      return true; // Visual verification only; never an action context.
    }
    if(ownData(store,'isWatcher')===true || ownData(store,'isHotTiming')===true ||
        ownData(store,'isAddingCommonBlock')===true || ownData(store,'isUsingPenetrateProp')===true ||
        ownData(store,'isCanTouchBlock')===false ||
        (ownData(store,'state')!==undefined && ownData(store,'state')!==2)) abort('external_mode_active');
    var uid=ownData(store,'uid'), rid=ownData(store,'rid'), start=ownData(store,'start_time'), gamers=ownData(store,'gamers');
    var self=Array.isArray(gamers) && gamers.length<=512 ? gamers.filter(function(g){return ownData(g,'uid')===uid;}) : [];
    if(self.length===1 && ownData(self[0],'state')!==1)abort('external_mode_active');
    function identity(v){return (typeof v==='string' && v.length>0 && v.length<=128) || integer(v,1,9007199254740991);}
    if(!identity(uid) || !identity(rid) || !integer(start,1,9007199254740991) || self.length!==1 || ownData(self[0],'state')!==1 ||
        ownData(store,'isWatcher')!==false || ownData(store,'isHotTiming')!==false || ownData(store,'isAddingCommonBlock')!==false ||
        ownData(store,'isUsingPenetrateProp')!==false || ownData(store,'isCanTouchBlock')!==true || ownData(store,'state')!==2)return null;
    return {store:store,game:game,layer:layer,uid:uid,rid:rid,start:start};
  }
  // Task.setup uses task_info; reward animations may display the old task.
  function readMission(cc,games,gameLayer,records) {
    try {
      if(games.length!==1)return null;
      var game=games[0], layer=ownData(game,'GameLayer'), task=ownData(game,'Task');
      if(game.isValid!==true || game.enabled===false || game.enabledInHierarchy===false ||
          !records.has(game.node) || !layer || layer.node!==gameLayer || layer.isValid!==true ||
          cc.js.getClassName(layer)!=='GameLayer' || !task || cc.js.getClassName(task)!=='Task' ||
          task.isValid!==true || !records.has(task.node) || task.enabled===false || task.enabledInHierarchy===false)return null;
      // The Game component must own the gameplay layer and task subtree.
      function inside(n) { for(var d=0;n && d<=LIMITS.depth;d++,n=records.get(n))if(n===game.node)return true;return false; }
      if(!inside(gameLayer) || !inside(task.node))return null;
      var loader=ownData(window,'__require');if(typeof loader!=='function')return null;
      var store=ownData(loader('GameStore'),'default');
      if(!store || !Array.isArray(ownData(store,'pile_blocks')) || !Array.isArray(ownData(store,'hand_blocks')) ||
          !Array.isArray(ownData(store,'storage_blocks')) || ownData(store,'isWatcher')!==false)return null;
      var info=ownData(store,'task_info'), type=ownData(info,'target_block_type'),
        current=ownData(info,'current_num'), total=ownData(info,'total_num');
      if(!integer(type,1,10000) || !integer(total,1,1000000) || !integer(current,0,total))return null;
      return {type:'type:'+type,current:current,total:total,key:JSON.stringify([id(game),id(store),type,current,total]),targetType:type};
    } catch (_) { return null; } // Optional mission data must not stop normal play.
  }
  function cardLayout(node,cc) {
    if (typeof node.getComponents !== 'function') cardRule('component');
    var components=node.getComponents(cc.Component), blocks=[];
    if (!Array.isArray(components) || components.length > LIMITS.components) cardRule('component');
    for (var i=0;i<components.length;i++) if (cc.js.getClassName(components[i]) === 'Block') blocks.push(components[i]);
    if (blocks.length !== 1) cardRule('component');
    var block=blocks[0], bgSprite=ownData(block,'BgSprite'), skin=ownData(block,'SkinSprite'),
      bg=bgSprite && bgSprite.node, face=skin && skin.node, mask=ownData(block,'MaskNode'), special=ownData(block,'SpecialNode'),
      hot=ownData(block,'HotTimeAnimNode'), bomb=ownData(block,'BombAnimNode'), actual=children(node), required=[bg,mask,hot,bomb];
    if (!block || block.node !== node || block.isValid !== true || !bg || !face || !mask || !hot || !bomb ||
        face.parent !== bg || new Set(required).size !== 4 || !required.every(function(n){return n.parent === node;})) abort('card_geometry');
    if (special && special.parent === node) required.push(special);
    else {
      var specialInfo=ownData(ownData(block,'blockInfo'),'special_info');
      if (!special || !object(specialInfo) || ownData(specialInfo,'type') === 0 || ownData(specialInfo,'lock_state') !== 0) abort('card_geometry');
    }
    if (actual.length !== required.length || new Set(required).size !== required.length ||
        !actual.every(function(n){return required.indexOf(n) >= 0;})) abort('card_geometry');
    return {block:block,bg:bg,face:face,mask:mask,special:special,hot:hot,bomb:bomb};
  }
  function metadata(node,cc,zone,layout) {
    var block=layout.block, info=ownData(block,'blockInfo'), rawID=ownData(info,'id'), type=ownData(info,'type'),
      state=ownData(info,'state'), layer=0, gridRow=0, gridCol=0, issue=null;
    function note(detail) { if (!issue) issue=detail; }
    if (!block || block.node !== node || block.isValid !== true) cardRule('component');
    if (!object(info)) cardRule('metadata_missing');
    if (typeof rawID !== 'string' || !rawID || rawID.length > 128) cardRule('metadata_id');
    if (!integer(type,0,10000)) note('metadata_type');
    if (state !== (zone === 'board' ? 0 : zone === 'tray' ? 1 : 2)) note('metadata_state');
    if (zone === 'board') {
      layer=ownData(info,'layer'); var row=ownData(info,'row'), col=ownData(info,'col');
      if (!integer(layer,0,10000)) cardRule('metadata_layer');
      if (!num(row) || !num(col) || Math.abs(row)>10000 || Math.abs(col)>10000) cardRule('metadata_position');
      var pieces=rawID.split('-'); gridRow=pieces.length >= 3 ? Number(pieces[1]) : NaN; gridCol=pieces.length >= 3 ? Number(pieces[2]) : NaN;
      if (pieces.length < 3 || !pieces[1] || !pieces[2] || !num(gridRow) || !num(gridCol) ||
          Math.abs(gridRow)>10000 || Math.abs(gridCol)>10000) cardRule('metadata_grid');
      if (Math.abs(node.x-(5*row-240)) > .01 || Math.abs(node.y-(315-4.5*col)) > .01) animation('board_metadata_position');
    }
    var canTouch=ownData(block,'canTouch'), isTouched=ownData(block,'isTouched');
    if (typeof canTouch !== 'boolean' || typeof isTouched !== 'boolean') note('touch_flags');
    var specialDescriptor=Object.getOwnPropertyDescriptor(info,'special_info'), special=ownData(info,'special_info'), specialType=0, lock=0;
    if (specialDescriptor && !Object.prototype.hasOwnProperty.call(specialDescriptor,'value')) note('metadata_special_type');
    if (special) {
      specialType=ownData(special,'type');
      if (!integer(specialType,0,10000)) note('metadata_special_type');
      // Block.getIsSpecialBlock returns false for type 0. A lock field is
      // irrelevant in this branch and is often omitted from plain JSON.
      if (specialType !== 0) {
        lock=ownData(special,'lock_state');
        if (!integer(lock,0,10000)) note('metadata_special_lock');
      }
    }
    if (isTouched === true) animation('original_touch_pending');
    return {rawID:rawID,type:integer(type,0,10000) ? 'type:'+type : null,state:state,layer:layer,gridRow:gridRow,gridCol:gridCol,
      selectable:!issue && !(specialType !== 0 && lock !== 0),canTouch:canTouch,specialType:specialType,lock:lock,block:block,ruleIssue:issue};
  }
  function modeActive(component,name,root) {
    var field=name === 'CommonStore' ? 'coverNode' : name === 'GameLayer' ? 'HotTimeMask' : name === 'Game' ? 'WatchMaskNode' : null;
    if (!field) return false;
    var node=ownData(component,field);
    return node && visible(node,root);
  }
  function snapshot(visualStore) {
    budget();
    if (typeof window !== 'object' || !window || (window.top && window.top !== window)) abort('context_unavailable');
    if (typeof document !== 'object' || !document || document.visibilityState !== 'visible' ||
        (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('document_unavailable');
    var cc = window.cc;
    if (!object(cc) || version(cc) !== '2.4.4') abort('engine_version');
    if (!cc.director || typeof cc.director.getScene !== 'function' || !cc.Sprite || !cc.Button || !cc.Component ||
        !cc.Component.EventHandler || !cc.Component.EventHandler.prototype || !cc.js || typeof cc.js.getClassName !== 'function') abort('context_unavailable');
    var emitter = cc.Component.EventHandler.prototype.emit, root = cc.director.getScene();
    if (typeof emitter !== 'function' || !visible(root,root)) abort('context_unavailable');
    var stack = [{n:root,p:null,d:0}], seen = new Set(), records = new Map(), boards = [], trays = [], reserves = [], nodes = [], games = [], modal = false;
    while (stack.length) {
      budget(); var en = stack.pop(), n = en.n;
      if (xray && typeof xray.owns === 'function' && xray.owns(n)) continue;
      if (!object(n) || seen.has(n) || (en.p && n.parent !== en.p)) abort('invalid_scene');
      seen.add(n); if (seen.size > LIMITS.nodes || en.d > LIMITS.depth) abort('scan_limit');
      if (!visible(n,root)) continue;
      records.set(n,en.p); nodes.push(n);
      if (size(n,560,720)) boards.push(n);
      if (size(n,560,80)) trays.push(n);
      if (size(n,240,90)) reserves.push(n);
      if (size(n,240,102)) modal = true;
      if (!size(n,80,90) && typeof n.getComponents === 'function') {
        var comps = n.getComponents(cc.Component);
        if (!Array.isArray(comps) || comps.length > LIMITS.components) abort('scan_limit');
        for (var q = 0; q < comps.length; q++) {
          var name = cc.js.getClassName(comps[q]);
          if (name === 'Game') games.push(comps[q]);
          if (modeActive(comps[q],name,root) && !(visualStore && name==='Game')) abort('external_mode_active');
          if (typeof name === 'string' && /Alert$/.test(name) && comps[q].enabled !== false && comps[q].enabledInHierarchy !== false) modal = true;
        }
      }
      var desc = children(n); if (stack.length + desc.length > LIMITS.nodes) abort('scan_limit');
      for (var j = desc.length-1; j >= 0; j--) stack.push({n:desc[j],p:n,d:en.d+1});
    }
    if (modal) abort('modal_visible');
    if (boards.length !== 1 || trays.length !== 1 || reserves.length !== 1) abort('board_ambiguous');
    var board = boards[0], tray = trays[0], reserve = reserves[0];
    if (!transform(board) || !transform(tray) || !transform(reserve) || !tray.parent || !size(tray.parent,600,130) ||
        typeof tray.parent.getComponent !== 'function') abort('board_geometry');
    var traySprite = tray.parent.getComponent(cc.Sprite);
    if (!traySprite || !traySprite.spriteFrame || typeof traySprite.spriteFrame.name !== 'string' || hash(traySprite.spriteFrame.name) !== '3a2ba3a6') abort('tray_unverified');
    var capacity = tray.width / 80;
    if (capacity !== 7 || tray.x !== 0 || tray.y !== 10) abort('tray_unverified');
    // All three containers must belong to the same gameplay layer.
    var gameLayer = board.parent && board.parent.parent;
    if (!gameLayer || !tray.parent.parent || tray.parent.parent.parent !== gameLayer || !reserve.parent || reserve.parent.parent !== gameLayer) abort('board_geometry');
    var playState=readPlayState(cc,games,gameLayer,records,visualStore);
    if(visualStore){if(playState!==true)abort('context_unavailable');playState=null;}
    var cardList = [], trayList = [], refs = new Map(), rawIDs=new Set(), warehouseSignatures = [], actionRejection=null;
    var zoneNodes = [{n:board,z:'board'},{n:reserve,z:'reserve'},{n:tray,z:'tray'}];
    for (var z = 0; z < zoneNodes.length; z++) {
      var container = zoneNodes[z].n, zone = zoneNodes[z].z, cs = children(container);
      for (var t = 0; t < cs.length; t++) {
        budget(); var card = cs[t];
        if (!visible(card,root) || !size(card,80,90) || !transform(card)) abort('card_geometry');
        if (zone === 'board' && (Math.abs(card.x) > board.width/2+0.01 || Math.abs(card.y) > board.height/2+0.01)) animation('board_bounds');
        var parts = children(card), layout=cardLayout(card,cc), bg=layout.bg, leaves=children(bg);
        if (!visible(bg,root) || !transform(bg) || !size(bg,80,90) || leaves.length !== 1) abort('unknown_card');
        var background = frame(bg,cc), tag = hash(background.name);
        var face = layout.face; if (leaves[0] !== face || !visible(face,root) || !size(face,80,90) || !transform(face)) abort('unknown_card');
        var f = frame(face,cc); if (!frameIDs.has(f)) frameIDs.set(f,'f'+nextFrame++);
        var mask=layout.mask, masked=visible(mask,root), meta=metadata(card,cc,zone,layout), type=meta.type;
        if (rawIDs.has(meta.rawID)) cardRule('duplicate_id'); rawIDs.add(meta.rawID);
        if (meta.ruleIssue && !actionRejection) actionRejection={reason:'unsupported_card_rules',detail:meta.ruleIssue};
        var bgFrames=ownData(meta.block,'BgArr');
        if (tag !== 'a78ac5ca' && tag !== '6be7dcd3' && !(meta.specialType !== 0 && Array.isArray(bgFrames) &&
            bgFrames.length === 3 && bgFrames[2] === background)) abort('unknown_card');
        if (masked) {
          var ms = mask.getComponent && mask.getComponent(cc.Sprite), mf = ms && ms.spriteFrame;
          if (!size(mask,80,90) || mask.opacity !== 128 || !mf || typeof mf.name !== 'string' || hash(mf.name) !== 'f4a086c3') abort('mask_unverified');
        }
        // The original locked-card badge is static; bomb/hot-time branches are not.
        var staticSpecial=meta.specialType !== 0 ? ownData(meta.block,'SpecialNode') : null;
        if ([layout.special,layout.hot,layout.bomb].some(function(n){return visible(n,root) && n.parent === card && n !== staticSpecial;})) abort('card_effect_active');
        var row = {id:id(card),type:type,zone:zone,x:card.x,y:card.y,order:t,blockedBy:[],available:false,node:card,frame:f,masked:masked,layer:meta.layer,gridRow:meta.gridRow,gridCol:meta.gridCol,
          rawID:meta.rawID,selectable:meta.selectable,metadata:meta,occlusionDepth:0,maskNode:mask,faceNode:face};
        refs.set(row.id,row); if (refs.size > LIMITS.cards) abort('scan_limit');
        if (zone === 'tray') { if (masked || Math.abs(card.y) > 0.01) animation('tray_mask_or_y'); trayList.push(row); }
        else cardList.push(row);
      }
    }
    for (var u = 0; u < nodes.length; u++) if (size(nodes[u],80,90) && (children(nodes[u]).length === 5 || children(nodes[u]).length === 4) &&
        nodes[u].parent !== board && nodes[u].parent !== tray && nodes[u].parent !== reserve) {
      var parked=parkedWarehouseCard(nodes[u],cc,root,emitter,records,gameLayer);
      if (!parked) animation('external_card');
      warehouseSignatures.push(parked);
    }
    if (trayList.length >= capacity) abort('tray_full');
    trayList.sort(function(a,b){return a.x-b.x;});
    for (var ti=0;ti<trayList.length;ti++) if (Math.abs(trayList[ti].x-(-240+80*ti)) > 0.01) animation('tray_spacing');
    for (var v=0;v<cardList.length;v++) {
      budget(); var c = cardList[v];
      if (c.zone === 'board') for (var w=0;w<cardList.length;w++) {
        var d = cardList[w]; if (d.zone === 'board' && d.layer > c.layer && Math.abs(d.gridRow-c.gridRow) < 16 && Math.abs(d.gridCol-c.gridCol) < 20) c.blockedBy.push(d.id);
      }
      if (c.zone==='board' && c.masked !== (c.blockedBy.length > 0)) abort('occlusion_mismatch');
      if(visualStore)continue;
      try {
        c.action = action(c,cc,emitter,records,false);
        if (c.action.receiver !== c.metadata.block || c.action.enabled !== c.metadata.canTouch) {
          if (!actionRejection) actionRejection={reason:'unsupported_card_rules',detail:'control_state'};
        }
        c.available = !c.masked && c.action.enabled && c.selectable;
      } catch (error) {
        if (['button_unavailable','handler_ambiguous','event_mismatch','disabled_control','handler_unavailable'].indexOf(rejection) < 0) throw error;
        if (!actionRejection) actionRejection={reason:rejection,detail:null};
        rejection=null;
      }
    }
    var byLayer=cardList.slice().sort(function(a,b){return b.layer-a.layer;});
    byLayer.forEach(function(c){
      var max=-1; c.blockedBy.forEach(function(key){var blocker=refs.get(key);max=Math.max(max,blocker.occlusionDepth);});
      c.occlusionDepth=max+1;
    });
    if(phase&&typeof phase.prepareReserves==='function'){try{phase.prepareReserves({cards:cardList});}catch(_){animation('reserve_metadata');}}
    var reserved=cardList.filter(function(c){return c.zone==='reserve';});
    reserveDiagnostic={status:'ready',cards:reserved.length,verified:reserved.filter(function(c){return c.storageVerified;}).length,
      geometricCovered:reserved.filter(function(c){return integer(c.occlusionDepth,1,512);}).length,masked:reserved.filter(function(c){return c.masked;}).length,
      omitted:Math.max(0,reserved.length-32),rows:reserved.slice(0,32).map(function(c){return {type:c.metadata.type?Number(c.metadata.type.slice(5)):null,
        layer:c.storageVerified?c.storageLayer:null,index:c.storageVerified?c.storageIndex:null,x:c.x,y:c.y,masked:c.masked,
        depth:integer(c.occlusionDepth,0,512)?c.occlusionDepth:null};})};
    cardsRead = refs.size;
    var typesRead = new Set(); refs.forEach(function(c){if (c.type !== null) typesRead.add(c.type);}); cardTypesRead = typesRead.size;
    var sig = [id(root),id(board),id(tray),id(reserve)];
    refs.forEach(function(c){sig.push(c.id,c.zone,c.type,c.x,c.y,c.order,c.masked,c.available,c.rawID,c.layer,c.gridRow,c.gridCol,c.selectable,frameIDs.get(c.frame),c.frame.name);});
    sig.push(warehouseSignatures);
    if(playState)sig.push(id(playState.store),playState.uid,playState.rid,playState.start);
    if(visualStore && (watchedStore()!==visualStore || readPlayState(cc,games,gameLayer,records,visualStore)!==true ||
        window.cc!==cc || cc.director.getScene()!==root))abort('context_changed');
    var mission=visualStore?null:readMission(cc,games,gameLayer,records);
    return {playState:playState,mission:mission,missionKey:mission?mission.key:'unavailable',cc:cc,root:root,gameLayer:gameLayer,board:board,trayNode:tray,reserve:reserve,emitter:emitter,records:records,refs:refs,cards:cardList,tray:trayList,capacity:capacity,signature:JSON.stringify(sig),actionRejection:actionRejection};
  }
  function consumedInSyncedBoard(p,s) {
    var a=p.before.playState,b=s.playState;
    if(!a || !b || p.root!==s.root || a.store!==b.store || a.game!==b.game || a.layer!==b.layer ||
        a.uid!==b.uid || a.rid!==b.rid || a.start!==b.start)return false;
    // A node can be rebuilt or pooled on Resume. Reconcile original card IDs,
    // requiring every Store entry and rendered zone to agree before retiring
    // uncertainty. This does not count an effect as our confirmed move.
    var live=new Map(), entries=0;
    for(var z=0;z<3;z++){
      var field=['pile_blocks','hand_blocks','storage_blocks'][z],zone=['board','tray','reserve'][z],list=ownData(b.store,field);
      if(!Array.isArray(list) || list.length>LIMITS.cards)return false;
      var flat=[];
      for(var i=0;i<list.length;i++){
        var item=list[i];
        if(z===2 && Array.isArray(item)){if(item.length>LIMITS.cards)return false;flat=flat.concat(item);}
        else flat.push(item);
        if(flat.length>LIMITS.cards)return false;
      }
      for(var j=0;j<flat.length;j++){
        budget();if(z===2&&flat[j]===null)continue;var info=flat[j], key=ownData(info,'id'),type=ownData(info,'type');
        if(typeof key!=='string' || !key || live.has(key) || !integer(type,0,10000) || ownData(info,'state')!==z || ++entries>LIMITS.cards)return false;
        live.set(key,{zone:zone,type:'type:'+type});
      }
    }
    if(live.size!==s.refs.size)return false;
    var matches=true;s.refs.forEach(function(c){var entry=live.get(c.rawID);if(!entry || entry.zone!==c.zone || entry.type!==c.type)matches=false;});
    var chosen=live.get(p.card.rawID);
    return matches && (!chosen || (chosen.zone==='tray' && chosen.type===p.card.type));
  }
  function planSnapshot(s,options) {
    if(batchSize>1&&fast&&options.cooperativePlanning!==true){var quick=fast.plan(s);if(quick)return quick;}
    var clean=s.cards.map(function(c){return {id:c.id,type:c.type,zone:c.zone,x:c.x,y:c.y,order:c.order,blockedBy:c.blockedBy.slice(),available:c.available,selectable:c.selectable};});
    var decision=plan({cooperative:options.cooperativePlanning===true,cards:clean,tray:s.tray.map(function(c){return {id:c.id,type:c.type};}),capacity:s.capacity,matchSize:3,budgetMs:8,extendedPlanning:options.extendedPlanning===true,phaseSnapshot:s.phaseSnapshot||null,mission:s.mission?{type:s.mission.type,current:s.mission.current,total:s.mission.total}:null,stateKey:s.signature+'|'+String(generation)});
    if(options.cooperativePlanning===true&&decision)decision.fastBatch=!!(batchSize>1&&fast&&!fast.diagnostic().compatibility&&decision.status==='move'&&Array.isArray(decision.sequence)&&decision.sequence.every(function(id){var c=s.refs.get(id);return c&&c.available&&!c.masked&&c.selectable&&c.metadata.specialType===0&&!c.blockedBy.length;}));
    return decision;
  }
  function unchangedCards(before, after, chosen) {
    var a=before.cards.filter(function(c){return c.id !== chosen;});
    if (a.length !== after.cards.length) return false;
    for (var i=0;i<a.length;i++) { var c=after.refs.get(a[i].id); if (!c || c.zone !== a[i].zone || c.type !== a[i].type) return false; }
    return !after.cards.some(function(c){return c.id === chosen;});
  }
  function confirmedChange(p,s) {
    if (p.root !== s.root || !unchangedCards(p.before,s,p.card.id)) return false;
    var expected = p.before.tray.map(function(c){return {id:c.id,type:c.type};});
    insertAndMatch(expected,p.card);
    if (expected.length !== s.tray.length) return false;
    return expected.every(function(c,i){return s.tray[i].id === c.id && s.tray[i].type === c.type;});
  }
  function terminalBoardReplacement(p,s) {
    // Stage transitions may keep both scene and board objects, and pool the
    // last three card nodes. An elapsed timeout never proves this transition.
    // Require a terminal triple, an observed intervening modal, an empty new
    // bar and a large influx of identities not present in that terminal state.
    if (!p.sawModal || p.before.cards.length !== 1 || p.before.tray.length !== 2 ||
        p.before.cards[0].id !== p.card.id || s.tray.length !== 0 || s.cards.length < 18 ||
        !p.before.tray.every(function(c){return c.type === p.card.type;})) return false;
    var added = 0;
    s.refs.forEach(function(c){if (!p.before.refs.has(c.id)) added++;});
    return added >= 15;
  }
  function testCovered(s,options,now) {
    // ponytail: one deterministic candidate per explicit click, not a second
    // planner or a background retry queue. The original transport owns the ACK.
    var kind=options.penetrateAttempt===true?'penetrate_zero':'touch';coveredRequestKind=kind;
    function blocked(reason){if(covered)covered.block(reason,kind);return result('watching','covered_experiment');}
    if(!covered)return blocked('observer_unavailable');
    if(options.coveredAttempt===true && options.penetrateAttempt===true)return blocked('action_disabled');
    if(options.allowAction!==false)return blocked('action_disabled');
    if(pending || powers && powers.busy())return blocked('original_pending');
    showXray(s,null);
    if(!xrayWanted || xrayState.status!=='ready')return blocked('xray_required');
    if(!s.playState || s.actionRejection)return blocked('context_unavailable');
    if(!stable || stable.signature!==s.signature){stable={signature:s.signature,time:now};return blocked('observing_board');}
    if(now-stable.time<80)return blocked('observing_board');
    var propID=null, socket=null;
    if(kind==='penetrate_zero'){
      var props=ownData(s.playState.store,'props_blocks');
      if(!Array.isArray(props) || props.length>16)return blocked('penetrate_unavailable');
      var matching=props.filter(function(p){return ownData(p,'type')===3;});
      if(matching.length!==1)return blocked('penetrate_unavailable');
      var stock=ownData(matching[0],'count');
      if(!integer(stock,0,1000000))return blocked('penetrate_unavailable');
      if(stock!==0)return blocked('penetrate_stock_not_zero');
      propID=ownData(matching[0],'id');
      // Use only the exact prop row supplied by the game. No invented power ID,
      // count writes, popup activation or isUsingPenetrateProp flag mutation.
      if(typeof propID!=='string' || !propID || propID.length>128 || propID!=='3-'+String(s.playState.uid))return blocked('penetrate_id_unverified');
      var loader=ownData(window,'__require');
      if(typeof loader!=='function')return blocked('context_unavailable');
      try{socket=ownData(loader('Socket'),'default');}catch(_){return blocked('context_unavailable');}
      if(!object(socket))return blocked('context_unavailable');
    }
    var counts=new Map();s.tray.forEach(function(c){counts.set(c.type,(counts.get(c.type)||0)+1);});
    var candidates=s.cards.filter(function(c){
      if(c.zone!=='board' || c.masked!==true || !c.blockedBy.length || !integer(c.occlusionDepth,1,xrayDepth) ||
          !c.selectable || !c.type || !c.metadata || c.metadata.specialType!==0 || !c.action ||
          c.action.button.enabled!==true || c.action.button.enabledInHierarchy!==true)return false;
      var bar=s.tray.map(function(t){return {id:t.id,type:t.type};});insertAndMatch(bar,c);
      return bar.length<s.capacity;
    });
    candidates.sort(function(a,b){return (counts.get(b.type)||0)-(counts.get(a.type)||0) ||
      Number(!!s.mission && b.type===s.mission.type)-Number(!!s.mission && a.type===s.mission.type) ||
      a.occlusionDepth-b.occlusionDepth || a.order-b.order;});
    if(!candidates.length)return blocked('no_covered_card');
    var current=candidates[0], registered=action(current,s.cc,s.emitter,s.records,false);
    if(registered.event!==current.action.event || registered.button!==current.action.button || registered.receiver!==current.metadata.block ||
        window.cc!==s.cc || s.cc.director.getScene()!==s.root || s.cc.Component.EventHandler.prototype.emit!==s.emitter ||
        version(s.cc)!=='2.4.4' || document.visibilityState!=='visible' || current.node.parent!==s.board ||
        !visible(current.node,s.root) || !transform(current.node) || !visible(current.maskNode,s.root) ||
        current.faceNode.parent!==ownData(registered.receiver,'BgSprite').node || frame(current.faceNode,s.cc)!==current.frame)
      return blocked('candidate_unavailable');
    var generatedEvent=kind==='touch'?inputEvent(s.cc,registered.button):null;budget();
    stable=null;planned=null;route=null;
    var invoked=covered.dispatch(s,current,function(){
      if(kind==='touch')return s.emitter.call(registered.event,[generatedEvent]);
      // Lookup after the coordinator installs its observer. Delegation uses the
      // game's UseProp/send and preserves the original Promise identity.
      var returned=socket.UseProp(propID,current.rawID);
      Promise.prototype.then.call(returned,function(){},function(){});
      return returned;
    },{kind:kind});
    return result(invoked?(coveredDiagnostic().status==='uncertain'?'dispatch_uncertain':'original_event_dispatched'):'watching','covered_experiment',invoked);
  }
  function watchBoard(store,options) {
    // Freeze proof progress, retaining every pending original request.
    invalidatePhase('external_mode_active');stable=null;planned=null;route=null;planningState={state:'blocked',nodes:0,slices:0};
    if(pending){pending.confirmation=null;pending.replacement=null;pending.resync=null;}
    if(fast)fast.invalidate();if(covered)covered.invalidate();if(powers)powers.freeze();if(coop)coop.freeze();
    if(covered&&(options.coveredAttempt===true||options.penetrateAttempt===true))covered.block('external_mode_active',coveredRequestKind);
    var why='external_mode_active';
    try { showXray(snapshot(store),null); } catch (_) { why=rejection||'read_error';clearXray(xrayWanted?'blocked':'off'); }
    return result('blocked',why);
  }
  return function runtime(options) {
    options = options || {};
    if(options.command==='phase_snapshot')return readPhaseOnly();
    phaseRequired=options.requirePhaseSnapshot===true;
    xrayWanted=options.xrayEnabled === true;
    if((options.coveredAttempt===true || options.penetrateAttempt===true) && !(covered && covered.busy()))
      coveredRequestKind=options.penetrateAttempt===true?'penetrate_zero':'touch';
    xrayDepth=num(options.xrayDepth) && Math.floor(options.xrayDepth) === options.xrayDepth ? Math.max(1,Math.min(4,options.xrayDepth)) : 1;
    if (!xrayWanted) clearXray('off');
    missionState={status:'unavailable'};reserveDiagnostic={status:'unavailable'};
    rejection = null; animationDetail = null; cardRuleDetail = null; started = clock(); cardsRead = 0; cardTypesRead = 0;
    var command = options.command || 'tick';
    var stabilityMs=options.superFastEnabled===true?20:options.turboEnabled===true?40:80;
    batchSize=options.cardsPerBatch===undefined?(options.superFastEnabled===true?3:1):integer(options.cardsPerBatch,1,3)?options.cardsPerBatch:1;
    var preferences=JSON.stringify([options.extendedPlanning===true,options.turboEnabled===true,options.powersEnabled===true,options.superFastEnabled===true,batchSize]);
    if(preferences!==preferenceKey){preferenceKey=preferences;stable=null;planned=null;route=null;}
    if (command !== 'tick' && command !== 'pause' && command !== 'reset') { clearXray('blocked'); return result('blocked','invalid_command'); }
    if (options.resumeGeneration !== generation) {
      invalidatePhase('context_changed');
      generation = options.resumeGeneration; stable = null; planned = null; route=null; planningState={state:'blocked',nodes:0,slices:0}; clearXray(xrayWanted ? 'blocked' : 'off');
      if (pending) { pending.confirmation=null; pending.replacement=null; pending.resync=null; }
      if(coop)coop.freeze();
      if(fast)fast.invalidate();
      if(covered)covered.invalidate();
    }
    if (command !== 'tick') {
      invalidatePhase('user_paused');
      if(powers)powers.freeze();
      clearXray('off'); stable = null; planned = null; route=null;
      if (pending) { pending.confirmation=null; pending.replacement=null; pending.resync=null; }
      if(coop)coop.freeze();
      if(fast)fast.invalidate();
      if(covered)covered.invalidate();
      return result('paused',pending ? 'pending_preserved' : 'user_paused');
    }
    var watched=watchedStore();if(watched)return watchBoard(watched,options);
    if (typeof plan !== 'function' || !coop) { clearXray(xrayWanted ? 'unavailable' : 'off'); return result('blocked','planner_unavailable'); }
    try {
      if(fast&&fast.busy()){
        if(fast.diagnostic().status==='uncertain'){clearXray(xrayWanted?'blocked':'off');return result('dispatch_uncertain','super_fast_uncertain');}
        var batchObservation=snapshot();refreshPhase(batchObservation);var harvested=fast.observe(batchObservation);showXray(batchObservation,null);
        stable=null;planned=null;route=null;
        if(harvested){confirmed=Math.min(10000,confirmed+harvested);if(powers)powers.normalConfirmed();return result('move_confirmed','super_fast_confirmed');}
        if(fast.diagnostic().status==='resynced')return result('watching','board_resynced');
        return result(fast.diagnostic().status==='uncertain'?'dispatch_uncertain':'waiting_confirmation','super_fast_pending');
      }
      if(covered && covered.busy()){
        var observation=snapshot();refreshPhase(observation);covered.observe(observation);showXray(observation,null);
        stable=null;planned=null;route=null;
        return result(coveredDiagnostic().status==='uncertain'?'dispatch_uncertain':'waiting_confirmation','covered_experiment');
      }
      if((options.coveredAttempt===true || options.penetrateAttempt===true) && (pending || powers && powers.busy())){
        if(covered)covered.block('original_pending',coveredRequestKind);return result('watching','covered_experiment');
      }
      if(powers && powers.needsPopup()){
        invalidatePhase('external_mode_active');
        clearXray(xrayWanted?'blocked':'off');
        var popupResult=powers.tick(options,null);
        return result(popupResult.status,popupResult.reason,popupResult.dispatched);
      }
      var s = snapshot(), now = clock(),phaseReady=refreshPhase(s);
      var cooperation=coop.observe(s,options,now);
      if(cooperation){stable=null;planned=null;route=null;showXray(s,null);if(cooperation.status==='move_confirmed')confirmed=Math.min(10000,confirmed+1);return result(cooperation.status,cooperation.reason,cooperation.dispatched);}
      if((options.coveredAttempt===true||options.penetrateAttempt===true)&&phaseRequired&&!phaseReady)return result('blocked','phase_snapshot_unavailable');
      if(options.coveredAttempt===true || options.penetrateAttempt===true)return testCovered(s,options,now);
      if(powers && powers.busy()){
        planned=null;route=null;stable=null;showXray(s,null);
        if(s.actionRejection){powers.freeze();cardRuleDetail=s.actionRejection.detail;return result('blocked',s.actionRejection.reason);}
        var powerResult=powers.tick(options,s);
        return result(powerResult.status,powerResult.reason,powerResult.dispatched);
      }
      if(observedMissionKey!==s.missionKey){
        // Invalidate prepared actions, not the uncertain original action.
        observedMissionKey=s.missionKey;planned=null;route=null;planningState={state:'blocked',nodes:0,slices:0};
      }
      if(s.mission)missionState={status:s.mission.current===s.mission.total?'complete':'identified',
        targetType:s.mission.targetType,current:s.mission.current,total:s.mission.total};
      if(route && ['priority','fallback'].indexOf(route.missionStatus)>=0 && s.mission && s.mission.current<s.mission.total)
        missionState.status=route.missionStatus;
      if (s.actionRejection) {
        stable=null; planned=null; route=null; planningState={state:'blocked',nodes:0,slices:0};
        if (pending) { pending.confirmation=null; pending.replacement=null; pending.resync=null; }
        showXray(s,null); cardRuleDetail=s.actionRejection.detail;
        return result('blocked',s.actionRejection.reason);
      }
      if (pending) {
        showXray(s,null);
        var terminalReplacement = terminalBoardReplacement(pending,s);
        if (pending.root !== s.root || pending.before.board !== s.board || terminalReplacement) {
          // A different complete board cannot replay the old card. Require two
          // stable observations before retiring uncertainty; do not count a move.
          if (!terminalReplacement && s.refs.has(pending.card.id)) return result('blocked','pending_context_changed');
          if (!pending.replacement || pending.replacement.signature !== s.signature) {
            pending.replacement={signature:s.signature,time:now}; return result('waiting_confirmation','new_board_stability');
          }
          if (now-pending.replacement.time < stabilityMs) return result('waiting_confirmation','new_board_stability');
          stable={signature:s.signature,time:pending.replacement.time};
          pending=null; planned=null; route=null; return result('watching','new_board_detected');
        }
        pending.replacement=null;
        if (confirmedChange(pending,s)) {
          if (!pending.confirmation || pending.confirmation.signature !== s.signature) {
            pending.confirmation={signature:s.signature,time:now}; return result('waiting_confirmation','confirm_stability');
          }
          if (now-pending.confirmation.time < stabilityMs) return result('waiting_confirmation','confirm_stability');
          stable={signature:s.signature,time:pending.confirmation.time};
          if (route && route.sequence[0] === pending.card.id) { route.sequence.shift(); route=validateRoute(s,route); } else route=null;
          pending=null; planned=null; if(powers)powers.normalConfirmed(); confirmed=Math.min(10000,confirmed+1); showXray(s,route); return result('move_confirmed','board_change_confirmed');
        }
        pending.confirmation=null;
        if(consumedInSyncedBoard(pending,s)){
          if(!pending.resync || pending.resync.signature!==s.signature){pending.resync={signature:s.signature,time:now};return result('waiting_confirmation','board_resync_stability');}
          if(now-pending.resync.time<stabilityMs)return result('waiting_confirmation','board_resync_stability');
          stable={signature:s.signature,time:pending.resync.time};pending=null;planned=null;route=null;
          return result('watching','board_resynced');
        }
        pending.resync=null;
        // Visual advice is independently proved against the current board;
        // an uncertain callback blocks dispatch, not read-only trio hints.
        if(xrayWanted&&(!phaseRequired||phaseReady)){
          if(!stable || stable.signature!==s.signature)stable={signature:s.signature,time:now};
          else if(now-stable.time>=stabilityMs)showXray(s,validateRoute(s,planSnapshot(s,options),true));
        }
        return result('waiting_confirmation',now-pending.time > 8000 ? 'confirmation_uncertain' : 'awaiting_original_result');
      }
      if(options.superFastEnabled===true&&!fast)return result('blocked','super_fast_unavailable');
      if(phaseRequired&&!phaseReady){showXray(s,null);return result('waiting_stability',phaseDiagnostic().status==='waiting'?'phase_snapshot_stability':'phase_snapshot_unavailable');}
      if (options.allowAction !== true && !xrayWanted) { stable=null; planned=null; route=null; return result('watching','action_disabled'); }
      if (!stable || stable.signature !== s.signature) { planned=null; stable={signature:s.signature,time:now}; showXray(s,null); return result('waiting_stability','observing_board'); }
      if (now-stable.time < stabilityMs) return result('waiting_stability','observing_board');
      if (!planned) {
        route=route && validateRoute(s,route);
        if (!route) {
          var decision=planSnapshot(s,options);
          if (object(decision) && decision.status === 'searching' && decision.reason === 'search_in_progress') {
            plannerDiagnostic(decision,'searching'); showXray(s,null); return result('planning','search_in_progress');
          }
          if (!object(decision) || decision.status !== 'move' || typeof decision.cardID !== 'string') {
            plannerDiagnostic(decision,'blocked'); showXray(s,null);
            var reasons=['observed_state_unbalanced','observed_state_locked','no_complete_solution','search_limit_reached','board_clear','no_remaining_triples','invalid_state'];
            if(options.cooperativePlanning===true&&['no_complete_solution','no_remaining_triples','search_limit_reached','no_safe_move'].indexOf(decision&&decision.reason)>=0){
              var supplied=coop.begin(s,options,{parked:parkedWarehouseCard,layout:cardLayout,action:action,input:inputEvent,ready:refreshPhase,budget:budget},now);
              if(supplied){stable=null;planned=null;route=null;return result(supplied.status,supplied.reason,supplied.dispatched);}
            }
            if(powers && !pending && powers.begin(s,options,object(decision)?decision.reason:null)){
              stable=null;planned=null;route=null;return result('original_event_dispatched','power_popup_opened',true);
            }
            if(options.cooperativePlanning===true&&options.allowAction===true&&decision&&['no_complete_solution','no_remaining_triples'].indexOf(decision.reason)>=0)return result('watching','waiting_supply');
            return result('blocked',object(decision) && reasons.indexOf(decision.reason) >= 0 ? decision.reason : 'no_safe_move');
          }
          if (!Array.isArray(decision.actions) || JSON.stringify(decision.actions) !== JSON.stringify(decision.sequence) ||
              !decision.sequence || decision.cardID !== decision.sequence[0]) abort('planner_invalid_move');
          route=validateRoute(s,decision,true); if (!route) abort('planner_invalid_move');
          route.missionKey=s.missionKey;
          route.missionStatus=object(decision.stats) && ['priority','fallback'].indexOf(decision.stats.missionStatus)>=0?decision.stats.missionStatus:null;
          plannerDiagnostic(decision,'proved');
        }
        var candidate=s.refs.get(route.sequence[0]);
        if (!candidate || !candidate.available || candidate.zone === 'tray') abort('planner_invalid_move');
        planned={signature:s.signature,cardID:candidate.id,event:candidate.action.event,button:candidate.action.button,receiver:candidate.action.receiver};
        showXray(s,route);
        // Revalidate on a fresh tick before dispatch.
        return result('waiting_stability','plan_ready');
      }
      if (planned.signature !== s.signature) abort('context_changed');
      route=validateRoute(s,route); if (!route || route.sequence[0] !== planned.cardID) abort('planner_invalid_move');
      showXray(s,route);
      if (options.allowAction !== true) return result('watching','action_disabled');
      if(batchSize>1&&fast&&route.fastBatch===true){
        var batchCards=route.sequence.map(function(key){return s.refs.get(key);}),prepared=[];
        for(var bi=0;bi<batchCards.length;bi++){var bc=batchCards[bi],ba=action(bc,s.cc,s.emitter,s.records,true);
          if(ba.receiver!==bc.metadata.block)abort('context_changed');prepared.push({card:bc,action:ba,event:inputEvent(s.cc,ba.button)});}
        budget();if(!phase||!refreshPhase(s))return result('waiting_stability','phase_snapshot_unavailable');
        planned=null;route=null;stable=null;
        var burstStarted=clock();
        var burst=fast.dispatch(s,batchCards,function(card,index){
          var saved=prepared[index],a,info;try{a=action(card,s.cc,s.emitter,s.records,true);info=ownData(a.receiver,'blockInfo');
          if(clock()-burstStarted>=4||window.cc!==s.cc||s.cc.director.getScene()!==s.root||document.visibilityState!=='visible'||
              s.cc.Component.EventHandler.prototype.emit!==s.emitter||a.event!==saved.action.event||a.button!==saved.action.button||a.receiver!==saved.action.receiver||
              card.node.parent!==(card.zone==='board'?s.board:s.reserve)||!visible(card.node,s.root)||!transform(card.node)||visible(card.maskNode,s.root)||
              ownData(a.receiver,'canTouch')!==true||ownData(a.receiver,'isTouched')!==false||ownData(info,'id')!==card.rawID||'type:'+ownData(info,'type')!==card.type||
              ownData(info,'state')!==(card.zone==='board'?0:2)||ownData(info,'special_info')&&ownData(ownData(info,'special_info'),'type')!==0||
              card.faceNode.parent!==ownData(a.receiver,'BgSprite').node||!visible(card.faceNode,s.root)||frame(card.faceNode,s.cc)!==card.frame)return false;
          }catch(_){return false;}
          s.emitter.call(a.event,[saved.event]);return true;
        },batchSize);
        var fd=fast.diagnostic();
        return result(fd.status==='uncertain'?'dispatch_uncertain':burst?'original_event_dispatched':fd.compatibility?'watching':'blocked',
          fd.status==='uncertain'?'super_fast_uncertain':burst?'super_fast_pending':fd.compatibility?'super_fast_compatibility':'super_fast_unavailable',burst);
      }
      var current=s.refs.get(planned.cardID);
      if (!current || !current.available || current.zone === 'tray') abort('planner_invalid_move');
      var registered=action(current,s.cc,s.emitter,s.records,true); budget();
      if (registered.event !== planned.event || registered.button !== planned.button || registered.receiver !== planned.receiver ||
          window.cc !== s.cc || s.cc.director.getScene() !== s.root || version(s.cc) !== '2.4.4' ||
          s.cc.Component.EventHandler.prototype.emit !== s.emitter || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive') ||
          current.node.parent !== (current.zone === 'board' ? s.board : s.reserve) ||
          !visible(current.node,s.root) || !transform(current.node) || visible(current.maskNode,s.root) ||
          current.faceNode.parent !== ownData(registered.receiver,'BgSprite').node || frame(current.faceNode,s.cc) !== current.frame) abort('context_changed');
      var generatedEvent=inputEvent(s.cc,registered.button); budget();
      if(phase && !refreshPhase(s))return result('waiting_stability','phase_snapshot_unavailable');
      budget();
      var fresh=s;
      planned=null;
      pending={root:s.root,card:current,before:fresh,time:clock(),confirmation:null}; stable=null;
      try { s.emitter.call(registered.event,[generatedEvent]); }
      catch (_) { return result('dispatch_uncertain','event_exception',true); }
      return result('original_event_dispatched','awaiting_original_result',true);
    } catch (_) {
      if(fast&&fast.busy()&&typeof fast.terminal==='function'){var endCount=fast.terminal();
        if(endCount){confirmed=Math.min(10000,confirmed+endCount);invalidatePhase('observation_interrupted');return result('move_confirmed','super_fast_confirmed');}
        if(fast.diagnostic().status==='resynced')return result('watching','board_resynced');}
      invalidatePhase(rejection==='external_mode_active'?'external_mode_active':'observation_interrupted');
      if(fast)fast.invalidate(rejection);
      if(covered)covered.invalidate();
      if(powers)powers.freeze();
      if(coop)coop.freeze();
      if (pending) {
        if (rejection === 'modal_visible') pending.sawModal=true;
        // An incomplete snapshot breaks consecutiveness of the proof, even
        // when a later state happens to have the same signature.
        pending.confirmation=null; pending.replacement=null;
        pending.resync=null;
      }
      clearXray(xrayWanted ? 'blocked' : 'off'); stable=null; planned=null; route=null; return result('blocked',rejection || 'read_error');
    }
  };
})

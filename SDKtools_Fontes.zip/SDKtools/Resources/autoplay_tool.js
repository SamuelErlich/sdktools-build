/* SDKtools V3.3. Live, bounded Cocos 2.4.4 adapter. Calls only the original
 * registered touchBlock event. No captured source, inventory or network writes.
 * Expression: (autoplay_tool.js)(autoplay_planner.js, xray_overlay.js) -> runtime(options).
 */
(function (plan, makeXray) {
  'use strict';
  var ids = new WeakMap(), frameIDs = new WeakMap(), nextID = 1, nextFrame = 1;
  var stable = null, planned = null, pending = null, route = null, generation = null, confirmed = 0, cardsRead = 0, cardTypesRead = 0;
  var observedMissionKey=null, missionState={status:'unavailable'};
  var xrayDepth=1, planningState={state:'blocked',nodes:0,slices:0}, xray = null, xrayWanted = false, xrayState = {status:'off',coveredIcons:0,matchedBorders:0};
  try { if (typeof makeXray === 'function') xray = makeXray(); } catch (_) {}
  var LIMITS = { nodes: 4096, children: 512, cards: 512, depth: 24, components: 32, budgetMs: 18 };
  var rejection = null, animationDetail = null, cardRuleDetail = null, started = 0;
  function object(x) { return x !== null && (typeof x === 'object' || typeof x === 'function'); }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  function clock() { return typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now(); }
  function abort(reason) { rejection = reason; throw Error('SDKtools guard'); }
  function animation(reason) { animationDetail = reason; abort('animation_active'); }
  function cardRule(detail) { cardRuleDetail=detail; abort('unsupported_card_rules'); }
  function budget() { if (clock() - started >= LIMITS.budgetMs) abort('time_budget'); }
  function id(x) { if (!ids.has(x)) ids.set(x, 'c' + nextID++); return ids.get(x); }
  function size(n, w, h) { return n.width === w && n.height === h; }
  function visible(n, root) { return object(n) && n.isValid === true && n.activeInHierarchy === true &&
    (n === root || n.active === true) && num(n.opacity) && n.opacity > 0 && n.opacity <= 255; }
  function children(n) { var a = n.children; if (!Array.isArray(a)) abort('invalid_scene');
    if (a.length > LIMITS.children) abort('scan_limit'); return a; }
  function version(cc) { var a = cc.ENGINE_VERSION, b = window.CocosEngine;
    return typeof a === 'string' && typeof b === 'string' && a !== b ? null : typeof a === 'string' ? a : b; }
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length && i < 128; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
  function result(status, reason, dispatched) { var output = { version: 1, status: status, reason: reason,
    cardsRead: cardsRead, cardTypesRead: cardTypesRead, confirmedMoves: confirmed, dispatched: dispatched === true,
    awaitingBoardChange: pending !== null };
    output.xray = xrayState; output.planning=Object.assign({},planningState,{mission:missionState});
    if (animationDetail) output.animationDetail = animationDetail;
    if (cardRuleDetail) output.cardRuleDetail = cardRuleDetail;
    return output; }
  function transform(n) { return num(n.x) && num(n.y) && n.angle === 0 && n.scaleX === 1 && n.scaleY === 1 &&
    n.anchorX === 0.5 && n.anchorY === 0.5 && (!num(n.z) || n.z === 0); }
  function frame(n, cc) { if (typeof n.getComponent !== 'function') abort('sprite_unavailable');
    var s = n.getComponent(cc.Sprite), f = s && s.spriteFrame;
    if (!object(s) || s.enabled !== true || s.enabledInHierarchy !== true || !object(f) ||
        typeof f.name !== 'string' || !f.name || f.name.length > 256 || typeof f.getRect !== 'function') abort('unknown_card');
    var r = f.getRect(); if (!object(r) || r.width !== 120 || r.height !== 135) abort('unknown_card');
    return f; }
  function action(card, cc, emitter, records, requireEnabled) {
    var nodes = [card.node], a = children(card.node), matches = [];
    for (var i = 0; i < a.length; i++) if (visible(a[i], null)) nodes.push(a[i]);
    for (var j = 0; j < nodes.length; j++) {
      var n = nodes[j]; if (typeof n.getComponent !== 'function') abort('button_unavailable');
      var b = n.getComponent(cc.Button); if (!b) continue;
      var events = b.clickEvents;
      if (!Array.isArray(events) || events.length !== 1 || !events[0] || events[0].handler !== 'touchBlock') continue;
      matches.push({button:b,event:events[0],node:n});
    }
    if (matches.length !== 1) abort('handler_ambiguous');
    var m = matches[0], b = m.button, e = m.event, target = e.target;
    if (b.isValid !== true || b.node !== m.node || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype, e) ||
        e.emit !== emitter || e.customEventData !== '' || !object(target) || !records.has(target) ||
        (target !== card.node && target.parent !== card.node) || typeof target.getComponents !== 'function') abort('event_mismatch');
    if (requireEnabled && (b.enabled !== true || b.enabledInHierarchy !== true || b.interactable !== true)) abort('disabled_control');
    var components = target.getComponents(cc.Component), found = [];
    if (!Array.isArray(components) || components.length > LIMITS.components) abort('handler_unavailable');
    for (var k = 0; k < components.length; k++) {
      var c = components[k]; if (c && typeof c.touchBlock === 'function') found.push(c);
    }
    if (found.length !== 1 || found[0].isValid !== true || found[0].node !== target || found[0].touchBlock.length > 2) abort('handler_ambiguous');
    // If the public registration exposes a name, ensure it resolves to the same receiver.
    if (typeof e.component === 'string' && e.component &&
        (typeof target.getComponent !== 'function' || target.getComponent(e.component) !== found[0])) abort('event_mismatch');
    return {button:b,event:e,receiver:found[0],enabled:b.enabled === true && b.enabledInHierarchy === true && b.interactable === true};
  }
  function inputEvent(cc, button) {
    // CCButton._onTouchEnded forwards EventTouch to clickEvents. Its separate
    // node.emit('click', button) API is not the registered component callback.
    // Cocos 2.4 CCEvent.js initializes _eventCode through _setEventCode; only
    // this newly allocated event is changed, never a real input or game node.
    var n=button.node, EventTouch=cc.Event && cc.Event.EventTouch;
    if (typeof cc.Touch !== 'function' || typeof EventTouch !== 'function' ||
        EventTouch.ENDED !== 2 || cc.Event.AT_TARGET !== 2 || !cc.Node || !cc.Node.EventType ||
        cc.Node.EventType.TOUCH_END !== 'touchend' || typeof cc.v2 !== 'function' ||
        typeof n.convertToWorldSpaceAR !== 'function') abort('input_event_unavailable');
    var point=n.convertToWorldSpaceAR(cc.v2(0,0));
    if (!object(point) || !num(point.x) || !num(point.y)) abort('input_event_unavailable');
    var touch=new cc.Touch();
    if (!object(touch) || typeof touch.setTouchInfo !== 'function') abort('input_event_unavailable');
    touch.setTouchInfo(0,point.x,point.y);
    var event=new EventTouch([touch],true), proto=EventTouch.prototype;
    if (!object(event) || !object(proto) || !Object.prototype.isPrototypeOf.call(proto,event) ||
        typeof proto._setEventCode !== 'function' || typeof event.getEventCode !== 'function' ||
        typeof event.getTouches !== 'function' || typeof event.getLocation !== 'function') abort('input_event_unavailable');
    event.touch=touch; event.currentTouch=touch;
    event.target=n; event.currentTarget=n; event.type=cc.Node.EventType.TOUCH_END; event.eventPhase=cc.Event.AT_TARGET;
    proto._setEventCode.call(event,EventTouch.ENDED);
    var location=event.getLocation(), touches=event.getTouches();
    if (event.target !== n || event.currentTarget !== n || event.touch !== touch ||
        event.getEventCode() !== EventTouch.ENDED || event.type !== 'touchend' ||
        !Array.isArray(touches) || touches.length !== 1 || touches[0] !== touch ||
        !object(location) || location.x !== point.x || location.y !== point.y) abort('input_event_unavailable');
    return event;
  }
  function parkedWarehouseCard(card,cc,root,emitter,records,gameLayer) {
    var slot=card.parent, row=slot && slot.parent, panel=row && row.parent;
    if (!slot || !row || !panel || !size(slot,84,94) || !size(row,260,94) || !size(panel,272,126) ||
        !panel.parent || panel.parent.parent !== gameLayer || !records.has(panel) ||
        !transform(slot) || !transform(row) || !transform(panel) || row.x !== 0 || row.y !== 8 ||
        typeof panel.getComponent !== 'function') return null;
    var ps=panel.getComponent(cc.Sprite), pf=ps && ps.spriteFrame;
    if (!ps || ps.enabled !== true || ps.enabledInHierarchy !== true || !pf || typeof pf.name !== 'string' ||
        hash(pf.name) !== 'd0a9f790' || typeof pf.getRect !== 'function') return null;
    var pr=pf.getRect(); if (!pr || pr.width !== 272 || pr.height !== 126) return null;
    var slots=children(row), signature=[], found=false;
    if (slots.length !== 3) return null;
    for (var i=0;i<slots.length;i++) {
      budget(); var n=slots[i];
      if (!visible(n,root) || !records.has(n) || n.parent !== row || !size(n,84,94) || !transform(n) ||
          n.x !== -88+88*i || n.y !== 0 || typeof n.getComponents !== 'function' || typeof n.getComponent !== 'function') return null;
      var components=n.getComponents(cc.Component), matches=[];
      if (!Array.isArray(components) || components.length > LIMITS.components) return null;
      for (var j=0;j<components.length;j++) if (components[j] && typeof components[j].onBtnClick === 'function') matches.push(components[j]);
      if (matches.length !== 1 || cc.js.getClassName(matches[0]) !== 'CommonStoreItem') return null;
      var c=matches[0], b=n.getComponent(cc.Button), events=b && b.clickEvents, e=Array.isArray(events) && events.length === 1 && events[0];
      if (!c || c.isValid !== true || c.node !== n || typeof c.isSelf !== 'boolean' || typeof c.isEmpty !== 'boolean' ||
          typeof c.onBtnClick !== 'function' || c.onBtnClick.length !== 0 || !b || b.isValid !== true || b.node !== n ||
          !e || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype,e) || e.emit !== emitter ||
          e.handler !== 'onBtnClick' || e.target !== n || e.customEventData !== '' ||
          (typeof e.component === 'string' && e.component && n.getComponent(e.component) !== c)) return null;
      var possible=children(n).filter(function(child){return visible(child,root) && size(child,80,90) && children(child).length === 5;});
      if (possible.length > 1 || c.isEmpty !== (possible.length === 0)) animation('warehouse_card_unsettled');
      signature.push(id(n),c.isSelf,c.isEmpty);
      if (n === slot) {
        if (possible.length !== 1 || possible[0] !== card) animation('warehouse_card_unsettled');
        found=true;
      }
    }
    if (!found || !transform(card) || card.x !== 0 || card.y !== 0) animation('warehouse_card_unsettled');
    var parts=children(card), bg=parts[0], faces=children(bg);
    if (!visible(bg,root) || !transform(bg) || !size(bg,80,90) || faces.length !== 1 ||
        parts.slice(1).some(function(n){return visible(n,root);})) animation('warehouse_card_unsettled');
    var background=frame(bg,cc), tag=hash(background.name), face=faces[0];
    if ((tag !== 'a78ac5ca' && tag !== '6be7dcd3') || !visible(face,root) || !size(face,80,90) || !transform(face)) animation('warehouse_card_unsettled');
    var f=frame(face,cc); if (!frameIDs.has(f)) frameIDs.set(f,'f'+nextFrame++);
    // Membership only. Warehouse ownership never authorizes a click here.
    signature.push(id(card),frameIDs.get(f),f.name,card.x,card.y);
    return signature;
  }
  function clearXray(status) {
    try { if (xray && typeof xray.clear === 'function') xray.clear(); } catch (_) {}
    xrayState={status:status || 'off',coveredIcons:0,matchedBorders:0};
  }
  function showXray(s, proof) {
    if (!xrayWanted) { clearXray('off'); return; }
    if (!xray || typeof xray.render !== 'function') { clearXray('unavailable'); return; }
    try {
      var rendered=xray.render(s,proof,{depth:xrayDepth});
      xrayState=rendered && rendered.status === 'ready' ? {status:'ready',
        coveredIcons:Math.max(0,Math.min(512,rendered.coveredIcons|0)),
        matchedBorders:Math.max(0,Math.min(3,rendered.matchedBorders|0)),depthLimit:xrayDepth,
        hiddenByDepth:Math.max(0,Math.min(512,rendered.hiddenByDepth|0)),hiddenByLayout:Math.max(0,Math.min(512,rendered.hiddenByLayout|0)),
        labelMode:['none','cocos_label','vector_digits'].indexOf(rendered.labelMode) >= 0 ? rendered.labelMode : 'none'} : {status:'unavailable',coveredIcons:0,matchedBorders:0};
    } catch (_) { clearXray('unavailable'); }
  }
  // HandArea.calculateInsertIndex/findThreeBlock: group insertion followed
  // by the first adjacent equal trio, matching the original local rule.
  function insertAndMatch(bar,card) {
    var index=-1;
    for (var i=0;i<bar.length;i++) {
      if (i+1 === bar.length) { index=i+1; break; }
      if (bar[i].type === card.type && bar[i+1].type !== card.type) { index=i+1; break; }
    }
    bar.splice(index,0,{id:card.id,type:card.type});
    for (var j=0;j<bar.length-2;j++) if (bar[j].type === bar[j+1].type && bar[j].type === bar[j+2].type) return bar.splice(j,3);
    return null;
  }
  // Independently replay a local route through its FIRST completed trio.
  // No score, timeout or arbitrary single pick authorizes an event. The next
  // trio is recalculated after completion using the newly observed board.
  function validateRoute(s, decision, checkMarker) {
    if (!object(decision) || !Array.isArray(decision.sequence) || decision.sequence.length < 1 || decision.sequence.length > 512 ||
        decision.proofKind !== 'local_trio' || (decision.missionKey !== undefined && decision.missionKey !== s.missionKey)) return null;
    var removed=new Set(), bar=s.tray.map(function(c){return {id:c.id,type:c.type};}), peak=bar.length, firstTrio=null, lastTrio=null;
    for (var i=0;i<decision.sequence.length;i++) {
      budget(); var card=s.refs.get(decision.sequence[i]);
      if (!card || card.zone === 'tray' || card.selectable === false || removed.has(card.id) || (i === 0 && !card.available) ||
          (!card.available && !card.blockedBy.length) || card.blockedBy.some(function(v){return !removed.has(v);})) return null;
      removed.add(card.id); peak=Math.max(peak,bar.length+1);
      if (bar.length+1 > s.capacity) return null;
      lastTrio=insertAndMatch(bar,card);
      if (bar.length >= s.capacity) return null;
      if (lastTrio && i !== decision.sequence.length-1) return null;
      if (!firstTrio && lastTrio) firstTrio=lastTrio;
    }
    if (!firstTrio || !lastTrio) return null;
    var left=s.cards.filter(function(c){return !removed.has(c.id);}).concat(bar);
    var trio=firstTrio.map(function(c){return c.id;}), matchedType=firstTrio[0].type;
    if (checkMarker && (decision.matchedType !== matchedType || !Array.isArray(decision.tripleCardIDs) ||
        decision.tripleCardIDs.length !== 3 || new Set(decision.tripleCardIDs).size !== 3 ||
        !trio.every(function(v){return decision.tripleCardIDs.indexOf(v) >= 0;}))) return null;
    return {proofKind:decision.proofKind,sequence:decision.sequence.slice(),tripleCardIDs:trio,matchedType:matchedType,
      peakTrayCount:peak,residualCards:left.length,missionKey:decision.missionKey,missionStatus:decision.missionStatus};
  }
  function plannerDiagnostic(decision,state) {
    var stats=object(decision) && object(decision.stats) ? decision.stats : {};
    planningState={state:state,nodes:num(stats.expanded) ? Math.max(0,Math.min(1000000,Math.floor(stats.expanded))) : 0,
      slices:num(stats.slices) ? Math.max(0,Math.min(1000000,Math.floor(stats.slices))) : 0};
    if (['searching','priority','fallback'].indexOf(stats.missionStatus)>=0 && missionState.status!=='unavailable' && missionState.status!=='complete')
      missionState.status=stats.missionStatus;
    if (stats.goal === 'next_trio') planningState.goal=stats.goal;
    if (num(stats.residualCards)) planningState.residualCards=Math.max(0,Math.min(512,Math.floor(stats.residualCards)));
    if (route) { planningState.goal='next_trio'; planningState.residualCards=route.residualCards; }
  }
  function ownData(o,key) {
    if (!object(o)) return undefined;
    var descriptor=Object.getOwnPropertyDescriptor(o,key);
    return descriptor && Object.prototype.hasOwnProperty.call(descriptor,'value') ? descriptor.value : undefined;
  }
  function integer(v,min,max) { return num(v) && Math.floor(v) === v && v >= min && v <= max; }
  // Original Alpaca Task.setup reads GameStore.task_info. Do not infer the
  // type from skins or labels: the reward animation displays the old task
  // after updateCommonTask has already installed new_task_info in the Store.
  // Only read the loaded module after verifying Game -> GameLayer / Task in
  // this scene. No hooks, getters, pushes, props or mission writes are needed.
  function readMission(cc,games,gameLayer,records) {
    try {
      if(games.length!==1)return null;
      var game=games[0], layer=ownData(game,'GameLayer'), task=ownData(game,'Task');
      if(game.isValid!==true || game.enabled===false || game.enabledInHierarchy===false ||
          !records.has(game.node) || !layer || layer.node!==gameLayer || layer.isValid!==true ||
          cc.js.getClassName(layer)!=='GameLayer' || !task || cc.js.getClassName(task)!=='Task' ||
          task.isValid!==true || !records.has(task.node) || task.enabled===false || task.enabledInHierarchy===false)return null;
      // The Game component must own the gameplay layer and task subtree.
      function inside(n) { for(var d=0;n && d<=LIMITS.depth;d++,n=records.get(n))if(n===game.node)return true;return false; }
      if(!inside(gameLayer) || !inside(task.node))return null;
      var loader=ownData(window,'__require');if(typeof loader!=='function')return null;
      var store=ownData(loader('GameStore'),'default');
      if(!store || !Array.isArray(ownData(store,'pile_blocks')) || !Array.isArray(ownData(store,'hand_blocks')) ||
          !Array.isArray(ownData(store,'storage_blocks')) || ownData(store,'isWatcher')!==false)return null;
      var info=ownData(store,'task_info'), type=ownData(info,'target_block_type'),
        current=ownData(info,'current_num'), total=ownData(info,'total_num');
      if(!integer(type,1,10000) || !integer(total,1,1000000) || !integer(current,0,total))return null;
      return {type:'type:'+type,current:current,total:total,key:JSON.stringify([id(game),id(store),type,current,total]),targetType:type};
    } catch (_) { return null; } // Optional mission data must not stop normal play.
  }
  function cardLayout(node,cc) {
    if (typeof node.getComponents !== 'function') cardRule('component');
    var components=node.getComponents(cc.Component), blocks=[];
    if (!Array.isArray(components) || components.length > LIMITS.components) cardRule('component');
    for (var i=0;i<components.length;i++) if (cc.js.getClassName(components[i]) === 'Block') blocks.push(components[i]);
    if (blocks.length !== 1) cardRule('component');
    var block=blocks[0], bgSprite=ownData(block,'BgSprite'), skin=ownData(block,'SkinSprite'),
      bg=bgSprite && bgSprite.node, face=skin && skin.node, mask=ownData(block,'MaskNode'), special=ownData(block,'SpecialNode'),
      hot=ownData(block,'HotTimeAnimNode'), bomb=ownData(block,'BombAnimNode'), actual=children(node), required=[bg,mask,hot,bomb];
    if (!block || block.node !== node || block.isValid !== true || !bg || !face || !mask || !hot || !bomb ||
        face.parent !== bg || new Set(required).size !== 4 || !required.every(function(n){return n.parent === node;})) abort('card_geometry');
    if (special && special.parent === node) required.push(special);
    else {
      var specialInfo=ownData(ownData(block,'blockInfo'),'special_info');
      if (!special || !object(specialInfo) || ownData(specialInfo,'type') === 0 || ownData(specialInfo,'lock_state') !== 0) abort('card_geometry');
    }
    if (actual.length !== required.length || new Set(required).size !== required.length ||
        !actual.every(function(n){return required.indexOf(n) >= 0;})) abort('card_geometry');
    return {block:block,bg:bg,face:face,mask:mask,special:special,hot:hot,bomb:bomb};
  }
  function metadata(node,cc,zone,layout) {
    var block=layout.block, info=ownData(block,'blockInfo'), rawID=ownData(info,'id'), type=ownData(info,'type'),
      state=ownData(info,'state'), layer=0, gridRow=0, gridCol=0, issue=null;
    function note(detail) { if (!issue) issue=detail; }
    if (!block || block.node !== node || block.isValid !== true) cardRule('component');
    if (!object(info)) cardRule('metadata_missing');
    if (typeof rawID !== 'string' || !rawID || rawID.length > 128) cardRule('metadata_id');
    if (!integer(type,0,10000)) note('metadata_type');
    if (state !== (zone === 'board' ? 0 : zone === 'tray' ? 1 : 2)) note('metadata_state');
    // Only PileArea uses original grid/layer/row/col. StorageArea and HandArea
    // use their own placement rules and may contain cards without pile fields.
    if (zone === 'board') {
      layer=ownData(info,'layer'); var row=ownData(info,'row'), col=ownData(info,'col');
      if (!integer(layer,0,10000)) cardRule('metadata_layer');
      if (!num(row) || !num(col) || Math.abs(row)>10000 || Math.abs(col)>10000) cardRule('metadata_position');
      // The original reads ID components 1 and 2, preserving the entire ID as
      // identity. It does not reject an additional opaque suffix.
      var pieces=rawID.split('-'); gridRow=pieces.length >= 3 ? Number(pieces[1]) : NaN; gridCol=pieces.length >= 3 ? Number(pieces[2]) : NaN;
      if (pieces.length < 3 || !pieces[1] || !pieces[2] || !num(gridRow) || !num(gridCol) ||
          Math.abs(gridRow)>10000 || Math.abs(gridCol)>10000) cardRule('metadata_grid');
      if (Math.abs(node.x-(5*row-240)) > .01 || Math.abs(node.y-(315-4.5*col)) > .01) animation('board_metadata_position');
    }
    var canTouch=ownData(block,'canTouch'), isTouched=ownData(block,'isTouched');
    if (typeof canTouch !== 'boolean' || typeof isTouched !== 'boolean') note('touch_flags');
    var specialDescriptor=Object.getOwnPropertyDescriptor(info,'special_info'), special=ownData(info,'special_info'), specialType=0, lock=0;
    if (specialDescriptor && !Object.prototype.hasOwnProperty.call(specialDescriptor,'value')) note('metadata_special_type');
    if (special) {
      specialType=ownData(special,'type');
      if (!integer(specialType,0,10000)) note('metadata_special_type');
      // Block.getIsSpecialBlock returns false for type 0. A lock field is
      // irrelevant in this branch and is often omitted from plain JSON.
      if (specialType !== 0) {
        lock=ownData(special,'lock_state');
        if (!integer(lock,0,10000)) note('metadata_special_lock');
      }
    }
    if (isTouched === true) animation('original_touch_pending');
    return {rawID:rawID,type:integer(type,0,10000) ? 'type:'+type : null,state:state,layer:layer,gridRow:gridRow,gridCol:gridCol,
      selectable:!issue && !(specialType !== 0 && lock !== 0),canTouch:canTouch,specialType:specialType,lock:lock,block:block,ruleIssue:issue};
  }
  function modeActive(component,name,root) {
    var field=name === 'CommonStore' ? 'coverNode' : name === 'GameLayer' ? 'HotTimeMask' : name === 'Game' ? 'WatchMaskNode' : null;
    if (!field) return false;
    var node=ownData(component,field);
    return node && visible(node,root);
  }
  function snapshot() {
    budget();
    if (typeof window !== 'object' || !window || (window.top && window.top !== window)) abort('context_unavailable');
    if (typeof document !== 'object' || !document || document.visibilityState !== 'visible' ||
        (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('document_unavailable');
    var cc = window.cc;
    if (!object(cc) || version(cc) !== '2.4.4') abort('engine_version');
    if (!cc.director || typeof cc.director.getScene !== 'function' || !cc.Sprite || !cc.Button || !cc.Component ||
        !cc.Component.EventHandler || !cc.Component.EventHandler.prototype || !cc.js || typeof cc.js.getClassName !== 'function') abort('context_unavailable');
    var emitter = cc.Component.EventHandler.prototype.emit, root = cc.director.getScene();
    if (typeof emitter !== 'function' || !visible(root,root)) abort('context_unavailable');
    var stack = [{n:root,p:null,d:0}], seen = new Set(), records = new Map(), boards = [], trays = [], reserves = [], nodes = [], games = [], modal = false;
    while (stack.length) {
      budget(); var en = stack.pop(), n = en.n;
      if (xray && typeof xray.owns === 'function' && xray.owns(n)) continue;
      if (!object(n) || seen.has(n) || (en.p && n.parent !== en.p)) abort('invalid_scene');
      seen.add(n); if (seen.size > LIMITS.nodes || en.d > LIMITS.depth) abort('scan_limit');
      if (!visible(n,root)) continue;
      records.set(n,en.p); nodes.push(n);
      if (size(n,560,720)) boards.push(n);
      if (size(n,560,80)) trays.push(n);
      if (size(n,240,90)) reserves.push(n);
      if (size(n,240,102)) modal = true;
      if (!size(n,80,90) && typeof n.getComponents === 'function') {
        var comps = n.getComponents(cc.Component);
        if (!Array.isArray(comps) || comps.length > LIMITS.components) abort('scan_limit');
        for (var q = 0; q < comps.length; q++) {
          var name = cc.js.getClassName(comps[q]);
          if (name === 'Game') games.push(comps[q]);
          if (modeActive(comps[q],name,root)) abort('external_mode_active');
          if (typeof name === 'string' && /Alert$/.test(name) && comps[q].enabled !== false && comps[q].enabledInHierarchy !== false) modal = true;
        }
      }
      var desc = children(n); if (stack.length + desc.length > LIMITS.nodes) abort('scan_limit');
      for (var j = desc.length-1; j >= 0; j--) stack.push({n:desc[j],p:n,d:en.d+1});
    }
    if (modal) abort('modal_visible');
    if (boards.length !== 1 || trays.length !== 1 || reserves.length !== 1) abort('board_ambiguous');
    var board = boards[0], tray = trays[0], reserve = reserves[0];
    if (!transform(board) || !transform(tray) || !transform(reserve) || !tray.parent || !size(tray.parent,600,130) ||
        typeof tray.parent.getComponent !== 'function') abort('board_geometry');
    var traySprite = tray.parent.getComponent(cc.Sprite);
    if (!traySprite || !traySprite.spriteFrame || typeof traySprite.spriteFrame.name !== 'string' || hash(traySprite.spriteFrame.name) !== '3a2ba3a6') abort('tray_unverified');
    var capacity = tray.width / 80;
    if (capacity !== 7 || tray.x !== 0 || tray.y !== 10) abort('tray_unverified');
    // All three containers must belong to the same gameplay layer.
    var gameLayer = board.parent && board.parent.parent;
    if (!gameLayer || !tray.parent.parent || tray.parent.parent.parent !== gameLayer || !reserve.parent || reserve.parent.parent !== gameLayer) abort('board_geometry');
    var cardList = [], trayList = [], refs = new Map(), rawIDs=new Set(), warehouseSignatures = [], actionRejection=null;
    var zoneNodes = [{n:board,z:'board'},{n:reserve,z:'reserve'},{n:tray,z:'tray'}];
    for (var z = 0; z < zoneNodes.length; z++) {
      var container = zoneNodes[z].n, zone = zoneNodes[z].z, cs = children(container);
      for (var t = 0; t < cs.length; t++) {
        budget(); var card = cs[t];
        if (!visible(card,root) || !size(card,80,90) || !transform(card)) abort('card_geometry');
        if (zone === 'board' && (Math.abs(card.x) > board.width/2+0.01 || Math.abs(card.y) > board.height/2+0.01)) animation('board_bounds');
        var parts = children(card), layout=cardLayout(card,cc), bg=layout.bg, leaves=children(bg);
        if (!visible(bg,root) || !transform(bg) || !size(bg,80,90) || leaves.length !== 1) abort('unknown_card');
        var background = frame(bg,cc), tag = hash(background.name);
        var face = layout.face; if (leaves[0] !== face || !visible(face,root) || !size(face,80,90) || !transform(face)) abort('unknown_card');
        var f = frame(face,cc); if (!frameIDs.has(f)) frameIDs.set(f,'f'+nextFrame++);
        var mask=layout.mask, masked=visible(mask,root), meta=metadata(card,cc,zone,layout), type=meta.type;
        if (rawIDs.has(meta.rawID)) cardRule('duplicate_id'); rawIDs.add(meta.rawID);
        if (meta.ruleIssue && !actionRejection) actionRejection={reason:'unsupported_card_rules',detail:meta.ruleIssue};
        var bgFrames=ownData(meta.block,'BgArr');
        if (tag !== 'a78ac5ca' && tag !== '6be7dcd3' && !(meta.specialType !== 0 && Array.isArray(bgFrames) &&
            bgFrames.length === 3 && bgFrames[2] === background)) abort('unknown_card');
        if (masked) {
          var ms = mask.getComponent && mask.getComponent(cc.Sprite), mf = ms && ms.spriteFrame;
          if (!size(mask,80,90) || mask.opacity !== 128 || !mf || typeof mf.name !== 'string' || hash(mf.name) !== 'f4a086c3') abort('mask_unverified');
        }
        // The original locked-card badge is static; bomb/hot-time branches are not.
        var staticSpecial=meta.specialType !== 0 ? ownData(meta.block,'SpecialNode') : null;
        if ([layout.special,layout.hot,layout.bomb].some(function(n){return visible(n,root) && n.parent === card && n !== staticSpecial;})) abort('card_effect_active');
        var row = {id:id(card),type:type,zone:zone,x:card.x,y:card.y,order:t,blockedBy:[],available:false,node:card,frame:f,masked:masked,layer:meta.layer,gridRow:meta.gridRow,gridCol:meta.gridCol,
          rawID:meta.rawID,selectable:meta.selectable,metadata:meta,occlusionDepth:0,maskNode:mask,faceNode:face};
        refs.set(row.id,row); if (refs.size > LIMITS.cards) abort('scan_limit');
        if (zone === 'tray') { if (masked || Math.abs(card.y) > 0.01) animation('tray_mask_or_y'); trayList.push(row); }
        else cardList.push(row);
      }
    }
    for (var u = 0; u < nodes.length; u++) if (size(nodes[u],80,90) && (children(nodes[u]).length === 5 || children(nodes[u]).length === 4) &&
        nodes[u].parent !== board && nodes[u].parent !== tray && nodes[u].parent !== reserve) {
      var parked=parkedWarehouseCard(nodes[u],cc,root,emitter,records,gameLayer);
      if (!parked) animation('external_card');
      warehouseSignatures.push(parked);
    }
    if (trayList.length >= capacity) abort('tray_full');
    trayList.sort(function(a,b){return a.x-b.x;});
    for (var ti=0;ti<trayList.length;ti++) if (Math.abs(trayList[ti].x-(-240+80*ti)) > 0.01) animation('tray_spacing');
    for (var v=0;v<cardList.length;v++) {
      budget(); var c = cardList[v];
      if (c.zone === 'board') for (var w=0;w<cardList.length;w++) {
        var d = cardList[w]; if (d.zone === 'board' && d.layer > c.layer && Math.abs(d.gridRow-c.gridRow) < 16 && Math.abs(d.gridCol-c.gridCol) < 20) c.blockedBy.push(d.id);
      }
      if (c.masked !== (c.blockedBy.length > 0)) abort('occlusion_mismatch');
      // Icons and occlusion are a read-only snapshot; a disabled or unavailable
      // action contract must not erase a separately verified X-ray snapshot.
      try {
        c.action = action(c,cc,emitter,records,false);
        if (c.action.receiver !== c.metadata.block || c.action.enabled !== c.metadata.canTouch) {
          if (!actionRejection) actionRejection={reason:'unsupported_card_rules',detail:'control_state'};
        }
        c.available = !c.masked && c.action.enabled && c.selectable;
      } catch (error) {
        if (['button_unavailable','handler_ambiguous','event_mismatch','disabled_control','handler_unavailable'].indexOf(rejection) < 0) throw error;
        if (!actionRejection) actionRejection={reason:rejection,detail:null};
        rejection=null;
      }
    }
    var byLayer=cardList.slice().sort(function(a,b){return b.layer-a.layer;});
    byLayer.forEach(function(c){
      var max=-1; c.blockedBy.forEach(function(key){var blocker=refs.get(key);max=Math.max(max,blocker.occlusionDepth);});
      c.occlusionDepth=max+1;
    });
    cardsRead = refs.size;
    var typesRead = new Set(); refs.forEach(function(c){if (c.type !== null) typesRead.add(c.type);}); cardTypesRead = typesRead.size;
    var sig = [id(root),id(board),id(tray),id(reserve)];
    refs.forEach(function(c){sig.push(c.id,c.zone,c.type,c.x,c.y,c.order,c.masked,c.available,c.rawID,c.layer,c.gridRow,c.gridCol,c.selectable,frameIDs.get(c.frame),c.frame.name);});
    sig.push(warehouseSignatures);
    var mission=readMission(cc,games,gameLayer,records);
    return {mission:mission,missionKey:mission?mission.key:'unavailable',cc:cc,root:root,gameLayer:gameLayer,board:board,trayNode:tray,reserve:reserve,emitter:emitter,records:records,refs:refs,cards:cardList,tray:trayList,capacity:capacity,signature:JSON.stringify(sig),actionRejection:actionRejection};
  }
  function unchangedCards(before, after, chosen) {
    var a=before.cards.filter(function(c){return c.id !== chosen;});
    if (a.length !== after.cards.length) return false;
    for (var i=0;i<a.length;i++) { var c=after.refs.get(a[i].id); if (!c || c.zone !== a[i].zone || c.type !== a[i].type) return false; }
    return !after.cards.some(function(c){return c.id === chosen;});
  }
  function confirmedChange(p,s) {
    if (p.root !== s.root || !unchangedCards(p.before,s,p.card.id)) return false;
    var expected = p.before.tray.map(function(c){return {id:c.id,type:c.type};});
    insertAndMatch(expected,p.card);
    if (expected.length !== s.tray.length) return false;
    return expected.every(function(c,i){return s.tray[i].id === c.id && s.tray[i].type === c.type;});
  }
  function terminalBoardReplacement(p,s) {
    // Stage transitions may keep both scene and board objects, and pool the
    // last three card nodes. An elapsed timeout never proves this transition.
    // Require a terminal triple, an observed intervening modal, an empty new
    // bar and a large influx of identities not present in that terminal state.
    if (!p.sawModal || p.before.cards.length !== 1 || p.before.tray.length !== 2 ||
        p.before.cards[0].id !== p.card.id || s.tray.length !== 0 || s.cards.length < 18 ||
        !p.before.tray.every(function(c){return c.type === p.card.type;})) return false;
    var added = 0;
    s.refs.forEach(function(c){if (!p.before.refs.has(c.id)) added++;});
    return added >= 15;
  }
  return function runtime(options) {
    options = options || {}; xrayWanted=options.xrayEnabled === true;
    xrayDepth=num(options.xrayDepth) && Math.floor(options.xrayDepth) === options.xrayDepth ? Math.max(1,Math.min(5,options.xrayDepth)) : 1;
    if (!xrayWanted) clearXray('off');
    missionState={status:'unavailable'};
    rejection = null; animationDetail = null; cardRuleDetail = null; started = clock(); cardsRead = 0; cardTypesRead = 0;
    var command = options.command || 'tick';
    if (command !== 'tick' && command !== 'pause' && command !== 'reset') { clearXray('blocked'); return result('blocked','invalid_command'); }
    if (options.resumeGeneration !== generation) {
      generation = options.resumeGeneration; stable = null; planned = null; route=null; planningState={state:'blocked',nodes:0,slices:0}; clearXray(xrayWanted ? 'blocked' : 'off');
      if (pending) { pending.confirmation=null; pending.replacement=null; }
    }
    if (command !== 'tick') {
      clearXray('off'); stable = null; planned = null; route=null;
      if (pending) { pending.confirmation=null; pending.replacement=null; }
      return result('paused',pending ? 'pending_preserved' : 'user_paused');
    }
    if (typeof plan !== 'function') { clearXray(xrayWanted ? 'unavailable' : 'off'); return result('blocked','planner_unavailable'); }
    try {
      var s = snapshot(), now = clock();
      if(observedMissionKey!==s.missionKey){
        // Invalidate prepared actions, not the uncertain original action.
        observedMissionKey=s.missionKey;planned=null;route=null;planningState={state:'blocked',nodes:0,slices:0};
      }
      if(s.mission)missionState={status:s.mission.current===s.mission.total?'complete':'identified',
        targetType:s.mission.targetType,current:s.mission.current,total:s.mission.total};
      if(route && ['priority','fallback'].indexOf(route.missionStatus)>=0 && s.mission && s.mission.current<s.mission.total)
        missionState.status=route.missionStatus;
      if (s.actionRejection) {
        stable=null; planned=null; route=null; planningState={state:'blocked',nodes:0,slices:0};
        if (pending) { pending.confirmation=null; pending.replacement=null; }
        showXray(s,null); cardRuleDetail=s.actionRejection.detail;
        return result('blocked',s.actionRejection.reason);
      }
      if (pending) {
        showXray(s,null);
        var terminalReplacement = terminalBoardReplacement(pending,s);
        if (pending.root !== s.root || pending.before.board !== s.board || terminalReplacement) {
          // A different complete board cannot replay the old card. Require two
          // stable observations before retiring uncertainty; do not count a move.
          if (!terminalReplacement && s.refs.has(pending.card.id)) return result('blocked','pending_context_changed');
          if (!pending.replacement || pending.replacement.signature !== s.signature) {
            pending.replacement={signature:s.signature,time:now}; return result('waiting_confirmation','new_board_stability');
          }
          if (now-pending.replacement.time < 80) return result('waiting_confirmation','new_board_stability');
          stable={signature:s.signature,time:pending.replacement.time};
          pending=null; planned=null; route=null; return result('watching','new_board_detected');
        }
        pending.replacement=null;
        if (confirmedChange(pending,s)) {
          if (!pending.confirmation || pending.confirmation.signature !== s.signature) {
            pending.confirmation={signature:s.signature,time:now}; return result('waiting_confirmation','confirm_stability');
          }
          if (now-pending.confirmation.time < 80) return result('waiting_confirmation','confirm_stability');
          stable={signature:s.signature,time:pending.confirmation.time};
          if (route && route.sequence[0] === pending.card.id) { route.sequence.shift(); route=validateRoute(s,route); } else route=null;
          pending=null; planned=null; confirmed=Math.min(10000,confirmed+1); showXray(s,route); return result('move_confirmed','board_change_confirmed');
        }
        pending.confirmation=null;
        return result('waiting_confirmation',now-pending.time > 8000 ? 'confirmation_uncertain' : 'awaiting_original_result');
      }
      if (options.allowAction !== true && !xrayWanted) { stable=null; planned=null; route=null; return result('watching','action_disabled'); }
      if (!stable || stable.signature !== s.signature) { planned=null; stable={signature:s.signature,time:now}; showXray(s,null); return result('waiting_stability','observing_board'); }
      if (now-stable.time < 80) return result('waiting_stability','observing_board');
      if (!planned) {
        var clean=s.cards.map(function(c){return {id:c.id,type:c.type,zone:c.zone,x:c.x,y:c.y,order:c.order,blockedBy:c.blockedBy.slice(),available:c.available,selectable:c.selectable};});
        route=route && validateRoute(s,route);
        if (!route) {
          var decision=plan({cards:clean,tray:s.tray.map(function(c){return {id:c.id,type:c.type};}),capacity:s.capacity,matchSize:3,budgetMs:8,mission:s.mission?{type:s.mission.type,current:s.mission.current,total:s.mission.total}:null,stateKey:s.signature+'|'+String(generation)});
          if (object(decision) && decision.status === 'searching' && decision.reason === 'search_in_progress') {
            plannerDiagnostic(decision,'searching'); showXray(s,null); return result('planning','search_in_progress');
          }
          if (!object(decision) || decision.status !== 'move' || typeof decision.cardID !== 'string') {
            plannerDiagnostic(decision,'blocked'); showXray(s,null);
            var reasons=['observed_state_unbalanced','observed_state_locked','no_complete_solution','search_limit_reached','board_clear','no_remaining_triples','invalid_state'];
            return result('blocked',object(decision) && reasons.indexOf(decision.reason) >= 0 ? decision.reason : 'no_safe_move');
          }
          if (!Array.isArray(decision.actions) || JSON.stringify(decision.actions) !== JSON.stringify(decision.sequence) ||
              !decision.sequence || decision.cardID !== decision.sequence[0]) abort('planner_invalid_move');
          route=validateRoute(s,decision,true); if (!route) abort('planner_invalid_move');
          route.missionKey=s.missionKey;
          route.missionStatus=object(decision.stats) && ['priority','fallback'].indexOf(decision.stats.missionStatus)>=0?decision.stats.missionStatus:null;
          plannerDiagnostic(decision,'proved');
        }
        var candidate=s.refs.get(route.sequence[0]);
        if (!candidate || !candidate.available || candidate.zone === 'tray') abort('planner_invalid_move');
        planned={signature:s.signature,cardID:candidate.id,event:candidate.action.event,button:candidate.action.button,receiver:candidate.action.receiver};
        showXray(s,route);
        // Planning and execution occur on different ticks. The next tick reads
        // a fresh complete board once; no stale plan can dispatch.
        return result('waiting_stability','plan_ready');
      }
      if (planned.signature !== s.signature) abort('context_changed');
      route=validateRoute(s,route); if (!route || route.sequence[0] !== planned.cardID) abort('planner_invalid_move');
      showXray(s,route);
      if (options.allowAction !== true) return result('watching','action_disabled');
      var current=s.refs.get(planned.cardID);
      if (!current || !current.available || current.zone === 'tray') abort('planner_invalid_move');
      var registered=action(current,s.cc,s.emitter,s.records,true); budget();
      if (registered.event !== planned.event || registered.button !== planned.button || registered.receiver !== planned.receiver ||
          window.cc !== s.cc || s.cc.director.getScene() !== s.root || version(s.cc) !== '2.4.4' ||
          s.cc.Component.EventHandler.prototype.emit !== s.emitter || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive') ||
          current.node.parent !== (current.zone === 'board' ? s.board : s.reserve) ||
          !visible(current.node,s.root) || !transform(current.node) || visible(current.maskNode,s.root) ||
          current.faceNode.parent !== ownData(registered.receiver,'BgSprite').node || frame(current.faceNode,s.cc) !== current.frame) abort('context_changed');
      var generatedEvent=inputEvent(s.cc,registered.button); budget();
      var fresh=s;
      planned=null;
      pending={root:s.root,card:current,before:fresh,time:clock(),confirmation:null}; stable=null;
      try { s.emitter.call(registered.event,[generatedEvent]); }
      catch (_) { return result('dispatch_uncertain','event_exception',true); }
      return result('original_event_dispatched','awaiting_original_result',true);
    } catch (_) {
      if (pending) {
        if (rejection === 'modal_visible') pending.sawModal=true;
        // An incomplete snapshot breaks consecutiveness of the proof, even
        // when a later state happens to have the same signature.
        pending.confirmation=null; pending.replacement=null;
      }
      clearXray(xrayWanted ? 'blocked' : 'off'); stable=null; planned=null; route=null; return result('blocked',rejection || 'read_error');
    }
  };
})

/* SDKtools V2.6. Live, bounded Cocos 2.4.4 adapter. Calls only the original
 * registered touchBlock event. No captured source, inventory or network writes.
 * Expression: (autoplay_tool.js)(autoplay_planner.js) -> runtime(options).
 */
(function (plan) {
  'use strict';
  var ids = new WeakMap(), frameIDs = new WeakMap(), nextID = 1, nextFrame = 1;
  var stable = null, planned = null, pending = null, generation = null, confirmed = 0, cardsRead = 0;
  var LIMITS = { nodes: 4096, children: 512, cards: 512, depth: 24, components: 32, budgetMs: 18 };
  var rejection = null, started = 0;
  function object(x) { return x !== null && (typeof x === 'object' || typeof x === 'function'); }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  function clock() { return typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now(); }
  function abort(reason) { rejection = reason; throw Error('SDKtools guard'); }
  function budget() { if (clock() - started >= LIMITS.budgetMs) abort('time_budget'); }
  function id(x) { if (!ids.has(x)) ids.set(x, 'c' + nextID++); return ids.get(x); }
  function size(n, w, h) { return n.width === w && n.height === h; }
  function visible(n, root) { return object(n) && n.isValid === true && n.activeInHierarchy === true &&
    (n === root || n.active === true) && num(n.opacity) && n.opacity > 0 && n.opacity <= 255; }
  function children(n) { var a = n.children; if (!Array.isArray(a)) abort('invalid_scene');
    if (a.length > LIMITS.children) abort('scan_limit'); return a; }
  function version(cc) { var a = cc.ENGINE_VERSION, b = window.CocosEngine;
    return typeof a === 'string' && typeof b === 'string' && a !== b ? null : typeof a === 'string' ? a : b; }
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length && i < 128; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
  function result(status, reason, dispatched) { return { version: 1, status: status, reason: reason,
    cardsRead: cardsRead, confirmedMoves: confirmed, dispatched: dispatched === true,
    awaitingBoardChange: pending !== null }; }
  function transform(n) { return num(n.x) && num(n.y) && n.angle === 0 && n.scaleX === 1 && n.scaleY === 1 &&
    n.anchorX === 0.5 && n.anchorY === 0.5 && (!num(n.z) || n.z === 0); }
  function frame(n, cc) { if (typeof n.getComponent !== 'function') abort('sprite_unavailable');
    var s = n.getComponent(cc.Sprite), f = s && s.spriteFrame;
    if (!object(s) || s.enabled !== true || s.enabledInHierarchy !== true || !object(f) ||
        typeof f.name !== 'string' || !f.name || f.name.length > 256 || typeof f.getRect !== 'function') abort('unknown_card');
    var r = f.getRect(); if (!object(r) || r.width !== 120 || r.height !== 135) abort('unknown_card');
    return f; }
  function action(card, cc, emitter, records, requireEnabled) {
    var nodes = [card.node], a = children(card.node), matches = [];
    for (var i = 0; i < a.length; i++) if (visible(a[i], null)) nodes.push(a[i]);
    for (var j = 0; j < nodes.length; j++) {
      var n = nodes[j]; if (typeof n.getComponent !== 'function') abort('button_unavailable');
      var b = n.getComponent(cc.Button); if (!b) continue;
      var events = b.clickEvents;
      if (!Array.isArray(events) || events.length !== 1 || !events[0] || events[0].handler !== 'touchBlock') continue;
      matches.push({button:b,event:events[0],node:n});
    }
    if (matches.length !== 1) abort('handler_ambiguous');
    var m = matches[0], b = m.button, e = m.event, target = e.target;
    if (b.isValid !== true || b.node !== m.node || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype, e) ||
        e.emit !== emitter || e.customEventData !== '' || !object(target) || !records.has(target) ||
        (target !== card.node && target.parent !== card.node) || typeof target.getComponents !== 'function') abort('event_mismatch');
    if (requireEnabled && (b.enabled !== true || b.enabledInHierarchy !== true || b.interactable !== true)) abort('disabled_control');
    var components = target.getComponents(cc.Component), found = [];
    if (!Array.isArray(components) || components.length > LIMITS.components) abort('handler_unavailable');
    for (var k = 0; k < components.length; k++) {
      var c = components[k]; if (c && typeof c.touchBlock === 'function') found.push(c);
    }
    if (found.length !== 1 || found[0].isValid !== true || found[0].node !== target || found[0].touchBlock.length > 2) abort('handler_ambiguous');
    // If the public registration exposes a name, ensure it resolves to the same receiver.
    if (typeof e.component === 'string' && e.component &&
        (typeof target.getComponent !== 'function' || target.getComponent(e.component) !== found[0])) abort('event_mismatch');
    return {button:b,event:e,receiver:found[0],enabled:b.enabled === true && b.enabledInHierarchy === true && b.interactable === true};
  }
  function snapshot() {
    budget();
    if (typeof window !== 'object' || !window || (window.top && window.top !== window)) abort('context_unavailable');
    if (typeof document !== 'object' || !document || document.visibilityState !== 'visible' ||
        (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('document_unavailable');
    var cc = window.cc;
    if (!object(cc) || version(cc) !== '2.4.4') abort('engine_version');
    if (!cc.director || typeof cc.director.getScene !== 'function' || !cc.Sprite || !cc.Button || !cc.Component ||
        !cc.Component.EventHandler || !cc.Component.EventHandler.prototype || !cc.js || typeof cc.js.getClassName !== 'function') abort('context_unavailable');
    var emitter = cc.Component.EventHandler.prototype.emit, root = cc.director.getScene();
    if (typeof emitter !== 'function' || !visible(root,root)) abort('context_unavailable');
    var stack = [{n:root,p:null,d:0}], seen = new Set(), records = new Map(), boards = [], trays = [], reserves = [], nodes = [], modal = false;
    while (stack.length) {
      budget(); var en = stack.pop(), n = en.n;
      if (!object(n) || seen.has(n) || (en.p && n.parent !== en.p)) abort('invalid_scene');
      seen.add(n); if (seen.size > LIMITS.nodes || en.d > LIMITS.depth) abort('scan_limit');
      if (!visible(n,root)) continue;
      records.set(n,en.p); nodes.push(n);
      if (size(n,560,720)) boards.push(n);
      if (size(n,560,80)) trays.push(n);
      if (size(n,240,90)) reserves.push(n);
      if (size(n,240,102)) modal = true;
      if (!size(n,80,90) && typeof n.getComponents === 'function') {
        var comps = n.getComponents(cc.Component);
        if (!Array.isArray(comps) || comps.length > LIMITS.components) abort('scan_limit');
        for (var q = 0; q < comps.length; q++) {
          var name = cc.js.getClassName(comps[q]);
          if (typeof name === 'string' && /Alert$/.test(name) && comps[q].enabled !== false && comps[q].enabledInHierarchy !== false) modal = true;
        }
      }
      var desc = children(n); if (stack.length + desc.length > LIMITS.nodes) abort('scan_limit');
      for (var j = desc.length-1; j >= 0; j--) stack.push({n:desc[j],p:n,d:en.d+1});
    }
    if (modal) abort('modal_visible');
    if (boards.length !== 1 || trays.length !== 1 || reserves.length !== 1) abort('board_ambiguous');
    var board = boards[0], tray = trays[0], reserve = reserves[0];
    if (!transform(board) || !transform(tray) || !transform(reserve) || !tray.parent || !size(tray.parent,600,130) ||
        typeof tray.parent.getComponent !== 'function') abort('board_geometry');
    var traySprite = tray.parent.getComponent(cc.Sprite);
    if (!traySprite || !traySprite.spriteFrame || typeof traySprite.spriteFrame.name !== 'string' || hash(traySprite.spriteFrame.name) !== '3a2ba3a6') abort('tray_unverified');
    var capacity = tray.width / 80;
    if (capacity !== 7 || tray.x !== 0 || tray.y !== 10) abort('tray_unverified');
    // All three containers must belong to the same gameplay layer.
    var gameLayer = board.parent && board.parent.parent;
    if (!gameLayer || !tray.parent.parent || tray.parent.parent.parent !== gameLayer || !reserve.parent || reserve.parent.parent !== gameLayer) abort('board_geometry');
    var cardList = [], trayList = [], refs = new Map(), inTransit = false;
    var zoneNodes = [{n:board,z:'board'},{n:reserve,z:'reserve'},{n:tray,z:'tray'}];
    for (var z = 0; z < zoneNodes.length; z++) {
      var container = zoneNodes[z].n, zone = zoneNodes[z].z, cs = children(container);
      for (var t = 0; t < cs.length; t++) {
        budget(); var card = cs[t];
        if (!visible(card,root) || !size(card,80,90) || children(card).length !== 5 || !transform(card)) abort('card_geometry');
        if (zone === 'board' && (Math.abs(card.x) > board.width/2+0.01 || Math.abs(card.y) > board.height/2+0.01)) abort('animation_active');
        var parts = children(card), bg = parts[0], leaves = children(bg);
        if (!visible(bg,root) || !transform(bg) || !size(bg,80,90) || leaves.length !== 1) abort('unknown_card');
        var background = frame(bg,cc), tag = hash(background.name);
        if (tag !== 'a78ac5ca' && tag !== '6be7dcd3') abort('unknown_card');
        var face = leaves[0]; if (!visible(face,root) || !size(face,80,90) || !transform(face)) abort('unknown_card');
        var f = frame(face,cc); if (!frameIDs.has(f)) frameIDs.set(f,'f'+nextFrame++);
        var type = frameIDs.get(f)+':'+f.name, mask = parts[2], masked = visible(mask,root);
        if (masked) {
          var ms = mask.getComponent && mask.getComponent(cc.Sprite), mf = ms && ms.spriteFrame;
          if (!size(mask,80,90) || mask.opacity !== 128 || !mf || typeof mf.name !== 'string' || hash(mf.name) !== 'f4a086c3') abort('mask_unverified');
        }
        // Other two optional child branches must be inactive in the observed card layout.
        if (visible(parts[1],root) || visible(parts[3],root) || visible(parts[4],root)) abort('card_effect_active');
        var row = {id:id(card),type:type,zone:zone,x:card.x,y:card.y,order:t,blockedBy:[],available:false,node:card,frame:f,masked:masked};
        refs.set(row.id,row); if (refs.size > LIMITS.cards) abort('scan_limit');
        if (zone === 'tray') { if (masked || Math.abs(card.y) > 0.01) abort('animation_active'); trayList.push(row); }
        else cardList.push(row);
      }
    }
    for (var u = 0; u < nodes.length; u++) if (size(nodes[u],80,90) && children(nodes[u]).length === 5 &&
        nodes[u].parent !== board && nodes[u].parent !== tray && nodes[u].parent !== reserve) inTransit = true;
    if (inTransit) abort('animation_active');
    if (trayList.length >= capacity) abort('tray_full');
    trayList.sort(function(a,b){return a.x-b.x;});
    for (var ti=0;ti<trayList.length;ti++) if (Math.abs(trayList[ti].x-(-240+80*ti)) > 0.01) abort('animation_active');
    for (var v=0;v<cardList.length;v++) {
      budget(); var c = cardList[v];
      if (c.zone === 'board') for (var w=0;w<cardList.length;w++) {
        var d = cardList[w]; if (d.zone === 'board' && d.order > c.order && Math.abs(d.x-c.x) < 79.99 && Math.abs(d.y-c.y) < 89.99) c.blockedBy.push(d.id);
      }
      if (c.masked !== (c.blockedBy.length > 0)) abort('occlusion_mismatch');
      c.action = action(c,cc,emitter,records,false);
      c.available = !c.masked && c.action.enabled;
    }
    cardsRead = refs.size;
    var sig = [id(root),id(board),id(tray),id(reserve)];
    refs.forEach(function(c){sig.push(c.id,c.zone,c.type,c.x,c.y,c.order,c.masked,c.available);});
    return {cc:cc,root:root,board:board,trayNode:tray,reserve:reserve,emitter:emitter,records:records,refs:refs,cards:cardList,tray:trayList,capacity:capacity,signature:JSON.stringify(sig)};
  }
  function unchangedCards(before, after, chosen) {
    var a=before.cards.filter(function(c){return c.id !== chosen;});
    if (a.length !== after.cards.length) return false;
    for (var i=0;i<a.length;i++) { var c=after.refs.get(a[i].id); if (!c || c.zone !== a[i].zone || c.type !== a[i].type) return false; }
    return !after.cards.some(function(c){return c.id === chosen;});
  }
  function confirmedChange(p,s) {
    if (p.root !== s.root || !unchangedCards(p.before,s,p.card.id)) return false;
    var same = p.before.tray.filter(function(c){return c.type === p.card.type;});
    var expected = p.before.tray.slice();
    if (same.length === 2) expected = expected.filter(function(c){return c.type !== p.card.type;});
    else expected.push(p.card);
    if (expected.length !== s.tray.length) return false;
    var actual = new Map(); s.tray.forEach(function(c){actual.set(c.id,c.type);});
    return expected.every(function(c){return actual.get(c.id) === c.type;});
  }
  return function runtime(options) {
    options = options || {}; rejection = null; started = clock(); cardsRead = 0;
    var command = options.command || 'tick';
    if (command !== 'tick' && command !== 'pause' && command !== 'reset') return result('blocked','invalid_command');
    if (options.resumeGeneration !== generation) { generation = options.resumeGeneration; stable = null; planned = null; }
    if (command !== 'tick') { stable = null; planned = null; return result('paused',pending ? 'pending_preserved' : 'user_paused'); }
    if (typeof plan !== 'function') return result('blocked','planner_unavailable');
    try {
      var s = snapshot(), now = clock();
      if (pending) {
        if (pending.root !== s.root || pending.before.board !== s.board) {
          // A different complete board cannot replay the old card. Require two
          // stable observations before retiring uncertainty; do not count a move.
          if (s.refs.has(pending.card.id)) return result('blocked','pending_context_changed');
          if (!pending.replacement || pending.replacement.signature !== s.signature) {
            pending.replacement={signature:s.signature,time:now}; return result('waiting_confirmation','new_board_stability');
          }
          if (now-pending.replacement.time < 200) return result('waiting_confirmation','new_board_stability');
          pending=null; stable=null; planned=null; return result('watching','new_board_detected');
        }
        pending.replacement=null;
        if (confirmedChange(pending,s)) {
          if (!pending.confirmation || pending.confirmation.signature !== s.signature) {
            pending.confirmation={signature:s.signature,time:now}; return result('waiting_confirmation','confirm_stability');
          }
          if (now-pending.confirmation.time < 120) return result('waiting_confirmation','confirm_stability');
          pending=null; stable=null; confirmed=Math.min(10000,confirmed+1); return result('move_confirmed','board_change_confirmed');
        }
        pending.confirmation=null;
        return result('waiting_confirmation',now-pending.time > 8000 ? 'confirmation_uncertain' : 'awaiting_original_result');
      }
      if (options.allowAction !== true) { stable=null; planned=null; return result('watching','action_disabled'); }
      if (!stable || stable.signature !== s.signature) { planned=null; stable={signature:s.signature,time:now}; return result('waiting_stability','observing_board'); }
      if (now-stable.time < 200) return result('waiting_stability','observing_board');
      if (!planned) {
        var clean=s.cards.map(function(c){return {id:c.id,type:c.type,zone:c.zone,x:c.x,y:c.y,order:c.order,blockedBy:c.blockedBy.slice(),available:c.available};});
        var decision=plan({cards:clean,tray:s.tray.map(function(c){return {id:c.id,type:c.type};}),capacity:s.capacity,matchSize:3,budgetMs:8});
        if (!object(decision) || decision.status !== 'move' || typeof decision.cardID !== 'string') return result('blocked','no_safe_move');
        var candidate=s.refs.get(decision.cardID);
        if (!candidate || !candidate.available || candidate.zone === 'tray') abort('planner_invalid_move');
        planned={signature:s.signature,cardID:candidate.id,event:candidate.action.event,button:candidate.action.button,receiver:candidate.action.receiver};
        // Planning and execution occur on different ticks. The next tick reads
        // a fresh complete board once; no stale plan can dispatch.
        return result('waiting_stability','plan_ready');
      }
      if (planned.signature !== s.signature) abort('context_changed');
      var current=s.refs.get(planned.cardID);
      if (!current || !current.available || current.zone === 'tray') abort('planner_invalid_move');
      var registered=action(current,s.cc,s.emitter,s.records,true); budget();
      if (registered.event !== planned.event || registered.button !== planned.button || registered.receiver !== planned.receiver ||
          window.cc !== s.cc || s.cc.director.getScene() !== s.root || version(s.cc) !== '2.4.4' ||
          s.cc.Component.EventHandler.prototype.emit !== s.emitter || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive') ||
          current.node.parent !== (current.zone === 'board' ? s.board : s.reserve) ||
          !visible(current.node,s.root) || !transform(current.node) || visible(children(current.node)[2],s.root) ||
          frame(children(children(current.node)[0])[0],s.cc) !== current.frame) abort('context_changed');
      var fresh=s;
      planned=null;
      pending={root:s.root,card:current,before:fresh,time:clock(),confirmation:null}; stable=null;
      try { s.emitter.call(registered.event,[registered.button]); }
      catch (_) { return result('dispatch_uncertain','event_exception',true); }
      return result('original_event_dispatched','awaiting_original_result',true);
    } catch (_) { stable=null; planned=null; return result('blocked',rejection || 'read_error'); }
  };
})

/* SDKtools V2.9. Live, bounded Cocos 2.4.4 adapter. Calls only the original
 * registered touchBlock event. No captured source, inventory or network writes.
 * Expression: (autoplay_tool.js)(autoplay_planner.js) -> runtime(options).
 */
(function (plan) {
  'use strict';
  var ids = new WeakMap(), frameIDs = new WeakMap(), nextID = 1, nextFrame = 1;
  var stable = null, planned = null, pending = null, generation = null, confirmed = 0, cardsRead = 0, cardTypesRead = 0;
  var LIMITS = { nodes: 4096, children: 512, cards: 512, depth: 24, components: 32, budgetMs: 18 };
  var rejection = null, animationDetail = null, started = 0;
  function object(x) { return x !== null && (typeof x === 'object' || typeof x === 'function'); }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  function clock() { return typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now(); }
  function abort(reason) { rejection = reason; throw Error('SDKtools guard'); }
  function animation(reason) { animationDetail = reason; abort('animation_active'); }
  function budget() { if (clock() - started >= LIMITS.budgetMs) abort('time_budget'); }
  function id(x) { if (!ids.has(x)) ids.set(x, 'c' + nextID++); return ids.get(x); }
  function size(n, w, h) { return n.width === w && n.height === h; }
  function visible(n, root) { return object(n) && n.isValid === true && n.activeInHierarchy === true &&
    (n === root || n.active === true) && num(n.opacity) && n.opacity > 0 && n.opacity <= 255; }
  function children(n) { var a = n.children; if (!Array.isArray(a)) abort('invalid_scene');
    if (a.length > LIMITS.children) abort('scan_limit'); return a; }
  function version(cc) { var a = cc.ENGINE_VERSION, b = window.CocosEngine;
    return typeof a === 'string' && typeof b === 'string' && a !== b ? null : typeof a === 'string' ? a : b; }
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length && i < 128; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
  function result(status, reason, dispatched) { var output = { version: 1, status: status, reason: reason,
    cardsRead: cardsRead, cardTypesRead: cardTypesRead, confirmedMoves: confirmed, dispatched: dispatched === true,
    awaitingBoardChange: pending !== null };
    if (animationDetail) output.animationDetail = animationDetail;
    return output; }
  function transform(n) { return num(n.x) && num(n.y) && n.angle === 0 && n.scaleX === 1 && n.scaleY === 1 &&
    n.anchorX === 0.5 && n.anchorY === 0.5 && (!num(n.z) || n.z === 0); }
  function frame(n, cc) { if (typeof n.getComponent !== 'function') abort('sprite_unavailable');
    var s = n.getComponent(cc.Sprite), f = s && s.spriteFrame;
    if (!object(s) || s.enabled !== true || s.enabledInHierarchy !== true || !object(f) ||
        typeof f.name !== 'string' || !f.name || f.name.length > 256 || typeof f.getRect !== 'function') abort('unknown_card');
    var r = f.getRect(); if (!object(r) || r.width !== 120 || r.height !== 135) abort('unknown_card');
    return f; }
  function action(card, cc, emitter, records, requireEnabled) {
    var nodes = [card.node], a = children(card.node), matches = [];
    for (var i = 0; i < a.length; i++) if (visible(a[i], null)) nodes.push(a[i]);
    for (var j = 0; j < nodes.length; j++) {
      var n = nodes[j]; if (typeof n.getComponent !== 'function') abort('button_unavailable');
      var b = n.getComponent(cc.Button); if (!b) continue;
      var events = b.clickEvents;
      if (!Array.isArray(events) || events.length !== 1 || !events[0] || events[0].handler !== 'touchBlock') continue;
      matches.push({button:b,event:events[0],node:n});
    }
    if (matches.length !== 1) abort('handler_ambiguous');
    var m = matches[0], b = m.button, e = m.event, target = e.target;
    if (b.isValid !== true || b.node !== m.node || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype, e) ||
        e.emit !== emitter || e.customEventData !== '' || !object(target) || !records.has(target) ||
        (target !== card.node && target.parent !== card.node) || typeof target.getComponents !== 'function') abort('event_mismatch');
    if (requireEnabled && (b.enabled !== true || b.enabledInHierarchy !== true || b.interactable !== true)) abort('disabled_control');
    var components = target.getComponents(cc.Component), found = [];
    if (!Array.isArray(components) || components.length > LIMITS.components) abort('handler_unavailable');
    for (var k = 0; k < components.length; k++) {
      var c = components[k]; if (c && typeof c.touchBlock === 'function') found.push(c);
    }
    if (found.length !== 1 || found[0].isValid !== true || found[0].node !== target || found[0].touchBlock.length > 2) abort('handler_ambiguous');
    // If the public registration exposes a name, ensure it resolves to the same receiver.
    if (typeof e.component === 'string' && e.component &&
        (typeof target.getComponent !== 'function' || target.getComponent(e.component) !== found[0])) abort('event_mismatch');
    return {button:b,event:e,receiver:found[0],enabled:b.enabled === true && b.enabledInHierarchy === true && b.interactable === true};
  }
  function inputEvent(cc, button) {
    // CCButton._onTouchEnded forwards EventTouch to clickEvents. Its separate
    // node.emit('click', button) API is not the registered component callback.
    // Cocos 2.4 CCEvent.js initializes _eventCode through _setEventCode; only
    // this newly allocated event is changed, never a real input or game node.
    var n=button.node, EventTouch=cc.Event && cc.Event.EventTouch;
    if (typeof cc.Touch !== 'function' || typeof EventTouch !== 'function' ||
        EventTouch.ENDED !== 2 || cc.Event.AT_TARGET !== 2 || !cc.Node || !cc.Node.EventType ||
        cc.Node.EventType.TOUCH_END !== 'touchend' || typeof cc.v2 !== 'function' ||
        typeof n.convertToWorldSpaceAR !== 'function') abort('input_event_unavailable');
    var point=n.convertToWorldSpaceAR(cc.v2(0,0));
    if (!object(point) || !num(point.x) || !num(point.y)) abort('input_event_unavailable');
    var touch=new cc.Touch();
    if (!object(touch) || typeof touch.setTouchInfo !== 'function') abort('input_event_unavailable');
    touch.setTouchInfo(0,point.x,point.y);
    var event=new EventTouch([touch],true), proto=EventTouch.prototype;
    if (!object(event) || !object(proto) || !Object.prototype.isPrototypeOf.call(proto,event) ||
        typeof proto._setEventCode !== 'function' || typeof event.getEventCode !== 'function' ||
        typeof event.getTouches !== 'function' || typeof event.getLocation !== 'function') abort('input_event_unavailable');
    event.touch=touch; event.currentTouch=touch;
    event.target=n; event.currentTarget=n; event.type=cc.Node.EventType.TOUCH_END; event.eventPhase=cc.Event.AT_TARGET;
    proto._setEventCode.call(event,EventTouch.ENDED);
    var location=event.getLocation(), touches=event.getTouches();
    if (event.target !== n || event.currentTarget !== n || event.touch !== touch ||
        event.getEventCode() !== EventTouch.ENDED || event.type !== 'touchend' ||
        !Array.isArray(touches) || touches.length !== 1 || touches[0] !== touch ||
        !object(location) || location.x !== point.x || location.y !== point.y) abort('input_event_unavailable');
    return event;
  }
  function parkedWarehouseCard(card,cc,root,emitter,records,gameLayer) {
    var slot=card.parent, row=slot && slot.parent, panel=row && row.parent;
    if (!slot || !row || !panel || !size(slot,84,94) || !size(row,260,94) || !size(panel,272,126) ||
        !panel.parent || panel.parent.parent !== gameLayer || !records.has(panel) ||
        !transform(slot) || !transform(row) || !transform(panel) || row.x !== 0 || row.y !== 8 ||
        typeof panel.getComponent !== 'function') return null;
    var ps=panel.getComponent(cc.Sprite), pf=ps && ps.spriteFrame;
    if (!ps || ps.enabled !== true || ps.enabledInHierarchy !== true || !pf || typeof pf.name !== 'string' ||
        hash(pf.name) !== 'd0a9f790' || typeof pf.getRect !== 'function') return null;
    var pr=pf.getRect(); if (!pr || pr.width !== 272 || pr.height !== 126) return null;
    var slots=children(row), signature=[], found=false;
    if (slots.length !== 3) return null;
    for (var i=0;i<slots.length;i++) {
      budget(); var n=slots[i];
      if (!visible(n,root) || !records.has(n) || n.parent !== row || !size(n,84,94) || !transform(n) ||
          n.x !== -88+88*i || n.y !== 0 || typeof n.getComponents !== 'function' || typeof n.getComponent !== 'function') return null;
      var components=n.getComponents(cc.Component), matches=[];
      if (!Array.isArray(components) || components.length > LIMITS.components) return null;
      for (var j=0;j<components.length;j++) if (components[j] && typeof components[j].onBtnClick === 'function') matches.push(components[j]);
      if (matches.length !== 1 || cc.js.getClassName(matches[0]) !== 'CommonStoreItem') return null;
      var c=matches[0], b=n.getComponent(cc.Button), events=b && b.clickEvents, e=Array.isArray(events) && events.length === 1 && events[0];
      if (!c || c.isValid !== true || c.node !== n || typeof c.isSelf !== 'boolean' || typeof c.isEmpty !== 'boolean' ||
          typeof c.onBtnClick !== 'function' || c.onBtnClick.length !== 0 || !b || b.isValid !== true || b.node !== n ||
          !e || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype,e) || e.emit !== emitter ||
          e.handler !== 'onBtnClick' || e.target !== n || e.customEventData !== '' ||
          (typeof e.component === 'string' && e.component && n.getComponent(e.component) !== c)) return null;
      var possible=children(n).filter(function(child){return visible(child,root) && size(child,80,90) && children(child).length === 5;});
      if (possible.length > 1 || c.isEmpty !== (possible.length === 0)) animation('warehouse_card_unsettled');
      signature.push(id(n),c.isSelf,c.isEmpty);
      if (n === slot) {
        if (possible.length !== 1 || possible[0] !== card) animation('warehouse_card_unsettled');
        found=true;
      }
    }
    if (!found || !transform(card) || card.x !== 0 || card.y !== 0) animation('warehouse_card_unsettled');
    var parts=children(card), bg=parts[0], faces=children(bg);
    if (!visible(bg,root) || !transform(bg) || !size(bg,80,90) || faces.length !== 1 ||
        parts.slice(1).some(function(n){return visible(n,root);})) animation('warehouse_card_unsettled');
    var background=frame(bg,cc), tag=hash(background.name), face=faces[0];
    if ((tag !== 'a78ac5ca' && tag !== '6be7dcd3') || !visible(face,root) || !size(face,80,90) || !transform(face)) animation('warehouse_card_unsettled');
    var f=frame(face,cc); if (!frameIDs.has(f)) frameIDs.set(f,'f'+nextFrame++);
    // Membership only. Warehouse ownership never authorizes a click here.
    signature.push(id(card),frameIDs.get(f),f.name,card.x,card.y);
    return signature;
  }
  function snapshot() {
    budget();
    if (typeof window !== 'object' || !window || (window.top && window.top !== window)) abort('context_unavailable');
    if (typeof document !== 'object' || !document || document.visibilityState !== 'visible' ||
        (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('document_unavailable');
    var cc = window.cc;
    if (!object(cc) || version(cc) !== '2.4.4') abort('engine_version');
    if (!cc.director || typeof cc.director.getScene !== 'function' || !cc.Sprite || !cc.Button || !cc.Component ||
        !cc.Component.EventHandler || !cc.Component.EventHandler.prototype || !cc.js || typeof cc.js.getClassName !== 'function') abort('context_unavailable');
    var emitter = cc.Component.EventHandler.prototype.emit, root = cc.director.getScene();
    if (typeof emitter !== 'function' || !visible(root,root)) abort('context_unavailable');
    var stack = [{n:root,p:null,d:0}], seen = new Set(), records = new Map(), boards = [], trays = [], reserves = [], nodes = [], modal = false;
    while (stack.length) {
      budget(); var en = stack.pop(), n = en.n;
      if (!object(n) || seen.has(n) || (en.p && n.parent !== en.p)) abort('invalid_scene');
      seen.add(n); if (seen.size > LIMITS.nodes || en.d > LIMITS.depth) abort('scan_limit');
      if (!visible(n,root)) continue;
      records.set(n,en.p); nodes.push(n);
      if (size(n,560,720)) boards.push(n);
      if (size(n,560,80)) trays.push(n);
      if (size(n,240,90)) reserves.push(n);
      if (size(n,240,102)) modal = true;
      if (!size(n,80,90) && typeof n.getComponents === 'function') {
        var comps = n.getComponents(cc.Component);
        if (!Array.isArray(comps) || comps.length > LIMITS.components) abort('scan_limit');
        for (var q = 0; q < comps.length; q++) {
          var name = cc.js.getClassName(comps[q]);
          if (typeof name === 'string' && /Alert$/.test(name) && comps[q].enabled !== false && comps[q].enabledInHierarchy !== false) modal = true;
        }
      }
      var desc = children(n); if (stack.length + desc.length > LIMITS.nodes) abort('scan_limit');
      for (var j = desc.length-1; j >= 0; j--) stack.push({n:desc[j],p:n,d:en.d+1});
    }
    if (modal) abort('modal_visible');
    if (boards.length !== 1 || trays.length !== 1 || reserves.length !== 1) abort('board_ambiguous');
    var board = boards[0], tray = trays[0], reserve = reserves[0];
    if (!transform(board) || !transform(tray) || !transform(reserve) || !tray.parent || !size(tray.parent,600,130) ||
        typeof tray.parent.getComponent !== 'function') abort('board_geometry');
    var traySprite = tray.parent.getComponent(cc.Sprite);
    if (!traySprite || !traySprite.spriteFrame || typeof traySprite.spriteFrame.name !== 'string' || hash(traySprite.spriteFrame.name) !== '3a2ba3a6') abort('tray_unverified');
    var capacity = tray.width / 80;
    if (capacity !== 7 || tray.x !== 0 || tray.y !== 10) abort('tray_unverified');
    // All three containers must belong to the same gameplay layer.
    var gameLayer = board.parent && board.parent.parent;
    if (!gameLayer || !tray.parent.parent || tray.parent.parent.parent !== gameLayer || !reserve.parent || reserve.parent.parent !== gameLayer) abort('board_geometry');
    var cardList = [], trayList = [], refs = new Map(), warehouseSignatures = [];
    var zoneNodes = [{n:board,z:'board'},{n:reserve,z:'reserve'},{n:tray,z:'tray'}];
    for (var z = 0; z < zoneNodes.length; z++) {
      var container = zoneNodes[z].n, zone = zoneNodes[z].z, cs = children(container);
      for (var t = 0; t < cs.length; t++) {
        budget(); var card = cs[t];
        if (!visible(card,root) || !size(card,80,90) || children(card).length !== 5 || !transform(card)) abort('card_geometry');
        if (zone === 'board' && (Math.abs(card.x) > board.width/2+0.01 || Math.abs(card.y) > board.height/2+0.01)) animation('board_bounds');
        var parts = children(card), bg = parts[0], leaves = children(bg);
        if (!visible(bg,root) || !transform(bg) || !size(bg,80,90) || leaves.length !== 1) abort('unknown_card');
        var background = frame(bg,cc), tag = hash(background.name);
        if (tag !== 'a78ac5ca' && tag !== '6be7dcd3') abort('unknown_card');
        var face = leaves[0]; if (!visible(face,root) || !size(face,80,90) || !transform(face)) abort('unknown_card');
        var f = frame(face,cc); if (!frameIDs.has(f)) frameIDs.set(f,'f'+nextFrame++);
        var type = frameIDs.get(f)+':'+f.name, mask = parts[2], masked = visible(mask,root);
        if (masked) {
          var ms = mask.getComponent && mask.getComponent(cc.Sprite), mf = ms && ms.spriteFrame;
          if (!size(mask,80,90) || mask.opacity !== 128 || !mf || typeof mf.name !== 'string' || hash(mf.name) !== 'f4a086c3') abort('mask_unverified');
        }
        // Other two optional child branches must be inactive in the observed card layout.
        if (visible(parts[1],root) || visible(parts[3],root) || visible(parts[4],root)) abort('card_effect_active');
        var row = {id:id(card),type:type,zone:zone,x:card.x,y:card.y,order:t,blockedBy:[],available:false,node:card,frame:f,masked:masked};
        refs.set(row.id,row); if (refs.size > LIMITS.cards) abort('scan_limit');
        if (zone === 'tray') { if (masked || Math.abs(card.y) > 0.01) animation('tray_mask_or_y'); trayList.push(row); }
        else cardList.push(row);
      }
    }
    for (var u = 0; u < nodes.length; u++) if (size(nodes[u],80,90) && children(nodes[u]).length === 5 &&
        nodes[u].parent !== board && nodes[u].parent !== tray && nodes[u].parent !== reserve) {
      var parked=parkedWarehouseCard(nodes[u],cc,root,emitter,records,gameLayer);
      if (!parked) animation('external_card');
      warehouseSignatures.push(parked);
    }
    if (trayList.length >= capacity) abort('tray_full');
    trayList.sort(function(a,b){return a.x-b.x;});
    for (var ti=0;ti<trayList.length;ti++) if (Math.abs(trayList[ti].x-(-240+80*ti)) > 0.01) animation('tray_spacing');
    for (var v=0;v<cardList.length;v++) {
      budget(); var c = cardList[v];
      if (c.zone === 'board') for (var w=0;w<cardList.length;w++) {
        var d = cardList[w]; if (d.zone === 'board' && d.order > c.order && Math.abs(d.x-c.x) < 79.99 && Math.abs(d.y-c.y) < 89.99) c.blockedBy.push(d.id);
      }
      if (c.masked !== (c.blockedBy.length > 0)) abort('occlusion_mismatch');
      c.action = action(c,cc,emitter,records,false);
      c.available = !c.masked && c.action.enabled;
    }
    cardsRead = refs.size;
    var typesRead = new Set(); refs.forEach(function(c){typesRead.add(c.type);}); cardTypesRead = typesRead.size;
    var sig = [id(root),id(board),id(tray),id(reserve)];
    refs.forEach(function(c){sig.push(c.id,c.zone,c.type,c.x,c.y,c.order,c.masked,c.available);});
    sig.push(warehouseSignatures);
    return {cc:cc,root:root,board:board,trayNode:tray,reserve:reserve,emitter:emitter,records:records,refs:refs,cards:cardList,tray:trayList,capacity:capacity,signature:JSON.stringify(sig)};
  }
  function unchangedCards(before, after, chosen) {
    var a=before.cards.filter(function(c){return c.id !== chosen;});
    if (a.length !== after.cards.length) return false;
    for (var i=0;i<a.length;i++) { var c=after.refs.get(a[i].id); if (!c || c.zone !== a[i].zone || c.type !== a[i].type) return false; }
    return !after.cards.some(function(c){return c.id === chosen;});
  }
  function confirmedChange(p,s) {
    if (p.root !== s.root || !unchangedCards(p.before,s,p.card.id)) return false;
    var same = p.before.tray.filter(function(c){return c.type === p.card.type;});
    var expected = p.before.tray.slice();
    if (same.length === 2) expected = expected.filter(function(c){return c.type !== p.card.type;});
    else expected.push(p.card);
    if (expected.length !== s.tray.length) return false;
    var actual = new Map(); s.tray.forEach(function(c){actual.set(c.id,c.type);});
    return expected.every(function(c){return actual.get(c.id) === c.type;});
  }
  function terminalBoardReplacement(p,s) {
    // Stage transitions may keep both scene and board objects, and pool the
    // last three card nodes. An elapsed timeout never proves this transition.
    // Require a terminal triple, an observed intervening modal, an empty new
    // bar and a large influx of identities not present in that terminal state.
    if (!p.sawModal || p.before.cards.length !== 1 || p.before.tray.length !== 2 ||
        p.before.cards[0].id !== p.card.id || s.tray.length !== 0 || s.cards.length < 18 ||
        !p.before.tray.every(function(c){return c.type === p.card.type;})) return false;
    var added = 0;
    s.refs.forEach(function(c){if (!p.before.refs.has(c.id)) added++;});
    return added >= 15;
  }
  return function runtime(options) {
    options = options || {}; rejection = null; animationDetail = null; started = clock(); cardsRead = 0; cardTypesRead = 0;
    var command = options.command || 'tick';
    if (command !== 'tick' && command !== 'pause' && command !== 'reset') return result('blocked','invalid_command');
    if (options.resumeGeneration !== generation) {
      generation = options.resumeGeneration; stable = null; planned = null;
      if (pending) { pending.confirmation=null; pending.replacement=null; }
    }
    if (command !== 'tick') {
      stable = null; planned = null;
      if (pending) { pending.confirmation=null; pending.replacement=null; }
      return result('paused',pending ? 'pending_preserved' : 'user_paused');
    }
    if (typeof plan !== 'function') return result('blocked','planner_unavailable');
    try {
      var s = snapshot(), now = clock();
      if (pending) {
        var terminalReplacement = terminalBoardReplacement(pending,s);
        if (pending.root !== s.root || pending.before.board !== s.board || terminalReplacement) {
          // A different complete board cannot replay the old card. Require two
          // stable observations before retiring uncertainty; do not count a move.
          if (!terminalReplacement && s.refs.has(pending.card.id)) return result('blocked','pending_context_changed');
          if (!pending.replacement || pending.replacement.signature !== s.signature) {
            pending.replacement={signature:s.signature,time:now}; return result('waiting_confirmation','new_board_stability');
          }
          if (now-pending.replacement.time < 180) return result('waiting_confirmation','new_board_stability');
          stable={signature:s.signature,time:pending.replacement.time};
          pending=null; planned=null; return result('watching','new_board_detected');
        }
        pending.replacement=null;
        if (confirmedChange(pending,s)) {
          if (!pending.confirmation || pending.confirmation.signature !== s.signature) {
            pending.confirmation={signature:s.signature,time:now}; return result('waiting_confirmation','confirm_stability');
          }
          if (now-pending.confirmation.time < 120) return result('waiting_confirmation','confirm_stability');
          stable={signature:s.signature,time:pending.confirmation.time};
          pending=null; planned=null; confirmed=Math.min(10000,confirmed+1); return result('move_confirmed','board_change_confirmed');
        }
        pending.confirmation=null;
        return result('waiting_confirmation',now-pending.time > 8000 ? 'confirmation_uncertain' : 'awaiting_original_result');
      }
      if (options.allowAction !== true) { stable=null; planned=null; return result('watching','action_disabled'); }
      if (!stable || stable.signature !== s.signature) { planned=null; stable={signature:s.signature,time:now}; return result('waiting_stability','observing_board'); }
      if (now-stable.time < 180) return result('waiting_stability','observing_board');
      if (!planned) {
        var clean=s.cards.map(function(c){return {id:c.id,type:c.type,zone:c.zone,x:c.x,y:c.y,order:c.order,blockedBy:c.blockedBy.slice(),available:c.available};});
        var decision=plan({cards:clean,tray:s.tray.map(function(c){return {id:c.id,type:c.type};}),capacity:s.capacity,matchSize:3,budgetMs:8});
        if (!object(decision) || decision.status !== 'move' || typeof decision.cardID !== 'string') return result('blocked','no_safe_move');
        var candidate=s.refs.get(decision.cardID);
        if (!candidate || !candidate.available || candidate.zone === 'tray') abort('planner_invalid_move');
        planned={signature:s.signature,cardID:candidate.id,event:candidate.action.event,button:candidate.action.button,receiver:candidate.action.receiver};
        // Planning and execution occur on different ticks. The next tick reads
        // a fresh complete board once; no stale plan can dispatch.
        return result('waiting_stability','plan_ready');
      }
      if (planned.signature !== s.signature) abort('context_changed');
      var current=s.refs.get(planned.cardID);
      if (!current || !current.available || current.zone === 'tray') abort('planner_invalid_move');
      var registered=action(current,s.cc,s.emitter,s.records,true); budget();
      if (registered.event !== planned.event || registered.button !== planned.button || registered.receiver !== planned.receiver ||
          window.cc !== s.cc || s.cc.director.getScene() !== s.root || version(s.cc) !== '2.4.4' ||
          s.cc.Component.EventHandler.prototype.emit !== s.emitter || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive') ||
          current.node.parent !== (current.zone === 'board' ? s.board : s.reserve) ||
          !visible(current.node,s.root) || !transform(current.node) || visible(children(current.node)[2],s.root) ||
          frame(children(children(current.node)[0])[0],s.cc) !== current.frame) abort('context_changed');
      var generatedEvent=inputEvent(s.cc,registered.button); budget();
      var fresh=s;
      planned=null;
      pending={root:s.root,card:current,before:fresh,time:clock(),confirmation:null}; stable=null;
      try { s.emitter.call(registered.event,[generatedEvent]); }
      catch (_) { return result('dispatch_uncertain','event_exception',true); }
      return result('original_event_dispatched','awaiting_original_result',true);
    } catch (_) {
      if (pending) {
        if (rejection === 'modal_visible') pending.sawModal=true;
        // An incomplete snapshot breaks consecutiveness of the proof, even
        // when a later state happens to have the same signature.
        pending.confirmation=null; pending.replacement=null;
      }
      stable=null; planned=null; return result('blocked',rejection || 'read_error');
    }
  };
})

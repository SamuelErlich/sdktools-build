/* SDKtools V2.3. Factory expression: the native recorder retains the returned
 * function in its own random, per-WebView/per-session namespace and removes it
 * when recording stops. This file does not write to window, cc or game objects.
 * Public Cocos Creator 2.x observation only; 10 ms is a cooperative soft budget.
 * Object IDs track runtime objects within this closure, never card identities.
 * capture({traceControls:true}) explicitly enables bounded, read-only control
 * descriptors. It never emits events, invokes callbacks or changes game state.
 */
(function () {
  'use strict';
  var nodeIDs = new WeakMap(), frameIDs = new WeakMap(), textureIDs = new WeakMap();
  var nextID = { n: 0, f: 0, t: 0 };
  function object(value) { return value !== null && (typeof value === 'object' || typeof value === 'function'); }
  function identity(map, value, prefix) {
    if (!object(value)) return null;
    if (!map.has(value)) map.set(value, prefix + (++nextID[prefix]));
    return map.get(value);
  }
  function num(v) { return typeof v === 'number' && isFinite(v) && Math.abs(v) <= 10000000 ? Math.round(v * 1000) / 1000 : null; }
  function flag(v) { return typeof v === 'boolean' ? v : null; }
  function tag(value) {
    if (typeof value !== 'string') return null;
    var hash = 2166136261, text = value.slice(0, 128);
    for (var i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return ('00000000' + (hash >>> 0).toString(16)).slice(-8);
  }
  function category(value) {
    if (typeof value !== 'string') return 'other';
    var match = /(?:sheep|alpaca|card|tile|board|slot|layer|button|btn|canvas|sprite|icon|cell|stage|result|match)/i.exec(value.slice(0, 96));
    return match ? match[0].toLowerCase() : 'other';
  }
  return function capture(options) {
    var traceControls = false;
    try { traceControls = !!options && options.traceControls === true; } catch (_) {}
    var limits = { maxNodes: 1536, maxVisits: 4096, maxChildrenPerNode: 512, maxQueue: 4096, maxDepth: 24, budgetMs: 10 };
    var out = { version: 2, status: 'cocos_not_exposed', cocos: {}, dom: {}, sceneNodes: [] };
    var controlTrace = traceControls ? { enabled: true, observedButtonCount: 0, candidateCount: 0,
      inspectedNodes: 0, metadataNodeCount: 0, truncated: false, truncationReasons: [],
      limits: { maxControls: 64, maxEvents: 8, maxComponents: 8, maxIdentifierLength: 96 } } : null;
    if (controlTrace) out.controlTrace = controlTrace;
    var stats = { visitedNodes: 0, inspectedChildren: 0, skippedInactive: 0, skippedInvalid: 0,
      skippedRepeated: 0, queuePeak: 0, remainingQueued: 0, elapsedMs: 0, readErrors: 0,
      frameMetadataReads: 0, frameMetadataCacheHits: 0 };
    // Frames are shared by many sprites. Snapshot their public metadata once in
    // this capture only: the next capture must observe edits to the same object.
    var reasons = [], stack = [], visited = new Set(), frameMetadata = new WeakMap();
    function reason(value) { if (reasons.indexOf(value) < 0) reasons.push(value); }
    function controlReason(value) {
      if (controlTrace && controlTrace.truncationReasons.indexOf(value) < 0) controlTrace.truncationReasons.push(value);
    }
    function failure() { stats.readErrors++; reason('read_error'); }
    function read(value, key) { try { return value == null ? undefined : value[key]; } catch (_) { failure(); return undefined; } }
    function clock() {
      try { if (typeof performance === 'object' && typeof performance.now === 'function') return performance.now(); } catch (_) {}
      return Date.now();
    }
    var began = clock();
    function expired() {
      if (clock() - began >= limits.budgetMs) { reason('time_budget'); return true; }
      return false;
    }
    function rect(value) { return { x: num(read(value, 'x')), y: num(read(value, 'y')),
      width: num(read(value, 'width')), height: num(read(value, 'height')) }; }
    function spriteMetadata(frame) {
      if (frameMetadata.has(frame)) { stats.frameMetadataCacheHits++; return frameMetadata.get(frame); }
      stats.frameMetadataReads++;
      var metadata = { present: true, frameID: identity(frameIDs, frame, 'f'), frameNameTag: tag(read(frame, 'name')) };
      frameMetadata.set(frame, metadata);
      var getRect = read(frame, 'getRect'), getTexture = read(frame, 'getTexture');
      if (typeof getRect === 'function') {
        try { metadata.atlasRect = rect(getRect.call(frame)); } catch (_) { failure(); }
      }
      if (typeof getTexture === 'function') {
        try { metadata.textureID = identity(textureIDs, getTexture.call(frame), 't'); } catch (_) { failure(); }
      }
      return metadata;
    }
    function identifier(value) {
      return typeof value === 'string' && value.length <= 96 && /^[A-Za-z_$]/.test(value) && !/[^A-Za-z0-9_.$]/.test(value) ? value : null;
    }
    function sizeIs(node, width, height) {
      return read(node, 'width') === width && read(node, 'height') === height;
    }
    function propsRow(node) {
      if (!object(node) || read(node, 'isValid') === false || read(node, 'active') !== true ||
          read(node, 'activeInHierarchy') !== true || !sizeIs(node, 292, 90)) return false;
      var children = read(node, 'children');
      return Array.isArray(children) && children.length === 3;
    }
    function controlGeometry(node, parentNode) {
      if (sizeIs(node, 80, 90) && propsRow(parentNode)) return 'props_item_geometry';
      return sizeIs(node, 240, 102) ? 'confirm_geometry' : 'none';
    }
    // A visual candidate is a scoped observation, never proof of a callable
    // game action. The modal repeats the icon, so an isolated tag is insufficient.
    function returnVisualCandidate(node, parentNode, engine) {
      if (!propsRow(parentNode)) return false;
      var children = read(parentNode, 'children');
      if (children[1] !== node) return false;
      var tags = ['8c2cba4f', '8b2cb8bc', '8d2cbbe2'], xs = [-106, 0, 106];
      var atlasXs = [880, 1002, 1124], Sprite = read(engine, 'Sprite');
      if (!Sprite) return false;
      for (var index = 0; index < 3; index++) {
        if (expired()) { controlReason('time_budget'); return false; }
        var item = children[index], icons = read(item, 'children');
        if (!object(item) || read(item, 'isValid') === false || !sizeIs(item, 80, 90) || read(item, 'x') !== xs[index] || read(item, 'y') !== 0 ||
            read(item, 'active') !== true || read(item, 'activeInHierarchy') !== true || !Array.isArray(icons) || !icons.length) return false;
        var icon = icons[0], getComponent = read(icon, 'getComponent');
        if (!object(icon) || read(icon, 'isValid') === false || read(icon, 'active') !== true ||
            read(icon, 'activeInHierarchy') !== true || !sizeIs(icon, 80, 90) || typeof getComponent !== 'function') return false;
        try {
          var sprite = getComponent.call(icon, Sprite), spriteFrame = read(sprite, 'spriteFrame');
          if (!object(spriteFrame)) return false;
          var metadata = spriteMetadata(spriteFrame), rect = metadata.atlasRect;
          if (metadata.frameNameTag !== tags[index] || !rect || rect.x !== atlasXs[index] || rect.y !== 232 ||
              rect.width !== 120 || rect.height !== 135) return false;
        } catch (_) { failure(); controlReason('read_error'); return false; }
      }
      return true;
    }
    function eventMetadata(event) {
      var target = read(event, 'target'), component = identifier(read(event, 'component'));
      var handler = identifier(read(event, 'handler')), custom = read(event, 'customEventData');
      var type = custom === null ? 'null' : typeof custom;
      var row = { targetNodeID: identity(nodeIDs, target, 'n'), targetValid: flag(read(target, 'isValid')),
        component: component, handler: handler,
        customData: { present: custom !== undefined, type: type, length: typeof custom === 'string' ? Math.min(custom.length, 10000000) : null },
        handlerResolved: false, handlerArity: null };
      var getComponent = read(target, 'getComponent');
      if (component && handler && row.targetValid !== false && typeof getComponent === 'function') {
        try {
          var receiver = getComponent.call(target, component), callback = read(receiver, handler);
          row.handlerResolved = typeof callback === 'function';
          // Inspect the function's signature only. Never invoke a game callback.
          if (row.handlerResolved) {
            var arity = read(callback, 'length');
            row.handlerArity = typeof arity === 'number' && arity >= 0 && arity <= 128 && arity % 1 === 0 ? arity : null;
          }
        } catch (_) { failure(); controlReason('read_error'); }
      }
      return row;
    }
    function inspectControl(node, parentNode, engine) {
      if (!controlTrace || expired()) { if (controlTrace) controlReason('time_budget'); return null; }
      controlTrace.inspectedNodes++;
      var startErrors = stats.readErrors, hint = controlGeometry(node, parentNode);
      if (hint !== 'none') controlTrace.candidateCount++;
      var getComponent = read(node, 'getComponent'), Button = read(engine, 'Button'), button = null;
      if (typeof getComponent === 'function' && Button) {
        try { button = getComponent.call(node, Button); } catch (_) { failure(); }
      }
      if (object(button)) controlTrace.observedButtonCount++;
      if (hint === 'none' && !object(button)) {
        if (stats.readErrors > startErrors) controlReason('read_error');
        return null;
      }
      if (controlTrace.metadataNodeCount >= controlTrace.limits.maxControls) { controlReason('control_limit'); return null; }
      var result = { geometryHint: hint, semanticHint: 'none', componentTypes: [] };
      controlTrace.metadataNodeCount++;
      if (hint !== 'none') {
        var getComponents = read(node, 'getComponents'), Component = read(engine, 'Component');
        var js = read(engine, 'js'), getClassName = read(js, 'getClassName');
        if (typeof getComponents === 'function' && Component && typeof getClassName === 'function') {
          try {
            var components = getComponents.call(node, Component);
            if (Array.isArray(components)) {
              if (components.length > 8) controlReason('component_limit');
              for (var c = 0; c < Math.min(components.length, 8); c++) {
                if (expired()) { controlReason('time_budget'); break; }
                var name = identifier(getClassName.call(js, components[c]));
                if (name && result.componentTypes.indexOf(name) < 0) result.componentTypes.push(name);
              }
            }
          } catch (_) { failure(); }
        }
        if (hint === 'props_item_geometry' && returnVisualCandidate(node, parentNode, engine)) result.semanticHint = 'return_visual_candidate';
      }
      if (object(button)) {
        var events = read(button, 'clickEvents');
        result.button = { enabled: flag(read(button, 'enabled')), enabledInHierarchy: flag(read(button, 'enabledInHierarchy')),
          interactable: flag(read(button, 'interactable')), eventCount: Array.isArray(events) ? num(events.length) : null, events: [] };
        if (Array.isArray(events)) {
          if (events.length > 8) controlReason('event_limit');
          for (var i = 0; i < Math.min(events.length, 8); i++) {
            if (expired()) { controlReason('time_budget'); break; }
            if (object(events[i])) result.button.events.push(eventMetadata(events[i]));
          }
        }
      }
      if (stats.readErrors > startErrors) controlReason('read_error');
      return result;
    }
    function finish() {
      stats.remainingQueued = stack.length;
      stats.elapsedMs = num(Math.max(0, clock() - began));
      out.cocos.limits = limits; out.cocos.stats = stats;
      out.cocos.truncationReasons = reasons;
      out.cocos.truncated = reasons.length > 0;
      out.cocos.nodeCount = out.sceneNodes.length;
      out.cocos.descendantNodeCount = out.sceneNodes.filter(function (row) { return !row.isSceneRoot; }).length;
      out.cocos.spriteNodeCount = out.sceneNodes.filter(function (row) { return !row.structuralOnly && !!row.sprite; }).length;
      if (controlTrace) {
        if (reasons.length) controlReason('scene_incomplete');
        if (reasons.indexOf('time_budget') >= 0) controlReason('time_budget');
        if (reasons.indexOf('read_error') >= 0) controlReason('read_error');
        controlTrace.truncated = controlTrace.truncationReasons.length > 0;
      }
      return out;
    }
    // Dimensions are prioritization hints from observed sessions, not predicates
    // for identifying cards. Original sibling order remains in siblingIndex.
    function priority(node, parentNode) {
      var width = read(node, 'width'), height = read(node, 'height');
      if (traceControls) {
        if ((width === 240 && height === 102) || (width === 292 && height === 90) ||
            (width === 80 && height === 90 && propsRow(parentNode))) return { score: 8, hint: 'control_geometry' };
        // One bounded child look-ahead lifts a control container ahead of the
        // dense board. Never walk or classify the whole tree outside the budget.
        var children = read(node, 'children');
        if (Array.isArray(children) && children.length <= 12) {
          for (var j = 0; j < children.length; j++) {
            if (expired()) break;
            if (sizeIs(children[j], 292, 90) || sizeIs(children[j], 240, 102)) return { score: 7, hint: 'control_geometry' };
          }
        }
      }
      if (typeof width === 'number' && typeof height === 'number') {
        if (width >= 55 && width <= 110 && height >= 65 && height <= 130)
          return { score: 4, hint: 'piece_geometry' };
        if (width >= 450 && width <= 650 && height >= 600 && height <= 850)
          return { score: 3, hint: 'board_geometry' };
      }
      var kind = category(read(node, 'name'));
      return /^(sheep|alpaca|card|tile|board|canvas|layer)$/.test(kind) ?
        { score: 2, hint: 'name_hint' } : { score: 0, hint: 'none' };
    }
    try {
      try {
        var canvases = document.querySelectorAll('canvas'), rows = [];
        for (var c = 0; c < Math.min(canvases.length, 6); c++) {
          var canvas = canvases[c];
          rows.push({ index: c, width: num(canvas.width), height: num(canvas.height), cssRect: rect(canvas.getBoundingClientRect()) });
        }
        out.dom = { viewportWidth: num(window.innerWidth), viewportHeight: num(window.innerHeight),
          devicePixelRatio: num(window.devicePixelRatio), canvasCount: Math.min(canvases.length, 10000), canvases: rows,
          iframeCount: Math.min(document.querySelectorAll('iframe').length, 10000),
          readyState: /^(loading|interactive|complete)$/.test(document.readyState) ? document.readyState : 'unknown' };
      } catch (_) { failure(); }
      var engine = window.cc;
      if (!engine || !engine.director) return finish();
      var version = typeof engine.ENGINE_VERSION === 'string' ? engine.ENGINE_VERSION : window.CocosEngine;
      version = typeof version === 'string' && /^\d{1,2}\.\d{1,3}\.\d{1,3}(?:[-+][a-zA-Z0-9.]{1,20})?$/.test(version) ? version : 'unknown';
      out.cocos = { exposed: true, version: version, activeNodesOnly: false, inactiveDescendantsSkipped: true,
        rootTraversal: 'director_scene_children_independent_of_root_active_flags', visibilityVerified: false,
        coordinates: 'cocos_local_and_world_units',
        occlusionResolved: false, cardRulesKnown: false, spriteTagMeaning: 'fnv32_public_frame_name_not_visual_identity',
        identityScope: 'probe_closure_object_identity_not_card_identity', traversal: 'prioritized_depth_first' };
      if (!/^2\./.test(version)) { out.status = 'cocos_version_unsupported'; return finish(); }
      if (typeof engine.director.getScene !== 'function') { out.status = 'scene_api_unavailable'; return finish(); }
      var scene = engine.director.getScene();
      if (!scene) { out.status = 'no_scene'; return finish(); }
      // The director's Scene is a structural container. Its active flags do not
      // decide whether to inspect its children, and do not establish visibility.
      // Preserve unknown flags as null instead of reporting an invented false.
      var rootActive = flag(read(scene, 'active')), rootHierarchy = flag(read(scene, 'activeInHierarchy'));
      out.cocos.sceneRoot = { nodeID: identity(nodeIDs, scene, 'n'), active: rootActive,
        activeInHierarchy: rootHierarchy, isValid: flag(read(scene, 'isValid')),
        childCountReal: null, structuralOnly: true };
      if (!object(scene) || out.cocos.sceneRoot.isValid === false) {
        stats.skippedInvalid++; out.status = 'scene_root_invalid'; return finish();
      }
      stack.push({ node: scene, parentNode: null, parent: null, parentID: null, depth: 0, siblingIndex: 0, hint: 'none', isSceneRoot: true });
      stats.queuePeak = 1;
      while (stack.length) {
        if (out.sceneNodes.length >= limits.maxNodes) { reason('node_limit'); break; }
        if (stats.visitedNodes >= limits.maxVisits) { reason('visit_limit'); break; }
        if (expired()) break;
        var entry = stack.pop(), node = entry.node;
        stats.visitedNodes++;
        if (!object(node) || (!entry.isSceneRoot && read(node, 'isValid') === false)) { stats.skippedInvalid++; continue; }
        if (visited.has(node)) { stats.skippedRepeated++; continue; }
        visited.add(node);
        var isSceneRoot = entry.isSceneRoot === true;
        var active = isSceneRoot ? rootActive : flag(read(node, 'active'));
        var activeInHierarchy = isSceneRoot ? rootHierarchy : flag(read(node, 'activeInHierarchy'));
        if (!isSceneRoot && (activeInHierarchy === false || active === false)) { stats.skippedInactive++; continue; }
        var index = out.sceneNodes.length, nodeID = identity(nodeIDs, node, 'n');
        var row = { index: index, parent: entry.parent, nodeID: nodeID, parentID: entry.parentID, depth: entry.depth,
          siblingIndex: entry.siblingIndex, prioritizationHint: entry.hint, category: category(read(node, 'name')),
          active: active, activeInHierarchy: activeInHierarchy, isSceneRoot: isSceneRoot, structuralOnly: isSceneRoot,
          local: {}, childCountReal: null, childrenQueued: 0 };
        ['x', 'y', 'z', 'width', 'height', 'anchorX', 'anchorY', 'scaleX', 'scaleY', 'angle', 'opacity'].forEach(function (key) {
          row.local[key] = num(read(node, key));
        });
        var world = isSceneRoot ? undefined : read(node, 'convertToWorldSpaceAR'), v2 = read(engine, 'v2');
        if (typeof world === 'function' && typeof v2 === 'function') {
          try { var origin = world.call(node, v2.call(engine, 0, 0)); row.worldOrigin = { x: num(read(origin, 'x')), y: num(read(origin, 'y')) }; } catch (_) { failure(); }
        }
        var getComponent = isSceneRoot ? undefined : read(node, 'getComponent'), Sprite = read(engine, 'Sprite');
        if (!isSceneRoot && typeof getComponent === 'function' && Sprite) {
          try {
            var sprite = getComponent.call(node, Sprite), frame = read(sprite, 'spriteFrame');
            if (object(frame)) row.sprite = spriteMetadata(frame);
          } catch (_) { failure(); }
        }
        if (traceControls && !isSceneRoot) {
          var control = inspectControl(node, entry.parentNode, engine);
          if (control) row.control = control;
        }
        out.sceneNodes.push(row);
        var children = read(node, 'children');
        if (!Array.isArray(children)) continue;
        row.childCountReal = num(children.length);
        if (isSceneRoot) out.cocos.sceneRoot.childCountReal = row.childCountReal;
        if (entry.depth >= limits.maxDepth) { if (children.length) reason('depth_limit'); continue; }
        if (children.length > limits.maxChildrenPerNode) reason('child_limit');
        var candidates = [], count = Math.min(children.length, limits.maxChildrenPerNode);
        for (var j = 0; j < count; j++) {
          if (expired()) break;
          stats.inspectedChildren++;
          var child = read(children, j), ranked = priority(child, node);
          candidates.push({ node: child, parentNode: node, parent: index, parentID: nodeID, depth: entry.depth + 1,
            siblingIndex: j, hint: ranked.hint, score: ranked.score });
        }
        candidates.sort(function (a, b) { return b.score - a.score || a.siblingIndex - b.siblingIndex; });
        var available = Math.max(0, limits.maxQueue - stack.length);
        if (candidates.length > available) { candidates.length = available; reason('queue_limit'); }
        row.childrenQueued = candidates.length;
        // LIFO: the best candidate and its descendants are visited together.
        // A wide board therefore cannot postpone every card's face until the end.
        for (var k = candidates.length - 1; k >= 0; k--) stack.push(candidates[k]);
        stats.queuePeak = Math.max(stats.queuePeak, stack.length);
      }
      out.status = out.sceneNodes.some(function (row) { return !row.isSceneRoot; }) ?
        'cocos2_scene_captured' : (reasons.length ? 'cocos2_scene_observed_incomplete' : 'cocos2_scene_observed_empty');
    } catch (_) { failure(); out.status = 'capture_error'; }
    return finish();
  };
}())

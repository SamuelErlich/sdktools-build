/* SDKtools V1: read-only, bounded observation inside the selected game WebView.
 * Cocos Creator 2.x public API only. No hooks, input, network or game mutations.
 * World coordinates are Cocos units, not UIKit points. Video is needed to verify
 * card semantics and occlusion. A sprite fingerprint does not prove a match.
 */
(function () {
  'use strict';
  var out = { version: 1, status: 'cocos_not_exposed', cocos: {}, dom: {}, sceneNodes: [] };
  var clock = function () { return (typeof performance === 'object' && performance.now) ? performance.now() : Date.now(); };
  var began = clock();
  function num(v) { return typeof v === 'number' && isFinite(v) && Math.abs(v) <= 10000000 ? Math.round(v * 1000) / 1000 : null; }
  function tag(value) {
    if (typeof value !== 'string') return null;
    var hash = 2166136261, text = value.slice(0, 128);
    for (var i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return ('00000000' + (hash >>> 0).toString(16)).slice(-8);
  }
  function category(value) {
    if (typeof value !== 'string') return 'other';
    var match = /(?:sheep|alpaca|card|tile|board|slot|layer|button|btn|canvas|sprite|icon|cell|stage|result|match)/i.exec(value.slice(0, 96));
    return match ? match[0].toLowerCase() : 'other';
  }
  function rect(value) {
    return { x: num(value.x), y: num(value.y), width: num(value.width), height: num(value.height) };
  }
  try {
    var canvases = document.querySelectorAll('canvas'), rows = [];
    for (var i = 0; i < Math.min(canvases.length, 6); i++) {
      var canvas = canvases[i];
      rows.push({ index: i, width: num(canvas.width), height: num(canvas.height), cssRect: rect(canvas.getBoundingClientRect()) });
    }
    out.dom = {
      viewportWidth: num(window.innerWidth), viewportHeight: num(window.innerHeight),
      devicePixelRatio: num(window.devicePixelRatio), canvasCount: Math.min(canvases.length, 10000), canvases: rows,
      iframeCount: Math.min(document.querySelectorAll('iframe').length, 10000),
      readyState: /^(loading|interactive|complete)$/.test(document.readyState) ? document.readyState : 'unknown'
    };
    var engine = window.cc;
    if (!engine || !engine.director) return out;
    var version = typeof engine.ENGINE_VERSION === 'string' ? engine.ENGINE_VERSION : window.CocosEngine;
    version = typeof version === 'string' && /^\d{1,2}\.\d{1,3}\.\d{1,3}(?:[-+][a-zA-Z0-9.]{1,20})?$/.test(version) ? version : 'unknown';
    out.cocos = { exposed: true, version: version, activeNodesOnly: true, coordinates: 'cocos_local_and_world_units',
      occlusionResolved: false, cardRulesKnown: false, spriteTagMeaning: 'fnv32_public_frame_name_not_visual_identity' };
    if (!/^2\./.test(version)) { out.status = 'cocos_version_unsupported'; return out; }
    if (typeof engine.director.getScene !== 'function') { out.status = 'scene_api_unavailable'; return out; }
    var scene = engine.director.getScene();
    if (!scene) { out.status = 'no_scene'; return out; }
    var queue = [{ node: scene, parent: null, depth: 0 }], cursor = 0, visited = new Set(), truncated = false;
    while (cursor < queue.length && out.sceneNodes.length < 120) {
      if (clock() - began > 8) { truncated = true; break; }
      var entry = queue[cursor++], node = entry.node;
      if (!node || visited.has(node) || node.isValid === false || node.activeInHierarchy === false) continue;
      visited.add(node);
      var index = out.sceneNodes.length;
      var row = { index: index, parent: entry.parent, depth: entry.depth, category: category(node.name),
        active: node.active === true, activeInHierarchy: node.activeInHierarchy === true,
        local: { x: num(node.x), y: num(node.y), z: num(node.z), width: num(node.width), height: num(node.height),
          anchorX: num(node.anchorX), anchorY: num(node.anchorY), scaleX: num(node.scaleX), scaleY: num(node.scaleY),
          angle: num(node.angle), opacity: num(node.opacity) } };
      if (typeof node.convertToWorldSpaceAR === 'function' && typeof engine.v2 === 'function') {
        try { var origin = node.convertToWorldSpaceAR(engine.v2(0, 0)); row.worldOrigin = { x: num(origin.x), y: num(origin.y) }; } catch (_) {}
      }
      if (typeof node.getComponent === 'function' && engine.Sprite) {
        try {
          var sprite = node.getComponent(engine.Sprite), frame = sprite && sprite.spriteFrame;
          if (frame) {
            row.sprite = { present: true, frameNameTag: tag(frame.name) };
            if (typeof frame.getRect === 'function') row.sprite.atlasRect = rect(frame.getRect());
          }
        } catch (_) {}
      }
      out.sceneNodes.push(row);
      var children = node.children;
      if (!Array.isArray(children)) continue;
      if (children.length > 64 || (entry.depth >= 12 && children.length)) truncated = true;
      if (entry.depth < 12) for (var j = 0; j < Math.min(children.length, 64); j++) {
        if (queue.length >= 240) { truncated = true; break; }
        queue.push({ node: children[j], parent: index, depth: entry.depth + 1 });
      }
    }
    if (cursor < queue.length) truncated = true;
    out.cocos.truncated = truncated;
    out.cocos.nodeCount = out.sceneNodes.length;
    out.status = 'cocos2_scene_captured';
  } catch (_) { out.status = 'capture_error'; }
  return out;
}());

/* SDKtools V2.8. Factory expression: the native recorder retains the returned
 * function in its own random, per-WebView/per-session namespace and removes it
 * when recording stops. This file does not write to window, cc or game objects.
 * Public Cocos Creator 2.x observation only; 10 ms is a cooperative soft budget.
 * Object IDs track runtime objects within this closure, never card identities.
 * capture({traceControls:true}) explicitly enables bounded, read-only control
 * descriptors. On exact verified power and CommonStoreItem structures it reads
 * bounded component data descriptors and method text. It never emits events,
 * invokes handlers, follows module state or changes game state.
 */
(function () {
  'use strict';
  var nodeIDs = new WeakMap(), frameIDs = new WeakMap(), textureIDs = new WeakMap();
  var nextID = { n: 0, f: 0, t: 0 };
  function object(value) { return value !== null && (typeof value === 'object' || typeof value === 'function'); }
  function identity(map, value, prefix) {
    if (!object(value)) return null;
    if (!map.has(value)) map.set(value, prefix + (++nextID[prefix]));
    return map.get(value);
  }
  function num(v) { return typeof v === 'number' && isFinite(v) && Math.abs(v) <= 10000000 ? Math.round(v * 1000) / 1000 : null; }
  function flag(v) { return typeof v === 'boolean' ? v : null; }
  function tag(value) {
    if (typeof value !== 'string') return null;
    var hash = 2166136261, text = value.slice(0, 128);
    for (var i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return ('00000000' + (hash >>> 0).toString(16)).slice(-8);
  }
  function category(value) {
    if (typeof value !== 'string') return 'other';
    var match = /(?:sheep|alpaca|card|tile|board|slot|layer|button|btn|canvas|sprite|icon|cell|stage|result|match)/i.exec(value.slice(0, 96));
    return match ? match[0].toLowerCase() : 'other';
  }
  return function capture(options) {
    var traceControls = false;
    try { traceControls = !!options && options.traceControls === true; } catch (_) {}
    var limits = { maxNodes: 1536, maxVisits: 4096, maxChildrenPerNode: 512, maxQueue: 4096, maxDepth: 24, budgetMs: 10 };
    var out = { version: 2, status: 'cocos_not_exposed', cocos: {}, dom: {}, sceneNodes: [] };
    var controlTrace = traceControls ? { enabled: true, scope: 'non_board_ui_controls', observedButtonCount: 0,
      skippedBoardButtonCount: 0, candidateCount: 0,
      inspectedNodes: 0, metadataNodeCount: 0, truncated: false, truncationReasons: [],
      limits: { maxControls: 64, maxEvents: 8, maxComponents: 8, maxIdentifierLength: 96,
        maxReturnInspections: 2, maxWarehouseInspections: 3, maxInspectionFields: 16, maxInspectionMethods: 16,
        maxMethodSourceChars: 8192, maxComponentSourceChars: 32768, maxSampleSourceChars: 49152 } } : null;
    if (controlTrace) out.controlTrace = controlTrace;
    var stats = { visitedNodes: 0, inspectedChildren: 0, skippedInactive: 0, skippedInvalid: 0,
      skippedRepeated: 0, queuePeak: 0, remainingQueued: 0, elapsedMs: 0, readErrors: 0,
      frameMetadataReads: 0, frameMetadataCacheHits: 0 };
    // Frames are shared by many sprites. Snapshot their public metadata once in
    // this capture only: the next capture must observe edits to the same object.
    var reasons = [], stack = [], visited = new Set(), frameMetadata = new WeakMap();
    var returnAnchors = [], propsRows = [], confirmationCandidates = [], inspectionSourceChars = 0;
    var warehouseRows = [], warehouseCandidates = [];
    var warehouseFields = ['index', 'slotIndex', 'state', 'status', 'isOpen', 'isLocked', 'isUnlocked',
      'isSelf', 'isOwner', 'isMine', 'canUse', 'enabled', 'count', 'num'];
    function warehousePrimitive(key, value) {
      if (/^is/.test(key) || key === 'canUse' || key === 'enabled') return typeof value === 'boolean' ? value : null;
      var maximum = key === 'index' || key === 'slotIndex' ? 2 : 1000000;
      return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= maximum ? value : null;
    }
    function reason(value) { if (reasons.indexOf(value) < 0) reasons.push(value); }
    function controlReason(value) {
      if (controlTrace && controlTrace.truncationReasons.indexOf(value) < 0) controlTrace.truncationReasons.push(value);
    }
    function failure() { stats.readErrors++; reason('read_error'); }
    function read(value, key) { try { return value == null ? undefined : value[key]; } catch (_) { failure(); return undefined; } }
    function clock() {
      try { if (typeof performance === 'object' && typeof performance.now === 'function') return performance.now(); } catch (_) {}
      return Date.now();
    }
    var began = clock();
    function expired() {
      if (clock() - began >= limits.budgetMs) { reason('time_budget'); return true; }
      return false;
    }
    function rect(value) { return { x: num(read(value, 'x')), y: num(read(value, 'y')),
      width: num(read(value, 'width')), height: num(read(value, 'height')) }; }
    function spriteMetadata(frame) {
      if (frameMetadata.has(frame)) { stats.frameMetadataCacheHits++; return frameMetadata.get(frame); }
      stats.frameMetadataReads++;
      var metadata = { present: true, frameID: identity(frameIDs, frame, 'f'), frameNameTag: tag(read(frame, 'name')) };
      frameMetadata.set(frame, metadata);
      var getRect = read(frame, 'getRect'), getTexture = read(frame, 'getTexture');
      if (typeof getRect === 'function') {
        try { metadata.atlasRect = rect(getRect.call(frame)); } catch (_) { failure(); }
      }
      if (typeof getTexture === 'function') {
        try { metadata.textureID = identity(textureIDs, getTexture.call(frame), 't'); } catch (_) { failure(); }
      }
      return metadata;
    }
    function identifier(value) {
      return typeof value === 'string' && value.length <= 96 && /^[A-Za-z_$]/.test(value) && !/[^A-Za-z0-9_.$]/.test(value) ? value : null;
    }
    // Component members are inspected through descriptors. Accessors are never
    // invoked merely to discover a callback or an inventory-like primitive.
    function dataMember(value, key, engine) {
      var current = value, base = engine && engine.Component && engine.Component.prototype;
      for (var depth = 0; object(current) && !componentBase(current, base, value) && depth <= 3; depth++) {
        var descriptor = Object.getOwnPropertyDescriptor(current, key);
        if (descriptor) return Object.prototype.hasOwnProperty.call(descriptor, 'value') ?
          { found: true, value: descriptor.value } : { found: false, accessor: true };
        current = Object.getPrototypeOf(current);
      }
      return { found: false };
    }
    function componentBase(value, base, receiver) {
      return value === base || value === Object.prototype ||
        (value !== receiver && Object.getPrototypeOf(value) === null);
    }
    function callbackMember(receiver, handler, engine) {
      try {
        var member = dataMember(receiver, handler, engine);
        if (member.accessor) { failure(); controlReason('read_error'); }
        return member.found && typeof member.value === 'function' ? member.value : null;
      } catch (_) { failure(); controlReason('read_error'); return null; }
    }
    function sizeIs(node, width, height) {
      return read(node, 'width') === width && read(node, 'height') === height;
    }
    function cardObservation(node, engine) {
      if (version !== '2.4.4' || !sizeIs(node, 80, 90)) return null;
      try {
        var get = read(node, 'getComponents'), name = read(read(engine, 'js'), 'getClassName');
        if (typeof get !== 'function' || typeof name !== 'function' || !engine.Component) return null;
        var components = get.call(node, engine.Component), block = null;
        if (!Array.isArray(components) || components.length > 32) return null;
        for (var i = 0; i < components.length; i++) {
          var component = components[i];
          if (!object(component) || dataMember(component, 'node', engine).value !== node ||
              dataMember(component, 'isValid', engine).value === false || name.call(engine.js, component) !== 'Block') continue;
          if (block) return null;
          block = component;
        }
        if (!block) return null;
        var info = dataMember(block, 'blockInfo', engine).value;
        if (!object(info)) return null;
        function integer(value, max) { return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= max ? value : null; }
        var type = integer(dataMember(info, 'type', engine).value, 10000), state = integer(dataMember(info, 'state', engine).value, 3);
        if (type === null || state === null) return null;
        var storage = dataMember(info, 'storage_info', engine).value;
        var layer = object(storage) ? integer(dataMember(storage, 'layer', engine).value, 511) : null;
        var index = object(storage) ? integer(dataMember(storage, 'index', engine).value, 2) : null;
        return { type: type, state: state, storageLayer: layer !== null && index !== null ? layer : null,
          storageIndex: layer !== null && index !== null ? index : null,
          canTouch: flag(dataMember(block, 'canTouch', engine).value), isTouched: flag(dataMember(block, 'isTouched', engine).value) };
      } catch (_) { failure(); return null; }
    }
    function propsRow(node) {
      if (!object(node) || read(node, 'isValid') === false || read(node, 'active') !== true ||
          read(node, 'activeInHierarchy') !== true || !sizeIs(node, 292, 90)) return false;
      var children = read(node, 'children');
      return Array.isArray(children) && children.length === 3;
    }
    function controlGeometry(node, parentNode) {
      if (sizeIs(node, 80, 90) && propsRow(parentNode)) return 'props_item_geometry';
      return sizeIs(node, 240, 102) ? 'confirm_geometry' : 'none';
    }
    // A visual candidate is a scoped observation, never proof of a callable
    // game action. The modal repeats the icon, so an isolated tag is insufficient.
    function returnVisualCandidate(node, parentNode, engine) {
      if (!propsRow(parentNode)) return false;
      var children = read(parentNode, 'children');
      if (children[1] !== node) return false;
      var tags = [], xs = [-106, 0, 106];
      var Sprite = read(engine, 'Sprite');
      if (!Sprite) return false;
      for (var index = 0; index < 3; index++) {
        if (expired()) { controlReason('time_budget'); return false; }
        var item = children[index], icons = read(item, 'children');
        if (!object(item) || read(item, 'isValid') === false || !sizeIs(item, 80, 90) || read(item, 'x') !== xs[index] || read(item, 'y') !== 0 ||
            read(item, 'active') !== true || read(item, 'activeInHierarchy') !== true || !Array.isArray(icons) || !icons.length) return false;
        var icon = icons[0], getComponent = read(icon, 'getComponent');
        if (!object(icon) || read(icon, 'isValid') === false || read(icon, 'active') !== true ||
            read(icon, 'activeInHierarchy') !== true || !sizeIs(icon, 80, 90) || typeof getComponent !== 'function') return false;
        try {
          var sprite = getComponent.call(icon, Sprite), spriteFrame = read(sprite, 'spriteFrame');
          if (!object(spriteFrame)) return false;
          var metadata = spriteMetadata(spriteFrame), rect = metadata.atlasRect;
          // Atlas packing differs between sessions. The observed names, sizes
          // and sibling geometry form the fingerprint, not texture coordinates.
          if (!rect ||
              rect.width !== 120 || rect.height !== 135) return false;
          tags.push(metadata.frameNameTag);
        } catch (_) { failure(); controlReason('read_error'); return false; }
      }
      // Match a whole row observed in the reports. The same power can occupy
      // a different slot; accepting independent tag sets would admit unseen
      // combinations. The last tuple is the V2.6 failure reported on 14 Oct.
      return ['8c2cba4f,8b2cb8bc,8d2cbbe2', '8c2cba4f,8b2cb8bc,882cb403',
        '8c2cba4f,8e2cbd75,882cb403', '8c2cba4f,8b2cb8bc,8e2cbd75'].indexOf(tags.join(',')) >= 0;
    }
    function eventMetadata(event, engine) {
      var target = read(event, 'target'), component = identifier(read(event, 'component'));
      var handler = identifier(read(event, 'handler')), custom = read(event, 'customEventData');
      var type = custom === null ? 'null' : typeof custom;
      var row = { targetNodeID: identity(nodeIDs, target, 'n'), targetValid: flag(read(target, 'isValid')),
        component: component, handler: handler,
        customData: { present: custom !== undefined, type: type, length: typeof custom === 'string' ? Math.min(custom.length, 10000000) : null },
        handlerResolved: false, handlerArity: null, resolvedComponent: null, resolution: 'unresolved' };
      var getComponent = read(target, 'getComponent');
      var receiver = null, callback = null;
      if (component && handler && row.targetValid !== false && typeof getComponent === 'function') {
        try {
          receiver = getComponent.call(target, component);
          callback = read(receiver, 'isValid') === false ? null : callbackMember(receiver, handler, engine);
          if (typeof callback === 'function') { row.resolution = 'configured_component'; row.resolvedComponent = component; }
        } catch (_) { failure(); controlReason('read_error'); }
      }
      if (row.resolution === 'unresolved' && handler && row.targetValid !== false) {
        var getComponents = read(target, 'getComponents'), Component = read(engine, 'Component');
        var js = read(engine, 'js'), getClassName = read(js, 'getClassName');
        if (typeof getComponents === 'function' && Component && typeof getClassName === 'function') {
          try {
            var components = getComponents.call(target, Component), matches = [], complete = true;
            if (Array.isArray(components)) {
              if (components.length > 8) { controlReason('component_limit'); complete = false; }
              for (var c = 0; c < Math.min(components.length, 8); c++) {
                if (expired()) { controlReason('time_budget'); complete = false; break; }
                var beforeReads = stats.readErrors;
                var candidate = components[c];
                if (!object(candidate) || read(candidate, 'isValid') === false) continue;
                var candidateCallback = callbackMember(candidate, handler, engine);
                if (stats.readErrors > beforeReads) complete = false;
                if (typeof candidateCallback === 'function' && !matches.some(function (match) { return match.receiver === candidate; }))
                  matches.push({ receiver: candidate, callback: candidateCallback });
              }
              if (matches.length > 1) row.resolution = 'ambiguous';
              else if (complete && matches.length === 1) {
                var name = identifier(getClassName.call(js, matches[0].receiver));
                if (name) { row.resolution = 'unique_target_method'; row.resolvedComponent = name; callback = matches[0].callback; }
              }
            }
          } catch (_) { failure(); controlReason('read_error'); }
        }
      }
      row.handlerResolved = row.resolution === 'configured_component' || row.resolution === 'unique_target_method';
      // Ordinary control metadata contains the signature only. The separate,
      // opt-in return inspection below has a much narrower source-reading scope.
      if (row.handlerResolved) {
        var arity = read(callback, 'length');
        row.handlerArity = typeof arity === 'number' && arity >= 0 && arity <= 128 && arity % 1 === 0 ? arity : null;
      }
      return row;
    }
    function inspectControl(node, parentNode, engine) {
      if (!controlTrace || expired()) { if (controlTrace) controlReason('time_budget'); return null; }
      controlTrace.inspectedNodes++;
      if (propsRow(node)) propsRows.push(node);
      if (sizeIs(node, 260, 94) && sizeIs(parentNode, 272, 126))
        warehouseRows.push({node: node, panel: parentNode});
      var startErrors = stats.readErrors, hint = controlGeometry(node, parentNode);
      if (hint !== 'none') controlTrace.candidateCount++;
      var getComponent = read(node, 'getComponent'), Button = read(engine, 'Button'), button = null;
      if (typeof getComponent === 'function' && Button) {
        try { button = getComponent.call(node, Button); } catch (_) { failure(); }
      }
      var events = null;
      if (object(button)) {
        controlTrace.observedButtonCount++;
        events = read(button, 'clickEvents');
        // The captures contain hundreds of board pieces with this exact single
        // handler. Count them, but reserve detailed metadata for the UI. Unknown
        // buttons and multi-event controls are not excluded by this rule.
        if (hint === 'none' && sizeIs(node, 80, 90) && Array.isArray(events) && events.length === 1 &&
            identifier(read(events[0], 'handler')) === 'touchBlock') {
          controlTrace.skippedBoardButtonCount++;
          if (stats.readErrors > startErrors) controlReason('read_error');
          return null;
        }
      }
      if (hint === 'none' && !object(button)) {
        if (stats.readErrors > startErrors) controlReason('read_error');
        return null;
      }
      if (controlTrace.metadataNodeCount >= controlTrace.limits.maxControls) { controlReason('control_limit'); return null; }
      var result = { geometryHint: hint, semanticHint: 'none', componentTypes: [] };
      controlTrace.metadataNodeCount++;
      if (hint !== 'none') {
        var getComponents = read(node, 'getComponents'), Component = read(engine, 'Component');
        var js = read(engine, 'js'), getClassName = read(js, 'getClassName');
        if (typeof getComponents === 'function' && Component && typeof getClassName === 'function') {
          try {
            var components = getComponents.call(node, Component);
            if (Array.isArray(components)) {
              if (components.length > 8) controlReason('component_limit');
              for (var c = 0; c < Math.min(components.length, 8); c++) {
                if (expired()) { controlReason('time_budget'); break; }
                var name = identifier(getClassName.call(js, components[c]));
                if (name && result.componentTypes.indexOf(name) < 0) result.componentTypes.push(name);
              }
            }
          } catch (_) { failure(); }
        }
        if (hint === 'props_item_geometry' && returnVisualCandidate(node, parentNode, engine)) {
          result.semanticHint = 'central_visual_candidate';
          returnAnchors.push({node: node, control: result});
        }
      }
      if (object(button)) {
        result.button = { enabled: flag(read(button, 'enabled')), enabledInHierarchy: flag(read(button, 'enabledInHierarchy')),
          interactable: flag(read(button, 'interactable')), eventCount: Array.isArray(events) ? num(events.length) : null, events: [] };
        if (Array.isArray(events)) {
          if (events.length > 8) controlReason('event_limit');
          for (var i = 0; i < Math.min(events.length, 8); i++) {
            if (expired()) { controlReason('time_budget'); break; }
            if (object(events[i])) result.button.events.push(eventMetadata(events[i], engine));
          }
        }
      }
      if (hint === 'confirm_geometry' && object(button)) confirmationCandidates.push({node: node, button: button, control: result});
      if (hint === 'none' && object(button) && sizeIs(node, 84, 94) && sizeIs(parentNode, 260, 94))
        warehouseCandidates.push({node: node, parent: parentNode, button: button, control: result});
      if (stats.readErrors > startErrors) controlReason('read_error');
      return result;
    }
    function inspectionReason(result, value) {
      if (result.reasons.indexOf(value) < 0) result.reasons.push(value);
      result.truncated = true;
    }
    function componentList(node, engine) {
      var getComponents = read(node, 'getComponents');
      if (typeof getComponents !== 'function' || !engine.Component) return null;
      var list = getComponents.call(node, engine.Component);
      return Array.isArray(list) && list.length <= 8 ? list : null;
    }
    function componentName(value, engine) {
      var js = read(engine, 'js'), getClassName = read(js, 'getClassName');
      return typeof getClassName === 'function' ? identifier(getClassName.call(js, value)) : null;
    }
    function visible(node) {
      return object(node) && read(node, 'isValid') !== false && read(node, 'active') === true &&
        read(node, 'activeInHierarchy') === true && read(node, 'opacity') !== 0;
    }
    function returnReceiver(anchor, engine) {
      var list = componentList(anchor, engine), matches = [], children = read(anchor, 'children');
      if (!list || !Array.isArray(children) || !children.length) return null;
      for (var c = 0; c < list.length; c++) {
        if (expired()) return null;
        if (componentName(list[c], engine) === 'Prop') matches.push(list[c]);
      }
      if (matches.length !== 1 || read(matches[0], 'isValid') === false) return null;
      var icon = children[0], getComponent = read(icon, 'getComponent');
      if (typeof getComponent !== 'function' || !engine.Button) return null;
      var button = getComponent.call(icon, engine.Button), events = read(button, 'clickEvents');
      if (!Array.isArray(events) || events.length !== 1 || read(events[0], 'target') !== anchor ||
          read(events[0], 'handler') !== 'onUseProp') return null;
      var method = dataMember(matches[0], 'onUseProp', engine);
      return method.found && typeof method.value === 'function' ? matches[0] : null;
    }
    function confirmationReceiver(candidate, engine) {
      if (!visible(candidate.node) || !sizeIs(candidate.node, 240, 102)) return null;
      var events = read(candidate.button, 'clickEvents');
      if (!Array.isArray(events) || events.length !== 1 || !object(events[0])) return null;
      var target = read(events[0], 'target'), handler = identifier(read(events[0], 'handler'));
      if (!object(target) || read(target, 'isValid') === false || handler !== 'onBtnUseClick') return null;
      var list = componentList(target, engine), configured = identifier(read(events[0], 'component'));
      if (!list || (configured && configured !== 'UsePropAlert')) return null;
      var matches = [];
      for (var c = 0; c < list.length; c++) {
        if (expired()) return null;
        var receiver = list[c], name = componentName(receiver, engine);
        if (!object(receiver) || read(receiver, 'isValid') === false || name !== 'UsePropAlert') continue;
        var member = dataMember(receiver, handler, engine);
        // An accessor cannot establish a unique receiver among unseen values.
        if (member.accessor) return null;
        if (member.found && typeof member.value === 'function' && !matches.some(function (m) { return m.receiver === receiver; }))
          matches.push({ receiver: receiver, name: name, handler: handler });
      }
      return matches.length === 1 ? matches[0] : null;
    }
    function stockBadge(anchor, engine) {
      var unavailable = {status: 'unavailable', value: null}, children = read(anchor, 'children');
      if (!Array.isArray(children) || children.length < 2) return unavailable;
      var badge = children[1], leaves = read(badge, 'children');
      if (!visible(badge) || !sizeIs(badge, 40, 40) || read(badge, 'x') !== 40 || read(badge, 'y') !== 33 ||
          !Array.isArray(leaves) || leaves.length !== 1) return unavailable;
      var getComponent = read(badge, 'getComponent');
      if (typeof getComponent !== 'function' || !engine.Sprite || !engine.Label) return unavailable;
      var sprite = getComponent.call(badge, engine.Sprite), frame = read(sprite, 'spriteFrame');
      if (!object(frame)) return unavailable;
      var metadata = spriteMetadata(frame);
      if (metadata.frameNameTag !== 'b9340fe3' || !metadata.atlasRect ||
          metadata.atlasRect.width !== 36 || metadata.atlasRect.height !== 40) return unavailable;
      var leaf = leaves[0], leafChildren = read(leaf, 'children');
      if (!visible(leaf) || num(read(leaf, 'width')) !== 13.35 || num(read(leaf, 'height')) !== 30.24 ||
          read(leaf, 'x') !== 0 || read(leaf, 'y') !== 2.5 || !Array.isArray(leafChildren) || leafChildren.length !== 0) return unavailable;
      var getLabel = read(leaf, 'getComponent');
      if (typeof getLabel !== 'function') return unavailable;
      var label = getLabel.call(leaf, engine.Label);
      if (!object(label)) return unavailable;
      // The known Label.string public API is the only text property read. Do
      // not export its content unless it is strictly a short ASCII integer.
      var text = read(label, 'string');
      return typeof text === 'string' && text.length >= 1 && text.length <= 8 && !/[^0-9]/.test(text) ?
        {status: 'numeric', value: Number(text)} : {status: 'not_numeric', value: null};
    }
    function warehouseTargets(engine) {
      // This is the visible CommonStoreItem row captured in report31A, not
      // the separate 240x90 personal reserve populated by Prop.Storage.
      if (warehouseRows.length !== 1) return [];
      var row = warehouseRows[0], items = read(row.node, 'children'), panels = read(row.panel, 'children');
      if (!visible(row.node) || !visible(row.panel) || read(row.node, 'x') !== 0 || read(row.node, 'y') !== 8 ||
          !Array.isArray(items) || items.length !== 3 || !Array.isArray(panels) || panels.length !== 2 || panels[1] !== row.node)
        return [];
      var getSprite = read(row.panel, 'getComponent');
      if (typeof getSprite !== 'function' || !engine.Sprite) return [];
      var sprite = getSprite.call(row.panel, engine.Sprite), frame = read(sprite, 'spriteFrame');
      if (!object(frame)) return [];
      var metadata = spriteMetadata(frame), atlas = metadata.atlasRect;
      if (metadata.frameNameTag !== 'd0a9f790' || !atlas || atlas.width !== 272 || atlas.height !== 126) return [];
      var targets = [], xs = [-88, 0, 88];
      for (var index = 0; index < 3; index++) {
        if (expired()) return [];
        var node = items[index];
        if (!visible(node) || !sizeIs(node, 84, 94) || read(node, 'x') !== xs[index] || read(node, 'y') !== 0) return [];
        var matches = warehouseCandidates.filter(function (candidate) { return candidate.node === node && candidate.parent === row.node; });
        if (matches.length !== 1) return [];
        var candidate = matches[0], events = read(candidate.button, 'clickEvents');
        if (!Array.isArray(events) || events.length !== 1 || !object(events[0]) || read(events[0], 'target') !== node ||
            read(events[0], 'handler') !== 'onBtnClick' || read(events[0], 'customEventData') !== '') return [];
        var configured = identifier(read(events[0], 'component'));
        if (configured && configured !== 'CommonStoreItem') return [];
        var list = componentList(node, engine), receivers = [];
        if (!list) return [];
        for (var c = 0; c < list.length; c++) {
          if (expired()) return [];
          var receiver = list[c];
          if (!object(receiver) || read(receiver, 'isValid') === false || componentName(receiver, engine) !== 'CommonStoreItem') continue;
          var handler = dataMember(receiver, 'onBtnClick', engine);
          if (handler.accessor) return [];
          if (handler.found && typeof handler.value === 'function' && receivers.indexOf(receiver) < 0) receivers.push(receiver);
        }
        if (receivers.length !== 1) return [];
        targets.push({receiver: receivers[0], name: 'CommonStoreItem', role: 'common_store_slot',
          control: candidate.control, key: 'warehouseInspection', handler: 'onBtnClick', slotIndex: index});
      }
      var containerTypes = {row: [], panel: []}, containerStatus = 'ok';
      [['row', row.node], ['panel', row.panel]].forEach(function (entry) {
        if (expired()) { containerStatus = 'truncated'; return; }
        try {
          var getComponents = read(entry[1], 'getComponents');
          if (typeof getComponents !== 'function' || !engine.Component) { containerStatus = 'unavailable'; return; }
          var list = getComponents.call(entry[1], engine.Component);
          if (!Array.isArray(list)) { containerStatus = 'unavailable'; return; }
          if (list.length > 8 && containerStatus === 'ok') containerStatus = 'truncated';
          for (var index = 0; index < Math.min(list.length, 8); index++) {
            if (expired()) { containerStatus = 'truncated'; break; }
            var name = componentName(list[index], engine);
            if (!name) { if (containerStatus === 'ok') containerStatus = 'truncated'; continue; }
            if (containerTypes[entry[0]].indexOf(name) < 0) containerTypes[entry[0]].push(name);
          }
        } catch (_) { containerStatus = 'unavailable'; }
      });
      targets.forEach(function (target) {
        // Ordinary geometry-none controls deliberately omit broad class reads.
        // The whole verified row above establishes this exact receiver class,
        // which the native warehouse sanitizer also requires before accepting
        // its inspection. Publish it only after all three slots validated.
        if (target.control.componentTypes.indexOf('CommonStoreItem') < 0)
          target.control.componentTypes.push('CommonStoreItem');
        target.containerTypes = containerTypes; target.containerStatus = containerStatus;
      });
      return targets;
    }
    function inspectReturnComponent(receiver, name, role, badge, engine, registeredHandler, entryOnly, initial) {
      var warehouse = role === 'common_store_slot';
      var result = initial || {version: 1, role: role, component: name, stockBadge: badge,
        fields: [], methods: [], truncated: false, reasons: []};
      if (warehouse) delete result.stockBadge;
      var current = receiver, base = engine.Component && engine.Component.prototype;
      var seen = new Set(result.fields.map(function (field) { return field.name; }).concat(result.methods.map(function (method) { return method.name; })));
      var componentChars = result.methods.reduce(function (sum, method) { return sum + method.source.length; }, 0);
      function appendMethod(key, value) {
        if (result.methods.length >= 16) { inspectionReason(result, 'method_limit'); return; }
        var available = Math.min(8192, 32768 - componentChars, 49152 - inspectionSourceChars);
        if (available <= 0) { inspectionReason(result, 'source_limit'); return; }
        var source = Function.prototype.toString.call(value), limited = source.length > available;
        var end = Math.min(source.length, available);
        // Do not leave half of a UTF-16 surrogate pair in the exported JSON.
        if (end > 0 && end < source.length && source.charCodeAt(end - 1) >= 0xD800 &&
            source.charCodeAt(end - 1) <= 0xDBFF && source.charCodeAt(end) >= 0xDC00 && source.charCodeAt(end) <= 0xDFFF) end--;
        var kept = source.slice(0, end);
        result.methods.push({name: key, source: kept, sourceTruncated: limited});
        componentChars += kept.length; inspectionSourceChars += kept.length;
        if (limited) inspectionReason(result, 'source_limit');
      }
      function appendPowerData() {
        // These two fields are the actual values read by UsePropAlert.setup
        // and onBtnUseClick in the new report. Do not enumerate the payload or
        // copy its ID; the lexical UseProp service remains outside this scope.
        var info = Object.getOwnPropertyDescriptor(receiver, 'propInfo');
        if (info && !Object.prototype.hasOwnProperty.call(info, 'value')) {
          inspectionReason(result, 'accessor_skipped');
        } else if (info && object(info.value)) {
          ['count', 'type'].forEach(function (key) {
            var field = Object.getOwnPropertyDescriptor(info.value, key);
            if (field && !Object.prototype.hasOwnProperty.call(field, 'value')) {
              inspectionReason(result, 'accessor_skipped'); return;
            }
            var value = field && field.value;
            if (typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= 1000000) {
              var fieldName = 'propInfo_' + key;
              result.fields.push({name: fieldName, value: value}); seen.add(fieldName);
            }
          });
        }
        if (role !== 'confirmation_candidate') return;
        var label = Object.getOwnPropertyDescriptor(receiver, 'propNameLabel');
        if (label && Object.prototype.hasOwnProperty.call(label, 'value') && object(label.value)) {
          var tid = Object.getOwnPropertyDescriptor(label.value, 'tid');
          // Export one fixed boolean, never arbitrary label strings.
          var kinds = { 'prop.storage.name': 'Storage', 'prop.withdraw.name': 'Withdraw',
            'prop.refresh.name': 'Refresh', 'prop.penetrate.name': 'Penetrate',
            'prop.bomb.name': 'Bomb', 'prop.remove.name': 'Remove' };
          if (tid && Object.prototype.hasOwnProperty.call(tid, 'value') &&
              typeof tid.value === 'string' && Object.prototype.hasOwnProperty.call(kinds, tid.value)) {
            var kindName = 'propKind' + kinds[tid.value];
            result.fields.push({name: kindName, value: true}); seen.add(kindName);
          }
        }
        var sprite = Object.getOwnPropertyDescriptor(receiver, 'propSprite');
        if (sprite && Object.prototype.hasOwnProperty.call(sprite, 'value') && object(sprite.value)) {
          var sf = read(sprite.value, 'spriteFrame');
          if (object(sf)) {
            var metadata = spriteMetadata(sf), atlas = metadata.atlasRect;
            if (atlas && atlas.width === 120 && atlas.height === 135 &&
                ['8c2cba4f', '8b2cb8bc', '8e2cbd75', '8d2cbbe2', '882cb403'].indexOf(metadata.frameNameTag) >= 0)
              result.iconFrameTag = metadata.frameNameTag;
          }
        }
      }
      try {
        // Capture the actual registered entry point first. Generic component
        // fields or helper methods must not exhaust its property/source quota.
        if (expired()) { inspectionReason(result, 'time_budget'); return result; }
        if (identifier(registeredHandler) && !seen.has(registeredHandler)) {
          var registered = dataMember(receiver, registeredHandler, engine);
          if (registered.found && typeof registered.value === 'function') {
            appendMethod(registeredHandler, registered.value); seen.add(registeredHandler);
          } else if (registered.accessor) inspectionReason(result, 'accessor_skipped');
        }
        if (entryOnly) return result;
        if (!warehouse && !expired()) appendPowerData();
        // Own descriptors plus up to three application prototype levels. The
        // engine base and Object.prototype are never enumerated.
        for (var depth = 0; object(current) && !componentBase(current, base, receiver) && depth <= 3; depth++) {
          if (expired()) { inspectionReason(result, 'time_budget'); break; }
          var keys = Object.getOwnPropertyNames(current);
          if (keys.length > 32) inspectionReason(result, 'property_limit');
          for (var i = 0; i < Math.min(keys.length, 32); i++) {
            if (expired()) { inspectionReason(result, 'time_budget'); break; }
            var key = keys[i];
            if (!identifier(key) || key === 'constructor' || seen.has(key)) continue;
            seen.add(key);
            var descriptor = Object.getOwnPropertyDescriptor(current, key);
            if (!descriptor || !Object.prototype.hasOwnProperty.call(descriptor, 'value')) {
              inspectionReason(result, 'accessor_skipped'); continue;
            }
            var value = descriptor.value;
            if (typeof value === 'function') {
              appendMethod(key, value);
            } else if (depth === 0 && (warehouse ? warehouseFields.indexOf(key) >= 0 :
                /(prop|count|num|limit|used?|stock|remain|cooldown)/i.test(key) &&
                !/(id|token|auth|pass|secret|cookie|session|account|email|phone|credential)/i.test(key))) {
              var primitive = warehouse ? warehousePrimitive(key, value) : typeof value === 'boolean' ? value : num(value);
              if (primitive !== null) {
                if (result.fields.length < 16) result.fields.push({name: key, value: primitive});
                else inspectionReason(result, 'property_limit');
              }
            }
          }
          current = Object.getPrototypeOf(current);
          if (depth === 3 && object(current) && !componentBase(current, base, receiver))
            inspectionReason(result, 'prototype_limit');
        }
      } catch (_) { inspectionReason(result, 'read_error'); }
      return result;
    }
    function inspectReturnCandidates(engine, version) {
      // A completed traversal is necessary: an unvisited second row or modal
      // must never be assumed absent. No retained target is reused next sample.
      if (!traceControls || version !== '2.4.4' || reasons.length || stack.length ||
          controlTrace.truncationReasons.length || expired()) return;
      var exposedVersion = read(window, 'CocosEngine');
      if (typeof exposedVersion === 'string' && exposedVersion !== '2.4.4') return;
      try {
        var targets = warehouseTargets(engine);
        // The middle slot changes from Retornar to Shuffle between game modes.
        // A central icon identifies that slot, never the identity of an open modal.
        if (propsRows.length === 1 && returnAnchors.length === 1) {
          var anchor = returnAnchors[0], receiver = returnReceiver(anchor.node, engine);
          if (receiver && !expired()) {
            var badge = stockBadge(anchor.node, engine);
            if (!reasons.length && !expired()) {
              var icon = read(anchor.node, 'children')[0], sprite = read(icon, 'getComponent').call(icon, engine.Sprite);
              targets.push({receiver: receiver, name: 'Prop', role: 'central_prop', badge: badge,
                control: anchor.control, key: 'returnInspection', handler: 'onUseProp',
                iconFrameTag: spriteMetadata(read(sprite, 'spriteFrame')).frameNameTag});
            }
          }
        }
        // Capture only the exact observed modal callback. This is read-only and
        // does not depend on which of the three original powers opened the modal.
        if (propsRows.length === 1 && confirmationCandidates.length === 1 && !reasons.length && !expired()) {
          var candidate = confirmationCandidates[0], resolved = confirmationReceiver(candidate, engine);
          if (resolved && !expired()) targets.push({receiver: resolved.receiver, name: resolved.name,
            role: 'confirmation_candidate', badge: {status: 'unavailable', value: null},
            control: candidate.control, key: 'returnInspection', handler: resolved.handler});
        }
        if (reasons.length || expired()) return;
        // Reserve the registered entry point of every verified receiver before
        // any component's helper methods can consume the shared49152char cap.
        targets.forEach(function (target) {
          var result = inspectReturnComponent(target.receiver, target.name, target.role, target.badge,
            engine, target.handler, true);
          if (target.key === 'warehouseInspection') {
            result.slotIndex = target.slotIndex; result.ownership = 'unknown';
            result.containerComponentTypes = target.containerTypes; result.containerMetadataStatus = target.containerStatus;
          }
          if (target.iconFrameTag) result.iconFrameTag = target.iconFrameTag;
          target.control[target.key] = result;
        });
        targets.forEach(function (target) {
          inspectReturnComponent(target.receiver, target.name, target.role, target.badge,
            engine, target.handler, false, target.control[target.key]);
        });
      } catch (_) { failure(); controlReason('read_error'); }
    }
    function finish() {
      stats.remainingQueued = stack.length;
      stats.elapsedMs = num(Math.max(0, clock() - began));
      out.cocos.limits = limits; out.cocos.stats = stats;
      out.cocos.truncationReasons = reasons;
      out.cocos.truncated = reasons.length > 0;
      out.cocos.nodeCount = out.sceneNodes.length;
      out.cocos.descendantNodeCount = out.sceneNodes.filter(function (row) { return !row.isSceneRoot; }).length;
      out.cocos.spriteNodeCount = out.sceneNodes.filter(function (row) { return !row.structuralOnly && !!row.sprite; }).length;
      if (controlTrace) {
        if (reasons.length) controlReason('scene_incomplete');
        if (reasons.indexOf('time_budget') >= 0) controlReason('time_budget');
        if (reasons.indexOf('read_error') >= 0) controlReason('read_error');
        controlTrace.truncated = controlTrace.truncationReasons.length > 0;
      }
      return out;
    }
    // Dimensions are prioritization hints from observed sessions, not predicates
    // for identifying cards. Original sibling order remains in siblingIndex.
    function priority(node, parentNode) {
      var width = read(node, 'width'), height = read(node, 'height');
      if (traceControls) {
        if ((width === 240 && height === 102) || (width === 292 && height === 90) ||
            (width === 80 && height === 90 && propsRow(parentNode))) return { score: 8, hint: 'control_geometry' };
        // One bounded child look-ahead lifts a control container ahead of the
        // dense board. Never walk or classify the whole tree outside the budget.
        var children = read(node, 'children');
        if (Array.isArray(children) && children.length <= 12) {
          for (var j = 0; j < children.length; j++) {
            if (expired()) break;
            if (sizeIs(children[j], 292, 90) || sizeIs(children[j], 240, 102)) return { score: 7, hint: 'control_geometry' };
          }
        }
      }
      if (typeof width === 'number' && typeof height === 'number') {
        if (width >= 55 && width <= 110 && height >= 65 && height <= 130)
          return { score: 4, hint: 'piece_geometry' };
        if (width >= 450 && width <= 650 && height >= 600 && height <= 850)
          return { score: 3, hint: 'board_geometry' };
      }
      var kind = category(read(node, 'name'));
      return /^(sheep|alpaca|card|tile|board|canvas|layer)$/.test(kind) ?
        { score: 2, hint: 'name_hint' } : { score: 0, hint: 'none' };
    }
    try {
      try {
        var canvases = document.querySelectorAll('canvas'), rows = [];
        for (var c = 0; c < Math.min(canvases.length, 6); c++) {
          var canvas = canvases[c];
          rows.push({ index: c, width: num(canvas.width), height: num(canvas.height), cssRect: rect(canvas.getBoundingClientRect()) });
        }
        out.dom = { viewportWidth: num(window.innerWidth), viewportHeight: num(window.innerHeight),
          devicePixelRatio: num(window.devicePixelRatio), canvasCount: Math.min(canvases.length, 10000), canvases: rows,
          iframeCount: Math.min(document.querySelectorAll('iframe').length, 10000),
          readyState: /^(loading|interactive|complete)$/.test(document.readyState) ? document.readyState : 'unknown' };
      } catch (_) { failure(); }
      var engine = window.cc;
      if (!engine || !engine.director) return finish();
      var version = typeof engine.ENGINE_VERSION === 'string' ? engine.ENGINE_VERSION : window.CocosEngine;
      version = typeof version === 'string' && /^\d{1,2}\.\d{1,3}\.\d{1,3}(?:[-+][a-zA-Z0-9.]{1,20})?$/.test(version) ? version : 'unknown';
      out.cocos = { exposed: true, version: version, activeNodesOnly: false, inactiveDescendantsSkipped: true,
        rootTraversal: 'director_scene_children_independent_of_root_active_flags', visibilityVerified: false,
        coordinates: 'cocos_local_and_world_units',
        occlusionResolved: false, cardRulesKnown: false, spriteTagMeaning: 'fnv32_public_frame_name_not_visual_identity',
        identityScope: 'probe_closure_object_identity_not_card_identity', traversal: 'prioritized_depth_first' };
      if (!/^2\./.test(version)) { out.status = 'cocos_version_unsupported'; return finish(); }
      if (typeof engine.director.getScene !== 'function') { out.status = 'scene_api_unavailable'; return finish(); }
      var scene = engine.director.getScene();
      if (!scene) { out.status = 'no_scene'; return finish(); }
      // The director's Scene is a structural container. Its active flags do not
      // decide whether to inspect its children, and do not establish visibility.
      // Preserve unknown flags as null instead of reporting an invented false.
      var rootActive = flag(read(scene, 'active')), rootHierarchy = flag(read(scene, 'activeInHierarchy'));
      out.cocos.sceneRoot = { nodeID: identity(nodeIDs, scene, 'n'), active: rootActive,
        activeInHierarchy: rootHierarchy, isValid: flag(read(scene, 'isValid')),
        childCountReal: null, structuralOnly: true };
      if (!object(scene) || out.cocos.sceneRoot.isValid === false) {
        stats.skippedInvalid++; out.status = 'scene_root_invalid'; return finish();
      }
      stack.push({ node: scene, parentNode: null, parent: null, parentID: null, depth: 0, siblingIndex: 0, hint: 'none', isSceneRoot: true });
      stats.queuePeak = 1;
      while (stack.length) {
        if (out.sceneNodes.length >= limits.maxNodes) { reason('node_limit'); break; }
        if (stats.visitedNodes >= limits.maxVisits) { reason('visit_limit'); break; }
        if (expired()) break;
        var entry = stack.pop(), node = entry.node;
        stats.visitedNodes++;
        if (!object(node) || (!entry.isSceneRoot && read(node, 'isValid') === false)) { stats.skippedInvalid++; continue; }
        if (visited.has(node)) { stats.skippedRepeated++; continue; }
        visited.add(node);
        var isSceneRoot = entry.isSceneRoot === true;
        var active = isSceneRoot ? rootActive : flag(read(node, 'active'));
        var activeInHierarchy = isSceneRoot ? rootHierarchy : flag(read(node, 'activeInHierarchy'));
        if (!isSceneRoot && (activeInHierarchy === false || active === false)) { stats.skippedInactive++; continue; }
        var index = out.sceneNodes.length, nodeID = identity(nodeIDs, node, 'n');
        var row = { index: index, parent: entry.parent, nodeID: nodeID, parentID: entry.parentID, depth: entry.depth,
          siblingIndex: entry.siblingIndex, prioritizationHint: entry.hint, category: category(read(node, 'name')),
          active: active, activeInHierarchy: activeInHierarchy, isSceneRoot: isSceneRoot, structuralOnly: isSceneRoot,
          local: {}, childCountReal: null, childrenQueued: 0 };
        ['x', 'y', 'z', 'width', 'height', 'anchorX', 'anchorY', 'scaleX', 'scaleY', 'angle', 'opacity'].forEach(function (key) {
          row.local[key] = num(read(node, key));
        });
        var world = isSceneRoot ? undefined : read(node, 'convertToWorldSpaceAR'), v2 = read(engine, 'v2');
        if (typeof world === 'function' && typeof v2 === 'function') {
          try { var origin = world.call(node, v2.call(engine, 0, 0)); row.worldOrigin = { x: num(read(origin, 'x')), y: num(read(origin, 'y')) }; } catch (_) { failure(); }
        }
        var getComponent = isSceneRoot ? undefined : read(node, 'getComponent'), Sprite = read(engine, 'Sprite');
        if (!isSceneRoot && typeof getComponent === 'function' && Sprite) {
          try {
            var sprite = getComponent.call(node, Sprite), frame = read(sprite, 'spriteFrame');
            if (object(frame)) row.sprite = spriteMetadata(frame);
          } catch (_) { failure(); }
        }
        if (!isSceneRoot) {
          var observation = cardObservation(node, engine);
          if (observation) row.cardObservation = observation;
        }
        if (traceControls && !isSceneRoot) {
          var control = inspectControl(node, entry.parentNode, engine);
          if (control) row.control = control;
        }
        out.sceneNodes.push(row);
        var children = read(node, 'children');
        if (!Array.isArray(children)) continue;
        row.childCountReal = num(children.length);
        if (isSceneRoot) out.cocos.sceneRoot.childCountReal = row.childCountReal;
        if (entry.depth >= limits.maxDepth) { if (children.length) reason('depth_limit'); continue; }
        if (children.length > limits.maxChildrenPerNode) reason('child_limit');
        var candidates = [], count = Math.min(children.length, limits.maxChildrenPerNode);
        for (var j = 0; j < count; j++) {
          if (expired()) break;
          stats.inspectedChildren++;
          var child = read(children, j), ranked = priority(child, node);
          candidates.push({ node: child, parentNode: node, parent: index, parentID: nodeID, depth: entry.depth + 1,
            siblingIndex: j, hint: ranked.hint, score: ranked.score });
        }
        candidates.sort(function (a, b) { return b.score - a.score || a.siblingIndex - b.siblingIndex; });
        var available = Math.max(0, limits.maxQueue - stack.length);
        if (candidates.length > available) { candidates.length = available; reason('queue_limit'); }
        row.childrenQueued = candidates.length;
        // LIFO: the best candidate and its descendants are visited together.
        // A wide board therefore cannot postpone every card's face until the end.
        for (var k = candidates.length - 1; k >= 0; k--) stack.push(candidates[k]);
        stats.queuePeak = Math.max(stats.queuePeak, stack.length);
      }
      out.status = out.sceneNodes.some(function (row) { return !row.isSceneRoot; }) ?
        'cocos2_scene_captured' : (reasons.length ? 'cocos2_scene_observed_incomplete' : 'cocos2_scene_observed_empty');
      inspectReturnCandidates(engine, version);
    } catch (_) { failure(); out.status = 'capture_error'; }
    return finish();
  };
}())

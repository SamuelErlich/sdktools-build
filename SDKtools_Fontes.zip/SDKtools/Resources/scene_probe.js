/* SDKtools V2. Factory expression: the native recorder retains the returned
 * function in its own random, per-WebView/per-session namespace and removes it
 * when recording stops. This file does not write to window, cc or game objects.
 * Public Cocos Creator 2.x observation only; 10 ms is a cooperative soft budget.
 * Object IDs track runtime objects within this closure, never card identities.
 */
(function () {
  'use strict';
  var nodeIDs = new WeakMap(), frameIDs = new WeakMap(), textureIDs = new WeakMap();
  var nextID = { n: 0, f: 0, t: 0 };
  function object(value) { return value !== null && (typeof value === 'object' || typeof value === 'function'); }
  function identity(map, value, prefix) {
    if (!object(value)) return null;
    if (!map.has(value)) map.set(value, prefix + (++nextID[prefix]));
    return map.get(value);
  }
  function num(v) { return typeof v === 'number' && isFinite(v) && Math.abs(v) <= 10000000 ? Math.round(v * 1000) / 1000 : null; }
  function tag(value) {
    if (typeof value !== 'string') return null;
    var hash = 2166136261, text = value.slice(0, 128);
    for (var i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return ('00000000' + (hash >>> 0).toString(16)).slice(-8);
  }
  function category(value) {
    if (typeof value !== 'string') return 'other';
    var match = /(?:sheep|alpaca|card|tile|board|slot|layer|button|btn|canvas|sprite|icon|cell|stage|result|match)/i.exec(value.slice(0, 96));
    return match ? match[0].toLowerCase() : 'other';
  }
  return function capture() {
    var limits = { maxNodes: 768, maxVisits: 1536, maxChildrenPerNode: 512, maxQueue: 1536, maxDepth: 24, budgetMs: 10 };
    var out = { version: 2, status: 'cocos_not_exposed', cocos: {}, dom: {}, sceneNodes: [] };
    var stats = { visitedNodes: 0, inspectedChildren: 0, skippedInactive: 0, skippedInvalid: 0,
      skippedRepeated: 0, queuePeak: 0, remainingQueued: 0, elapsedMs: 0, readErrors: 0 };
    var reasons = [], stack = [], visited = new Set();
    function reason(value) { if (reasons.indexOf(value) < 0) reasons.push(value); }
    function failure() { stats.readErrors++; reason('read_error'); }
    function read(value, key) { try { return value == null ? undefined : value[key]; } catch (_) { failure(); return undefined; } }
    function clock() {
      try { if (typeof performance === 'object' && typeof performance.now === 'function') return performance.now(); } catch (_) {}
      return Date.now();
    }
    var began = clock();
    function expired() {
      if (clock() - began >= limits.budgetMs) { reason('time_budget'); return true; }
      return false;
    }
    function rect(value) { return { x: num(read(value, 'x')), y: num(read(value, 'y')),
      width: num(read(value, 'width')), height: num(read(value, 'height')) }; }
    function finish() {
      stats.remainingQueued = stack.length;
      stats.elapsedMs = num(Math.max(0, clock() - began));
      out.cocos.limits = limits; out.cocos.stats = stats;
      out.cocos.truncationReasons = reasons;
      out.cocos.truncated = reasons.length > 0;
      out.cocos.nodeCount = out.sceneNodes.length;
      return out;
    }
    // Dimensions are prioritization hints from observed sessions, not predicates
    // for identifying cards. Original sibling order remains in siblingIndex.
    function priority(node) {
      var width = read(node, 'width'), height = read(node, 'height');
      if (typeof width === 'number' && typeof height === 'number') {
        if (width >= 55 && width <= 110 && height >= 65 && height <= 130)
          return { score: 4, hint: 'piece_geometry' };
        if (width >= 450 && width <= 650 && height >= 600 && height <= 850)
          return { score: 3, hint: 'board_geometry' };
      }
      var kind = category(read(node, 'name'));
      return /^(sheep|alpaca|card|tile|board|canvas|layer)$/.test(kind) ?
        { score: 2, hint: 'name_hint' } : { score: 0, hint: 'none' };
    }
    try {
      try {
        var canvases = document.querySelectorAll('canvas'), rows = [];
        for (var c = 0; c < Math.min(canvases.length, 6); c++) {
          var canvas = canvases[c];
          rows.push({ index: c, width: num(canvas.width), height: num(canvas.height), cssRect: rect(canvas.getBoundingClientRect()) });
        }
        out.dom = { viewportWidth: num(window.innerWidth), viewportHeight: num(window.innerHeight),
          devicePixelRatio: num(window.devicePixelRatio), canvasCount: Math.min(canvases.length, 10000), canvases: rows,
          iframeCount: Math.min(document.querySelectorAll('iframe').length, 10000),
          readyState: /^(loading|interactive|complete)$/.test(document.readyState) ? document.readyState : 'unknown' };
      } catch (_) { failure(); }
      var engine = window.cc;
      if (!engine || !engine.director) return finish();
      var version = typeof engine.ENGINE_VERSION === 'string' ? engine.ENGINE_VERSION : window.CocosEngine;
      version = typeof version === 'string' && /^\d{1,2}\.\d{1,3}\.\d{1,3}(?:[-+][a-zA-Z0-9.]{1,20})?$/.test(version) ? version : 'unknown';
      out.cocos = { exposed: true, version: version, activeNodesOnly: true, coordinates: 'cocos_local_and_world_units',
        occlusionResolved: false, cardRulesKnown: false, spriteTagMeaning: 'fnv32_public_frame_name_not_visual_identity',
        identityScope: 'probe_closure_object_identity_not_card_identity', traversal: 'prioritized_depth_first' };
      if (!/^2\./.test(version)) { out.status = 'cocos_version_unsupported'; return finish(); }
      if (typeof engine.director.getScene !== 'function') { out.status = 'scene_api_unavailable'; return finish(); }
      var scene = engine.director.getScene();
      if (!scene) { out.status = 'no_scene'; return finish(); }
      stack.push({ node: scene, parent: null, parentID: null, depth: 0, siblingIndex: 0, hint: 'none' });
      stats.queuePeak = 1;
      while (stack.length) {
        if (out.sceneNodes.length >= limits.maxNodes) { reason('node_limit'); break; }
        if (stats.visitedNodes >= limits.maxVisits) { reason('visit_limit'); break; }
        if (expired()) break;
        var entry = stack.pop(), node = entry.node;
        stats.visitedNodes++;
        if (!object(node) || read(node, 'isValid') === false) { stats.skippedInvalid++; continue; }
        if (visited.has(node)) { stats.skippedRepeated++; continue; }
        visited.add(node);
        if (read(node, 'activeInHierarchy') === false || read(node, 'active') === false) { stats.skippedInactive++; continue; }
        var index = out.sceneNodes.length, nodeID = identity(nodeIDs, node, 'n');
        var row = { index: index, parent: entry.parent, nodeID: nodeID, parentID: entry.parentID, depth: entry.depth,
          siblingIndex: entry.siblingIndex, prioritizationHint: entry.hint, category: category(read(node, 'name')),
          active: read(node, 'active') === true, activeInHierarchy: read(node, 'activeInHierarchy') === true,
          local: {}, childCountReal: null, childrenQueued: 0 };
        ['x', 'y', 'z', 'width', 'height', 'anchorX', 'anchorY', 'scaleX', 'scaleY', 'angle', 'opacity'].forEach(function (key) {
          row.local[key] = num(read(node, key));
        });
        var world = read(node, 'convertToWorldSpaceAR'), v2 = read(engine, 'v2');
        if (typeof world === 'function' && typeof v2 === 'function') {
          try { var origin = world.call(node, v2.call(engine, 0, 0)); row.worldOrigin = { x: num(read(origin, 'x')), y: num(read(origin, 'y')) }; } catch (_) { failure(); }
        }
        var getComponent = read(node, 'getComponent'), Sprite = read(engine, 'Sprite');
        if (typeof getComponent === 'function' && Sprite) {
          try {
            var sprite = getComponent.call(node, Sprite), frame = read(sprite, 'spriteFrame');
            if (object(frame)) {
              row.sprite = { present: true, frameID: identity(frameIDs, frame, 'f'), frameNameTag: tag(read(frame, 'name')) };
              var getRect = read(frame, 'getRect'), getTexture = read(frame, 'getTexture');
              if (typeof getRect === 'function') row.sprite.atlasRect = rect(getRect.call(frame));
              if (typeof getTexture === 'function') row.sprite.textureID = identity(textureIDs, getTexture.call(frame), 't');
            }
          } catch (_) { failure(); }
        }
        out.sceneNodes.push(row);
        var children = read(node, 'children');
        if (!Array.isArray(children)) continue;
        row.childCountReal = num(children.length);
        if (entry.depth >= limits.maxDepth) { if (children.length) reason('depth_limit'); continue; }
        if (children.length > limits.maxChildrenPerNode) reason('child_limit');
        var candidates = [], count = Math.min(children.length, limits.maxChildrenPerNode);
        for (var j = 0; j < count; j++) {
          if (expired()) break;
          stats.inspectedChildren++;
          var child = read(children, j), ranked = priority(child);
          candidates.push({ node: child, parent: index, parentID: nodeID, depth: entry.depth + 1,
            siblingIndex: j, hint: ranked.hint, score: ranked.score });
        }
        candidates.sort(function (a, b) { return b.score - a.score || a.siblingIndex - b.siblingIndex; });
        var available = Math.max(0, limits.maxQueue - stack.length);
        if (candidates.length > available) { candidates.length = available; reason('queue_limit'); }
        row.childrenQueued = candidates.length;
        // LIFO: the best candidate and its descendants are visited together.
        // A wide board therefore cannot postpone every card's face until the end.
        for (var k = candidates.length - 1; k >= 0; k--) stack.push(candidates[k]);
        stats.queuePeak = Math.max(stats.queuePeak, stack.length);
      }
      out.status = 'cocos2_scene_captured';
    } catch (_) { failure(); out.status = 'capture_error'; }
    return finish();
  };
}())

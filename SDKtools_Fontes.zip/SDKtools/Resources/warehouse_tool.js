/* SDKtools V3.0: one explicit request through the original own-slot button.
 * Evidence: CommonStoreItem.onBtnClick/init/setup captured in US 6.6.2.
 * The original callback retains its spectator/ownership/empty/lock checks.
 * No direct showAddBlock call, game-state writes, server replies or retries.
 * Dispatch is not confirmation that the original selector actually opened.
 */
(function () {
  'use strict';
  var LIMITS = { nodes: 4096, depth: 24, children: 512, components: 32, budgetMs: 18 };
  function object(v) { return v !== null && (typeof v === 'object' || typeof v === 'function'); }
  function size(n, w, h) { return n.width === w && n.height === h; }
  function hash(s) {
    if (typeof s !== 'string' || s.length > 128) return null;
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return ('00000000' + (h >>> 0).toString(16)).slice(-8);
  }
  return function openOwnWarehouse(options) {
    var visited = 0, started = 0, dispatchStarted = false, rejection = null;
    function clock() {
      var t = typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now();
      if (typeof t !== 'number' || !isFinite(t)) throw Error('clock');
      return t;
    }
    function abort(reason) { rejection = reason; throw Error('guard'); }
    function budget() { if (clock() - started >= LIMITS.budgetMs) abort('time_budget'); }
    function ownData(o, key, reason) {
      var d = Object.getOwnPropertyDescriptor(o, key);
      if (!d) return undefined;
      if (!Object.prototype.hasOwnProperty.call(d, 'value')) abort(reason);
      return d.value;
    }
    function output(status, reason) {
      var elapsed = 0;
      try { elapsed = Math.max(0, Math.round((clock() - started) * 1000) / 1000); } catch (_) {}
      return { version: 1, command: 'open', status: status, reason: reason,
        dispatched: status === 'original_event_dispatched' ? true : status === 'dispatch_uncertain' ? null : false,
        effectConfirmed: false, ownerOnly: true, serverManaged: true,
        stats: { visitedNodes: visited, elapsedMs: elapsed } };
    }
    function version(cc) {
      var primary = cc.ENGINE_VERSION, fallback = window.CocosEngine;
      if (typeof primary === 'string' && typeof fallback === 'string' && primary !== fallback) return null;
      return typeof primary === 'string' ? primary : fallback;
    }
    function visible(n, root) {
      return object(n) && n.isValid === true && n.activeInHierarchy === true &&
        (n === root || n.active === true) && typeof n.opacity === 'number' && n.opacity > 0 && n.opacity <= 255;
    }
    function transform(n) { return n.scaleX === 1 && n.scaleY === 1 && n.angle === 0; }
    function children(n) {
      var c = n.children;
      if (!Array.isArray(c)) abort('invalid_scene');
      if (c.length > LIMITS.children) abort('scan_limit');
      return c;
    }
    function components(n, cc) {
      if (typeof n.getComponents !== 'function') return [];
      var list = n.getComponents(cc.Component);
      if (!Array.isArray(list)) abort('handler_unavailable');
      if (list.length > LIMITS.components) abort('scan_limit');
      return list;
    }
    function slot(n, cc, emitter) {
      if (typeof n.getComponent !== 'function') abort('handler_unavailable');
      var list = components(n, cc), matches = [];
      for (var i = 0; i < list.length; i++) {
        budget();
        // An extra same-named handler can make Cocos' registered resolution ambiguous.
        if (object(list[i]) && typeof list[i].onBtnClick === 'function') matches.push(list[i]);
      }
      if (matches.length !== 1 || cc.js.getClassName(matches[0]) !== 'CommonStoreItem') abort('handler_ambiguous');
      var receiver = matches[0], button = n.getComponent(cc.Button), events = button && button.clickEvents;
      if (receiver.isValid !== true || receiver.node !== n || receiver.onBtnClick.length !== 0) abort('handler_unavailable');
      if (!object(button) || button.isValid !== true || button.node !== n) abort('button_unavailable');
      if (!Array.isArray(events) || events.length !== 1) abort('event_mismatch');
      var event = events[0];
      if (!object(event) || !Object.prototype.isPrototypeOf.call(cc.Component.EventHandler.prototype, event) ||
          event.emit !== emitter || event.target !== n || event.handler !== 'onBtnClick' || event.customEventData !== '') abort('event_mismatch');
      if (typeof event.component === 'string' && event.component && n.getComponent(event.component) !== receiver) abort('event_mismatch');
      var isSelf = ownData(receiver, 'isSelf', 'owner_unknown');
      if (typeof isSelf !== 'boolean') abort('owner_unknown');
      return { node: n, receiver: receiver, handler: receiver.onBtnClick, button: button, event: event, isSelf: isSelf };
    }
    function fingerprint(row, cc, root) {
      if (!size(row, 260, 94) || !transform(row) || row.x !== 0 || row.y !== 8) return null;
      var panel = row.parent;
      if (!visible(panel, root) || !size(panel, 272, 126) || !transform(panel) || typeof panel.getComponent !== 'function') return null;
      var panels = children(panel), items = children(row);
      if (panels.length !== 2 || panels[1] !== row || items.length !== 3) return null;
      var sprite = panel.getComponent(cc.Sprite), frame = sprite && sprite.spriteFrame;
      if (!object(sprite) || sprite.enabled !== true || sprite.enabledInHierarchy !== true || !object(frame) ||
          hash(frame.name) !== 'd0a9f790' || typeof frame.getRect !== 'function') return null;
      var rect = frame.getRect();
      if (!object(rect) || rect.width !== 272 || rect.height !== 126) return null;
      for (var i = 0; i < items.length; i++) {
        budget(); var n = items[i];
        if (!visible(n, root) || n.parent !== row || !size(n, 84, 94) || !transform(n) || n.x !== -88 + 88 * i || n.y !== 0) return null;
      }
      return { row: row, panel: panel, items: items };
    }
    function resolve(candidate, cc, emitter, records, root) {
      var own = [], store = null;
      for (var i = 0; i < candidate.items.length; i++) {
        budget(); var current = slot(candidate.items[i], cc, emitter), s = ownData(current.receiver, 'commonStore', 'store_unavailable');
        if (!object(s) || s.isValid !== true || cc.js.getClassName(s) !== 'CommonStore' ||
            s.node !== candidate.panel.parent || !records.has(s.node) || !visible(s.node, root)) abort('store_unavailable');
        if (store && store !== s) abort('store_unavailable');
        store = s;
        if (current.isSelf) own.push(current);
      }
      if (own.length !== 1) abort(own.length ? 'owner_ambiguous' : 'owner_unknown');
      var selected = own[0], receiver = selected.receiver, block = ownData(receiver, 'commonBlock', 'slot_state_unavailable');
      var isEmpty = ownData(receiver, 'isEmpty', 'slot_state_unavailable');
      if (typeof isEmpty !== 'boolean' || !object(block)) abort('slot_state_unavailable');
      if (!isEmpty) abort('own_slot_occupied');
      // Mirror the observed setup() emptiness test using data only; never write it.
      var contained = ownData(block, 'block', 'slot_state_unavailable'), lock = ownData(block, 'lock_state', 'slot_state_unavailable');
      if (contained != null && (!object(contained) || ownData(contained, 'id', 'slot_state_unavailable') !== '')) abort('slot_state_changed');
      if (typeof lock !== 'number' || !isFinite(lock) || Math.floor(lock) !== lock || lock < 0 || lock > 3) abort('slot_state_unavailable');
      if (lock !== 0) abort('own_slot_locked');
      if (selected.button.enabled !== true || selected.button.enabledInHierarchy !== true || selected.button.interactable !== true) abort('disabled_control');
      var content = children(selected.node);
      for (var c = 0; c < content.length; c++) {
        budget();
        if (visible(content[c], root) && size(content[c], 80, 90)) abort('slot_state_changed');
      }
      selected.store = store; selected.block = block;
      return selected;
    }
    try {
      started = clock();
      if (options !== undefined && (!object(options) || Array.isArray(options) ||
          (options.command !== undefined && options.command !== 'open'))) abort('invalid_options');
      if (typeof window !== 'object' || !window || (window.top && window.top !== window)) abort('context_unavailable');
      if (typeof document !== 'object' || !document || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('document_unavailable');
      var cc = window.cc;
      if (!object(cc) || version(cc) !== '2.4.4') abort('engine_version');
      if (!object(cc.director) || typeof cc.director.getScene !== 'function' || !cc.Sprite || !cc.Button || !cc.Component ||
          !cc.Component.EventHandler || !cc.Component.EventHandler.prototype || !object(cc.js) || typeof cc.js.getClassName !== 'function') abort('context_unavailable');
      var director = cc.director, emitter = cc.Component.EventHandler.prototype.emit;
      if (typeof emitter !== 'function') abort('event_unavailable');
      var root = director.getScene();
      if (!visible(root, root)) abort('context_unavailable');
      var stack = [{ node: root, parent: null, depth: 0 }], seen = new Set(), records = new Map(), candidates = [], buttons = [], modal = false;
      while (stack.length) {
        budget(); var entry = stack.pop(), n = entry.node;
        if (++visited > LIMITS.nodes || entry.depth > LIMITS.depth) abort('scan_limit');
        if (!object(n) || seen.has(n)) abort('invalid_scene');
        seen.add(n);
        if (entry.parent && n.parent !== entry.parent) abort('invalid_scene');
        if (!visible(n, root)) continue;
        records.set(n, entry.parent);
        if (size(n, 240, 102)) modal = true;
        var list = components(n, cc);
        for (var q = 0; q < list.length; q++) {
          budget(); var name = cc.js.getClassName(list[q]);
          if (typeof name === 'string' && /Alert$/.test(name) && list[q].enabled !== false && list[q].enabledInHierarchy !== false) modal = true;
        }
        if (typeof n.getComponent === 'function') {
          var b = n.getComponent(cc.Button);
          if (object(b) && b.enabled === true && b.enabledInHierarchy === true) buttons.push(b);
        }
        var found = fingerprint(n, cc, root);
        if (found) candidates.push(found);
        var descendants = children(n);
        if (stack.length + descendants.length > LIMITS.nodes) abort('scan_limit');
        for (var j = descendants.length - 1; j >= 0; j--) stack.push({ node: descendants[j], parent: n, depth: entry.depth + 1 });
      }
      if (modal) abort('modal_visible');
      if (!candidates.length) abort('fingerprint_mismatch');
      if (candidates.length !== 1) abort('ambiguous_control');
      var candidate = candidates[0], selected = resolve(candidate, cc, emitter, records, root);
      // The observed selector's original cover is a separate registered event.
      // Detect it rather than stacking a second request on an open selection UI.
      for (var bi = 0; bi < buttons.length; bi++) {
        budget(); var cover = buttons[bi].node;
        if (!object(cover) || cover.parent !== selected.store.node || cover.x !== 0 || cover.y !== 0 ||
            !size(cover, selected.store.node.width, selected.store.node.height) || !transform(cover)) continue;
        var events = buttons[bi].clickEvents;
        if (!Array.isArray(events) || events.length > 8) continue;
        for (var ei = 0; ei < events.length; ei++) {
          if (object(events[ei]) && events[ei].target === selected.store.node && events[ei].handler === 'onCoverClick') abort('selection_already_open');
        }
      }
      budget();
      if (window.cc !== cc || cc.director !== director || director.getScene() !== root || version(cc) !== '2.4.4' ||
          cc.Component.EventHandler.prototype.emit !== emitter || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('context_changed');
      var cursor = selected.node, depth = 0;
      while (cursor) {
        budget();
        if (++depth > LIMITS.depth + 1 || !records.has(cursor) || !visible(cursor, root)) abort('context_changed');
        var expected = records.get(cursor);
        if (expected && cursor.parent !== expected) abort('context_changed');
        cursor = expected;
      }
      var fresh = fingerprint(candidate.row, cc, root);
      if (!fresh || fresh.panel !== candidate.panel) abort('context_changed');
      var current = resolve(fresh, cc, emitter, records, root);
      if (current.node !== selected.node || current.receiver !== selected.receiver || current.button !== selected.button ||
          current.handler !== selected.handler || current.event !== selected.event || current.store !== selected.store || current.block !== selected.block) abort('context_changed');
      budget(); dispatchStarted = true;
      emitter.call(current.event, []);
      return output('original_event_dispatched', 'original_warehouse_requested');
    } catch (_) {
      return output(dispatchStarted ? 'dispatch_uncertain' : 'no_action', dispatchStarted ? 'event_exception' : rejection || 'read_error');
    }
  };
})()

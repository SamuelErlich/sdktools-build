/* SDKtools V3.11: bounded, read-only color markers for gameType 2007.
 * Solid = verified current visible color; quartered = special card;
 * hollow + cross = unknown. Back=0 never inherits retained front artwork.
 * Optional root binding validates current Store and HandArea object identity.
 * Native activation/context, 600 ms lease and owned-node-only cleanup remain.
 */
(function makeCardHints(makeRoot) {
  'use strict';
  var rootReader=typeof makeRoot==='function'?makeRoot():null,rootShown=0;
  var LIMIT={nodes:4096,children:512,depth:24,cards:256,ms:8},LEASE=600;
  var owned=new WeakSet(),icons=new Map(),layer=null,engine=null,scene=null,host=null,doc=null;
  var raf=null,deadline=0,lastRender=0;
  var latest={version:1,status:'waiting',reason:'no_verified_cards',shown:0,unknown:0,unavailable:0,unknownShown:0,special:0,candidates:0};
  function finite(v){return typeof v==='number' && isFinite(v);}
  function own(o,k){if(!o || (typeof o!=='object' && typeof o!=='function'))return null;var d=Object.getOwnPropertyDescriptor(o,k);return d && Object.prototype.hasOwnProperty.call(d,'value')?d:null;}
  function className(o){for(var p=o,i=0;p && i<5;p=Object.getPrototypeOf(p),i++){var d=own(p,'__classname__');if(d)return d.value;}return null;}
  function valid(n){return !!n && n.isValid===true;}
  function clock(){try{if(window.performance && typeof window.performance.now==='function')return window.performance.now();}catch(_){}return Date.now();}
  function report(status,reason,shown,unknown,unavailable,unknownShown,special,candidates){
    latest={version:1,status:status,reason:reason};
    [shown,unknown,unavailable,unknownShown,special,candidates].forEach(function(v,i){latest[['shown','unknown','unavailable','unknownShown','special','candidates'][i]]=Math.min(256,v||0);});if(rootReader)Object.assign(latest,rootReader.stats(),{rootShown:rootShown});return latest;
  }
  function destroy(n){if(!n)return;try{n.active=false;if(typeof n.removeFromParent==='function')n.removeFromParent(false);if(typeof n.destroy==='function')n.destroy();}catch(_){}}
  function clean(){if(raf!==null){try{window.cancelAnimationFrame(raf);}catch(_){}raf=null;}destroy(layer);layer=null;icons.clear();scene=null;engine=null;host=null;doc=null;deadline=0;}
  function clear(){clean();if(rootReader)rootReader.clear();rootShown=0;report('waiting','no_verified_cards');}
  function stop(status,reason){clean();if(rootReader)rootReader.clear();rootShown=0;return report(status,reason);}
  function name(n){return typeof n.name==='string'?n.name.slice(0,128):'';}
  function readable(n){return valid(n) && n.active===true && n.activeInHierarchy!==false && (!finite(n.opacity) || n.opacity>0);}
  function children(n){var a=n.children;if(!Array.isArray(a)||a.length>LIMIT.children)throw Error('invalid_card_layout');return a;}
  function paintChildren(n){return children(n).slice().sort(function(a,b){return (finite(a.zIndex)?a.zIndex:0)-(finite(b.zIndex)?b.zIndex:0);});}
  function tag(text){if(typeof text!=='string')return null;var h=2166136261;for(var i=0;i<Math.min(text.length,128);i++)h=Math.imul(h^text.charCodeAt(i),16777619);return ('00000000'+(h>>>0).toString(16)).slice(-8);}
  function sprite(cc,n){if(typeof n.getComponent!=='function')return null;var p=n.getComponent(cc.Sprite);return p && p.enabled!==false && p.enabledInHierarchy!==false?p:null;}
  function frameInfo(frame){
    if(!frame || typeof frame.getRect!=='function' || typeof frame.getTexture!=='function')return null;
    var r=frame.getRect(),texture=frame.getTexture();if(!r || !texture || (texture.loaded!==undefined && texture.loaded!==true))return null;
    if(!['x','y','width','height'].every(function(k){return finite(r[k]) && r[k]>=0 && r[k]<=16384;}) || r.width<1 || r.height<1)return null;
    return {name:tag(frame.name),x:r.x,y:r.y,width:r.width,height:r.height};
  }
  // Atlas placement changes between otherwise identical sessions. Match only
  // the proven frame name and trimmed dimensions within the verified subtree;
  // x/y remain validated metadata, never part of a card's visual identity.
  function matches(frame,hash,width,height){var v=frameInfo(frame);return v && v.name===hash && v.width===width && v.height===height;}
  function at(cc,from,to,x,y){if(typeof from.convertToWorldSpaceAR!=='function'||typeof to.convertToNodeSpaceAR!=='function')throw Error('renderer_unavailable');var p=to.convertToNodeSpaceAR(from.convertToWorldSpaceAR(cc.v2(x,y)));if(!p||!finite(p.x)||!finite(p.y)||Math.abs(p.x)>100000||Math.abs(p.y)>100000)throw Error('invalid_card_layout');return {x:p.x,y:p.y};}
  function corners(cc,n,to){
    if(!finite(n.width)||!finite(n.height)||n.width<=0||n.height<=0||n.width>4096||n.height>4096||!finite(n.anchorX)||!finite(n.anchorY))throw Error('invalid_card_layout');
    var x=-n.width*n.anchorX,y=-n.height*n.anchorY;return [[x,y],[x+n.width,y],[x+n.width,y+n.height],[x,y+n.height]].map(function(p){return at(cc,n,to,p[0],p[1]);});
  }
  function bounds(points){var b={left:Infinity,right:-Infinity,bottom:Infinity,top:-Infinity};points.forEach(function(p){b.left=Math.min(b.left,p.x);b.right=Math.max(b.right,p.x);b.bottom=Math.min(b.bottom,p.y);b.top=Math.max(b.top,p.y);});return b;}
  function overlap(a,b,gap){return a.left<b.right+gap && a.right>b.left-gap && a.bottom<b.top+gap && a.top>b.bottom-gap;}
  function newNode(cc,label,parent){var n=new cc.Node(label);owned.add(n);n.x=0;n.y=0;n.anchorX=.5;n.anchorY=.5;n.zIndex=32700;if(typeof parent.group==='string')n.group=parent.group;parent.addChild(n);return n;}
  function ensure(cc,root){
    var canvas=cc.Canvas && cc.Canvas.instance && cc.Canvas.instance.node,p=canvas,depth=0;
    while(valid(p) && p!==root && depth++<LIMIT.depth)p=p.parent;
    if(!readable(canvas) || p!==root)throw Error('renderer_unavailable');
    if(!cc.Sprite || typeof cc.Node!=='function' || typeof cc.Color!=='function' || typeof cc.v2!=='function' || typeof cc.Graphics!=='function')throw Error('renderer_unavailable');
    if(scene!==root || engine!==cc || host!==canvas || doc!==document || !valid(layer) || layer.parent!==canvas){clean();engine=cc;scene=root;host=canvas;doc=document;layer=newNode(cc,'SDKtools Card Colors',canvas);layer.width=0;layer.height=0;}
  }
  var COLOR_NAMES=['special','red','blue','yellow','green'];
  var PALETTE=[[230,230,236],[230,93,148],[17,135,255],[254,200,100],[175,226,77]];
  function colorOfFrames(cc,front){
    var parts=children(front);if(parts.length<3 || !readable(parts[0]) || !readable(parts[2]))return null;
    var bg=sprite(cc,parts[0]),symbol=sprite(cc,parts[2]);
    if(!bg||!symbol||!frameInfo(bg.spriteFrame)||!frameInfo(symbol.spriteFrame))return null;
    var bgName=bg.spriteFrame.name,symbolName=symbol.spriteFrame.name,color=COLOR_NAMES.indexOf(typeof bgName==='string'?bgName.replace(/^card_bg_/,''):'');
    if(color<0 || bgName!=='card_bg_'+COLOR_NAMES[color])return null;
    if(color===0){if(['change_color','inc4','throw_pot'].indexOf(symbolName)<0)return null;}
    else if(typeof symbolName!=='string'||!new RegExp('^(num[1-9]|skip|reverse|inc2|same_color|look_over|give_gamer)_'+COLOR_NAMES[color]+'$').test(symbolName))return null;
    return {color:color,bg:bg,symbol:symbol,bgFrame:bg.spriteFrame,symbolFrame:symbol.spriteFrame};
  }
  function cardState(n,front){
    var list=own(n,'_components'),candidates=[];
    if(!list || !Array.isArray(list.value))return {kind:'absent'};
    if(list.value.length>16)return {kind:'invalid'};
    list.value.forEach(function(c){if(!c||typeof c!=='object')return;var skin=own(c,'skinNode');if(className(c)==='Card'||Object.getOwnPropertyDescriptor(c,'cardInfo')||(skin&&skin.value===front))candidates.push(c);});
    if(!candidates.length)return {kind:'absent'};
    if(candidates.length!==1)return {kind:'invalid'};
    var c=candidates[0],d=own(c,'cardInfo'),info=d&&d.value,t=own(info,'type'),type=t&&t.value,cv=own(info,'color'),color=cv&&cv.value;
    if(!Number.isInteger(type)||type<0||type>10)return {kind:'invalid'};
    // Ended hands can retain color while explicitly changing type to Back.
    // Count this as a diagnostic candidate only, never a verified color.
    if(type===0)return {kind:'unknown',component:c,info:info,candidate:Number.isInteger(color)&&color>=1&&color<=4};
    var special=type===4||type===6||type===10;
    if(!Number.isInteger(color)||color<0||color>4||(!special&&color===0))return {kind:'invalid'};
    var skin=own(c,'skinNode'),bg=own(c,'bgSprite'),symbol=own(c,'typeSprite');
    if(!skin||skin.value!==front||!bg||!symbol)return {kind:'invalid'};
    // Do not require num or decode id to identify a color.
    return {kind:'known',component:c,info:info,type:type,rawColor:color,color:special?0:color,bg:bg.value,symbol:symbol.value};
  }
  function sameState(a,b){return b.kind==='known'&&['component','info','type','rawColor','color','bg','symbol'].every(function(k){return a[k]===b[k];});}
  function inspectCard(cc,n){
    var a=children(n);if(a.length!==4||sprite(cc,n))return null;
    var base=a[1],front=a[2],back=a[3],b=sprite(cc,base);
    if(!b||!matches(b.spriteFrame,'260ca2c4',216,286)||!readable(base)||sprite(cc,front))return null;
    var state=cardState(n,front),binding=rootReader&&state.component?rootReader.resolve(n,state.component):null;
    if(state.kind==='unknown')return {kind:'unknown',node:n,color:null,candidate:state.candidate};
    if(state.kind==='invalid')return {kind:'unavailable',node:n};
    var faceVisible=readable(front),backVisible=readable(back);
    if(backVisible&&!faceVisible){
      var v=sprite(cc,back);
      if(!v||!(matches(v.spriteFrame,'811c9dc5',224,295)||matches(v.spriteFrame,'4dbc405b',210,280)))return null;
      if(binding&&binding.kind==='known')return {kind:'front',node:n,color:binding.color,rootBinding:binding};
      // A hidden non-Back component may be stale too. Without a fresh store
      // binding, its raw color is diagnostic evidence only.
      return {kind:'unknown',node:n,color:null,candidate:state.kind==='known'&&state.color>0};
    }
    if(!faceVisible||backVisible)return {kind:'unavailable',node:n};
    var art=colorOfFrames(cc,front);
    if(!art)return {kind:'unavailable',node:n};
    if(state.kind==='known'&&(state.color!==art.color||state.bg!==art.bg||state.symbol!==art.symbol))return {kind:'unavailable',node:n};
    // Re-read before publishing. Reused node IDs never carry color history.
    var check=colorOfFrames(cc,front);
    if(!check||check.color!==art.color||check.bgFrame!==art.bgFrame||check.symbolFrame!==art.symbolFrame||
      (state.kind==='known'&&!sameState(state,cardState(n,front)))||!readable(front)||readable(back))return {kind:'unavailable',node:n};
    return {kind:'front',node:n,color:art.color};
  }
  function worldUnit(cc,root){
    var canvas=cc.Canvas && cc.Canvas.instance && cc.Canvas.instance.node,element=document.querySelector && document.querySelector('canvas');
    if(!valid(canvas)||!element||typeof element.getBoundingClientRect!=='function')throw Error('renderer_unavailable');
    var rect=element.getBoundingClientRect();if(!rect||!finite(rect.width)||!finite(rect.height)||rect.width<100||rect.height<100)throw Error('renderer_unavailable');
    var p=at(cc,canvas,root,0,0),q=at(cc,canvas,root,canvas.width,0),dx=q.x-p.x,dy=q.y-p.y,unit=Math.sqrt(dx*dx+dy*dy)/rect.width;
    if(!finite(unit)||unit<.05||unit>20)throw Error('renderer_unavailable');return {unit:unit,canvas:bounds(corners(cc,canvas,root))};
  }
  function paintBacking(cc,entry,item){
    var g=entry.graphic,u=item.unit,r=7*u;
    g.clear();g.lineWidth=1.5*u;g.strokeColor=new cc.Color(245,247,252,255);
    g.moveTo(item.linkStart.x,item.linkStart.y);g.lineTo(item.linkEnd.x,item.linkEnd.y);g.stroke();
    g.fillColor=new cc.Color(13,20,28,245);g.circle(0,0,9*u);g.fill();
    if(item.color===null){
      g.strokeColor=new cc.Color(161,169,183,255);g.circle(0,0,r);g.stroke();
      g.moveTo(-2*u,-2*u);g.lineTo(2*u,2*u);g.moveTo(-2*u,2*u);g.lineTo(2*u,-2*u);g.stroke();
    }else if(item.color===0){
      for(var k=0;k<4;k++){
        var rgb=PALETTE[k+1];g.fillColor=new cc.Color(rgb[0],rgb[1],rgb[2],255);g.moveTo(0,0);
        for(var j=0;j<=8;j++){var a=(k+j/8)*Math.PI/2;g.lineTo(Math.cos(a)*r,Math.sin(a)*r);}g.close();g.fill();
      }
      g.circle(0,0,r);g.stroke();
    }else{
      var color=PALETTE[item.color];g.fillColor=new cc.Color(color[0],color[1],color[2],255);g.circle(0,0,r);g.fill();g.stroke();
      // One to four short marks also distinguish colors without hue alone.
      g.strokeColor=new cc.Color(13,20,28,255);g.lineWidth=1.2*u;
      for(var i=0;i<item.color;i++){var x=(i-(item.color-1)/2)*2.6*u;g.moveTo(x,-2*u);g.lineTo(x,2*u);}g.stroke();
    }
  }
  function draw(item,view,placed,cardBoxes){
    var unit=view.unit,w=18*unit,h=18*unit,box=item.sourceBox,center=(box.left+box.right)/2;
    var hw=w/2+2*unit,hh=h/2+2*unit,above=box.top+h/2+7*unit,step=w+6*unit;
    var choices=[{x:center,y:above},{x:center-step,y:above},{x:center+step,y:above},
      {x:box.right+hw+5*unit,y:box.top-hh},{x:box.left-hw-5*unit,y:box.top-hh}];
    var a=item.topEdge[0],b=item.topEdge[1],dx=b.x-a.x,dy=b.y-a.y,length=dx*dx+dy*dy;
    if(!finite(length)||length<=0)return null;
    // Five local choices only: keep icons close to their source instead of
    // moving them into a detached row or placing them over another card.
    for(var i=0;i<choices.length;i++){
      var choice=choices[i],x=Math.max(view.canvas.left+hw+2*unit,Math.min(view.canvas.right-hw-2*unit,choice.x));
      var y=Math.max(view.canvas.bottom+hh+2*unit,Math.min(view.canvas.top-hh-2*unit,choice.y));
      if(Math.abs(x-choice.x)>step || Math.abs(y-choice.y)>step)continue;
      var target={left:x-hw,right:x+hw,bottom:y-hh,top:y+hh};
      if(target.left<view.canvas.left || target.right>view.canvas.right || target.bottom<view.canvas.bottom || target.top>view.canvas.top ||
        placed.some(function(p){return overlap(p,target,2*unit);}) || cardBoxes.some(function(p){return overlap(p,target,0);}))continue;
      var t=Math.max(0,Math.min(1,((x-a.x)*dx+(y-a.y)*dy)/length));
      var end={x:a.x+t*dx-x,y:a.y+t*dy-y};
      if(end.x+x<view.canvas.left || end.x+x>view.canvas.right || end.y+y<view.canvas.bottom || end.y+y>view.canvas.top)continue;
      var edge=Math.max(Math.abs(end.x)/hw,Math.abs(end.y)/hh);if(!finite(edge)||edge<=1)continue;
      var start={x:end.x/edge,y:end.y/edge},lx=end.x-start.x,ly=end.y-start.y;
      if(lx*lx+ly*ly>24*24*unit*unit)continue;
      item.box=target;item.x=x;item.y=y;item.width=w;item.height=h;item.unit=unit;item.linkStart=start;item.linkEnd=end;
      return item;
    }
    return null;
  }
  function apply(cc,item){
    var e=icons.get(item.node);
    if(!e||!valid(e.node)){var n=newNode(cc,'SDKtools Card Color',layer),g=n.addComponent(cc.Graphics);if(!g||typeof g.fill!=='function'||typeof g.circle!=='function'||typeof g.close!=='function')throw Error('renderer_unavailable');e={node:n,graphic:g,stamp:null};icons.set(item.node,e);}
    e.node.x=item.x;e.node.y=item.y;e.node.active=true;
    var stamp=JSON.stringify([item.color,item.unit,item.linkStart,item.linkEnd]);
    if(e.stamp!==stamp){paintBacking(cc,e,item);e.stamp=stamp;}
  }
  function render(){
    var cc=window.cc,began=clock(),root;
    if(!cc || (cc.ENGINE_VERSION!=='2.4.5' && window.CocosEngine!=='2.4.5') || (cc.ENGINE_VERSION && cc.ENGINE_VERSION!=='2.4.5') || (window.CocosEngine && window.CocosEngine!=='2.4.5'))return stop('unsupported','unsupported_engine');
    if(document.hidden===true || document.visibilityState==='hidden')return stop('blocked','hidden_document');
    if(!cc.director || typeof cc.director.getScene!=='function' || !valid(root=cc.director.getScene()))return stop('waiting','scene_unavailable');
    rootShown=0;if(rootReader)rootReader.begin(cc,root);
    var fronts=[],allCards=[],unknown=0,unavailable=0,candidates=0,seen=new Set(),queue=[{n:root,depth:0}];
    try {
      while(queue.length){
        if(seen.size>=LIMIT.nodes || clock()-began>=LIMIT.ms)throw Error('read_budget');
        var q=queue.pop(),n=q.n;if(!valid(n)||seen.has(n)||(n!==root && !readable(n))||owned.has(n)||/^SDKtools /.test(name(n)))continue;seen.add(n);
        if(q.depth>LIMIT.depth)throw Error('read_budget');
        if(/card/i.test(name(n)) && n.width===224 && n.height===295){
          var c=inspectCard(cc,n);if(c){if(allCards.length>=LIMIT.cards)throw Error('read_budget');c.order=seen.size;allCards.push(c);if(c.kind==='front'||c.kind==='unknown')fronts.push(c);if(c.kind==='unknown')unknown++;if(c.candidate)candidates++;if(c.kind==='unavailable')unavailable++;continue;}
        }
        paintChildren(n).forEach(function(c){queue.push({n:c,depth:q.depth+1});});if(queue.length>LIMIT.nodes)throw Error('read_budget');
      }
      if(!fronts.length){clean();return report(unknown||unavailable?'ready':'waiting',unavailable?'layout_limited':unknown?'hidden_faces_unknown':'no_verified_cards',0,unknown,unavailable);}
      var oldDeadline=deadline;ensure(cc,root);deadline=oldDeadline;var view=worldUnit(cc,layer),placed=[],wanted=new Set();
      var occluders=[],visibleFronts=[],cardBoxes=[];
      allCards.forEach(function(item){
        if(clock()-began>=LIMIT.ms)throw Error('read_budget');
        var points=corners(cc,item.node,layer),box=bounds(points),covered=occluders.some(function(b){return b.left<=box.left && b.right>=box.right && b.bottom<=box.bottom && b.top>=box.top;});
        item.sourceBox=box;item.topEdge=[points[3],points[2]];
        if(item.kind==='front'||item.kind==='unknown'){if(covered)unavailable++;else visibleFronts.push(item);}
        if(!covered){occluders.push(box);cardBoxes.push(box);}
      });
      fronts=visibleFronts;
      var unknownShown=0,special=0,shown=0;
      fronts.forEach(function(item){
        if(clock()-began>=LIMIT.ms)throw Error('read_budget');
        // Geometry reads can execute engine code: revalidate before drawing.
        var fresh=inspectCard(cc,item.node);
        if(!fresh||fresh.kind!==item.kind||fresh.color!==item.color||(item.rootBinding&&(!rootReader.same(item.rootBinding,fresh.rootBinding)||!rootReader.valid(item.rootBinding,item.node)))){unavailable++;return;}
        if(!draw(item,view,placed,cardBoxes)){unavailable++;var old=icons.get(item.node);if(old)destroy(old.node);icons.delete(item.node);return;}
        apply(cc,item);
        if(item.rootBinding&&!rootReader.valid(item.rootBinding,item.node)){var stale=icons.get(item.node);if(stale)destroy(stale.node);icons.delete(item.node);unavailable++;return;}
        if(item.rootBinding)rootShown++;placed.push(item.box);wanted.add(item.node);if(item.color===null)unknownShown++;else{shown++;if(item.color===0)special++;}
      });
      icons.forEach(function(e,key){if(!wanted.has(key)){destroy(e.node);icons.delete(key);}});
      return report('ready',unavailable?'layout_limited':unknown?'hidden_faces_unknown':'hints_ready',shown,unknown,unavailable,unknownShown,special,candidates);
    }catch(error){return stop('error',error && ['read_budget','invalid_card_layout','renderer_unavailable'].indexOf(error.message)>=0?error.message:'renderer_unavailable');}
  }
  function schedule(){
    if(raf!==null || !layer || deadline<=0)return;
    raf=window.requestAnimationFrame(function(){
      raf=null;try{if(clock()>=deadline){stop('blocked','lease_expired');return;}
      if(document!==doc || document.hidden===true || document.visibilityState==='hidden'){stop('blocked','hidden_document');return;}
      if(window.cc!==engine || !engine.director || engine.director.getScene()!==scene){stop('blocked','stale_scene');return;}
      if(clock()-lastRender>=33){lastRender=clock();render();}schedule();
      }catch(_){stop('error','renderer_unavailable');}
    });
  }
  function tick(){
    if(typeof window.requestAnimationFrame!=='function' || typeof window.cancelAnimationFrame!=='function')return stop('unsupported','renderer_unavailable');
    deadline=clock()+LEASE;lastRender=clock();var r=render();if(layer)schedule();return r;
  }
  return {tick:tick,clear:clear,owns:function(n){return !!n && (typeof n==='object'||typeof n==='function') && owned.has(n);}};
})

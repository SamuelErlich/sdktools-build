/* SDKtools V3.4. Ah, minha carta: read-only hints for verified visible fronts.
 * A back, inactive front or asset catalogue never establishes card identity.
 * Native gameType 2007 gating owns the namespace. tick() renews a 600 ms lease;
 * clear() cancels animation work and destroys only this factory's own nodes.
 */
(function makeCardHints() {
  'use strict';
  var LIMIT={nodes:4096,children:512,depth:24,cards:256,faceNodes:24,ms:8},LEASE=600;
  var owned=new WeakSet(),icons=new Map(),layer=null,engine=null,scene=null,host=null,doc=null;
  var raf=null,deadline=0,lastRender=0,frames=new WeakMap(),nextFrame=1;
  var latest={version:1,status:'waiting',reason:'no_verified_cards',shown:0,unknown:0,unavailable:0};
  function finite(v){return typeof v==='number' && isFinite(v);}
  function valid(n){return !!n && n.isValid===true;}
  function clock(){try{if(window.performance && typeof window.performance.now==='function')return window.performance.now();}catch(_){}return Date.now();}
  function report(status,reason,shown,unknown,unavailable){latest={version:1,status:status,reason:reason,shown:Math.min(256,shown||0),unknown:Math.min(256,unknown||0),unavailable:Math.min(256,unavailable||0)};return latest;}
  function destroy(n){if(!n)return;try{n.active=false;if(typeof n.removeFromParent==='function')n.removeFromParent(false);if(typeof n.destroy==='function')n.destroy();}catch(_){}}
  function clean(keepFrames){if(raf!==null){try{window.cancelAnimationFrame(raf);}catch(_){}raf=null;}destroy(layer);layer=null;icons.clear();scene=null;engine=null;host=null;doc=null;deadline=0;if(!keepFrames){frames=new WeakMap();nextFrame=1;}}
  function clear(){clean();report('waiting','no_verified_cards');}
  function stop(status,reason){clean();return report(status,reason);}
  function name(n){return typeof n.name==='string'?n.name.slice(0,128):'';}
  function readable(n){return valid(n) && n.active===true && n.activeInHierarchy!==false && (!finite(n.opacity) || n.opacity>0);}
  function children(n){var a=n.children;if(!Array.isArray(a)||a.length>LIMIT.children)throw Error('invalid_card_layout');return a;}
  function paintChildren(n){return children(n).slice().sort(function(a,b){return (finite(a.zIndex)?a.zIndex:0)-(finite(b.zIndex)?b.zIndex:0);});}
  function tag(text){if(typeof text!=='string')return null;var h=2166136261;for(var i=0;i<Math.min(text.length,128);i++)h=Math.imul(h^text.charCodeAt(i),16777619);return ('00000000'+(h>>>0).toString(16)).slice(-8);}
  function sprite(cc,n){if(typeof n.getComponent!=='function')return null;var p=n.getComponent(cc.Sprite);return p && p.enabled!==false && p.enabledInHierarchy!==false?p:null;}
  function frameInfo(frame){
    if(!frame || typeof frame.getRect!=='function' || typeof frame.getTexture!=='function')return null;
    var r=frame.getRect(),texture=frame.getTexture();if(!r || !texture || (texture.loaded!==undefined && texture.loaded!==true))return null;
    if(!['x','y','width','height'].every(function(k){return finite(r[k]) && r[k]>=0 && r[k]<=16384;}) || r.width<1 || r.height<1)return null;
    return {name:tag(frame.name),x:r.x,y:r.y,width:r.width,height:r.height};
  }
  function matches(frame,hash,rect){var v=frameInfo(frame);return v && v.name===hash && v.x===rect[0] && v.y===rect[1] && v.width===rect[2] && v.height===rect[3];}
  function at(cc,from,to,x,y){if(typeof from.convertToWorldSpaceAR!=='function'||typeof to.convertToNodeSpaceAR!=='function')throw Error('renderer_unavailable');var p=to.convertToNodeSpaceAR(from.convertToWorldSpaceAR(cc.v2(x,y)));if(!p||!finite(p.x)||!finite(p.y)||Math.abs(p.x)>100000||Math.abs(p.y)>100000)throw Error('invalid_card_layout');return {x:p.x,y:p.y};}
  function corners(cc,n,to){
    if(!finite(n.width)||!finite(n.height)||n.width<=0||n.height<=0||n.width>4096||n.height>4096||!finite(n.anchorX)||!finite(n.anchorY))throw Error('invalid_card_layout');
    var x=-n.width*n.anchorX,y=-n.height*n.anchorY;return [[x,y],[x+n.width,y],[x+n.width,y+n.height],[x,y+n.height]].map(function(p){return at(cc,n,to,p[0],p[1]);});
  }
  function bounds(points){var b={left:Infinity,right:-Infinity,bottom:Infinity,top:-Infinity};points.forEach(function(p){b.left=Math.min(b.left,p.x);b.right=Math.max(b.right,p.x);b.bottom=Math.min(b.bottom,p.y);b.top=Math.max(b.top,p.y);});return b;}
  function overlap(a,b){return a.left<b.right+2 && a.right>b.left-2 && a.bottom<b.top+2 && a.top>b.bottom-2;}
  function newNode(cc,label,parent){var n=new cc.Node(label);owned.add(n);n.x=0;n.y=0;n.anchorX=.5;n.anchorY=.5;n.zIndex=32700;if(typeof parent.group==='string')n.group=parent.group;parent.addChild(n);return n;}
  function ensure(cc,root){
    var canvas=cc.Canvas && cc.Canvas.instance && cc.Canvas.instance.node,p=canvas,depth=0;
    while(valid(p) && p!==root && depth++<LIMIT.depth)p=p.parent;
    if(!readable(canvas) || p!==root)throw Error('renderer_unavailable');
    if(!cc.Sprite || !cc.Sprite.SizeMode || !finite(cc.Sprite.SizeMode.CUSTOM) || !cc.Sprite.Type || !finite(cc.Sprite.Type.SIMPLE) || typeof cc.Node!=='function' || typeof cc.Color!=='function' || typeof cc.v2!=='function' || typeof cc.Graphics!=='function')throw Error('renderer_unavailable');
    if(scene!==root || engine!==cc || host!==canvas || doc!==document || !valid(layer) || layer.parent!==canvas){clean(true);engine=cc;scene=root;host=canvas;doc=document;layer=newNode(cc,'SDKtools Card Faces',canvas);layer.width=0;layer.height=0;}
  }
  function frameID(f){if(!frames.has(f))frames.set(f,nextFrame++);return frames.get(f);}
  function frontParts(cc,card,base,front){
    var out=[],seen=new Set(),queue=[{n:front,depth:0},{n:base,depth:0}];
    while(queue.length){
      var item=queue.pop(),n=item.n;if(seen.has(n))throw Error('invalid_card_layout');seen.add(n);if(seen.size>LIMIT.faceNodes||item.depth>5)throw Error('invalid_card_layout');
      if(!readable(n))continue;
      var sp=sprite(cc,n);
      if(sp){
        if(sp.type!==cc.Sprite.Type.SIMPLE || !frameInfo(sp.spriteFrame))throw Error('invalid_card_layout');
        var p=at(cc,n,card,0,0),px=at(cc,n,card,1,0),py=at(cc,n,card,0,1),vx={x:px.x-p.x,y:px.y-p.y},vy={x:py.x-p.x,y:py.y-p.y};
        var sx=Math.sqrt(vx.x*vx.x+vx.y*vx.y),sy=Math.sqrt(vy.x*vy.x+vy.y*vy.y);
        if(!finite(n.width)||!finite(n.height)||n.width<=0||n.height<=0||n.width>448||n.height>590||Math.abs(p.x)>448||Math.abs(p.y)>590||sx<=0||sy<=0||vx.x*vy.y-vx.y*vy.x<=0||Math.abs(vx.x*vy.x+vx.y*vy.y)>1e-5*sx*sy)throw Error('invalid_card_layout');
        var color=n.color;if(!color || !['r','g','b','a'].every(function(k){return finite(color[k])&&color[k]>=0&&color[k]<=255;}))throw Error('invalid_card_layout');
        out.push({source:n,frame:sp.spriteFrame,frameID:frameID(sp.spriteFrame),x:p.x,y:p.y,width:n.width,height:n.height,anchorX:n.anchorX,anchorY:n.anchorY,scaleX:sx,scaleY:sy,angle:Math.atan2(vx.y,vx.x)*180/Math.PI,color:{r:color.r,g:color.g,b:color.b,a:color.a},opacity:finite(n.opacity)?n.opacity:255,trim:typeof sp.trim==='boolean'?sp.trim:true});
      }
      paintChildren(n).reverse().forEach(function(c){if(!owned.has(c))queue.push({n:c,depth:item.depth+1});});
    }
    // Base plus at least a colored front and a distinct symbol is required.
    if(out.length<3 || out.length>12)throw Error('invalid_card_layout');return out;
  }
  function inspectCard(cc,n){
    var a=children(n);if(a.length!==4 || sprite(cc,n))return null;
    var base=a[1],front=a[2],back=a[3],b=sprite(cc,base);
    if(!b || !matches(b.spriteFrame,'260ca2c4',[909,212,216,286]) || !readable(base) || sprite(cc,front))return null;
    var faceVisible=readable(front),backVisible=readable(back);
    if(backVisible && !faceVisible){
      var v=sprite(cc,back);
      // A name hash alone is not an identity; one back has an empty name.
      if(!v || !(matches(v.spriteFrame,'811c9dc5',[1357,208,224,295]) || matches(v.spriteFrame,'4dbc405b',[1138,212,210,280])))return null;
      return {kind:'unknown',node:n};
    }
    if(!faceVisible || backVisible)return {kind:'unavailable',node:n};
    // Inactive back components are deliberately not read: their frame was not
    // captured and need not be initialized for a valid observed front.
    var faceChildren=children(front);
    if(faceChildren.length<3 || !readable(faceChildren[0]) || !readable(faceChildren[2]) || !sprite(cc,faceChildren[0]) || !sprite(cc,faceChildren[2]))throw Error('invalid_card_layout');
    return {kind:'front',node:n,parts:frontParts(cc,n,base,front)};
  }
  function worldUnit(cc,root){
    var canvas=cc.Canvas && cc.Canvas.instance && cc.Canvas.instance.node,element=document.querySelector && document.querySelector('canvas');
    if(!valid(canvas)||!element||typeof element.getBoundingClientRect!=='function')throw Error('renderer_unavailable');
    var rect=element.getBoundingClientRect();if(!rect||!finite(rect.width)||!finite(rect.height)||rect.width<100||rect.height<100)throw Error('renderer_unavailable');
    var p=at(cc,canvas,root,0,0),q=at(cc,canvas,root,canvas.width,0),dx=q.x-p.x,dy=q.y-p.y,unit=Math.sqrt(dx*dx+dy*dy)/rect.width;
    if(!finite(unit)||unit<.05||unit>20)throw Error('renderer_unavailable');return {unit:unit,canvas:bounds(corners(cc,canvas,root))};
  }
  function paintBacking(cc,entry,width,height){
    var g=entry.graphic;g.clear();g.fillColor=new cc.Color(13,20,28,230);g.strokeColor=new cc.Color(243,159,63,240);g.lineWidth=1.5;
    g.moveTo(-width/2,-height/2);g.lineTo(width/2,-height/2);g.lineTo(width/2,height/2);g.lineTo(-width/2,height/2);g.close();g.fill();g.stroke();
  }
  function draw(cc,item,unit){
    var card=item.node;
    var scale=20*unit/224,w=20*unit,h=295*scale,box=bounds(corners(cc,card,layer));
    var x=(box.left+box.right)/2,y=box.top+h/2+3*unit;
    item.box={left:x-w/2-2*unit,right:x+w/2+2*unit,bottom:y-h/2-2*unit,top:y+h/2+2*unit};
    item.x=x;item.y=y;item.width=w;item.height=h;item.scale=scale;
    return item;
  }
  function apply(cc,item){
    var e=icons.get(item.node);
    if(!e||!valid(e.node)){var n=newNode(cc,'SDKtools Visible Card',layer),g=n.addComponent(cc.Graphics);if(!g||typeof g.fill!=='function'||typeof g.close!=='function')throw Error('renderer_unavailable');e={node:n,graphic:g,parts:[],stamp:null};icons.set(item.node,e);}
    e.node.x=item.x;e.node.y=item.y;e.node.active=true;
    var stamp=JSON.stringify([item.scale,item.parts.map(function(p){return [p.frameID,p.x,p.y,p.width,p.height,p.anchorX,p.anchorY,p.scaleX,p.scaleY,p.angle,p.color,p.opacity,p.trim];})]);
    if(e.stamp===stamp)return;
    while(e.parts.length>item.parts.length)destroy(e.parts.pop());
    item.parts.forEach(function(p,i){
      var n=e.parts[i];if(!valid(n)){n=newNode(cc,'SDKtools Visible Face Part',e.node);n.addComponent(cc.Sprite);e.parts[i]=n;}
      var sp=n.getComponent(cc.Sprite);sp.spriteFrame=p.frame;sp.type=cc.Sprite.Type.SIMPLE;sp.sizeMode=cc.Sprite.SizeMode.CUSTOM;sp.trim=p.trim;
      n.width=p.width;n.height=p.height;n.anchorX=p.anchorX;n.anchorY=p.anchorY;n.x=p.x*item.scale;n.y=p.y*item.scale;n.scaleX=p.scaleX*item.scale;n.scaleY=p.scaleY*item.scale;n.angle=p.angle;n.opacity=p.opacity;n.color=new cc.Color(p.color.r,p.color.g,p.color.b,p.color.a);
    });
    paintBacking(cc,e,item.width+4*item.scale*224/20,item.height+4*item.scale*224/20);e.stamp=stamp;
  }
  function render(){
    var cc=window.cc,began=clock(),root;
    if(!cc || (cc.ENGINE_VERSION!=='2.4.5' && window.CocosEngine!=='2.4.5') || (cc.ENGINE_VERSION && cc.ENGINE_VERSION!=='2.4.5') || (window.CocosEngine && window.CocosEngine!=='2.4.5'))return stop('unsupported','unsupported_engine');
    if(document.hidden===true || document.visibilityState==='hidden')return stop('blocked','hidden_document');
    if(!cc.director || typeof cc.director.getScene!=='function' || !valid(root=cc.director.getScene()))return stop('waiting','scene_unavailable');
    var fronts=[],allCards=[],unknown=0,unavailable=0,seen=new Set(),queue=[{n:root,depth:0}];
    try {
      while(queue.length){
        if(seen.size>=LIMIT.nodes || clock()-began>=LIMIT.ms)throw Error('read_budget');
        var q=queue.pop(),n=q.n;if(!valid(n)||seen.has(n)||(n!==root && !readable(n))||owned.has(n)||/^SDKtools /.test(name(n)))continue;seen.add(n);
        if(q.depth>LIMIT.depth)throw Error('read_budget');
        if(/card/i.test(name(n)) && n.width===224 && n.height===295){
          var c=inspectCard(cc,n);if(c){if(allCards.length>=LIMIT.cards)throw Error('read_budget');c.order=seen.size;allCards.push(c);if(c.kind==='front')fronts.push(c);else if(c.kind==='unknown')unknown++;else unavailable++;continue;}
        }
        paintChildren(n).forEach(function(c){queue.push({n:c,depth:q.depth+1});});if(queue.length>LIMIT.nodes)throw Error('read_budget');
      }
      if(!fronts.length){clean();return report(unknown?'ready':'waiting',unknown?'hidden_faces_unknown':'no_verified_cards',0,unknown,unavailable);}
      var oldDeadline=deadline;ensure(cc,root);deadline=oldDeadline;var view=worldUnit(cc,layer),placed=[],wanted=new Set();
      var occluders=[],visibleFronts=[];
      allCards.forEach(function(item){
        var box=bounds(corners(cc,item.node,layer)),covered=occluders.some(function(b){return b.left<=box.left && b.right>=box.right && b.bottom<=box.bottom && b.top>=box.top;});
        if(item.kind==='front'){if(covered)unavailable++;else visibleFronts.push(item);}
        if(!covered)occluders.push(box);
      });
      fronts=visibleFronts;
      fronts.forEach(function(item){
        draw(cc,item,view.unit);var box=item.box;
        if(box.left<view.canvas.left || box.right>view.canvas.right || box.bottom<view.canvas.bottom || box.top>view.canvas.top || placed.some(function(b){return overlap(b,box);})){unavailable++;var old=icons.get(item.node);if(old)destroy(old.node);icons.delete(item.node);return;}
        apply(cc,item);placed.push(box);wanted.add(item.node);
      });
      icons.forEach(function(e,key){if(!wanted.has(key)){destroy(e.node);icons.delete(key);}});
      return report('ready',unavailable?'layout_limited':unknown?'hidden_faces_unknown':'hints_ready',wanted.size,unknown,unavailable);
    }catch(error){return stop('error',error && ['read_budget','invalid_card_layout','renderer_unavailable'].indexOf(error.message)>=0?error.message:'renderer_unavailable');}
  }
  function schedule(){
    if(raf!==null || !layer || deadline<=0)return;
    raf=window.requestAnimationFrame(function(){
      raf=null;try{if(clock()>=deadline){stop('blocked','lease_expired');return;}
      if(document!==doc || document.hidden===true || document.visibilityState==='hidden'){stop('blocked','hidden_document');return;}
      if(window.cc!==engine || !engine.director || engine.director.getScene()!==scene){stop('blocked','stale_scene');return;}
      if(clock()-lastRender>=33){lastRender=clock();render();}schedule();
      }catch(_){stop('error','renderer_unavailable');}
    });
  }
  function tick(){
    if(typeof window.requestAnimationFrame!=='function' || typeof window.cancelAnimationFrame!=='function')return stop('unsupported','renderer_unavailable');
    deadline=clock()+LEASE;lastRender=clock();var r=render();if(layer)schedule();return r;
  }
  return {tick:tick,clear:clear,owns:function(n){return !!n && (typeof n==='object'||typeof n==='function') && owned.has(n);}};
})

/* Cooperative pickup uses the original registered Block.touchBlock only.
 * A pending pickup survives pauses and never becomes a timeout retry. */
(function (plan) {
 'use strict';
 var job=null,confirmed=0,phase='rush',progress=null,available=0,reason='ready';
 function object(v){return v!==null&&(typeof v==='object'||typeof v==='function');}
 function own(o,k){if(!object(o))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);if(d&&!Object.prototype.hasOwnProperty.call(d,'value'))throw Error('accessor');return d&&d.value;}
 function integer(n,a,b){return typeof n==='number'&&Number.isInteger(n)&&n>=a&&n<=b;}
   function insertAndMatch(bar,card) {
    var index=-1;
    for (var i=0;i<bar.length;i++) {
      if (i+1 === bar.length) { index=i+1; break; }
      if (bar[i].type === card.type && bar[i+1].type !== card.type) { index=i+1; break; }
    }
    bar.splice(index,0,{id:card.id,type:card.type});
    for (var j=0;j<bar.length-2;j++) if (bar[j].type === bar[j+1].type && bar[j].type === bar[j+2].type) return bar.splice(j,3);
    return null;
  }
  // Replay through the FIRST trio, or exactly two exposed trios with an empty hand.
  // No score, timeout or arbitrary single pick authorizes an event. The next
  // trio is recalculated after completion using the newly observed board.
  function validateRoute(s, decision, checkMarker, checkBudget) {
    var two=object(decision)&&decision.proofKind==='two_trios';
    if (!object(decision) || !Array.isArray(decision.sequence) || decision.sequence.length < 1 || decision.sequence.length > 512 ||
        (!two&&decision.proofKind !== 'local_trio') || (decision.missionKey !== undefined && decision.missionKey !== s.missionKey)) return null;
    if(two&&(s.capacity!==7||s.tray.length!==0||decision.sequence.length!==6))return null;
    var removed=new Set(), rawIDs=new Set(),bar=s.tray.map(function(c){return {id:c.id,type:c.type};}), peak=bar.length, firstTrio=null, lastTrio=null;
    for (var i=0;i<decision.sequence.length;i++) {
      if(typeof checkBudget==='function')checkBudget(); var card=s.refs.get(decision.sequence[i]);
      if (!card || card.zone === 'tray' || card.selectable === false || removed.has(card.id) || (i === 0 && !card.available) ||
          (!card.available && !card.blockedBy.length) || card.blockedBy.some(function(v){return !removed.has(v);})) return null;
      if(two&&(['board','reserve'].indexOf(card.zone)<0||card.available!==true||card.masked!==false||card.selectable!==true||
          !card.metadata||card.metadata.specialType!==0||card.blockedBy.length||typeof card.rawID!=='string'||!card.rawID||rawIDs.has(card.rawID)||
          card.type!==s.refs.get(decision.sequence[i<3?0:3]).type))return null;
      rawIDs.add(card.rawID);
      removed.add(card.id); peak=Math.max(peak,bar.length+1);
      if (bar.length+1 > s.capacity) return null;
      lastTrio=insertAndMatch(bar,card);
      if (bar.length >= s.capacity) return null;
      if (two?!!lastTrio!==(i===2||i===5):lastTrio && i !== decision.sequence.length-1) return null;
      if (!firstTrio && lastTrio) firstTrio=lastTrio;
    }
    if (!firstTrio || !lastTrio) return null;
    var left=s.cards.filter(function(c){return !removed.has(c.id);}).concat(bar);
    var trio=firstTrio.map(function(c){return c.id;}), matchedType=firstTrio[0].type;
    if (checkMarker && (decision.matchedType !== matchedType || !Array.isArray(decision.tripleCardIDs) ||
        decision.tripleCardIDs.length !== 3 || new Set(decision.tripleCardIDs).size !== 3 ||
        !trio.every(function(v){return decision.tripleCardIDs.indexOf(v) >= 0;}))) return null;
    return {proofKind:decision.proofKind,sequence:decision.sequence.slice(),tripleCardIDs:trio,matchedType:matchedType,
      peakTrayCount:two?6:peak,residualCards:left.length,fastBatch:decision.fastBatch===true,missionKey:decision.missionKey,missionStatus:decision.missionStatus};
  }

 function healthy(s){
  var p=s&&s.playState,store=p&&p.store,d=s&&s.phaseSnapshot;
  return !!p&&d&&d.complete===true&&d.rules&&d.rules.allRecognized===true&&
   window.cc===s.cc&&s.cc.director.getScene()===s.root&&document.visibilityState==='visible'&&
   own(store,'uid')===p.uid&&own(store,'rid')===p.rid&&own(store,'start_time')===p.start&&
   own(store,'state')===2&&own(store,'isWatcher')===false&&own(store,'isHotTiming')===false&&
   own(store,'isAddingCommonBlock')===false&&own(store,'isUsingPenetrateProp')===false&&own(store,'isCanTouchBlock')===true;
 }
 function binding(s){var p=s.playState;return [window,document,own(window,'__require'),s.cc,s.root,s.board,s.trayNode,p.store,p.layer,p.uid,p.rid,p.start];}
 function same(a,b){return a.length===b.length&&a.every(function(v,i){return v===b[i];});}
 function core(s){return s.cards.map(function(c){return [c.metadata.rawID,c.type,c.zone];}).sort(function(a,b){return a[0]<b[0]?-1:1;});}
 function bar(s){return s.tray.map(function(c){return {id:c.metadata.rawID,type:c.type};});}
 function rows(s,api){
  var store=s.playState.store,common=own(store,'common_blocks'),owner=own(s.playState.layer,'CommonStore'),items=owner&&own(owner,'itemsNode'),nodes=items&&items.children,slots=s.phaseSnapshot.sharedSlots;
  if(!Array.isArray(common)||common.length!==3||!owner||owner.isValid!==true||s.cc.js.getClassName(owner)!=='CommonStore'||
   !s.records.has(owner.node)||!Array.isArray(nodes)||nodes.length!==3||!Array.isArray(slots)||slots.length!==3)return [];
  var out=[];
  for(var i=0;i<3;i++){
   var n=nodes[i],slot=slots[i],row=common[i];if(!n||!row||!slot||slot.index!==i||slot.empty!==false||slot.isSelf!==false||!slot.card||slot.card.specialType!==0)continue;
   var parts=n.getComponents(s.cc.Component);if(!Array.isArray(parts)||parts.length>32)return [];
   var matches=parts.filter(function(c){return s.cc.js.getClassName(c)==='CommonStoreItem';});if(matches.length!==1)return [];
   var item=matches[0],info=own(row,'block');
   if(item.isValid!==true||item.node!==n||own(item,'commonStore')!==owner||own(item,'commonBlock')!==row||own(item,'isSelf')!==false||own(item,'isEmpty')!==false||
    !integer(own(row,'lock_state'),0,3)||!info||own(info,'state')!==3||!integer(own(info,'type'),0,10000)||typeof own(info,'id')!=='string'||!own(info,'id')||own(info,'id').length>128)continue;
   var special=own(info,'special_info');if(special&&own(special,'type')!==0)continue;
   var children=n.children;if(!Array.isArray(children)||children.length>32)return [];
   var found=[];children.forEach(function(child){if(!child||!s.records.has(child))return;var cs=child.getComponents(s.cc.Component);
    if(!Array.isArray(cs)||cs.length>32)throw Error('components');cs.forEach(function(c){if(s.cc.js.getClassName(c)==='Block')found.push(c);});});
   if(found.length!==1)continue;var block=found[0],node=block.node;
   if(block.isValid!==true||own(block,'blockInfo')!==info||own(block,'canTouch')!==true||own(block,'isTouched')!==false||node.parent!==n||
    !api.parked(node,s.cc,s.root,s.emitter,s.records,s.gameLayer))continue;
   var layout=api.layout(node,s.cc),type='type:'+own(info,'type');
   if(layout.block!==block||layout.mask.activeInHierarchy===true||slot.card.type!==type)continue;
   var control=api.action({node:node},s.cc,s.emitter,s.records,true);if(control.receiver!==block)continue;
   var candidate={id:'sdktools_supply_'+i,type:type,zone:'reserve',available:true,selectable:true,blockedBy:[],index:i,node:node,block:block,info:info,rawID:own(info,'id'),control:control};
   out.push(candidate);
  }
  return out;
 }
 function status(name,why,dispatched){reason=why;return {status:name,reason:why,dispatched:dispatched===true};}
 function diagnostic(){return {version:1,phase:phase,progressPercent:progress,available:available,pending:!!job,confirmed:confirmed,reason:reason,serverConfirmed:false};}
 function freeze(){if(job){job.stable=null;job.replacement=null;}}
 function observe(s,options,now){
  try{
   var p=s&&s.phaseSnapshot&&s.phaseSnapshot.progressPercent;
   progress=typeof p==='number'&&isFinite(p)&&p>=0&&p<=100?p:null;
   if(!job){phase=progress!==null&&progress>=75||s.cards.length<=36?'assist':'rush';reason='ready';return null;}
   if(!healthy(s)){freeze();return status('waiting_confirmation','cooperative_pending');}
   // Reference refreshes in the same round cannot authorize another pickup.
   if(!same(job.binding.slice(-3),binding(s).slice(-3))){
    if(!job.replacement||!same(job.replacement.binding,binding(s))){job.replacement={binding:binding(s),at:now};return status('waiting_confirmation','cooperative_pending');}
    if(now-job.replacement.at<80)return status('waiting_confirmation','cooperative_pending');
    job=null;return status('watching','cooperative_context_changed');
   }
   job.replacement=null;
   var slot=s.phaseSnapshot.sharedSlots[job.index],valid=slot&&slot.empty===true&&JSON.stringify(core(s))===job.core&&JSON.stringify(bar(s))===job.expected;
   if(valid){
    if(!job.stable||job.stable.signature!==s.signature||!same(job.stable.binding,binding(s))){job.stable={signature:s.signature,binding:binding(s),at:now};return status('waiting_confirmation','cooperative_pending');}
    if(now-job.stable.at<80)return status('waiting_confirmation','cooperative_pending');
    job=null;confirmed=Math.min(10000,confirmed+1);return status('move_confirmed','cooperative_confirmed');
   }
   job.stable=null;return status(now-job.at>8000?'dispatch_uncertain':'waiting_confirmation',now-job.at>8000?'cooperative_uncertain':'cooperative_pending');
  }catch(_){freeze();return job?status('waiting_confirmation','cooperative_pending'):null;}
 }
 function begin(s,options,api,now){
  if(job)return status('waiting_confirmation','cooperative_pending');
  if(!options||options.cooperativePlanning!==true||options.allowAction!==true)return null;
  try{
   if(!healthy(s))return null;
   var supplies=rows(s,api);available=supplies.length;phase='waiting_supply';reason='waiting_supply';if(!supplies.length)return null;
   var clean=s.cards.map(function(c){return {id:c.id,type:c.type,zone:c.zone,blockedBy:c.blockedBy.slice(),available:c.available,selectable:c.selectable,order:c.order};});
   var temporary={cards:clean.concat(supplies),tray:s.tray,refs:new Map(),capacity:7,missionKey:s.missionKey};
   temporary.cards.concat(s.tray).forEach(function(c){temporary.refs.set(c.id,c);});
   var input={cards:temporary.cards.map(function(c){return {id:c.id,type:c.type,zone:c.zone,blockedBy:c.blockedBy,available:c.available,selectable:c.selectable};}),
    tray:s.tray.map(function(c){return {id:c.id,type:c.type};}),capacity:7,matchSize:3,budgetMs:6,stateKey:s.signature+'|supply'};
   var decision=plan(input);if(decision.status==='searching')return status('planning','cooperative_search');
   if(decision.status!=='move'||!validateRoute(temporary,decision,true,api.budget))return null;
   var selected=null;
   for(var k=0;k<decision.sequence.length&&!selected;k++){
    var candidate=supplies.find(function(c){return c.id===decision.sequence[k];});if(!candidate)continue;
    var path=[candidate.id].concat(decision.sequence.filter(function(id){return id!==candidate.id;}));
    for(var length=1;length<=path.length;length++){
     var proof=validateRoute(temporary,{proofKind:'local_trio',sequence:path.slice(0,length)},false,api.budget);
     if(proof&&proof.tripleCardIDs.indexOf(candidate.id)>=0){selected=candidate;break;}
    }
   }
   if(!selected||!api.ready(s)||!healthy(s))return null;
   var live=rows(s,api).find(function(c){return c.index===selected.index&&c.node===selected.node&&c.info===selected.info&&c.rawID===selected.rawID&&c.type===selected.type;});
   if(!live)return null;
   var event=api.input(s.cc,live.control.button);
   if(!api.ready(s)||!healthy(s)||!rows(s,api).some(function(c){return c.index===live.index&&c.node===live.node&&c.info===live.info&&c.rawID===live.rawID&&c.type===live.type;}))return null;
   var expected=bar(s);insertAndMatch(expected,{id:live.rawID,type:live.type});
   if(expected.length>=7)return null;api.budget();
   job={binding:binding(s),index:live.index,core:JSON.stringify(core(s)),expected:JSON.stringify(expected),at:now,stable:null,replacement:null};phase='assist';
   try{s.emitter.call(live.control.event,[event]);}catch(_){return status('dispatch_uncertain','cooperative_uncertain',true);}
   return status('original_event_dispatched','cooperative_requested',true);
  }catch(_){return null;}
 }
 return Object.freeze({insertAndMatch:insertAndMatch,validateRoute:validateRoute,begin:begin,observe:observe,busy:function(){return !!job;},freeze:freeze,diagnostic:diagnostic});
})

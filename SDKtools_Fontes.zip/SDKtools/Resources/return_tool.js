/* SDKtools V2.4: factory expression returning one explicit action.
 * Opens the original Retornar popup through its registered Cocos click event.
 * It never confirms the popup, edits a piece, changes inventory or retries.
 * The fingerprint is limited to the observed WePlay US / Cocos 2.4.4 scene.
 * Atlas coordinates are deliberately excluded: dynamic atlases move sprites.
 * Native code must scope the WebView and reject overlapping requests.
 */
(function () {
  'use strict';
  var LIMITS = { nodes: 4096, children: 512, depth: 24, components: 32, budgetMs: 10 };
  function object(value) { return value !== null && (typeof value === 'object' || typeof value === 'function'); }
  function tag(value) {
    if (typeof value !== 'string') return null;
    var hash = 2166136261, text = value.slice(0, 128);
    for (var i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return ('00000000' + (hash >>> 0).toString(16)).slice(-8);
  }
  return function openOriginalReturn() {
    var visited = 0, began = 0, dispatchStarted = false, rejection = null;
    function clock() {
      var value = typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now();
      if (typeof value !== 'number' || !isFinite(value)) throw Error('clock');
      return value;
    }
    function abort(reason) { rejection = reason; throw Error('guard'); }
    function budget() { if (clock() - began >= LIMITS.budgetMs) abort('time_budget'); }
    function output(status, reason) {
      var elapsed = 0;
      try { elapsed = Math.max(0, Math.round((clock() - began) * 1000) / 1000); } catch (_) {}
      return { version: 1, status: status, reason: reason,
        dispatched: status === 'original_event_dispatched' ? true : status === 'dispatch_uncertain' ? null : false,
        popupConfirmationRequired: status !== 'no_action',
        stats: { visitedNodes: visited, elapsedMs: elapsed } };
    }
    function size(node, width, height) { return node.width === width && node.height === height; }
    function engineVersion(engine) {
      // Web-mobile exports may expose the version through CocosEngine rather
      // than cc.ENGINE_VERSION. This matches the recorder's public fallback,
      // with an extra rejection when two exposed version strings disagree.
      var primary = engine.ENGINE_VERSION, fallback = window.CocosEngine;
      if (typeof primary === 'string' && typeof fallback === 'string' && primary !== fallback) return null;
      return typeof primary === 'string' ? primary : fallback;
    }
    function visible(node, structuralRoot) {
      return object(node) && node.isValid === true && node.activeInHierarchy === true &&
        (structuralRoot || node.active === true) && typeof node.opacity === 'number' && node.opacity > 0 && node.opacity <= 255;
    }
    function children(node) {
      var value = node.children;
      if (!Array.isArray(value)) abort('invalid_scene');
      if (value.length > LIMITS.children) abort('scan_limit');
      return value;
    }
    function fingerprint(row, engine) {
      if (!size(row, 292, 90)) return null;
      var items = children(row);
      if (items.length !== 3) return null;
      var names = [['8c2cba4f'], ['8b2cb8bc'], ['8d2cbbe2', '882cb403']], xs = [-106, 0, 106];
      var icon = null;
      for (var i = 0; i < 3; i++) {
        budget();
        var item = items[i];
        if (!visible(item, false) || item.parent !== row || !size(item, 80, 90) || item.x !== xs[i] || item.y !== 0) return null;
        var icons = children(item), first = icons[0];
        if (!visible(first, false) || first.parent !== item || !size(first, 80, 90) || typeof first.getComponent !== 'function') return null;
        var sprite = first.getComponent(engine.Sprite);
        if (!object(sprite) || sprite.enabled !== true || sprite.enabledInHierarchy !== true) return null;
        var frame = sprite.spriteFrame;
        if (!object(frame) || names[i].indexOf(tag(frame.name)) < 0 || typeof frame.getRect !== 'function') return null;
        var rect = frame.getRect();
        if (!object(rect) || rect.width !== 120 || rect.height !== 135) return null;
        if (i === 1) icon = first;
      }
      return { row: row, target: items[1], icon: icon };
    }
    function action(candidate, engine, emitter) {
      var target = candidate.target, icon = candidate.icon;
      if (typeof target.getComponents !== 'function') abort('handler_unavailable');
      var components = target.getComponents(engine.Component);
      if (!Array.isArray(components)) abort('handler_unavailable');
      if (components.length > LIMITS.components) abort('scan_limit');
      var props = [];
      for (var i = 0; i < components.length; i++) {
        budget();
        if (engine.js.getClassName(components[i]) === 'Prop') props.push(components[i]);
      }
      if (props.length !== 1) abort('handler_ambiguous');
      var prop = props[0];
      if (prop.isValid !== true || prop.node !== target || typeof prop.onUseProp !== 'function') abort('handler_unavailable');
      var button = icon.getComponent(engine.Button);
      if (!object(button) || button.isValid !== true || button.node !== icon) abort('button_unavailable');
      if (button.enabled !== true || button.enabledInHierarchy !== true || button.interactable !== true) abort('disabled_control');
      var events = button.clickEvents;
      if (!Array.isArray(events) || events.length !== 1) abort('event_mismatch');
      var event = events[0];
      if (!object(event) || !Object.prototype.isPrototypeOf.call(engine.Component.EventHandler.prototype, event) ||
          event.emit !== emitter || event.target !== target || event.handler !== 'onUseProp' || event.customEventData !== '') abort('event_mismatch');
      // The saved component identifier was redacted by the capture. The
      // original registered emitter performs its own component resolution.
      // Never substitute a direct Prop.onUseProp() call or private-field lookup.
      return { button: button, event: event, prop: prop };
    }
    try {
      began = clock();
      if (typeof window !== 'object' || !window || (window.top && window.top !== window)) abort('context_unavailable');
      if (typeof document !== 'object' || !document || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('document_unavailable');
      var engine = window.cc;
      if (!object(engine) || engineVersion(engine) !== '2.4.4') abort('engine_version');
      var director = engine.director, Component = engine.Component;
      if (!object(director) || typeof director.getScene !== 'function' || !engine.Sprite || !engine.Button ||
          !Component || !Component.EventHandler || !Component.EventHandler.prototype ||
          !object(engine.js) || typeof engine.js.getClassName !== 'function') abort('context_unavailable');
      var emitter = Component.EventHandler.prototype.emit;
      if (typeof emitter !== 'function') abort('event_unavailable');
      var root = director.getScene();
      if (!visible(root, true)) abort('context_unavailable');
      var stack = [{ node: root, depth: 0, parent: null }], seen = new Set(), records = new Map(), candidates = [], modalVisible = false;
      while (stack.length) {
        budget();
        var entry = stack.pop(), node = entry.node;
        if (++visited > LIMITS.nodes || entry.depth > LIMITS.depth || stack.length > LIMITS.nodes) abort('scan_limit');
        if (!object(node) || seen.has(node)) abort('invalid_scene');
        seen.add(node);
        if (entry.parent && node.parent !== entry.parent) abort('invalid_scene');
        if (!visible(node, node === root)) continue;
        records.set(node, entry.parent);
        if (size(node, 240, 102)) modalVisible = true;
        var candidate = fingerprint(node, engine);
        if (candidate) candidates.push(candidate);
        var descendants = children(node);
        if (stack.length + descendants.length > LIMITS.nodes) abort('scan_limit');
        for (var c = descendants.length - 1; c >= 0; c--) stack.push({ node: descendants[c], parent: node, depth: entry.depth + 1 });
      }
      if (modalVisible) abort('modal_visible');
      if (!candidates.length) abort('fingerprint_mismatch');
      if (candidates.length !== 1) abort('ambiguous_control');
      var selected = candidates[0], resolved = action(selected, engine, emitter);
      budget();
      // Revalidate the same live path and the registered event just before the
      // one allowed dispatch. No cached node IDs survive this invocation.
      if (window.cc !== engine || engine.director !== director || director.getScene() !== root ||
          engineVersion(engine) !== '2.4.4' || Component.EventHandler.prototype.emit !== emitter || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('context_changed');
      var cursor = selected.row, pathLength = 0;
      while (cursor) {
        budget();
        if (++pathLength > LIMITS.depth + 1 || !records.has(cursor) || !visible(cursor, cursor === root)) abort('context_changed');
        var expected = records.get(cursor);
        if (expected && cursor.parent !== expected) abort('context_changed');
        cursor = expected;
      }
      var fresh = fingerprint(selected.row, engine);
      if (!fresh || fresh.target !== selected.target || fresh.icon !== selected.icon) abort('context_changed');
      var current = action(fresh, engine, emitter);
      if (current.button !== resolved.button || current.event !== resolved.event || current.prop !== resolved.prop) abort('context_changed');
      budget();
      dispatchStarted = true;
      emitter.call(current.event, [current.button]);
      return output('original_event_dispatched', 'confirm_in_original_popup');
    } catch (_) {
      // A throwing original event might already have changed state. The native
      // caller must not resend automatically and must show the uncertain state.
      return output(dispatchStarted ? 'dispatch_uncertain' : 'no_action', dispatchStarted ? 'event_exception' : rejection || 'read_error');
    }
  };
})()

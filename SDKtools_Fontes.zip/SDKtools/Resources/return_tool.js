/* SDKtools V2.7: factory expression returning one explicit power action.
 * open(left|center|right) invokes the original Prop event. confirm requires a
 * separate explicit request and the live UsePropAlert's enabled original button.
 * Never edits pieces/inventory, executes captured source or retries an event.
 * A successful dispatch is a request, not proof of consumption or board effect.
 * The fingerprint is limited to the observed WePlay US / Cocos 2.4.4 scene.
 * Atlas coordinates are deliberately excluded: dynamic atlases move sprites.
 * Native code must scope the WebView and reject overlapping requests.
 */
(function () {
  'use strict';
  var LIMITS = { nodes: 4096, children: 512, depth: 24, components: 32, budgetMs: 18 };
  function object(value) { return value !== null && (typeof value === 'object' || typeof value === 'function'); }
  function tag(value) {
    if (typeof value !== 'string') return null;
    var hash = 2166136261, text = value.slice(0, 128);
    for (var i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return ('00000000' + (hash >>> 0).toString(16)).slice(-8);
  }
  return function originalPower(options) {
    var command = 'open', slot = 'center', slotIndex = 1;
    var visited = 0, began = 0, dispatchStarted = false, rejection = null;
    function clock() {
      var value = typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now();
      if (typeof value !== 'number' || !isFinite(value)) throw Error('clock');
      return value;
    }
    function abort(reason) { rejection = reason; throw Error('guard'); }
    function budget() { if (clock() - began >= LIMITS.budgetMs) abort('time_budget'); }
    function output(status, reason) {
      var elapsed = 0;
      try { elapsed = Math.max(0, Math.round((clock() - began) * 1000) / 1000); } catch (_) {}
      return { version: 1, status: status, reason: reason,
        dispatched: status === 'original_event_dispatched' ? true : status === 'dispatch_uncertain' ? null : false,
        command: command, slot: slot,
        popupConfirmationRequired: command === 'open' && status !== 'no_action',
        effectConfirmed: false, consumptionManagedByOriginal: true,
        stats: { visitedNodes: visited, elapsedMs: elapsed } };
    }
    function size(node, width, height) { return node.width === width && node.height === height; }
    function engineVersion(engine) {
      // Web-mobile exports may expose the version through CocosEngine rather
      // than cc.ENGINE_VERSION. This matches the recorder's public fallback,
      // with an extra rejection when two exposed version strings disagree.
      var primary = engine.ENGINE_VERSION, fallback = window.CocosEngine;
      if (typeof primary === 'string' && typeof fallback === 'string' && primary !== fallback) return null;
      return typeof primary === 'string' ? primary : fallback;
    }
    function visible(node, structuralRoot) {
      return object(node) && node.isValid === true && node.activeInHierarchy === true &&
        (structuralRoot || node.active === true) && typeof node.opacity === 'number' && node.opacity > 0 && node.opacity <= 255;
    }
    function children(node) {
      var value = node.children;
      if (!Array.isArray(value)) abort('invalid_scene');
      if (value.length > LIMITS.children) abort('scan_limit');
      return value;
    }
    function fingerprint(row, engine) {
      if (!size(row, 292, 90)) return null;
      var items = children(row);
      if (items.length !== 3) return null;
      var names = [['8c2cba4f'], ['8b2cb8bc', '8e2cbd75'], ['8d2cbbe2', '882cb403', '8e2cbd75']], xs = [-106, 0, 106];
      var icon = null, observedTags = [];
      for (var i = 0; i < 3; i++) {
        budget();
        var item = items[i];
        if (!visible(item, false) || item.parent !== row || !size(item, 80, 90) || item.x !== xs[i] || item.y !== 0) return null;
        var icons = children(item), first = icons[0];
        if (!visible(first, false) || first.parent !== item || !size(first, 80, 90) || typeof first.getComponent !== 'function') return null;
        var sprite = first.getComponent(engine.Sprite);
        if (!object(sprite) || sprite.enabled !== true || sprite.enabledInHierarchy !== true) return null;
        var frame = sprite.spriteFrame;
        if (!object(frame) || names[i].indexOf(tag(frame.name)) < 0 || typeof frame.getRect !== 'function') return null;
        var rect = frame.getRect();
        if (!object(rect) || rect.width !== 120 || rect.height !== 135) return null;
        observedTags.push(tag(frame.name));
        if (i === slotIndex) icon = first;
      }
      // Full observed loadouts. Slots vary across matches: the refresh icon can
      // be central or right. Never infer a fixed power from its position alone.
      var signature = observedTags.join('/');
      if (['8c2cba4f/8b2cb8bc/8d2cbbe2', '8c2cba4f/8b2cb8bc/882cb403',
           '8c2cba4f/8e2cbd75/882cb403', '8c2cba4f/8b2cb8bc/8e2cbd75'].indexOf(signature) < 0) return null;
      return { row: row, target: items[slotIndex], icon: icon };
    }
    function action(candidate, engine, emitter) {
      var target = candidate.target, icon = candidate.icon;
      if (typeof target.getComponents !== 'function') abort('handler_unavailable');
      var components = target.getComponents(engine.Component);
      if (!Array.isArray(components)) abort('handler_unavailable');
      if (components.length > LIMITS.components) abort('scan_limit');
      var props = [];
      for (var i = 0; i < components.length; i++) {
        budget();
        if (engine.js.getClassName(components[i]) === 'Prop') props.push(components[i]);
      }
      if (props.length !== 1) abort('handler_ambiguous');
      var prop = props[0];
      if (prop.isValid !== true || prop.node !== target || typeof prop.onUseProp !== 'function' || prop.onUseProp.length !== 0) abort('handler_unavailable');
      var button = icon.getComponent(engine.Button);
      if (!object(button) || button.isValid !== true || button.node !== icon) abort('button_unavailable');
      if (button.enabled !== true || button.enabledInHierarchy !== true || button.interactable !== true) abort('disabled_control');
      var events = button.clickEvents;
      if (!Array.isArray(events) || events.length !== 1) abort('event_mismatch');
      var event = events[0];
      if (!object(event) || !Object.prototype.isPrototypeOf.call(engine.Component.EventHandler.prototype, event) ||
          event.emit !== emitter || event.target !== target || event.handler !== 'onUseProp' || event.customEventData !== '') abort('event_mismatch');
      // The saved component identifier was redacted by the capture. The
      // original registered emitter performs its own component resolution.
      // Never substitute a direct Prop.onUseProp() call or private-field lookup.
      return { button: button, event: event, prop: prop };
    }
    function stock(info) {
      if (!object(info) || typeof info.count !== 'number' || !isFinite(info.count) ||
          info.count < 0 || info.count > 1000000 || Math.floor(info.count) !== info.count) abort('stock_unavailable');
      if (info.count === 0) abort('stock_empty');
      function identity(value) { return (typeof value === 'number' && isFinite(value) && value >= 0 &&
        Math.floor(value) === value && value <= 9007199254740991) ||
        (typeof value === 'string' && value.length > 0 && value.length <= 128 && /^[a-zA-Z0-9_-]+$/.test(value)); }
      if (!identity(info.id) || !identity(info.type)) abort('stock_unavailable');
      return {info: info, count: info.count, id: info.id, type: info.type};
    }
    function confirmation(node, engine, emitter, records) {
      if (!size(node, 240, 102) || typeof node.getComponent !== 'function') return null;
      var button = node.getComponent(engine.Button);
      if (!object(button)) return null;
      var events = button.clickEvents;
      if (!Array.isArray(events) || events.length !== 1 || !object(events[0]) || events[0].handler !== 'onBtnUseClick') return null;
      var event = events[0], target = event.target;
      if (!object(target) || !records.has(target) || typeof target.getComponents !== 'function') abort('event_mismatch');
      var cursor = node, depth = 0;
      while (cursor && cursor !== target && ++depth <= LIMITS.depth) cursor = records.get(cursor);
      if (cursor !== target) abort('event_mismatch');
      var components = target.getComponents(engine.Component);
      if (!Array.isArray(components)) abort('handler_unavailable');
      if (components.length > LIMITS.components) abort('scan_limit');
      var matches = [];
      for (var i = 0; i < components.length; i++) {
        budget();
        if (engine.js.getClassName(components[i]) === 'UsePropAlert') matches.push(components[i]);
      }
      if (matches.length !== 1) abort('handler_ambiguous');
      var receiver = matches[0];
      if (!object(receiver) || receiver.isValid !== true || receiver.node !== target ||
          typeof receiver.onBtnUseClick !== 'function' || receiver.onBtnUseClick.length !== 0 || receiver.useButton !== button) abort('handler_unavailable');
      if (button.isValid !== true || button.node !== node) abort('button_unavailable');
      if (button.enabled !== true || button.enabledInHierarchy !== true || button.interactable !== true) abort('disabled_control');
      if (!Object.prototype.isPrototypeOf.call(engine.Component.EventHandler.prototype, event) ||
          event.emit !== emitter || event.customEventData !== '') abort('event_mismatch');
      // setup(e) and onBtnUseClick were captured in the V2.6 report. Inspect the
      // live receiver's propInfo; never reconstruct or invoke captured source.
      return {node: node, target: target, button: button, event: event, receiver: receiver, stock: stock(receiver.propInfo)};
    }
    try {
      began = clock();
      if (options !== undefined) {
        if (!object(options) || Array.isArray(options)) abort('invalid_options');
        if (options.command !== undefined) command = options.command;
        if (options.slot !== undefined) slot = options.slot;
      }
      if ((command !== 'open' && command !== 'confirm') || ['left', 'center', 'right', 'current'].indexOf(slot) < 0 ||
          (command === 'open' && slot === 'current')) { command = 'open'; slot = 'center'; abort('invalid_options'); }
      slotIndex = slot === 'left' ? 0 : slot === 'right' ? 2 : 1;
      if (typeof window !== 'object' || !window || (window.top && window.top !== window)) abort('context_unavailable');
      if (typeof document !== 'object' || !document || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('document_unavailable');
      var engine = window.cc;
      if (!object(engine) || engineVersion(engine) !== '2.4.4') abort('engine_version');
      var director = engine.director, Component = engine.Component;
      if (!object(director) || typeof director.getScene !== 'function' || !engine.Sprite || !engine.Button ||
          !Component || !Component.EventHandler || !Component.EventHandler.prototype ||
          !object(engine.js) || typeof engine.js.getClassName !== 'function') abort('context_unavailable');
      var emitter = Component.EventHandler.prototype.emit;
      if (typeof emitter !== 'function') abort('event_unavailable');
      var root = director.getScene();
      if (!visible(root, true)) abort('context_unavailable');
      var stack = [{ node: root, depth: 0, parent: null }], seen = new Set(), records = new Map(), candidates = [], modalNodes = [];
      while (stack.length) {
        budget();
        var entry = stack.pop(), node = entry.node;
        if (++visited > LIMITS.nodes || entry.depth > LIMITS.depth || stack.length > LIMITS.nodes) abort('scan_limit');
        if (!object(node) || seen.has(node)) abort('invalid_scene');
        seen.add(node);
        if (entry.parent && node.parent !== entry.parent) abort('invalid_scene');
        if (!visible(node, node === root)) continue;
        records.set(node, entry.parent);
        if (size(node, 240, 102)) modalNodes.push(node);
        var candidate = fingerprint(node, engine);
        if (candidate) candidates.push(candidate);
        var descendants = children(node);
        if (stack.length + descendants.length > LIMITS.nodes) abort('scan_limit');
        for (var c = descendants.length - 1; c >= 0; c--) stack.push({ node: descendants[c], parent: node, depth: entry.depth + 1 });
      }
      if (command === 'open' && modalNodes.length) abort('modal_visible');
      if (!candidates.length) abort('fingerprint_mismatch');
      if (candidates.length !== 1) abort('ambiguous_control');
      var selected = candidates[0], resolved, popup = null;
      if (command === 'open') resolved = action(selected, engine, emitter);
      else {
        var confirmations = [];
        for (var m = 0; m < modalNodes.length; m++) {
          budget(); var found = confirmation(modalNodes[m], engine, emitter, records);
          if (found) confirmations.push(found);
        }
        if (!confirmations.length) abort('confirmation_unavailable');
        if (confirmations.length !== 1) abort('confirmation_ambiguous');
        popup = confirmations[0]; resolved = popup;
        if (slot !== 'current') {
          var selectedProp = action(selected, engine, emitter).prop, selectedStock = stock(selectedProp.propInfo);
          if (selectedStock.id !== popup.stock.id || selectedStock.type !== popup.stock.type) abort('prop_mismatch');
        }
      }
      budget();
      // Revalidate the live path, event and stock immediately before one send.
      if (window.cc !== engine || engine.director !== director || director.getScene() !== root ||
          engineVersion(engine) !== '2.4.4' || Component.EventHandler.prototype.emit !== emitter || document.visibilityState !== 'visible' ||
          (document.readyState !== 'complete' && document.readyState !== 'interactive')) abort('context_changed');
      function verifyPath(start) {
        var cursor = start, pathLength = 0;
        while (cursor) {
          budget();
          if (++pathLength > LIMITS.depth + 1 || !records.has(cursor) || !visible(cursor, cursor === root)) abort('context_changed');
          var expected = records.get(cursor);
          if (expected && cursor.parent !== expected) abort('context_changed');
          cursor = expected;
        }
      }
      verifyPath(selected.row);
      var fresh = fingerprint(selected.row, engine);
      if (!fresh || fresh.target !== selected.target || fresh.icon !== selected.icon) abort('context_changed');
      var current;
      if (command === 'open') {
        current = action(fresh, engine, emitter);
        if (current.button !== resolved.button || current.event !== resolved.event || current.prop !== resolved.prop) abort('context_changed');
      } else {
        verifyPath(popup.node);
        current = confirmation(popup.node, engine, emitter, records);
        if (!current || current.button !== popup.button || current.event !== popup.event || current.receiver !== popup.receiver ||
            current.stock.info !== popup.stock.info || current.stock.count !== popup.stock.count ||
            current.stock.id !== popup.stock.id || current.stock.type !== popup.stock.type) abort('context_changed');
        if (slot !== 'current') {
          var freshStock = stock(action(fresh, engine, emitter).prop.propInfo);
          if (freshStock.id !== current.stock.id || freshStock.type !== current.stock.type) abort('prop_mismatch');
        }
      }
      budget(); dispatchStarted = true;
      // Both captured handlers are zero-argument methods. Button.clickEvents
      // normally receives EventTouch, not Button. No touch is needed by these
      // verified callbacks; pass no fabricated event object.
      emitter.call(current.event, []);
      return output('original_event_dispatched', command === 'open' ? 'confirm_in_original_popup' : 'original_power_requested');
    } catch (_) {
      // A throwing original event might already have changed state. The native
      // caller must not resend automatically and must show the uncertain state.
      return output(dispatchStarted ? 'dispatch_uncertain' : 'no_action', dispatchStarted ? 'event_exception' : rejection || 'read_error');
    }
  };
})()

/* SDKtools 3.19.9: explicit ONE-ATTEMPT own-slot lock experiment.
 * The lock is zero only during the original warehouse-opening callback and
 * restored before the user selects a card. No forged packets or direct sends.
 * A temporary observer correlates ONE original ChooseCommonBlock call with an
 * unmodified outgoing envelope and the matching incoming response header.
 * 200 is a protocol acknowledgement, NOT proof of permanent unlock.
 */
(function (openWarehouse) {
  'use strict';
  var job=null;
  function object(x){return x!==null&&(typeof x==='object'||typeof x==='function');}
  function own(x,k){if(!object(x))return undefined;var d=Object.getOwnPropertyDescriptor(x,k);if(d&&!Object.prototype.hasOwnProperty.call(d,'value'))throw Error('accessor');return d?d.value:undefined;}
  function int(x,a,b){return typeof x==='number'&&isFinite(x)&&Math.floor(x)===x&&x>=a&&x<=b;}
  function method(x,k){var p=x;for(var i=0;p&&i<8;i++,p=Object.getPrototypeOf(p)){var d=Object.getOwnPropertyDescriptor(p,k);if(d){if(!('value'in d)||typeof d.value!=='function')throw Error('method');return d.value;}}throw Error('method');}
  function snapshot(){
    var start=Date.now(),reject='context_unavailable';
    function fail(r){reject=r;throw Error(r);}
    try {
      if(typeof window!=='object'||!window||window.top&&window.top!==window)fail('context_unavailable');
      if(typeof document!=='object'||document.visibilityState!=='visible')fail('document_unavailable');
      var cc=own(window,'cc');if(!cc||cc.ENGINE_VERSION!=='2.4.4'||typeof window.CocosEngine==='string'&&window.CocosEngine!=='2.4.4')fail('engine_version');
      if(!cc.director||typeof cc.director.getScene!=='function'||!cc.js||typeof cc.js.getClassName!=='function'||!cc.Component)fail('context_unavailable');
      var root=cc.director.getScene(),todo=[{n:root,p:null,d:0}],seen=new Set(),records=new Map(),games=[];
      while(todo.length){
        if(Date.now()-start>=18)fail('time_budget');var e=todo.pop(),n=e.n;
        if(!object(n)||seen.has(n)||e.p&&n.parent!==e.p)fail('invalid_scene');seen.add(n);
        if(seen.size>4096||e.d>24)fail('scan_limit');
        if(n.isValid!==true||n.activeInHierarchy!==true||n!==root&&n.active!==true)continue;records.set(n,e.p);
        if(typeof n.getComponents==='function'){var cs=n.getComponents(cc.Component);if(!Array.isArray(cs)||cs.length>32)fail('scan_limit');cs.forEach(function(c){if(cc.js.getClassName(c)==='Game')games.push(c);});}
        var children=n.children;if(!Array.isArray(children)||children.length>512)fail('invalid_scene');
        for(var i=children.length-1;i>=0;i--)todo.push({n:children[i],p:n,d:e.d+1});
      }
      if(games.length!==1)fail('game_ambiguous');
      var game=games[0],layer=own(game,'GameLayer'),store=own(layer,'CommonStore');
      function bound(c,name){return c&&c.isValid===true&&records.has(c.node)&&cc.js.getClassName(c)===name;}
      function inside(n,parent){for(var d=0;n&&d<=24;d++,n=records.get(n))if(n===parent)return true;return false;}
      if(!bound(game,'Game')||!bound(layer,'GameLayer')||!bound(store,'CommonStore')||!inside(layer.node,game.node)||!inside(store.node,layer.node))fail('store_unavailable');
      var items=own(store,'itemsNode'),index=own(store,'selfIndex'),slots=items&&items.children;
      if(!records.has(items)||!inside(items,store.node)||!Array.isArray(slots)||slots.length<2||slots.length>3||!int(index,0,slots.length-1))fail('owner_unavailable');
      var self=[];
      slots.forEach(function(n,i){var a=n.getComponents(cc.Component);if(!Array.isArray(a)||a.length>32)fail('scan_limit');var found=a.filter(function(c){return cc.js.getClassName(c)==='CommonStoreItem';});if(found.length!==1)fail('slot_unavailable');if(own(found[0],'isSelf')===true)self.push({item:found[0],index:i});});
      if(self.length!==1||self[0].index!==index)fail('owner_ambiguous');var item=self[0].item;
      if(!bound(item,'CommonStoreItem')||own(item,'commonStore')!==store||item.node!==slots[index])fail('owner_unavailable');
      var loader=own(window,'__require');if(typeof loader!=='function')fail('module_unavailable');
      var gs=own(loader('GameStore'),'default'),socket=own(loader('Socket'),'default');
      var round=own(gs,'start_time'),rid=own(socket,'rid'),currentWS=own(socket,'socket');
      if(!((int(round,1,9007199254740991))||(typeof round==='string'&&/^[1-9][0-9]{0,15}$/.test(round))) || !((typeof rid==='string'&&rid.length>0&&rid.length<=128)||int(rid,1,9007199254740991)))fail('round_unavailable');
      if(own(gs,'isWatcher')!==false||own(gs,'mode')!==0||own(gs,'state')!==2)fail('unsupported_mode');
      if(own(gs,'isHotTiming')!==false||own(gs,'isUsingPenetrateProp')!==false)fail('external_mode_active');
      var rows=own(gs,'common_blocks'),row=own(item,'commonBlock');
      if(!Array.isArray(rows)||rows.length<2||rows.length>3||rows[index]!==row||!object(row))fail('awaiting_setup');
      var lock=own(row,'lock_state'),empty=own(item,'isEmpty'),card=own(row,'block'),cardID=own(card,'id');
      if(!int(lock,0,3)||typeof empty!=='boolean'||empty!==(card==null||cardID===''))fail('invalid_slot_state');
      return {ws:currentWS,round:round,rid:rid,cc:cc,root:root,layer:layer,store:store,item:item,row:row,gs:gs,socket:socket,index:index,lock:lock,empty:empty,cardID:cardID,records:records};
    }catch(_){return {error:reject};}
  }
  function shadow(owner,key,wrapped){
    var before=Object.getOwnPropertyDescriptor(owner,key),base=method(owner,key);
    if(before&&(!('value'in before)||!before.writable))throw Error('not writable');
    if(!before&&!Object.isExtensible(owner))throw Error('not extensible');
    Object.defineProperty(owner,key,before?Object.assign({},before,{value:wrapped}):{value:wrapped,configurable:true,writable:true,enumerable:false});
    return {base:base,undo:function(){var now=Object.getOwnPropertyDescriptor(owner,key);if(!now||now.value!==wrapped)return false;if(before)Object.defineProperty(owner,key,before);else delete owner[key];return true;}};
  }
  function sameContext(s,j){return !s.error&&s.root===j.root&&s.store===j.store&&s.gs===j.gs&&s.socket===j.socket&&s.ws===j.ws&&s.round===j.round&&s.rid===j.rid;}
  function closeSelection(j){
    try {var s=snapshot();if(sameContext(s,j)&&j.selectionOpened&&own(s.gs,'isAddingCommonBlock')===true&&s.store.coverNode.active===true)j.close.call(s.store);}catch(_){}
  }
  function clean(j,close){
    if(j.timer!==null){clearTimeout(j.timer);j.timer=null;}
    if(j.listener){try{j.ws.removeEventListener('message',j.listener);}catch(_){}j.listener=null;}
    if(j.chooseHook){try{j.hooksRestored=j.chooseHook.undo()&&j.hooksRestored;}catch(_){j.hooksRestored=false;}j.chooseHook=null;}
    j.active=false;if(close&&!j.requestObserved)closeSelection(j);
  }
  function expire(j){if(job!==j||!j.active)return;clean(j,true);j.status=j.requestObserved?'uncertain':'expired';j.reason=j.requestObserved?'response_timeout':'selection_timeout';}
  function lease(j,ms){if(j.timer!==null)clearTimeout(j.timer);j.timer=setTimeout(function(){expire(j);},ms);}
  function outcome(){
    if(!job)return {version:1,command:'warehouse_test',status:'idle',reason:'not_armed',active:false,localWriteApplied:false,localRestored:true,hooksRestored:true,requestObserved:false,responseObserved:false,slotEffectConfirmed:false,testedWhileLocked:false,attemptCount:0};
    var j=job,s=snapshot(),effect=false;
    if(sameContext(s,j)){j.afterLock=s.lock;effect=j.status==='accepted'&&j.serverCode===200&&j.testedWhileLocked&&typeof j.chosenID==='string'&&s.cardID===j.chosenID&&!s.empty;}
    var r={version:1,command:'warehouse_test',status:j.status,reason:j.reason,active:j.active,localWriteApplied:j.localWriteApplied,localRestored:j.localRestored,hooksRestored:j.hooksRestored,
      requestObserved:j.requestObserved,responseObserved:j.serverCode!==null,slotEffectConfirmed:effect,testedWhileLocked:j.testedWhileLocked,attemptCount:j.attemptCount,beforeLock:j.beforeLock};
    if(int(j.afterLock,0,3))r.afterLock=j.afterLock;if(j.serverCode!==null)r.serverCode=j.serverCode;return r;
  }
  function arm(){
    if(job&&(job.active||job.attemptCount>0))return outcome();
    var s=snapshot();if(s.error)return blocked(s.error);
    if(!s.empty)return blocked('own_slot_occupied');if(s.lock===0)return blocked('already_unlocked');
    if(own(s.gs,'isAddingCommonBlock')!==false)return blocked('selection_already_open');
    if(typeof openWarehouse!=='function'||typeof setTimeout!=='function'||typeof clearTimeout!=='function')return blocked('observer_unavailable');
    var lockDesc=Object.getOwnPropertyDescriptor(s.row,'lock_state');
    if(!lockDesc||!('value'in lockDesc)||lockDesc.writable!==true)return blocked('lock_not_writable');
    var ws=own(s.socket,'socket'),packet=own(s.socket,'packetId');
    if(!ws||ws.readyState!==1||typeof ws.addEventListener!=='function'||typeof ws.removeEventListener!=='function'||!int(packet,1,2147483647))return blocked('socket_unavailable');
    var choose,send,close,cards;
    try {choose=method(s.socket,'ChooseCommonBlock');send=method(ws,'send');close=method(s.store,'onCoverClick');
      if(choose.length!==1)throw Error('signature');cards=method(s.layer,'GetCanClickBlocks').call(s.layer);
      if(!Array.isArray(cards)||!cards.length||cards.length>512)throw Error('cards');
    }catch(_){return blocked('observer_unavailable');}
    var eligible=new Map();
    try {cards.forEach(function(c){var info=own(c,'blockInfo'),id=own(info,'id'),state=own(info,'state');
      if(!c||c.isValid!==true||!s.records.has(c.node)||s.cc.js.getClassName(c)!=='Block'||typeof id!=='string'||!id||id.length>128||!int(state,0,2)||eligible.has(id))throw Error('card');eligible.set(id,c);});}catch(_){return blocked('cards_unavailable');}
    var j={status:'armed',reason:'choose_one_card',active:true,round:s.round,rid:s.rid,gs:s.gs,root:s.root,store:s.store,socket:s.socket,ws:ws,close:close,eligible:eligible,
      timer:null,listener:null,chooseHook:null,packet:null,chosenID:null,beforeLock:s.lock,afterLock:s.lock,localWriteApplied:false,localRestored:true,hooksRestored:true,
      requestObserved:false,testedWhileLocked:false,attemptCount:0,serverCode:null,selectionOpened:false};job=j;
    j.listener=function(e){
      if(!j.active||!j.requestObserved||e.isTrusted!==true||e.target!==j.ws||!int(j.packet,1,2147483647)||typeof e.data!=='string'||e.data.length>262144)return;
      var v;try{v=JSON.parse(e.data);}catch(_){return;}
      if(!v||v.packet_id!==j.packet||!int(v.code,0,1000000))return;
      j.serverCode=v.code;
      if(!sameContext(snapshot(),j)){clean(j,false);j.status='uncertain';j.reason='context_changed';return;}
      j.status=j.testedWhileLocked?(v.code===200?'accepted':'rejected'):'uncertain';
      j.reason=!j.testedWhileLocked?'not_a_locked_slot_attempt':v.code===200?'server_200':'server_rejected';clean(j,false);
    };
    var wrapped=function(){
      if(!j.active||j.attemptCount>0||this!==s.socket)return choose.apply(this,arguments);
      var args=arguments,a=args[0],id,now=snapshot(),candidate;
      try{id=own(a,'id');candidate=eligible.get(id);}catch(_){}
      // Observe exactly one manual selection; do not change original arguments,
      // return value, this, exceptions or Promise/rejection behavior.
      if(!sameContext(now,j)||!candidate||candidate.isValid!==true||own(own(candidate,'blockInfo'),'id')!==id||own(a,'type')!==0){
        clean(j,false);j.status='uncertain';j.reason='request_not_eligible';return choose.apply(this,args);
      }
      j.attemptCount=1;j.chosenID=id;j.testedWhileLocked=now.empty&&now.lock>0;
      if(j.chooseHook){j.hooksRestored=j.chooseHook.undo()&&j.hooksRestored;j.chooseHook=null;}
      var before=own(s.socket,'packetId'),sendHook=null;
      var trackedSend=function(data){
        var v;try{if(typeof data==='string'&&data.length<=8192)v=JSON.parse(data);}catch(_){}
        if(this===ws&&v&&v.packet_id===before&&v.command==='CMD_CHOOSE_COMMON_BLOCK'&&v.param&&v.param.id===id&&v.param.type===0){
          j.packet=before;j.requestObserved=true;j.status='submitted';j.reason='awaiting_server';lease(j,15000);
        }
        return send.apply(this,arguments);
      };
      try {sendHook=shadow(ws,'send',trackedSend);}
      catch(_){clean(j,false);j.status='uncertain';j.reason='outbound_not_observed';return choose.apply(this,args);}
      try {return choose.apply(this,args);}
      catch(e){j.status='uncertain';j.reason='original_exception';throw e;}
      finally {if(sendHook){try{j.hooksRestored=sendHook.undo()&&j.hooksRestored;}catch(_){j.hooksRestored=false;}}
        if(!j.requestObserved){clean(j,false);j.status='uncertain';j.reason='outbound_not_observed';}}
    };
    try {ws.addEventListener('message',j.listener);j.chooseHook=shadow(s.socket,'ChooseCommonBlock',wrapped);lease(j,30000);}
    catch(_){clean(j,false);j.status='blocked';j.reason='observer_unavailable';return outcome();}
    var opened;
    try {
      Object.defineProperty(s.row,'lock_state',Object.assign({},lockDesc,{value:0}));j.localWriteApplied=true;j.localRestored=false;
      opened=openWarehouse({command:'open'});
    }catch(_){j.status='uncertain';j.reason='opening_exception';}
    finally {
      try {var current=Object.getOwnPropertyDescriptor(s.row,'lock_state');
        if(current&&'value'in current&&current.value===0&&current.writable===lockDesc.writable&&current.configurable===lockDesc.configurable&&current.enumerable===lockDesc.enumerable){
          Object.defineProperty(s.row,'lock_state',lockDesc);j.localRestored=true;
        }
      }catch(_){}
    }
    j.selectionOpened=!!(s.store.coverNode&&s.store.coverNode.active===true&&own(s.gs,'isAddingCommonBlock')===true);
    if(!j.localRestored){clean(j,true);j.status='uncertain';j.reason='local_restore_failed';}
    else if(!opened||opened.status!=='original_event_dispatched'||!j.selectionOpened){clean(j,true);j.status='blocked';j.reason='selector_not_opened';}
    return outcome();
  }
  function blocked(reason){return Object.assign(outcome(),{status:'blocked',reason:reason});}
  return function runtime(options){
    var cmd=options&&options.command;
    if(cmd==='arm')return arm();
    if(cmd==='poll')return outcome();
    if(cmd==='cancel'){if(job&&job.active){clean(job,true);job.status=job.requestObserved&&job.serverCode===null?'uncertain':'cancelled';job.reason=job.requestObserved?'cancelled_after_request':'user_cancelled';}return outcome();}
    return blocked('invalid_command');
  };
})

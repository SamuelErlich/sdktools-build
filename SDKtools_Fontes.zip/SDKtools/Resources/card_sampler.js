/* SDKtools 3.19.7: injected event sampler + direct current-hand census.
 * Native must first verify game 2007 and this document. Does NOT call Sync,
 * send/play/reveal, change card fields, or derive a face from the card ID.
 * Copies only card fields before original methods can reuse the argument;
 * commits observations only after their successful, exactly-once original call.
 */
(function makeCardSampler() {
  'use strict';
  var engine=null,scene=null,store=null,client=null,Card=null,patches=[],timer=null;
  var epoch=null,facts=new Map(),retired=new Set(),deadline=0,lastRead=null;
  var status='waiting',reason='awaiting_modules',fatal=false;
  var counters={samplerSamples:0,samplerSyncs:0,samplerUpdates:0,samplerSetups:0,samplerObserved:0,samplerRejected:0,samplerErrors:0};
  var LEASE=600,MAX_AGE=120000,MAX_GAP=1500;
  function own(o,k){if(!o||(typeof o!=='object'&&typeof o!=='function'))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);return d&&Object.prototype.hasOwnProperty.call(d,'value')?d.value:undefined;}
  function object(o){return !!o&&typeof o==='object';}
  function integer(v,max){return typeof v==='number'&&Number.isInteger(v)&&v>=0&&v<=max;}
  function uid(v){return typeof v==='string'?v.length>0&&v.length<=128:typeof v==='number'&&Number.isSafeInteger(v)&&v>0;}
  function now(){try{return window.performance&&typeof window.performance.now==='function'?window.performance.now():Date.now();}catch(_){return Date.now();}}
  function inc(k){counters[k]=Math.min(1000000,counters[k]+1);}
  function values(o){return ['id','type','color','num'].map(function(k){return own(o,k);});}
  function eq(a,b){return a.every(function(v,i){return v===b[i];});}
  function hidden(v){return v[1]===0&&v[2]===0&&v[3]===0;}
  function face(o){var v=values(o),special=[4,6,10].indexOf(v[1])>=0;
    if(!integer(v[0],65535)||!v[0]||!integer(v[1],10)||!v[1]||!integer(v[2],4)||(!special&&!v[2])||!integer(v[3],9)||(v[1]===1?!v[3]:v[3]!==0))return null;
    return {id:v[0],type:v[1],color:special?0:v[2],num:v[3]};}
  function sameFace(a,b){return !!a&&!!b&&['id','type','color','num'].every(function(k){return a[k]===b[k];});}
  function method(o,k){for(var i=0;o&&i<5;i++,o=Object.getPrototypeOf(o)){var d=Object.getOwnPropertyDescriptor(o,k);if(d)return typeof d.value==='function'?d:null;}return null;}
  function named(o,name){for(var i=0;o&&i<5;i++,o=Object.getPrototypeOf(o))if(own(o,'__classname__')===name)return true;return false;}
  function forget(){epoch=null;facts.clear();retired.clear();lastRead=null;}
  function retire(id){facts.delete(id);if(retired.size<256)retired.add(id);}
  function restore(){for(var i=patches.length-1;i>=0;i--){var p=patches[i];try{if(own(p.target,p.key)===p.wrapper){if(p.prior)Object.defineProperty(p.target,p.key,p.prior);else delete p.target[p.key];}}catch(_){inc('samplerErrors');}}patches=[];}
  function stop(){restore();if(timer!==null){window.clearInterval(timer);timer=null;}forget();engine=scene=store=client=Card=null;deadline=0;status='waiting';reason='stopped';}
  function live(){try{return deadline>0&&now()<=deadline&&document.hidden!==true&&document.visibilityState!=='hidden'&&window.cc===engine&&engine&&engine.director.getScene()===scene;}catch(_){return false;}}
  function intact(){return patches.every(function(p){return own(p.target,p.key)===p.wrapper;});}
  function fail(why){stop();fatal=true;status='error';reason=why;}
  function snapshot(){
    if(!live())return null;
    var token=own(store,'start_time'),state=own(store,'state'),gs=own(store,'gamers'),socket=own(client,'socket');
    if(!((typeof token==='number'&&Number.isSafeInteger(token)&&token>0)||(typeof token==='string'&&token.length>0&&token.length<=128))||[2,3,4,5,6,9,10,11].indexOf(state)<0||!Array.isArray(gs)||!gs.length||gs.length>8||!object(socket))return null;
    var discarded=own(store,'discard_cards');if(!Array.isArray(discarded)||discarded.length>256)return null;
    var gone=new Set();for(var d=0;d<discarded.length;d++){var id=own(own(discarded,String(d)),'id');if(integer(id,65535))gone.add(id);}
    var hands=[],rows=new Map(),uids=new Set(),total=0;
    for(var slot=0;slot<gs.length;slot++){
      var gamer=own(gs,String(slot)),owner=own(gamer,'uid'),cards=own(gamer,'cards');
      if(!uid(owner)||uids.has(owner)||!Array.isArray(cards)||cards.length>256||(total+=cards.length)>256)return null;uids.add(owner);
      var hand={slot:slot,uid:owner,gamer:gamer,cards:cards,length:cards.length,entries:[]};hands.push(hand);
      for(var j=0;j<cards.length;j++){
        var info=own(cards,String(j)),v=values(info);if(!object(info)||!integer(v[0],65535)||!v[0]||rows.has(v[0]))return null;
        var row={uid:owner,info:info,values:v,hand:hand,index:j};rows.set(v[0],row);hand.entries.push(row);
      }
    }
    var result={token:token,state:state,gs:gs,socket:socket,discarded:discarded,gone:gone,hands:hands,rows:rows};return fresh(result)?result:null;
  }
  function fresh(s){return !!s&&live()&&own(store,'start_time')===s.token&&own(store,'state')===s.state&&own(store,'gamers')===s.gs&&s.gs.length===s.hands.length&&own(client,'socket')===s.socket&&own(store,'discard_cards')===s.discarded&&
    s.hands.every(function(h){return own(s.gs,String(h.slot))===h.gamer&&own(h.gamer,'uid')===h.uid&&own(h.gamer,'cards')===h.cards&&h.cards.length===h.length&&h.entries.every(function(r){return own(h.cards,String(r.index))===r.info&&eq(values(r.info),r.values);});});}
  function currentEpoch(s,t){return epoch&&epoch.token===s.token&&epoch.socket===s.socket&&lastRead!==null&&t>=lastRead&&t-lastRead<=MAX_GAP;}
  function reconcile(s,t){
    if(!currentEpoch(s,t)){forget();epoch={token:s.token,socket:s.socket};}lastRead=t;
    facts.forEach(function(f,id){var r=s.rows.get(id);if(!r||r.uid!==f.uid||s.gone.has(id)||t-f.at>MAX_AGE||!(hidden(r.values)||sameFace(face(r.info),f.face)))retire(id);});
  }
  function candidates(payload){
    var out=[];function add(o,source){var f=face(o);if(f&&out.length<768){f.source=source||'argument';out.push(f);}}
    function list(a,source){if(Array.isArray(a)&&a.length<=256)for(var i=0;i<a.length;i++)add(own(a,String(i)),source);}
    add(payload);var gs=own(payload,'gamers');if(Array.isArray(gs)&&gs.length<=8)for(var i=0;i<gs.length;i++)list(own(own(gs,String(i)),'cards'));
    list(own(payload,'cards'));list(own(payload,'look_over_cards'),'look_over');add(own(payload,'select_give_card'),'selected');return out;
  }
  function remember(s,faces,t){faces.forEach(function(f){var r=s.rows.get(f.id),old=facts.get(f.id);
    if(!r||s.gone.has(f.id)||retired.has(f.id)||retired.size>=256||!(hidden(r.values)||sameFace(face(r.info),f))){inc('samplerRejected');return;}
    if(old&&(!sameFace(old.face,f)||old.uid!==r.uid)){retire(f.id);inc('samplerRejected');return;}
    if(!old&&facts.size<256){facts.set(f.id,{uid:r.uid,face:f,source:f.source,at:t});inc('samplerObserved');}
  });}
  function sample(faces){var s=snapshot(),t=now();if(!s){forget();return null;}reconcile(s,t);
    remember(s,candidates({gamers:s.gs,select_give_card:own(store,'select_give_card'),look_over_cards:own(store,'look_over_cards')}),t);
    if(faces)remember(s,faces,t);return fresh(s)?s:null;}
  function patch(target,key,counter){
    var found=method(target,key),prior=Object.getOwnPropertyDescriptor(target,key);if(!found||(prior&&(!prior.configurable||!prior.writable)))throw Error('method_contract');
    var original=found.value,rec={target:target,key:key,prior:prior};
    rec.wrapper=function(){
      if(!live()||(target===store?this!==store:!Object.prototype.isPrototypeOf.call(own(Card,'prototype'),this)))return original.apply(this,arguments);
      var before=[];try{before=candidates(arguments[0]);}catch(_){inc('samplerErrors');}
      // Original exception/return/this/arguments are preserved. Never retry it.
      var result=original.apply(this,arguments);
      try{if(live()&&intact()){inc(counter);sample(target===store?before:boundSetupFaces(this,before));}}catch(_){inc('samplerErrors');forget();}
      return result;
    };
    Object.defineProperty(target,key,{configurable:true,enumerable:prior?prior.enumerable:false,writable:true,value:rec.wrapper});patches.push(rec);
  }
  function install(){
    var cc=own(window,'cc'),loader=own(window,'__require');
    if(!cc||(cc.ENGINE_VERSION!=='2.4.5'&&own(window,'CocosEngine')!=='2.4.5')||(cc.ENGINE_VERSION&&cc.ENGINE_VERSION!=='2.4.5')||typeof loader!=='function'||!cc.director||typeof cc.director.getScene!=='function')return false;
    var root=cc.director.getScene(),registry=cc.js&&method(cc.js,'getClassByName');if(!root||root.isValid!==true||!registry)return false;
    var C=registry.value.call(cc.js,'Card'),H=registry.value.call(cc.js,'HandArea'),G=registry.value.call(cc.js,'game');
    if(typeof C!=='function'||typeof H!=='function'||typeof G!=='function')return false;
    // These registered eager-entry factories have already run in this bundle.
    if(own(loader('Card'),'default')!==C||own(loader('HandArea'),'default')!==H||own(loader('game'),'default')!==G)return false;
    var s=own(loader('GameStore'),'default'),sock=own(loader('Socket'),'default');
    if(!object(s)||!object(sock)||!method(s,'sync')||!method(s,'updatePushMessage')||!method(own(C,'prototype'),'setup'))return false;
    engine=cc;scene=root;store=s;client=sock;Card=C;
    try{patch(store,'sync','samplerSyncs');patch(store,'updatePushMessage','samplerUpdates');patch(own(Card,'prototype'),'setup','samplerSetups');}
    catch(_){restore();engine=scene=store=client=Card=null;inc('samplerErrors');fatal=true;status='error';reason='install_failed';return false;}
    if(typeof window.setInterval==='function')timer=window.setInterval(function(){if(!live()){stop();reason='lease_expired';}else if(!intact())fail('hook_replaced');},150);
    return true;
  }
  function eligible(s,row,t){var raw=face(row.info),f=facts.get(row.values[0]);if(raw)return {face:raw,fact:null};
    return hidden(row.values)&&f&&f.uid===row.uid&&currentEpoch(s,t)&&t-f.at<=MAX_AGE&&!s.gone.has(f.face.id)?{face:f.face,fact:f}:null;}
  function census(){try{var s=snapshot(),t=now(),hiddenKnown=0;if(!s||!currentEpoch(s,t))return null;
    var result=s.hands.map(function(h){var colors=[0,0,0,0,0],selected=0;
      h.entries.forEach(function(r){var f=eligible(s,r,t);if(f){colors[f.face.color]++;if(f.fact){hiddenKnown++;if(f.fact.source==='selected')selected++;}}});
      var known=colors.reduce(function(a,b){return a+b;},0);return {slot:h.slot,total:h.length,known:known,unknown:h.length-known,special:colors[0],colors:colors,selected:selected};});return fresh(s)?{hands:result,hiddenKnown:hiddenKnown}:null;}catch(_){return null;}}
  function oneCard(n){var a=own(n,'_components');if(!Array.isArray(a)||a.length>16)return null;var found=null;for(var i=0;i<a.length;i++){var c=own(a,String(i));if(named(c,'Card')){if(found)return null;found=c;}}return found;}
  function nodeOwner(node,row){var parent=node.parent,p=parent,found=null;
    for(var depth=0;p&&depth<6;depth++,p=p.parent){var a=own(p,'_components');if(!Array.isArray(a))continue;if(a.length>16)return null;
      for(var i=0;i<a.length;i++){var h=own(a,String(i));if(named(h,'HandArea')&&own(h,'itemsNode')===parent){if(found)return null;found=h;}}
    }
    if(!found||own(found,'uid')!==row.uid||own(own(found,'gamer'),'uid')!==row.uid)return null;
    var n=node,k=0;while(n&&n!==scene&&k++<24)n=n.parent;if(n!==scene)return null;return found;
  }
  function boundSetupFaces(component,faces){
    var node=own(component,'node')||own(component,'_node'),info=own(component,'cardInfo'),s=snapshot(),row=s&&s.rows.get(own(info,'id'));
    if(!node||node.isValid!==true||node.active!==true||!row||oneCard(node)!==component||!nodeOwner(node,row))return [];
    var v=values(info);return fresh(s)?faces.filter(function(f){return f.id===row.values[0]&&(eq(v,row.values)||sameFace(face(info),f));}):[];
  }
  function resolve(node,component){try{var s=snapshot(),t=now(),info=own(component,'cardInfo'),row=s&&s.rows.get(own(info,'id'));
    if(!row||!currentEpoch(s,t)||!node||node.isValid!==true||node.active!==true||node.activeInHierarchy===false||oneCard(node)!==component||!Object.prototype.isPrototypeOf.call(own(Card,'prototype'),component))return null;
    var hit=eligible(s,row,t),hand=hit&&nodeOwner(node,row);if(!hit||!hand)return null;
    // A whole current UI hand, not a matching ID found somewhere in the scene.
    var siblings=node.parent.children,used=new Set();if(!Array.isArray(siblings)||siblings.length!==row.hand.length)return null;
    for(var i=0;i<siblings.length;i++){var n=own(siblings,String(i)),c=oneCard(n),v=values(own(c,'cardInfo')),r=s.rows.get(v[0]);
      if(!n||n.isValid!==true||n.active!==true||!c||!r||r.uid!==row.uid||used.has(v[0])||!Object.prototype.isPrototypeOf.call(own(Card,'prototype'),c)||!(eq(v,r.values)||(hidden(v)&&face(r.info))))return null;used.add(v[0]);}
    return fresh(s)?{color:hit.face.color,face:hit.face,fact:hit.fact,uid:row.uid,epoch:epoch,component:component,info:info,modelInfo:row.info,hand:hand,node:node}:null;
  }catch(_){return null;}}
  function same(a,b){return !!a&&!!b&&a.component===b.component&&a.info===b.info&&a.modelInfo===b.modelInfo&&a.hand===b.hand&&a.uid===b.uid&&a.epoch===b.epoch&&a.fact===b.fact&&sameFace(a.face,b.face);}
  function valid(b,node){return !!b&&same(b,resolve(node,b.component));}
  function stats(){var c=census(),rows=c&&c.hands,out={samplerStatus:status,samplerReason:reason,samplerHooks:patches.length,samplerRetained:facts.size,samplerHiddenKnown:c?c.hiddenKnown:0,samplerSelfSlot:8};Object.assign(out,counters);
    if(rows){out.samplerStatus='sampling';out.samplerReason='direct_and_hooks';
      var self=own(store,'isWatcher')===false?own(store,'uid'):own(store,'isWatcher')===true?own(store,'watchUid'):undefined;var snap=snapshot();
      if(uid(self)&&snap)for(var i=0;i<snap.hands.length;i++)if(snap.hands[i].uid===self)out.samplerSelfSlot=snap.hands[i].slot;
      out.handsStatus='ready';out.handCounts=rows;out.handTotal=out.handKnown=out.handUnknown=0;rows.forEach(function(h){out.handTotal+=h.total;out.handKnown+=h.known;out.handUnknown+=h.unknown;});}else if(out.samplerStatus==='sampling'){out.samplerStatus='waiting';out.samplerReason='awaiting_state';}
    return out;}
  function tick(){try{
    if(fatal)return stats();
    if(document.hidden===true||document.visibilityState==='hidden'){stop();reason='hidden_document';return stats();}
    if(patches.length&&(!live()||!intact())){var replaced=!intact();stop();if(replaced){fatal=true;status='error';reason='hook_replaced';return stats();}}
    deadline=now()+LEASE;
    if(!patches.length&&!install()){if(!fatal){status='waiting';reason='awaiting_modules';}return stats();}
    inc('samplerSamples');var current=sample();status=current?'sampling':'waiting';reason=current?'direct_and_hooks':'awaiting_state';return stats();
  }catch(_){inc('samplerErrors');fail('sampling_failed');return stats();}}
  return Object.freeze({tick:tick,stats:stats,resolve:resolve,same:same,valid:valid,clear:function(){stop();fatal=false;}});
})

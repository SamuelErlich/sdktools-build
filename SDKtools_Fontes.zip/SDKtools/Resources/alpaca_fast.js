/* Super Fast: at most three exposed original events per batch.
 * Observes original TouchBlock Promises + matching trusted WS acknowledgements.
 * No packet synthesis, direct transport gameplay call, flag/stock edits or retry. */
(function () {
  'use strict';
  var job=null,batches=0,confirmedCards=0,lastReason='not_armed',lastStatus='idle',lastIssue='none',compat=null;
  var LIMIT=15000,COMPAT_MS=3000;
  function own(o,k){if(o===null||typeof o!=='object'&&typeof o!=='function')return undefined;
    var d=Object.getOwnPropertyDescriptor(o,k);if(d&&!('value'in d))throw Error('accessor');return d&&d.value;}
  function int(v,a,b){return typeof v==='number'&&isFinite(v)&&Math.floor(v)===v&&v>=a&&v<=b;}
  function now(){return typeof performance==='object'&&typeof performance.now==='function'?performance.now():Date.now();}
  function method(o,k){for(var p=o,i=0;p&&i<8;p=Object.getPrototypeOf(p),i++){
    var d=Object.getOwnPropertyDescriptor(p,k);if(d){if(!('value'in d)||typeof d.value!=='function')throw Error('method');return d.value;}}throw Error('method');}
  function shadow(o,k,fn){var d=Object.getOwnPropertyDescriptor(o,k);method(o,k);
    if(d?!('value'in d)||d.writable!==true:!Object.isExtensible(o))throw Error('observer');
    Object.defineProperty(o,k,d?Object.assign({},d,{value:fn}):{value:fn,writable:true,configurable:true,enumerable:false});
    return function(){var current=Object.getOwnPropertyDescriptor(o,k);if(!current||current.value!==fn)return false;
      if(d)Object.defineProperty(o,k,d);else delete o[k];return true;};}
  function transport(ws){return typeof ws.url==='string'&&ws.url.length<=4096&&/^wss?:\/\/[^\/?#\s@\\]+(?:[\/?][^#\s\\]*)?$/.test(ws.url);}
  function busy(){return !!(job&&job.pending);}
  function cleanup(j){var ok=true;if(j.timer!==null){try{clearTimeout(j.timer);}catch(_){ok=false;}j.timer=null;}
    j.listeners.forEach(function(pair){try{j.remove.call(j.ws,pair[0],pair[1]);}catch(_){ok=false;}});j.listeners=[];return ok;}
  function restore(j){var ok=true;j.undo.reverse().forEach(function(fn){try{ok=fn()&&ok;}catch(_){ok=false;}});j.undo=[];return ok;}
  function uncertain(j,r){if(job!==j||!j.pending||j.status==='uncertain')return;
    // Accepted requests may outlive a hidden board; keep the latch until their effect is verified.
    var accepted=r==='effect_timeout'&&j.phase==='effect'&&j.dispatchDone&&j.rows.length>0&&j.rows.length===j.dispatchCount&&j.rows.every(function(v){
      return v.invoked&&v.calls===1&&v.sends===1&&v.request&&v.response&&v.settled&&v.resolved&&v.code===200;});
    j.status=accepted?'waiting_effect':'uncertain';j.reason=r;j.stable=null;restore(j);cleanup(j);}
  function arm(j,phase){if(j.timer!==null)clearTimeout(j.timer);j.phase=phase;j.deadline=now()+LIMIT;
    j.timer=setTimeout(function(){if(job===j&&j.pending)uncertain(j,phase==='response'?'response_timeout':'effect_timeout');},LIMIT);}
  function timed(){var j=job;if(!j||!j.pending||j.status==='uncertain')return;
    var t=now();if(!isFinite(t)||t<j.started)uncertain(j,'clock_invalid');else if(t>=j.deadline&&j.status!=='waiting_effect')uncertain(j,j.phase==='response'?'response_timeout':'effect_timeout');}
  function diagnostic(){timed();compatible(null);var j=job,rows=j?j.rows:[];
    return {version:1,status:j?j.status:lastStatus,reason:j?j.reason:lastReason,pending:!!(j&&j.pending),batches:batches,
      submitted:rows.filter(function(row){return row.invoked;}).length,requests:rows.filter(function(row){return row.request;}).length,
      responses:rows.filter(function(row){return row.response;}).length,settled:rows.filter(function(row){return row.settled;}).length,
      accepted:rows.filter(function(row){return row.response&&row.code===200;}).length,
      effectObserved:!!(j&&j.effect),confirmedCards:confirmedCards,
      observerIssue:j?j.observerIssue||'none':lastIssue,compatibility:!!compat};}
  function invalidate(reason){if(job){job.stable=null;if(reason!=='external_mode_active')job.terminalProof=null;if(reason==='modal_visible')job.sawModal=true;}}
  function insert(bar,c){var at=-1;for(var i=0;i<bar.length;i++){
    if(i+1===bar.length){at=i+1;break;}if(bar[i].type===c.type&&bar[i+1].type!==c.type){at=i+1;break;}}
    bar.splice(at,0,{id:c.id,type:c.type});for(var k=0;k<bar.length-2;k++)if(bar[k].type===bar[k+1].type&&bar[k].type===bar[k+2].type)return bar.splice(k,3);return null;}
  function plan(s,allowed){
    if(compatible(s))return null;
    if(!s||!Array.isArray(s.cards)||!Array.isArray(s.tray)||s.cards.length+s.tray.length>512||s.capacity!==7)return null;
    var groups=new Map(),barCounts=new Map();s.tray.forEach(function(c){barCounts.set(c.type,(barCounts.get(c.type)||0)+1);});
    s.cards.forEach(function(c){if(c.available!==true||c.masked===true||c.selectable!==true||!c.metadata||c.metadata.specialType!==0||
        !Array.isArray(c.blockedBy)||c.blockedBy.length||['board','reserve'].indexOf(c.zone)<0||typeof allowed==='function'&&!allowed(s,c))return;
      if(!groups.has(c.type))groups.set(c.type,[]);groups.get(c.type).push(c);});
    var candidates=[];groups.forEach(function(cards,type){var need=3-(barCounts.get(type)||0);
      if(!int(need,1,3)||cards.length<need)return;
      cards.sort(function(a,b){return Number(b.zone==='reserve')-Number(a.zone==='reserve')||a.order-b.order;});
      var chosen=cards.slice(0,need),bar=s.tray.map(function(c){return {id:c.id,type:c.type};}),matched=null,peak=bar.length;
      chosen.forEach(function(c){peak=Math.max(peak,bar.length+1);matched=insert(bar,c);});
      if(peak>7||bar.length>=7||!matched)return;
      candidates.push({type:type,chosen:chosen,matched:matched,peak:peak});});
    candidates.sort(function(a,b){return Number(!!s.mission&&s.mission.current<s.mission.total&&b.type===s.mission.type)-Number(!!s.mission&&s.mission.current<s.mission.total&&a.type===s.mission.type)||a.chosen.length-b.chosen.length||a.chosen[0].order-b.chosen[0].order;});
    if(!candidates.length)return null;var c=candidates[0],ids=c.chosen.map(function(v){return v.id;});
    return {status:'move',fastBatch:true,proofKind:'local_trio',cardID:ids[0],sequence:ids,actions:ids.slice(),tripleCardIDs:c.matched.map(function(v){return v.id;}),
      matchedType:c.type,peakTrayCount:c.peak,missionKey:s.missionKey,stats:{expanded:s.cards.length,goal:'next_trio',missionStatus:s.mission&&s.mission.type===c.type?'priority':'fallback'}};
  }
  // Prove the complete route through its first trio, then submit only its
  // currently exposed prefix. A future covered card is never prepared or clicked.
  function prefix(s,cards,limit){
    try{
      limit=limit===undefined?3:int(limit,1,3)?limit:1;
      if(!s||s.capacity!==7||!Array.isArray(s.tray)||s.tray.length>=7||!s.refs||!Array.isArray(cards)||!cards.length||cards.length>7)return [];
      var removed=new Set(),rawIDs=new Set(),bar=s.tray.map(function(c){return {id:c.id,type:c.type};}),chosen=[],open=true,matched=null;
      for(var i=0;i<cards.length;i++){
        var c=cards[i];
        if(!c||s.refs.get(c.id)!==c||removed.has(c.id)||typeof c.rawID!=='string'||!c.rawID||rawIDs.has(c.rawID)||
          ['board','reserve'].indexOf(c.zone)<0||c.selectable!==true||!c.metadata||!Array.isArray(c.blockedBy)||
          (!c.available&&!c.blockedBy.length)||c.blockedBy.some(function(id){return !removed.has(id);}))return [];
        if(c.available!==true||c.masked!==false||c.metadata.specialType!==0||c.blockedBy.length)open=false;
        if(open&&chosen.length<limit)chosen.push(c);
        removed.add(c.id);rawIDs.add(c.rawID);
        if(bar.length+1>s.capacity)return [];matched=insert(bar,c);
        if(bar.length>=s.capacity||matched&&i!==cards.length-1)return [];
      }
      return matched?chosen:[];
    }catch(_){return [];}
  }
  function sameRound(j,s){var p=s&&s.playState;
    return typeof window==='object'&&window===j.window&&typeof document==='object'&&document===j.document&&
      own(window,'cc')===j.cc&&own(window,'__require')===j.loader&&
      own(j.loader('GameStore'),'default')===j.store&&own(j.loader('Socket'),'default')===j.socket&&own(j.store,'uid')===j.uid&&
      own(j.store,'rid')===j.rid&&own(j.store,'start_time')===j.start&&own(j.socket,'uid')===j.uid&&own(j.socket,'rid')===j.rid&&
      own(j.socket,'socket')===j.ws&&own(j.socket,'responseMap')===j.map&&j.ws.url===j.url&&
      (!s||p&&s.cc===j.cc&&p.store===j.store&&p.uid===j.uid&&p.rid===j.rid&&p.start===j.start);
  }
  function sameContext(j,s){var p=s&&s.playState;
    return sameRound(j,s)&&method(j.cc.director,'getScene').call(j.cc.director)===j.root&&
      (!s||s.root===j.root&&s.board===j.board&&s.reserve===j.reserve&&p.game===j.game&&p.layer===j.layer);
  }
  function live(j,s){return sameContext(j,s)&&transport(j.ws);}
  // Capability fallback only before any original event. The normal planner
  // keeps its one-card pending/effect proof; this never sends an unobserved trio.
  function compatible(s){if(!compat||busy())return false;try{var t=now(),j=compat.binding;
      if(isFinite(t)&&t>=compat.started&&t<compat.until&&sameContext(j,s))
        return flags(j)&&document.visibilityState==='visible'&&j.ws.readyState===1;
    }catch(_){}compat=null;return false;}
  function offerCompatibility(j,issue){if(!j||['event_api','timers','hooks'].indexOf(issue)<0)return;
    try{if(!sameContext(j,j.before)||!flags(j)||document.visibilityState!=='visible'||j.ws.readyState!==1||!j.map||
        typeof j.operation!=='function'||typeof j.send!=='function'||!transport(j.ws))return;
      var t=now();if(isFinite(t))compat={binding:j,started:t,until:t+COMPAT_MS};
    }catch(_){}
  }
  function flags(j){var s=j.store,g=own(s,'gamers');return own(s,'state')===2&&own(s,'isWatcher')===false&&own(s,'isHotTiming')===false&&
    own(s,'isAddingCommonBlock')===false&&own(s,'isUsingPenetrateProp')===false&&own(s,'isCanTouchBlock')===true&&Array.isArray(g)&&g.length<=512&&g.filter(function(v){return own(v,'uid')===j.uid&&own(v,'state')===1&&own(v,'choosing_hot_time_block')!==true;}).length===1;}
  function agreement(j){if(job!==j||!j.pending||j.status==='uncertain')return;
    try{if(!sameRound(j,null)||!transport(j.ws)){uncertain(j,'context_changed');return;}}catch(_){uncertain(j,'context_changed');return;}
    for(var i=0;i<j.rows.length;i++){var row=j.rows[i];if(row.response&&row.settled&&((row.code===200)!==row.resolved)){uncertain(j,'response_mismatch');return;}
      if(row.response&&row.code!==200){uncertain(j,'server_rejected');return;}}
    if(j.dispatchDone&&j.rows.length&&j.rows.every(function(r){return r.request&&r.response&&r.settled&&r.code===200;})){
      j.reason='awaiting_effect';if(j.phase!=='effect')arm(j,'effect');}
  }
  function dispatch(s,cards,invoke,limit){
    if(busy())return false;
    job=null;compat=null;lastStatus='blocked';lastIssue='none';
    var p=s&&s.playState,j,stage='candidate';
    limit=limit===undefined?3:int(limit,1,3)?limit:1;
    try{
      if(!p||!s.phaseSnapshot||s.phaseSnapshot.complete!==true||typeof invoke!=='function')throw Error('candidate');
      cards=prefix(s,cards,limit);if(!cards.length)throw Error('candidate');
      stage='socket';var loader=own(window,'__require'),socket=own(loader('Socket'),'default'),ws=own(socket,'socket');
      j={window:window,document:document,loader:loader,cc:s.cc,root:s.root,board:s.board,reserve:s.reserve,game:p.game,layer:p.layer,store:p.store,
        uid:p.uid,rid:p.rid,start:p.start,socket:socket,ws:ws,url:ws.url,map:own(socket,'responseMap'),rows:[],active:null,undo:[],listeners:[],timer:null,
        status:'submitted',reason:'invoking_original',pending:true,phase:'response',started:now(),deadline:now()+LIMIT,stable:null,effect:false,dispatchDone:false,
        before:s,dispatchCount:0,observerIssue:'none'};
      stage='context';if(!sameContext(j,s)||!j.map)throw Error('observer');
      stage='flags';if(!flags(j))throw Error('observer');
      stage='document';if(document.visibilityState!=='visible')throw Error('observer');
      stage='socket_closed';if(ws.readyState!==1)throw Error('observer');
      stage='operation';j.operation=method(socket,'TouchBlock');j.send=method(ws,'send');
      stage='transport';if(!transport(ws))throw Error('observer');
      stage='event_api';j.add=method(ws,'addEventListener');j.remove=method(ws,'removeEventListener');
      // Function.length is not an ABI: rest/default/instrumentation wrappers
      // may report zero. observedOperation validates the actual two arguments.
      stage='promise';if(typeof Promise!=='function')throw Error('observer');
      stage='timers';if(typeof setTimeout!=='function'||typeof clearTimeout!=='function')throw Error('observer');
    }catch(_){lastReason='observer_unavailable';lastIssue=stage;offerCompatibility(j,stage);return false;}
    job=j;
    function onMessage(e){try{timed();if(!j.pending||j.status==='uncertain'||!e||e.isTrusted!==true||e.target!==j.ws||typeof e.data!=='string'||e.data.length>262144)return;
      var data;try{data=JSON.parse(e.data);}catch(_){return;}
      if(!data||!int(data.code,0,1000000))return;
      var row=j.rows.find(function(r){return r.request&&r.packet===data.packet_id;});if(!row)return;
      if(row.response&&row.code!==data.code){uncertain(j,'response_mismatch');return;}row.response=true;row.code=data.code;agreement(j);
    }catch(_){uncertain(j,'context_changed');}}
    function onClose(e){if(e&&e.isTrusted===true&&e.target===j.ws)uncertain(j,'socket_closed');}
    function observedSend(){var r=j.active;if(r&&j.pending&&j.status!=='uncertain'){
      try{var raw=arguments[0],v=typeof raw==='string'&&raw.length<=8192?JSON.parse(raw):null,param=v&&v.param;
        if(this!==j.ws||++r.sends!==1||!v||v.command!=='CMD_TOUCH_BLOCK'||v.packet_id!==r.packet||!param||param.block_id!==r.card.rawID||param.block_state!==r.state||param.uid!==j.uid||param.rid!==j.rid)throw Error('request');r.request=true;
      }catch(_){uncertain(j,'request_mismatch');}}
      try{return j.send.apply(this,arguments);}catch(e){uncertain(j,'original_exception');throw e;}}
    function observedOperation(){var r=j.active,track=!!(r&&j.pending&&j.status!=='uncertain');
      if(track){try{if(this!==j.socket||++r.calls!==1||arguments.length!==2||arguments[0]!==r.card.rawID||arguments[1]!==r.state||!live(j,null))throw Error('request');
        r.packet=own(j.socket,'packetId');if(!int(r.packet,1,9007199254740990)||own(j.map,String(r.packet))!==undefined)throw Error('packet');
      }catch(_){uncertain(j,'request_mismatch');track=false;}}
      var returned;try{returned=j.operation.apply(this,arguments);}catch(e){uncertain(j,'original_exception');throw e;}
      if(track&&j.status!=='uncertain'){try{var entry=own(j.map,String(r.packet));
        if(!r.request||r.sends!==1||own(j.socket,'packetId')!==r.packet+1||!entry||typeof own(entry,'resolve')!=='function'||typeof own(entry,'reject')!=='function')throw Error('entry');
        Promise.prototype.then.call(returned,function(){r.settled=true;r.resolved=true;agreement(j);},function(){r.settled=true;r.resolved=false;agreement(j);});
      }catch(_){uncertain(j,'outbound_not_observed');}}
      return returned;}
    try{
      stage='hooks';
      [['message',onMessage],['close',onClose],['error',onClose]].forEach(function(pair){j.listeners.push(pair);j.add.call(j.ws,pair[0],pair[1]);});
      j.undo.push(shadow(j.socket,'TouchBlock',observedOperation));j.undo.push(shadow(j.ws,'send',observedSend));stage='timers';arm(j,'response');
    }catch(_){var restored=restore(j),cleaned=cleanup(j);j.pending=!(restored&&cleaned);j.status=j.pending?'uncertain':'blocked';
      j.reason=j.pending?'observer_restore_failed':'observer_unavailable';j.observerIssue=j.pending?'restore':stage;
      if(!j.pending)offerCompatibility(j,stage);return false;}
    // Validate the full matching route above; submit only the selected prefix.
    try{for(var i=0;i<Math.min(cards.length,limit);i++){
      if(!live(j,null)){uncertain(j,'context_changed');break;}if(!flags(j)||document.visibilityState!=='visible'||j.ws.readyState!==1)break;
      var row={card:cards[i],state:cards[i].zone==='board'?0:2,invoked:false,calls:0,sends:0,request:false,response:false,settled:false};j.rows.push(row);j.active=row;
      var invoked=invoke(cards[i],i);
      if(invoked!==true){if(row.request||row.calls){row.invoked=true;j.dispatchCount++;uncertain(j,'original_exception');}else j.rows.pop();break;}
      row.invoked=true;j.dispatchCount++;
      if(j.status==='uncertain')break;
      if(!row.request||row.calls!==1){uncertain(j,'outbound_not_observed');break;}
    }}catch(_){if(j.active){j.active.invoked=true;j.dispatchCount++;}uncertain(j,'original_exception');}
    finally{j.active=null;j.dispatchDone=true;if(!restore(j))uncertain(j,'observer_restore_failed');}
    if(!j.dispatchCount){if(j.status==='uncertain')return false;cleanup(j);j.pending=false;j.status='blocked';j.reason='candidate_unavailable';return false;}
    batches=Math.min(10000,batches+1);agreement(j);return true;
  }
  function terminalBatch(j){var bar=j.before.tray.map(function(c){return {id:c.id,type:c.type};});j.rows.forEach(function(r){insert(bar,r.card);});return j.before.cards.length===j.rows.length&&bar.length===0;}
  function replacement(j,s){if(!j.sawModal||!terminalBatch(j)||s.tray.length||s.cards.length<18)return false;
    return s.cards.filter(function(c){return !j.before.refs.has(c.id);}).length>=15;}
  function consumed(j,s){return j.rows.every(function(row){var found=null;s.refs.forEach(function(c){if(c.rawID===row.card.rawID)found=c;});
    return !found||found.zone==='tray'&&found.type===row.card.type;});}
  function complete(j,exact){var bar=j.before.tray.map(function(c){return {id:c.id,type:c.type};}),matched=null;j.rows.forEach(function(r){matched=insert(bar,r.card);});
    j.pending=false;j.status=exact?'confirmed':'resynced';j.reason=exact?(matched?'trio_confirmed':'prefix_confirmed'):'board_resynced';j.effect=exact;cleanup(j);
    if(exact){confirmedCards=Math.min(10000,confirmedCards+j.rows.length);return j.rows.length;}return 0;}
  function terminal(){var j=job;if(!j||!j.pending)return 0;timed();if(j.status==='uncertain'||j.phase!=='effect')return 0;
    try{if(!sameRound(j,null)||!transport(j.ws)){uncertain(j,'context_changed');return 0;}
      var gamers=own(j.store,'gamers'),self=Array.isArray(gamers)?gamers.filter(function(g){return own(g,'uid')===j.uid;}):[];
      var pile=own(j.store,'pile_blocks'),hand=own(j.store,'hand_blocks'),storage=own(j.store,'storage_blocks');
      if(document.visibilityState!=='visible'||j.ws.readyState!==1||self.length!==1||own(self[0],'state')!==3||
          !Array.isArray(pile)||pile.length||!Array.isArray(hand)||hand.length||!Array.isArray(storage)||storage.length>512||
          storage.some(function(layer){return Array.isArray(layer)?layer.length>512||layer.some(function(row){return row!==null;}):layer!==null;})){j.terminalProof=null;return 0;}
      var t=now(),proof=j.terminalProof;if(!proof||proof.pile!==pile||proof.hand!==hand||proof.storage!==storage||proof.self!==self[0]){j.terminalProof={pile:pile,hand:hand,storage:storage,self:self[0],time:t};return 0;}if(t-proof.time<80)return 0;
      var count=complete(j,terminalBatch(j));if(count)j.reason='win_confirmed';return count;
    }catch(_){uncertain(j,'context_changed');return 0;}
  }
  function expected(j,s,rebuilt){
    if(!s.phaseSnapshot||s.phaseSnapshot.complete!==true||!s.refs)return false;
    function key(c){return rebuilt?c.rawID:c.id;}
    var selected=new Set(j.rows.map(function(r){return key(r.card);})),before=j.before;
    var remaining=before.cards.filter(function(c){return !selected.has(key(c));}),liveCards=new Map(s.cards.map(function(c){return [key(c),c];}));
    if(remaining.length!==s.cards.length||!remaining.every(function(c){var other=liveCards.get(key(c));return other&&other.rawID===c.rawID&&other.type===c.type&&other.zone===c.zone;}))return false;
    var bar=before.tray.map(function(c){return {id:key(c),type:c.type};});j.rows.forEach(function(r){insert(bar,{id:key(r.card),type:r.card.type});});
    return bar.length===s.tray.length&&bar.every(function(c,i){return key(s.tray[i])===c.id&&s.tray[i].type===c.type;});
  }
  function observe(s){var j=job;if(!j||!j.pending)return 0;timed();if(j.status==='uncertain')return 0;
    try{if(!sameRound(j,s)||!transport(j.ws)){uncertain(j,'context_changed');return 0;}
      if(!sameContext(j,s))j.visualChanged=true;
      if(j.ws.readyState!==1){uncertain(j,'socket_closed');return 0;}
      if(document.visibilityState!=='visible'||j.phase!=='effect'||!s.phaseSnapshot||s.phaseSnapshot.complete!==true){j.stable=null;return 0;}
      if(j.visualChanged){
        // Rebuilt scene objects are not request identity. Reconcile the entire
        // stable census by game IDs only after every exact request was accepted.
        if(!j.dispatchDone||j.rows.length!==j.dispatchCount||!j.rows.every(function(r){return r.invoked&&r.calls===1&&r.sends===1&&r.request&&r.response&&r.settled&&r.resolved&&r.code===200;})||!expected(j,s,true))return 0;
        return complete(j,false);
      }
      var exact=expected(j,s)||replacement(j,s);if(!exact&&!consumed(j,s)){j.stable=null;return 0;}
      // The required phase snapshot already proved two equal reads >=80ms.
      // Do not add a second redundant animation/stability delay after all ACKs.
      return complete(j,exact);
    }catch(_){uncertain(j,'context_changed');return 0;}
  }
  return Object.freeze({plan:plan,prefix:prefix,dispatch:dispatch,observe:observe,busy:busy,diagnostic:diagnostic,invalidate:invalidate,terminal:terminal});
})

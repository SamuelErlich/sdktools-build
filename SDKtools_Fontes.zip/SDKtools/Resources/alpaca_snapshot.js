/* Read-only phase snapshot. No transport, hooks, game writes or action calls.
 * Scene/Store agreement is a local observation, never a server acknowledgement.
 * Unknown rules remain explicit. New state requires two stable reads >=80ms. */
(function () {
  'use strict';
  var candidate=null, current=null, binding=null, revision=0, scope=0, lastTime=null;
  var status='unavailable',reason='not_observed',verifiedGeometry=null;
  var MAX_CARDS=512,MAX_EDGES=8192,MAX_BYTES=262144,STABLE_MS=80;
  var reasons=['not_observed','snapshot_stability','verified','context_unavailable','context_changed','store_unavailable',
    'store_scene_mismatch','invalid_cards','invalid_dependencies','invalid_inventory','invalid_mission','invalid_slots',
    'external_mode_active','time_budget','rules_unrecognized','clock_invalid','read_error','size_limit','user_paused','observation_interrupted'];
  function fail(r){throw Error(r);}
  function object(v){return v!==null&&typeof v==='object';}
  function own(o,k){if(!object(o)&&typeof o!=='function')return undefined;
    var d=Object.getOwnPropertyDescriptor(o,k);if(d&&!Object.prototype.hasOwnProperty.call(d,'value'))fail('read_error');return d?d.value:undefined;}
  function int(v,a,b){return typeof v==='number'&&isFinite(v)&&Math.floor(v)===v&&v>=a&&v<=b;}
  function finite(v){return typeof v==='number'&&isFinite(v)&&Math.abs(v)<=10000;}
  function rawID(v){return typeof v==='string'&&v.length>0&&v.length<=128;}
  function localID(v){return typeof v==='string'&&/^c[1-9][0-9]{0,14}$/.test(v);}
  function bool(v){return typeof v==='boolean';}
  function freeze(v){if(object(v)){Object.keys(v).forEach(function(k){freeze(v[k]);});Object.freeze(v);}return v;}
  function tickRevision(){if(revision>=1000000000)fail('context_unavailable');revision++;}
  function invalidate(r){r=reasons.indexOf(r)>=0?r:'observation_interrupted';
    if(current||candidate||reason!==r)tickRevision();current=null;candidate=null;status='unavailable';reason=r;}
  function same(a,b){return !!a&&a.length===b.length&&a.every(function(v,i){return v===b[i];});}
  function context(s,env){
    var p=s&&s.playState,store=p&&p.store,loader=env&&env.loader;
    if(!p||!object(store)||typeof loader!=='function'||!env.window||!env.document||!s.root||!s.board||!s.reserve||!s.trayNode)fail('context_unavailable');
    var socket=own(loader('Socket'),'default'),ws=own(socket,'socket'),map=own(socket,'responseMap');
    if(own(loader('GameStore'),'default')!==store||!object(socket)||!object(ws)||!object(map)||own(socket,'uid')!==p.uid||own(socket,'rid')!==p.rid||ws.readyState!==1)fail('context_unavailable');
    if(own(store,'uid')!==p.uid||own(store,'rid')!==p.rid||own(store,'start_time')!==p.start||!int(p.start,1,9007199254740991))fail('context_changed');
    var gamers=own(store,'gamers');if(!Array.isArray(gamers)||gamers.length>512)fail('store_unavailable');
    var self=gamers.filter(function(g){return own(g,'uid')===p.uid;});
    var flags={state:own(store,'state'),watcher:own(store,'isWatcher'),hotTime:own(store,'isHotTiming'),
      commonSelection:own(store,'isAddingCommonBlock'),penetrateSelection:own(store,'isUsingPenetrateProp'),canTouch:own(store,'isCanTouchBlock')};
    var hotChoice=self.length===1?own(self[0],'choosing_hot_time_block'):undefined;
    if(hotChoice!==undefined&&typeof hotChoice!=='boolean')fail('store_unavailable');
    flags.hotChoice=hotChoice===undefined?'unreported':hotChoice;
    if(hotChoice===true||self.length!==1||own(self[0],'state')!==1||flags.state!==2||flags.watcher!==false||flags.hotTime!==false||
      flags.commonSelection!==false||flags.penetrateSelection!==false||flags.canTouch!==true)fail('external_mode_active');
    return {store:store,socket:socket,flags:flags,binding:[env.window,env.document,loader,s.cc,s.root,s.board,s.trayNode,s.reserve,p.game,p.layer,store,p.uid,p.rid,p.start,socket,ws,map,env.generation]};
  }
  // StorageArea uses a sparse matrix, 80px columns and 7px layer offsets.
  // This annotates SDK-owned rows only. Touch availability stays the game's decision.
  function prepareReserves(s){
    var list=s.cards.filter(function(c){return c.zone==='reserve';}),cells=new Set();
    list.forEach(function(c){var info=own(c.metadata.block,'blockInfo'),position=own(info,'storage_info');
      c.storageVerified=false;c.hintBlockedBy=[];
      if(position===undefined||position===null){if(c.masked)c.occlusionDepth=null;return;}
      var layer=own(position,'layer'),index=own(position,'index'),cell=String(layer)+':'+String(index);
      if(!int(layer,0,511)||!int(index,0,2)||cells.has(cell)||Math.abs(c.node.x-(80*index-80))>.01||Math.abs(c.node.y-7*layer)>.01)fail('invalid_cards');
      cells.add(cell);c.storageLayer=layer;c.storageIndex=index;c.storageVerified=true;
    });
    list.sort(function(a,b){return (b.storageLayer||0)-(a.storageLayer||0);});
    list.forEach(function(c){
      if(!c.storageVerified)return;
      // Hints describe geometric stacks; they never authorize an inaccessible pick.
      c.hintBlockedBy=list.filter(function(other){return other!==c&&other.storageVerified&&other.storageIndex===c.storageIndex&&other.storageLayer>c.storageLayer;}).map(function(other){return other.id;});
      if(c.hintBlockedBy.length){var deepest=-1;c.hintBlockedBy.forEach(function(id){var b=list.find(function(v){return v.id===id;});
        if(int(b.occlusionDepth,0,512))deepest=Math.max(deepest,b.occlusionDepth);});
        c.occlusionDepth=deepest>=0?deepest+1:null;}
      else c.occlusionDepth=c.masked?null:0;
    });
  }
  function collect(s,env){
    function budget(){if(typeof env.checkBudget==='function'&&env.checkBudget()!==true)fail('time_budget');}
    budget();var c=context(s,env),store=c.store;
    if(!Array.isArray(s.cards)||!Array.isArray(s.tray)||s.cards.length+s.tray.length>MAX_CARDS||
      !s.refs||s.refs.size!==s.cards.length+s.tray.length||s.capacity!==7||s.tray.length>=7)fail('invalid_cards');
    var arrays=['pile_blocks','hand_blocks','storage_blocks'].map(function(k){return own(store,k);});
    var rows=new Map(),proof=[],epochRefs=arrays.slice();
    arrays.forEach(function(list,z){
      if(!Array.isArray(list)||list.length>MAX_CARDS)fail('store_unavailable');var flat=[];
      list.forEach(function(row){if(z===2&&Array.isArray(row)){if(row.length>MAX_CARDS)fail('invalid_cards');flat=flat.concat(row);}else flat.push(row);
        if(flat.length>MAX_CARDS)fail('invalid_cards');});
      flat.forEach(function(row){
        if(z===2&&row===null)return;
        var id=own(row,'id'),type=own(row,'type'),state=own(row,'state'),special=own(row,'special_info');
        var specialType=special?own(special,'type'):0,lock=specialType!==0?own(special,'lock_state'):0;
        if(!rawID(id)||!int(type,0,10000)||state!==z||rows.has(id)||rows.size>=MAX_CARDS||!int(specialType,0,10000)||!int(lock,0,10000))fail('invalid_cards');
        var value={type:'type:'+type,zone:['board','tray','reserve'][z],specialType:specialType,lock:lock};
        if(z===2){var storage=own(row,'storage_info');if(storage!=null){value.storageLayer=own(storage,'layer');value.storageIndex=own(storage,'index');
          if(!int(value.storageLayer,0,511)||!int(value.storageIndex,0,2))fail('invalid_cards');}}
        if(z===0){value.layer=own(row,'layer');value.row=own(row,'row');value.col=own(row,'col');
          if(!int(value.layer,0,10000)||!finite(value.row)||!finite(value.col))fail('invalid_cards');}
        rows.set(id,value);proof.push([id,type,state,specialType,lock,value.layer,value.row,value.col,value.storageLayer,value.storageIndex]);
      });
    });
    if(rows.size!==s.refs.size)fail('store_scene_mismatch');
    var ids=new Set(),rawIDs=new Set(),cards=[],all=s.cards.concat(s.tray),byID=new Map(),edges=0,unknown=new Set();
    all.forEach(function(card,index){
      if(index%16===0)budget();
      var m=card&&card.metadata,row=card&&rows.get(card.rawID);
      if(!card||!m||!row||!localID(card.id)||ids.has(card.id)||rawIDs.has(card.rawID)||s.refs.get(card.id)!==card||row.type!==card.type||row.zone!==card.zone||
        row.specialType!==m.specialType||row.lock!==m.lock||m.ruleIssue||!bool(card.available)||!bool(card.selectable)||
        !Array.isArray(card.blockedBy)||card.blockedBy.length>64||!bool(m.canTouch))fail('store_scene_mismatch');
      var component=m.block,info=own(component,'blockInfo');
      if(!object(component)||component.isValid!==true||component.node!==card.node||own(component,'canTouch')!==m.canTouch||own(component,'isTouched')!==false||
          own(info,'id')!==card.rawID||'type:'+own(info,'type')!==card.type||own(info,'state')!==['board','tray','reserve'].indexOf(card.zone))fail('store_scene_mismatch');
      var specialInfo=own(info,'special_info'),componentSpecial=specialInfo?own(specialInfo,'type'):0,componentLock=componentSpecial!==0?own(specialInfo,'lock_state'):0;
      if(componentSpecial!==row.specialType||componentLock!==row.lock)fail('store_scene_mismatch');
      if(card.zone==='board'&&(row.layer!==card.layer||Math.abs(card.x-(5*row.row-240))>.01||Math.abs(card.y-(315-4.5*row.col))>.01))fail('store_scene_mismatch');
      ids.add(card.id);rawIDs.add(card.rawID);edges+=card.blockedBy.length;if(edges>MAX_EDGES)fail('invalid_dependencies');
      if(row.specialType!==0)unknown.add(row.specialType);
      var out={id:card.id,type:card.type,zone:card.zone,order:card.zone==='tray'?s.tray.indexOf(card):card.order,blockedBy:card.blockedBy.slice().sort(),available:card.available,
        selectable:card.selectable,specialType:row.specialType,lock:row.lock,canTouch:m.canTouch};
      if(card.zone==='board'&&(!int(card.layer,0,10000)||!finite(card.gridRow)||!finite(card.gridCol)))fail('invalid_cards');
      if(card.zone==='reserve'){
        out.masked=card.masked===true;out.storageVerified=card.storageVerified===true;out.hintBlockedBy=(card.hintBlockedBy||[]).slice().sort();out.occlusionDepth=card.occlusionDepth;
        if(row.storageLayer!==undefined){
          if(!out.storageVerified||card.storageLayer!==row.storageLayer||card.storageIndex!==row.storageIndex||Math.abs(card.node.x-(80*row.storageIndex-80))>.01||Math.abs(card.node.y-7*row.storageLayer)>.01)fail('store_scene_mismatch');
          out.storageLayer=row.storageLayer;out.storageIndex=row.storageIndex;
        }else if(out.storageVerified)fail('store_scene_mismatch');
      }
      if(!int(out.order,0,511))fail('invalid_cards');
      if(card.zone==='board'){out.layer=card.layer;out.row=card.gridRow;out.col=card.gridCol;}
      else if(out.blockedBy.length)fail('invalid_dependencies');
      cards.push(out);byID.set(out.id,out);
    });
    var geometryKey=JSON.stringify(cards.map(function(c){return [c.id,c.zone,c.layer,c.row,c.col,c.blockedBy];})),checkGeometry=geometryKey!==verifiedGeometry;
    var indegree=new Map(),covers=new Map();
    cards.forEach(function(card,index){
      if(index%16===0)budget();
      if(checkGeometry&&card.zone==='board'){var expected=cards.filter(function(other){return other.zone==='board'&&other.layer>card.layer&&Math.abs(other.row-card.row)<16&&Math.abs(other.col-card.col)<20;}).map(function(other){return other.id;}).sort();
        if(JSON.stringify(expected)!==JSON.stringify(card.blockedBy))fail('invalid_dependencies');}
      var seen=new Set();indegree.set(card.id,card.blockedBy.length);
      card.blockedBy.forEach(function(id){var parent=byID.get(id);
        if(!parent||parent.id===card.id||parent.zone!=='board'||card.zone!=='board'||parent.layer<=card.layer||seen.has(id))fail('invalid_dependencies');
        seen.add(id);if(!covers.has(id))covers.set(id,[]);covers.get(id).push(card.id);});
      if(card.available&&(card.blockedBy.length||!card.selectable||!card.canTouch||card.zone==='tray'))fail('invalid_dependencies');
    });
    var queue=cards.filter(function(card){return indegree.get(card.id)===0;}).map(function(card){return card.id;}),count=0;
    while(count<queue.length){var key=queue[count++];(covers.get(key)||[]).forEach(function(id){var n=indegree.get(id)-1;indegree.set(id,n);if(!n)queue.push(id);});}
    if(count!==cards.length)fail('invalid_dependencies');verifiedGeometry=geometryKey;
    var inventory=own(store,'props_blocks');if(!Array.isArray(inventory)||inventory.length>16)fail('invalid_inventory');
    var stockIDs=new Set(),stock=[];
    inventory.forEach(function(row){var id=own(row,'id'),type=own(row,'type'),number=own(row,'count');
      if(!rawID(id)||stockIDs.has(id)||!int(type,0,10000)||!int(number,0,1000000))fail('invalid_inventory');stockIDs.add(id);
      stock.push({type:type,count:number,recognized:type<=5});proof.push(['stock',id,type,number]);});
    stock.sort(function(a,b){return a.type-b.type||a.count-b.count;});epochRefs.push(inventory);
    var task=own(store,'task_info'),mission;
    if(task===null)mission={status:'none'};
    else {var target=own(task,'target_block_type'),done=own(task,'current_num'),total=own(task,'total_num');
      if(!object(task)||!int(target,1,10000)||!int(total,1,1000000)||!int(done,0,total))fail('invalid_mission');
      if(s.mission&&(s.mission.targetType!==target||s.mission.current!==done||s.mission.total!==total))fail('invalid_mission');
      mission={status:done===total?'complete':'observed',targetType:target,current:done,total:total};}
    var common=own(store,'common_blocks'),slots=[],shared=own(c.store===s.playState.store?s.playState.layer:null,'CommonStore');
    if(!Array.isArray(common)||common.length>3)fail('invalid_slots');epochRefs.push(common);
    var selfIndex=own(shared,'selfIndex'),items=own(shared,'itemsNode'),nodes=items&&items.children;
    if(common.length&&(!shared||shared.isValid!==true||s.cc.js.getClassName(shared)!=='CommonStore'||!int(selfIndex,0,common.length-1)||!Array.isArray(nodes)||nodes.length<common.length||nodes.length>3||!s.records||!s.records.has(shared.node)))fail('invalid_slots');
    common.forEach(function(row,i){var lock=own(row,'lock_state'),block=own(row,'block'),id=own(block,'id'),empty=block==null||id==='';
      if(!int(lock,0,3)||!empty&&(!rawID(id)||!int(own(block,'type'),0,10000)))fail('invalid_slots');
      var node=nodes[i];if(!node||node.isValid!==true||!s.records.has(node)||node.parent!==items||typeof node.getComponents!=='function')fail('invalid_slots');
      var components=node.getComponents(s.cc.Component);
      if(!Array.isArray(components)||components.length>32)fail('invalid_slots');
      var matches=components.filter(function(item){return s.cc.js.getClassName(item)==='CommonStoreItem';});
      if(matches.length!==1||matches[0].node!==node||matches[0].isValid!==true||own(matches[0],'commonBlock')!==row||own(matches[0],'commonStore')!==shared||
        own(matches[0],'isSelf')!==(i===selfIndex)||own(matches[0],'isEmpty')!==empty)fail('invalid_slots');
      var slotChildren=node.children;if(!Array.isArray(slotChildren)||slotChildren.length>32)fail('invalid_slots');
      var blocks=[];slotChildren.forEach(function(child){if(!child||!s.records.has(child))return;
        var list=child.getComponents(s.cc.Component);if(!Array.isArray(list)||list.length>32)fail('invalid_slots');
        list.forEach(function(component){if(s.cc.js.getClassName(component)==='Block')blocks.push(component);});});
      if(empty?blocks.length!==0:blocks.length!==1||own(blocks[0],'blockInfo')!==block||own(block,'state')!==3)fail('invalid_slots');
      var slotCard=null;
      if(!empty){var special=own(block,'special_info'),specialType=special?own(special,'type'):0,cardLock=specialType!==0?own(special,'lock_state'):0;
        if(!int(specialType,0,10000)||!int(cardLock,0,10000)||rawIDs.has(id))fail('invalid_slots');rawIDs.add(id);
        if(specialType!==0)unknown.add(specialType);
        slotCard={id:'s'+i,type:'type:'+own(block,'type'),state:3,specialType:specialType,lock:cardLock};}
      slots.push({index:i,isSelf:i===selfIndex,empty:empty,lock:lock,type:slotCard?slotCard.type:null,card:slotCard});
      proof.push(['slot',i,id,lock,empty,slotCard&&slotCard.specialType,slotCard&&slotCard.lock]);});
    var mode=own(store,'mode'),totalNum=own(store,'total_num');
    if(!int(mode,0,10000)||!int(totalNum,0,1000000))fail('store_unavailable');
    var zones={board:[],tray:[],reserve:[]};cards.forEach(function(card){zones[card.zone].push(card);});
    zones.board.sort(function(a,b){return a.id.localeCompare(b.id);});zones.reserve.sort(function(a,b){return a.order-b.order;});zones.tray.sort(function(a,b){return a.order-b.order;});
    var sharedCards=slots.filter(function(slot){return !slot.empty;});if(cards.length+sharedCards.length>MAX_CARDS)fail('invalid_cards');
    var data={schema:'SDKtools.AlpacaPhaseSnapshot.v1',capacity:7,matchSize:3,cards:zones.board.concat(zones.reserve),tray:zones.tray,
      mission:mission,inventory:stock,sharedSlots:slots,mode:mode,totalNum:totalNum,flags:c.flags,
      rules:{ordinaryMatch:'triple',trayPolicy:'group_insert_then_match',ordinaryGeometry:'alpaca_2_4_4',
        reservePolicy:'original_touch_state_sparse_storage',slotPolicy:'self_empty_lock_zero',specialPolicy:'nonzero_lock_blocked',modeRecognized:mode===0||mode===1,
        allRecognized:(mode===0||mode===1)&&unknown.size===0&&stock.every(function(row){return row.recognized;}),unknownSpecialTypes:Array.from(unknown).sort(function(a,b){return a-b;})},
      counts:{board:zones.board.length,tray:zones.tray.length,reserve:zones.reserve.length,types:new Set(cards.map(function(card){return card.type;}).concat(sharedCards.map(function(slot){return slot.type;}))).size,
        dependencyEdges:edges,inventoryRows:stock.length,sharedSlots:slots.length,sharedCards:sharedCards.length}};
    var canonical=JSON.stringify(data),sourceStamp=JSON.stringify(proof);
    if(canonical.length>MAX_BYTES)fail('size_limit');
    // Reject binding/array replacement during acquisition. Store fields use data descriptors only.
    budget();var after=context(s,env);if(!same(c.binding,after.binding)||arrays.some(function(a,i){return a!==own(store,['pile_blocks','hand_blocks','storage_blocks'][i]);})||
      inventory!==own(store,'props_blocks')||task!==own(store,'task_info')||common!==own(store,'common_blocks'))fail('context_changed');
    return {data:data,key:canonical+'|'+sourceStamp,binding:c.binding,epoch:epochRefs};
  }
  function observe(s,env,time){
    if(typeof time!=='number'||!isFinite(time)||time<0||lastTime!==null&&time<lastTime){invalidate('clock_invalid');lastTime=time;return false;}lastTime=time;
    var read;try{read=collect(s,env);var witness=collect(s,env);
      if(read.key!==witness.key||!same(read.binding,witness.binding)||!same(read.epoch,witness.epoch))fail('context_changed');}catch(e){invalidate(reasons.indexOf(e&&e.message)>=0?e.message:'read_error');return false;}
    // Same-value Store array replacements BETWEEN coherent reads are not a
    // gameplay change. Mid-acquisition replacements still fail the witness.
    var newScope=!same(binding,read.binding),changed=newScope||!candidate||candidate.key!==read.key;
    if(changed){tickRevision();if(newScope){scope++;binding=read.binding;}current=null;
      candidate={key:read.key,data:read.data,time:time,reads:1};status='waiting';reason='snapshot_stability';return false;}
    candidate.reads++;
    if(time-candidate.time<STABLE_MS){status='waiting';reason='snapshot_stability';return false;}
    if(!current){current=freeze(Object.assign({scope:scope,revision:revision,complete:true,serverConfirmed:false},candidate.data));}
    status='ready';reason='verified';return true;
  }
  function diagnostic(){var d={version:1,status:status,reason:reason,revision:revision,scope:scope,complete:!!current,serverConfirmed:false};
    if(current){d.counts=Object.assign({},current.counts);d.allRulesRecognized=current.rules.allRecognized;}
    return d;}
  function copy(){return current?JSON.parse(JSON.stringify(current)):null;}
  return Object.freeze({observe:observe,invalidate:invalidate,diagnostic:diagnostic,current:copy,prepareReserves:prepareReserves});
})

-- SDKtools 3.21.0. Pure numerical strategy: no CS, globals, I/O or game calls.
-- Coordinates/radii/material profile come from the live observer, not pixels.
local M = {}
local sqrt,abs,min,max=math.sqrt,math.abs,math.min,math.max
local function finite(x) return type(x)=="number" and x==x and abs(x)<1e6 end
local function point(p) return type(p)=="table" and finite(p.x) and finite(p.z) end
local function dist(a,b) return sqrt((a.x-b.x)^2+(a.z-b.z)^2) end
local function unit(a,b) local d=dist(a,b);if d<1e-6 then return nil end;return {x=(b.x-a.x)/d,z=(b.z-a.z)/d},d end
local function dot(a,b) return a.x*b.x+a.z*b.z end
local function along(p,d,t) return {x=p.x+d.x*t,y=0,z=p.z+d.z*t} end
local function segmentDistance(p,a,b)
 local dx,dz=b.x-a.x,b.z-a.z;local n=dx*dx+dz*dz
 local t=n>1e-10 and max(0,min(1,((p.x-a.x)*dx+(p.z-a.z)*dz)/n)) or 0
 return dist(p,{x=a.x+t*dx,z=a.z+t*dz})
end
local function clear(s,a,b,ignore1,ignore2)
 local margin=1e6
 for _,ball in ipairs(s.balls) do
  if ball.active and not ball.potted and ball.tag~=ignore1 and ball.tag~=ignore2 then
   local gap=segmentDistance(ball.world,a,b)-s.radius-(ball.radius or s.radius)
   if gap<.012 then return false,gap end
   margin=min(margin,gap)
  end
 end
 return true,margin
end
-- Original launch: AddForceAtPosition(0.031*p*sqrt(p/reference), Impulse).
-- Scalar contact-slip integration, then linear/angular damping. This is NOT a
-- replacement for PhysX's multi-contact solver or the game's Lua corrections.
function M.launch(p,reference,mass) return .031*p*sqrt(p/reference)/mass end
function M.flight(speed,surface,s,travel,seconds)
 local v,w,x,t=speed,surface or 0,0,0
 local damp=max(0,1-s.drag*s.dt);local adamp=max(0,1-s.angularDrag*s.dt)
 for _=1,750 do
  if v*v<s.stopSquared then v=0 end
  if abs(w)/s.radius<.2 then w=0 end
  if v==0 and w==0 then break end
  local slip=v+w
  local impulse=min(abs(slip)/(1/s.mass+s.radius*s.radius/s.inertia),s.mu*s.mass*9.81*s.dt)
  if slip<0 then impulse=-impulse end
  v=(v-impulse/s.mass)*damp;w=(w-impulse*s.radius*s.radius/s.inertia)*adamp
  local dx=max(0,v)*s.dt
  if travel and x+dx>=travel then return max(0,v),travel,t+s.dt end
  x=x+dx;t=t+s.dt
  if seconds and t>=seconds-1e-8 then return max(0,v),x,t end
 end
 if travel then return 0,x,t end
 return x,v,t
end
local function railPoint(a,b,axis,value,lo,hi)
 local reflected={x=b.x,z=b.z};reflected[axis]=2*value-b[axis]
 local denominator=reflected[axis]-a[axis]
 if abs(denominator)<1e-8 then return nil end
 local t=(value-a[axis])/denominator
 if t<=.001 or t>=.999 then return nil end
 local p={x=a.x+t*(reflected.x-a.x),y=0,z=a.z+t*(reflected.z-a.z)}
 local v=axis=="x" and p.z or p.x
 if v<lo+.38 or v>hi-.38 then return nil end
 return p
end
local function legal(s,ball,count)
 if ball.tag==1 or not ball.active or ball.potted then return false end
 if s.phase==3 then return ball.number~=8 end
 if s.group==0 then return ball.number~=8 or count==0 end
 if ball.number==8 then return count==0 end
 return s.group==1 and ball.number>=1 and ball.number<=7 or s.group==2 and ball.number>=9 and ball.number<=15
end
function M.plan(s)
 if type(s)~="table" or not point(s.white) or type(s.balls)~="table" or #s.balls>16
  or type(s.pockets)~="table" or #s.pockets~=6 or not finite(s.radius) or s.radius<.1 or s.radius>.3
  or not finite(s.mass) or s.mass<=0 or not finite(s.inertia) or s.inertia<=0
  or not finite(s.maximum) or s.maximum<=0 or not finite(s.reference) or s.reference<=0
  or not finite(s.deadzone) or s.deadzone<0 or s.deadzone>=1
  or not finite(s.dt) or abs(s.dt-.02)>1e-6 or s.drag~=.5 or s.angularDrag~=.5
  or s.mu~=1 or s.stopSquared~=.008 or not ({[0]=true,[1]=true,[2]=true})[s.group]
  or not ({[3]=true,[5]=true,[7]=true})[s.phase] then return nil,"strategy_profile_invalid" end
 for _,b in ipairs(s.balls) do if b.active and not point(b.world) then return nil,"invalid_strategy_ball" end end
 for _,p in ipairs(s.pockets) do if not point(p) then return nil,"invalid_strategy_pocket" end end
 local count=0
 for _,b in ipairs(s.balls) do
  if b.active and not b.potted and b.number~=0 and b.number~=8 and
   (s.group==0 or s.group==1 and b.number<=7 or s.group==2 and b.number>=9) then count=count+1 end
 end
 local candidates,checks={},0
 local function offer(ball,pocket,bank)
  checks=checks+1
  local first=bank or pocket;local objectDir,objectLength=unit(ball.world,first)
  if not objectDir then return end
  if bank then objectLength=objectLength+dist(bank,pocket) end
  local ghost=along(ball.world,objectDir,-2*s.radius)
  local shot,cueLength=unit(s.white,ghost)
  if not shot or cueLength<.02 or ghost.x<s.bounds.xmin or ghost.x>s.bounds.xmax
   or ghost.z<s.bounds.zmin or ghost.z>s.bounds.zmax then return end
  local cut=dot(shot,objectDir)
  if cut<.38 then return end
  local ok,margin=clear(s,s.white,ghost,1,ball.tag);if not ok then return end
  local ok2,m2=clear(s,ball.world,first,ball.tag,1);if not ok2 then return end
  if bank then
   local ok3,m3=clear(s,bank,pocket,ball.tag,1);if not ok3 then return end;margin=min(margin,m3)
   -- A rail near any pocket mouth is not a valid one-cushion bank.
   for _,p in ipairs(s.pockets) do if dist(bank,p)<.6 then return end end
  end
  margin=min(margin,m2)
  -- Equal-mass residual direction after impact: reject an exposed scratch lane.
  local residual={x=shot.x-objectDir.x*cut,z=shot.z-objectDir.z*cut}
  local residualN=sqrt(dot(residual,residual));local scratch=0
  if residualN>.08 then
   local d={x=residual.x/residualN,z=residual.z/residualN}
   for _,p in ipairs(s.pockets) do
    local q={x=p.x-ghost.x,z=p.z-ghost.z};local ahead=dot(q,d)
    if ahead>0 and ahead<5 and abs(q.x*d.z-q.z*d.x)<s.radius*2 then scratch=1 end
   end
  end
  if scratch==1 then return end
  local score=cut*5+min(margin,.8)-.2*cueLength-.3*objectLength-(bank and 1.4 or 0)
  candidates[#candidates+1]={target=ball.tag,number=ball.number,pocket=pocket.index,ghost=ghost,
   direction={x=shot.x,y=0,z=shot.z},objectDirection={x=objectDir.x,y=0,z=objectDir.z},
   objectStart=ball.world,pocketWorld=pocket,bank=bank,cut=cut,cueLength=cueLength,
   objectLength=objectLength,score=score,kind=bank and "bank" or "direct",clearance=min(margin,20)}
 end
 for _,ball in ipairs(s.balls) do if s.phase~=3 and legal(s,ball,count) then
  for _,p in ipairs(s.pockets) do
   offer(ball,p)
   if s.phase~=3 then
    local b=s.bounds
    for _,r in ipairs({{"x",b.xmin,b.zmin,b.zmax},{"x",b.xmax,b.zmin,b.zmax},
      {"z",b.zmin,b.xmin,b.xmax},{"z",b.zmax,b.xmin,b.xmax}}) do
     local bank=railPoint(ball.world,p,r[1],r[2],r[3],r[4]);if bank then offer(ball,p,bank) end
    end
   end
  end
 end end
 table.sort(candidates,function(a,b) if a.score~=b.score then return a.score>b.score end
  if a.target~=b.target then return a.target<b.target end;return a.pocket<b.pocket end)
 local gain=s.gain or 1;local solutions={}
 -- Bound physical evaluations to 8 geometric candidates x 12 binary iterations.
 for i=1,min(#candidates,8) do
  local c=candidates[i];local low=max(.001,s.maximum*s.deadzone+.01);local high=s.maximum
  local function reaches(p)
   local v=M.launch(p,s.reference,s.mass)*gain
   local surface=.0008*(v*s.mass)*s.radius/s.inertia
   local at=M.flight(v,surface,s,c.cueLength)
   local speed=at*c.cut
   local distance=M.flight(speed,0,s)
   -- Separate cushion energy estimate. Live casts must still verify the bank.
   if c.bank then distance=distance*.8*.8 end
   return distance>=c.objectLength+.15
  end
  if reaches(high) then
   for _=1,12 do local mid=(low+high)/2;if reaches(mid) then high=mid else low=mid end end
   c.power=min(s.maximum,high*1.04);c.angle=(math.deg(math.atan(c.direction.x,c.direction.z))+360)%360
   c.launchSpeed=M.launch(c.power,s.reference,s.mass)*gain;c.evaluated=checks
   c.model="cache1084_slip_roll_1d";solutions[#solutions+1]=c
  end
 end
 -- Keep a reachable legal contact as an explicit safety/break, not a claimed pot.
 if #solutions==0 then
  for _,b in ipairs(s.balls) do if legal(s,b,count) then
   local d,l=unit(s.white,b.world)
   if d and clear(s,s.white,along(b.world,d,-2*s.radius),1,b.tag) then
    local p=s.phase==3 and s.maximum or min(s.maximum,max(s.maximum*.55,s.maximum*s.deadzone+.01))
    local speed=M.launch(p,s.reference,s.mass)*gain
    if M.flight(speed,.0008*speed*s.mass*s.radius/s.inertia,s,l-2*s.radius)>0 then
     solutions[1]={target=b.tag,number=b.number,pocket=0,kind=s.phase==3 and "break" or "safety",
      direction={x=d.x,y=0,z=d.z},angle=(math.deg(math.atan(d.x,d.z))+360)%360,power=p,
      cueLength=l-2*s.radius,ghost=along(b.world,d,-2*s.radius),launchSpeed=speed,
      score=-10,model="cache1084_slip_roll_1d",evaluated=checks};break
    end
   end
  end end
 end
 if #solutions==0 then return nil,"no_clear_legal_route" end
 return solutions,"ready"
end
return M

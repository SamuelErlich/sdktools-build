-- SDKtools 3.16. Read-only Billiard observer. The host calls this chunk on the
-- existing Lua state's owner/main thread with exactly "sample" or "stop".
-- Contracts: cache1084 CRes BiFrameLogic/BallBehavior/AuxiliaryLineBehavior.
-- Never call updateAuxiliary: it changes rebound data consumed by game physics.
local command = ...
local NULL = {}
local ARRAY = {}
local MAX_BALLS, MAX_HITS, MAX_QUERIES, MAX_SEGMENTS = 16, 96, 12, 12
local MAX_BOUNCES, MAX_DISTANCE, SPEED_LIMIT = 3, 20, 0.002
local function array() return setmetatable({}, ARRAY) end
local function finite(v) return type(v) == "number" and v == v and math.abs(v) < 1e12 end
local function integer(v, lo, hi) return finite(v) and v % 1 == 0 and v >= lo and v <= hi end
local function get(o, k)
    if o == nil or o == NULL then return nil end
    local ok, value = pcall(function() return o[k] end)
    if ok then return value end
end
local function invoke(o, name, ...)
    local f = get(o, name)
    if type(f) ~= "function" then return false, nil end
    return pcall(f, o, ...)
end
local function vector(v)
    local x, y, z = get(v, "x"), get(v, "y"), get(v, "z")
    if not finite(x) or not finite(y) or not finite(z) then return nil end
    return {x = x, y = y, z = z}
end
local function length(v) return math.sqrt(v.x*v.x + v.y*v.y + v.z*v.z) end
local function add(a, b, t) return {x=a.x+b.x*t, y=a.y+b.y*t, z=a.z+b.z*t} end
local function subtract(a, b) return {x=a.x-b.x, y=a.y-b.y, z=a.z-b.z} end
local function dot(a, b) return a.x*b.x + a.y*b.y + a.z*b.z end
local function unit(v)
    if not v then return nil end
    local n = length(v)
    if n < 1e-7 then return nil end
    return {x=v.x/n, y=v.y/n, z=v.z/n}
end
local function instance(o)
    local ok, value = invoke(o, "GetInstanceID")
    if ok and integer(value, -2147483648, 2147483647) and value ~= 0 then return value end
end
local function quote(s)
    return '"' .. s:gsub('[%z\1-\31\\"]', function(c)
        if c == '"' then return '\\"' end
        if c == '\\' then return '\\\\' end
        return string.format('\\u%04x', string.byte(c))
    end) .. '"'
end
local function encode(root)
    local seen, nodes = {}, 0
    local function visit(v, depth)
        nodes = nodes + 1
        if nodes > 16000 or depth > 12 then error("json_limit") end
        if v == NULL or v == nil then return "null" end
        local t = type(v)
        if t == "boolean" then return v and "true" or "false" end
        if t == "number" then
            if not finite(v) then error("json_nonfinite") end
            -- Avoid any locale-dependent decimal comma from a host setlocale.
            return (string.format("%.10g", v):gsub(",", "."))
        end
        if t == "string" then
            if #v > 512 then error("json_string_limit") end
            return quote(v)
        end
        if t ~= "table" or seen[v] then error("json_type") end
        seen[v] = true
        local out = {}
        if getmetatable(v) == ARRAY then
            for i=1,#v do out[i] = visit(v[i], depth+1) end
            seen[v] = nil
            return "[" .. table.concat(out, ",") .. "]"
        end
        local keys = {}
        for k in pairs(v) do
            if type(k) ~= "string" then error("json_key") end
            keys[#keys+1] = k
        end
        table.sort(keys)
        for _,k in ipairs(keys) do out[#out+1] = quote(k) .. ":" .. visit(v[k], depth+1) end
        seen[v] = nil
        return "{" .. table.concat(out, ",") .. "}"
    end
    local s = visit(root, 0)
    if #s > 65536 then error("json_bytes_limit") end
    return s
end

local state = rawget(_G, "__SDKtoolsBilliards315")
if type(state) ~= "table" or rawget(state, "version") ~= 1 then
    state = {version=1, session=0, frameRef=setmetatable({}, {__mode="v"})}
    rawset(_G, "__SDKtoolsBilliards315", state)
end
local result = {
    format="SDKtools.BilliardsLive", schema="SDKtools.BilliardsLive", schemaVersion=1,
    resourceGameId=20, gameType=1003, status="not_ready", sessionId=state.session,
    scene=NULL, frameNumber=NULL, screen=NULL, cameraInstanceId=NULL,
    balls=array(), cue=NULL, segments=array(),
    prediction={available=false, reason="not_ready", model="geometric", maxBounces=MAX_BOUNCES}
}
local function context(frame, sceneName, sceneHandle, cameraID)
    if not rawequal(state.frameRef[1], frame) or state.sceneName ~= sceneName
        or state.sceneHandle ~= sceneHandle or state.cameraID ~= cameraID then
        state.session = state.session + 1
        state.frameRef[1] = frame
        state.sceneName, state.sceneHandle, state.cameraID = sceneName, sceneHandle, cameraID
    end
    result.sessionId = state.session
end
local function stop(status, reason)
    result.status = status
    result.segments = array()
    result.prediction.available = false
    result.prediction.reason = reason
    return result
end

-- Structural evidence only. These references live for this invocation and are
-- never cached in the persistent observer state or used by the drawing path.
-- In particular, this does not execute a module, manager:get or __index function.
local function inspectEnvironment(tutorial)
    local SCAN_KEYS, MODULES, ENVIRONMENTS, UPVALUES, LOOKUP_DEPTH = 512, 24, 8, 16, 4
    local report = {
        schemaVersion=1, mode="structural_only", stage="before_contract",
        globals=array(), modules=array(), environments=array(),
        scannedKeys=0, matchedKeys=0, scanTruncated=false,
        modulesTruncated=false, environmentsTruncated=false, errorCount=0,
        limits={scanKeys=SCAN_KEYS, modules=MODULES, environments=ENVIRONMENTS,
            upvalues=UPVALUES, lookupDepth=LOOKUP_DEPTH}
    }
    state.environmentSequence = math.min((state.environmentSequence or 0)+1, 2147483647)
    report.sequence = state.environmentSequence
    local function markError()
        report.errorCount = math.min(report.errorCount+1, 128)
    end
    local function lookup(object, key)
        local detail = {rawType="nil", resolvedType="nil", lookup="absent", indexType="none", depth=0}
        if type(object) ~= "table" then
            detail.lookup="non_table"
            return nil, detail
        end
        local visited, cursor = {}, object
        for depth=0,LOOKUP_DEPTH do
            detail.depth=depth
            for i=1,#visited do
                if rawequal(visited[i],cursor) then
                    detail.lookup="cycle"
                    return nil, detail
                end
            end
            visited[#visited+1]=cursor
            local value=rawget(cursor,key)
            if depth==0 then detail.rawType=type(value) end
            if value~=nil then
                detail.resolvedType=type(value)
                detail.lookup=depth==0 and "raw" or "metatable_table"
                return value, detail
            end
            local ok, meta=pcall(getmetatable,cursor)
            if not ok then
                markError();detail.lookup="error"
                return nil, detail
            end
            if meta==nil then return nil, detail end
            if type(meta)~="table" then
                detail.indexType="protected";detail.lookup="protected_metatable"
                return nil, detail
            end
            local index=rawget(meta,"__index")
            detail.indexType=type(index)
            if type(index)=="function" then
                detail.lookup="function_index_blocked"
                return nil, detail
            end
            if index==nil then return nil, detail end
            if type(index)~="table" then
                detail.lookup="non_table"
                return nil, detail
            end
            if depth==LOOKUP_DEPTH then
                detail.lookup="depth_limit"
                return nil, detail
            end
            cursor=index
        end
    end
    for _,name in ipairs({"Core","Enum","Const","BiLogic","package","debug","CS"}) do
        local _, detail=lookup(_G,name)
        detail.name=name
        report.globals[#report.globals+1]=detail
    end
    local packageValue=lookup(_G,"package")
    local loaded=lookup(packageValue,"loaded")
    local debugValue=lookup(_G,"debug")
    local getupvalue=lookup(debugValue,"getupvalue")
    report.packageType,report.loadedType=type(packageValue),type(loaded)
    report.debugType,report.getupvalueType=type(debugValue),type(getupvalue)
    local environments={}
    local function observedGameType(value)
        local gameType=lookup(value,"GameType")
        if integer(gameType,0,2147483647) then return gameType end
    end
    local function addEnvironment(env, source)
        for index=1,#environments do
            if rawequal(environments[index],env) then return index end
        end
        if #environments>=ENVIRONMENTS then
            report.environmentsTruncated=true
            return nil
        end
        local index=#environments+1
        environments[index]=env
        local core=lookup(env,"Core")
        local enum=lookup(env,"Enum")
        local constants=lookup(env,"Const")
        local biLogic=lookup(env,"BiLogic")
        local manager=lookup(core,"logicMgr")
        local enumBilliard=lookup(enum,"Billiard")
        local constBilliard=lookup(constants,"Billiard")
        local enumGameType=observedGameType(enumBilliard)
        local constGameType=observedGameType(constBilliard)
        local logic=lookup(enumBilliard,"Logic")
        local frameDescriptor=lookup(logic,"frame")
        local tutorialDescriptor=lookup(logic,"tutorial")
        local descriptor=frameDescriptor
        if tutorial then descriptor=tutorialDescriptor end
        report.environments[#report.environments+1]={
            index=index, source=source, sameAsGlobal=rawequal(env,_G),
            coreType=type(core), enumType=type(enum), constType=type(constants),
            biLogicType=type(biLogic), managerType=type(manager),
            enumGameType=enumGameType, constGameType=constGameType,
            frameDescriptorType=type(frameDescriptor), tutorialDescriptorType=type(tutorialDescriptor),
            contractValid=enumGameType==1003 and constGameType==1003
                and type(lookup(manager,"get"))=="function" and descriptor~=nil and descriptor~=false
        }
        return index
    end
    addEnvironment(_G,"_G")
    local function moduleNameAllowed(name)
        if type(name)~="string" or #name>96 or #name==0 then return false end
        if not (name:match("^Billiard[/%.]") or name:match("^billiard[/%.]")) then return false end
        if name:find("[^A-Za-z0-9_/%.]") or name:find("[/%.][/%.]")
            or name:find("[/%.]$") then return false end
        return true
    end
    local recorded={}
    local function addModule(name,value,source)
        if value==nil or recorded[name] then return end
        recorded[name]=true
        report.matchedKeys=report.matchedKeys+1
        if #report.modules>=MODULES then
            report.modulesTruncated=true
            return
        end
        local row={name=name,valueType=type(value),source=source,
            gameType=observedGameType(value),upvaluesScanned=0,environmentStatus="not_function"}
        report.modules[#report.modules+1]=row
        if type(value)~="function" then return end
        if type(getupvalue)~="function" then row.environmentStatus="no_debug";return end
        for upvalueIndex=1,UPVALUES do
            local ok, name, env=pcall(getupvalue,value,upvalueIndex)
            if not ok then
                markError();row.environmentStatus="error";return
            end
            if name==nil then row.environmentStatus="no_env";return end
            row.upvaluesScanned=upvalueIndex
            if name=="_ENV" then
                if type(env)~="table" then row.environmentStatus="non_table_env";return end
                row.environmentIndex=addEnvironment(env,row.name)
                row.environmentStatus=row.environmentIndex and "found" or "env_limit"
                return
            end
        end
        row.environmentStatus="upvalue_limit"
    end
    if type(loaded)=="table" then
        for _,name in ipairs({"Billiard/Lua/Const/Enum","Billiard/Lua/Const/Const",
            "Billiard/Lua/Const/Init","Billiard/Lua/Loader","billiard/lua/const/enum",
            "billiard/lua/const/const","billiard/lua/const/init","billiard/lua/loader"}) do
            -- Existing entries only: do not ask a module-loader metatable.
            addModule(name,rawget(loaded,name),"known_key")
        end
        local key=nil
        for _=1,SCAN_KEYS do
            local ok, nextKey, value=pcall(next,loaded,key)
            if not ok then markError();break end
            if nextKey==nil then break end
            key=nextKey
            report.scannedKeys=report.scannedKeys+1
            if moduleNameAllowed(key) then addModule(key,value,"loaded_scan") end
            -- No 513th lookup: at the boundary the scan is conservatively
            -- incomplete, including a table that happens to have 512 entries.
            if report.scannedKeys==SCAN_KEYS then report.scanTruncated=true end
        end
    end
    return report
end
local function sample()
    if command == "stop" then
        state.session = state.session + 1
        state.frameRef[1] = nil
        state.sceneName, state.sceneHandle, state.cameraID = nil, nil, nil
        result.sessionId = state.session
        return stop("stopped", "stopped")
    end
    if command ~= "sample" then return stop("unsupported", "unknown_command") end

    local CS = rawget(_G, "CS")
    local engine = get(CS, "UnityEngine")
    local sceneManager = get(get(engine, "SceneManagement"), "SceneManager")
    local activeScene = get(sceneManager, "GetActiveScene")
    result.gates = {
        hasCore=type(rawget(_G,"Core"))=="table",
        hasEnum=type(rawget(_G,"Enum"))=="table",
        hasConst=type(rawget(_G,"Const"))=="table",
        hasUnityEngine=engine~=nil,
        hasSceneAPI=type(activeScene)=="function"
    }
    if type(activeScene) ~= "function" then
        context(nil, nil, nil, nil)
        return stop("unsupported", "scene_api_unavailable")
    end
    local okScene, scene = pcall(activeScene)
    local sceneName, sceneHandle = get(scene, "name"), get(scene, "handle")
    if not okScene or type(sceneName) ~= "string" or #sceneName > 120
        or not integer(sceneHandle, -2147483648, 2147483647) then
        context(nil, nil, nil, nil)
        return stop("not_ready", "invalid_scene")
    end
    result.scene = {name=sceneName, handle=sceneHandle}
    if sceneName ~= "BilliardInGame" and sceneName ~= "BilliardTutorial" then
        context(nil, sceneName, sceneHandle, nil)
        return stop("wrong_scene", "scene_not_billiards")
    end
    if get(scene, "isLoaded") ~= true then
        context(nil, sceneName, sceneHandle, nil)
        return stop("not_ready", "scene_not_loaded")
    end

    result.environment=inspectEnvironment(sceneName=="BilliardTutorial")

    local enum = get(rawget(_G, "Enum"), "Billiard")
    local constants = get(rawget(_G, "Const"), "Billiard")
    local manager = get(rawget(_G, "Core"), "logicMgr")
    if get(enum, "GameType") ~= 1003 or get(constants, "GameType") ~= 1003 then
        context(nil, sceneName, sceneHandle, nil)
        return stop("unsupported", "billiards_contract_mismatch")
    end
    local tutorial = sceneName == "BilliardTutorial"
    local descriptor = get(get(enum, "Logic"), tutorial and "tutorial" or "frame")
    if not descriptor then return stop("unsupported", "logic_descriptor_missing") end
    local okFrame, frame = invoke(manager, "get", descriptor)
    if not okFrame or type(frame) ~= "table" or get(frame, "Destroyed") == true then
        context(nil, sceneName, sceneHandle, nil)
        return stop("not_ready", "frame_unavailable")
    end
    result.gates.hasFrame=true
    local camera = get(get(engine, "Camera"), "main")
    local cameraID = instance(camera)
    context(frame, sceneName, sceneHandle, cameraID)
    result.cameraInstanceId = cameraID or NULL
    result.gates.hasCamera=cameraID~=nil
    if not cameraID or get(camera, "isActiveAndEnabled") ~= true
        or get(camera, "orthographic") ~= true then
        return stop("not_ready", "camera_unavailable")
    end
    local cameraGO = get(camera, "gameObject")
    if get(get(cameraGO, "scene"), "handle") ~= sceneHandle then
        return stop("not_ready", "camera_scene_mismatch")
    end
    local unityScreen, unityTime = get(engine, "Screen"), get(engine, "Time")
    local width, height = get(unityScreen, "width"), get(unityScreen, "height")
    local frameNumber = get(unityTime, "frameCount")
    if not integer(width, 1, 32768) or not integer(height, 1, 32768)
        or not integer(frameNumber, 0, 2147483647) then
        return stop("not_ready", "screen_or_clock_unavailable")
    end
    result.screen, result.frameNumber = {width=width, height=height}, frameNumber
    local vectorType = get(engine, "Vector3")
    local function unityVector(v) return vectorType(v.x, v.y, v.z) end
    local function project(v)
        local ok, p = invoke(camera, "WorldToScreenPoint", unityVector(v))
        p = ok and vector(p) or nil
        if not p or p.z <= 0 or math.abs(p.x) > width*8 or math.abs(p.y) > height*8 then return nil end
        return {x=p.x, y=p.y, depth=p.z}
    end
    local cameraRight = unit(vector(get(get(camera, "transform"), "right")))
    if not cameraRight then return stop("not_ready", "camera_basis_unavailable") end
    local frameBalls = get(frame, "balls")
    if type(frameBalls) ~= "table" then return stop("not_ready", "balls_unavailable") end
    local entries = 0
    for k in next, frameBalls do
        entries = entries + 1
        if entries > MAX_BALLS or not integer(k, 1, MAX_BALLS) then
            return stop("not_ready", "invalid_ball_collection")
        end
    end
    if entries == 0 then return stop("not_ready", "balls_empty") end
    local ballByTag, ballByGO, ballByCollider = {}, {}, {}
    local moving, white, observed = get(frame, "ballsInMovement") == true, nil, 0
    local angularMoving = false
    for i=1,MAX_BALLS do
        local ball = rawget(frameBalls, i)
        if ball ~= nil then
            local tag, number = get(ball, "ballTag"), get(ball, "ballNum")
            if not integer(tag, 1, MAX_BALLS) or number ~= tag-1 or ballByTag[tag] then
                return stop("not_ready", "invalid_ball_identity")
            end
            local active, potted = get(ball, "ballActive"), get(ball, "poted")
            if type(active) ~= "boolean" or type(potted) ~= "boolean" then
                return stop("not_ready", "invalid_ball_flags")
            end
            local row = {tag=tag, number=number, active=false, potted=potted,
                world=NULL, screen=NULL, speed=NULL, radiusPixels=NULL}
            local record = {row=row, source=ball}
            ballByTag[tag] = record
            result.balls[#result.balls+1] = row
            local go, tr, rb, collider = get(ball,"gameObject"), get(ball,"transform"),
                get(ball,"rigidbody"), get(ball,"collider")
            local gid, cid = instance(go), instance(collider)
            if active and not potted then
                if not gid or not cid or get(go,"activeInHierarchy") ~= true
                    or get(collider,"enabled") ~= true or get(collider,"isTrigger") ~= false
                    or get(get(go,"scene"),"handle") ~= sceneHandle then
                    return stop("not_ready", "active_ball_object_unavailable")
                end
                if ballByGO[gid] or ballByCollider[cid] then
                    return stop("not_ready", "reused_ball_object")
                end
                local pos, vel, angular = vector(get(tr,"position")), vector(get(rb,"velocity")),
                    vector(get(rb,"angularVelocity"))
                local radius, scale = get(collider,"radius"), vector(get(tr,"lossyScale"))
                if not pos or not vel or not angular or not finite(radius) or not scale
                    or math.abs(pos.x)>20 or math.abs(pos.y)>.5 or math.abs(pos.z)>20 then
                    return stop("not_ready", "invalid_ball_geometry")
                end
                radius = radius * math.max(math.abs(scale.x),math.abs(scale.y),math.abs(scale.z))
                if radius < .1 or radius > .3 then return stop("not_ready", "ball_radius_mismatch") end
                local screenPos, screenEdge = project(pos), project(add(pos,cameraRight,radius))
                if not screenPos or not screenEdge then return stop("not_ready", "ball_projection_failed") end
                local radiusPixels=math.sqrt((screenPos.x-screenEdge.x)^2+(screenPos.y-screenEdge.y)^2)
                if radiusPixels<.1 or radiusPixels>math.max(width,height)/4 then
                    return stop("not_ready", "invalid_projected_radius")
                end
                row.active, row.world, row.screen, row.speed, row.radiusPixels =
                    true, pos, screenPos, length(vel), radiusPixels
                record.position, record.radius, record.colliderID, record.gameObjectID = pos,radius,cid,gid
                ballByGO[gid],ballByCollider[cid]=record,record
                observed = observed + 1
                moving = moving or row.speed > SPEED_LIMIT or get(ball,"ballInMovement") == true
                angularMoving = angularMoving or length(angular) > .2
                if tag == 1 then white = record end
            end
        end
    end
    table.sort(result.balls,function(a,b) return a.tag<b.tag end)
    if not white or observed == 0 then return stop("not_ready", "white_ball_unavailable") end
    if moving or angularMoving then return stop("moving", "balls_moving") end
    if not tutorial and (get(frame,"started")~=true or get(frame,"canShot")~=true) then
        return stop("not_ready", "not_aiming")
    end
    if not tutorial and get(frame,"offlineMode")~=true then
        if get(frame,"isServer")~=true then return stop("not_ready", "not_local_turn") end
        local turn = get(get(frame,"frameStateLogic"),"turnData")
        if get(turn,"myTurn")==false then return stop("not_ready", "not_local_turn") end
    end
    if get(get(frame,"moveBallScript"),"ballInHand")==true then
        return stop("not_ready", "white_ball_in_hand")
    end
    local view=get(frame,tutorial and "tutorialView" or "gameView")
    local cueUI=get(view,tutorial and "cue" or "cueCom")
    if get(cueUI,"visible")~=true or get(view,"cueTouchable")~=true then
        return stop("not_ready", "aim_ui_hidden")
    end
    if not tutorial then
        local uiLogic=get(frame,"uiLogic")
        local dialogName=get(get(constants,"UIName"),"CuePositionDialogPanel")
        local okDialog,visible=invoke(uiLogic,"isUIShow",dialogName)
        if type(dialogName)~="string" or not okDialog or type(visible)~="boolean" then
            return stop("not_ready", "aim_ui_unavailable")
        end
        if visible then return stop("not_ready", "cue_dialog_visible") end
    end
    local aux = get(get(frame,"auxiliaryLine"),"auxData")
    if get(aux,"shown")~=true then return stop("not_ready", "aim_not_visible") end
    local direction = unit(vector(get(frame,"curDir")))
    if not direction or math.abs(direction.y)>.001 then return stop("not_ready", "invalid_cue_direction") end
    local auxStart,auxEnd=vector(get(aux,"cueStartPos")),vector(get(aux,"cueEndPos"))
    if not auxStart or not auxEnd then return stop("not_ready","aim_snapshot_unavailable") end
    local auxDir=unit(subtract(auxEnd,auxStart))
    local dx,dz=auxStart.x-white.position.x,auxStart.z-white.position.z
    if dx*dx+dz*dz>.0001 or not auxDir or dot(auxDir,direction)<.9999 then
        return stop("not_ready","aim_snapshot_stale")
    end
    result.cue = {world=white.position, direction=direction}
    result.status="aiming"

    local physics=get(engine,"Physics")
    local sphereCastAll=get(physics,"SphereCastAll")
    if type(sphereCastAll)~="function" then return stop("unsupported", "physics_query_unavailable") end
    local triggerPolicy=get(physics,"queriesHitTriggers")
    if type(triggerPolicy)~="boolean" then return stop("unsupported","physics_trigger_policy_unknown") end
    local queries, bounces, segments, failure, openPath = 0, 0, array(), nil, false
    local function classify(collider)
        local cid=instance(collider)
        if cid and ballByCollider[cid] then return "ball",ballByCollider[cid] end
        local tr=get(collider,"transform")
        local trigger=get(collider,"isTrigger")
        for depth=1,8 do
            if not tr then break end
            local go=get(tr,"gameObject")
            if get(get(go,"scene"),"handle")~=sceneHandle then return "unknown" end
            local gid=instance(go)
            if gid and ballByGO[gid] then return "ball",ballByGO[gid] end
            local name,tag=get(go,"name"),get(go,"tag")
            if trigger==true then
                -- Exact names from the BilliardInGame and Tutorial scene assets.
                if name=="potUpLeft" or name=="potUpRight" or name=="potUpCenter"
                    or name=="potDownLeft" or name=="potDownRight" or name=="potDownCenter" then
                    return "pocket"
                end
            else
                if name=="bumpers" or tag=="bumper" then return "cushion" end
                if name=="canvas" then return "surface" end
                if tag=="Ball" then return "unknown_ball" end
            end
            tr=get(tr,"parent")
        end
        return trigger==true and "trigger" or "unknown"
    end
    local function cast(origin,dir,radius,ignoreTags)
        queries=queries+1
        if queries>MAX_QUERIES then failure="query_limit";return nil end
        -- The five-argument overload is used by the recovered game itself.
        -- If global trigger queries are disabled, request the standard explicit
        -- Collide overload without changing Physics.queriesHitTriggers.
        local ok,hits
        if triggerPolicy==false then
            local collide=get(get(engine,"QueryTriggerInteraction"),"Collide")
            if collide==nil then failure="trigger_query_unavailable";return nil end
            ok,hits=pcall(sphereCastAll,unityVector(origin),radius,unityVector(dir),MAX_DISTANCE,1,collide)
        else
            ok,hits=pcall(sphereCastAll,unityVector(origin),radius,unityVector(dir),MAX_DISTANCE,1)
        end
        if not ok then failure="physics_query_failed";return nil end
        local count=get(hits,"Length")
        if not integer(count,0,MAX_HITS) then failure="physics_hit_limit";return nil end
        local nearest
        for i=0,count-1 do
            local hit=get(hits,i)
            local distance,collider=get(hit,"distance"),get(hit,"collider")
            if not finite(distance) or distance<0 or distance>MAX_DISTANCE+.001 then
                failure="invalid_physics_hit";return nil
            end
            if collider then
                local kind,ball=classify(collider)
                local ignored=kind=="surface" or kind=="trigger" or (ball and ignoreTags[ball.row.tag])
                if not ignored and distance>.0001 and (not nearest or distance<nearest.distance) then
                    local normal=unit(vector(get(hit,"normal")))
                    nearest={distance=distance,kind=kind,ball=ball,normal=normal}
                end
            end
        end
        if nearest then
            if nearest.kind=="unknown_ball" then failure="unmapped_ball_collider";return nil end
            if nearest.kind=="unknown" then failure="unclassified_collider";return nil end
            if nearest.kind=="cushion" and (not nearest.normal or math.abs(nearest.normal.y)>.25) then
                failure="invalid_cushion_normal";return nil
            end
        end
        return nearest
    end
    local function line(kind,a,b)
        if #segments>=MAX_SEGMENTS then failure="segment_limit";return false end
        if length(subtract(b,a))<.0001 then return true end
        local from,to=project(a),project(b)
        if not from or not to then failure="guide_projection_failed";return false end
        segments[#segments+1]={kind=kind,from=from,to=to,worldFrom=a,worldTo=b}
        return true
    end
    local queue={{origin=white.position,dir=direction,radius=white.radius,kind="cue",ignore={[1]=true},allowBall=true}}
    local cursor=1
    while cursor<=#queue and not failure do
        local branch=queue[cursor];cursor=cursor+1
        local start,dir=branch.origin,branch.dir
        local hit=cast(start,dir,branch.radius,branch.ignore)
        if failure then break end
        if not hit then
            -- An open pocket/missing collider must not produce an invented rail.
            -- Keep only already bounded guide segments; no twenty-unit runaway.
            openPath=true
        else
        local finish=add(start,dir,hit.distance)
        if not line(branch.kind,start,finish) then break end
        if hit.kind=="cushion" and bounces<MAX_BOUNCES then
            bounces=bounces+1
            local reflected=unit(add(dir,hit.normal,-2*dot(dir,hit.normal)))
            if not reflected then failure="invalid_reflection";break end
            queue[#queue+1]={origin=add(finish,reflected,.001),dir=reflected,radius=branch.radius,
                kind="rebound",ignore=branch.ignore,allowBall=branch.allowBall}
        elseif hit.kind=="ball" and branch.allowBall then
            local target=hit.ball
            local normal=unit(subtract(target.position,finish))
            if not normal or math.abs(normal.y)>.05 then failure="invalid_ball_contact";break end
            local transfer=dot(dir,normal)
            if transfer<0 or transfer>1.0001 then failure="invalid_ball_contact";break end
            local objectDir=normal
            local cueDir=unit(add(dir,normal,-transfer))
            local ignored={[1]=true,[target.row.tag]=true}
            if transfer>.001 then
                queue[#queue+1]={origin=add(target.position,objectDir,.001),dir=objectDir,radius=target.radius,
                    kind="object",ignore=ignored,allowBall=false}
            end
            if cueDir and length(add(dir,normal,-transfer))>.001 then
                queue[#queue+1]={origin=add(finish,cueDir,.001),dir=cueDir,radius=white.radius,
                    kind="cue",ignore=ignored,allowBall=false}
            end
        end
        end
    end
    if failure then return stop("unsupported",failure) end
    if #segments==0 then return stop("not_ready","no_bounded_trajectory") end
    result.segments=segments
    result.prediction.available=true
    result.prediction.reason=openPath and "open_path_unknown" or "geometric_no_spin_no_timing"
    result.prediction.queries=queries
    result.prediction.bounces=bounces
    return result
end
local ok, value = pcall(sample)
if not ok then value=stop("error","observer_exception") end
local encoded, json = pcall(encode,value)
if encoded then return json end
return '{"format":"SDKtools.BilliardsLive","schema":"SDKtools.BilliardsLive","schemaVersion":1,"resourceGameId":20,"gameType":1003,"status":"error","balls":[],"segments":[],"prediction":{"available":false,"reason":"serialization_failed","model":"geometric","maxBounces":3}}'

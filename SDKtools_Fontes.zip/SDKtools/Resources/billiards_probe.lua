-- SDKtools 3.21.0. Observer plus explicit opt-in shot strategy. The host calls this chunk on the
-- existing Lua state's owner/main thread. Exact opt-ins: arm_aim/arm_auto;
-- aim/autoplay require that live-VM lease. sample/stop remain read-only.
-- Contracts: cache1084 CRes BiFrameLogic/BallBehavior/AuxiliaryLineBehavior.
-- Never call updateAuxiliary: it changes rebound data consumed by game physics.
local command = ...
local NULL = {}
local ARRAY = {}
local MAX_BALLS, MAX_HITS, MAX_QUERIES, MAX_SEGMENTS = 16, 96, 96, 48
local MAX_BOUNCES, MAX_DISTANCE, SPEED_LIMIT = 6, 20, 0.002
local MAX_EVENTS, MAX_STEPS, MAX_SECONDS = 64, 750, 15
local function array() return setmetatable({}, ARRAY) end
local function finite(v) return type(v) == "number" and v == v and math.abs(v) < 1e12 end
local function integer(v, lo, hi) return finite(v) and v % 1 == 0 and v >= lo and v <= hi end
local function get(o, k)
    if o == nil or o == NULL then return nil end
    local ok, value = pcall(function() return o[k] end)
    if ok then return value end
end
local function invoke(o, name, ...)
    local f = get(o, name)
    if type(f) ~= "function" then return false, nil end
    return pcall(f, o, ...)
end
local function vector(v)
    local x, y, z = get(v, "x"), get(v, "y"), get(v, "z")
    if not finite(x) or not finite(y) or not finite(z) then return nil end
    return {x = x, y = y, z = z}
end
local function length(v) return math.sqrt(v.x*v.x + v.y*v.y + v.z*v.z) end
local function add(a, b, t) return {x=a.x+b.x*t, y=a.y+b.y*t, z=a.z+b.z*t} end
local function subtract(a, b) return {x=a.x-b.x, y=a.y-b.y, z=a.z-b.z} end
local function dot(a, b) return a.x*b.x + a.y*b.y + a.z*b.z end
local function unit(v)
    if not v then return nil end
    local n = length(v)
    if n < 1e-7 then return nil end
    return {x=v.x/n, y=v.y/n, z=v.z/n}
end
local function cross(a,b)
    return {x=a.y*b.z-a.z*b.y,y=a.z*b.x-a.x*b.z,z=a.x*b.y-a.y*b.x}
end
local function zero() return {x=0,y=0,z=0} end
local function instance(o)
    local ok, value = invoke(o, "GetInstanceID")
    if ok and integer(value, -2147483648, 2147483647) and value ~= 0 then return value end
end
local function quote(s)
    return '"' .. s:gsub('[%z\1-\31\\"]', function(c)
        if c == '"' then return '\\"' end
        if c == '\\' then return '\\\\' end
        return string.format('\\u%04x', string.byte(c))
    end) .. '"'
end
local function encode(root)
    local seen, nodes = {}, 0
    local function visit(v, depth)
        nodes = nodes + 1
        if nodes > 16000 or depth > 12 then error("json_limit") end
        if v == NULL or v == nil then return "null" end
        local t = type(v)
        if t == "boolean" then return v and "true" or "false" end
        if t == "number" then
            if not finite(v) then error("json_nonfinite") end
            -- Avoid any locale-dependent decimal comma from a host setlocale.
            return (string.format("%.10g", v):gsub(",", "."))
        end
        if t == "string" then
            if #v > 512 then error("json_string_limit") end
            return quote(v)
        end
        if t ~= "table" or seen[v] then error("json_type") end
        seen[v] = true
        local out = {}
        if getmetatable(v) == ARRAY then
            for i=1,#v do out[i] = visit(v[i], depth+1) end
            seen[v] = nil
            return "[" .. table.concat(out, ",") .. "]"
        end
        local keys = {}
        for k in pairs(v) do
            if type(k) ~= "string" then error("json_key") end
            keys[#keys+1] = k
        end
        table.sort(keys)
        for _,k in ipairs(keys) do out[#out+1] = quote(k) .. ":" .. visit(v[k], depth+1) end
        seen[v] = nil
        return "{" .. table.concat(out, ",") .. "}"
    end
    local s = visit(root, 0)
    if #s > 65536 then error("json_bytes_limit") end
    return s
end

local state = rawget(_G, "__SDKtoolsBilliards315")
if type(state) ~= "table" or rawget(state, "version") ~= 1 then
    state = {version=1, session=0, frameRef=setmetatable({}, {__mode="v"})}
    rawset(_G, "__SDKtoolsBilliards315", state)
end
local result = {
    format="SDKtools.BilliardsLive", schema="SDKtools.BilliardsLive", schemaVersion=1,
    resourceGameId=20, gameType=1003, status="not_ready", sessionId=state.session,
    scene=NULL, frameNumber=NULL, screen=NULL, cameraInstanceId=NULL,
    balls=array(), cue=NULL, segments=array(),
    resolution={schemaVersion=1, source="none", contractStatus="missing",
        enumType="nil", constType="nil", descriptorType="nil",
        managerType="nil", managerGetType="nil", managerLookup="not_attempted",
        frameCallAttempted=false, frameCallSucceeded=false, frameType="nil"},
    prediction={available=false, reason="not_ready", model="finite", maxBounces=MAX_BOUNCES,
        chainVersion=2, events=0, queries=0, collisions=0, bounces=0,
        affectedBallCount=0, truncated=false,durationSeconds=0,stepCount=0,complete=false,
        calibration="captured_damping_sliding_v1",finalStates=array()}
}
local function context(frame, sceneName, sceneHandle, cameraID)
    if not rawequal(state.frameRef[1], frame) or state.sceneName ~= sceneName
        or state.sceneHandle ~= sceneHandle or state.cameraID ~= cameraID then
        state.session = state.session + 1
        state.frameRef[1] = frame
        state.sceneName, state.sceneHandle, state.cameraID = sceneName, sceneHandle, cameraID
    end
    result.sessionId = state.session
end
local function stop(status, reason)
    result.status = status
    result.segments = array()
    result.prediction.available = false
    result.prediction.reason = reason
    return result
end

-- Structural evidence only. These references live for this invocation and are
-- never cached in the persistent observer state or used by the drawing path.
-- In particular, this does not execute a module, manager:get or __index function.
local function inspectEnvironment(tutorial)
    local SCAN_KEYS, MODULES, ENVIRONMENTS, UPVALUES, LOOKUP_DEPTH = 512, 24, 8, 16, 4
    local report = {
        schemaVersion=1, mode="structural_only", stage="before_contract",
        globals=array(), modules=array(), environments=array(),
        scannedKeys=0, matchedKeys=0, scanTruncated=false,
        modulesTruncated=false, environmentsTruncated=false, errorCount=0,
        limits={scanKeys=SCAN_KEYS, modules=MODULES, environments=ENVIRONMENTS,
            upvalues=UPVALUES, lookupDepth=LOOKUP_DEPTH}
    }
    state.environmentSequence = math.min((state.environmentSequence or 0)+1, 2147483647)
    report.sequence = state.environmentSequence
    local function markError()
        report.errorCount = math.min(report.errorCount+1, 128)
    end
    local function lookup(object, key)
        local detail = {rawType="nil", resolvedType="nil", lookup="absent", indexType="none", depth=0}
        if type(object) ~= "table" then
            detail.lookup="non_table"
            return nil, detail
        end
        local visited, cursor = {}, object
        for depth=0,LOOKUP_DEPTH do
            detail.depth=depth
            for i=1,#visited do
                if rawequal(visited[i],cursor) then
                    detail.lookup="cycle"
                    return nil, detail
                end
            end
            visited[#visited+1]=cursor
            local value=rawget(cursor,key)
            if depth==0 then detail.rawType=type(value) end
            if value~=nil then
                detail.resolvedType=type(value)
                detail.lookup=depth==0 and "raw" or "metatable_table"
                return value, detail
            end
            local ok, meta=pcall(getmetatable,cursor)
            if not ok then
                markError();detail.lookup="error"
                return nil, detail
            end
            if meta==nil then return nil, detail end
            if type(meta)~="table" then
                detail.indexType="protected";detail.lookup="protected_metatable"
                return nil, detail
            end
            local index=rawget(meta,"__index")
            detail.indexType=type(index)
            if type(index)=="function" then
                detail.lookup="function_index_blocked"
                return nil, detail
            end
            if index==nil then return nil, detail end
            if type(index)~="table" then
                detail.lookup="non_table"
                return nil, detail
            end
            if depth==LOOKUP_DEPTH then
                detail.lookup="depth_limit"
                return nil, detail
            end
            cursor=index
        end
    end
    for _,name in ipairs({"Core","Enum","Const","BiLogic","package","debug","CS"}) do
        local _, detail=lookup(_G,name)
        detail.name=name
        report.globals[#report.globals+1]=detail
    end
    local packageValue=lookup(_G,"package")
    local loaded=lookup(packageValue,"loaded")
    local debugValue=lookup(_G,"debug")
    local getupvalue=lookup(debugValue,"getupvalue")
    report.packageType,report.loadedType=type(packageValue),type(loaded)
    report.debugType,report.getupvalueType=type(debugValue),type(getupvalue)
    local environments={}
    local function observedGameType(value)
        local gameType=lookup(value,"GameType")
        if integer(gameType,0,2147483647) then return gameType end
    end
    local function addEnvironment(env, source)
        for index=1,#environments do
            if rawequal(environments[index],env) then return index end
        end
        if #environments>=ENVIRONMENTS then
            report.environmentsTruncated=true
            return nil
        end
        local index=#environments+1
        environments[index]=env
        local core=lookup(env,"Core")
        local enum=lookup(env,"Enum")
        local constants=lookup(env,"Const")
        local biLogic=lookup(env,"BiLogic")
        local manager=lookup(core,"logicMgr")
        local enumBilliard=lookup(enum,"Billiard")
        local constBilliard=lookup(constants,"Billiard")
        local enumGameType=observedGameType(enumBilliard)
        local constGameType=observedGameType(constBilliard)
        local logic=lookup(enumBilliard,"Logic")
        local frameDescriptor=lookup(logic,"frame")
        local tutorialDescriptor=lookup(logic,"tutorial")
        local descriptor=frameDescriptor
        if tutorial then descriptor=tutorialDescriptor end
        report.environments[#report.environments+1]={
            index=index, source=source, sameAsGlobal=rawequal(env,_G),
            coreType=type(core), enumType=type(enum), constType=type(constants),
            biLogicType=type(biLogic), managerType=type(manager),
            enumGameType=enumGameType, constGameType=constGameType,
            frameDescriptorType=type(frameDescriptor), tutorialDescriptorType=type(tutorialDescriptor),
            contractValid=enumGameType==1003 and constGameType==1003
                and type(lookup(manager,"get"))=="function" and descriptor~=nil and descriptor~=false
        }
        return index
    end
    addEnvironment(_G,"_G")
    local function moduleNameAllowed(name)
        if type(name)~="string" or #name>96 or #name==0 then return false end
        if not (name:match("^Billiard[/%.]") or name:match("^billiard[/%.]")) then return false end
        if name:find("[^A-Za-z0-9_/%.]") or name:find("[/%.][/%.]")
            or name:find("[/%.]$") then return false end
        return true
    end
    local recorded={}
    local function addModule(name,value,source)
        if value==nil or recorded[name] then return end
        recorded[name]=true
        report.matchedKeys=report.matchedKeys+1
        if #report.modules>=MODULES then
            report.modulesTruncated=true
            return
        end
        local row={name=name,valueType=type(value),source=source,
            gameType=observedGameType(value),upvaluesScanned=0,environmentStatus="not_function"}
        report.modules[#report.modules+1]=row
        if type(value)~="function" then return end
        if type(getupvalue)~="function" then row.environmentStatus="no_debug";return end
        for upvalueIndex=1,UPVALUES do
            local ok, name, env=pcall(getupvalue,value,upvalueIndex)
            if not ok then
                markError();row.environmentStatus="error";return
            end
            if name==nil then row.environmentStatus="no_env";return end
            row.upvaluesScanned=upvalueIndex
            if name=="_ENV" then
                if type(env)~="table" then row.environmentStatus="non_table_env";return end
                row.environmentIndex=addEnvironment(env,row.name)
                row.environmentStatus=row.environmentIndex and "found" or "env_limit"
                return
            end
        end
        row.environmentStatus="upvalue_limit"
    end
    if type(loaded)=="table" then
        for _,name in ipairs({"Billiard/Lua/Const/Enum","Billiard/Lua/Const/Const",
            "Billiard/Lua/Const/Init","Billiard/Lua/Loader","billiard/lua/const/enum",
            "billiard/lua/const/const","billiard/lua/const/init","billiard/lua/loader"}) do
            -- Existing entries only: do not ask a module-loader metatable.
            addModule(name,rawget(loaded,name),"known_key")
        end
        local key=nil
        for _=1,SCAN_KEYS do
            local ok, nextKey, value=pcall(next,loaded,key)
            if not ok then markError();break end
            if nextKey==nil then break end
            key=nextKey
            report.scannedKeys=report.scannedKeys+1
            if moduleNameAllowed(key) then addModule(key,value,"loaded_scan") end
            -- No 513th lookup: at the boundary the scan is conservatively
            -- incomplete, including a table that happens to have 512 entries.
            if report.scannedKeys==SCAN_KEYS then report.scanTruncated=true end
        end
    end
    return report
end

-- Resolve only configuration already stored in this Lua state. The canonical
-- cached pair is the pair observed in the V3.16 device capture; scanning results
-- and an arbitrary _G.__index function are not sources for this resolver.
local function resolveContract(tutorial)
    local report=result.resolution
    local function rawField(object,key)
        if type(object)=="table" then return rawget(object,key) end
    end
    local enumNamespace,constNamespace=rawget(_G,"Enum"),rawget(_G,"Const")
    local enum,constants=rawField(enumNamespace,"Billiard"),rawField(constNamespace,"Billiard")
    local function observeValues()
        report.enumType,report.constType=type(enum),type(constants)
        local enumGameType,constGameType=rawField(enum,"GameType"),rawField(constants,"GameType")
        if integer(enumGameType,0,2147483647) then report.enumGameType=enumGameType end
        if integer(constGameType,0,2147483647) then report.constGameType=constGameType end
        return enumGameType,constGameType
    end
    -- A non-table namespace is evidence of an incompatible environment, not a
    -- missing value to silently repair. Never write or merge namespaces.
    if (enumNamespace~=nil and type(enumNamespace)~="table")
        or (constNamespace~=nil and type(constNamespace)~="table") then
        report.enumType=type(enumNamespace)~="table" and type(enumNamespace) or type(enum)
        report.constType=type(constNamespace)~="table" and type(constNamespace) or type(constants)
        report.contractStatus="invalid"
        return nil,nil,nil,"billiards_contract_mismatch"
    end
    if (enum~=nil and type(enum)~="table") or (constants~=nil and type(constants)~="table") then
        observeValues();report.contractStatus="invalid"
        return nil,nil,nil,"billiards_contract_mismatch"
    end
    local selectedSource="globals"
    if enum==nil or constants==nil then
        local packageValue=rawget(_G,"package")
        local loaded=rawField(packageValue,"loaded")
        local cachedEnum=rawField(loaded,"Billiard/Lua/Const/Enum")
        local cachedConst=rawField(loaded,"Billiard/Lua/Const/Const")
        -- A partially present namespace must identify the very same object.
        -- Equivalent-looking copies are insufficient: manager keying is unknown.
        if (enum~=nil and not rawequal(enum,cachedEnum))
            or (constants~=nil and not rawequal(constants,cachedConst)) then
            observeValues();report.contractStatus="conflict"
            return nil,nil,nil,"billiards_contract_conflict"
        end
        enum,constants=cachedEnum,cachedConst
        selectedSource="package_loaded"
    end
    local enumGameType,constGameType=observeValues()
    if enum==nil or constants==nil then
        report.contractStatus="missing"
        return nil,nil,nil,"billiards_contract_mismatch"
    end
    if type(enum)~="table" or type(constants)~="table"
        or enumGameType~=1003 or constGameType~=1003 then
        report.contractStatus="invalid"
        return nil,nil,nil,"billiards_contract_mismatch"
    end
    local descriptor=rawField(rawField(enum,"Logic"),tutorial and "tutorial" or "frame")
    report.descriptorType=type(descriptor)
    if descriptor==nil then
        report.contractStatus="missing"
        return nil,nil,nil,"logic_descriptor_missing"
    end
    local name,pkg=rawField(descriptor,"Name"),rawField(descriptor,"PkgName")
    if name=="Game/BiFrameLogic" or name=="Game/BiTutorialLogic" then report.descriptorName=name end
    if pkg=="Billiard" then report.descriptorPackage=pkg end
    if type(descriptor)~="table" or pkg~="Billiard"
        or name~=(tutorial and "Game/BiTutorialLogic" or "Game/BiFrameLogic") then
        report.contractStatus="invalid"
        return nil,nil,nil,"logic_descriptor_invalid"
    end
    report.source,report.contractStatus=selectedSource,"selected"
    return enum,constants,descriptor
end

-- Resolve the manager and its existing getter without invoking a functional
-- __index. Table inheritance is bounded and cycle checked. The selected getter
-- is still a game function; its internal lazy-loading behavior is not known.
local function structuralField(object,key)
    if type(object)~="table" then return nil,"non_table" end
    local visited,cursor={},object
    for depth=0,4 do
        for i=1,#visited do
            if rawequal(visited[i],cursor) then return nil,"cycle" end
        end
        visited[#visited+1]=cursor
        local value=rawget(cursor,key)
        if value~=nil then return value,depth==0 and "raw" or "metatable_table" end
        local ok,meta=pcall(getmetatable,cursor)
        if not ok then return nil,"error" end
        if meta==nil then return nil,"absent" end
        if type(meta)~="table" then return nil,"protected_metatable" end
        local index=rawget(meta,"__index")
        if type(index)=="function" then return nil,"function_index_blocked" end
        if index==nil then return nil,"absent" end
        if type(index)~="table" then return nil,"non_table" end
        if depth==4 then return nil,"depth_limit" end
        cursor=index
    end
end

-- Invoked only by the two exact opt-in commands. sample/stop stay read-only.
local armingCommand=command=="arm_aim" or command=="arm_auto"
local actionCommand=command=="aim" or command=="autoplay" or armingCommand
local control
if actionCommand then
 control=rawget(state,"control321")
 if type(control)~="table" then
  control={phase="observing",shots=0,calibrationSamples=0,gain=1,ref=setmetatable({},{__mode="v"})}
  state.control321=control
 end
 result.automation={schemaVersion=1,phase=control.phase,reason="observing",shots=control.shots,
  calibrationSamples=control.calibrationSamples,gain=control.gain,mode=command}
end
local function controlStatus(phase,reason,plan)
 if not actionCommand then return end
 control.phase=phase
 local a=result.automation
 a.phase,a.reason,a.shots,a.calibrationSamples,a.gain=phase,reason,control.shots,control.calibrationSamples,control.gain
 if plan then
  for _,key in ipairs({"target","number","pocket","kind","angle","power","score","model","evaluated"}) do a[key]=plan[key] end
 end
end
local function matchIdentity(frame)
 local id=get(get(frame,"gameDataLogic"),"gameId")
 if type(id)=="number" and id>0 and id<9007199254740992 and id%1==0 then return string.format("%.0f",id) end
 if type(id)=="string" and #id>=1 and #id<=32 and id:match("^[1-9]%d*$") then return id end
end
local function controlObserve(frame,engine,sceneHandle,cameraID,white,rows,diagnostics,moving)
 if not actionCommand then return true end
 local clock=get(get(engine,"Time"),"time")
 local info=get(get(frame,"gameDataLogic"),"gameInfoData")
 local logic=get(frame,"frameStateLogic");local turn=get(logic,"turnData")
 local round=get(frame,"roundId");local phase=get(logic,"frameState")
 local identity=matchIdentity(frame)
 if not identity then controlStatus("waiting","match_identity_unavailable");return false end
 if control.matchIdentity and control.matchIdentity~=identity then controlStatus("ended","match_changed");return false end
 control.matchIdentity=identity
 if control.phase=="ended" or control.phase=="uncertain" then
  controlStatus(control.phase,"manual_restart_required");return false
 end
 if control.ref[1] and (not rawequal(control.ref[1],frame) or not rawequal(control.ref[2],info)
  or control.scene~=sceneHandle or control.camera~=cameraID) then
  controlStatus("ended","context_changed");return false
 end
 if not control.ref[1] then
  control.ref[1],control.ref[2]=frame,info;control.scene,control.camera=sceneHandle,cameraID
 end
 if phase==10 or control.seenStarted and get(frame,"started")~=true then
  controlStatus("ended","match_ended");return false
 end
 if get(frame,"started")==true then control.seenStarted=true end
 if not finite(clock) or not integer(round,0,1000000) or get(turn,"turnCount")~=round
  or not ({[3]=true,[5]=true,[7]=true})[phase] then
  controlStatus("waiting","turn_contract_unavailable");return false
 end
 if control.maxRound and round<control.maxRound then controlStatus("ended","round_rewound");return false end
 control.maxRound=math.max(control.maxRound or 0,round)
 local shot=control.pending
 if shot and shot.round==round then
  if moving then
   shot.motion=true
   local elapsed=clock-shot.time
   -- Fit only a short straight free-flight segment, before ANY possible contact.
   if not shot.measured and elapsed>=.04 and elapsed<=.20 and white and
    shot.plan.cueLength>shot.plan.launchSpeed*elapsed+.2 and type(SDK321Planner)=="table" then
    shot.measured=true
    local delta=subtract(white.position,shot.origin)
    local velocity=white.row.velocity;local d=shot.plan.direction
    local forward=dot(velocity,d)
    local lateral=length(subtract(velocity,add(zero(),d,forward)))
    local speed=SDK321Planner.launch(shot.plan.power,shot.physics.reference,shot.physics.mass)
    local surface=.0008*speed*shot.physics.mass*shot.physics.radius/shot.physics.inertia
    local expected,expectedTravel=SDK321Planner.flight(speed,surface,shot.physics,nil,elapsed)
    local alongTravel=dot(delta,d)
    local lateralTravel=length(subtract(delta,add(zero(),d,alongTravel)))
    if forward>.2 and lateral<forward*.02 and length(delta)<shot.plan.cueLength-.1 and expected>.2
     and alongTravel>0 and math.abs(alongTravel-expectedTravel)<math.max(.015,expectedTravel*.05)
     and lateralTravel<.01 then
     local ratio=forward/expected
     if ratio>=.8 and ratio<=1.2 then
      control.calibrationSamples=math.min(control.calibrationSamples+1,1000)
      control.gain=math.max(.9,math.min(1.1,control.gain*.8+ratio*.2))
     end
    end
   end
   controlStatus("moving","shot_motion_observed",shot.plan);return false
  end
  if not shot.motion and clock-shot.time>1.5 then controlStatus("uncertain","shot_not_confirmed",shot.plan)
  else controlStatus("waiting","awaiting_next_turn",shot.plan) end
  return false -- Never retry a submitted intent, even when no motion was seen.
 end
 if shot and round~=shot.round then control.pending=nil;control.prepared=nil end
 return true
end
local function controlAct(frame,engine,sceneHandle,cameraID,white,rows,diagnostics,physicsReason,enum,constants,materialMatches)
 if not actionCommand then return nil end
 if type(SDK321Planner)~="table" then controlStatus("uncertain","strategy_unavailable");return result end
 if physicsReason and physicsReason~="power_below_deadzone" then
  controlStatus("waiting",physicsReason);return result
 end
 local time=get(get(engine,"Time"),"time");local nowFrame=get(get(engine,"Time"),"frameCount")
 local turn=get(get(frame,"frameStateLogic"),"turnData")
 local phase=get(get(frame,"frameStateLogic"),"frameState");local round=get(frame,"roundId")
 local group=get(frame,"selfColor")
 local view=get(frame,"gameView");local slider=get(view,"powerSld")
 if get(turn,"myTurn")~=true or get(frame,"isServer")~=true or get(frame,"offlineMode")==true
  or not integer(group,0,2) or get(view,"frameLogic")~=frame or get(slider,"touchable")~=true
  or type(get(frame,"updateCueDir"))~="function" or type(get(frame,"updatePower"))~="function"
  or type(get(view,"onPowerRelease"))~="function" or type(get(view,"updateSliderUI"))~="function" then
  controlStatus("waiting","action_contract_unavailable");return result
 end
 if get(get(frame,"gameDataLogic"),"gameInfoData")==nil then controlStatus("waiting","match_info_unavailable");return result end
 -- settingItem is the settings launcher: being touchable does not mean a
 -- dialog is open. Actual cue/modal and original power-control gates apply.
 if #rows~=16 then controlStatus("waiting","complete_rack_required");return result end
 for _,row in ipairs(rows) do
  if not row.active and not row.potted then controlStatus("waiting","table_ball_state_unresolved");return result end
 end
 local fingerprint={tostring(round),tostring(phase),tostring(group),tostring(diagnostics.sliderMax),tostring(diagnostics.powerReference)}
 for _,row in ipairs(rows) do
  fingerprint[#fingerprint+1]=row.tag..":"..tostring(row.active)..":"..tostring(row.potted)
  if row.active then fingerprint[#fingerprint+1]=string.format("%.4f,%.4f",row.world.x,row.world.z) end
 end
 fingerprint=table.concat(fingerprint,"|")
 if control.board~=fingerprint or control.mode~=command then
  control.board,control.mode=fingerprint,command;control.stableAt=time;control.stableFrame=nowFrame;control.prepared=nil
  controlStatus("planning","stabilizing");return result
 end
 if time-control.stableAt<.15 or nowFrame<=control.stableFrame then controlStatus("planning","stabilizing");return result end
 local names={potUpLeft=true,potUpRight=true,potUpCenter=true,potDownLeft=true,potDownRight=true,potDownCenter=true}
 local physics=get(engine,"Physics");local cast=get(physics,"SphereCastAll")
 local trigger=get(get(engine,"QueryTriggerInteraction"),"Collide")
 if type(cast)~="function" or trigger==nil then controlStatus("waiting","route_query_unavailable");return result end
 local queries=0
 local function nearest(origin,dir,ignore,includeSurface)
  queries=queries+1;if queries>24 then return nil end
  local found,hits=pcall(cast,engine.Vector3(origin.x,origin.y or 0,origin.z),white.radius,
   engine.Vector3(dir.x,dir.y or 0,dir.z),20,524289,trigger)
  local n=get(hits,"Length");if not found or not integer(n,0,96) then return nil end
  local first
  for i=0,n-1 do
   local hit=get(hits,i);local distance=get(hit,"distance");local col=get(hit,"collider")
   if not finite(distance) or distance<0 or distance>20 then return nil end
   local id=instance(col);local record
   for _,b in ipairs(rows) do if b.active and instance(get(get(frame,"balls")[b.tag],"collider"))==id then record=b;break end end
   local kind=record and (record.tag==ignore and "ignore" or "ball") or "unknown"
   local pocketName
   local p=get(col,"transform")
   for _=1,8 do
    if not p then break end
    local go=get(p,"gameObject");if get(get(go,"scene"),"handle")~=sceneHandle then return nil end
    local name,tag=get(go,"name"),get(go,"tag")
    if not record then
     if names[name] and get(col,"isTrigger")==true then kind="pocket";pocketName=name
     elseif name=="bumpers" or tag=="bumper" then kind="cushion"
     elseif name=="canvas" then kind=includeSurface and "surface" or "ignore" end
    end
    p=get(p,"parent")
   end
   if kind~="ignore" then
    if not first or distance<first.distance-.00001 then
     first={kind=kind,tag=record and record.tag,distance=distance,normal=vector(get(hit,"normal")),material=get(col,"sharedMaterial"),pocket=pocketName}
    elseif math.abs(distance-first.distance)<.00001 and (kind~=first.kind or (record and record.tag~=first.tag)) then return nil end
   end
  end
  return first
 end
 local function validMaterial(material,friction,restitution,staticFriction)
  return material~=nil and get(material,"frictionCombine")~=nil and get(material,"bounceCombine")~=nil
   and materialMatches(material,friction,restitution,staticFriction)
 end
 local surfaceHit=nearest(add(white.position,{x=0,y=1,z=0},.5),{x=0,y=-1,z=0},1,true)
 if not surfaceHit or surfaceHit.kind~="surface" or surfaceHit.distance<.3 or surfaceHit.distance>.7
  or not surfaceHit.normal or surfaceHit.normal.y<.99 or not validMaterial(surfaceHit.material,1,0) then
  controlStatus("waiting","live_table_material_mismatch");return result
 end
 local prepared=control.prepared
 if prepared then
  local plan=prepared.plan
  if command=="aim" then controlStatus("aimed","aim_only_no_shot",plan);return result end
  if time-prepared.time>4 then control.prepared=nil;controlStatus("waiting","aim_expired");return result end
  local dir=unit(vector(get(frame,"curDir")))
  if not dir or dot(dir,plan.direction)<.999999 or math.abs(get(slider,"value")-plan.power)>.001 then
   controlStatus("uncertain","prepared_inputs_changed",plan);return result
  end
  if nowFrame<=prepared.frame or time-prepared.time<.3 then controlStatus("aimed","confirming_aim",plan);return result end
  local fresh=nearest(white.position,plan.direction,1)
  if not fresh or fresh.kind~="ball" or fresh.tag~=plan.target or math.abs(fresh.distance-plan.cueLength)>.05 then
   controlStatus("uncertain","route_changed_before_release",plan);return result
  end
  -- Latch BEFORE the original release method: an exception is an uncertain shot.
  local last=state.lastAttempt321
  if last and rawequal(last.ref[1],frame) and rawequal(last.ref[2],get(get(frame,"gameDataLogic"),"gameInfoData")) and last.round==round and last.identity==matchIdentity(frame) then
   controlStatus("uncertain","turn_already_submitted",plan);return result
  end
  state.lastAttempt321={ref=setmetatable({frame,get(get(frame,"gameDataLogic"),"gameInfoData")},{__mode="v"}),round=round,identity=matchIdentity(frame)}
  control.pending={round=round,time=time,plan=plan,origin=white.position,physics=prepared.physics,motion=false}
  control.shots=control.shots+1
  controlStatus("submitted","original_release_once",plan)
  local ok=invoke(view,"onPowerRelease")
  if not ok then controlStatus("uncertain","original_release_exception",plan) end
  return result
 end
 -- Read the same live pocket transforms used by BiAILogic:onSceneLoaded.
 local find=get(get(engine,"GameObject"),"Find")
 if type(find)~="function" then controlStatus("waiting","table_geometry_unavailable");return result end
 local ok,pots=pcall(find,"Table/Pots");local tr=ok and get(pots,"transform") or nil
 local count=get(tr,"childCount");local pockets={};local named={}
 local names={potUpLeft=true,potUpRight=true,potUpCenter=true,potDownLeft=true,potDownRight=true,potDownCenter=true}
 if not integer(count,6,16) or get(get(pots,"scene"),"handle")~=sceneHandle then controlStatus("waiting","table_geometry_unavailable");return result end
 for i=0,count-1 do
  local found,p=invoke(tr,"GetChild",i);local name=get(p,"name");local pos=vector(get(p,"position"))
  local tag=get(p,"tag")
  -- The shipped binary scene has SEVEN children: six pockets plus PotsRollBalls.
  -- Do not mistake a hierarchy child count for a count of playable pockets.
  if found and name=="PotsRollBalls" then
   -- Known decorative/collection child; never a shot destination.
  elseif not found or not names[name] or named[name] or not pos or math.abs(pos.x)>10 or math.abs(pos.z)>10
   or type(tag)~="string" or tag:sub(1,3)~="Pot" then controlStatus("waiting","pocket_contract_mismatch");return result end
  if names[name] then named[name]=true;pockets[#pockets+1]={x=pos.x,y=0,z=pos.z,name=name} end
 end
 if #pockets~=6 then controlStatus("waiting","pocket_contract_mismatch");return result end
 table.sort(pockets,function(a,b) return a.name<b.name end)
 local xmin,xmax,zmin,zmax=20,-20,20,-20
 for i,p in ipairs(pockets) do p.index=i;xmin=math.min(xmin,p.x);xmax=math.max(xmax,p.x);zmin=math.min(zmin,p.z);zmax=math.max(zmax,p.z) end
 if xmax-xmin<6 or xmax-xmin>14 or zmax-zmin<3 or zmax-zmin>8 then controlStatus("waiting","table_extent_mismatch");return result end
 -- Match BiAILogic's CORNER anchors. The middle pocket transforms protrude
 -- farther than the corners in the shipped scene; extrema give wrong banks.
 local cornerA,cornerB
 for _,p in ipairs(pockets) do if p.name=="potUpRight" then cornerA=p elseif p.name=="potDownLeft" then cornerB=p end end
 local bounds={xmin=cornerA.x+.07+white.radius,xmax=cornerB.x-.07-white.radius,
  zmin=cornerB.z+.15+white.radius,zmax=cornerA.z-.15-white.radius}
 if bounds.xmin>=bounds.xmax or bounds.zmin>=bounds.zmax then controlStatus("waiting","table_anchor_mismatch");return result end
 local row=white.row;local inertia=get(row.inertiaTensor,"x")
 local s={white=white.position,balls=rows,pockets=pockets,radius=white.radius,mass=row.mass,inertia=inertia,
  dt=diagnostics.fixedDeltaTime,drag=row.drag,angularDrag=row.angularDrag,stopSquared=diagnostics.stopSpeedSquared,
  mu=1,reference=diagnostics.powerReference,maximum=diagnostics.sliderMax,deadzone=diagnostics.deadzone,
  phase=phase,group=group,gain=control.calibrationSamples>=3 and control.gain or 1,
  bounds=bounds}
 local plans,reason=SDK321Planner.plan(s)
 if not plans then controlStatus("waiting",reason);return result end
 -- Verify shortlisted paths using bounded READ-ONLY Unity casts. No candidate
 -- invokes updateAuxiliary, Physics.Simulate, transforms or Rigidbody setters.
 local physics=get(engine,"Physics");local cast=get(physics,"SphereCastAll")
 local trigger=get(get(engine,"QueryTriggerInteraction"),"Collide")
 if type(cast)~="function" or trigger==nil then controlStatus("waiting","route_query_unavailable");return result end
 local selected
 for _,plan in ipairs(plans) do
  local hit=nearest(white.position,plan.direction,1)
  local valid=hit and hit.kind=="ball" and hit.tag==plan.target and math.abs(hit.distance-plan.cueLength)<.05
  if valid and plan.pocket~=0 then
   hit=nearest(plan.objectStart,plan.objectDirection,plan.target)
   valid=hit and hit.kind==(plan.bank and "cushion" or "pocket")
   if valid and not plan.bank then valid=hit.pocket==plan.pocketWorld.name end
   if valid and plan.bank then valid=validMaterial(hit.material,.5,.8,0) end
   if valid and plan.bank then
    local n=unit(hit.normal);local expected=unit(subtract(plan.pocketWorld,plan.bank))
    local rebound=n and unit(subtract(plan.objectDirection,add(zero(),n,2*dot(plan.objectDirection,n))))
    local actual=add(plan.objectStart,plan.objectDirection,hit.distance)
    valid=n and expected and rebound and dot(expected,rebound)>.999 and length(subtract(actual,plan.bank))<.06
    if valid then local start=add(actual,n,.003);hit=nearest(start,rebound,plan.target);valid=hit and hit.kind=="pocket" and hit.pocket==plan.pocketWorld.name end
   end
  end
  if valid then selected=plan;break end
 end
 if not selected then controlStatus("waiting","live_route_not_confirmed");return result end
 -- Original updateCueDir synchronizes curDir AND the panel's local cueAngle.
 -- Original updatePower updates the slider/display, but does not release it.
 control.prepared={plan=selected,time=time,frame=nowFrame,physics=s}
 local aimed=invoke(frame,"updateCueDir",selected.angle)
 local powered=aimed and invoke(frame,"updatePower",selected.power)
 local displayed=powered and invoke(view,"updateSliderUI",selected.power/s.maximum)
 if not aimed or not powered or not displayed then controlStatus("uncertain","original_aim_exception",selected)
 else controlStatus("aimed",command=="aim" and "aim_only_no_shot" or "confirming_aim",selected) end
 return result
end

local function sample()
    if command == "suspend" then
        local current=rawget(state,"control321")
        if type(current)=="table" then
            current.prepared=nil; current.board=nil
            current.stableAt=nil; current.stableFrame=nil
        end
        -- Keep the explicit lease, match binding, pending and lastAttempt.
        return stop("not_ready", "interaction_suspended")
    end
    if command == "stop" then
        state.session = state.session + 1
        state.control321 = nil -- Explicit user disarm. lastAttempt survives.
        state.controlMode321 = nil -- A new/reloaded Lua VM cannot inherit consent.
        state.frameRef[1] = nil
        state.sceneName, state.sceneHandle, state.cameraID = nil, nil, nil
        result.sessionId = state.session
        return stop("stopped", "stopped")
    end
    if command ~= "sample" and not actionCommand then return stop("unsupported", "unknown_command") end
    if actionCommand and not armingCommand and state.controlMode321~=command then
        controlStatus("uncertain","explicit_arm_required")
        return stop("unsupported","explicit_arm_required")
    end

    local CS = rawget(_G, "CS")
    local engine = get(CS, "UnityEngine")
    local sceneManager = get(get(engine, "SceneManagement"), "SceneManager")
    local activeScene = get(sceneManager, "GetActiveScene")
    result.gates = {
        hasCore=type(rawget(_G,"Core"))=="table",
        hasEnum=type(rawget(_G,"Enum"))=="table",
        hasConst=type(rawget(_G,"Const"))=="table",
        hasUnityEngine=engine~=nil,
        hasSceneAPI=type(activeScene)=="function"
    }
    if type(activeScene) ~= "function" then
        context(nil, nil, nil, nil)
        return stop("unsupported", "scene_api_unavailable")
    end
    local okScene, scene = pcall(activeScene)
    local sceneName, sceneHandle = get(scene, "name"), get(scene, "handle")
    if not okScene or type(sceneName) ~= "string" or #sceneName > 120
        or not integer(sceneHandle, -2147483648, 2147483647) then
        context(nil, nil, nil, nil)
        return stop("not_ready", "invalid_scene")
    end
    result.scene = {name=sceneName, handle=sceneHandle}
    if sceneName ~= "BilliardInGame" and sceneName ~= "BilliardTutorial" then
        context(nil, sceneName, sceneHandle, nil)
        return stop("wrong_scene", "scene_not_billiards")
    end
    if get(scene, "isLoaded") ~= true then
        context(nil, sceneName, sceneHandle, nil)
        return stop("not_ready", "scene_not_loaded")
    end

    result.environment=inspectEnvironment(sceneName=="BilliardTutorial")

    local tutorial = sceneName == "BilliardTutorial"
    local enum,constants,descriptor,contractReason=resolveContract(tutorial)
    if contractReason then
        context(nil, sceneName, sceneHandle, nil)
        return stop("unsupported", contractReason)
    end
    local resolution=result.resolution
    local manager,managerLookup=structuralField(rawget(_G,"Core"),"logicMgr")
    resolution.managerType,resolution.managerLookup=type(manager),managerLookup
    if type(manager)~="table" then
        context(nil,sceneName,sceneHandle,nil)
        return stop("unsupported","logic_manager_unavailable")
    end
    local getter,getterLookup=structuralField(manager,"get")
    resolution.managerGetType=type(getter)
    resolution.managerLookup=getterLookup
    if getterLookup=="raw" and managerLookup=="metatable_table" then
        resolution.managerLookup="metatable_table"
    end
    if type(getter)~="function" then
        local blocked=getterLookup=="function_index_blocked" or getterLookup=="protected_metatable"
            or getterLookup=="cycle" or getterLookup=="depth_limit" or getterLookup=="error"
        context(nil,sceneName,sceneHandle,nil)
        return stop("unsupported",blocked and "logic_getter_blocked" or "logic_getter_missing")
    end
    resolution.frameCallAttempted=true
    local okFrame,frame=pcall(getter,manager,descriptor)
    resolution.frameCallSucceeded=okFrame
    -- On an exception the second pcall result is private error text, not a frame.
    if okFrame then resolution.frameType=type(frame) end
    local destroyed
    if okFrame and type(frame)=="table" then destroyed=get(frame,"Destroyed") end
    if type(destroyed)=="boolean" then resolution.frameDestroyed=destroyed end
    if not okFrame or type(frame) ~= "table" or destroyed == true then
        context(nil, sceneName, sceneHandle, nil)
        return stop("not_ready", okFrame and "frame_unavailable" or "frame_lookup_failed")
    end
    result.gates.hasFrame=true
    local camera = get(get(engine, "Camera"), "main")
    local cameraID = instance(camera)
    context(frame, sceneName, sceneHandle, cameraID)
    result.cameraInstanceId = cameraID or NULL
    result.gates.hasCamera=cameraID~=nil
    if not cameraID or get(camera, "isActiveAndEnabled") ~= true
        or get(camera, "orthographic") ~= true then
        return stop("not_ready", "camera_unavailable")
    end
    local cameraGO = get(camera, "gameObject")
    if get(get(cameraGO, "scene"), "handle") ~= sceneHandle then
        return stop("not_ready", "camera_scene_mismatch")
    end
    local unityScreen, unityTime = get(engine, "Screen"), get(engine, "Time")
    local width, height = get(unityScreen, "width"), get(unityScreen, "height")
    local frameNumber = get(unityTime, "frameCount")
    if not integer(width, 1, 32768) or not integer(height, 1, 32768)
        or not integer(frameNumber, 0, 2147483647) then
        return stop("not_ready", "screen_or_clock_unavailable")
    end
    result.screen, result.frameNumber = {width=width, height=height}, frameNumber
    local vectorType = get(engine, "Vector3")
    local function unityVector(v) return vectorType(v.x, v.y, v.z) end
    local function project(v)
        local ok, p = invoke(camera, "WorldToScreenPoint", unityVector(v))
        p = ok and vector(p) or nil
        if not p or p.z <= 0 or math.abs(p.x) > width*8 or math.abs(p.y) > height*8 then return nil end
        return {x=p.x, y=p.y, depth=p.z}
    end
    local cameraRight = unit(vector(get(get(camera, "transform"), "right")))
    if not cameraRight then return stop("not_ready", "camera_basis_unavailable") end
    local frameBalls = get(frame, "balls")
    if type(frameBalls) ~= "table" then return stop("not_ready", "balls_unavailable") end
    local entries = 0
    for k in next, frameBalls do
        entries = entries + 1
        if entries > MAX_BALLS or not integer(k, 1, MAX_BALLS) then
            return stop("not_ready", "invalid_ball_collection")
        end
    end
    if entries == 0 then return stop("not_ready", "balls_empty") end
    -- XLua boxes enums and its native ToString callback appends ": <hash>".
    -- Accept only known typed enum equality or exact named/numeric forms; an
    -- arbitrary userdata or a string merely containing an enum name is invalid.
    local constraintNames={None=0,FreezePositionX=2,FreezePositionY=4,FreezePositionZ=8,
        FreezeRotationX=16,FreezeRotationY=32,FreezeRotationZ=64,
        FreezePosition=14,FreezeRotation=112,FreezeAll=126}
    local combineNames={Average=0,Multiply=1,Minimum=2,Maximum=3}
    local function enumText(value)
        if value==nil then return nil end
        local ok,text=pcall(tostring,value)
        if not ok or type(text)~="string" or #text>96 or text:find("[%z\1-\31\127]")
            or text:find("0[xX]%x+") then return nil end
        return text
    end
    local function enumValue(value,family,names,maximum)
        if integer(value,0,maximum) then return value end
        if value==nil then return nil end
        local values=get(engine,family)
        local text=enumText(value)
        for name,number in pairs(names) do
            local typed=get(values,name)
            if typed~=nil then
                local ok,same=pcall(function() return value==typed end)
                if ok and same then return number end
            end
            if text==name or text==name..": "..number then return number end
        end
    end
    local function enumDiagnostic(row,prefix,value,family,names,maximum)
        row[prefix.."Type"]=type(value)
        row[prefix.."Text"]=enumText(value)
        row[prefix.."Value"]=enumValue(value,family,names,maximum)
    end
    local ballByTag, ballByGO, ballByCollider = {}, {}, {}
    local moving, white, observed = get(frame, "ballsInMovement") == true, nil, 0
    local angularMoving = false
    for i=1,MAX_BALLS do
        local ball = rawget(frameBalls, i)
        if ball ~= nil then
            local tag, number = get(ball, "ballTag"), get(ball, "ballNum")
            if not integer(tag, 1, MAX_BALLS) or number ~= tag-1 or ballByTag[tag] then
                return stop("not_ready", "invalid_ball_identity")
            end
            local active, potted = get(ball, "ballActive"), get(ball, "poted")
            if type(active) ~= "boolean" or type(potted) ~= "boolean" then
                return stop("not_ready", "invalid_ball_flags")
            end
            local row = {tag=tag, number=number, active=false, potted=potted,
                world=NULL, screen=NULL, speed=NULL, radiusPixels=NULL}
            local record = {row=row, source=ball}
            ballByTag[tag] = record
            result.balls[#result.balls+1] = row
            local go, tr, rb, collider = get(ball,"gameObject"), get(ball,"transform"),
                get(ball,"rigidbody"), get(ball,"collider")
            local gid, cid = instance(go), instance(collider)
            if active and not potted then
                if not gid or not cid or get(go,"activeInHierarchy") ~= true
                    or get(collider,"enabled") ~= true or get(collider,"isTrigger") ~= false
                    or get(get(go,"scene"),"handle") ~= sceneHandle then
                    return stop("not_ready", "active_ball_object_unavailable")
                end
                if ballByGO[gid] or ballByCollider[cid] then
                    return stop("not_ready", "reused_ball_object")
                end
                local pos, vel, angular = vector(get(tr,"position")), vector(get(rb,"velocity")),
                    vector(get(rb,"angularVelocity"))
                local radius, scale = get(collider,"radius"), vector(get(tr,"lossyScale"))
                if not pos or not vel or not angular or not finite(radius) or not scale
                    or math.abs(pos.x)>20 or math.abs(pos.y)>.5 or math.abs(pos.z)>20 then
                    return stop("not_ready", "invalid_ball_geometry")
                end
                radius = radius * math.max(math.abs(scale.x),math.abs(scale.y),math.abs(scale.z))
                if radius < .1 or radius > .3 then return stop("not_ready", "ball_radius_mismatch") end
                local screenPos, screenEdge = project(pos), project(add(pos,cameraRight,radius))
                if not screenPos or not screenEdge then return stop("not_ready", "ball_projection_failed") end
                local radiusPixels=math.sqrt((screenPos.x-screenEdge.x)^2+(screenPos.y-screenEdge.y)^2)
                if radiusPixels<.1 or radiusPixels>math.max(width,height)/4 then
                    return stop("not_ready", "invalid_projected_radius")
                end
                row.active, row.world, row.screen, row.speed, row.radiusPixels =
                    true, pos, screenPos, length(vel), radiusPixels
                row.velocity,row.angularVelocity=vel,angular
                for _,key in ipairs({"mass","drag","angularDrag"}) do
                    local value=get(rb,key)
                    if finite(value) then row[key]=value end
                end
                row.inertiaTensor=vector(get(rb,"inertiaTensor"))
                record.material=get(collider,"sharedMaterial")
                record.center=vector(get(collider,"center"))
                record.centerOfMass=vector(get(rb,"centerOfMass"))
                record.constraints=get(rb,"constraints")
                record.maxAngularVelocity=get(rb,"maxAngularVelocity")
                local profile={worldRadius=radius,colliderCenter=record.center,
                    centerOfMass=record.centerOfMass,materialPresent=record.material~=nil}
                if finite(record.maxAngularVelocity) then profile.maxAngularVelocity=record.maxAngularVelocity end
                enumDiagnostic(profile,"constraints",record.constraints,"RigidbodyConstraints",constraintNames,127)
                for _,key in ipairs({"dynamicFriction","staticFriction","bounciness"}) do
                    local value=get(record.material,key)
                    if finite(value) then profile[key]=value end
                end
                enumDiagnostic(profile,"frictionCombine",get(record.material,"frictionCombine"),
                    "PhysicMaterialCombine",combineNames,3)
                enumDiagnostic(profile,"bounceCombine",get(record.material,"bounceCombine"),
                    "PhysicMaterialCombine",combineNames,3)
                row.physicalProfile=profile
                record.position, record.radius, record.colliderID, record.gameObjectID = pos,radius,cid,gid
                ballByGO[gid],ballByCollider[cid]=record,record
                observed = observed + 1
                moving = moving or row.speed > SPEED_LIMIT or get(ball,"ballInMovement") == true
                angularMoving = angularMoving or length(angular) > .2
                if tag == 1 then white = record end
            end
        end
    end
    table.sort(result.balls,function(a,b) return a.tag<b.tag end)
    if not white or observed == 0 then return stop("not_ready", "white_ball_unavailable") end
    -- Read observed dynamics before the motion/turn guards: exports can explain
    -- real deceleration without ever authorizing a guide while balls move.
    local diagnostics={schemaVersion=1,available=false,reason="physics_unavailable",
        muTable=1,profile="cache1084_physics_v1",materialSource="cache1084_profile",modelLimit="no_custom_contact_correction"}
    result.physics=diagnostics
    local function observed(key,value)
        if finite(value) then diagnostics[key]=value;return value end
    end
    local step=observed("fixedDeltaTime",get(unityTime,"fixedDeltaTime"))
    observed("gameTime",get(unityTime,"time"));observed("fixedTime",get(unityTime,"fixedTime"))
    local gravity=vector(get(get(engine,"Physics"),"gravity"));diagnostics.gravity=gravity
    local stopSquared=observed("stopSpeedSquared",get(constants,"BALL_MIN_VEL"))
    local stopAngular=observed("stopAngularSpeed",get(constants,"BALL_MIN_ANGVEL"))
    local slider=get(get(frame,"gameView"),"powerSld")
    local power=observed("power",get(slider,"value"))
    local sliderMax=observed("sliderMax",get(slider,"max"))
    local powerReference=observed("powerReference",get(constants,"CUE_POWER_MAX"))
    local deadzone=observed("deadzone",get(constants,"CUE_POWER_DEADZONE"))
    local hitAngle=get(constants,"HIT_BALL_ANGLE")
    local spinValue=get(frame,"trickShotAdd")
    local spinX,spinY=get(spinValue,"x"),get(spinValue,"y")
    if finite(spinX) and finite(spinY) then diagnostics.spin={x=spinX,y=spinY} end
    observed("framePowerValue",get(frame,"powerValue"))
    diagnostics.shotPower=vector(get(frame,"shotPower"))
    local localTurn=get(frame,"isServer")
    if type(localTurn)=="boolean" then
        if get(get(get(frame,"frameStateLogic"),"turnData"),"myTurn")==false then localTurn=false end
        diagnostics.localTurn=localTurn
    end
    local physicsReason
    local function reject(reason,field,tag)
        if not physicsReason then
            physicsReason=reason
            diagnostics.mismatchField=field
            diagnostics.mismatchBallTag=tag
        end
    end
    if tutorial then reject("tutorial_physics_unsupported","scene")
    elseif not power or power<0 then reject("power_unavailable","power")
    elseif not sliderMax or sliderMax<=0 then reject("power_unavailable","sliderMax")
    elseif power>sliderMax+.0001 then reject("power_unavailable","power")
    elseif not powerReference or powerReference<=0 then reject("power_unavailable","powerReference")
    elseif not deadzone or deadzone<0 or deadzone>=1 then reject("power_unavailable","deadzone")
    elseif not finite(spinX) or not finite(spinY) then reject("spin_unavailable","spin")
    elseif not finite(hitAngle) then reject("spin_unavailable","hitAngle")
    elseif math.abs(spinX)>.001 or math.abs(spinY)>.001 then reject("spin_unsupported","spin")
    elseif not step then reject("physics_unavailable","fixedDeltaTime")
    elseif not gravity then reject("physics_unavailable","gravity")
    elseif not stopSquared then reject("physics_unavailable","stopSpeedSquared")
    elseif not stopAngular then reject("physics_unavailable","stopAngularSpeed")
    elseif math.abs(step-.02)>.000001 then reject("physics_profile_mismatch","fixedDeltaTime")
    elseif math.abs(gravity.x)>.00001 or math.abs(gravity.z)>.00001
        or math.abs(gravity.y+9.81)>.01 then reject("physics_profile_mismatch","gravity")
    elseif math.abs(stopSquared-.008)>.000001 then reject("physics_profile_mismatch","stopSpeedSquared")
    elseif math.abs(stopAngular-.2)>.000001 then reject("physics_profile_mismatch","stopAngularSpeed") end
    local function materialMatches(material,friction,restitution,staticFriction)
        if material==nil then return true end -- Cache1084 evidence, explicitly named above.
        staticFriction=staticFriction==nil and friction or staticFriction
        for _,item in ipairs({{"dynamicFriction",friction},{"staticFriction",staticFriction},{"bounciness",restitution}}) do
            local value=get(material,item[1])
            if not finite(value) or math.abs(value-item[2])>=.0001 then return false,item[1] end
        end
        for _,item in ipairs({{"frictionCombine",3},{"bounceCombine",1}}) do
            local value=get(material,item[1])
            if value~=nil and enumValue(value,"PhysicMaterialCombine",combineNames,3)~=item[2] then
                return false,item[1]
            end
        end
        return true
    end
    for _,row in ipairs(result.balls) do
        if row.active then
            local inertia,record=row.inertiaTensor,ballByTag[row.tag]
            local function bodyReject(reason,field) reject(reason,field,row.tag) end
            for _,item in ipairs({{"colliderCenter",record.center},{"centerOfMass",record.centerOfMass},
                {"maxAngularVelocity",finite(record.maxAngularVelocity) and record.maxAngularVelocity or nil},
                {"constraints",record.constraints},{"mass",row.mass},{"drag",row.drag},
                {"angularDrag",row.angularDrag},{"inertiaTensor",inertia}}) do
                if item[2]==nil then bodyReject("physics_body_unavailable",item[1]) end
            end
            if inertia and (inertia.x<=0 or inertia.y<=0 or inertia.z<=0
                or math.abs(inertia.x-inertia.y)>inertia.x*.001
                or math.abs(inertia.x-inertia.z)>inertia.x*.001) then
                bodyReject("inertia_tensor_unsupported","inertiaTensor")
            end
            if record.constraints~=nil and row.physicalProfile.constraintsValue~=4 then
                bodyReject("physics_profile_mismatch","constraints") end
            if record.center and length(record.center)>.000001 then bodyReject("physics_profile_mismatch","colliderCenter") end
            if record.centerOfMass and length(record.centerOfMass)>.000001 then bodyReject("physics_profile_mismatch","centerOfMass") end
            for _,item in ipairs({{"maxAngularVelocity",record.maxAngularVelocity,500,.001},
                {"mass",row.mass,.45,.0001},{"drag",row.drag,.5,.0001},
                {"angularDrag",row.angularDrag,.5,.0001},{"worldRadius",record.radius,.165,.0001}}) do
                if finite(item[2]) and math.abs(item[2]-item[3])>item[4] then
                    bodyReject("physics_profile_mismatch",item[1]) end
            end
            if inertia and row.mass and math.abs(inertia.x-.4*row.mass*record.radius^2)>inertia.x*.05 then
                bodyReject("physics_profile_mismatch","inertiaTensor") end
            local matches,field=materialMatches(record.material,0,1)
            if not matches then bodyReject("physics_profile_mismatch",field) end
        end
    end
    if not physicsReason then
        diagnostics.launchSpeed=.031*power*math.sqrt(power/powerReference)/white.row.mass
        if not finite(diagnostics.launchSpeed) or diagnostics.launchSpeed>1000 then reject("power_unavailable","launchSpeed")
        elseif power<deadzone*sliderMax then reject("power_below_deadzone","power") end
    end
    diagnostics.reason=physicsReason or "ready"
    diagnostics.available=physicsReason==nil
    if actionCommand and not controlObserve(frame,engine,sceneHandle,cameraID,white,result.balls,diagnostics,moving or angularMoving) then
        return result
    end
    if armingCommand then
        -- This read-only arm binds frame, gameId, turn and camera NOW, rather
        -- than letting the first later action silently bind a different match.
        state.controlMode321=command=="arm_auto" and "autoplay" or "aim"
        controlStatus("waiting","automation_armed")
        return result
    end
    if moving or angularMoving then return stop("moving", "balls_moving") end
    if not tutorial and (get(frame,"started")~=true or get(frame,"canShot")~=true) then
        return stop("not_ready", "not_aiming")
    end
    if not tutorial and get(frame,"offlineMode")~=true then
        if get(frame,"isServer")~=true then return stop("not_ready", "not_local_turn") end
        local turn = get(get(frame,"frameStateLogic"),"turnData")
        if get(turn,"myTurn")==false then return stop("not_ready", "not_local_turn") end
    end
    if get(get(frame,"moveBallScript"),"ballInHand")==true then
        return stop("not_ready", "white_ball_in_hand")
    end
    local view=get(frame,tutorial and "tutorialView" or "gameView")
    local cueUI=get(view,tutorial and "cue" or "cueCom")
    if get(cueUI,"visible")~=true or get(view,"cueTouchable")~=true then
        return stop("not_ready", "aim_ui_hidden")
    end
    if not tutorial then
        local uiLogic=get(frame,"uiLogic")
        local dialogName=get(get(constants,"UIName"),"CuePositionDialogPanel")
        local okDialog,visible=invoke(uiLogic,"isUIShow",dialogName)
        if type(dialogName)~="string" or not okDialog or type(visible)~="boolean" then
            return stop("not_ready", "aim_ui_unavailable")
        end
        if visible then return stop("not_ready", "cue_dialog_visible") end
    end
    local aux = get(get(frame,"auxiliaryLine"),"auxData")
    if get(aux,"shown")~=true then return stop("not_ready", "aim_not_visible") end
    local direction = unit(vector(get(frame,"curDir")))
    if not direction or math.abs(direction.y)>.001 then return stop("not_ready", "invalid_cue_direction") end
    local auxStart,auxEnd=vector(get(aux,"cueStartPos")),vector(get(aux,"cueEndPos"))
    if not auxStart or not auxEnd then return stop("not_ready","aim_snapshot_unavailable") end
    local auxDir=unit(subtract(auxEnd,auxStart))
    local dx,dz=auxStart.x-white.position.x,auxStart.z-white.position.z
    if dx*dx+dz*dz>.0001 or not auxDir or dot(auxDir,direction)<.9999 then
        return stop("not_ready","aim_snapshot_stale")
    end
    result.cue = {world=white.position, direction=direction}
    result.status="aiming"
    if actionCommand then
        return controlAct(frame,engine,sceneHandle,cameraID,white,result.balls,diagnostics,physicsReason,enum,constants,materialMatches)
    end

    local physics=get(engine,"Physics")
    local sphereCastAll=get(physics,"SphereCastAll")
    if type(sphereCastAll)~="function" then return stop("unsupported", "physics_query_unavailable") end
    local triggerPolicy=get(physics,"queriesHitTriggers")
    if type(triggerPolicy)~="boolean" then return stop("unsupported","physics_trigger_policy_unknown") end
    -- Fallback starts only before the finite solver has issued ANY query, and
    -- only after the same scene, movement, turn, viewport and coherent aim gates.
    local function runGeometricGuide()
        local MAX_BOUNCES,MAX_SEGMENTS,MAX_QUERIES,MAX_EVENTS,HORIZON=2,24,32,16,12
        result.prediction={available=false,reason="not_ready",model="geometric",maxBounces=MAX_BOUNCES,
            chainVersion=1,events=0,queries=0,collisions=0,bounces=0,affectedBallCount=0,truncated=false}
        -- Synthetic equal-mass geometry only: normalized velocities and horizon are
        -- NOT seconds, cue power, friction, spin or a prediction of final positions.
        -- Unity remains untouched. All moving synthetic balls share one event clock.
        local queries,bounces,collisions,events,clock=0,0,0,0,0
        local segments, failure, partialReason = array(), nil, nil
        local EPS, CONTACT_EPS, TIME_EPS, VELOCITY_EPS = .0005, .00001, .000001, .00001
        local function classify(collider)
            local cid=instance(collider)
            if cid and ballByCollider[cid] then return "ball",ballByCollider[cid] end
            local tr=get(collider,"transform")
            local trigger=get(collider,"isTrigger")
            for depth=1,8 do
                if not tr then break end
                local go=get(tr,"gameObject")
                if get(get(go,"scene"),"handle")~=sceneHandle then return "unknown" end
                local gid=instance(go)
                if gid and ballByGO[gid] then return "ball",ballByGO[gid] end
                local name,tag=get(go,"name"),get(go,"tag")
                if trigger==true then
                    if name=="potUpLeft" or name=="potUpRight" or name=="potUpCenter"
                        or name=="potDownLeft" or name=="potDownRight" or name=="potDownCenter" then
                        return "pocket"
                    end
                else
                    if name=="bumpers" or tag=="bumper" then return "cushion" end
                    if name=="canvas" then return "surface" end
                    if tag=="Ball" then return "unknown_ball" end
                end
                tr=get(tr,"parent")
            end
            return trigger==true and "trigger" or "unknown"
        end
        local function cast(body)
            if queries>=MAX_QUERIES then partialReason="query_limit";return nil end
            queries=queries+1
            local speed=length(body.velocity)
            local dir=unit(body.velocity)
            local offset=body.afterCushion and EPS or 0
            local origin=add(body.position,dir,offset)
            local ok,hits
            -- Layer0 contains rails/balls; layer19 contains pocket triggers AND the
            -- canvas. Classification still excludes the canvas after broadphase.
            local mask=524289
            if triggerPolicy==false then
                local collide=get(get(engine,"QueryTriggerInteraction"),"Collide")
                if collide==nil then failure="trigger_query_unavailable";return nil end
                ok,hits=pcall(sphereCastAll,unityVector(origin),body.radius,unityVector(dir),MAX_DISTANCE,mask,collide)
            else
                ok,hits=pcall(sphereCastAll,unityVector(origin),body.radius,unityVector(dir),MAX_DISTANCE,mask)
            end
            if not ok then failure="physics_query_failed";return nil end
            local count=get(hits,"Length")
            if not integer(count,0,MAX_HITS) then failure="physics_hit_limit";return nil end
            local nearest
            for i=0,count-1 do
                local hit=get(hits,i)
                local distance,collider=get(hit,"distance"),get(hit,"collider")
                if not finite(distance) or distance<0 or distance>MAX_DISTANCE+.001 then
                    failure="invalid_physics_hit";return nil
                end
                if collider then
                    local kind=classify(collider)
                    -- ALL mapped Unity ball colliders are stale for synthetic future
                    -- positions; analytical pair tests below handle these balls.
                    if kind~="ball" and kind~="surface" and kind~="trigger" then
                        local normal=unit(vector(get(hit,"normal")))
                        if not nearest or distance<nearest.distance-TIME_EPS then
                            nearest={distance=distance,kind=kind,normal=normal}
                        elseif math.abs(distance-nearest.distance)<=TIME_EPS then
                            -- Different equally early rail/pocket normals cannot be
                            -- reduced to the arbitrary order returned by Unity.
                            local sameNormal=normal and nearest.normal and dot(normal,nearest.normal)>.99999
                            if kind~=nearest.kind or not sameNormal then nearest.ambiguous=true end
                        end
                    end
                end
            end
            if nearest then
                if nearest.kind=="unknown_ball" or nearest.kind=="unknown" then
                    local reason=nearest.kind=="unknown_ball" and "unmapped_ball_collider" or "unclassified_collider"
                    if #segments>0 then partialReason=reason else failure=reason end
                    return nil
                end
                if nearest.kind=="cushion" then
                    -- Unity's initial-overlap normal is opposite the sweep, not an
                    -- actual rail normal. Never manufacture a reflection from it.
                    if nearest.distance<=TIME_EPS then partialReason="environment_overlap";return nil end
                    if not nearest.normal or math.abs(nearest.normal.y)>.25
                        or dot(dir,nearest.normal)>=-TIME_EPS then
                        failure="invalid_cushion_normal";return nil
                    end
                    nearest.normal=unit({x=nearest.normal.x,y=0,z=nearest.normal.z})
                end
                nearest.time=clock+(nearest.distance+offset)/speed
                if nearest.ambiguous then nearest.kind="ambiguous" end
            else
                -- This is only a verified empty sweep window, not a rail or a line.
                -- Earlier analytical collisions may still provide a bounded path.
                nearest={kind="open",time=clock+MAX_DISTANCE/speed}
            end
            body.afterCushion=false
            return nearest
        end
        local bodies,affected={},{}
        for _,row in ipairs(result.balls) do
            if row.active and not row.potted then
                local record=ballByTag[row.tag]
                bodies[#bodies+1]={tag=row.tag,radius=record.radius,
                    position={x=record.position.x,y=record.position.y,z=record.position.z},
                    velocity={x=0,y=0,z=0},trace=record.position,
                    kind=row.tag==1 and "cue" or "object",bounces=0,live=true}
            end
        end
        local function movingBody(body) return body.live and length(body.velocity)>VELOCITY_EPS end
        for _,body in ipairs(bodies) do
            if body.tag==1 then body.velocity=direction;affected[1]=true end
        end
        local function emit(body,terminal,targetTag)
            if length(subtract(body.position,body.trace))<.0001 then
                body.trace=body.position;return true
            end
            if #segments>=MAX_SEGMENTS then partialReason="segment_limit";return false end
            local from,to=project(body.trace),project(body.position)
            if not from or not to then failure="guide_projection_failed";return false end
            local row={kind=body.kind,from=from,to=to,worldFrom=body.trace,worldTo=body.position,
                ballTag=body.tag,eventIndex=events,terminal=terminal}
            if terminal=="ball" then row.hitBallTag=targetTag end
            segments[#segments+1]=row
            body.trace=body.position
            return true
        end
        local function pairTime(a,b)
            if not a.live or not b.live then return nil end
            local relativePosition=subtract(b.position,a.position)
            local relativeVelocity=subtract(b.velocity,a.velocity)
            local speed2=dot(relativeVelocity,relativeVelocity)
            if speed2<VELOCITY_EPS*VELOCITY_EPS then return nil end
            local closing=dot(relativePosition,relativeVelocity)
            if closing>=-TIME_EPS then return nil end
            local radius=a.radius+b.radius
            local gap=dot(relativePosition,relativePosition)-radius*radius
            if gap < -CONTACT_EPS then partialReason="overlapping_ball_geometry";return nil end
            if gap<=CONTACT_EPS then return clock end
            local discriminant=closing*closing-speed2*gap
            if discriminant<=TIME_EPS*TIME_EPS then return nil end
            local dt=(-closing-math.sqrt(discriminant))/speed2
            if not finite(dt) or dt < -TIME_EPS then return nil end
            return clock+math.max(0,dt)
        end
        local function shares(a,b)
            return a.a==b.a or a.a==b.b or (a.b and (a.b==b.a or a.b==b.b))
        end
        local function advance(time)
            local dt=time-clock
            for _,body in ipairs(bodies) do
                if movingBody(body) then body.position=add(body.position,body.velocity,dt) end
            end
            clock=time
        end
        local function flush(terminal)
            for _,body in ipairs(bodies) do
                -- No extension for an unbounded/unknown path. A completed collision
                -- segment is already retained even if its next sweep is open.
                if movingBody(body) and body.cached and body.cached.kind~="open" then
                    if not emit(body,terminal) then return end
                end
            end
        end
        while not failure and not partialReason do
            if events>=MAX_EVENTS then partialReason="event_limit";break end
            local candidates,anyMoving={},false
            for _,body in ipairs(bodies) do
                if movingBody(body) then
                    anyMoving=true
                    if not body.cached then body.cached=cast(body) end
                    if failure or partialReason then break end
                    candidates[#candidates+1]={time=body.cached.time,kind=body.cached.kind,
                        a=body,normal=body.cached.normal}
                end
            end
            if failure or partialReason then break end
            if not anyMoving then break end
            for i=1,#bodies-1 do
                for j=i+1,#bodies do
                    local t=pairTime(bodies[i],bodies[j])
                    if t then candidates[#candidates+1]={time=t,kind="ball",a=bodies[i],b=bodies[j]} end
                end
            end
            if partialReason then break end
            table.sort(candidates,function(a,b)
                if a.time~=b.time then return a.time<b.time end
                if a.a.tag~=b.a.tag then return a.a.tag<b.a.tag end
                return (a.b and a.b.tag or 0)<(b.b and b.b.tag or 0)
            end)
            local event=candidates[1]
            if not event or event.time>HORIZON then
                events=events+1;advance(HORIZON);flush("horizon")
                partialReason="horizon_limit";break
            end
            if event.kind=="open" then partialReason="open_path_unknown";break end
            local ambiguous=event.kind=="ambiguous"
            for i=2,#candidates do
                local other=candidates[i]
                if other.time-event.time>TIME_EPS then break end
                if other.kind~="open" and shares(event,other) then ambiguous=true;break end
            end
            if ambiguous then
                events=events+1;advance(event.time);flush("limit")
                partialReason="simultaneous_contacts";break
            end
            -- Reserve both possible incoming traces before advancing the event.
            local needed=event.b and 2 or 1
            if #segments+needed>MAX_SEGMENTS then partialReason="segment_limit";break end
            events=events+1
            advance(event.time)
            local a,b=event.a,event.b
            if event.kind=="ball" then
                local normal=unit(subtract(b.position,a.position))
                if not normal or math.abs(normal.y)>.05 then failure="invalid_ball_contact";break end
                local transfer=dot(subtract(a.velocity,b.velocity),normal)
                if transfer<=TIME_EPS then partialReason="degenerate_ball_contact";break end
                if not emit(a,"ball",b.tag) or not emit(b,"ball",a.tag) then break end
                a.velocity=add(a.velocity,normal,-transfer)
                b.velocity=add(b.velocity,normal,transfer)
                a.cached,b.cached=nil,nil
                a.afterCushion,b.afterCushion=false,false
                a.kind=a.tag==1 and "cue" or "object"
                b.kind=b.tag==1 and "cue" or "object"
                if movingBody(a) then affected[a.tag]=true end
                if movingBody(b) then affected[b.tag]=true end
                collisions=collisions+1
            elseif event.kind=="pocket" then
                if not emit(a,"pocket") then break end
                a.live=false;a.velocity={x=0,y=0,z=0};a.cached=nil
            elseif event.kind=="cushion" then
                if a.bounces>=MAX_BOUNCES then
                    emit(a,"limit");partialReason="bounce_limit";break
                end
                if not emit(a,"cushion") then break end
                a.velocity=add(a.velocity,event.normal,-2*dot(a.velocity,event.normal))
                a.kind="rebound";a.bounces=a.bounces+1;bounces=bounces+1
                a.cached=nil;a.afterCushion=true
            end
        end
        if not failure and partialReason and events>0 then flush("limit") end
        local affectedCount=0;for _ in pairs(affected) do affectedCount=affectedCount+1 end
        result.prediction.events=events
        result.prediction.queries=queries
        result.prediction.collisions=collisions
        result.prediction.bounces=bounces
        result.prediction.affectedBallCount=affectedCount
        result.prediction.truncated=partialReason~=nil
        if failure then return stop("unsupported",failure) end
        if #segments==0 then return stop("not_ready",partialReason or "no_bounded_trajectory") end
        result.segments=segments
        result.prediction.available=true
        result.prediction.reason=partialReason or "geometric_chain_no_spin_no_timing"
        return result
    end
    if physicsReason then return runGeometricGuide() end
    -- Pure local predictor. Slip impulse and damping match the observed free
    -- phases; Unity contact correction, solver order and tiny render-step timing
    -- differences still make endpoints ESTIMATES, never guaranteed outcomes.
    local queries,bounces,collisions,events,clock,steps=0,0,0,0,0,0
    local segments, failure, partialReason = array(), nil, nil
    local EPS, CONTACT_EPS, TIME_EPS, VELOCITY_EPS = .0005, .00001, .000001, .00001
    local function classify(collider)
        local cid=instance(collider)
        if cid and ballByCollider[cid] then return "ball",ballByCollider[cid] end
        local tr=get(collider,"transform")
        local trigger=get(collider,"isTrigger")
        for depth=1,8 do
            if not tr then break end
            local go=get(tr,"gameObject")
            if get(get(go,"scene"),"handle")~=sceneHandle then return "unknown" end
            local gid=instance(go)
            if gid and ballByGO[gid] then return "ball",ballByGO[gid] end
            local name,tag=get(go,"name"),get(go,"tag")
            if trigger==true then
                if name=="potUpLeft" or name=="potUpRight" or name=="potUpCenter"
                    or name=="potDownLeft" or name=="potDownRight" or name=="potDownCenter" then
                    return "pocket"
                end
            else
                if name=="bumpers" or tag=="bumper" then return "cushion" end
                if name=="canvas" then return "surface" end
                if tag=="Ball" then return "unknown_ball" end
            end
            tr=get(tr,"parent")
        end
        return trigger==true and "trigger" or "unknown"
    end
    local function cast(body)
        if queries>=MAX_QUERIES then partialReason="query_limit";return nil end
        queries=queries+1
        local dir=unit(body.velocity)
        local offset=body.afterCushion and EPS or 0
        local origin=add(body.position,dir,offset)
        local ok,hits
        -- Layer0 contains rails/balls; layer19 contains pocket triggers AND the
        -- canvas. Classification still excludes the canvas after broadphase.
        local mask=524289
        if triggerPolicy==false then
            local collide=get(get(engine,"QueryTriggerInteraction"),"Collide")
            if collide==nil then failure="trigger_query_unavailable";return nil end
            ok,hits=pcall(sphereCastAll,unityVector(origin),body.radius,unityVector(dir),MAX_DISTANCE,mask,collide)
        else
            ok,hits=pcall(sphereCastAll,unityVector(origin),body.radius,unityVector(dir),MAX_DISTANCE,mask)
        end
        if not ok then failure="physics_query_failed";return nil end
        local count=get(hits,"Length")
        if not integer(count,0,MAX_HITS) then failure="physics_hit_limit";return nil end
        local nearest
        for i=0,count-1 do
            local hit=get(hits,i)
            local distance,collider=get(hit,"distance"),get(hit,"collider")
            if not finite(distance) or distance<0 or distance>MAX_DISTANCE+.001 then
                failure="invalid_physics_hit";return nil
            end
            if collider then
                local kind=classify(collider)
                -- ALL mapped Unity ball colliders are stale for synthetic future
                -- positions; analytical pair tests below handle these balls.
                if kind=="surface" and not materialMatches(get(collider,"sharedMaterial"),1,0) then
                    partialReason="physics_material_mismatch";return nil
                end
                if kind~="ball" and kind~="surface" and kind~="trigger" then
                    local normal=unit(vector(get(hit,"normal")))
                    if not nearest or distance<nearest.distance-TIME_EPS then
                        nearest={distance=distance,kind=kind,normal=normal,material=get(collider,"sharedMaterial")}
                    elseif math.abs(distance-nearest.distance)<=TIME_EPS then
                        -- Different equally early rail/pocket normals cannot be
                        -- reduced to the arbitrary order returned by Unity.
                        local sameNormal=normal and nearest.normal and dot(normal,nearest.normal)>.99999
                        if kind~=nearest.kind or not sameNormal then nearest.ambiguous=true end
                    end
                end
            end
        end
        if nearest then
            if nearest.kind=="unknown_ball" or nearest.kind=="unknown" then
                local reason=nearest.kind=="unknown_ball" and "unmapped_ball_collider" or "unclassified_collider"
                if #segments>0 then partialReason=reason else failure=reason end
                return nil
            end
            if nearest.kind=="cushion" then
                -- Unity's initial-overlap normal is opposite the sweep, not an
                -- actual rail normal. Never manufacture a reflection from it.
                if nearest.distance<=TIME_EPS then partialReason="environment_overlap";return nil end
                if not nearest.normal or math.abs(nearest.normal.y)>.25
                    or dot(dir,nearest.normal)>=-TIME_EPS then
                    failure="invalid_cushion_normal";return nil
                end
                nearest.normal=unit({x=nearest.normal.x,y=0,z=nearest.normal.z})
            end
            if nearest.kind=="cushion" and not materialMatches(nearest.material,.5,.8,0) then
                partialReason="physics_material_mismatch";return nil
            end
            nearest.distance=nearest.distance+offset
            nearest.direction=dir
            if nearest.ambiguous then nearest.kind="ambiguous" end
        else
            -- This is only a verified empty sweep window, not a rail or a line.
            -- Earlier analytical collisions may still provide a bounded path.
            nearest={kind="open",distance=MAX_DISTANCE,direction=dir}
        end
        body.afterCushion=false
        return nearest
    end
    local bodies,affected={},{}
    for _,row in ipairs(result.balls) do
        if row.active and not row.potted then
            local record=ballByTag[row.tag]
            bodies[#bodies+1]={tag=row.tag,radius=record.radius,mass=row.mass,inertia=row.inertiaTensor.x,
                drag=row.drag,angularDrag=row.angularDrag,position=record.position,
                velocity=zero(),omega=zero(),trace=record.position,
                kind=row.tag==1 and "cue" or "object",bounces=0,live=true,resting=true}
        end
    end
    for _,body in ipairs(bodies) do
        if body.tag==1 then
            body.velocity=add(zero(),direction,diagnostics.launchSpeed)
            local impulse=add(zero(),direction,diagnostics.launchSpeed*body.mass)
            local torqueY=add(zero(),{x=0,y=1,z=0},-spinX*hitAngle*length(impulse)*.1)
            local torqueRoll=add(zero(),cross({x=0,y=1,z=0},impulse),-(spinY*hitAngle+.008)*.1)
            body.omega=add(torqueY,torqueRoll,1)
            body.omega=add(zero(),body.omega,1/body.inertia)
            body.resting=false;affected[1]=true
        end
    end
    local function movingBody(body) return body.live and length(body.velocity)>VELOCITY_EPS end
    local function workingBody(body) return body.live and not body.resting end
    local function emit(body,terminal,targetTag)
        if length(subtract(body.position,body.trace))<.000000001 then body.trace=body.position;return true end
        if #segments>=MAX_SEGMENTS then partialReason="segment_limit";return false end
        local from,to=project(body.trace),project(body.position)
        if not from or not to then failure="guide_projection_failed";return false end
        local row={kind=body.kind,from=from,to=to,worldFrom=body.trace,worldTo=body.position,
            ballTag=body.tag,eventIndex=math.max(1,events),terminal=terminal,timeSeconds=clock}
        if terminal=="ball" then row.hitBallTag=targetTag end
        segments[#segments+1]=row;body.trace=body.position
        return true
    end
    local function eventCount()
        if events>=MAX_EVENTS then partialReason="event_limit";return false end
        events=events+1;return true
    end
    local function frictionAndDamping(body)
        local r={x=0,y=-body.radius,z=0}
        local contact=add(body.velocity,cross(body.omega,r),1)
        contact.y=0
        local slip=length(contact)
        if slip>TIME_EPS then
            local tangent=unit(contact)
            local arm=cross(r,tangent)
            local denominator=1/body.mass+dot(arm,arm)/body.inertia
            local impulse=math.min(diagnostics.muTable*body.mass*(-gravity.y)*step,slip/denominator)
            local push=add(zero(),tangent,-impulse)
            body.velocity=add(body.velocity,push,1/body.mass)
            body.omega=add(body.omega,cross(r,push),1/body.inertia)
        end
        body.velocity=add(zero(),body.velocity,1-body.drag*step)
        body.omega=add(zero(),body.omega,1-body.angularDrag*step)
        body.velocity.y=0
    end
    local function pairTime(a,b)
        if not a.live or not b.live then return nil end
        local position=subtract(b.position,a.position)
        local velocity=subtract(b.velocity,a.velocity)
        local speed2=dot(velocity,velocity)
        if speed2<VELOCITY_EPS*VELOCITY_EPS then return nil end
        local closing=dot(position,velocity)
        if closing>=-TIME_EPS then return nil end
        local radius=a.radius+b.radius
        local gap=dot(position,position)-radius*radius
        if gap < -CONTACT_EPS then partialReason="overlapping_ball_geometry";return nil end
        if gap<=CONTACT_EPS then return 0 end
        local d=closing*closing-speed2*gap
        if d<=TIME_EPS*TIME_EPS then return nil end
        return math.max(0,(-closing-math.sqrt(d))/speed2)
    end
    local function shares(a,b) return a.a==b.a or a.a==b.b or (a.b and (a.b==b.a or a.b==b.b)) end
    local function advance(dt)
        for _,body in ipairs(bodies) do
            if movingBody(body) then
                local distance=length(body.velocity)*dt
                body.position=add(body.position,body.velocity,dt)
                if body.cached then body.cached.distance=math.max(0,body.cached.distance-distance) end
            end
        end
        clock=math.min(MAX_SECONDS,clock+dt)
    end
    local function cushionImpulse(body,normal)
        local normalSpeed=dot(body.velocity,normal)
        local normalImpulse=-(1+.8)*normalSpeed*body.mass
        body.velocity=add(body.velocity,normal,normalImpulse/body.mass)
        local r=add(zero(),normal,-body.radius)
        local tangent=cross({x=0,y=1,z=0},normal)
        local contact=add(body.velocity,cross(body.omega,r),1)
        local inertiaTerm=body.radius*body.radius/body.inertia
        local jh=-dot(contact,tangent)/(1/body.mass+inertiaTerm)
        local jv=-contact.y/inertiaTerm
        local magnitude=math.sqrt(jh*jh+jv*jv)
        if magnitude>normalImpulse*.5 and magnitude>0 then
            local scale=normalImpulse*.5/magnitude;jh=jh*scale;jv=jv*scale
        end
        local push=add({x=0,y=jv,z=0},tangent,jh)
        body.velocity=add(body.velocity,push,1/body.mass);body.velocity.y=0
        body.omega=add(body.omega,cross(r,push),1/body.inertia)
    end
    while not failure and not partialReason and steps<MAX_STEPS and clock<MAX_SECONDS-TIME_EPS do
        local any=false
        for _,body in ipairs(bodies) do if workingBody(body) then any=true;break end end
        if not any then break end
        steps=steps+1
        for _,body in ipairs(bodies) do
            if workingBody(body) then
                frictionAndDamping(body)
                local newDirection=unit(body.velocity)
                if body.cached and (not newDirection or dot(body.cached.direction,newDirection)<1-1e-10) then
                    body.cached=nil
                end
                -- Split curved slip paths into short geometric chords. The
                -- previous chord ends at the actual accumulated position.
                local chord=unit(subtract(body.position,body.trace))
                if chord and newDirection and dot(chord,newDirection)<.99995 then
                    if not eventCount() or not emit(body,"horizon") then break end
                end
            end
        end
        local remaining=math.min(step,MAX_SECONDS-clock)
        while remaining>TIME_EPS and not failure and not partialReason do
            local candidates={}
            for _,body in ipairs(bodies) do
                if movingBody(body) then
                    if not body.cached then body.cached=cast(body) end
                    if failure or partialReason then break end
                    local dt=body.cached.distance/length(body.velocity)
                    if dt<=remaining+TIME_EPS then
                        candidates[#candidates+1]={dt=math.max(0,dt),kind=body.cached.kind,a=body,normal=body.cached.normal}
                    end
                end
            end
            if failure or partialReason then break end
            for i=1,#bodies-1 do for j=i+1,#bodies do
                local dt=pairTime(bodies[i],bodies[j])
                if dt and dt<=remaining+TIME_EPS then candidates[#candidates+1]={dt=dt,kind="ball",a=bodies[i],b=bodies[j]} end
            end end
            if partialReason then break end
            table.sort(candidates,function(a,b)
                if a.dt~=b.dt then return a.dt<b.dt end
                if a.a.tag~=b.a.tag then return a.a.tag<b.a.tag end
                return (a.b and a.b.tag or 0)<(b.b and b.b.tag or 0)
            end)
            local event=candidates[1]
            if not event then advance(remaining);remaining=0;break end
            if event.kind=="open" then partialReason="open_path_unknown";break end
            local ambiguous=event.kind=="ambiguous"
            for i=2,#candidates do
                if candidates[i].dt-event.dt>TIME_EPS then break end
                if shares(event,candidates[i]) then ambiguous=true;break end
            end
            if not eventCount() then break end
            advance(math.min(event.dt,remaining));remaining=math.max(0,remaining-event.dt)
            if ambiguous then partialReason="simultaneous_contacts";break end
            local a,b=event.a,event.b
            if event.kind=="ball" then
                local normal=unit(subtract(b.position,a.position))
                if not normal or math.abs(normal.y)>.05 then failure="invalid_ball_contact";break end
                local closing=dot(subtract(a.velocity,b.velocity),normal)
                if closing<=TIME_EPS then partialReason="degenerate_ball_contact";break end
                if not emit(a,"ball",b.tag) or not emit(b,"ball",a.tag) then break end
                local impulse=2*closing/(1/a.mass+1/b.mass)
                a.velocity=add(a.velocity,normal,-impulse/a.mass)
                b.velocity=add(b.velocity,normal,impulse/b.mass)
                a.cached,b.cached=nil,nil;a.afterCushion,b.afterCushion=false,false
                a.resting,b.resting=false,false;affected[a.tag],affected[b.tag]=true,true
                a.kind=a.tag==1 and "cue" or "object";b.kind=b.tag==1 and "cue" or "object"
                collisions=collisions+1
            elseif event.kind=="pocket" then
                if not emit(a,"pocket") then break end
                a.live=false;a.potted=true;a.velocity=zero();a.omega=zero();a.cached=nil
            elseif event.kind=="cushion" then
                if a.bounces>=MAX_BOUNCES then emit(a,"limit");partialReason="bounce_limit";break end
                if not emit(a,"cushion") then break end
                cushionImpulse(a,event.normal)
                a.kind="rebound";a.bounces=a.bounces+1;bounces=bounces+1
                a.cached=nil;a.afterCushion=true
            end
        end
        if failure or partialReason then break end
        -- Source onUpdate performs these cutoffs after the physics step. A
        -- zeroed linear speed alone is not a rest while angular energy remains.
        for _,body in ipairs(bodies) do
            if workingBody(body) then
                if dot(body.velocity,body.velocity)<stopSquared then body.velocity=zero();body.cached=nil end
                if length(body.omega)<stopAngular then body.omega=zero() end
                if length(body.velocity)==0 and length(body.omega)==0 then
                    if not eventCount() or not emit(body,"rest") then break end
                    body.resting=true;body.cached=nil
                end
            end
        end
    end
    local complete=not failure and not partialReason
    if complete then
        for _,body in ipairs(bodies) do if workingBody(body) then complete=false;partialReason="time_limit";break end end
    end
    if not failure and partialReason then
        if events==0 then eventCount() end
        for _,body in ipairs(bodies) do if affected[body.tag] and body.live then if not emit(body,"limit") then break end end end
    end
    local finalStates=array();local affectedCount=0
    for _,body in ipairs(bodies) do
        if affected[body.tag] then
            affectedCount=affectedCount+1
            local point=project(body.position)
            if not point then failure="guide_projection_failed";complete=false;break end
            finalStates[#finalStates+1]={ballTag=body.tag,world=body.position,screen=point,
                outcome=body.potted and "pocket" or (complete and body.resting and "rest" or "unknown")}
        end
    end
    result.prediction.events=events;result.prediction.queries=queries
    result.prediction.collisions=collisions;result.prediction.bounces=bounces
    result.prediction.affectedBallCount=affectedCount;result.prediction.truncated=partialReason~=nil
    result.prediction.durationSeconds=clock;result.prediction.stepCount=steps
    result.prediction.complete=complete;result.prediction.finalStates=finalStates
    if failure then result.prediction.complete=false;return stop("unsupported",failure) end
    if #segments==0 then result.prediction.complete=false;return stop("not_ready",partialReason or "no_bounded_trajectory") end
    result.segments=segments;result.prediction.available=true
    result.prediction.reason=partialReason or "finite_sliding_rolling_estimate"
    return result
end
local ok, value = pcall(sample)
if not ok then
    if actionCommand then controlStatus("uncertain","controller_exception") end
    value=stop("error","observer_exception")
end
local encoded, json = pcall(encode,value)
if encoded then return json end
return '{"format":"SDKtools.BilliardsLive","schema":"SDKtools.BilliardsLive","schemaVersion":1,"resourceGameId":20,"gameType":1003,"status":"error","balls":[],"segments":[],"prediction":{"available":false,"reason":"serialization_failed","model":"finite","maxBounces":6,"chainVersion":2,"events":0,"queries":0,"collisions":0,"bounces":0,"affectedBallCount":0,"truncated":false,"durationSeconds":0,"stepCount":0,"complete":false,"calibration":"captured_damping_sliding_v1","finalStates":[]}}'

/* Owned-stock, conservative rescue power coordinator. No direct transport, stock writes or purchases.
 * One original popup open and one separately revalidated original confirmation.
 * Storage(0), Withdraw(1), Refresh(2), owned Penetrate(3), remove(5).
 * Bomb(4) stays blocked: server target selection is not proven.
 * A stock decrement AND a matching, stable board effect are required. */
(function (originalPower, makeCovered, win) {
  'use strict';
  var active=null, lastAttempt=null, spentSinceMove=false, confirmed=0;
  var diagnostic={status:'off',confirmed:0},decision=null,owned=null;
  try{if(typeof makeCovered==='function')owned=makeCovered();}catch(_){}
  var baseline=win&&typeof win.fork==='function'?win.fork():null,forecast=win&&typeof win.fork==='function'?win.fork():null;
  function percent(model){return model&&['exact','estimated'].indexOf(model.status)>=0&&typeof model.winPercent==='number'&&Number.isFinite(model.winPercent)?model.winPercent:null;}
  function modelAfter(s,target,pair){
    var gone=new Set([target.id].concat(pair.map(function(c){return c.id;})));
    return {signature:s.signature+':owned-penetrate:'+target.id,capacity:s.capacity,
      tray:s.tray.filter(function(c){return !gone.has(c.id);}),
      cards:s.cards.filter(function(c){return !gone.has(c.id);}).map(function(c){
        var blockers=c.blockedBy.filter(function(id){return !gone.has(id);});
        return Object.assign({},c,{blockedBy:blockers,available:blockers.length===0});
      })};
  }
  function removeHelps(s){
    var h=s.tray,exposed=s.cards.filter(function(c){return c.available&&c.selectable!==false;});
    if(h.length<4)return false;
    // The server supplies removed_slot_blocks. Do not pretend to choose them.
    for(var i=0;i<h.length-2;i++)for(var j=i+1;j<h.length-1;j++)for(var k=j+1;k<h.length;k++)
      if(!directTrio(h.filter(function(_,n){return n!==i&&n!==j&&n!==k;}),exposed,s.capacity))return false;
    return true;
  }
  function assess(s,r,lastID,lastState){
    decision={policy:'conserve',guaranteedCleared:0,freedSlots:0};
    var base=baseline?baseline.observe(s,true):null,p=percent(base);if(p!==null)decision.baselinePercent=p;
    // Win is a local no-power model, not a measured success rate. A complete
    // 100% model leaves no justification for spending a rescue power.
    if(base&&base.status==='exact'&&base.winPercent===100)return null;
    var exposed=s.cards.filter(function(c){return c.available&&c.selectable!==false;});
    if(directTrio(s.tray,exposed,s.capacity))return null;
    function stock(type){var m=r.inventory.filter(function(v){return own(v,'type')===type&&own(v,'count')>0;});return m.length===1?m[0]:null;}
    var pen=stock(3),pair=null,target=null;
    if(pen&&owned&&own(pen,'id')==='3-'+String(r.uid)){
      var reveals=new Map();s.cards.forEach(function(c){c.blockedBy.forEach(function(id){reveals.set(id,(reveals.get(id)||0)+1);});});
      var choices=s.cards.filter(function(c){return c.zone==='board'&&c.masked===true&&c.selectable===true&&
        Array.isArray(c.blockedBy)&&c.blockedBy.length&&c.metadata&&c.metadata.specialType===0&&c.metadata.lock===0&&
        s.tray.filter(function(t){return t.type===c.type&&t.metadata&&t.metadata.specialType===0;}).length===2;});
      choices.sort(function(a,b){return Number(!!s.mission&&b.type===s.mission.type)-Number(!!s.mission&&a.type===s.mission.type)||
        (reveals.get(b.id)||0)-(reveals.get(a.id)||0)||
        a.occlusionDepth-b.occlusionDepth||a.order-b.order;});
      target=choices[0];
      if(target){
        pair=s.tray.filter(function(t){return t.type===target.type;});
        var predicted=forecast?forecast.observe(modelAfter(s,target,pair),true):null,q=percent(predicted);
        if(q!==null)decision.forecastPercent=q;
        if(!(base&&base.status==='exact'&&predicted&&predicted.status==='exact'&&predicted.winPercent<base.winPercent)){
          Object.assign(decision,{policy:'complete_trio',guaranteedCleared:3,freedSlots:2});
          return {id:own(pen,'id'),count:own(pen,'count'),type:3,target:target,pair:pair};
        }
      }
    }
    delete decision.forecastPercent; // A rejected target's forecast is not another power's forecast.
    if(s.tray.length<4)return null;
    var priority=[1,0,5,2];
    for(var k=0;k<priority.length;k++){
      var type=priority[k],matches=r.slots.filter(function(p){return p.type===type&&p.count>0;});if(matches.length!==1)continue;
      if(type===0&&(s.cards.some(function(c){return c.zone==='reserve';})||!storageHelps(s)))continue;
      if(type===1&&(!s.tray.some(function(c){return c.rawID===lastID;})||[0,2].indexOf(lastState)<0||!withdrawHelps(s,lastID,lastState)))continue;
      if(type===5&&!removeHelps(s))continue;
      // Refresh is random: no fabricated win delta. Require a crowded hand,
      // a real pair, and mixed non-hand faces that can actually be reshuffled.
      if(type===2&&(s.tray.length<5||!s.tray.some(function(c){return s.tray.filter(function(t){return t.type===c.type;}).length===2;})||
        !s.tray.some(function(c){return s.tray.filter(function(t){return t.type===c.type;}).length===2&&s.cards.some(function(t){return t.type===c.type;});})||
        new Set(s.cards.map(function(c){return c.type;})).size<2))continue;
      Object.assign(decision,{policy:{0:'store_for_trio',1:'free_slot',2:'shuffle_rescue',5:'remove_for_trio'}[type],freedSlots:{0:3,1:1,2:0,5:3}[type]});
      return matches[0];
    }
    if(stock(4))decision.policy='bomb_unmodeled';
    return null;
  }
  function own(o,k){var d=o&&Object.getOwnPropertyDescriptor(o,k);return d&&Object.prototype.hasOwnProperty.call(d,'value')?d.value:undefined;}
  function int(v,l,h){return Number.isInteger(v)&&v>=l&&v<=h;}
  function visible(n){return n&&n.isValid===true&&n.activeInHierarchy===true&&n.opacity>0;}
  function now(){return performance.now();}
  function read(){
    var cc=window.cc,root=cc&&cc.director.getScene(),start=now(),seen=new Set(),stack=[root],games=[],popups=[],alerts=[];
    var primary=cc&&cc.ENGINE_VERSION,fallback=window.CocosEngine;
    if(!cc||(typeof primary==='string'&&typeof fallback==='string'&&primary!==fallback)||
      (typeof primary==='string'?primary:fallback)!=='2.4.4'||!visible(root)||document.visibilityState!=='visible')throw Error('context');
    while(stack.length){
      if(seen.size>=4096||now()-start>=18)throw Error('budget');
      var n=stack.pop();if(!n||seen.has(n))throw Error('scene');seen.add(n);if(!visible(n))continue;
      var comps=n.getComponents?n.getComponents(cc.Component):[];
      if(!Array.isArray(comps)||comps.length>32||!Array.isArray(n.children)||n.children.length>512)throw Error('scene');
      comps.forEach(function(c){var name=cc.js.getClassName(c);if(name==='Game')games.push(c);
        if(typeof name==='string'&&/Alert$/.test(name)){alerts.push(c);if(name==='UsePropAlert')popups.push(c);}});
      n.children.forEach(function(child){if(child.parent!==n)throw Error('parent');stack.push(child);});
    }
    if(games.length!==1)throw Error('game');
    var game=games[0],layer=own(game,'GameLayer'),area=own(layer,'PropArea'),row=own(area,'AreaNode');
    var loader=own(window,'__require'),store=typeof loader==='function'?own(loader('GameStore'),'default'):null;
    var socket=typeof loader==='function'?own(loader('Socket'),'default'):null,ws=own(socket,'socket');
    if(!ws||ws.readyState!==1)throw Error('connection');
    if(!layer||!area||cc.js.getClassName(layer)!=='GameLayer'||cc.js.getClassName(area)!=='PropArea'||
      layer.isValid!==true||area.isValid!==true||!seen.has(layer.node)||!seen.has(area.node)||!seen.has(row)||
      !row||row.width!==292||row.height!==90||row.children.length!==3||own(store,'isWatcher')!==false||
      own(store,'state')!==2||own(store,'isHotTiming')!==false||own(store,'isAddingCommonBlock')!==false||
      own(store,'isUsingPenetrateProp')!==false||own(store,'isCanTouchBlock')!==true)throw Error('state');
    if(game.isValid!==true||game.enabled===false||game.enabledInHierarchy===false||layer.enabled===false||area.enabled===false)throw Error('game');
    function inside(node,parent){for(var depth=0;node&&depth<=24;depth++,node=node.parent)if(node===parent)return true;return false;}
    if(!inside(layer.node,game.node)||!inside(area.node,layer.node)||!inside(row,area.node))throw Error('owner');
    var uid=own(store,'uid'),gamers=own(store,'gamers');
    if(!(typeof uid==='string'&&uid.length>0&&uid.length<=128)&&!int(uid,1,9007199254740991))throw Error('player');
    if(own(socket,'uid')!==uid)throw Error('player');
    if(!Array.isArray(gamers)||gamers.filter(function(g){return own(g,'uid')===uid&&own(g,'state')===1;}).length!==1)throw Error('player');
    var startTime=own(store,'start_time'),rid=own(store,'rid');
    if(!(typeof rid==='number'||typeof rid==='string')||!int(startTime,1,9007199254740991))throw Error('round');
    if(own(socket,'rid')!==rid)throw Error('round');
    var inventory=own(store,'props_blocks');if(!Array.isArray(inventory)||inventory.length>16)throw Error('stock');
    var slots=row.children.map(function(n,i){
      var list=n.getComponents(cc.Component),props=list.filter(function(c){return cc.js.getClassName(c)==='Prop';});
      if(props.length!==1||!visible(n)||n.parent!==row)throw Error('prop');
      var p=props[0],info=own(p,'propInfo'),id=own(info,'id'),type=own(info,'type'),count=own(info,'count');
      var matches=inventory.filter(function(v){return own(v,'id')===id&&own(v,'type')===type&&own(v,'count')===count;});
      if(p.isValid!==true||p.node!==n||!int(type,0,5)||!int(count,0,1000000)||matches.length!==1||
        own(p,'id')!==id||own(p,'type')!==type||own(p,'num')!==count)throw Error('stock');
      return {id:id,type:type,count:count,slot:['left','center','right'][i],prop:p};
    });
    if(new Set(slots.map(function(s){return s.id;})).size!==3)throw Error('stock');
    var ids=new Set(),types=new Set();inventory.forEach(function(p){var id=own(p,'id'),type=own(p,'type'),count=own(p,'count');
      if(typeof id!=='string'||!id||id.length>128||!int(type,0,5)||!int(count,0,1000000)||ids.has(id)||types.has(type))throw Error('stock');
      ids.add(id);types.add(type);});
    return {cc:cc,root:root,store:store,layer:layer,uid:uid,startTime:startTime,rid:rid,socket:socket,ws:ws,socketRoom:own(socket,'rid'),slots:slots,inventory:inventory,popups:popups,alerts:alerts};
  }
  function same(a,b){return a.root===b.root&&a.store===b.store&&a.layer===b.layer&&a.uid===b.uid&&a.startTime===b.startTime&&a.rid===b.rid&&
    a.socket===b.socket&&a.ws===b.ws&&a.socketRoom===b.socketRoom;}
  function status(value){diagnostic=Object.assign({status:value,confirmed:confirmed},decision||{});
    if(active){diagnostic.type=active.power.type;diagnostic.stockBefore=active.power.count;
      if(active.power.type===3&&owned){var d=owned.diagnostic();diagnostic.responseOutcome=d.responseOutcome;}}
    return diagnostic;}
  function census(store){
    var rows=[];['pile_blocks','hand_blocks','storage_blocks'].forEach(function(key){var list=own(store,key);
      if(!Array.isArray(list)||list.length>512)throw Error('census');
      list.flat().forEach(function(c){if(c===null&&key==='storage_blocks')return;
        var id=own(c,'id'),type=own(c,'type'),state=own(c,'state');
        if(typeof id!=='string'||!int(type,0,10000)||!int(state,0,2))throw Error('census');var special=own(c,'special_info'),storage=own(c,'storage_info');
        rows.push([id,type,state,own(c,'layer'),own(c,'row'),own(c,'col'),own(special,'type'),own(special,'lock_state'),own(storage,'layer'),own(storage,'index')]);});});
    if(rows.length>512||new Set(rows.map(function(c){return c[0];})).size!==rows.length)throw Error('census');
    return JSON.stringify(rows.sort(function(a,b){return a[0]<b[0]?-1:a[0]>b[0]?1:0;}));
  }
  function board(s){return s.cards.concat(s.tray).map(function(c){return {id:c.id,rawID:c.rawID,type:c.type,zone:c.zone};});}
  function directTrio(hand,exposed,capacity){
    var h=new Map(),a=new Map();hand.forEach(function(c){h.set(c.type,(h.get(c.type)||0)+1);});
    exposed.forEach(function(c){a.set(c.type,(a.get(c.type)||0)+1);});
    var possible=false;a.forEach(function(n,t){var needed=3-(h.get(t)||0);if(n>=needed&&needed<=capacity-hand.length)possible=true;});
    return possible;
  }
  function storageHelps(s){
    // The server chooses the three stored cards. Do not assume which three:
    // every three-card subset must leave at least one exposed completable trio.
    var h=s.tray,exposed=s.cards.filter(function(c){return c.available&&c.selectable!==false;});
    for(var i=0;i<h.length-2;i++)for(var j=i+1;j<h.length-1;j++)for(var k=j+1;k<h.length;k++){
      var left=h.filter(function(_,n){return n!==i&&n!==j&&n!==k;});
      // Unknown future reserve placement cannot authorize a re-pick. Require
      // an independently exposed board trio for every server-selected subset.
      if(!directTrio(left,exposed,s.capacity))return false;
    }
    return h.length>=3;
  }
  function withdrawHelps(s,id,state){
    var card=s.tray.filter(function(c){return c.rawID===id;})[0];if(!card||card.selectable===false)return false;
    var exposed=s.cards.filter(function(c){return c.available&&c.selectable!==false;}),left=s.tray.filter(function(c){return c!==card;});
    if(state===0){
      var info=own(card.metadata.block,'blockInfo'),layer=own(info,'layer'),pieces=id.split('-'),row=Number(pieces[1]),col=Number(pieces[2]);
      if(!int(layer,0,10000)||pieces.length<3||!Number.isFinite(row)||!Number.isFinite(col))return false;
      var near=function(c){return c.zone==='board'&&Math.abs(c.gridRow-row)<16&&Math.abs(c.gridCol-col)<20;};
      exposed=exposed.filter(function(c){return !(near(c)&&layer>c.layer);});
      if(!s.cards.some(function(c){return near(c)&&c.layer>layer;}))exposed.push(card);
    }else exposed=exposed.filter(function(c){return c.zone==='board';}); // Restored reserve position is server-selected.
    return directTrio(left,exposed,s.capacity);
  }
  function effect(a,s){
    if(a.power.type===3){
      var gone=new Set([a.power.target.id].concat(a.power.pair.map(function(c){return c.id;}))),left=a.before.filter(function(c){return !gone.has(c.id);}),remaining=board(s);
      return remaining.length===left.length&&left.every(function(c){return remaining.some(function(v){return v.id===c.id&&v.type===c.type&&v.zone===c.zone;});});
    }
    var after=board(s),before=a.before,byID=new Map(after.map(function(c){return [c.id,c];}));
    if(a.power.type===5){
      var removed=before.filter(function(c){return !byID.has(c.id);});
      return removed.length===3&&removed.every(function(c){return c.zone==='tray';})&&after.length===before.length-3&&
        after.every(function(c){return before.some(function(v){return v.id===c.id&&v.type===c.type&&v.zone===c.zone;});});
    }
    if(before.length!==after.length||before.some(function(c){return !byID.has(c.id);}))return false;
    var moved=[];
    for(var i=0;i<before.length;i++){
      var b=before[i],c=byID.get(b.id);
      if(a.power.type!==2&&b.type!==c.type)return false;
      if(b.zone!==c.zone)moved.push({before:b,after:c});
    }
    if(a.power.type===0)return moved.length===3&&moved.every(function(c){return c.before.zone==='tray'&&c.after.zone==='reserve';});
    if(a.power.type===1)return moved.length===1&&moved[0].before.rawID===a.lastBlock&&moved[0].before.zone==='tray'&&
      moved[0].after.zone===(a.lastState===0?'board':'reserve');
    // Refresh can change types, not identity/zone or the existing hand.
    return moved.length===0&&before.filter(function(c){return c.zone==='tray';}).every(function(c){return byID.get(c.id).type===c.type;})&&
      before.some(function(c){return c.zone!=='tray'&&byID.get(c.id).type!==c.type;});
  }
  return {
    diagnostic:function(){return diagnostic;},
    busy:function(){return !!active;},
    needsPopup:function(){return active&&active.phase==='opening';},
    normalConfirmed:function(){spentSinceMove=false;},
    freeze:function(){if(active)active.stable=null;if(owned)owned.invalidate();},
    beginPlanned:function(s,options,prescribed){return this.begin(s,options,'global_prescribed',prescribed);},
    begin:function(s,options,reason,prescribed){
      if(active)return false;
      if(options.powersEnabled!==true||options.allowAction!==true||(!prescribed&&spentSinceMove)||typeof originalPower!=='function')return false;
      if((!prescribed&&['no_complete_solution','no_remaining_triples','search_limit_reached','no_safe_move','global_no_route','global_search_limit'].indexOf(reason)<0)||s.tray.length>=s.capacity)return false;
      try{
        var r=read();if(r.root!==s.root||r.layer.node!==s.gameLayer||r.alerts.length)return false;
        var candidate=null,last=own(r.store,'last_block'),lastID=own(last,'id'),lastState=own(last,'state');
        if(prescribed){
          if(reason!=='global_prescribed'||prescribed.signature!==s.signature||[1,3].indexOf(prescribed.type)<0)return false;
          var target=s.refs.get(prescribed.targetID),stock=r.inventory.filter(function(v){return own(v,'type')===prescribed.type&&own(v,'count')>0;});
          if(!target||stock.length!==1||!target.metadata||target.metadata.specialType!==0||target.metadata.lock!==0)return false;
          if(prescribed.type===3){
            var pair=s.tray.filter(function(c){return c.type===target.type&&c.metadata.specialType===0;});
            if(!owned||target.zone!=='board'||target.masked!==true||!target.blockedBy.length||pair.length!==2||own(stock[0],'id')!=='3-'+String(r.uid))return false;
            candidate={id:own(stock[0],'id'),count:own(stock[0],'count'),type:3,target:target,pair:pair};
          }else{
            var slots=r.slots.filter(function(v){return v.type===1&&v.count>0;});
            if(slots.length!==1||target.zone!=='tray'||target.rawID!==lastID||lastState!==0)return false;
            candidate=slots[0];
          }
          decision={policy:prescribed.type===3?'complete_trio':'free_slot',guaranteedCleared:prescribed.type===3?3:0,freedSlots:prescribed.type===3?2:1};
        }else candidate=assess(s,r,lastID,lastState);
        if(!candidate){status('unavailable');return false;}
        var key=JSON.stringify([r.startTime,r.rid,s.signature,candidate.id,candidate.count]);
        if(lastAttempt===key)return false;lastAttempt=key;
        active={context:r,power:candidate,phase:candidate.type===3?'submitted':'opening',before:board(s),census:census(r.store),time:now(),stable:null,lastBlock:lastID,lastState:lastState};
        if(candidate.type===3){
          // Revalidated positive stock + exact hand pair, observed original call.
          // The original game builds its own request. Never enter the zero-stock
          // experiment, write selection flags or emit a normal covered touch.
          var invoked=owned.dispatch(s,candidate.target,function(){
            var returned=r.socket.UseProp(candidate.id,candidate.target.rawID);
            Promise.prototype.then.call(returned,function(){},function(){});return returned;
          },{kind:'penetrate_owned'});
          if(!invoked){active=null;status('unavailable');return false;}
          spentSinceMove=true;status('submitted');return true;
        }
        // Set the latch BEFORE the original event, including an exception.
        var out=originalPower({command:'open',slot:candidate.slot,ownedInventory:true});
        if(out.status!=='original_event_dispatched'){if(out.status==='no_action')active=null;else active.phase='uncertain';status('uncertain');return false;}
        status('opening');return true;
      }catch(_){if(active){active.phase='uncertain';status('uncertain');}else status('unavailable');return false;}
    },
    tick:function(options,s){
      if(!active){status(options.powersEnabled===true?'ready':'off');return {status:'watching',reason:'action_disabled'};}
      var a=active,r;
      try{r=read();}catch(_){a.stable=null;status('uncertain');return {status:'waiting_confirmation',reason:'power_context_unavailable'};}
      if(!same(a.context,r)){a.stable=null;status('uncertain');return {status:'waiting_confirmation',reason:'power_context_changed'};}
      var stock=r.inventory.filter(function(p){return own(p,'id')===a.power.id&&own(p,'type')===a.power.type;});
      if(stock.length!==1){status('uncertain');return {status:'waiting_confirmation',reason:'power_context_changed'};}
      if(a.power.type===3){
        if(s)owned.observe(s);var observed=owned.diagnostic();
        if(!observed.pending&&observed.responseOutcome==='rejected'&&s&&stock[0].count===a.power.count){
          var unchanged=board(s),rollback=unchanged.length===a.before.length&&a.before.every(function(c){
            return unchanged.some(function(v){return v.id===c.id&&v.type===c.type&&v.zone===c.zone;});});
          if(rollback){active=null;decision.policy='conserve';status('ready');return {status:'watching',reason:'power_rejected'};}
        }
        // Even a 200 and a consumed stock are insufficient without the exact
        // selected triple disappearing and all unrelated cards remaining.
        if(observed.pending||observed.responseOutcome!=='accepted'||!observed.effectObserved){
          a.stable=null;status(observed.status==='uncertain'||observed.responseOutcome==='rejected'?'uncertain':'submitted');
          return {status:'waiting_confirmation',reason:'power_effect_pending'};
        }
      }
      if(a.phase==='opening'){
        // The user may confirm the already-open popup while Auto is paused.
        // Observe that consumption without emitting another confirmation; the
        // next complete snapshot must still prove the exact, stable effect.
        if(stock[0].count===a.power.count-1){
          a.phase='submitted';a.time=now();a.stable=null;spentSinceMove=true;status('submitted');
          return {status:'waiting_confirmation',reason:'power_effect_pending'};
        }
        if(options.allowAction!==true||options.powersEnabled!==true)return {status:'waiting_confirmation',reason:'power_paused'};
        if(now()-a.time>3500){status('uncertain');return {status:'waiting_confirmation',reason:'power_confirmation_uncertain'};}
        if(r.alerts.length!==1||r.popups.length!==1)return {status:'waiting_confirmation',reason:'power_popup_pending'};
        var info=own(r.popups[0],'propInfo');
        if(own(info,'id')!==a.power.id||own(info,'type')!==a.power.type||own(info,'count')!==a.power.count||stock[0].count!==a.power.count){
          status('uncertain');return {status:'waiting_confirmation',reason:'power_popup_mismatch'};}
        if(census(r.store)!==a.census||own(own(r.store,'last_block'),'id')!==a.lastBlock||own(own(r.store,'last_block'),'state')!==a.lastState){
          status('uncertain');return {status:'waiting_confirmation',reason:'power_context_changed'};}
        a.phase='submitted';a.time=now();spentSinceMove=true;
        var out;
        try{out=originalPower({command:'confirm',slot:a.power.slot,ownedInventory:true});}catch(_){out={status:'dispatch_uncertain'};}
        if(out.status!=='original_event_dispatched'){status('uncertain');return {status:'dispatch_uncertain',reason:'power_dispatch_uncertain',dispatched:true};}
        status('submitted');return {status:'original_event_dispatched',reason:'power_requested',dispatched:true};
      }
      if(s&&stock[0].count===a.power.count-1&&effect(a,s)){
        if(!a.stable||a.stable.signature!==s.signature){a.stable={signature:s.signature,time:now()};return {status:'waiting_confirmation',reason:'power_effect_stability'};}
        if(now()-a.stable.time>=80){confirmed++;active=null;status('confirmed');return {status:'watching',reason:'power_effect_confirmed'};}
      }else a.stable=null;
      status(now()-a.time>8000?'uncertain':'submitted');
      return {status:'waiting_confirmation',reason:now()-a.time>8000?'power_confirmation_uncertain':'power_effect_pending'};
    }
  };
})

/* SDKtools 3.12: bounded observation from WKUserScript document start.
 * This factory NEVER requests game data, writes cards, reveals hidden values,
 * evaluates source, or guesses an earlier value from a later occurrence of an ID.
 * Main-bundle contract: Creator 2.4.5 web-mobile, its CommonJS loader, and the
 * registered Card / HandArea / game classes. In the inspected bundle all six
 * allowlisted modules are eager entries, before window.__require is assigned.
 * A different bundle/registry is rejected; module factories are not hooked.
 * Native must bind this document to game 2007 and accept the hello. A reply is
 * only a lease, never evidence that a concealed card's identity was recovered.
 */
(function makeCardEarly(config) {
  'use strict';
  var LIMIT={duration:90000,lease:3000,interval:250,events:4096,totalBytes:4194304,
    queueBytes:262144,eventBytes:32768,batchBytes:49152,batchEvents:96,cards:256,players:8,pending:32};
  var COMMANDS=['CMD_SYNC','CMD_ENTER_GAME','CMD_PLAY_CARD','CMD_SELECT_COLOR','CMD_DOUBT','CMD_CHOOSE_GAMER','CMD_END_LOOK_OVER','CMD_GIVE_CARD','CMD_UNO','CMD_CATCH','CMD_CANCEL_AUTO'];
  var doc=window.document,engine=null,socket=null,store=null,cardProto=null,handProto=null,skin=null;
  var born=now(),lease=born,status='waiting',reason='awaiting_loader',stopped=false,approved=false;
  var patches=[],pending=[],queue=[],queueBytes=0,totalBytes=0,sequence=0,call=0,currentCall=0,connectionGeneration=0,round=1,startToken;
  var timer=null,inflight=false,requestBorn=0,endSent=false,afterGameOver=false,loaderWatch=null,sceneListener=null,firstSyncCallID=0;
  var objects=new WeakMap(),nodes=new WeakMap(),bindings=new WeakMap(),sprites=new WeakMap(),nextObject=0,nextNode=0;
  var stats={dropped:0,truncated:0,errors:0,decodedResponses:0,decoderMissed:0,staleBindings:0};
  var milestones={loaderSeen:false,modulesReady:false,beforeScene:false,beforeSocket:false,beforeFirstSync:false,hasInitialSync:false,lateAttach:false};
  var gaps=[],documentID='',handler=null;
  function now(){return window.performance&&typeof window.performance.now==='function'?window.performance.now():Date.now();}
  function object(v){return v!==null&&(typeof v==='object'||typeof v==='function');}
  function own(o,k){if(!object(o))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);return d&&Object.prototype.hasOwnProperty.call(d,'value')?d.value:undefined;}
  function integer(v,max){return typeof v==='number'&&Number.isInteger(v)&&v>=0&&v<=max;}
  function method(o,k){for(var i=0;object(o)&&i<6;i++,o=Object.getPrototypeOf(o)){var d=Object.getOwnPropertyDescriptor(o,k);if(d)return typeof d.value==='function'?d.value:null;}return null;}
  function alias(map,o,prefix){if(!object(o))return undefined;var id=map.get(o);if(!id){id=prefix+(prefix==='ec'?++nextObject:++nextNode);map.set(o,id);}return id;}
  function gap(value){if(gaps.indexOf(value)<0)gaps.push(value);}
  function restoreResolver(rec){if(rec.done)return;rec.done=true;try{if(own(rec.entry,'resolve')===rec.wrapper)Object.defineProperty(rec.entry,'resolve',rec.prior);}catch(_){stats.errors++;}}
  function cleanup(){
    if(timer!==null){window.clearInterval(timer);timer=null;}
    if(sceneListener)try{engine.director.off(engine.Director.EVENT_BEFORE_SCENE_LAUNCH,sceneListener);}catch(_){stats.errors++;}
    sceneListener=null;
    for(var i=patches.length-1;i>=0;i--){var p=patches[i];try{if(own(p.target,p.key)===p.wrapper){if(p.prior)Object.defineProperty(p.target,p.key,p.prior);else delete p.target[p.key];}}catch(_){stats.errors++;}}
    patches=[];pending.forEach(restoreResolver);pending=[];
    if(loaderWatch)try{var d=Object.getOwnPropertyDescriptor(window,'__require');if(d&&d.get===loaderWatch.get&&d.set===loaderWatch.set){
      if(loaderWatch.prior)Object.defineProperty(window,'__require',Object.assign({},loaderWatch.prior,{value:loaderWatch.value}));
      else if(loaderWatch.assigned)Object.defineProperty(window,'__require',{value:loaderWatch.value,writable:true,configurable:true,enumerable:true});
      else delete window.__require;
    }}catch(_){stats.errors++;}
    loaderWatch=null;
    if(typeof window.removeEventListener==='function')window.removeEventListener('pagehide',onPageHide);
    if(doc&&typeof doc.removeEventListener==='function')doc.removeEventListener('visibilitychange',onVisibility);
  }
  function close(why){if(stopped)return;stopped=true;status='stopped';reason=why;cleanup();if(!inflight)send('end');}
  function live(){
    if(stopped)return false;
    if(window.document!==doc){close('document_changed');return false;}
    if(doc&&(doc.hidden===true||doc.visibilityState==='hidden')){close('hidden_document');return false;}
    if(now()-born>=LIMIT.duration){close('duration_limit');return false;}
    if(now()-lease>=LIMIT.lease){close(inflight?'bridge_timeout':'lease_expired');return false;}
    return true;
  }
  function colorState(c){if(c.type===0)return c.color>=1&&c.color<=4?'candidate':'unknown';if(c.type===4||c.type===6||c.type===10)return integer(c.color,4)?'special':'unavailable';if(integer(c.color,4)&&c.color>0)return integer(c.type,10)&&c.type>0?'known':'candidate';return 'unavailable';}
  function observe(stage,value,id,parent,extra,component,cardReference){
    if(!live())return;
    try{
      if(sequence>=LIMIT.events){stats.dropped++;close('event_limit');return;}
      var start=now(),event={sequence:++sequence,stage:stage,elapsedMs:Math.max(0,Math.round(start-born)),callID:id||0,parentCallID:parent||0,connectionGeneration:connectionGeneration,round:round,truncated:false,cards:[]};
      var token=own(value,'start_time');if(integer(token,Number.MAX_SAFE_INTEGER)){if(startToken!==undefined&&startToken!==token){round++;afterGameOver=false;}startToken=token;event.round=round;}
      if(extra){if(extra.pushEvent===2)afterGameOver=false;if(extra.pushEvent===12)afterGameOver=true;Object.keys(extra).forEach(function(k){event[k]=extra[k];});}
      event.afterGameOver=afterGameOver;
      var state=own(value,'state');if(!integer(state,65535))state=own(store,'state');if(integer(state,65535))event.observedState=state;
      ['state','mode','game_mode_type','bet_level'].forEach(function(k){var n=own(value,k);if(integer(n,65535))event[k]=n;});
      if(component){var node=own(component,'node')||own(component,'_node'),nid=alias(nodes,node,'en');if(nid)event.nodeID=nid;}
      var gamers=own(value,'gamers');if(!Array.isArray(gamers))gamers=own(store,'gamers');
      function slotFor(uid){if(typeof uid!=='string'&&typeof uid!=='number')return null;if(!Array.isArray(gamers))return null;var match=null;for(var i=0;i<Math.min(gamers.length,LIMIT.players);i++)if(own(own(gamers,String(i)),'uid')===uid){if(match!==null)return null;match=i;}return match;}
      function card(v,zone,slot,index,group){
        if(!object(v))return;
        if(event.cards.length>=LIMIT.cards||now()-start>3){event.truncated=true;return;}
        var row={zone:zone,index:index,present:0,objectID:stage.indexOf('skin_')===0&&extra&&extra.objectID?extra.objectID:alias(objects,v,'ec')};if(slot!==null&&slot!==undefined)row.slot=slot;if(integer(group,7))row.group=group;
        ['id','type','color','num'].forEach(function(k,i){var n=own(v,k),max=i===0?65535:i===1?10:i===2?4:99;if(integer(n,max)){row[k]=n;row.present|=1<<i;}});
        row.colorState=colorState(row);event.cards.push(row);
      }
      function exactHand(reference){
        if(!object(reference))return null;var gs=own(store,'gamers'),match=null;if(!Array.isArray(gs)||gs.length>LIMIT.players)return null;
        for(var g=0;g<gs.length;g++){var cards=own(own(gs,String(g)),'cards');if(!Array.isArray(cards)||cards.length>LIMIT.cards)continue;for(var i=0;i<cards.length;i++){if(now()-start>3){event.truncated=true;return null;}if(own(cards,String(i))===reference){if(match)return null;match={slot:g,index:i};}}}return match;
      }
      function list(a,zone,slot,group){if(!Array.isArray(a))return;if(a.length>LIMIT.cards)event.truncated=true;for(var i=0;i<Math.min(a.length,LIMIT.cards);i++){card(own(a,String(i)),zone,slot,i,group);if(event.cards.length>=LIMIT.cards||now()-start>3){if(i+1<a.length)event.truncated=true;break;}}}
      function field(o,key,path,group,bucket){var d=object(o)?Object.getOwnPropertyDescriptor(o,key):null,v,f={path:path,presence:'absent'};if(integer(group,7))f.group=group;if(d){if(!Object.prototype.hasOwnProperty.call(d,'value'))f.presence='accessor';else{v=d.value;f.presence=v===null?'null':Array.isArray(v)?'array':object(v)?'object':'invalid';if(Array.isArray(v))f.count=Math.min(v.length,1000000);}}bucket.push(f);return v;}
      function ranks(o,key,path,zone){var a=field(o,key,path,null,event.resultFields);if(!Array.isArray(a))return;if(a.length>LIMIT.players)event.truncated=true;for(var i=0;i<Math.min(a.length,LIMIT.players);i++){var r=own(a,String(i));list(field(r,'cards',path+'_cards',i,event.resultFields),zone,slotFor(own(r,'uid')),i);}}
      if(stage==='card_setup_input'||stage==='card_setup_after'||stage.indexOf('skin_')===0){var handBinding=exactHand(cardReference||value);card(value,'visual',handBinding?handBinding.slot:null,handBinding?handBinding.index:0);}
      else if(stage==='hand_setup_input'||stage==='hand_setup_after')list(own(value,'cards'),'hand',slotFor(own(value,'uid')));
      else{
        event.payloadFields=[];event.resultFields=[];
        ['gamers','cards','card','look_over_cards','select_give_card'].forEach(function(k){field(value,k,k,null,event.payloadFields);});
        ranks(value,'rank_infos','rank_infos','result_rank');ranks(field(value,'game_over_info','game_over_info',null,event.resultFields),'rank_infos','game_over_rank_infos','result_sync');
        var current=own(value,'gamers');if(Array.isArray(current)){if(current.length>LIMIT.players)event.truncated=true;for(var g=0;g<Math.min(current.length,LIMIT.players);g++)list(own(own(current,String(g)),'cards'),'hand',g);}
        list(own(value,'discard_cards'),'discard',null);list(own(value,'cards'),'event',null);list(own(value,'look_over_cards'),'look_over',null);
        card(own(value,'card'),'draw',null,0);card(own(value,'select_give_card'),'selected',null,0);
        var penalty=field(value,'punish','punish',null,event.payloadFields);list(field(penalty,'cards','punish_cards',null,event.payloadFields),'punish',slotFor(own(penalty,'uid')));
        var penalties=field(value,'punish_list','punish_list',null,event.payloadFields);if(Array.isArray(penalties)){if(penalties.length>LIMIT.players)event.truncated=true;for(var pi=0;pi<Math.min(penalties.length,LIMIT.players);pi++){var p=own(penalties,String(pi));list(field(p,'cards','punish_list_cards',pi,event.payloadFields),'punish_list',slotFor(own(p,'uid')),pi);}}
        var selected=own(value,'color'),type=own(value,'card_type');if(integer(selected,4))event.selectedColor=selected;if(integer(type,10))event.eventCardType=type;
      }
      function counts(){event.colorCounts={known:0,special:0,unknown:0,candidate:0,unavailable:0};event.cards.forEach(function(c){event.colorCounts[c.colorState]++;});}
      counts();while(JSON.stringify(event).length>LIMIT.eventBytes-1024&&event.cards.length){event.cards.pop();event.truncated=true;}counts();
      // Only a same-response ID coincidence. It is never an identity proof and
      // never feeds the overlay. Require a unique masked hand occurrence.
      var selectedRows=event.cards.filter(function(c){return c.zone==='selected'&&c.id>0&&c.colorState==='known';});
      event.sideChannelCandidates=[];selectedRows.forEach(function(c){var hand=event.cards.filter(function(h){return h.zone==='hand'&&h.id===c.id;});if(hand.length===1&&hand[0].type===0&&hand[0].color===0&&!event.truncated){var h=hand[0],candidate={id:c.id,slot:h.slot,index:h.index,source:'selected',type:c.type,color:c.color,objectID:c.objectID,handObjectID:h.objectID,relation:'same_response_id_only',confidence:'candidate'};if(integer(c.num,99))candidate.num=c.num;event.sideChannelCandidates.push(candidate);}});
      var bytes=JSON.stringify(event).length;if(event.truncated)stats.truncated++;
      if(totalBytes+bytes>LIMIT.totalBytes){stats.dropped++;close('byte_limit');return;}
      if(queue.length>=LIMIT.batchEvents*4||queueBytes+bytes>LIMIT.queueBytes){stats.dropped++;gap('transport_loss');return;}
      queue.push({event:event,bytes:bytes});queueBytes+=bytes;totalBytes+=bytes;
    }catch(_){stats.errors++;}
  }
  function snapshot(events){return {version:1,status:status,reason:reason,elapsedMs:Math.max(0,Math.round(now()-born)),events:events,milestones:Object.assign({},milestones),gaps:gaps.slice(),counters:{lastSequence:sequence,totalEvents:sequence,dropped:stats.dropped,truncated:stats.truncated,errors:stats.errors,decodedResponses:stats.decodedResponses,decoderMissed:stats.decoderMissed,bytesQueued:queueBytes,totalBytes:totalBytes,staleBindings:stats.staleBindings},connectionGeneration:connectionGeneration,round:round};}
  function send(kind){
    if(inflight||!handler||(kind==='end'&&endSent))return;
    var events=[],bytes=0;if(kind!=='hello')while(queue.length&&events.length<LIMIT.batchEvents&&bytes+queue[0].bytes<=LIMIT.batchBytes){var item=queue.shift();events.push(item.event);bytes+=item.bytes;queueBytes-=item.bytes;}
    if(kind==='end'){endSent=true;stats.dropped+=queue.length;queue=[];queueBytes=0;}
    var payload={version:1,token:config.token,documentID:documentID,kind:kind,observation:snapshot(events)};
    inflight=true;requestBorn=now();
    try{var promise=handler.postMessage(payload);Promise.prototype.then.call(promise,function(reply){inflight=false;if(!reply||reply.active!==true){if(!stopped)close('bridge_rejected');return;}approved=true;lease=now();if(stopped){if(kind!=='end')send('end');}else if(kind==='hello')attemptInstall();},function(){inflight=false;gap('transport_loss');close('bridge_rejected');});}
    catch(_){inflight=false;gap('transport_loss');close('bridge_unavailable');}
  }
  function patch(target,key,build,optional){
    var prior=Object.getOwnPropertyDescriptor(target,key),original=method(target,key);
    if(!original||(prior&&(!Object.prototype.hasOwnProperty.call(prior,'value')||(!prior.configurable&&!prior.writable)))){if(optional)return false;throw new Error('observer_contract');}
    var wrapper=build(original);Object.defineProperty(target,key,prior?Object.assign({},prior,{value:wrapper}):{value:wrapper,writable:true,configurable:true,enumerable:false});patches.push({target:target,key:key,prior:prior,wrapper:wrapper});return true;
  }
  function paired(before,after){return function(original){return function(){if(!live())return original.apply(this,arguments);var parent=currentCall,id=++call;currentCall=id;observe(before,arguments[0],id,parent);try{var result=original.apply(this,arguments);observe(after,this,id,parent);return result;}finally{currentCall=parent;}};};}
  function trackResolver(entry,id,parent,command,map,packetID){
    pending=pending.filter(function(r){if(own(r.entry,'resolve')!==r.wrapper){r.done=true;return false;}if(own(socket,'responseMap')!==r.map||own(r.map,String(r.packetID))!==r.entry){restoreResolver(r);return false;}return !r.done;});var prior=object(entry)?Object.getOwnPropertyDescriptor(entry,'resolve'):null;
    if(pending.length>=LIMIT.pending||!prior||typeof prior.value!=='function'||(!prior.writable&&!prior.configurable)){stats.decoderMissed++;return false;}
    var rec={entry:entry,prior:prior,done:false,map:map,packetID:packetID},original=prior.value;
    rec.wrapper=function(){restoreResolver(rec);if(live()){stats.decodedResponses++;if(command==='CMD_SYNC'&&id===firstSyncCallID&&milestones.beforeFirstSync)milestones.hasInitialSync=true;observe('socket_decoded_response',arguments[0],id,parent,{command:command});}return original.apply(this,arguments);};
    try{Object.defineProperty(entry,'resolve',Object.assign({},prior,{value:rec.wrapper}));pending.push(rec);return true;}catch(_){stats.decoderMissed++;return false;}
  }
  function wrapPush(original){return function(){if(!live())return original.apply(this,arguments);var parent=currentCall,id=++call;currentCall=id;if(integer(arguments[0],19)&&arguments[0]>0&&arguments[0]!==14)observe('push_input',arguments[1],id,parent,{pushEvent:arguments[0]});try{return original.apply(this,arguments);}finally{currentCall=parent;}};}
  function installPush(){
    if(typeof own(socket,'pushHandler')!=='function')return;
    if(patches.some(function(p){return p.target===socket&&p.key==='pushHandler'&&own(socket,'pushHandler')===p.wrapper;}))return;
    try{patches.forEach(function(p){if(p.target===socket&&p.key==='pushHandler')p.retired=true;});patch(socket,'pushHandler',wrapPush);}catch(_){stats.errors++;gap('missing_push_registration');}
  }
  function bindCard(component,card){
    var old=bindings.get(component),node=own(component,'node')||own(component,'_node'),b={component:component,card:card,node:node,parent:own(node,'parent')||own(node,'_parent'),generation:old?old.generation+1:1,round:round,values:['id','type','color','num'].map(function(k){return own(card,k);})};bindings.set(component,b);
    ['bgSprite','typeSprite','backSprite'].forEach(function(k){var sprite=own(component,k);if(object(sprite))sprites.set(sprite,b);});return b;
  }
  function validBinding(b,sprite){if(!b||!live())return false;return bindings.get(b.component)===b&&sprites.get(sprite)===b&&own(b.component,'cardInfo')===b.card&&(own(b.component,'node')||own(b.component,'_node'))===b.node&&(own(b.node,'parent')||own(b.node,'_parent'))===b.parent&&round===b.round&&['id','type','color','num'].every(function(k,i){return own(b.card,k)===b.values[i];})&&(!engine||typeof engine.isValid!=='function'||engine.isValid(sprite));}
  function skinObserver(stage,typeIndex,colorIndex,numIndex,spriteIndex){return function(original){return function(){
    if(!live())return original.apply(this,arguments);var parent=currentCall,id=++call,b=sprites.get(arguments[spriteIndex]),sprite=arguments[spriteIndex];
    // Snapshot arguments immediately; the promise may settle after node reuse.
    var value={type:arguments[typeIndex],color:arguments[colorIndex]};if(numIndex>=0)value.num=arguments[numIndex];var originalCard=b&&b.card;if(originalCard&&integer(own(originalCard,'id'),65535))value.id=own(originalCard,'id');
    var info={bindingGeneration:b?b.generation:0,bindingValid:validBinding(b,sprite)};if(b)info.objectID=alias(objects,b.card,'ec');currentCall=id;observe(stage+'_input',value,id,parent,info,b&&b.component,originalCard);
    var result;try{result=original.apply(this,arguments);}finally{currentCall=parent;}
    function complete(){if(!live())return;var valid=validBinding(b,sprite);if(b&&!valid){stats.staleBindings++;gap('async_binding_changed');}var done={bindingGeneration:b?b.generation:0,bindingValid:valid};if(b)done.objectID=info.objectID;observe(stage+'_complete',value,id,parent,done,b&&b.component,originalCard);}
    if(object(result)){try{Promise.prototype.then.call(result,complete,function(){if(live())stats.errors++;});}catch(_){complete();}}else complete();
    return result;
  };};}
  function installObservers(){
    var preexisting=object(own(socket,'socket'));if(preexisting){gap('preexisting_socket');gap('initial_sync_unproven');}else{milestones.beforeSocket=!milestones.lateAttach&&milestones.beforeScene;milestones.beforeFirstSync=milestones.beforeSocket;if(!milestones.beforeFirstSync)gap('initial_sync_unproven');}
    patch(store,'sync',paired('store_input','store_after'));patch(store,'updatePushMessage',paired('store_update_input','store_update_after'));
    patch(socket,'onMessage',function(original){return function(){if(!live())return original.apply(this,arguments);var parent=currentCall,id=++call;currentCall=id;observe('onmessage_entry',null,id,parent);try{return original.apply(this,arguments);}finally{currentCall=parent;}};});
    patch(socket,'establish',function(original){return function(){if(!live())return original.apply(this,arguments);connectionGeneration++;var parent=currentCall,id=++call;currentCall=id;observe('socket_establish',null,id,parent);try{return original.apply(this,arguments);}finally{currentCall=parent;}};});
    patch(socket,'sync',function(original){return function(){if(!live())return original.apply(this,arguments);var parent=currentCall,id=++call;currentCall=id;observe('sync_called',null,id,parent);try{return original.apply(this,arguments);}finally{currentCall=parent;}};});
    if(!patch(socket,'resisterPushHandler',function(original){return function(){var result=original.apply(this,arguments);if(live())installPush();return result;};},true))gap('missing_push_registration');installPush();
    if(!patch(socket,'send',function(original){return function(){
      var command=arguments[0],watch=this===socket&&COMMANDS.indexOf(command)>=0&&live(),pid=watch?own(socket,'packetId'):undefined,map=watch?own(socket,'responseMap'):null,prior=own(map,String(pid)),parent=currentCall,id=watch?++call:0;
      if(watch&&command==='CMD_SYNC'&&!firstSyncCallID)firstSyncCallID=id;
      var result;try{result=original.apply(this,arguments);}catch(error){if(id===firstSyncCallID)gap('initial_sync_unproven');throw error;}
      if(watch&&!stopped){var tracked=false;try{if(integer(pid,Number.MAX_SAFE_INTEGER)&&own(socket,'packetId')===pid+1&&own(socket,'responseMap')===map&&!prior)tracked=trackResolver(own(map,String(pid)),id,parent,command,map,pid);else stats.decoderMissed++;}catch(_){stats.decoderMissed++;}if(id===firstSyncCallID&&!tracked)gap('initial_sync_unproven');}return result;
    };},true))gap('missing_decoded_boundary');
    patch(cardProto,'setup',function(original){return function(){if(!live())return original.apply(this,arguments);var parent=currentCall,id=++call,b=bindCard(this,arguments[0]);currentCall=id;observe('card_setup_input',arguments[0],id,parent,{bindingGeneration:b.generation},this);try{var result=original.apply(this,arguments);observe('card_setup_after',own(this,'cardInfo'),id,parent,{bindingGeneration:b.generation},this);return result;}finally{currentCall=parent;}};});
    patch(handProto,'setup',function(original){return function(){if(!live())return original.apply(this,arguments);var parent=currentCall,id=++call;currentCall=id;observe('hand_setup_input',arguments[0],id,parent);try{var result=original.apply(this,arguments);observe('hand_setup_after',own(this,'gamer'),id,parent);return result;}finally{currentCall=parent;}};});
    patch(skin,'setCardBg',skinObserver('skin_bg',0,1,-1,2));patch(skin,'setCardType',skinObserver('skin_type',1,0,2,3));
    milestones.modulesReady=true;status='ready';reason='observing';
  }
  function loaderSignature(loader){var source=Function.prototype.toString.call(loader);return source.length<20000&&source.indexOf('exports')>=0&&source.indexOf('Cannot find module')>=0&&source.indexOf('__require')>=0&&source.indexOf('.call(')>=0;}
  function attemptInstall(){
    if(!live()||milestones.modulesReady)return;
    // A user-content controller can be shared by several WebViews. Only the
    // exact native-approved game/document may receive game-method wrappers.
    // If the reply arrives after startup, report that gap instead of claiming
    // to have intercepted an initial response retroactively.
    if(!approved)return;
    try{
      var cc=own(window,'cc');if(!cc){reason='awaiting_engine';return;}
      if((cc.ENGINE_VERSION!=='2.4.5'&&own(window,'CocosEngine')!=='2.4.5')||(cc.ENGINE_VERSION&&cc.ENGINE_VERSION!=='2.4.5')||(own(window,'CocosEngine')&&own(window,'CocosEngine')!=='2.4.5')){status='unsupported';close('unsupported_engine');return;}
      engine=cc;var loader=loaderWatch?loaderWatch.value:own(window,'__require');if(typeof loader!=='function'){reason='awaiting_loader';return;}milestones.loaderSeen=true;
      if(!loaderSignature(loader)){gap('loader_contract_unverified');reason='loader_contract_mismatch';return;}
      var registry=cc.js&&method(cc.js,'getClassByName');if(!registry){gap('missing_module_registry');reason='awaiting_modules';return;}
      var Card=registry.call(cc.js,'Card'),HandArea=registry.call(cc.js,'HandArea'),Game=registry.call(cc.js,'game');
      if(typeof Card!=='function'||typeof HandArea!=='function'||typeof Game!=='function'){reason='awaiting_modules';return;}
      // Registry proves these class factories have run. The inspected main
      // bundle eagerly executes their service dependencies before assignment.
      if(own(loader('Card'),'default')!==Card||own(loader('HandArea'),'default')!==HandArea||own(loader('game'),'default')!==Game){reason='loader_contract_mismatch';return;}
      store=own(loader('GameStore'),'default');socket=own(loader('Socket'),'default');skin=own(loader('CardSkinManager'),'default');cardProto=own(Card,'prototype');handProto=own(HandArea,'prototype');
      if(!store||!socket||!skin||!method(store,'sync')||!method(store,'updatePushMessage')||!method(socket,'establish')||!method(socket,'onMessage')||!method(socket,'sync')||!method(cardProto,'setup')||!method(handProto,'setup')||!method(skin,'setCardBg')||!method(skin,'setCardType')){reason='awaiting_modules';return;}
      var director=cc.director,event=cc.Director&&cc.Director.EVENT_BEFORE_SCENE_LAUNCH;
      if(director&&method(director,'getScene')&&director.getScene()){gap('scene_already_running');milestones.beforeScene=false;}
      else milestones.beforeScene=!milestones.lateAttach;
      if(director&&typeof event==='string'&&method(director,'on')&&method(director,'off')){sceneListener=function(){if(live())observe('before_scene',null,++call,currentCall);};director.on(event,sceneListener);}else gap('missing_scene_event');
      installObservers();
    }catch(_){stats.errors++;close('install_failed');}
  }
  function watchLoader(){
    var prior=Object.getOwnPropertyDescriptor(window,'__require');
    if(prior&&!Object.prototype.hasOwnProperty.call(prior,'value')){close('loader_accessor');return;}
    if(prior&&(!prior.configurable||!prior.writable)){close('loader_readonly');return;}
    if(!prior){for(var proto=Object.getPrototypeOf(window),depth=0;object(proto)&&depth<8;proto=Object.getPrototypeOf(proto),depth++){var inherited=Object.getOwnPropertyDescriptor(proto,'__require');if(inherited){close('loader_accessor');return;}}}
    loaderWatch={prior:prior,value:prior&&prior.value,assigned:!!prior};
    loaderWatch.get=function(){return loaderWatch?loaderWatch.value:undefined;};
    loaderWatch.set=function(value){loaderWatch.value=value;loaderWatch.assigned=true;milestones.loaderSeen=typeof value==='function';observe('loader_assignment',null,++call,currentCall);attemptInstall();};
    Object.defineProperty(window,'__require',{configurable:true,enumerable:prior?prior.enumerable:true,get:loaderWatch.get,set:loaderWatch.set});
    if(typeof loaderWatch.value==='function'){milestones.lateAttach=true;milestones.loaderSeen=true;gap('late_attach');gap('initial_sync_unproven');attemptInstall();}
  }
  function onPageHide(){close('pagehide');}
  function onVisibility(){if(doc&&(doc.hidden||doc.visibilityState==='hidden'))close('hidden_document');}
  function intact(){
    for(var i=0;i<patches.length;i++){var p=patches[i];if(!p.retired&&own(p.target,p.key)!==p.wrapper){close('method_replaced');return false;}}
    if(loaderWatch){var d=Object.getOwnPropertyDescriptor(window,'__require');if(!d||d.get!==loaderWatch.get||d.set!==loaderWatch.set){close('method_replaced');return false;}}
    return true;
  }
  var api=Object.freeze({stop:function(){close('explicit_stop');},snapshot:function(){return snapshot([]);}});
  try{
    if(window.top!==window)return api;
    if(!config||typeof config.handlerName!=='string'||!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(config.handlerName)||typeof config.token!=='string'||!/^[A-Za-z0-9_-]{16,128}$/.test(config.token)){stopped=true;reason='bridge_unavailable';return api;}
    handler=window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers[config.handlerName];
    if(!handler||typeof handler.postMessage!=='function'||!window.crypto||typeof window.crypto.getRandomValues!=='function'){stopped=true;reason='bridge_unavailable';return api;}
    var random=new Uint8Array(12);window.crypto.getRandomValues(random);for(var r=0;r<random.length;r++)documentID+=random[r].toString(16).padStart(2,'0');
    send('hello');if(stopped)return api;
    watchLoader();if(stopped)return api;
    if(typeof window.addEventListener==='function')window.addEventListener('pagehide',onPageHide);
    if(doc&&typeof doc.addEventListener==='function')doc.addEventListener('visibilitychange',onVisibility);
    timer=window.setInterval(function(){if(!live()||!intact())return;if(inflight&&now()-requestBorn>=LIMIT.lease){close('bridge_timeout');return;}attemptInstall();if(approved&&!inflight)send('batch');},LIMIT.interval);
  }catch(_){stats.errors++;close('install_failed');}
  return api;
})

(function SDKtoolsPlannerFactory() {
  'use strict';
  // A private resumable search belongs to this runtime, never to a global.
  // V3.19.8 prioritizes a verified mission trio with bounded normal fallback.
  // Still proves the next trio rather than requiring a complete-game solution.
  // A bounded lookahead compares tray headroom and newly accessible matches.
  // A local route is not a claim of optimal play or server-confirmed victory.
  var session = null;
  return function SDKtoolsPlan(input) {
  var start = Date.now(), rawTypes = [], sliceGenerated = 0, sliceLimit = null;
  function empty(status, reason) {
    return {status:status, reason:reason, cardID:null, actions:[], sequence:[], matchedType:null,
      tripleCardIDs:[], peakTrayCount:0, proofKind:null,
      stats:{expanded:0,generated:0,pruned:0,backtracks:0,transpositions:0,depth:0,slices:0,targetTriples:0,
        elapsedMs:Math.max(0,Date.now()-start),limit:null,searchMode:'next_trio',completeSolution:false,completePlan:false,completeSearch:false}};
  }
  function invalid(reason) { session=null; return empty('invalid_state',reason); }
  function bounded(value, fallback, low, high) {
    return typeof value === 'number' && isFinite(value) ? Math.max(low, Math.min(high, Math.floor(value))) : fallback;
  }
  function textID(value) { return typeof value === 'string' && value.length > 0 && value.length <= 128; }
  if (!input || typeof input !== 'object' || !Array.isArray(input.cards) || !Array.isArray(input.tray)) return invalid('invalid_input');
  var cards = [], raw = input.cards, capacity = input.capacity;
  if (!Number.isInteger(capacity) || capacity < 2 || capacity > 12 || input.matchSize !== 3) return invalid('unsupported_rules');
  if (raw.length > 512 || input.tray.length >= capacity) return invalid('invalid_board_size');
  var maxNodes = bounded(input.maxNodes, 600, 1, 4000);
  var maxDepth = bounded(input.maxDepth, 7, 1, 12);
  var budgetMs = bounded(input.budgetMs, 8, 1, 12);
  var maxTotalNodes = bounded(input.maxTotalNodes, 20000, 1, 100000);
  var maxTranspositions = bounded(input.maxTranspositions, 6000, 1, 20000);
  if (input.stateKey !== undefined && (typeof input.stateKey !== 'string' || input.stateKey.length > 262144)) return invalid('invalid_state_key');
  var indexByID = Object.create(null), typeIndex = Object.create(null), typeCount = 0, edgeCount = 0;
  function indexType(type) {
    if (!textID(type) || /^(unknown|unreadable|special)$/i.test(type)) return -1;
    if (typeIndex[type] === undefined) { typeIndex[type] = typeCount++; rawTypes.push(type); }
    return typeIndex[type];
  }
  for (var i = 0; i < raw.length; i++) {
    var c = raw[i];
    if (!c || !textID(c.id) || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_card_id');
    var t = indexType(c.type);
    if (t < 0 || (c.zone !== 'board' && c.zone !== 'reserve') || typeof c.available !== 'boolean' || !Array.isArray(c.blockedBy)) return invalid('unreadable_card');
    if ((c.locked !== undefined && typeof c.locked !== 'boolean') || (c.selectable !== undefined && typeof c.selectable !== 'boolean')) return invalid('invalid_card_lock');
    edgeCount += c.blockedBy.length;
    if (c.blockedBy.length > 64 || edgeCount > 8192) return invalid('excessive_blockers');
    indexByID[c.id] = i;
    cards.push({id: c.id, type: t, available: c.available, locked: c.locked === true || c.selectable === false, blockedBy: c.blockedBy.slice(), blockers: [],
      zone: c.zone, order: Number.isFinite(c.order) ? c.order : i});
  }
  var trayTypes = [], trayIDs = Object.create(null);
  for (i = 0; i < input.tray.length; i++) {
    c = input.tray[i];
    if (!c || !textID(c.id) || trayIDs[c.id] || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_tray_id');
    t = indexType(c.type);
    if (t < 0) return invalid('unreadable_tray');
    trayIDs[c.id] = true; trayTypes.push(t);
  }
  var counts = new Array(typeCount).fill(0), indegree = new Array(cards.length).fill(0);
  var covers = cards.map(function () { return []; });
  for (i = 0; i < trayTypes.length; i++) {
    counts[trayTypes[i]]++;
    if (counts[trayTypes[i]] >= 3) return invalid('unsettled_tray');
  }
  for (i = 0; i < cards.length; i++) {
    var seen = Object.create(null);
    c = cards[i];
    for (var j = 0; j < c.blockedBy.length; j++) {
      var blockerID = c.blockedBy[j], b = indexByID[blockerID];
      if (!textID(blockerID) || b === undefined || b === i || seen[blockerID] || cards[b].zone !== c.zone) return invalid('invalid_blocker');
      seen[blockerID] = true; c.blockers.push(b); covers[b].push(i); indegree[i]++;
    }
    if (c.available && c.blockers.length) return invalid('inconsistent_availability');
  }
  // A cycle is not a difficult puzzle; it is evidence of an invalid observation.
  var queue = [], qi = 0, cycleCount = 0;
  for (i = 0; i < cards.length; i++) if (!indegree[i]) queue.push(i);
  while (qi < queue.length) {
    var n = queue[qi++]; cycleCount++;
    for (j = 0; j < covers[n].length; j++) if (--indegree[covers[n][j]] === 0) queue.push(covers[n][j]);
  }
  if (cycleCount !== cards.length) return invalid('cyclic_blockers');
  for (i = 0; i < cards.length; i++) cards[i].equivalence = cards[i].type + ':' + covers[i].join(',');
  // Before the first trio, every selection consumes one slot. No first-trio
  // route can be longer than the physical space available, even on 512 cards.
  var mission=input.mission, missionValid=mission && textID(mission.type) && !/^(unknown|unreadable|special)$/i.test(mission.type) &&
    Number.isInteger(mission.current) && mission.current>=0 && mission.current<=1000000 &&
    Number.isInteger(mission.total) && mission.total>0 && mission.total<=1000000 && mission.current<=mission.total;
  var missionType=missionValid && typeIndex[mission.type] !== undefined ? typeIndex[mission.type] : -1;
  var missionRequested=!!(missionValid && mission.current<mission.total), missionActive=false;
  var missionStamp=missionValid ? [mission.type,mission.current,mission.total] : null;
  var routeDepth=Math.min(maxDepth,capacity-trayTypes.length);
  var fingerprint = JSON.stringify([input.stateKey || '',input.cooperative===true,capacity,routeDepth,maxTotalNodes,maxTranspositions,missionStamp,
    cards.map(function(c){return [c.id,rawTypes[c.type],c.available,c.locked,c.blockedBy,c.order,c.zone];}),
    input.tray.map(function(c){return [c.id,c.type];})]);
  function removed(state, idx) { return (state.removed[idx >>> 5] & (1 << (idx & 31))) !== 0; }
  function eligible(state, idx) {
    var c=cards[idx];
    if (removed(state,idx) || c.locked || (!c.available && !c.blockers.length)) return false;
    for(var k=0;k<c.blockers.length;k++) if(!removed(state,c.blockers[k])) return false;
    return true;
  }
  function legal(state, idx) {
    return eligible(state,idx) && state.occupancy < capacity &&
      (state.counts[cards[idx].type] === 2 || state.occupancy + 1 < capacity);
  }
  function advance(state, idx) {
    var bits=state.removed.slice(), next=state.counts.slice(), type=cards[idx].type, triple=next[type]===2;
    bits[idx>>>5]|=1<<(idx&31); next[type]=triple?0:next[type]+1;
    return {removed:bits,counts:next,occupancy:state.occupancy+1-(triple?3:0),removedCount:state.removedCount+1,triples:state.triples+(triple?1:0),
      peak:Math.max(state.peak,state.occupancy+1)};
  }
  function stateKey(state) { return Array.prototype.join.call(state.removed,'.'); }
  function frame(state, chosen) { return {state:state,chosen:chosen,options:null,next:0,scan:0,building:[],equivalent:Object.create(null)}; }
  var initial={removed:new Uint32Array(Math.ceil(cards.length/32)),counts:counts,occupancy:trayTypes.length,removedCount:0,peak:trayTypes.length,triples:0};
  var totals=counts.slice(), targetTriples=0;
  for(i=0;i<cards.length;i++)totals[cards[i].type]++;
  for(i=0;i<typeCount;i++)targetTriples+=Math.floor(totals[i]/3);
  missionActive=missionRequested && missionType>=0 && totals[missionType]>=3;
  // Mark target ancestors so an accessible normal trio does not hide a safe
  // mission route behind one or more unrelated blocking cards.
  var missionUseful=new Array(cards.length).fill(false), missionNeeded=[];
  if(missionActive)for(i=0;i<cards.length;i++)if(cards[i].type===missionType){missionUseful[i]=true;missionNeeded.push(i);}
  for(i=0;i<missionNeeded.length;i++)for(j=0;j<cards[missionNeeded[i]].blockers.length;j++){
    var ma=cards[missionNeeded[i]].blockers[j];if(!missionUseful[ma]){missionUseful[ma]=true;missionNeeded.push(ma);}
  }
  var useful=new Array(cards.length).fill(false), needed=[], directTypes=[];
  for(i=0;i<cards.length;i++)if(totals[cards[i].type]>=3){useful[i]=true;needed.push(i);}
  for(i=0;i<needed.length;i++)for(j=0;j<cards[needed[i]].blockers.length;j++){
    var ancestor=cards[needed[i]].blockers[j];if(!useful[ancestor]){useful[ancestor]=true;needed.push(ancestor);}
  }
  for(i=0;i<typeCount;i++)if(totals[i]>=3)directTypes.push(i);
  directTypes.sort(function(a,b){return (missionActive ? (b===missionType)-(a===missionType) : 0) || counts[b]-counts[a] || a-b;});
  if (!session || session.fingerprint !== fingerprint) {
    session={fingerprint:fingerprint,stack:[frame(initial,-1)],dead:new Set(),generated:0,expanded:0,pruned:0,backtracks:0,
      depth:0,slices:0,terminal:null,limit:null,proof:null,completeSearch:false,bestScore:null,candidates:0,
      directCursor:0,direct:null,directDone:false,continuations:new Map()};
    if(!cards.length && !trayTypes.length) session.terminal='board_clear';
    else if(!targetTriples) session.terminal='no_remaining_triples';
  }
  function pursuingMission() { return missionActive && !session.missionAbandoned; }
  if(session.missionAbandoned)directTypes.sort(function(a,b){return counts[b]-counts[a] || a-b;});
  function abandonMission(limit) {
    session.missionAbandoned=true;session.missionNodes=session.generated;session.limit=limit;
    // No normal proof yet: give the original algorithm its own full budget and
    // ordering, rather than letting a failed target search starve normal play.
    session.stack=[frame(initial,-1)];session.dead=new Set();session.generated=0;
    session.expanded=0;session.pruned=0;session.backtracks=0;session.depth=0;
    session.directCursor=0;session.direct=null;session.directDone=false;
  }
  session.slices++;
  function result(status, reason) {
    var proof=status==='move'?session.proof:null, sequence=proof?proof.sequence.slice():[];
    return {status:status,reason:reason,cardID:sequence.length?sequence[0]:null,sequence:sequence,actions:sequence.slice(),
      matchedType:proof?proof.matchedType:null,tripleCardIDs:proof?proof.tripleCardIDs.slice():[],
      peakTrayCount:proof?proof.peak:0,proofKind:proof?'local_trio':status==='solved'?'complete_board':null,
      stats:{expanded:session.expanded,generated:session.generated,pruned:session.pruned,backtracks:session.backtracks,
        transpositions:session.dead.size,depth:session.depth,slices:session.slices,targetTriples:targetTriples,elapsedMs:Math.max(0,Date.now()-start),
        limit:session.limit || sliceLimit,searchMode:'next_trio',goal:'next_trio',candidates:session.candidates,
        missionStatus:!missionValid?'unavailable':!missionRequested?'complete':
          proof && proof.matchedType===mission.type?'priority':status==='searching'&&pursuingMission()?'searching':'fallback',
        missionNodes:session.missionNodes||0,
        missionReason:!missionRequested?null:!missionActive?'not_observed':
          proof && proof.matchedType===mission.type?null:session.limit?'search_limit':'no_safe_route',
        continuation:input.cooperative===true?proof?['dead_end','unknown','proved','clear'][proof.continuation+1]:'unknown':undefined,
        completeSolution:!!(proof&&proof.empty) || status==='solved',completePlan:!!proof || status==='solved',completeSearch:session.completeSearch}};
  }
  function terminal() {
    if(session.terminal==='solution_found') return result('move','solution_found');
    if(session.terminal==='board_clear') return result('solved','board_clear');
    return result('blocked',session.terminal);
  }
  function finishOrWait(limit, terminalLimit) {
    if(terminalLimit)session.limit=limit;else sliceLimit=limit;
    if(session.proof && (!input.cooperative || session.proof.continuation>=1 || terminalLimit) && (!pursuingMission() || session.proof.matchedType===mission.type || terminalLimit)){
      session.terminal='solution_found';return terminal();
    }
    if(terminalLimit && pursuingMission()){
      abandonMission(limit);return result('searching','search_in_progress');
    }
    if(terminalLimit){session.terminal='search_limit_reached';return terminal();}
    return result('searching','search_in_progress');
  }
  if(session.terminal) return terminal();
  // At most eight 8ms planner slices / 2400 generated choices per observed
  // state pursue a covered target. Limits mean fallback, not impossibility.
  function missionLimit() { return pursuingMission() && (session.slices>8 || session.generated>=2400); }
  function outOfTime() { return Date.now()-start>=budgetMs; }
  function rank(state,idx,missionSearch) {
    var type=cards[idx].type, same=state.counts[type], score=same===2?100000:same===1?5000:0;
    for(var u=0;u<covers[idx].length;u++) {
      var child=cards[covers[idx][u]], left=0;
      for(var v=0;v<child.blockers.length;v++) if(!removed(state,child.blockers[v])) left++;
      if(left===1 && !child.locked) score+=20+state.counts[child.type]*100;
    }
    if(missionSearch && pursuingMission() && missionUseful[idx])score+=cards[idx].type===missionType?1000000:500000;
    return score;
  }
  function buildOptions(f) {
    while(f.scan<cards.length) {
      if((f.scan&15)===0 && outOfTime()) return false;
      var idx=f.scan++, c=cards[idx];
      if(!useful[idx] || !legal(f.state,idx)) continue;
      if(f.equivalent[c.equivalence]){session.pruned++;continue;}
      f.equivalent[c.equivalence]=true;f.building.push({idx:idx,rank:rank(f.state,idx,true)});
    }
    f.building.sort(function(a,b){return b.rank-a.rank || cards[a.idx].order-cards[b.idx].order || a.idx-b.idx;});
    f.options=f.building.map(function(o){return o.idx;}); f.building=null;f.equivalent=null;session.expanded++;
    return true;
  }
  function proofFor(path) {
    if(!path.length || path.length>routeDepth) return null;
    var check=initial, firstType=null, firstIDs=[], groups=Object.create(null);
    input.tray.forEach(function(c){var t=typeIndex[c.type];(groups[t]||(groups[t]=[])).push(c.id);});
    for(var k=0;k<path.length;k++) {
      var idx=path[k], c=cards[idx];
      if(!Number.isInteger(idx) || !c || check.triples || !legal(check,idx)) return null;
      var ids=groups[c.type]||(groups[c.type]=[]);ids.push(c.id);
      if(ids.length===3){firstType=rawTypes[c.type];firstIDs=ids.slice();groups[c.type]=[];}
      check=advance(check,idx);
    }
    if(check.triples!==1 || check.peak>capacity || check.counts[cards[path[path.length-1]].type]!==0) return null;
    return {sequence:path.map(function(idx){return cards[idx].id;}),matchedType:firstType,tripleCardIDs:firstIDs,peak:check.peak,
      empty:check.removedCount===cards.length&&check.occupancy===0,after:check,path:path.slice()};
  }
  function continuation(state) {
    if(state.removedCount===cards.length&&state.occupancy===0)return 2;
    var key=Array.from(state.removed).join(','),cached=session.continuations.get(key);
    if(cached!==undefined)return cached;
    var stack=[state],seen=new Set(),visited=0;
    while(stack.length){
      if(outOfTime()||++visited>2000)return 0;
      var current=stack.pop();
      for(var ci=0;ci<cards.length;ci++){
        if((ci&31)===0&&outOfTime())return 0;
        if(!legal(current,ci))continue;
        var next=advance(current,ci);
        if(next.triples>state.triples){if(session.continuations.size<256)session.continuations.set(key,1);return 1;}
        var stamp=Array.from(next.removed).join(',');
        if(!seen.has(stamp)){seen.add(stamp);stack.push(next);}
        if(seen.size>2000)return 0;
      }
    }
    if(session.continuations.size<256)session.continuations.set(key,-1);
    return -1;
  }
  function consider(path) {
    var proof=proofFor(path);if(!proof)return false;
    // Remove irrelevant picks before scoring; only an exact replay can retain
    // a nonmatching blocker in this route. This keeps free tray slots useful.
    for(var pi=path.length-1;pi>=0;pi--)if(rawTypes[cards[path[pi]].type]!==proof.matchedType){
      var trimmed=path.slice();trimmed.splice(pi,1);var shorter=proofFor(trimmed);
      if(shorter){path=trimmed;proof=shorter;}
    }
    var after=proof.after, accessible=after.counts.slice(), released=0, pairs=0;
    for(var ci=0;ci<cards.length;ci++)if(eligible(after,ci)){
      accessible[cards[ci].type]++;
      if(cards[ci].blockers.length)released++;
    }
    var nextTrios=0;
    for(var ti=0;ti<typeCount;ti++){
      if(after.counts[ti]===2)pairs++;
      // Only immediately exposed matches fitting the remaining slots count
      // as next opportunities; covered cards are not imagined to be playable.
      if(accessible[ti]>=3 && 3-after.counts[ti]<=capacity-after.occupancy)nextTrios++;
    }
    // Lexicographic priorities: headroom, near-term completions, useful
    // releases, pairs. A bounded comparison is not a global optimality proof.
    var score=[-after.occupancy,nextTrios,released,pairs,-proof.peak];
    if(pursuingMission())score.unshift(proof.matchedType===mission.type?1:0);
    if(input.cooperative===true){proof.continuation=continuation(after);score.unshift(proof.continuation);}
    var better=!session.bestScore;
    if(!better)for(var si=0;si<score.length;si++){if(score[si]!==session.bestScore[si]){better=score[si]>session.bestScore[si];break;}}
    session.candidates++;
    if(better){session.proof=proof;session.bestScore=score;}
    return true;
  }
  // Fast phase compares complete same-type routes, including matching stacks.
  // The scan is resumable; a loaded 512-card board cannot monopolize a tick.
  while(!session.directDone){
    if(session.directCursor>=directTypes.length){session.directDone=true;break;}
    if(outOfTime())return finishOrWait('time_slice',false);
    if(sliceGenerated>=maxNodes)return finishOrWait('node_slice',false);
    if(session.generated>=maxTotalNodes)return finishOrWait('total_node_budget',true);
    if(!session.direct)session.direct={type:directTypes[session.directCursor],state:initial,path:[],scan:0,best:-1,rank:-Infinity};
    var direct=session.direct;
    if(direct.path.length>=routeDepth){session.direct=null;session.directCursor++;continue;}
    while(direct.scan<cards.length){
      if((direct.scan&15)===0&&outOfTime())return finishOrWait('time_slice',false);
      var di=direct.scan++;
      if(cards[di].type!==direct.type || !legal(direct.state,di))continue;
      var dr=rank(direct.state,di);
      if(direct.best<0 || dr>direct.rank || (dr===direct.rank&&cards[di].order<cards[direct.best].order)){direct.best=di;direct.rank=dr;}
    }
    session.expanded++;
    if(direct.best<0){session.direct=null;session.directCursor++;continue;}
    direct.path.push(direct.best);direct.state=advance(direct.state,direct.best);session.generated++;sliceGenerated++;
    session.depth=Math.max(session.depth,direct.path.length);
    if(direct.state.triples){consider(direct.path);session.direct=null;session.directCursor++;}
    else{direct.scan=0;direct.best=-1;direct.rank=-Infinity;}
  }
  // Any direct route has the minimum possible occupancy for its starting
  // tray count. Prefer the best tested direct route rather than waiting for a
  // complete game search. Hidden unlock routes are searched only if needed.
  if(session.proof && (!input.cooperative || session.proof.continuation>=1) && (!pursuingMission() || session.proof.matchedType===mission.type)){
    session.terminal='solution_found';return terminal();
  }
  // Keep the old best direct trio as fallback while pursuing a covered target.
  // If no mission route is proved, never publish an unproved target single.
  while(session.stack.length) {
    var f=session.stack[session.stack.length-1];
    if(f.state.triples){
      if(!consider(session.stack.slice(1).map(function(x){return x.chosen;}))){session.terminal='invalid_route_proof';return result('invalid_state','invalid_route_proof');}
      session.stack.pop();session.backtracks++;
      if(pursuingMission() && session.proof && session.proof.matchedType===mission.type && (!input.cooperative || session.proof.continuation>=1)){session.terminal='solution_found';return terminal();}
      continue;
    }
    if(missionLimit())return finishOrWait('mission_budget',true);
    if(outOfTime())return finishOrWait('time_slice',false);
    if(sliceGenerated>=maxNodes)return finishOrWait('node_slice',false);
    if(f.state.removedCount>=routeDepth){session.stack.pop();session.backtracks++;continue;}
    if(f.options===null&&!buildOptions(f))return finishOrWait('time_slice',false);
    if(f.next>=f.options.length){
      if(session.dead.size>=maxTranspositions)return finishOrWait('memory_budget',true);
      session.dead.add(stateKey(f.state));session.stack.pop();session.backtracks++;continue;
    }
    if(session.generated>=maxTotalNodes)return finishOrWait('total_node_budget',true);
    var idx=f.options[f.next++],child=advance(f.state,idx);session.generated++;sliceGenerated++;
    if(session.dead.has(stateKey(child))){session.pruned++;continue;}
    session.stack.push(frame(child,idx));session.depth=Math.max(session.depth,child.removedCount);
  }
  if(session.proof){session.terminal='solution_found';return terminal();}
  if(routeDepth<capacity-trayTypes.length)return finishOrWait('depth_limit',true);
  session.terminal='no_complete_solution';session.completeSearch=true;return terminal();
  };
})()

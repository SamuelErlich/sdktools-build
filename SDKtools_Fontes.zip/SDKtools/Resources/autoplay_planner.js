(function SDKtoolsPlan(input) {
  'use strict';
  // Pure, bounded planner for a fully observed three-of-a-kind board. It does
  // not dispatch touches or claim that a partial beam search proves a win.
  var start = Date.now(), visited = 0, generated = 0, pruned = 0, depthReached = 0;
  var limit = null;
  function result(status, reason, node) {
    return {status: status, cardID: node && node.path.length ? cards[node.path[0]].id : null,
      reason: reason, actions: node ? node.path.map(function (i) { return cards[i].id; }) : [],
      stats: {expanded: visited, generated: generated, pruned: pruned, depth: depthReached,
        elapsedMs: Math.max(0, Date.now() - start), limit: limit,
        completeSolution: !!(node && node.removedCount === cards.length && node.occupancy === 0)}};
  }
  function invalid(reason) { return result('invalid_state', reason, null); }
  function bounded(value, fallback, low, high) {
    return typeof value === 'number' && isFinite(value) ? Math.max(low, Math.min(high, Math.floor(value))) : fallback;
  }
  function textID(value) { return typeof value === 'string' && value.length > 0 && value.length <= 128; }
  if (!input || typeof input !== 'object' || !Array.isArray(input.cards) || !Array.isArray(input.tray)) return invalid('invalid_input');
  var cards = [], raw = input.cards, capacity = input.capacity;
  if (!Number.isInteger(capacity) || capacity < 2 || capacity > 12 || input.matchSize !== 3) return invalid('unsupported_rules');
  if (raw.length > 512 || input.tray.length >= capacity) return invalid('invalid_board_size');
  var maxNodes = bounded(input.maxNodes, 1800, 1, 10000);
  var maxDepth = bounded(input.maxDepth, 12, 1, 24);
  var beamWidth = bounded(input.beamWidth, 32, 1, 128);
  var budgetMs = bounded(input.budgetMs, 8, 1, 40);
  var indexByID = Object.create(null), typeIndex = Object.create(null), typeCount = 0, edgeCount = 0;
  function indexType(type) {
    if (!textID(type) || /^(unknown|unreadable|special)$/i.test(type)) return -1;
    if (typeIndex[type] === undefined) typeIndex[type] = typeCount++;
    return typeIndex[type];
  }
  for (var i = 0; i < raw.length; i++) {
    var c = raw[i];
    if (!c || !textID(c.id) || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_card_id');
    var t = indexType(c.type);
    if (t < 0 || (c.zone !== 'board' && c.zone !== 'reserve') || typeof c.available !== 'boolean' || !Array.isArray(c.blockedBy)) return invalid('unreadable_card');
    edgeCount += c.blockedBy.length;
    if (c.blockedBy.length > 64 || edgeCount > 8192) return invalid('excessive_blockers');
    indexByID[c.id] = i;
    cards.push({id: c.id, type: t, available: c.available, blockedBy: c.blockedBy.slice(), blockers: [],
      zone: c.zone, order: Number.isFinite(c.order) ? c.order : i});
  }
  var trayTypes = [], trayIDs = Object.create(null);
  for (i = 0; i < input.tray.length; i++) {
    c = input.tray[i];
    if (!c || !textID(c.id) || trayIDs[c.id] || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_tray_id');
    t = indexType(c.type);
    if (t < 0) return invalid('unreadable_tray');
    trayIDs[c.id] = true; trayTypes.push(t);
  }
  var counts = new Array(typeCount).fill(0), indegree = new Array(cards.length).fill(0);
  var covers = cards.map(function () { return []; });
  for (i = 0; i < trayTypes.length; i++) {
    counts[trayTypes[i]]++;
    if (counts[trayTypes[i]] >= 3) return invalid('unsettled_tray');
  }
  for (i = 0; i < cards.length; i++) {
    var seen = Object.create(null);
    c = cards[i];
    for (var j = 0; j < c.blockedBy.length; j++) {
      var blockerID = c.blockedBy[j], b = indexByID[blockerID];
      if (!textID(blockerID) || b === undefined || b === i || seen[blockerID]) return invalid('invalid_blocker');
      seen[blockerID] = true; c.blockers.push(b); covers[b].push(i); indegree[i]++;
    }
    if ((c.available && c.blockers.length) || (c.zone === 'reserve' && c.blockers.length)) return invalid('inconsistent_availability');
  }
  // A cycle is not a difficult puzzle; it is evidence of an invalid observation.
  var queue = [], qi = 0, cycleCount = 0;
  for (i = 0; i < cards.length; i++) if (!indegree[i]) queue.push(i);
  while (qi < queue.length) {
    var n = queue[qi++]; cycleCount++;
    for (j = 0; j < covers[n].length; j++) if (--indegree[covers[n][j]] === 0) queue.push(covers[n][j]);
  }
  if (cycleCount !== cards.length) return invalid('cyclic_blockers');
  for (i = 0; i < cards.length; i++) cards[i].equivalence = cards[i].type + ':' + covers[i].join(',');
  var initial = {removed: new Uint32Array(Math.ceil(cards.length / 32)), counts: counts,
    occupancy: trayTypes.length, removedCount: 0, triples: 0, path: [], score: 0, risk: 0};
  if (!cards.length) return result(trayTypes.length ? 'blocked' : 'solved', trayTypes.length ? 'unmatched_tray' : 'board_clear', initial);
  function removed(state, idx) { return (state.removed[idx >>> 5] & (1 << (idx & 31))) !== 0; }
  function eligible(state, idx) {
    if (removed(state, idx)) return false;
    var card = cards[idx];
    // A disabled uncovered button is not assumed to become enabled. A covered
    // normal card can become eligible only after every observed blocker leaves.
    if (!card.available && !card.blockers.length) return false;
    for (var k = 0; k < card.blockers.length; k++) if (!removed(state, card.blockers[k])) return false;
    return true;
  }
  function legal(state, idx) {
    if (!eligible(state, idx)) return false;
    var after = state.occupancy + 1 - (state.counts[cards[idx].type] === 2 ? 3 : 0);
    // The final occupied slot can end a game. Keep one free slot unless this
    // very pick completes a triple; never depend on an inferred eighth slot.
    return after < capacity;
  }
  function timedOut() {
    if (Date.now() - start >= budgetMs) { limit = 'time_budget'; return true; }
    return false;
  }
  function candidates(state) {
    var output = [], equivalent = Object.create(null);
    for (var k = 0; k < cards.length; k++) {
      if (!legal(state, k)) continue;
      var card = cards[k], same = state.counts[card.type], unlock = 0;
      // Two exposed cards of the same type which cover exactly the same cards
      // have identical consequences in this model. Explore one representative.
      if (equivalent[card.equivalence]) { pruned++; continue; }
      equivalent[card.equivalence] = true;
      for (var u = 0; u < covers[k].length; u++) {
        var child = cards[covers[k][u]], remaining = 0;
        for (var v = 0; v < child.blockers.length; v++) if (!removed(state, child.blockers[v])) remaining++;
        if (remaining === 1) unlock++;
      }
      output.push({index: k, rank: (same === 2 ? 1000 : same === 1 ? 100 : 0) + unlock * 15 + (card.zone === 'reserve' ? 1 : 0)});
    }
    output.sort(function (a, b) { return b.rank - a.rank || cards[a.index].order - cards[b.index].order || a.index - b.index; });
    return output;
  }
  function apply(state, idx) {
    var bitset = state.removed.slice(), nextCounts = state.counts.slice(), card = cards[idx];
    bitset[idx >>> 5] |= 1 << (idx & 31);
    var triple = nextCounts[card.type] === 2;
    nextCounts[card.type] = triple ? 0 : nextCounts[card.type] + 1;
    var occupancy = state.occupancy + 1 - (triple ? 3 : 0);
    var child = {removed: bitset, counts: nextCounts, occupancy: occupancy,
      removedCount: state.removedCount + 1, triples: state.triples + (triple ? 1 : 0), path: state.path.concat(idx), score: 0,
      risk: state.risk + occupancy * occupancy};
    var pairs = 0, unlocked = 0;
    for (var k = 0; k < nextCounts.length; k++) if (nextCounts[k] === 2) pairs++;
    for (k = 0; k < cards.length; k++) if (cards[k].blockers.length && eligible(child, k)) unlocked++;
    child.score = child.triples * 180 + child.removedCount * 2 - occupancy * occupancy * 10 + pairs * 6 + unlocked * 5 - child.risk * 2;
    return child;
  }
  function better(a, b) {
    if (!b) return true;
    return a.score > b.score || (a.score === b.score && a.path.length < b.path.length);
  }
  function hasExit(state) {
    if (state.removedCount === cards.length) return state.occupancy === 0;
    for (var k = 0; k < cards.length; k++) if (legal(state, k)) return true;
    return false;
  }
  var frontier = [initial], best = null, found = Object.create(null);
  if (timedOut()) return result('blocked', 'search_budget_exhausted', null);
  var initialOptions = candidates(initial);
  if (!initialOptions.length) return result('blocked', initial.occupancy >= capacity - 1 ? 'tray_capacity' : 'no_available_card', null);
  for (var depth = 1; depth <= maxDepth; depth++) {
    if (timedOut()) break;
    var next = [];
    for (var fi = 0; fi < frontier.length; fi++) {
      var state = frontier[fi]; visited++;
      var options = state === initial ? initialOptions : candidates(state);
      for (var oi = 0; oi < options.length; oi++) {
        if (generated >= maxNodes) { limit = 'node_budget'; break; }
        if (timedOut()) break;
        var child = apply(state, options[oi].index); generated++; depthReached = Math.max(depthReached, depth);
        if (child.removedCount === cards.length && child.occupancy === 0) return result('move', 'solution_found', child);
        var key = Array.prototype.join.call(child.removed, '.');
        if (found[key]) { pruned++; continue; }
        found[key] = true;
        if (!hasExit(child)) { pruned++; continue; }
        if (better(child, best)) best = child;
        next.push(child);
      }
      if (limit) break;
    }
    if (limit || !next.length) break;
    next.sort(function (a, b) { return b.score - a.score || a.path[0] - b.path[0]; });
    if (next.length > beamWidth) { pruned += next.length - beamWidth; next.length = beamWidth; }
    frontier = next;
    if (depth === maxDepth) limit = 'depth_limit';
  }
  if (best) return result('move', best.triples ? 'triple_route' : 'safe_progress', best);
  return result('blocked', limit ? 'search_budget_exhausted' : 'no_safe_continuation', null);
})

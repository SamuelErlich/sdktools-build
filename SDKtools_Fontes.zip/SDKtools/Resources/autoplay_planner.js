(function SDKtoolsPlan(input) {
  'use strict';
  // Pure, bounded planner for a fully observed three-of-a-kind board. It does
  // not dispatch touches or claim that a partial beam search proves a win.
  var start = Date.now(), visited = 0, generated = 0, pruned = 0, depthReached = 0;
  var limit = null, searchMode = null, rawTypes = [];
  function result(status, reason, node) {
    var sequence = node ? node.path.map(function (i) { return cards[i].id; }) : [];
    var matchedType = node && node.matchedType !== null ? rawTypes[node.matchedType] : null;
    var triple = [];
    if (matchedType !== null) {
      input.tray.forEach(function (c) { if (c.type === matchedType) triple.push(c.id); });
      node.path.forEach(function (i) { if (cards[i].type === node.matchedType) triple.push(cards[i].id); });
    }
    return {status: status, cardID: sequence.length ? sequence[0] : null,
      reason: reason, actions: sequence.slice(), sequence: sequence,
      matchedType: matchedType, tripleCardIDs: triple, peakTrayCount: node ? node.peak : 0,
      stats: {expanded: visited, generated: generated, pruned: pruned, depth: depthReached,
        elapsedMs: Math.max(0, Date.now() - start), limit: limit, searchMode: searchMode,
        completeSolution: !!(node && node.removedCount === cards.length && node.occupancy === 0)}};
  }
  function invalid(reason) { return result('invalid_state', reason, null); }
  function bounded(value, fallback, low, high) {
    return typeof value === 'number' && isFinite(value) ? Math.max(low, Math.min(high, Math.floor(value))) : fallback;
  }
  function textID(value) { return typeof value === 'string' && value.length > 0 && value.length <= 128; }
  if (!input || typeof input !== 'object' || !Array.isArray(input.cards) || !Array.isArray(input.tray)) return invalid('invalid_input');
  var cards = [], raw = input.cards, capacity = input.capacity;
  if (!Number.isInteger(capacity) || capacity < 2 || capacity > 12 || input.matchSize !== 3) return invalid('unsupported_rules');
  if (raw.length > 512 || input.tray.length >= capacity) return invalid('invalid_board_size');
  var maxNodes = bounded(input.maxNodes, 1800, 1, 10000);
  var maxDepth = bounded(input.maxDepth, 12, 1, 24);
  var beamWidth = bounded(input.beamWidth, 32, 1, 128);
  var budgetMs = bounded(input.budgetMs, 8, 1, 40);
  var indexByID = Object.create(null), typeIndex = Object.create(null), typeCount = 0, edgeCount = 0;
  function indexType(type) {
    if (!textID(type) || /^(unknown|unreadable|special)$/i.test(type)) return -1;
    if (typeIndex[type] === undefined) { typeIndex[type] = typeCount++; rawTypes.push(type); }
    return typeIndex[type];
  }
  for (var i = 0; i < raw.length; i++) {
    var c = raw[i];
    if (!c || !textID(c.id) || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_card_id');
    var t = indexType(c.type);
    if (t < 0 || (c.zone !== 'board' && c.zone !== 'reserve') || typeof c.available !== 'boolean' || !Array.isArray(c.blockedBy)) return invalid('unreadable_card');
    edgeCount += c.blockedBy.length;
    if (c.blockedBy.length > 64 || edgeCount > 8192) return invalid('excessive_blockers');
    indexByID[c.id] = i;
    cards.push({id: c.id, type: t, available: c.available, blockedBy: c.blockedBy.slice(), blockers: [],
      zone: c.zone, order: Number.isFinite(c.order) ? c.order : i});
  }
  var trayTypes = [], trayIDs = Object.create(null);
  for (i = 0; i < input.tray.length; i++) {
    c = input.tray[i];
    if (!c || !textID(c.id) || trayIDs[c.id] || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_tray_id');
    t = indexType(c.type);
    if (t < 0) return invalid('unreadable_tray');
    trayIDs[c.id] = true; trayTypes.push(t);
  }
  var counts = new Array(typeCount).fill(0), indegree = new Array(cards.length).fill(0);
  var covers = cards.map(function () { return []; });
  for (i = 0; i < trayTypes.length; i++) {
    counts[trayTypes[i]]++;
    if (counts[trayTypes[i]] >= 3) return invalid('unsettled_tray');
  }
  for (i = 0; i < cards.length; i++) {
    var seen = Object.create(null);
    c = cards[i];
    for (var j = 0; j < c.blockedBy.length; j++) {
      var blockerID = c.blockedBy[j], b = indexByID[blockerID];
      if (!textID(blockerID) || b === undefined || b === i || seen[blockerID]) return invalid('invalid_blocker');
      seen[blockerID] = true; c.blockers.push(b); covers[b].push(i); indegree[i]++;
    }
    if ((c.available && c.blockers.length) || (c.zone === 'reserve' && c.blockers.length)) return invalid('inconsistent_availability');
  }
  // A cycle is not a difficult puzzle; it is evidence of an invalid observation.
  var queue = [], qi = 0, cycleCount = 0;
  for (i = 0; i < cards.length; i++) if (!indegree[i]) queue.push(i);
  while (qi < queue.length) {
    var n = queue[qi++]; cycleCount++;
    for (j = 0; j < covers[n].length; j++) if (--indegree[covers[n][j]] === 0) queue.push(covers[n][j]);
  }
  if (cycleCount !== cards.length) return invalid('cyclic_blockers');
  for (i = 0; i < cards.length; i++) cards[i].equivalence = cards[i].type + ':' + covers[i].join(',');
  var initial = {removed: new Uint32Array(Math.ceil(cards.length / 32)), counts: counts,
    occupancy: trayTypes.length, removedCount: 0, path: [], peak: trayTypes.length, matchedType: null, score: 0};
  if (!cards.length) return result(trayTypes.length ? 'blocked' : 'solved', trayTypes.length ? 'unmatched_tray' : 'board_clear', initial);
  // A route stops at its FIRST triple. Until that point every pick occupies a
  // slot, so it can never need more moves than the remaining physical slots.
  var routeDepth = Math.min(maxDepth, capacity - initial.occupancy);
  function removed(state, idx) { return (state.removed[idx >>> 5] & (1 << (idx & 31))) !== 0; }
  function eligible(state, idx) {
    if (removed(state, idx)) return false;
    var card = cards[idx];
    if (!card.available && !card.blockers.length) return false;
    for (var k = 0; k < card.blockers.length; k++) if (!removed(state, card.blockers[k])) return false;
    return true;
  }
  function legal(state, idx) {
    if (!eligible(state, idx)) return false;
    var triple = state.counts[cards[idx].type] === 2;
    return state.occupancy + 1 <= capacity && (triple || state.occupancy + 1 < capacity);
  }
  function timedOut() {
    if (Date.now() - start >= budgetMs) { limit = 'time_budget'; return true; }
    return false;
  }
  function exhausted() {
    if (generated >= maxNodes) { limit = 'node_budget'; return true; }
    return timedOut();
  }
  function unlockRank(state, idx) {
    var rank = 0;
    for (var u = 0; u < covers[idx].length; u++) {
      var child = cards[covers[idx][u]], remaining = 0;
      for (var v = 0; v < child.blockers.length; v++) if (!removed(state, child.blockers[v])) remaining++;
      if (remaining === 1) rank += 1 + state.counts[child.type] * 3;
    }
    return rank;
  }
  function candidates(state, onlyType) {
    var output = [], equivalent = Object.create(null);
    for (var k = 0; k < cards.length; k++) {
      if (!legal(state, k) || (onlyType !== undefined && cards[k].type !== onlyType)) continue;
      var card = cards[k], same = state.counts[card.type];
      if (equivalent[card.equivalence]) { pruned++; continue; }
      equivalent[card.equivalence] = true;
      output.push({index: k, rank: (same === 2 ? 10000 : same === 1 ? 1000 : 0) + unlockRank(state, k) * 10});
    }
    output.sort(function (a, b) { return b.rank - a.rank || cards[a.index].order - cards[b.index].order || a.index - b.index; });
    return output;
  }
  function apply(state, idx) {
    var bitset = state.removed.slice(), nextCounts = state.counts.slice(), card = cards[idx];
    bitset[idx >>> 5] |= 1 << (idx & 31);
    var triple = nextCounts[card.type] === 2;
    nextCounts[card.type] = triple ? 0 : nextCounts[card.type] + 1;
    var occupancy = state.occupancy + 1 - (triple ? 3 : 0);
    var child = {removed: bitset, counts: nextCounts, occupancy: occupancy,
      removedCount: state.removedCount + 1, path: state.path.concat(idx),
      peak: Math.max(state.peak, state.occupancy + 1), matchedType: triple ? card.type : null, score: 0};
    var pairs = 0;
    for (var k = 0; k < nextCounts.length; k++) if (nextCounts[k] === 2) pairs++;
    child.score = pairs * 100 + unlockRank(state, idx);
    return child;
  }
  function prove(node) {
    // Replay the whole emitted route independently of the search score. No
    // partial route, random fallback, premature triple, or final-slot loss can
    // escape as an executable decision.
    var check = initial;
    if (!node.path.length || node.path.length > routeDepth) return false;
    for (var k = 0; k < node.path.length; k++) {
      if (check.matchedType !== null || !legal(check, node.path[k])) return false;
      check = apply(check, node.path[k]);
    }
    return check.matchedType !== null && check.matchedType === node.matchedType &&
      check.peak <= capacity && check.occupancy === initial.occupancy + node.path.length - 3;
  }
  function completed(node) {
    // Beam pruning can miss a shorter route. Remove any unrelated pick whose
    // omission still proves this exact triple, rather than publishing a
    // needlessly occupied slot as part of the recommendation.
    for (var omit = node.path.length - 1; omit >= 0; omit--) {
      if (cards[node.path[omit]].type === node.matchedType) continue;
      var trimmed = initial, valid = true;
      for (var pi = 0; pi < node.path.length; pi++) if (pi !== omit) {
        if (trimmed.matchedType !== null || !legal(trimmed, node.path[pi])) { valid = false; break; }
        trimmed = apply(trimmed, node.path[pi]);
      }
      if (valid && trimmed.matchedType === node.matchedType) node = trimmed;
    }
    if (!prove(node)) return invalid('invalid_route_proof');
    return result('move', node.removedCount === cards.length && node.occupancy === 0 ? 'solution_found' : 'triple_route', node);
  }
  if (timedOut()) return result('blocked', 'search_budget_exhausted', null);
  var initialOptions = candidates(initial);
  if (!initialOptions.length) return result('blocked', initial.occupancy >= capacity - 1 ? 'tray_capacity' : 'no_available_card', null);

  // First complete a same-type triple without collecting unrelated blockers.
  // Existing pairs come first, then one existing card, then a fresh trio. A
  // deterministic topological walk also handles three matching stacked cards.
  searchMode = 'direct';
  var types = [], totals = counts.slice();
  for (i = 0; i < cards.length; i++) totals[cards[i].type]++;
  for (i = 0; i < typeCount; i++) if (totals[i] >= 3) types.push(i);
  types.sort(function (a, b) { return counts[b] - counts[a] || a - b; });
  for (var ti = 0; ti < types.length; ti++) {
    var direct = initial;
    for (var step = 0; step < routeDepth; step++) {
      if (exhausted()) return result('blocked', 'search_budget_exhausted', null);
      var sameOptions = candidates(direct, types[ti]); visited++;
      if (!sameOptions.length) break;
      direct = apply(direct, sameOptions[0].index); generated++;
      depthReached = Math.max(depthReached, direct.path.length);
      if (direct.matchedType !== null) return completed(direct);
    }
  }

  // No direct trio exists. Search only paths that demonstrably reveal and
  // complete one. Breadth-first depth prevents gratuitous extra picks; a beam
  // and strict budgets bound work on the main JavaScript thread.
  searchMode = 'unlock';
  var frontier = [initial], found = Object.create(null);
  for (var depth = 1; depth <= routeDepth; depth++) {
    if (timedOut()) break;
    var next = [];
    for (var fi = 0; fi < frontier.length; fi++) {
      var state = frontier[fi]; visited++;
      var options = state === initial ? initialOptions : candidates(state);
      for (var oi = 0; oi < options.length; oi++) {
        if (exhausted()) break;
        var child = apply(state, options[oi].index); generated++;
        depthReached = Math.max(depthReached, depth);
        if (child.matchedType !== null) return completed(child);
        var key = Array.prototype.join.call(child.removed, '.');
        if (found[key]) { pruned++; continue; }
        found[key] = true; next.push(child);
      }
      if (limit) break;
    }
    if (limit || !next.length) break;
    next.sort(function (a, b) { return b.score - a.score || a.path[0] - b.path[0]; });
    if (next.length > beamWidth) { pruned += next.length - beamWidth; next.length = beamWidth; }
    frontier = next;
    if (depth === routeDepth && maxDepth < capacity - initial.occupancy) limit = 'depth_limit';
  }
  return result('blocked', limit ? 'search_budget_exhausted' : 'no_complete_triple', null);
})

(function SDKtoolsPlannerFactory() {
  'use strict';
  // A private resumable search belongs to this runtime, never to a global.
  // Only a fully replayed plan for the observed closed board is executable.
  // Clearing this local model does not assert a server-confirmed game victory.
  var session = null;
  return function SDKtoolsPlan(input) {
  var start = Date.now(), rawTypes = [], sliceGenerated = 0, sliceLimit = null;
  function empty(status, reason) {
    return {status:status, reason:reason, cardID:null, actions:[], sequence:[], matchedType:null,
      tripleCardIDs:[], peakTrayCount:0, proofKind:null,
      stats:{expanded:0,generated:0,pruned:0,backtracks:0,transpositions:0,depth:0,slices:0,targetTriples:0,
        elapsedMs:Math.max(0,Date.now()-start),limit:null,searchMode:'complete_dfs',completeSolution:false,completePlan:false,completeSearch:false}};
  }
  function invalid(reason) { session=null; return empty('invalid_state',reason); }
  function bounded(value, fallback, low, high) {
    return typeof value === 'number' && isFinite(value) ? Math.max(low, Math.min(high, Math.floor(value))) : fallback;
  }
  function textID(value) { return typeof value === 'string' && value.length > 0 && value.length <= 128; }
  if (!input || typeof input !== 'object' || !Array.isArray(input.cards) || !Array.isArray(input.tray)) return invalid('invalid_input');
  var cards = [], raw = input.cards, capacity = input.capacity;
  if (!Number.isInteger(capacity) || capacity < 2 || capacity > 12 || input.matchSize !== 3) return invalid('unsupported_rules');
  if (raw.length > 512 || input.tray.length >= capacity) return invalid('invalid_board_size');
  var maxNodes = bounded(input.maxNodes, 600, 1, 4000);
  var maxDepth = bounded(input.maxDepth, 512, 1, 512);
  var budgetMs = bounded(input.budgetMs, 8, 1, 12);
  var maxTotalNodes = bounded(input.maxTotalNodes, 120000, 1, 500000);
  var maxTranspositions = bounded(input.maxTranspositions, 20000, 1, 40000);
  if (input.stateKey !== undefined && (typeof input.stateKey !== 'string' || input.stateKey.length > 262144)) return invalid('invalid_state_key');
  var indexByID = Object.create(null), typeIndex = Object.create(null), typeCount = 0, edgeCount = 0;
  function indexType(type) {
    if (!textID(type) || /^(unknown|unreadable|special)$/i.test(type)) return -1;
    if (typeIndex[type] === undefined) { typeIndex[type] = typeCount++; rawTypes.push(type); }
    return typeIndex[type];
  }
  for (var i = 0; i < raw.length; i++) {
    var c = raw[i];
    if (!c || !textID(c.id) || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_card_id');
    var t = indexType(c.type);
    if (t < 0 || (c.zone !== 'board' && c.zone !== 'reserve') || typeof c.available !== 'boolean' || !Array.isArray(c.blockedBy)) return invalid('unreadable_card');
    if ((c.locked !== undefined && typeof c.locked !== 'boolean') || (c.selectable !== undefined && typeof c.selectable !== 'boolean')) return invalid('invalid_card_lock');
    edgeCount += c.blockedBy.length;
    if (c.blockedBy.length > 64 || edgeCount > 8192) return invalid('excessive_blockers');
    indexByID[c.id] = i;
    cards.push({id: c.id, type: t, available: c.available, locked: c.locked === true || c.selectable === false, blockedBy: c.blockedBy.slice(), blockers: [],
      zone: c.zone, order: Number.isFinite(c.order) ? c.order : i});
  }
  var trayTypes = [], trayIDs = Object.create(null);
  for (i = 0; i < input.tray.length; i++) {
    c = input.tray[i];
    if (!c || !textID(c.id) || trayIDs[c.id] || indexByID[c.id] !== undefined) return invalid('duplicate_or_invalid_tray_id');
    t = indexType(c.type);
    if (t < 0) return invalid('unreadable_tray');
    trayIDs[c.id] = true; trayTypes.push(t);
  }
  var counts = new Array(typeCount).fill(0), indegree = new Array(cards.length).fill(0);
  var covers = cards.map(function () { return []; });
  for (i = 0; i < trayTypes.length; i++) {
    counts[trayTypes[i]]++;
    if (counts[trayTypes[i]] >= 3) return invalid('unsettled_tray');
  }
  for (i = 0; i < cards.length; i++) {
    var seen = Object.create(null);
    c = cards[i];
    for (var j = 0; j < c.blockedBy.length; j++) {
      var blockerID = c.blockedBy[j], b = indexByID[blockerID];
      if (!textID(blockerID) || b === undefined || b === i || seen[blockerID]) return invalid('invalid_blocker');
      seen[blockerID] = true; c.blockers.push(b); covers[b].push(i); indegree[i]++;
    }
    if ((c.available && c.blockers.length) || (c.zone === 'reserve' && c.blockers.length)) return invalid('inconsistent_availability');
  }
  // A cycle is not a difficult puzzle; it is evidence of an invalid observation.
  var queue = [], qi = 0, cycleCount = 0;
  for (i = 0; i < cards.length; i++) if (!indegree[i]) queue.push(i);
  while (qi < queue.length) {
    var n = queue[qi++]; cycleCount++;
    for (j = 0; j < covers[n].length; j++) if (--indegree[covers[n][j]] === 0) queue.push(covers[n][j]);
  }
  if (cycleCount !== cards.length) return invalid('cyclic_blockers');
  for (i = 0; i < cards.length; i++) cards[i].equivalence = cards[i].type + ':' + covers[i].join(',');
  var fingerprint = JSON.stringify([input.stateKey || '',capacity,maxDepth,maxTotalNodes,maxTranspositions,
    cards.map(function(c){return [c.id,rawTypes[c.type],c.available,c.locked,c.blockedBy,c.order,c.zone];}),
    input.tray.map(function(c){return [c.id,c.type];})]);
  function removed(state, idx) { return (state.removed[idx >>> 5] & (1 << (idx & 31))) !== 0; }
  function eligible(state, idx) {
    var c=cards[idx];
    if (removed(state,idx) || c.locked || (!c.available && !c.blockers.length)) return false;
    for(var k=0;k<c.blockers.length;k++) if(!removed(state,c.blockers[k])) return false;
    return true;
  }
  function legal(state, idx) {
    return eligible(state,idx) && state.occupancy < capacity &&
      (state.counts[cards[idx].type] === 2 || state.occupancy + 1 < capacity);
  }
  function advance(state, idx) {
    var bits=state.removed.slice(), next=state.counts.slice(), type=cards[idx].type, triple=next[type]===2;
    bits[idx>>>5]|=1<<(idx&31); next[type]=triple?0:next[type]+1;
    return {removed:bits,counts:next,occupancy:state.occupancy+1-(triple?3:0),removedCount:state.removedCount+1,triples:state.triples+(triple?1:0),
      peak:Math.max(state.peak,state.occupancy+1)};
  }
  function stateKey(state) { return Array.prototype.join.call(state.removed,'.'); }
  function frame(state, chosen) { return {state:state,chosen:chosen,options:null,next:0,scan:0,building:[],equivalent:Object.create(null)}; }
  var initial={removed:new Uint32Array(Math.ceil(cards.length/32)),counts:counts,occupancy:trayTypes.length,removedCount:0,peak:trayTypes.length,triples:0};
  var totals=counts.slice(), lockedTotals=new Array(typeCount).fill(0), targetTriples=0, balanced=true;
  for(i=0;i<cards.length;i++){totals[cards[i].type]++;if(cards[i].locked)lockedTotals[cards[i].type]++;}
  for(i=0;i<typeCount;i++){targetTriples+=Math.floor(totals[i]/3);if(totals[i]%3)balanced=false;}
  var goalKind=balanced?'complete_board':'all_observed_triples';
  // A type with fewer than three cards can only be useful as an observed
  // blocker of a type that still has a possible trio. This pruning is exact.
  var useful=new Array(cards.length).fill(false), needed=[];
  for(i=0;i<cards.length;i++)if(totals[cards[i].type]>=3){useful[i]=true;needed.push(i);}
  for(i=0;i<needed.length;i++)for(j=0;j<cards[needed[i]].blockers.length;j++){
    var ancestor=cards[needed[i]].blockers[j];if(!useful[ancestor]){useful[ancestor]=true;needed.push(ancestor);}
  }
  if (!session || session.fingerprint !== fingerprint) {
    session={fingerprint:fingerprint,stack:[frame(initial,-1)],dead:new Set(),generated:0,expanded:0,pruned:0,backtracks:0,
      depth:0,slices:0,terminal:null,limit:null,proof:null,completeSearch:false};
    if(!cards.length && !trayTypes.length) session.terminal='board_clear';
    else if(!targetTriples) session.terminal='no_remaining_triples';
    else if(lockedTotals.some(function(n,t){return n>totals[t]%3;})) session.terminal='observed_state_locked';
    else if(balanced && maxDepth<cards.length){session.terminal='search_limit_reached';session.limit='depth_limit';}
  }
  session.slices++;
  function result(status, reason) {
    var proof=session.proof, sequence=proof?proof.sequence.slice():[];
    return {status:status,reason:reason,cardID:sequence.length?sequence[0]:null,sequence:sequence,actions:sequence.slice(),
      matchedType:proof?proof.matchedType:null,tripleCardIDs:proof?proof.tripleCardIDs.slice():[],
      peakTrayCount:proof?proof.peak:0,proofKind:proof?goalKind:status==='solved'?'complete_board':null,
      stats:{expanded:session.expanded,generated:session.generated,pruned:session.pruned,backtracks:session.backtracks,
        transpositions:session.dead.size,depth:session.depth,slices:session.slices,targetTriples:targetTriples,elapsedMs:Math.max(0,Date.now()-start),
        limit:session.limit || sliceLimit,searchMode:'complete_dfs',completeSolution:!!(proof&&proof.empty) || status==='solved',completePlan:!!proof || status==='solved',completeSearch:session.completeSearch}};
  }
  function terminal() {
    if(session.terminal==='solution_found') return result('move','solution_found');
    if(session.terminal==='board_clear') return result('solved','board_clear');
    return result('blocked',session.terminal);
  }
  if(session.terminal) return terminal();
  function outOfTime() {
    if(Date.now()-start>=budgetMs){sliceLimit='time_slice';return true;} return false;
  }
  function rank(state,idx) {
    var type=cards[idx].type, same=state.counts[type], score=same===2?100000:same===1?5000:0;
    for(var u=0;u<covers[idx].length;u++) {
      var child=cards[covers[idx][u]], left=0;
      for(var v=0;v<child.blockers.length;v++) if(!removed(state,child.blockers[v])) left++;
      if(left===1) score+=20+state.counts[child.type]*100;
    }
    return score;
  }
  function buildOptions(f) {
    // Candidate construction itself is resumable. A wide board does not get
    // one unbounded scan merely because the DFS node budget has not expired.
    while(f.scan<cards.length) {
      if((f.scan&15)===0 && outOfTime()) return false;
      var idx=f.scan++, c=cards[idx];
      if(!useful[idx] || !legal(f.state,idx)) continue;
      if(f.equivalent[c.equivalence]){session.pruned++;continue;}
      f.equivalent[c.equivalence]=true;f.building.push({idx:idx,rank:rank(f.state,idx)});
    }
    f.building.sort(function(a,b){return b.rank-a.rank || cards[a.idx].order-cards[b.idx].order || a.idx-b.idx;});
    f.options=f.building.map(function(o){return o.idx;}); f.building=null;f.equivalent=null;session.expanded++;
    return true;
  }
  function proofFor(path) {
    if(!path.length || path.length>cards.length || path.length>maxDepth) return null;
    var check=initial, firstType=null, firstIDs=[], groups=Object.create(null);
    input.tray.forEach(function(c){var t=typeIndex[c.type];(groups[t]||(groups[t]=[])).push(c.id);});
    for(var k=0;k<path.length;k++) {
      var idx=path[k], c=cards[idx];
      if(!Number.isInteger(idx) || !c || !legal(check,idx)) return null;
      var ids=groups[c.type]||(groups[c.type]=[]);ids.push(c.id);
      if(ids.length===3){if(firstType===null){firstType=rawTypes[c.type];firstIDs=ids.slice();}groups[c.type]=[];}
      check=advance(check,idx);
    }
    if(check.triples!==targetTriples || check.peak>capacity) return null;
    var lastType=cards[path[path.length-1]].type;
    if(check.counts[lastType]!==0) return null; // Last pick must finish a trio.
    var residual=Array.prototype.slice.call(check.counts);
    for(k=0;k<cards.length;k++)if(!removed(check,k))residual[cards[k].type]++;
    if(residual.some(function(n){return n>=3;}))return null;
    var empty=check.removedCount===cards.length&&check.occupancy===0;
    if(balanced&&!empty)return null;
    var loose=[];Object.keys(groups).forEach(function(t){loose=loose.concat(groups[t]);});
    return {sequence:path.map(function(idx){return cards[idx].id;}),matchedType:firstType,tripleCardIDs:firstIDs,peak:check.peak,empty:empty,loose:loose};
  }
  while(session.stack.length) {
    var f=session.stack[session.stack.length-1];
    if(f.state.triples===targetTriples) {
      var path=session.stack.slice(1).map(function(x){return x.chosen;});
      session.proof=proofFor(path);
      // Remove any unnecessarily collected residual card. At most six cards
      // remain in the bar, so this final replay step is tightly bounded.
      if(session.proof&&!balanced)for(var pi=path.length-1;pi>=0;pi--){
        if(session.proof.loose.indexOf(cards[path[pi]].id)<0)continue;
        var trimmed=path.slice();trimmed.splice(pi,1);var smaller=proofFor(trimmed);
        if(smaller){path=trimmed;session.proof=smaller;}
      }
      if(!session.proof){session.terminal='invalid_route_proof';return result('invalid_state','invalid_route_proof');}
      session.terminal='solution_found';return terminal();
    }
    if(outOfTime()) return result('searching','search_in_progress');
    if(sliceGenerated>=maxNodes){sliceLimit='node_slice';return result('searching','search_in_progress');}
    if(f.state.removedCount>=maxDepth){session.limit='depth_limit';session.terminal='search_limit_reached';return terminal();}
    if(f.options===null && !buildOptions(f)) return result('searching','search_in_progress');
    if(f.next>=f.options.length) {
      if(session.dead.size>=maxTranspositions){session.limit='memory_budget';session.terminal='search_limit_reached';return terminal();}
      session.dead.add(stateKey(f.state));session.stack.pop();session.backtracks++;continue;
    }
    if(session.generated>=maxTotalNodes){session.limit='total_node_budget';session.terminal='search_limit_reached';return terminal();}
    var idx=f.options[f.next++], child=advance(f.state,idx);session.generated++;sliceGenerated++;
    if(session.dead.has(stateKey(child))){session.pruned++;continue;}
    session.stack.push(frame(child,idx));session.depth=Math.max(session.depth,child.removedCount);
  }
  session.terminal='no_complete_solution';session.completeSearch=true;return terminal();
  };
})()

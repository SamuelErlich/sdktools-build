/* SDKtools V3.5. Explicit, bounded card investigation for gameType 2007.
 * Native owns activation/context. This closure never writes a namespace,
 * invokes game accessors/handlers, reads modules or infers hidden identities.
 * Inactive artwork may be default/stale: identityVerified is ALWAYS false.
 * cpn/cpf/cpt/cpc/cpo IDs are local to this probe + document + sceneEpoch;
 * they are NOT scene_probe node/frame IDs or server/player identifiers.
 */
(function makeCardProbe() {
  'use strict';
  var L={nodes:4096,children:512,depth:24,cards:64,branch:16,branchDepth:5,components:8,fields:12,nestedFields:8,keys:256,ms:8,bytes:49152,cardBytes:16384};
  var PRIVATE=/user|player|owner|account|member|avatar|nick|session|token|cookie|auth|secret|password|passwd|email|phone|url|path|address|uuid|guid|socket|request|response|login|device|client|server|credential/i;
  var RELEVANT=/(card|poker|uno|rank|suit|value|color|point|face|front|back|index|type|state|status|num|count|selected|active|visible|reveal|flip)/i;
  var NESTED=/^(card(info|data|state|model)?|poker(info|data|state|model)?|uno(info|data|state|model)?|face(info|data|state)?|front(info|data|state)?)$/i;
  var root=null,engine=null,documentRef=null,epoch=0,index=0,cursor=0,born=null;
  var maps={},next={};
  function resetIDs(){maps={n:new WeakMap(),f:new WeakMap(),t:new WeakMap(),c:new WeakMap(),o:new WeakMap()};next={n:0,f:0,t:0,c:0,o:0};}
  resetIDs();
  function object(v){return v!==null && (typeof v==='object'||typeof v==='function');}
  function own(o,k){if(!object(o))return null;var d=Object.getOwnPropertyDescriptor(o,k);return d && Object.prototype.hasOwnProperty.call(d,'value')?d:null;}
  function id(kind,v){if(!object(v))return null;if(!maps[kind].has(v)){if(next[kind]>=1000000)throw Error('read_error');maps[kind].set(v,'cp'+kind+(++next[kind]));}return maps[kind].get(v);}
  function finite(v){return typeof v==='number'&&isFinite(v);}
  function number(v,limit){return finite(v)&&Math.abs(v)<=limit?Math.round(v*1000)/1000:null;}
  function valid(n){return !!n && n.isValid===true;}
  function clock(){try{if(window.performance&&typeof window.performance.now==='function')return window.performance.now();}catch(_){}return Date.now();}
  function name(n){return typeof n.name==='string'?n.name.slice(0,128):'';}
  function active(n){return valid(n)&&n.active===true;}
  function visible(n){return active(n)&&n.activeInHierarchy!==false&&(!finite(n.opacity)||n.opacity>0);}
  function tag(s){if(typeof s!=='string')return null;var h=2166136261;for(var i=0;i<Math.min(s.length,128);i++)h=Math.imul(h^s.charCodeAt(i),16777619);return ('00000000'+(h>>>0).toString(16)).slice(-8);}
  function sprite(cc,n){if(!valid(n)||typeof n.getComponent!=='function')return null;return n.getComponent(cc.Sprite);}
  function frameInfo(f){
    if(!object(f)||typeof f.getRect!=='function'||typeof f.getTexture!=='function')return null;
    var r=f.getRect(),t=f.getTexture();
    if(!r||!['x','y','width','height'].every(function(k){return finite(r[k])&&r[k]>=0&&r[k]<=16384;})||r.width<=0||r.height<=0)return null;
    return {frameID:id('f',f),textureID:object(t)?id('t',t):null,nameTag:tag(f.name),rect:{x:r.x,y:r.y,width:r.width,height:r.height},loaded:t&&typeof t.loaded==='boolean'?t.loaded:null};
  }
  function signature(f,hash,rect){var d=frameInfo(f);return d&&d.nameTag===hash&&d.rect.x===rect[0]&&d.rect.y===rect[1]&&d.rect.width===rect[2]&&d.rect.height===rect[3];}
  function children(n){var a=n.children;if(!Array.isArray(a)||a.length>L.children)throw Error('node_limit');return a;}
  function candidate(cc,n){
    if(!/card/i.test(name(n))||n.width!==224||n.height!==295||sprite(cc,n))return false;
    var a=children(n);if(a.length!==4||!valid(a[1])||!valid(a[2])||!valid(a[3])||sprite(cc,a[2]))return false;
    var b=sprite(cc,a[1]);if(!b||!signature(b.spriteFrame,'260ca2c4',[909,212,216,286]))return false;
    if(visible(a[2])){var f=children(a[2]);return f.length>=3&&!!sprite(cc,f[0])&&!!sprite(cc,f[2]);}
    if(visible(a[3])){var back=sprite(cc,a[3]);return !!back&&(signature(back.spriteFrame,'811c9dc5',[1357,208,224,295])||signature(back.spriteFrame,'4dbc405b',[1138,212,210,280]));}
    return false;
  }
  function fieldName(k){if(typeof k!=='string'||!/^[A-Za-z_$][A-Za-z0-9_$]{0,47}$/.test(k))return false;var n=k.replace(/^_+/,'').toLowerCase();return n==='seatindex'||n==='playerindex'||(!PRIVATE.test(n)&&RELEVANT.test(n));}
  function className(c){
    var p=c;for(var depth=0;object(p)&&depth<5;depth++,p=Object.getPrototypeOf(p)){
      var d=own(p,'__classname__');if(d){var s=d.value;return typeof s==='string'&&/^[A-Za-z_$][A-Za-z0-9_.$]{0,63}$/.test(s)&&!PRIVATE.test(s)?s:null;}
    }return null;
  }
  function componentObjects(n){var d=own(n,'_components');return d&&Array.isArray(d.value)?d.value:[];}
  return function capture(){
    var began=clock();if(born===null)born=began;
    var out={version:1,status:'waiting',reason:'no_verified_cards',sceneEpoch:epoch,sampleIndex:0,elapsedMs:Math.max(0,Math.min(3600000,Math.round(began-born))),truncated:false,truncationReasons:[],cards:[]};
    function clip(reason){out.truncated=true;if(out.truncationReasons.indexOf(reason)<0)out.truncationReasons.push(reason);}
    function timed(){if(clock()-began>=L.ms){clip('time_budget');return true;}return false;}
    function fail(status,reason){out.status=status;out.reason=reason;return out;}
    function safeFrame(f){try{return frameInfo(f);}catch(_){clip('read_error');return null;}}
    var cc=window.cc,current;
    try{
      if(!cc||(cc.ENGINE_VERSION!=='2.4.5'&&window.CocosEngine!=='2.4.5')||(cc.ENGINE_VERSION&&cc.ENGINE_VERSION!=='2.4.5')||(window.CocosEngine&&window.CocosEngine!=='2.4.5'))return fail('unsupported','unsupported_engine');
      if(document.hidden===true||document.visibilityState==='hidden')return fail('blocked','hidden_document');
      if(!cc.director||typeof cc.director.getScene!=='function'||!valid(current=cc.director.getScene())||!cc.Sprite)return fail('waiting','scene_unavailable');
      if(current!==root||engine!==cc||documentRef!==document){root=current;engine=cc;documentRef=document;epoch=Math.min(1000000,epoch+1);index=0;cursor=0;resetIDs();}
      out.sceneEpoch=epoch;out.sampleIndex=Math.min(1000000,++index);
      var found=[],queue=[{n:root,depth:0}],seen=new Set();
      while(queue.length&&!timed()){
        if(seen.size>=L.nodes){clip('node_limit');break;}
        var item=queue.pop(),n=item.n;if(!valid(n)||seen.has(n)||(n!==root&&!visible(n))||/^SDKtools /.test(name(n)))continue;seen.add(n);
        if(item.depth>L.depth){clip('node_limit');continue;}
        if(candidate(cc,n)){
          if(found.length>=L.cards){clip('card_limit');break;}
          id('n',n);found.push(n);continue;
        }
        var a=children(n);for(var i=a.length-1;i>=0;i--)queue.push({n:a[i],depth:item.depth+1});if(queue.length>L.nodes){clip('node_limit');break;}
      }
      if(!found.length)return out;
      var start=cursor%found.length,captured=0;
      function fields(o,depth,refs){
        var result=[],keys=Object.getOwnPropertyNames(o);if(keys.length>L.keys){keys=keys.slice(0,L.keys);clip('field_limit');}
        for(var i=0;i<keys.length;i++){
          var k=keys[i];if(!fieldName(k))continue;
          if(result.length>=(depth?L.nestedFields:L.fields)){clip('field_limit');break;}
          var d=Object.getOwnPropertyDescriptor(o,k),row={name:k,kind:'other'},normalized=k.replace(/^_+/,'').toLowerCase();
          if(!d)continue;
          if(!Object.prototype.hasOwnProperty.call(d,'value')){row.kind='accessor_skipped';result.push(row);continue;}
          var value=d.value;
          if(normalized==='seatindex'||normalized==='playerindex'){
            if(Number.isInteger(value)&&value>=0&&value<=7){row.kind='number';row.value=value;result.push(row);}continue;
          }
          if(typeof value==='boolean'){row.kind='boolean';row.value=value;}
          else if(finite(value)&&Math.abs(value)<=65535){row.kind='number';row.value=value;}
          else if(typeof value==='string')row.kind='string_omitted';
          else if(typeof value==='function')row.kind='function_omitted';
          else if(object(value)){
            if(refs.nodes.has(value)){row.kind='node_ref';row.ref=refs.nodes.get(value);}
            else if(refs.frames.has(value)){row.kind='frame_ref';row.ref=refs.frames.get(value);}
            else if(refs.components.has(value)){row.kind='component_ref';row.ref=refs.components.get(value);}
            else if(Array.isArray(value)){row.kind='array_omitted';row.length=Math.min(256,value.length);}
            else if(depth===0&&NESTED.test(normalized)){
              var proto=Object.getPrototypeOf(value);
              if(proto===null||Object.getPrototypeOf(proto)===null){row.kind='object';row.objectID=id('o',value);row.fields=fields(value,1,refs);}
            }
          }
          result.push(row);
        }return result;
      }
      function inspect(n){
        var a=children(n),parent=n.parent,siblings=valid(parent)?children(parent):[],record={nodeID:id('n',n),parentID:valid(parent)?id('n',parent):null,siblingIndex:Math.max(0,Math.min(511,siblings.indexOf(n))),frontActive:visible(a[2]),backActive:visible(a[3]),identityVerified:false,
          local:{x:number(n.x,100000),y:number(n.y,100000),width:n.width,height:n.height,scaleX:number(n.scaleX,100),scaleY:number(n.scaleY,100),angle:number(n.angle,36000),zIndex:number(n.zIndex,32768)},nodes:[],components:[]};
        Object.keys(record.local).forEach(function(k){if(record.local[k]===null)delete record.local[k];});
        // A local position without its parent's transform cannot be aligned
        // with another probe/video. Keep the observed world origin optional;
        // absent/invalid geometry must never become an invented zero.
        try{
          if(typeof n.convertToWorldSpaceAR==='function'&&typeof cc.v2==='function'){
            var p=n.convertToWorldSpaceAR(cc.v2(0,0)),wx=p?number(p.x,100000):null,wy=p?number(p.y,100000):null;
            if(wx!==null&&wy!==null)record.worldOrigin={x:wx,y:wy};
          }
        }catch(_){}
        var refs={nodes:new Map(),frames:new Map(),components:new Map()},components=[],todo=[{n:n,branch:'root',path:[]}],walked=new Set();
        while(todo.length&&!timed()){
          if(record.nodes.length>=L.branch){clip('branch_limit');break;}
          var item=todo.pop(),node=item.n;if(!valid(node)||walked.has(node)||/^SDKtools /.test(name(node)))continue;walked.add(node);
          if(item.path.length>L.branchDepth){clip('branch_limit');continue;}
          var nodeID=id('n',node),sp=sprite(cc,node),frame=sp?safeFrame(sp.spriteFrame):null;
          refs.nodes.set(node,nodeID);if(frame)refs.frames.set(sp.spriteFrame,frame.frameID);
          record.nodes.push({nodeID:nodeID,parentID:valid(node.parent)?id('n',node.parent):null,branch:item.branch,path:item.path,active:active(node),activeInHierarchy:node.activeInHierarchy===true,frame:frame,identityVerified:false});
          var list=componentObjects(node);if(list.length>L.components)clip('component_limit');
          for(var j=0;j<Math.min(list.length,L.components);j++){var component=list[j];if(!object(component))continue;components.push({value:component,nodeID:nodeID,name:className(component)});}
          if(item.branch==='root'){
            // Only proven structural siblings; no shadow, unrelated player UI
            // or whole-scene inactive traversal is included.
            [3,2,1].forEach(function(k){todo.push({n:a[k],branch:k===1?'base':k===2?'front':'back',path:[k]});});
          }else{
            var childrenList=children(node);for(var k=childrenList.length-1;k>=0;k--)todo.push({n:childrenList[k],branch:item.branch,path:item.path.concat(k)});
          }
        }
        // Script components precede stock Cocos renderers, which would otherwise
        // consume all slots before the actual per-card state component.
        components.sort(function(a,b){return (/^cc\./.test(a.name||'')?1:0)-(/^cc\./.test(b.name||'')?1:0);});
        if(components.length>L.components){clip('component_limit');components=components.slice(0,L.components);}
        components.forEach(function(c){refs.components.set(c.value,id('c',c.value));});
        components.forEach(function(c){if(timed())return;record.components.push({componentID:refs.components.get(c.value),nodeID:c.nodeID,className:c.name,fields:fields(c.value,0,refs)});});
        while(JSON.stringify(record).length>L.cardBytes && record.components.length){
          var last=record.components[record.components.length-1];
          if(last.fields.length)last.fields.pop();else record.components.pop();clip('field_limit');
        }
        return record;
      }
      for(var offset=0;offset<found.length&&!timed();offset++){
        var card=found[(start+offset)%found.length],record;
        try{record=inspect(card);}catch(_){clip('read_error');continue;}
        out.cards.push(record);
        // Output contains ASCII identifiers/enums/numbers only, so JS length is
        // the exact byte count. Reserve room for truncation reason metadata.
        if(JSON.stringify(out).length>L.bytes-128){out.cards.pop();clip('payload_limit');break;}
        captured++;
      }
      cursor=(start+Math.max(1,captured))%found.length;
      out.status=out.cards.length?'ready':'waiting';out.reason=out.cards.length?'captured':'no_verified_cards';return out;
    }catch(error){clip(error&&['node_limit','card_limit','branch_limit','component_limit','field_limit'].indexOf(error.message)>=0?error.message:'read_error');return fail('error','read_error');}
  };
})

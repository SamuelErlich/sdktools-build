/* SDKtools V3.0. Read-only card visualization using already-loaded SpriteFrames.
 * Factory -> {render(snapshot, provenRoute), clear(), owns(node)}.
 * Only SDK-owned Cocos nodes are mutated. No game callbacks or network access.
 * Cocos Creator 2.4 public APIs: Node coordinate conversion, Sprite CUSTOM,
 * Graphics.moveTo/lineTo/close/stroke. No labels or synthetic card identities.
 */
(function makeXrayOverlay() {
  'use strict';
  var owned=new WeakSet(), layer=null, root=null, host=null, engine=null, graphic=null, icons=new Map(), previous=null;
  function finite(v) { return typeof v === 'number' && isFinite(v); }
  function valid(n) { return n && n.isValid === true; }
  function destroy(n) {
    if (!n) return;
    try { n.active=false; if (typeof n.removeFromParent === 'function') n.removeFromParent(false); } catch (_) {}
    try { if (typeof n.destroy === 'function') n.destroy(); } catch (_) {}
  }
  function clear() {
    destroy(layer); layer=null; graphic=null; root=null; host=null; engine=null; previous=null; icons.clear();
  }
  function node(cc,name,parent) {
    var n=new cc.Node(name); owned.add(n);
    n.anchorX=0.5; n.anchorY=0.5; n.x=0; n.y=0; n.zIndex=32700;
    if (typeof parent.group === 'string' && parent.group.length <= 128) n.group=parent.group;
    // No Button, event listener, collider or input-blocking component is added.
    parent.addChild(n); return n;
  }
  function coordinate(s,n,x,y) {
    if (!n || typeof n.convertToWorldSpaceAR !== 'function' || typeof layer.convertToNodeSpaceAR !== 'function') throw Error('coordinates');
    var p=layer.convertToNodeSpaceAR(n.convertToWorldSpaceAR(s.cc.v2(x,y)));
    if (!p || !finite(p.x) || !finite(p.y) || Math.abs(p.x)>100000 || Math.abs(p.y)>100000) throw Error('coordinates');
    return p;
  }
  function ensure(s) {
    var cc=s.cc;
    if (!cc || typeof cc.Node !== 'function' || typeof cc.Sprite !== 'function' || !cc.Sprite.SizeMode ||
        !finite(cc.Sprite.SizeMode.CUSTOM) || typeof cc.Graphics !== 'function' || typeof cc.Color !== 'function' ||
        typeof cc.v2 !== 'function' || !valid(s.root) || !valid(s.gameLayer) || typeof s.gameLayer.addChild !== 'function') return false;
    if (root !== s.root || host !== s.gameLayer || engine !== cc || !valid(layer) || layer.parent !== s.gameLayer) {
      clear(); root=s.root; host=s.gameLayer; engine=cc; layer=node(cc,'SDKtools Card Hints',host);
      layer.width=0; layer.height=0;
      graphic=layer.addComponent(cc.Graphics);
      if (!graphic || typeof graphic.clear !== 'function' || typeof graphic.moveTo !== 'function' ||
          typeof graphic.lineTo !== 'function' || typeof graphic.close !== 'function' || typeof graphic.stroke !== 'function') { clear(); return false; }
      graphic.lineWidth=3; graphic.strokeColor=new cc.Color(65,235,126,245);
    }
    return true;
  }
  function render(s,proof) {
    try {
      if (!s || !Array.isArray(s.cards) || s.cards.length>512 || !s.refs || !ensure(s)) { clear(); return {status:'unavailable',coveredIcons:0,matchedBorders:0}; }
      var covered=s.cards.filter(function(c){return c.zone === 'board' && c.masked === true;});
      var matched=proof && Array.isArray(proof.tripleCardIDs) && proof.tripleCardIDs.length === 3 &&
        proof.peakTrayCount <= s.capacity ? proof.tripleCardIDs.slice() : [];
      var positions=covered.map(function(card){return coordinate(s,card.node,-26,30);});
      var outlines=matched.map(function(key){
        var card=s.refs.get(key); if (!card) throw Error('proof');
        return [coordinate(s,card.node,-39,-44),coordinate(s,card.node,39,-44),
          coordinate(s,card.node,39,44),coordinate(s,card.node,-39,44)];
      });
      // Container/ancestor transforms are intentionally part of this stamp;
      // card-local signatures alone would leave hints behind a moving layer.
      var stamp=s.signature+'|'+JSON.stringify([matched,positions,outlines]), desired=new Set(), duplicates=new Map();
      // Identity and geometry are refreshed every valid snapshot. Unchanged
      // content reuses nodes and draw commands, preventing overlay flicker.
      if (stamp !== previous) {
        graphic.clear();
        covered.forEach(function(card,index) {
          var n=icons.get(card.id), sprite;
          if (!n || !valid(n)) { n=node(s.cc,'SDKtools Hidden Card',layer); sprite=n.addComponent(s.cc.Sprite); icons.set(card.id,n); }
          else sprite=n.getComponent(s.cc.Sprite);
          if (!sprite || !card.frame) throw Error('sprite');
          sprite.spriteFrame=card.frame; sprite.sizeMode=s.cc.Sprite.SizeMode.CUSTOM;
          n.width=24; n.height=27; n.opacity=235; n.active=true;
          var p=positions[index], key=Math.round(p.x)+':'+Math.round(p.y), rank=duplicates.get(key)||0;
          duplicates.set(key,rank+1);
          n.x=p.x+(rank%3)*25; n.y=p.y-Math.floor(rank/3)*28; desired.add(card.id);
        });
        icons.forEach(function(n,key){if (!desired.has(key)) { destroy(n); icons.delete(key); }});
        outlines.forEach(function(points){
          graphic.moveTo(points[0].x,points[0].y);
          for(var i=1;i<points.length;i++) graphic.lineTo(points[i].x,points[i].y);
          graphic.close();
        });
        if (outlines.length) graphic.stroke();
        previous=stamp;
      }
      return {status:'ready',coveredIcons:covered.length,matchedBorders:matched.length};
    } catch (_) { clear(); return {status:'unavailable',coveredIcons:0,matchedBorders:0}; }
  }
  return {render:render,clear:clear,owns:function(n){return n !== null && (typeof n === 'object' || typeof n === 'function') && owned.has(n);}};
})

/* SDKtools V3.3. Compact, anchored read-only hints from loaded SpriteFrames.
 * render(snapshot, provenRoute, {depth:1..4}), clear(), owns(node).
 * occlusionDepth is the adapter's longest original-blocker chain, not render
 * order or a guessed layer number. Only SDK-created nodes are changed.
 */
(function makeXrayOverlay() {
  'use strict';
  var owned=new WeakSet(), layer=null, root=null, host=null, engine=null, graphic=null, icons=new Map(), previous=null;
  var frameIDs=new WeakMap(), nextFrame=1, labelMode='none';
  var countLayer=null,countGraphic=null,countRows=new Map(),countStamp=null;
  var COUNT_WIDTH=58,COUNT_ROW=58,COUNT_GAP=6,COUNT_BOARD_GAP=4;
  var WIDTH=30, HEIGHT=24, MAX=512, PER_STACK=4, PAD=3;
  // Four transparent corner badges leave the exposed artwork's center free.
  var ART_WIDTH=18, ART_HEIGHT=20, FONT=11;
  function finite(v) { return typeof v === 'number' && isFinite(v); }
  function valid(n) { return n && n.isValid === true; }
  function destroy(n) {
    if (!n) return;
    try { n.active=false; if (typeof n.removeFromParent === 'function') n.removeFromParent(false); } catch (_) {}
    try { if (typeof n.destroy === 'function') n.destroy(); } catch (_) {}
  }
  function clear() {
    clearCounts();destroy(layer); layer=null; graphic=null; root=null; host=null; engine=null; previous=null; icons.clear(); labelMode='none';
  }
  function node(cc,name,parent) {
    var n=new cc.Node(name); owned.add(n);
    n.anchorX=0.5; n.anchorY=0.5; n.x=0; n.y=0; n.zIndex=32700;
    if (typeof parent.group === 'string' && parent.group.length <= 128) n.group=parent.group;
    // No input listener, Button, collider or input-blocking component is added.
    parent.addChild(n); return n;
  }
  function coordinate(s,n,x,y) {
    if (!valid(n) || typeof n.convertToWorldSpaceAR !== 'function' || typeof layer.convertToNodeSpaceAR !== 'function') throw Error('coordinates');
    var p=layer.convertToNodeSpaceAR(n.convertToWorldSpaceAR(s.cc.v2(x,y)));
    if (!p || !finite(p.x) || !finite(p.y) || Math.abs(p.x)>100000 || Math.abs(p.y)>100000) throw Error('coordinates');
    return {x:p.x,y:p.y};
  }
  function corners(s,n,pad) {
    if (!n || !finite(n.width) || !finite(n.height) || n.width<=0 || n.height<=0 || n.width>10000 || n.height>10000 ||
        !finite(n.anchorX) || !finite(n.anchorY) || n.anchorX<0 || n.anchorX>1 || n.anchorY<0 || n.anchorY>1) throw Error('bounds');
    var left=-n.width*n.anchorX-pad, bottom=-n.height*n.anchorY-pad;
    var right=n.width*(1-n.anchorX)+pad, top=n.height*(1-n.anchorY)+pad;
    return [coordinate(s,n,left,bottom),coordinate(s,n,right,bottom),coordinate(s,n,right,top),coordinate(s,n,left,top)];
  }
  function bounds(points) {
    var b={left:Infinity,right:-Infinity,bottom:Infinity,top:-Infinity};
    points.forEach(function(p){b.left=Math.min(b.left,p.x);b.right=Math.max(b.right,p.x);b.bottom=Math.min(b.bottom,p.y);b.top=Math.max(b.top,p.y);});
    return b;
  }
  function ensure(s) {
    var cc=s.cc;
    if (!cc || typeof cc.Node !== 'function' || typeof cc.Sprite !== 'function' || !cc.Sprite.SizeMode ||
        !finite(cc.Sprite.SizeMode.CUSTOM) || typeof cc.Graphics !== 'function' || typeof cc.Color !== 'function' ||
        typeof cc.v2 !== 'function' || !valid(s.root) || !valid(s.gameLayer) || typeof s.gameLayer.addChild !== 'function') return false;
    if (root !== s.root || host !== s.gameLayer || engine !== cc || !valid(layer) || layer.parent !== s.gameLayer) {
      clear(); root=s.root; host=s.gameLayer; engine=cc; layer=node(cc,'SDKtools Card Hints',host);
      layer.width=0; layer.height=0; graphic=layer.addComponent(cc.Graphics);
      if (!graphic || typeof graphic.clear !== 'function' || typeof graphic.moveTo !== 'function' ||
          typeof graphic.lineTo !== 'function' || typeof graphic.close !== 'function' || typeof graphic.stroke !== 'function') { clear(); return false; }
      labelMode=typeof cc.Label === 'function' && typeof cc.LabelOutline === 'function' ? 'cocos_label' : 'vector_digits';
    }
    return true;
  }
  function path(points) {
    graphic.moveTo(points[0].x,points[0].y);
    for(var i=1;i<points.length;i++) graphic.lineTo(points[i].x,points[i].y);
    graphic.close();
  }
  function rectangle(x,y,w,h) { return [{x:x-w/2,y:y-h/2},{x:x+w/2,y:y-h/2},{x:x+w/2,y:y+h/2},{x:x-w/2,y:y+h/2}]; }
  function smallText(s,owner,x,y,text,target) {
    var pen=target||graphic;
    // Tiny vector fallback uses the same anchor transform as the artwork.
    var segments=[[-2,3,2,3],[2,3,2,0],[2,0,2,-3],[-2,-3,2,-3],[-2,0,-2,-3],[-2,3,-2,0],[-2,0,2,0]];
    var digits={0:[0,1,2,3,4,5],1:[1,2],2:[0,1,6,4,3],3:[0,1,6,2,3],4:[5,6,1,2],5:[0,5,6,2,3],6:[0,5,6,4,2,3],7:[0,1,2],8:[0,1,2,3,4,5,6],9:[0,1,2,3,5,6]};
    var strokes=[];
    for(var i=0;i<text.length;i++) {
      var origin=x+(i-(text.length-1)/2)*6, lines=text[i]==='+'?[[-2,0,2,0],[0,-2,0,2]]:digits[text[i]].map(function(k){return segments[k];});
      lines.forEach(function(line){var a=target?{x:origin+line[0],y:y+line[1]}:coordinate(s,owner,origin+line[0],y+line[1]),b=target?{x:origin+line[2],y:y+line[3]}:coordinate(s,owner,origin+line[2],y+line[3]);strokes.push([a,b]);});
    }
    [3.4,1.2].forEach(function(width,index){
      pen.lineWidth=width;pen.strokeColor=index?new s.cc.Color(255,255,255,255):new s.cc.Color(0,0,0,255);
      strokes.forEach(function(line){pen.moveTo(line[0].x,line[0].y);pen.lineTo(line[1].x,line[1].y);});pen.stroke();
    });
  }
  function makeBadge(s,item) {
    var n=node(s.cc,'SDKtools Hidden Card',layer),labelNode=null,label=null;
    var halo=node(s.cc,'SDKtools Hint Outline',n),outline=halo.addComponent(s.cc.Sprite);
    halo.width=ART_WIDTH+4;halo.height=ART_HEIGHT+4;halo.color=new s.cc.Color(0,0,0,255);halo.zIndex=0;
    var art=node(s.cc,'SDKtools Hint Artwork',n),sprite=art.addComponent(s.cc.Sprite);
    art.width=ART_WIDTH;art.height=ART_HEIGHT;art.zIndex=1;
    if(!sprite || !outline){destroy(n);throw Error('sprite');}
    if(labelMode==='cocos_label') {
      try {
        labelNode=node(s.cc,'SDKtools Depth',n);label=labelNode.addComponent(s.cc.Label);
        if(!label)throw Error('label');
        label.fontSize=FONT;label.lineHeight=14;label.enableBold=true;label.useSystemFont=true;label.fontFamily='Arial';label.enableWrapText=false;
        var border=labelNode.addComponent(s.cc.LabelOutline);if(!border)throw Error('outline');
        border.color=new s.cc.Color(0,0,0,255);border.width=1.5;
        if(s.cc.Label.HorizontalAlign && finite(s.cc.Label.HorizontalAlign.CENTER))label.horizontalAlign=s.cc.Label.HorizontalAlign.CENTER;
        if(s.cc.Label.VerticalAlign && finite(s.cc.Label.VerticalAlign.CENTER))label.verticalAlign=s.cc.Label.VerticalAlign.CENTER;
        labelNode.color=new s.cc.Color(255,255,255,255);labelNode.width=10;labelNode.height=14;labelNode.zIndex=2;
      } catch(_){destroy(labelNode);labelNode=null;label=null;labelMode='vector_digits';}
    }
    var digits=node(s.cc,'SDKtools Depth Digits',n),depthGraphic=digits.addComponent(s.cc.Graphics);digits.zIndex=2;
    if(!depthGraphic || typeof depthGraphic.clear!=='function'){destroy(n);throw Error('digits');}
    return {node:n,sprite:sprite,outline:outline,labelNode:labelNode,label:label,depthGraphic:depthGraphic};
  }
  function overlap(a,b) { return a.left<b.right+2 && a.right>b.left-2 && a.bottom<b.top+2 && a.top>b.bottom-2; }
  function localRect(s,n,x,y,w,h) { return rectangle(x,y,w,h).map(function(p){return coordinate(s,n,p.x,p.y);}); }
  function hidden(c){return c.zone==='reserve'?c.storageVerified===true&&Number.isInteger(c.occlusionDepth)&&c.occlusionDepth>0:c.zone==='board'&&c.masked===true;}
  function exposedOwner(s,card,cache,visiting) {
    if(cache.has(card.id))return cache.get(card.id);
    if(visiting.has(card.id) || visiting.size>=MAX)throw Error('coverage_cycle');
    var links=card.zone==='reserve'?card.hintBlockedBy:card.blockedBy;
    if(!Array.isArray(links) || links.length>MAX)throw Error('coverage');
    visiting.add(card.id);
    var origin=coordinate(s,card.node,0,0),blockers=[],candidates=[];
    links.forEach(function(id){
      var b=s.refs.get(id);if(!b || b.zone!==card.zone || !valid(b.node))throw Error('coverage');
      blockers.push(b);if(b.masked===false && b.occlusionDepth===0)candidates.push(b);
    });
    // Prefer a directly covering exposed card. Only follow a covering chain
    // when none is directly exposed; cache avoids rescanning dense DAGs.
    if(!candidates.length)blockers.forEach(function(b){var owner=exposedOwner(s,b,cache,visiting);if(owner && candidates.indexOf(owner)<0)candidates.push(owner);});
    var ranked=candidates.map(function(c){var p=coordinate(s,c.node,0,0);return {card:c,d:(p.x-origin.x)*(p.x-origin.x)+(p.y-origin.y)*(p.y-origin.y)};});
    ranked.sort(function(a,b){return a.d-b.d || (a.card.id<b.card.id?-1:a.card.id>b.card.id?1:0);});
    var result=ranked.length?ranked[0].card:null;visiting.delete(card.id);cache.set(card.id,result);return result;
  }
  function matchedCards(s,proof) {
    if (!proof || !Array.isArray(proof.tripleCardIDs) || proof.tripleCardIDs.length!==3 ||
        !finite(proof.peakTrayCount) || !finite(s.capacity) || proof.peakTrayCount>s.capacity || proof.peakTrayCount<1) return [];
    var seen=new Set(), selected=[];
    for(var i=0;i<3;i++) {
      var key=proof.tripleCardIDs[i], c=s.refs.get(key);
      if (typeof key!=='string' || seen.has(key) || !c || !valid(c.node) || typeof c.type!=='string' || (selected.length && c.type!==selected[0].type)) return [];
      seen.add(key); selected.push(c);
    }
    return selected;
  }
  function clearCounts() {
    destroy(countLayer);countLayer=null;countGraphic=null;countRows.clear();countStamp=null;
  }
  function countBounds(s,n) {
    var p=corners(s,n,0),vx={x:p[1].x-p[0].x,y:p[1].y-p[0].y},vy={x:p[3].x-p[0].x,y:p[3].y-p[0].y};
    var cross=vx.x*vy.y-vx.y*vy.x,product=Math.sqrt((vx.x*vx.x+vx.y*vx.y)*(vy.x*vy.x+vy.y*vy.y));
    if(!finite(product)||product<=0||cross<=0||Math.abs(vx.x*vy.x+vx.y*vy.y)>1e-5*product)throw Error('count_transform');
    return bounds(p);
  }
  function countLayout(s) {
    if(!Array.isArray(s.tray)||s.cards.length+s.tray.length>MAX)throw Error('count_cards');
    var byType=new Map(),ids=new Set(),rawIDs=new Set(),obstacles=[],all=s.cards.concat(s.tray);
    all.forEach(function(c,index){
      if(!c||typeof c.id!=='string'||!c.id.length||ids.has(c.id)||s.refs.get(c.id)!==c||!valid(c.node)||
          (index<s.cards.length?['board','reserve'].indexOf(c.zone)<0:c.zone!=='tray')||
          typeof c.type!=='string'||!/^type:(0|[1-9][0-9]{0,4})$/.test(c.type)||Number(c.type.slice(5))>10000||
          !c.frame||(typeof c.frame!=='object'&&typeof c.frame!=='function')||c.frame.isValid===false||
          typeof c.frame.name!=='string'||!c.frame.name.length||c.frame.name.length>256)throw Error('count_identity');
      ids.add(c.id);
      if(c.rawID!==undefined){if(typeof c.rawID!=='string'||!c.rawID.length||rawIDs.has(c.rawID))throw Error('count_identity');rawIDs.add(c.rawID);}
      obstacles.push(countBounds(s,c.node));
      var group=byType.get(c.type);if(!group){group={type:c.type,count:0,card:c};byType.set(c.type,group);}
      group.count++;if(c.id<group.card.id)group.card=c;
    });
    if(!all.length)return {status:'empty',rows:[],total:0};
    var board=countBounds(s,s.board),area=countBounds(s,s.gameLayer);obstacles.push(board);
    if(s.trayNode){
      obstacles.push(countBounds(s,s.trayNode));
      var trayParent=s.trayNode.parent;
      if(trayParent&&trayParent!==s.gameLayer&&trayParent!==s.root&&trayParent!==layer)obstacles.push(countBounds(s,trayParent));
    }
    if(s.reserve)obstacles.push(countBounds(s,s.reserve));
    var rows=Array.from(byType.values()).sort(function(a,b){return Number(a.type.slice(5))-Number(b.type.slice(5));});
    // The reference places separate square tiles in the upper-left margin.
    // Keep that placement for every type count; never move the list over to
    // the right or shorten it when the complete left column cannot fit.
    var height=rows.length*COUNT_ROW+(rows.length-1)*COUNT_GAP,top=area.top-Math.max(8,(area.top-area.bottom)*.1);
    var box={left:board.left-COUNT_BOARD_GAP-COUNT_WIDTH,right:board.left-COUNT_BOARD_GAP,top:top,bottom:top-height};
    if(box.left<area.left+8||box.right>area.right-8||box.bottom<area.bottom+8||
        obstacles.some(function(b){return overlap(b,box);}))throw Error('count_layout');
    rows.forEach(function(row){if(!frameIDs.has(row.card.frame))frameIDs.set(row.card.frame,nextFrame++);row.frameID=frameIDs.get(row.card.frame);});
    return {status:'ready',rows:rows,total:all.length,box:box};
  }
  function makeCountRow(s) {
    var n=node(s.cc,'SDKtools Card Count',countLayer),labelNode=null,label=null;
    var halo=node(s.cc,'SDKtools Count Outline',n),outline=halo.addComponent(s.cc.Sprite);
    halo.y=10.5;halo.color=new s.cc.Color(0,0,0,255);halo.zIndex=0;
    var art=node(s.cc,'SDKtools Count Artwork',n),sprite=art.addComponent(s.cc.Sprite);art.y=10.5;art.zIndex=1;
    if(!sprite||!outline){destroy(n);throw Error('count_sprite');}
    if(typeof s.cc.Label==='function'&&typeof s.cc.LabelOutline==='function'){
      try{
        labelNode=node(s.cc,'SDKtools Count Number',n);label=labelNode.addComponent(s.cc.Label);
        if(!label)throw Error('count_label');
        label.fontSize=16;label.lineHeight=18;label.enableBold=true;label.useSystemFont=true;label.fontFamily='Arial';label.enableWrapText=false;
        var border=labelNode.addComponent(s.cc.LabelOutline);if(!border)throw Error('count_outline');
        border.color=new s.cc.Color(0,0,0,255);border.width=1.5;
        if(s.cc.Label.HorizontalAlign&&finite(s.cc.Label.HorizontalAlign.CENTER))label.horizontalAlign=s.cc.Label.HorizontalAlign.CENTER;
        if(s.cc.Label.VerticalAlign&&finite(s.cc.Label.VerticalAlign.CENTER))label.verticalAlign=s.cc.Label.VerticalAlign.CENTER;
        labelNode.y=-17;labelNode.width=40;labelNode.height=18;labelNode.zIndex=2;labelNode.color=new s.cc.Color(255,255,255,255);
      }catch(_){destroy(labelNode);labelNode=null;label=null;}
    }
    var digits=node(s.cc,'SDKtools Count Digits',n),pen=digits.addComponent(s.cc.Graphics);digits.y=-17;digits.scaleX=digits.scaleY=1.8;digits.zIndex=2;
    if(!pen||typeof pen.clear!=='function'){destroy(n);throw Error('count_digits');}
    return {node:n,sprite:sprite,outline:outline,label:label,pen:pen};
  }
  function renderCounts(s) {
    try{
      var layout=countLayout(s);
      if(layout.status!=='ready'){clearCounts();return {countStatus:layout.status,countedCards:0,countedTypes:0};}
      var box=layout.box,stamp=JSON.stringify([box,layout.rows.map(function(r){return [r.type,r.count,r.card.id,r.frameID];})]);
      if(!valid(countLayer)||countLayer.parent!==layer){clearCounts();countLayer=node(s.cc,'SDKtools Card Counts',layer);countLayer.zIndex=32710;
        countGraphic=countLayer.addComponent(s.cc.Graphics);if(!countGraphic||typeof countGraphic.clear!=='function')throw Error('count_graphic');}
      if(stamp!==countStamp){
        countLayer.x=(box.left+box.right)/2;countLayer.y=(box.bottom+box.top)/2;countLayer.width=COUNT_WIDTH;countLayer.height=box.top-box.bottom;
        countGraphic.clear();
        var wanted=new Set();
        layout.rows.forEach(function(row,index){
          var current=countRows.get(row.type);if(!current||!valid(current.node)){if(current)destroy(current.node);current=makeCountRow(s);countRows.set(row.type,current);}
          current.node.width=COUNT_WIDTH;current.node.height=COUNT_ROW;current.node.y=countLayer.height/2-COUNT_ROW/2-(COUNT_ROW+COUNT_GAP)*index;
          var points=rectangle(0,current.node.y,COUNT_WIDTH-1,COUNT_ROW-1);
          countGraphic.moveTo(points[0].x,points[0].y);for(var p=1;p<points.length;p++)countGraphic.lineTo(points[p].x,points[p].y);countGraphic.close();
          current.sprite.sizeMode=current.outline.sizeMode=s.cc.Sprite.SizeMode.CUSTOM;
          current.sprite.spriteFrame=current.outline.spriteFrame=row.card.frame;
          current.sprite.node.width=28;current.sprite.node.height=31;current.outline.node.width=32;current.outline.node.height=35;
          current.pen.clear();if(current.label)current.label.string=String(row.count);else smallText(s,null,0,0,String(row.count),current.pen);
          wanted.add(row.type);
        });
        if(typeof countGraphic.fill==='function'){countGraphic.fillColor=new s.cc.Color(23,17,13,225);countGraphic.fill();}
        countGraphic.lineWidth=1;countGraphic.strokeColor=new s.cc.Color(46,36,28,255);countGraphic.stroke();
        countRows.forEach(function(row,type){if(!wanted.has(type)){destroy(row.node);countRows.delete(type);}});
        countStamp=stamp;
      }
      return {countStatus:'ready',countedCards:layout.total,countedTypes:layout.rows.length};
    }catch(_){clearCounts();return {countStatus:'unavailable',countedCards:0,countedTypes:0};}
  }
  function render(s,proof,options) {
    var depth=options && finite(options.depth) ? Math.max(1,Math.min(4,Math.round(options.depth))) : 1;
    var summary={status:'unavailable',coveredIcons:0,matchedBorders:0,depthLimit:depth,hiddenByDepth:0,hiddenByLayout:0,labelMode:'none'};
    try {
      if (!s || !Array.isArray(s.cards) || s.cards.length>MAX || !s.refs || typeof s.refs.get!=='function' || !ensure(s)) { clear(); return summary; }
      var ids=new Set(),groups=new Map(),ownerCache=new Map();
      s.cards.forEach(function(c) {
        if(!c || typeof c.id!=='string' || ids.has(c.id))throw Error('cards');ids.add(c.id);
        if((c.zone!=='board'&&c.zone!=='reserve') || (!hidden(c)&&!(c.zone==='reserve'&&c.masked)))return;
        if(c.zone==='reserve'&&(!c.storageVerified||!Number.isInteger(c.occlusionDepth))){summary.hiddenByLayout++;return;}
        if(!Number.isInteger(c.occlusionDepth) || c.occlusionDepth<1 || c.occlusionDepth>MAX)throw Error('depth_unverified');
        if(c.occlusionDepth>depth){summary.hiddenByDepth++;return;}
        if(!c.frame || (typeof c.frame!=='object' && typeof c.frame!=='function'))throw Error('frame');
        var owner=exposedOwner(s,c,ownerCache,new Set());if(!owner){summary.hiddenByLayout++;return;}
        if(!frameIDs.has(c.frame))frameIDs.set(c.frame,nextFrame++);
        var item={card:c,owner:owner,frameID:frameIDs.get(c.frame)};
        if(!groups.has(owner.id))groups.set(owner.id,{owner:owner,items:[],origin:coordinate(s,owner.node,0,0)});
        groups.get(owner.id).items.push(item);
      });
      var sortedGroups=Array.from(groups.values()).sort(function(a,b){return b.origin.y-a.origin.y || a.origin.x-b.origin.x || (a.owner.id<b.owner.id?-1:a.owner.id>b.owner.id?1:0);});
      var placements=[],badges=[],occupied=[];
      sortedGroups.forEach(function(group) {
        group.items.sort(function(a,b){return a.card.occlusionDepth-b.card.occlusionDepth || (a.card.id<b.card.id?-1:a.card.id>b.card.id?1:0);});
        var count=group.items.length,shown=Math.min(PER_STACK,count),n=group.owner.node;
        corners(s,n,0); // Validate size and anchor before making local placements.
        var size=Math.min(1,n.width*.40/WIDTH,n.height*.28/HEIGHT),left=-n.width*n.anchorX,right=n.width*(1-n.anchorX),bottom=-n.height*n.anchorY,top=n.height*(1-n.anchorY);
        if(size<.6){summary.hiddenByLayout+=count;return;}
        summary.hiddenByLayout+=count-shown;
        for(var i=0;i<shown;i++) {
          var item=group.items[i],side=i%2===0?-1:1;
          var slotX=side<0?left+PAD+WIDTH*size/2:right-PAD-WIDTH*size/2;
          var y=i<2?top-PAD-HEIGHT*size/2:bottom+PAD+HEIGHT*size/2,x=slotX+side*4*size;
          var points=localRect(s,n,slotX,y,WIDTH*size,HEIGHT*size),box=bounds(points);
          // Keep each hint on its verified owner. Do not move collisions to a
          // neighboring card or cover the center with an overflow counter.
          if(occupied.some(function(b){return overlap(b,box);})){summary.hiddenByLayout++;continue;}
          occupied.push(box);
          item.key='c:'+item.card.id;item.text=String(item.card.occlusionDepth);item.numberX=-side*14;
          item.local={x:x,y:y};item.position=coordinate(s,n,x,y);item.points=points;
          var px=coordinate(s,n,x+1,y),py=coordinate(s,n,x,y+1),vx={x:px.x-item.position.x,y:px.y-item.position.y},vy={x:py.x-item.position.x,y:py.y-item.position.y};
          item.scaleX=Math.sqrt(vx.x*vx.x+vx.y*vx.y);item.scaleY=Math.sqrt(vy.x*vy.x+vy.y*vy.y);item.angle=Math.atan2(vx.y,vx.x)*180/Math.PI;
          // Avoid inaccurate icon transforms under skew/reflection.
          if(item.scaleX<=0 || item.scaleY<=0 || vx.x*vy.y-vx.y*vy.x<=0 || Math.abs(vx.x*vy.x+vx.y*vy.y)>1e-5*item.scaleX*item.scaleY)throw Error('skew');
          item.scaleX*=size;item.scaleY*=size;
          badges.push(item);placements.push(item);
        }
      });
      var placedByID=new Map();placements.forEach(function(i){placedByID.set(i.card.id,i);});
      var matched=matchedCards(s,proof).filter(function(c){return !(hidden(c)||(c.zone==='reserve'&&c.masked)) || placedByID.has(c.id);});
      var outlines=matched.map(function(c){
        if(hidden(c)){return {points:placedByID.get(c.id).points,hidden:true};}
        return {points:corners(s,c.node,4),hidden:false};
      });
      var modeBefore=labelMode,stamp=JSON.stringify([depth,labelMode,badges.map(function(i){return [i.key,i.text,i.numberX,i.owner.id,i.frameID||0,i.position,i.points,i.scaleX,i.scaleY,i.angle];}),matched.map(function(c){return c.id;}),outlines]);
      if(stamp!==previous) {
        var wanted=new Set();
        badges.forEach(function(item) {
          var existing=icons.get(item.key);
          if(!existing || !valid(existing.node)){if(existing)destroy(existing.node);existing=makeBadge(s,item);icons.set(item.key,existing);}
          existing.sprite.spriteFrame=item.card.frame;existing.sprite.sizeMode=s.cc.Sprite.SizeMode.CUSTOM;
          existing.outline.spriteFrame=item.card.frame;existing.outline.sizeMode=s.cc.Sprite.SizeMode.CUSTOM;
          existing.sprite.node.width=ART_WIDTH;existing.sprite.node.height=ART_HEIGHT;
          existing.outline.node.width=ART_WIDTH+4;existing.outline.node.height=ART_HEIGHT+4;
          existing.node.width=ART_WIDTH;existing.node.height=ART_HEIGHT;existing.node.opacity=255;existing.node.active=true;
          var artPosition=item.position;
          existing.node.x=artPosition.x;existing.node.y=artPosition.y;existing.node.angle=item.angle;existing.node.scaleX=item.scaleX;existing.node.scaleY=item.scaleY;
          if(existing.label){existing.label.string=item.text;existing.labelNode.x=item.numberX;existing.labelNode.y=0;}
          existing.depthGraphic.clear();
          wanted.add(item.key);
        });
        icons.forEach(function(item,key){if(!wanted.has(key)){destroy(item.node);icons.delete(key);}});
        if(labelMode==='vector_digits'){
          icons.forEach(function(item){if(item.labelNode){destroy(item.labelNode);item.labelNode=null;item.label=null;}});
          badges.forEach(function(item){var badge=icons.get(item.key);smallText(s,null,item.numberX,0,item.text,badge.depthGraphic);});
        }
        graphic.clear();
        outlines.forEach(function(outline){
          graphic.lineWidth=outline.hidden?4:7;graphic.strokeColor=new s.cc.Color(35,3,8,245);path(outline.points);graphic.stroke();
          graphic.lineWidth=outline.hidden?1.8:3;graphic.strokeColor=new s.cc.Color(255,24,48,255);path(outline.points);graphic.stroke();
        });
        previous=labelMode===modeBefore?stamp:null;
      }
      var counts=renderCounts(s);summary.countStatus=counts.countStatus;summary.countedCards=counts.countedCards;summary.countedTypes=counts.countedTypes;
      summary.status='ready';summary.coveredIcons=placements.length;summary.matchedBorders=matched.length;summary.labelMode=labelMode;return summary;
    } catch (_) { clear(); return summary; }
  }
  return {render:render,clear:clear,owns:function(n){return n!==null && (typeof n==='object'||typeof n==='function') && owned.has(n);}};
})

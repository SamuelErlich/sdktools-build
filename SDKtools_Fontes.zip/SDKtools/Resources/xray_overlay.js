/* SDKtools V3.1. Read-only card hints from verified loaded SpriteFrames.
 * render(snapshot, provenRoute, {depth:1..5}), clear(), owns(node).
 * occlusionDepth is the adapter's longest original-blocker chain, not render
 * order or a guessed layer number. Only SDK-created nodes are changed.
 */
(function makeXrayOverlay() {
  'use strict';
  var owned=new WeakSet(), layer=null, root=null, host=null, engine=null, graphic=null, icons=new Map(), previous=null;
  var frameIDs=new WeakMap(), nextFrame=1, labelMode='none';
  var WIDTH=58, HEIGHT=40, GAP=6, MAX=512;
  function finite(v) { return typeof v === 'number' && isFinite(v); }
  function valid(n) { return n && n.isValid === true; }
  function destroy(n) {
    if (!n) return;
    try { n.active=false; if (typeof n.removeFromParent === 'function') n.removeFromParent(false); } catch (_) {}
    try { if (typeof n.destroy === 'function') n.destroy(); } catch (_) {}
  }
  function clear() {
    destroy(layer); layer=null; graphic=null; root=null; host=null; engine=null; previous=null; icons.clear(); labelMode='none';
  }
  function node(cc,name,parent) {
    var n=new cc.Node(name); owned.add(n);
    n.anchorX=0.5; n.anchorY=0.5; n.x=0; n.y=0; n.zIndex=32700;
    if (typeof parent.group === 'string' && parent.group.length <= 128) n.group=parent.group;
    // No input listener, Button, collider or input-blocking component is added.
    parent.addChild(n); return n;
  }
  function coordinate(s,n,x,y) {
    if (!valid(n) || typeof n.convertToWorldSpaceAR !== 'function' || typeof layer.convertToNodeSpaceAR !== 'function') throw Error('coordinates');
    var p=layer.convertToNodeSpaceAR(n.convertToWorldSpaceAR(s.cc.v2(x,y)));
    if (!p || !finite(p.x) || !finite(p.y) || Math.abs(p.x)>100000 || Math.abs(p.y)>100000) throw Error('coordinates');
    return {x:p.x,y:p.y};
  }
  function corners(s,n,pad) {
    if (!n || !finite(n.width) || !finite(n.height) || n.width<=0 || n.height<=0 || n.width>10000 || n.height>10000 ||
        !finite(n.anchorX) || !finite(n.anchorY) || n.anchorX<0 || n.anchorX>1 || n.anchorY<0 || n.anchorY>1) throw Error('bounds');
    var left=-n.width*n.anchorX-pad, bottom=-n.height*n.anchorY-pad;
    var right=n.width*(1-n.anchorX)+pad, top=n.height*(1-n.anchorY)+pad;
    return [coordinate(s,n,left,bottom),coordinate(s,n,right,bottom),coordinate(s,n,right,top),coordinate(s,n,left,top)];
  }
  function bounds(points) {
    var b={left:Infinity,right:-Infinity,bottom:Infinity,top:-Infinity};
    points.forEach(function(p){b.left=Math.min(b.left,p.x);b.right=Math.max(b.right,p.x);b.bottom=Math.min(b.bottom,p.y);b.top=Math.max(b.top,p.y);});
    return b;
  }
  function ensure(s) {
    var cc=s.cc;
    if (!cc || typeof cc.Node !== 'function' || typeof cc.Sprite !== 'function' || !cc.Sprite.SizeMode ||
        !finite(cc.Sprite.SizeMode.CUSTOM) || typeof cc.Graphics !== 'function' || typeof cc.Color !== 'function' ||
        typeof cc.v2 !== 'function' || !valid(s.root) || !valid(s.gameLayer) || typeof s.gameLayer.addChild !== 'function') return false;
    if (root !== s.root || host !== s.gameLayer || engine !== cc || !valid(layer) || layer.parent !== s.gameLayer) {
      clear(); root=s.root; host=s.gameLayer; engine=cc; layer=node(cc,'SDKtools Card Hints',host);
      layer.width=0; layer.height=0; graphic=layer.addComponent(cc.Graphics);
      if (!graphic || typeof graphic.clear !== 'function' || typeof graphic.moveTo !== 'function' ||
          typeof graphic.lineTo !== 'function' || typeof graphic.close !== 'function' || typeof graphic.stroke !== 'function') { clear(); return false; }
      labelMode=typeof cc.Label === 'function' ? 'cocos_label' : 'vector_digits';
    }
    return true;
  }
  function path(points) {
    graphic.moveTo(points[0].x,points[0].y);
    for(var i=1;i<points.length;i++) graphic.lineTo(points[i].x,points[i].y);
    graphic.close();
  }
  function rectangle(x,y,w,h) { return [{x:x-w/2,y:y-h/2},{x:x+w/2,y:y-h/2},{x:x+w/2,y:y+h/2},{x:x-w/2,y:y+h/2}]; }
  function plate(cc,p) {
    var dark=new cc.Color(12,19,23,235);
    if (typeof graphic.fill === 'function') { graphic.fillColor=dark; path(rectangle(p.x,p.y,WIDTH,HEIGHT)); graphic.fill(); }
    else {
      // Public Graphics.stroke remains a readable solid backing when fill is
      // absent; no missing font silently removes the depth number.
      graphic.strokeColor=dark; graphic.lineWidth=2;
      for(var y=-HEIGHT/2+1;y<HEIGHT/2;y+=2) { graphic.moveTo(p.x-WIDTH/2,p.y+y); graphic.lineTo(p.x+WIDTH/2,p.y+y); }
      graphic.stroke();
    }
  }
  function digit(cc,p,depth) {
    // Seven-segment fallback is explicit in diagnostics. Digits are depth
    // labels only; card identities always use their actual loaded artwork.
    var segments=[[-4,9,4,9],[4,9,4,0],[4,0,4,-9],[-4,-9,4,-9],[-4,0,-4,-9],[-4,9,-4,0],[-4,0,4,0]];
    var digits={1:[1,2],2:[0,1,6,4,3],3:[0,1,6,2,3],4:[5,6,1,2],5:[0,5,6,2,3]};
    graphic.lineWidth=2.5; graphic.strokeColor=new cc.Color(255,255,255,255);
    digits[depth].forEach(function(index){var line=segments[index];graphic.moveTo(p.x+17+line[0],p.y+line[1]);graphic.lineTo(p.x+17+line[2],p.y+line[3]);});
    graphic.stroke();
  }
  function makeIcon(s,card) {
    var n=node(s.cc,'SDKtools Hidden Card',layer), sprite=n.addComponent(s.cc.Sprite), labelNode=null, label=null;
    if (!sprite) { destroy(n); throw Error('sprite'); }
    if (labelMode === 'cocos_label') {
      try {
        labelNode=node(s.cc,'SDKtools Depth',n); label=labelNode.addComponent(s.cc.Label);
        if (!label) throw Error('label');
        label.fontSize=22; label.lineHeight=26; label.enableBold=true; label.useSystemFont=true; label.fontFamily='Arial'; label.enableWrapText=false;
        if (s.cc.Label.HorizontalAlign && finite(s.cc.Label.HorizontalAlign.CENTER)) label.horizontalAlign=s.cc.Label.HorizontalAlign.CENTER;
        if (s.cc.Label.VerticalAlign && finite(s.cc.Label.VerticalAlign.CENTER)) label.verticalAlign=s.cc.Label.VerticalAlign.CENTER;
        labelNode.color=new s.cc.Color(255,255,255,255); labelNode.width=16; labelNode.height=28; labelNode.x=29; labelNode.y=0;
      } catch (_) { destroy(labelNode); labelNode=null; label=null; labelMode='vector_digits'; }
    }
    return {node:n,sprite:sprite,labelNode:labelNode,label:label};
  }
  function matchedCards(s,proof) {
    if (!proof || !Array.isArray(proof.tripleCardIDs) || proof.tripleCardIDs.length!==3 ||
        !finite(proof.peakTrayCount) || !finite(s.capacity) || proof.peakTrayCount>s.capacity || proof.peakTrayCount<1) return [];
    var seen=new Set(), selected=[];
    for(var i=0;i<3;i++) {
      var key=proof.tripleCardIDs[i], c=s.refs.get(key);
      if (typeof key!=='string' || seen.has(key) || !c || !valid(c.node) || typeof c.type!=='string' || (selected.length && c.type!==selected[0].type)) return [];
      seen.add(key); selected.push(c);
    }
    return selected;
  }
  function render(s,proof,options) {
    var depth=options && finite(options.depth) ? Math.max(1,Math.min(5,Math.round(options.depth))) : 1;
    var summary={status:'unavailable',coveredIcons:0,matchedBorders:0,depthLimit:depth,hiddenByDepth:0,hiddenByLayout:0,labelMode:'none'};
    try {
      if (!s || !Array.isArray(s.cards) || s.cards.length>MAX || !s.refs || typeof s.refs.get!=='function' || !ensure(s)) { clear(); return summary; }
      var covered=[], ids=new Set();
      s.cards.forEach(function(c) {
        if (!c || typeof c.id!=='string' || ids.has(c.id)) throw Error('cards'); ids.add(c.id);
        if (c.zone!=='board' || c.masked!==true) return;
        if (!Number.isInteger(c.occlusionDepth) || c.occlusionDepth<1 || c.occlusionDepth>MAX) throw Error('depth_unverified');
        if (c.occlusionDepth>depth) { summary.hiddenByDepth++; return; }
        if (!c.frame || (typeof c.frame!=='object' && typeof c.frame!=='function')) throw Error('frame');
        var p=coordinate(s,c.node,-20,27);
        if (!frameIDs.has(c.frame)) frameIDs.set(c.frame,nextFrame++);
        covered.push({card:c,origin:p,frameID:frameIDs.get(c.frame)});
      });
      covered.sort(function(a,b){return a.card.occlusionDepth-b.card.occlusionDepth || b.origin.y-a.origin.y || a.origin.x-b.origin.x || (a.card.id<b.card.id?-1:a.card.id>b.card.id?1:0);});
      // One deterministic non-overlapping grid across the actual transformed
      // board. A badge searches at most 49 nearby cells; crowded leftovers are
      // reported, never stacked invisibly on top of another icon/number.
      var area=s.board ? bounds(corners(s,s.board,42)) : bounds([].concat.apply([],s.cards.filter(function(c){return c.zone==='board';}).map(function(c){return corners(s,c.node,0);}))), placements=[], occupied=new Set();
      var cols=Math.floor((area.right-area.left+GAP)/(WIDTH+GAP)), rows=Math.floor((area.top-area.bottom+GAP)/(HEIGHT+GAP));
      var offsets=[];
      for(var dy=-3;dy<=3;dy++)for(var dx=-3;dx<=3;dx++)offsets.push({x:dx,y:dy,d:dx*dx+dy*dy});
      offsets.sort(function(a,b){return a.d-b.d || b.y-a.y || a.x-b.x;});
      covered.forEach(function(item) {
        var cx=Math.round((item.origin.x-area.left-WIDTH/2)/(WIDTH+GAP)), cy=Math.round((item.origin.y-area.bottom-HEIGHT/2)/(HEIGHT+GAP)), placed=null;
        for(var i=0;i<offsets.length;i++) {
          var x=cx+offsets[i].x,y=cy+offsets[i].y,key=x+':'+y;
          if(x<0 || x>=cols || y<0 || y>=rows || occupied.has(key))continue;
          placed={x:area.left+WIDTH/2+x*(WIDTH+GAP),y:area.bottom+HEIGHT/2+y*(HEIGHT+GAP)};occupied.add(key);break;
        }
        if(placed) { item.position=placed; placements.push(item); } else summary.hiddenByLayout++;
      });
      var placedByID=new Map(); placements.forEach(function(i){placedByID.set(i.card.id,i);});
      var matched=matchedCards(s,proof).filter(function(c){return c.zone!=='board' || c.masked!==true || placedByID.has(c.id);});
      var outlines=matched.map(function(c){
        // A hidden recommendation belongs to its visible badge, never a large
        // rectangle over the exposed card above it. The depth cutoff applies
        // to recommendations as well as icons.
        if(c.zone==='board' && c.masked===true) { var p=placedByID.get(c.id).position; return {points:rectangle(p.x,p.y,WIDTH-1,HEIGHT-1),hidden:true}; }
        return {points:corners(s,c.node,4),hidden:false};
      });
      var modeBefore=labelMode, stamp=JSON.stringify([depth,labelMode,placements.map(function(i){return [i.card.id,i.card.occlusionDepth,i.frameID,i.origin,i.position];}),matched.map(function(c){return c.id;}),outlines]);
      if(stamp!==previous) {
        var wanted=new Set();
        placements.forEach(function(item) {
          var card=item.card, existing=icons.get(card.id);
          if(!existing || !valid(existing.node)) { if(existing)destroy(existing.node);existing=makeIcon(s,card);icons.set(card.id,existing); }
          existing.sprite.spriteFrame=card.frame; existing.sprite.sizeMode=s.cc.Sprite.SizeMode.CUSTOM;
          existing.node.width=28;existing.node.height=31.5;existing.node.opacity=255;existing.node.active=true;
          existing.node.x=item.position.x-12;existing.node.y=item.position.y;
          if(existing.label)existing.label.string=String(card.occlusionDepth);
          wanted.add(card.id);
        });
        icons.forEach(function(item,key){if(!wanted.has(key)){destroy(item.node);icons.delete(key);}});
        if(labelMode==='vector_digits')icons.forEach(function(item){if(item.labelNode){destroy(item.labelNode);item.labelNode=null;item.label=null;}});
        graphic.clear();
        placements.forEach(function(item) {
          var p=item.position, o=item.origin;
          if(Math.abs(p.x-o.x)>32 || Math.abs(p.y-o.y)>23) {
            graphic.lineWidth=2;graphic.strokeColor=new s.cc.Color(12,19,23,220);graphic.moveTo(o.x,o.y);graphic.lineTo(p.x,p.y);graphic.stroke();
          }
          plate(s.cc,p);
          var icon=icons.get(item.card.id);if(!icon.label)digit(s.cc,p,item.card.occlusionDepth);
        });
        outlines.forEach(function(outline) {
          graphic.lineWidth=outline.hidden?7:9;graphic.strokeColor=new s.cc.Color(5,24,12,245);path(outline.points);graphic.stroke();
          graphic.lineWidth=outline.hidden?3:4;graphic.strokeColor=new s.cc.Color(50,255,115,255);path(outline.points);graphic.stroke();
        });
        // A failed optional Label switches to explicit vector digits. Reuse all
        // nodes on the following tick rather than rebuilding the overlay.
        previous=labelMode===modeBefore?stamp:null;
      }
      summary.status='ready';summary.coveredIcons=placements.length;summary.matchedBorders=matched.length;summary.labelMode=labelMode;return summary;
    } catch (_) { clear(); return summary; }
  }
  return {render:render,clear:clear,owns:function(n){return n!==null && (typeof n==='object'||typeof n==='function') && owned.has(n);}};
})

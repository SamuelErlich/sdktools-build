/* Read-only local-board forecast. Never a measured player/server win rate.
 * All legal choices have positive weight: complete trio 6, pair 3, other 1.
 * Small graphs: exact weighted outcome probability. Large graphs: seeded
 * rollouts, resumed between observations. Sampling cannot prove 0% or 100%.
 * Removing a blocker exposes a normal card; unknown/special rules invalidate
 * the model. No powers, shared warehouse, future cards or allies are assumed.
 */
(function makeAlpacaWinAnalysis() {
  'use strict';
  var session=null, last={version:1,status:'unavailable',reason:'awaiting_stability'};
  var MAX_STATES=2048, MAX_SAMPLES=128, MAX_WORK=256, BUDGET_MS=2;
  function unavailable(reason){last={version:1,status:'unavailable',reason:reason};return last;}
  function text(v){return typeof v==='string'&&v.length>0&&v.length<=128&&!/^(unknown|unreadable|special)$/i.test(v);}
  function now(){return typeof performance==='object'&&typeof performance.now==='function'?performance.now():Date.now();}
  function prepare(s){
    if(!s||!Array.isArray(s.cards)||!Array.isArray(s.tray)||s.capacity!==7||s.cards.length+s.tray.length>512||s.tray.length>7)throw Error('invalid_snapshot');
    var cards=[],types=[],typeIDs=new Map(),ids=new Map(),allIDs=new Set(),edges=0;
    function typeID(t){if(!text(t))throw Error('unknown_rules');if(!typeIDs.has(t)){typeIDs.set(t,types.length);types.push(t);}return typeIDs.get(t);}
    s.cards.forEach(function(c,i){
      if(!c||!text(c.id)||allIDs.has(c.id)||!['board','reserve'].includes(c.zone)||!Array.isArray(c.blockedBy)||c.blockedBy.length>64||typeof c.available!=='boolean')throw Error('invalid_snapshot');
      if(c.selectable!==true||c.metadata&&c.metadata.specialType!==0||c.locked===true)throw Error('unknown_rules');
      if(c.zone==='reserve'&&c.storageVerified!==true)throw Error('unknown_rules');
      allIDs.add(c.id);ids.set(c.id,i);edges+=c.blockedBy.length;
      cards.push({type:typeID(c.type),zone:c.zone,available:c.available,links:c.blockedBy.slice(),blockers:[]});
    });
    var tray=s.tray.map(function(c){if(!c||!text(c.id)||allIDs.has(c.id)||c.metadata&&c.metadata.specialType!==0)throw Error('invalid_snapshot');allIDs.add(c.id);return typeID(c.type);});
    if(edges>8192)throw Error('invalid_snapshot');
    var counts=new Array(types.length).fill(0),totals=counts.slice(),indegree=new Array(cards.length).fill(0),covers=cards.map(function(){return [];});
    tray.forEach(function(t){if(++counts[t]>=3)throw Error('unsettled_tray');totals[t]++;});
    cards.forEach(function(c,i){
      var seen=new Set();totals[c.type]++;
      c.links.forEach(function(id){var b=ids.get(id);if(b===undefined||b===i||seen.has(b)||cards[b].zone!==c.zone)throw Error('invalid_snapshot');seen.add(b);c.blockers.push(b);covers[b].push(i);indegree[i]++;});
      if(c.available&&c.blockers.length)throw Error('invalid_snapshot');
      if(!c.available&&!c.blockers.length)throw Error('controls_unavailable');
    });
    var queue=[];indegree.forEach(function(n,i){if(!n)queue.push(i);});
    for(var q=0;q<queue.length;q++)covers[queue[q]].forEach(function(i){if(--indegree[i]===0)queue.push(i);});
    if(queue.length!==cards.length)throw Error('invalid_snapshot');
    var initial={bits:new Uint32Array(Math.ceil(cards.length/32)),counts:counts,occupancy:tray.length,captures:0};
    return {cards:cards,capacity:7,total:cards.length+tray.length,initial:initial,impossible:totals.some(function(n){return n%3!==0;})};
  }
  function removed(state,i){return (state.bits[i>>>5]&(1<<(i&31)))!==0;}
  function options(model,state){
    var choices=[],exposed=0,counts=state.counts.slice();
    if(state.occupancy>=model.capacity)return {choices:[],exposed:0,pairs:0};
    model.cards.forEach(function(c,i){
      if(removed(state,i)||c.blockers.some(function(b){return !removed(state,b);}))return;
      exposed++;counts[c.type]++;
      if(state.counts[c.type]===2||state.occupancy+1<model.capacity)choices.push({index:i,weight:state.counts[c.type]===2?6:state.counts[c.type]===1?3:1});
    });
    return {choices:choices,exposed:exposed,pairs:counts.reduce(function(n,c){return n+Math.floor(c/2);},0)};
  }
  function advance(model,state,i){
    var bits=state.bits.slice(),counts=state.counts.slice(),t=model.cards[i].type,match=counts[t]===2;
    bits[i>>>5]|=1<<(i&31);counts[t]=match?0:counts[t]+1;
    return {bits:bits,counts:counts,occupancy:state.occupancy+1-(match?3:0),captures:state.captures+1};
  }
  function key(state){return Array.prototype.join.call(state.bits,'.');}
  function terminal(model,state,opts){
    if(opts.choices.length)return null;
    var remaining=model.cards.length-state.captures+state.occupancy;
    return {p:remaining===0?1:0,cleared:model.total-remaining,captures:state.captures,remaining:remaining,tray:state.occupancy,
      stop:remaining===0?'clear':opts.exposed||state.occupancy>=model.capacity?'capacity':state.captures===model.cards.length?'unmatched_cards':'no_accessible_cards'};
  }
  function best(a,b){return !a||b.cleared>a.cleared||b.cleared===a.cleared&&b.captures>a.captures?b:a;}
  function frame(model,state){var opts=options(model,state);return {state:state,opts:opts,cursor:0,sum:0,weight:0,best:null,leaf:terminal(model,state,opts)};}
  function random(){var x=session.seed;x^=x<<13;x^=x>>>17;x^=x<<5;session.seed=x>>>0;return session.seed/4294967296;}
  function report(){
    var m=session.model,b=session.best,p=session.exact?session.exact.p*100:session.samples?(session.wins+0.5)/(session.samples+1)*100:null;
    if(session.impossible)p=0;
    last={version:1,status:session.done?(session.exact?'exact':'estimated'):'searching',
      reason:m.impossible?'unbalanced_types':session.exact?'all_routes_evaluated':session.done?'sample_limit':'analyzing',
      winPercent:p,impossible:session.impossible,searchComplete:!!session.exact,samples:session.samples,wins:session.wins,states:session.states,
      totalCards:m.total,exposedCards:session.rootOptions.exposed,visiblePairs:session.rootOptions.pairs,
      bestClearedCards:b?b.cleared:0,bestCaptures:b?b.captures:0,remainingAtStop:b?b.remaining:m.total,stopTrayCount:b?b.tray:m.initial.occupancy,
      stopReason:b?b.stop:'searching',model:'loaded_cards_no_powers'};
    return last;
  }
  function observe(s,ready){
    if(!ready)return unavailable('awaiting_stability');
    try{
      // Signature includes scene, phase revision and every observed card/control.
      // Never reuse an outcome after a refresh or a card/room/round change.
      function row(c){return [c.id,c.type,c.zone,c.available,c.selectable,c.locked,c.blockedBy,c.storageVerified,c.metadata&&c.metadata.specialType];}
      var fingerprint=JSON.stringify([s.signature,s.capacity,s.cards.map(row),s.tray.map(row)]);
      if(!session||session.fingerprint!==fingerprint){
        var model=prepare(s),seed=2166136261;
        for(var h=0;h<fingerprint.length;h++)seed=Math.imul(seed^fingerprint.charCodeAt(h),16777619)>>>0;
        session={fingerprint:fingerprint,model:model,seed:seed||1,rootOptions:options(model,model.initial),
          mode:model.cards.length<=22&&!model.impossible?'exact':'sample',memo:new Map(),stack:[],states:0,samples:0,wins:0,best:null,exact:null,done:false,impossible:model.impossible,rollout:null};
        var root=frame(model,model.initial);
        if(root.leaf){session.exact=root.leaf;session.best=root.leaf;session.impossible=root.leaf.p===0;session.done=true;}
        else if(session.mode==='exact')session.stack.push(root);
      }
      if(session.done)return report();
      var start=now(),work=0,m=session.model;
      while(!session.done&&work++<MAX_WORK&&now()-start<BUDGET_MS){
        if(session.mode==='exact'){
          var f=session.stack[session.stack.length-1],value=f.leaf;
          if(!value&&f.cursor===f.opts.choices.length)value=Object.assign({},f.best,{p:f.sum/f.weight});
          if(value){
            session.memo.set(key(f.state),value);session.best=best(session.best,value);session.stack.pop();
            if(!session.stack.length){session.exact=value;session.impossible=value.p===0;session.done=true;}
            continue;
          }
          var choice=f.opts.choices[f.cursor],next=advance(m,f.state,choice.index),cached=session.memo.get(key(next));
          if(cached){f.sum+=cached.p*choice.weight;f.weight+=choice.weight;f.best=best(f.best,cached);f.cursor++;}
          else if(session.states>=MAX_STATES){session.mode='sample';session.memo.clear();session.stack=[];}
          else{session.states++;session.stack.push(frame(m,next));}
        }else{
          if(!session.rollout)session.rollout=m.initial;
          var opts=options(m,session.rollout),leaf=terminal(m,session.rollout,opts);
          if(leaf){
            session.samples++;session.wins+=leaf.p;session.best=best(session.best,leaf);session.rollout=null;
            if(session.samples>=MAX_SAMPLES)session.done=true;
          }else{
            var weight=opts.choices.reduce(function(n,c){return n+c.weight;},0),draw=random()*weight,pick=opts.choices[opts.choices.length-1];
            for(var c=0;c<opts.choices.length;c++){draw-=opts.choices[c].weight;if(draw<0){pick=opts.choices[c];break;}}
            session.rollout=advance(m,session.rollout,pick.index);
          }
        }
      }
      return report();
    }catch(_){session=null;return unavailable('unsupported_snapshot');}
  }
  return {fork:makeAlpacaWinAnalysis,observe:observe,current:function(){return last;},invalidate:function(){unavailable('observation_interrupted');}};
})

/* SOLO whole-phase adapter. Pure observation and proof translation only.
 * The legacy function remains available for team/old callers. No game action,
 * timer, hook, purchase or stock write belongs in this controller. */
(function makeAlpacaGlobalRuntime(base, core) {
  'use strict';
  var serial=0, bindingSerial=0, current=null, certificate=null, carry=null, policy=false;
  var last={version:1,status:'blocked',reason:'awaiting_snapshot',totalCards:0,plannedCleared:0,remaining:0,states:0,powerUses:0,complete:false,optimal:false,scope:'current_phase'};
  function own(o,k){var d=o&&(typeof o==='object'||typeof o==='function')&&Object.getOwnPropertyDescriptor(o,k);
    if(d&&!Object.prototype.hasOwnProperty.call(d,'value'))throw Error('invalid_snapshot');return d?d.value:undefined;}
  function integer(v,l,h){return Number.isInteger(v)&&v>=l&&v<=h;}
  function localID(v){return typeof v==='string'&&/^c[1-9][0-9]{0,14}$/.test(v);}
  function face(v){return typeof v==='string'&&/^type:(?:0|[1-9][0-9]{0,4})$/.test(v)&&Number(v.slice(5))<=10000;}
  function identity(v){return typeof v==='string'&&v.length>0&&v.length<=128||integer(v,1,9007199254740991);}
  function finite(v){return typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<=10000;}
  function copy(v){return JSON.parse(JSON.stringify(v));}
  function fail(reason){throw Error(reason);}
  function equal(a,b){return a.length===b.length&&a.every(function(v,i){return v===b[i];});}
  function applies(s){try{return own(own(own(s,'playState'),'store'),'mode')===1;}catch(_){return false;}}
  function context(s,p){
    var play=own(s,'playState'),store=own(play,'store'),uid=own(play,'uid'),rid=own(play,'rid'),start=own(play,'start');
    if(!play||!store||!identity(uid)||!identity(rid)||!integer(start,1,9007199254740991)||own(store,'mode')!==1||
      own(store,'uid')!==uid||own(store,'rid')!==rid||own(store,'start_time')!==start)fail('context_changed');
    var keys=['state','isWatcher','isHotTiming','isAddingCommonBlock','isUsingPenetrateProp','isCanTouchBlock'],expected=[2,false,false,false,false,true];
    keys.forEach(function(k,i){if(own(store,k)!==expected[i])fail('context_changed');});
    var gamers=own(store,'gamers');if(!Array.isArray(gamers)||gamers.length>512||gamers.filter(function(g){return own(g,'uid')===uid&&own(g,'state')===1;}).length!==1)fail('context_changed');
    if(!s.root||!s.board||!s.reserve||!s.trayNode||!play.game||!play.layer)fail('context_changed');
    return [s.root,s.board,s.reserve,s.trayNode,store,play.game,play.layer,uid,rid,start,p.scope,policy];
  }
  function normalize(s,options){
    policy=!!options&&options.powersEnabled===true;
    if(!applies(s))fail('not_solo');
    var p=own(s,'phaseSnapshot'),rules=own(p,'rules');
    if(!p||own(p,'schema')!=='SDKtools.AlpacaPhaseSnapshot.v1'||own(p,'complete')!==true||own(p,'mode')!==1||
      !integer(own(p,'scope'),1,1000000000)||!integer(own(p,'revision'),1,1000000000))fail('snapshot_unavailable');
    if(own(p,'capacity')!==7||own(p,'matchSize')!==3||s.capacity!==7||!rules||own(rules,'allRecognized')!==true||
      own(rules,'modeRecognized')!==true||own(rules,'ordinaryMatch')!=='triple'||own(rules,'trayPolicy')!=='group_insert_then_match'||
      own(rules,'ordinaryGeometry')!=='alpaca_2_4_4'||own(rules,'reservePolicy')!=='verified_storage_columns'||
      !Array.isArray(own(rules,'unknownSpecialTypes'))||rules.unknownSpecialTypes.length!==0)fail('unsupported_rules');
    if(!Array.isArray(p.cards)||!Array.isArray(p.tray)||!Array.isArray(s.cards)||!Array.isArray(s.tray)||!s.refs||typeof s.refs.get!=='function'||
      p.cards.length+p.tray.length>512||p.cards.length!==s.cards.length||p.tray.length!==s.tray.length||p.tray.length>=7||
      !Array.isArray(p.sharedSlots)||p.sharedSlots.length||typeof s.signature!=='string'||!s.signature||s.signature.length>262144)fail('invalid_snapshot');
    var bound=context(s,p),ids=new Set(),rawIDs=new Set(),live=new Map(),stockTypes=new Set(),cards=[],tray=[],inventory=[],edgeCount=0,census=new Map();
    ['pile_blocks','hand_blocks','storage_blocks'].forEach(function(key,z){var list=own(bound[4],key);if(!Array.isArray(list)||list.length>512)fail('invalid_snapshot');
      var flat=[];list.forEach(function(row){if(z===2&&Array.isArray(row)){if(row.length>512)fail('invalid_snapshot');flat=flat.concat(row);}else flat.push(row);if(flat.length>512)fail('invalid_snapshot');});
      flat.forEach(function(row){if(z===2&&row===null)return;var id=own(row,'id');if(!identity(id)||census.has(id)||own(row,'state')!==z||!integer(own(row,'type'),0,10000))fail('invalid_snapshot');census.set(id,row);});
    });
    s.cards.concat(s.tray).forEach(function(c){if(!c||!localID(c.id)||live.has(c.id)||s.refs.get(c.id)!==c)fail('invalid_snapshot');live.set(c.id,c);});
    p.cards.concat(p.tray).forEach(function(c,index){
      var id=own(c,'id'),type=own(c,'type'),zone=own(c,'zone'),v=live.get(id),m=v&&own(v,'metadata'),links=own(c,'blockedBy');
      if(!localID(id)||ids.has(id)||!face(type)||!v||!m||v.type!==type||v.zone!==zone||own(c,'specialType')!==0||own(c,'lock')!==0||
        own(m,'specialType')!==0||own(m,'lock')!==0||own(m,'ruleIssue')||own(c,'selectable')!==true||v.selectable!==true||
        !Array.isArray(links)||links.length>64||typeof own(c,'available')!=='boolean'||v.available!==c.available||
        typeof own(c,'canTouch')!=='boolean'||own(m,'canTouch')!==c.canTouch||!Array.isArray(v.blockedBy)||
        JSON.stringify(links.slice().sort())!==JSON.stringify(v.blockedBy.slice().sort()))fail('invalid_snapshot');
      ids.add(id);edgeCount+=links.length;if(edgeCount>8192)fail('invalid_snapshot');
      var source=census.get(v.rawID),info=own(own(m,'block'),'blockInfo'),z=['board','tray','reserve'].indexOf(zone);
      var sourceSpecial=own(source,'special_info'),infoSpecial=own(info,'special_info');
      if(!source||!info||rawIDs.has(v.rawID)||own(info,'id')!==v.rawID||own(source,'type')!==Number(type.slice(5))||own(info,'type')!==own(source,'type')||
        sourceSpecial&&own(sourceSpecial,'type')!==0||infoSpecial&&own(infoSpecial,'type')!==0||
        own(source,'state')!==z||own(info,'state')!==z)fail('invalid_snapshot');
      rawIDs.add(v.rawID);
      var item={id:id,type:type,zone:zone,blockedBy:links.slice(),available:c.available,selectable:true,specialType:0,lock:0};
      if(index>=p.cards.length){if(zone!=='tray'||c.order!==index-p.cards.length||s.tray[index-p.cards.length]!==v||links.length)fail('invalid_snapshot');tray.push(item);}
      else{
        if(zone!=='board'&&zone!=='reserve')fail('invalid_snapshot');
        if(zone==='board'){
          if(!integer(c.layer,0,10000)||!finite(c.row)||!finite(c.col)||c.layer!==v.layer||c.row!==v.gridRow||c.col!==v.gridCol)fail('invalid_snapshot');
          item.layer=c.layer;item.row=c.row;item.col=c.col;
        }else{
          if(c.storageVerified!==true||v.storageVerified!==true||!integer(c.storageLayer,0,511)||!integer(c.storageIndex,0,2)||
            c.storageLayer!==v.storageLayer||c.storageIndex!==v.storageIndex)fail('unverified_reserve');
          item.storageVerified=true;item.storageLayer=c.storageLayer;item.storageIndex=c.storageIndex;
        }
        cards.push(item);
      }
    });
    if(ids.size!==live.size||s.refs.size!==ids.size||census.size!==ids.size)fail('invalid_snapshot');
    var actual=own(bound[4],'props_blocks'),snapshotStock=own(p,'inventory');
    if(!Array.isArray(actual)||!Array.isArray(snapshotStock)||actual.length!==snapshotStock.length||actual.length>6)fail('invalid_inventory');
    var stockIDs=new Set();snapshotStock.forEach(function(row){
      var t=own(row,'type'),n=own(row,'count');
      if(!integer(t,0,5)||!integer(n,0,1000000)||own(row,'recognized')!==true||stockTypes.has(t))fail('invalid_inventory');
      stockTypes.add(t);var found=actual.filter(function(v){return own(v,'type')===t;});
      if(found.length!==1||own(found[0],'count')!==n||!identity(own(found[0],'id'))||stockIDs.has(own(found[0],'id')))fail('invalid_inventory');
      stockIDs.add(own(found[0],'id'));inventory.push({type:t,count:policy?n:0});
    });
    inventory.sort(function(a,b){return a.type-b.type;});
    var input={mode:1,capacity:7,matchSize:3,snapshotVerified:true,cards:cards,tray:tray,inventory:inventory};
    if(policy&&inventory.some(function(v){return v.type===1&&v.count>0;})){
      var lastBlock=own(bound[4],'last_block'),lastID=own(lastBlock,'id'),state=own(lastBlock,'state'),origin=s.tray.find(function(c){return c.rawID===lastID;});
      if(origin&&state===0){
        var info=own(own(origin.metadata,'block'),'blockInfo'),layer=own(info,'layer'),parts=typeof lastID==='string'?lastID.split('-'):[],row=Number(parts[1]),col=Number(parts[2]);
        if(own(info,'id')!==lastID||own(info,'state')!==1||!integer(layer,0,10000)||parts.length<3||!parts[1]||!parts[2]||!finite(row)||!finite(col))fail('invalid_withdraw');
        var neighbors=cards.filter(function(c){return c.zone==='board'&&Math.abs(c.row-row)<16&&Math.abs(c.col-col)<20;});
        input.withdraw={verified:true,id:origin.id,zone:'board',blockedBy:neighbors.filter(function(c){return c.layer>layer;}).map(function(c){return c.id;}),
          covers:neighbors.filter(function(c){return c.layer<layer;}).map(function(c){return c.id;})};
      }
    }
    var key=JSON.stringify([s.signature,p.scope,p.revision,input,policy]);
    if(!current||current.key!==key||!equal(current.binding,bound)){
      if(++serial>1000000000)fail('context_changed');input.signature='SDKtools.global.phase.'+serial;
      current={key:key,input:input,binding:bound,revision:p.revision,signature:s.signature};
    }
    return current;
  }
  function reasonOf(result){
    if(result&&result.complete===true)return 'whole_route_proved';
    if(result&&result.status==='searching')return 'searching_whole_board';
    if(result&&result.reason==='state_limit_best_observed')return 'state_limit_best_known';
    if(result&&result.status==='best')return 'best_known_route';return 'solver_unavailable';
  }
  function diagnostic(result,proof){
    var total=proof&&proof.totalCards||0;
    last={version:1,status:result&&result.status==='searching'?'searching':proof&&proof.complete?'proved':proof&&proof.cleared>0?'partial':'blocked',
      reason:reasonOf(result),totalCards:total,plannedCleared:proof&&proof.cleared||0,remaining:proof?proof.remaining:total,
      states:result&&integer(result.states,0,1000000)?result.states:0,powerUses:proof&&proof.powerUses||0,
      complete:!!proof&&proof.complete===true,optimal:!!result&&result.optimal===true,scope:'current_phase'};
  }
  function blocked(reason){certificate=null;last={version:1,status:'blocked',reason:reason,totalCards:0,plannedCleared:0,remaining:0,states:0,powerUses:0,complete:false,optimal:false,scope:'current_phase'};
    return {status:'blocked',reason:reason==='board_clear'?'board_clear':'invalid_state',cardID:null,actions:[],sequence:[],proofKind:null,stats:{goal:'whole_board',completePlan:false,completeSearch:false}};}
  function stats(result,proof){return {goal:'whole_board',searchMode:'global_solo',expanded:result.states||0,generated:result.states||0,slices:result.slices||0,
    depth:result.route.length,residualCards:proof.remaining,completePlan:proof.complete,completeSolution:proof.complete,completeSearch:result.exhaustive===true,
    continuation:proof.complete?'clear':'unknown'};}
  function claims(proof,result){return {complete:proof.complete,cleared:proof.cleared,totalCards:proof.totalCards,remaining:proof.remaining,powerUses:proof.powerUses,optimal:result.optimal===true};}
  function prefix(input,route){
    var byID=new Map(input.cards.map(function(c){return [c.id,c];})),hand=input.tray.map(function(c){return {id:c.id,type:c.type};}),sequence=[],trio=[],matched=null,peak=hand.length;
    for(var i=0;i<route.length&&route[i].kind==='card';i++){
      var card=byID.get(route[i].id);if(!card)fail('replay_rejected');sequence.push(card.id);peak=Math.max(peak,hand.length+1);
      hand.push({id:card.id,type:card.type});var same=hand.filter(function(c){return c.type===card.type;});
      if(same.length===3){trio=same.map(function(c){return c.id;});matched=card.type;break;}
    }
    return {sequence:sequence,actions:sequence.slice(),cardID:sequence[0]||null,tripleCardIDs:trio,matchedType:matched,peakTrayCount:peak,fastBatch:false};
  }
  function issue(state,result,proof){
    var route=copy(result.route),claim=claims(proof,result),token=++bindingSerial;if(token>1000000000)fail('context_changed');
    certificate={token:token,key:state.key,binding:state.binding.slice(),revision:state.revision,route:route,claim:claim,result:result};
    diagnostic(result,proof);
    if(!route.length){certificate=null;last.reason=proof.complete?'board_clear':'no_complete_route';return {status:'blocked',reason:proof.complete?'board_clear':'no_complete_solution',cardID:null,actions:[],sequence:[],proofKind:null,stats:stats(result,proof)};}
    var shared={proofKind:'global_solo',globalBinding:token,globalRoute:copy(route),globalClaim:copy(claim),stats:stats(result,proof)};
    if(route[0].kind==='power')return Object.assign(shared,{status:'power',reason:'global_power_prescribed',action:copy(route[0]),cardID:null,sequence:[],actions:[],tripleCardIDs:[],matchedType:null});
    return Object.assign(shared,prefix(state.input,route),{status:'move',reason:proof.complete?'whole_route_proved':'best_known_route'});
  }
  function replay(state,route,claim){
    if(!core||typeof core.replay!=='function')fail('solver_unavailable');var proof=core.replay(state.input,route);
    if(!proof||proof.valid!==true||claim&&(proof.complete!==claim.complete||proof.cleared!==claim.cleared||proof.totalCards!==claim.totalCards||
      proof.remaining!==claim.remaining||proof.powerUses!==claim.powerUses))fail('replay_rejected');return proof;
  }
  function plan(s,options){
    try{
      var state=normalize(s,options);if(!core||typeof core.plan!=='function')fail('solver_unavailable');
      if(carry){var old=carry;carry=null;
        if(equal(old.binding,state.binding)&&state.revision>=old.revision){
          var resumed;try{resumed=replay(state,old.route);}catch(_){}
          if(resumed&&resumed.complete){var resumedResult={status:'solved',reason:'whole_route_replayed',route:old.route,complete:true,optimal:true,states:0,slices:0,exhaustive:false};return issue(state,resumedResult,resumed);}
        }
      }
      var result=core.plan(state.input);certificate=null;
      if(result&&result.status==='searching'){
        diagnostic(result,{totalCards:state.input.cards.length+state.input.tray.length,remaining:state.input.cards.length+state.input.tray.length,cleared:0,powerUses:0,complete:false});
        return {status:'searching',reason:'search_in_progress',cardID:null,actions:[],sequence:[],proofKind:null,stats:{goal:'whole_board',expanded:result.states||0,generated:result.states||0,slices:result.slices||0,completePlan:false,completeSearch:false}};
      }
      if(!result||['solved','best'].indexOf(result.status)<0||!Array.isArray(result.route))return blocked('solver_unavailable');
      var proof=replay(state,result.route,{complete:result.complete===true,cleared:result.bestCleared,totalCards:result.totalCards,remaining:result.remaining,powerUses:result.powerUses});
      if(!proof.complete&&(proof.cleared===0||proof.firstTrioIndex===null)){
        diagnostic(result,proof);last.status='blocked';last.reason='no_complete_route';return {status:'blocked',reason:'no_complete_solution',cardID:null,actions:[],sequence:[],proofKind:null,stats:stats(result,proof)};
      }
      return issue(state,result,proof);
    }catch(e){carry=null;return blocked(['snapshot_unavailable','unsupported_rules','not_solo','invalid_snapshot','invalid_inventory','unverified_reserve','context_changed','invalid_withdraw','replay_rejected','solver_unavailable'].indexOf(e&&e.message)>=0?e.message:'invalid_snapshot');}
  }
  function validate(s,decision,power){
    try{
      var state=normalize(s,{powersEnabled:policy}),cert=certificate;
      if(!cert||!decision||decision.proofKind!=='global_solo'||decision.globalBinding!==cert.token||state.key!==cert.key||!equal(state.binding,cert.binding)||
        JSON.stringify(decision.globalRoute)!==JSON.stringify(cert.route)||JSON.stringify(decision.globalClaim)!==JSON.stringify(cert.claim))return null;
      var proof=replay(state,cert.route,cert.claim),first=cert.route[0];if(!first)return null;
      if(power){if(first.kind!=='power'||decision.status!=='power'||JSON.stringify(decision.action)!==JSON.stringify(first))return null;
        return {type:first.powerType,targetID:first.id,signature:s.signature};}
      if(first.kind!=='card')return null;var expected=prefix(state.input,cert.route);
      if(JSON.stringify(decision.sequence)!==JSON.stringify(expected.sequence)||JSON.stringify(decision.actions)!==JSON.stringify(expected.actions)||
        decision.cardID!==expected.cardID||decision.matchedType!==expected.matchedType||JSON.stringify(decision.tripleCardIDs)!==JSON.stringify(expected.tripleCardIDs))return null;
      return Object.assign({},copy(decision),expected,{residualCards:proof.remaining});
    }catch(_){return null;}
  }
  function advance(kind,id){
    var cert=certificate;certificate=null;carry=null;if(!cert||!cert.claim.complete||!cert.route.length)return false;
    var first=cert.route[0];if(first.kind!==kind||first.id!==id)return false;
    carry={route:copy(cert.route.slice(1)),binding:cert.binding.slice(),revision:cert.revision};return true;
  }
  var solo=Object.freeze({applies:applies,plan:plan,validateRoute:function(s,d){return validate(s,d,false);},prescribed:function(s,d){return validate(s,d,true);},advance:advance,
    invalidate:function(){carry=null;certificate=null;current=null;if(core&&typeof core.invalidate==='function')core.invalidate();last={version:1,status:'blocked',reason:'awaiting_snapshot',totalCards:0,plannedCleared:0,remaining:0,states:0,powerUses:0,complete:false,optimal:false,scope:'current_phase'};},diagnostic:function(){return copy(last);}});
  function wrapped(input){return typeof base==='function'?base(input):{status:'blocked',reason:'planner_unavailable',actions:[],sequence:[]};}
  Object.defineProperty(wrapped,'solo',{value:solo,enumerable:false,writable:false,configurable:false});return wrapped;
})

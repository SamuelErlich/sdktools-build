-- Bounded read-only identity, separate from the live observer and its state.
-- No module loading, hooks, frame reads, captures or gameplay commands.
local ok, active = pcall(function()
    local cs = rawget(_G, "CS")
    if cs == nil then return false end
    local scene = cs.UnityEngine.SceneManagement.SceneManager.GetActiveScene()
    return scene.isLoaded == true and
        (scene.name == "BilliardInGame" or scene.name == "BilliardTutorial")
end)
if ok and active == true then
    return '{"format":"SDK.ClientContext","active":true}'
end
return '{"format":"SDK.ClientContext","active":false}'

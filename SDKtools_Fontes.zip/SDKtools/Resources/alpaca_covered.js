/* SDKtools: opt-in, one original TouchBlock or UseProp call, observed acknowledgement.
 * No packet construction, direct gameplay transport call or game-state writes.
 * A timeout is uncertainty, not permission to retry. Native input is explicit. */
(function () {
  'use strict';
  var job=null, attempts=0, last={status:'idle',reason:'not_armed',kind:'touch'};
  var LIMIT=15000, STABLE=80, MAX_JSON=262144;
  var REASONS=['not_armed','observer_unavailable','context_unavailable','candidate_unavailable',
    'external_mode_active','original_pending','mode_disabled','no_covered_candidate','action_disabled',
    'xray_required','observing_board','no_covered_card',
    'invoking_original','awaiting_server','awaiting_original_settlement','server_200','server_rejected',
    'awaiting_stability','effect_not_confirmed','response_timeout','socket_closed','context_changed',
    'original_exception','outbound_not_observed','request_mismatch','response_mismatch',
    'observer_restore_failed','cancelled_uncertain','penetrate_unavailable','penetrate_stock_not_zero',
    'penetrate_id_unverified','penetrate_stock_empty','trio_required','recovery_timeout','secure_transport_required'];
  function object(v){return v!==null&&(typeof v==='object'||typeof v==='function');}
  function own(o,k){if(!object(o))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);
    if(d&&!Object.prototype.hasOwnProperty.call(d,'value'))throw Error('accessor');return d?d.value:undefined;}
  function int(v,a,b){return typeof v==='number'&&isFinite(v)&&Math.floor(v)===v&&v>=a&&v<=b;}
  function identity(v){return typeof v==='string'&&v.length>0&&v.length<=128||int(v,1,9007199254740991);}
  // WebSocket.url is browser-canonicalized. Never export it or decode query fields.
  // This protects SDK experiments only; it cannot repair the host's earlier login.
  function secureSocket(ws){var value=ws&&ws.url;
    return typeof value==='string'&&value.length<=4096&&/^wss:\/\/[^\/?#\s@\\]+(?:[\/?][^#\s\\]*)?$/.test(value);}
  function now(){var v=typeof performance==='object'&&performance&&typeof performance.now==='function'?performance.now():Date.now();
    if(typeof v!=='number'||!isFinite(v))throw Error('clock');return v;}
  function method(o,k){for(var p=o,i=0;p&&i<8;p=Object.getPrototypeOf(p),i++){
    var d=Object.getOwnPropertyDescriptor(p,k);if(d){if(!('value'in d)||typeof d.value!=='function')throw Error('method');return d.value;}}
    throw Error('method');}
  function canShadow(o,k){var d=Object.getOwnPropertyDescriptor(o,k);method(o,k);
    return d?('value'in d&&d.writable===true):Object.isExtensible(o);}
  function shadow(o,k,wrapper){var d=Object.getOwnPropertyDescriptor(o,k);
    if(!canShadow(o,k))throw Error('shadow');
    Object.defineProperty(o,k,d?Object.assign({},d,{value:wrapper}):{value:wrapper,writable:true,configurable:true,enumerable:false});
    return function(){var current=Object.getOwnPropertyDescriptor(o,k);if(!current||current.value!==wrapper)return false;
      if(d)Object.defineProperty(o,k,d);else delete o[k];return true;};}
  function busy(){return !!(job&&job.pending);}
  function cancelLease(j){
    if(j.timer!==null){try{clearTimeout(j.timer);}catch(_){}j.timer=null;}
    j.leaseToken++;
  }
  function removeObservers(j){
    cancelLease(j);
    for(var i=j.listeners.length-1;i>=0;i--){try{j.remove.call(j.ws,j.listeners[i].name,j.listeners[i].fn);}catch(_){}}
    j.listeners=[];
  }
  function restoreHooks(j){var ok=true;for(var i=j.undo.length-1;i>=0;i--){try{ok=j.undo[i]()&&ok;}catch(_){ok=false;}}
    j.undo=[];return ok;}
  function uncertain(j,reason){if(job!==j||!j.pending||j.status==='uncertain')return;
    j.status='uncertain';j.phase='blocked';j.reason=reason;j.stable=null;restoreHooks(j);removeObservers(j);}
  function recoveryTimeout(j){if(job!==j||!j.pending||j.phase!=='recovery'||j.recoveryExpired)return;
    j.recoveryExpired=true;j.reason='recovery_timeout';j.stable=null;restoreHooks(j);removeObservers(j);}
  function armLease(j,phase){
    cancelLease(j);j.phase=phase;j.leaseStarted=now();j.deadline=j.leaseStarted+LIMIT;
    var token=j.leaseToken;
    j.timer=setTimeout(function(){
      if(job!==j||!j.pending||j.phase!==phase||j.leaseToken!==token)return;
      if(phase==='response')uncertain(j,'response_timeout');else recoveryTimeout(j);
    },LIMIT);
  }
  function timed(j){if(!j||!j.pending||j.status==='uncertain')return;
    try{var t=now();if(t<j.started){uncertain(j,'context_changed');return;}
      if(t>=j.deadline){if(j.phase==='response')uncertain(j,'response_timeout');else if(j.phase==='recovery')recoveryTimeout(j);}
    }catch(_){uncertain(j,'context_changed');}}
  function diagnostic(){timed(job);var j=job;
    var d={status:j?j.status:last.status,reason:j?j.reason:last.reason,pending:!!(j&&j.pending),
      requestObserved:!!(j&&j.requestObserved),responseObserved:!!(j&&j.responseObserved),
      promiseSettled:!!(j&&j.promiseSettled),effectObserved:!!(j&&j.effectObserved),attempts:attempts,
      kind:j?j.kind:last.kind,responseOutcome:j?j.responseOutcome:'unknown',phase:j?j.phase:last.status==='idle'?'idle':'blocked'};
    if(j&&int(j.code,0,1000000))d.serverCode=j.code;return d;}
  function block(reason,kind){if(!busy()){job=null;last={status:'blocked',reason:REASONS.indexOf(reason)>=0?reason:'candidate_unavailable',
    kind:['penetrate_zero','penetrate_owned'].indexOf(kind)>=0?kind:'touch'};}return diagnostic();}
  function invalidate(){if(job)job.stable=null;}
  function live(j,s){
    if(typeof window!=='object'||!window||typeof document!=='object'||document!==j.document||window!==j.window||
      own(window,'cc')!==j.cc||own(window,'__require')!==j.loader||
      method(j.cc.director,'getScene').call(j.cc.director)!==j.root||
      own(j.store,'uid')!==j.uid||own(j.store,'rid')!==j.rid||own(j.store,'start_time')!==j.start||
      own(j.socket,'uid')!==j.uid||own(j.socket,'rid')!==j.rid||own(j.socket,'socket')!==j.ws||
      own(j.socket,'responseMap')!==j.map||j.ws.url!==j.wsURL||!secureSocket(j.ws)||own(j.loader('Socket'),'default')!==j.socket||
      own(j.loader('GameStore'),'default')!==j.store)return false;
    if(s){var p=s.playState;if(!p||s.cc!==j.cc||s.root!==j.root||s.board!==j.board||p.store!==j.store||
      p.game!==j.game||p.layer!==j.layer||p.uid!==j.uid||p.rid!==j.rid||p.start!==j.start)return false;}
    return true;
  }
  function agreement(j){
    if(job!==j||!j.pending||j.status==='uncertain')return;
    try{if(!live(j,null)){uncertain(j,'context_changed');return;}}catch(_){uncertain(j,'context_changed');return;}
    if(!j.responseObserved||!j.promiseSettled){j.reason=j.responseObserved?'awaiting_original_settlement':'awaiting_server';return;}
    if((j.code===200)!==j.resolved){uncertain(j,'response_mismatch');return;}
    if(j.responseOutcome!=='unknown')return;
    j.responseOutcome=j.code===200?'accepted':'rejected';j.status=j.responseOutcome;
    j.reason=j.code===200?'server_200':'server_rejected';j.stable=null;armLease(j,'recovery');
  }
  function penetrate(store,uid,kind){
    var rows=own(store,'props_blocks');if(!Array.isArray(rows)||rows.length>16)throw Error('penetrate_unavailable');
    var found=rows.filter(function(row){return own(row,'type')===3;});if(found.length!==1)throw Error('penetrate_unavailable');
    var row=found[0],count=own(row,'count'),propID=own(row,'id');
    if(!int(count,0,1000000))throw Error('penetrate_unavailable');
    if(kind==='penetrate_owned'){if(count<1)throw Error('penetrate_stock_empty');}
    else if(count!==0)throw Error('penetrate_stock_not_zero');
    if(typeof propID!=='string'||!propID||propID.length>128||propID!=='3-'+String(uid))throw Error('penetrate_id_unverified');
    return {row:row,id:propID,count:count};
  }
  function initial(s,c,kind){
    var p=s&&s.playState,cc=s&&s.cc,loader=typeof window==='object'&&own(window,'__require');
    if(!p||!cc||typeof loader!=='function'||typeof document!=='object'||document.visibilityState!=='visible'||
      own(window,'cc')!==cc||!cc.director||method(cc.director,'getScene').call(cc.director)!==s.root||
      typeof s.signature!=='string'||!s.signature||!s.refs||typeof s.refs.get!=='function')throw Error('context_unavailable');
    var version=own(cc,'ENGINE_VERSION'),fallback=own(window,'CocosEngine');
    if((version||fallback)!=='2.4.4'||version&&fallback&&version!==fallback)throw Error('context_unavailable');
    var store=own(loader('GameStore'),'default'),socket=own(loader('Socket'),'default'),ws=own(socket,'socket'),map=own(socket,'responseMap');
    if(store!==p.store||!object(socket)||!object(map)||!ws||ws.readyState!==1||
      !identity(p.uid)||!identity(p.rid)||!int(p.start,1,9007199254740991)||
      own(store,'uid')!==p.uid||own(store,'rid')!==p.rid||own(store,'start_time')!==p.start||
      own(socket,'uid')!==p.uid||own(socket,'rid')!==p.rid)throw Error('context_unavailable');
    if(!secureSocket(ws))throw Error('secure_transport_required');
    if(own(store,'state')!==2||own(store,'isWatcher')!==false||own(store,'isHotTiming')!==false||
      own(store,'isAddingCommonBlock')!==false||own(store,'isUsingPenetrateProp')!==false||
      own(store,'isCanTouchBlock')!==true)throw Error('external_mode_active');
    var gamers=own(store,'gamers');if(!Array.isArray(gamers)||gamers.length>512||
      gamers.filter(function(g){return own(g,'uid')===p.uid&&own(g,'state')===1;}).length!==1)throw Error('external_mode_active');
    var a=c&&c.action,m=c&&c.metadata,b=m&&m.block,info=own(b,'blockInfo');
    if(!c||s.refs.get(c.id)!==c||c.zone!=='board'||c.masked!==true||!Array.isArray(c.blockedBy)||!c.blockedBy.length||
      c.selectable!==true||typeof c.type!=='string'||!/^type:[0-9]{1,5}$/.test(c.type)||
      !m||m.specialType!==0||m.lock!==0||m.canTouch!==false||
      !a||a.receiver!==b||!b||b.isValid!==true||b.node!==c.node||c.node.parent!==s.board||
      !a.button||a.button.isValid!==true||a.button.enabled!==true||a.button.enabledInHierarchy!==true||
      a.button.interactable!==false||!a.event||a.event.target!==c.node||a.event.handler!=='touchBlock'||
      !identity(c.rawID)||own(info,'id')!==c.rawID||own(info,'state')!==0||m.rawID!==c.rawID||m.state!==0)
      throw Error('candidate_unavailable');
    // Owned automation is not the zero-stock experiment. It must complete one
    // exact ordinary triple already in the hand; no guessed follow-up route.
    if(kind==='penetrate_owned'){
      var hand=own(store,'hand_blocks'),pile=own(store,'pile_blocks');
      if(!consistent(s,{store:store,rawID:c.rawID})||!Array.isArray(hand)||hand.length<2||hand.length>=7||!Array.isArray(pile)||pile.length>512||
        hand.filter(function(v){return own(v,'type')===own(info,'type');}).length!==2||
        pile.filter(function(v){return own(v,'id')===c.rawID&&own(v,'type')===own(info,'type');}).length!==1)
        throw Error('trio_required');
    }
    var prop=kind!=='touch'?penetrate(store,p.uid,kind):null,key=kind!=='touch'?'UseProp':'TouchBlock';
    var operation=method(socket,key),send=method(ws,'send'),add=method(ws,'addEventListener'),remove=method(ws,'removeEventListener');
    var next=own(socket,'packetId');
    if(!int(next,1,9007199254740990)||own(map,String(next))!==undefined)throw Error('observer_unavailable');
    if(operation.length!==2||method(socket,'send').length!==1||method(socket,'onMessage').length!==1||
      typeof Promise!=='function'||typeof Promise.prototype.then!=='function'||typeof setTimeout!=='function'||typeof clearTimeout!=='function'||
      !canShadow(socket,key)||!canShadow(ws,'send'))throw Error('observer_unavailable');
    return {window:window,document:document,cc:cc,loader:loader,root:s.root,board:s.board,
      store:store,game:p.game,layer:p.layer,uid:p.uid,rid:p.rid,start:p.start,
      socket:socket,ws:ws,wsURL:ws.url,map:map,operation:operation,operationKey:key,kind:kind,prop:prop,
      send:send,add:add,remove:remove,rawID:c.rawID,type:c.type};
  }
  function dispatch(s,card,invoke,options){
    if(busy())return false;
    var kind=options&&options.kind!==undefined?options.kind:'touch';
    var j;try{if(typeof invoke!=='function'||['touch','penetrate_zero','penetrate_owned'].indexOf(kind)<0)throw Error('candidate_unavailable');j=initial(s,card,kind);}
    catch(e){block(e&&REASONS.indexOf(e.message)>=0?e.message:'observer_unavailable',kind);return false;}
    var t;try{t=now();}catch(_){block('observer_unavailable',kind);return false;}
    Object.assign(j,{status:'submitted',reason:'invoking_original',pending:true,started:t,deadline:t+LIMIT,
      timer:null,leaseToken:0,phase:'response',responseOutcome:'unknown',recoveryExpired:false,
      listeners:[],undo:[],stable:null,requestObserved:false,responseObserved:false,
      promiseSettled:false,resolved:false,effectObserved:false,code:null,packet:null,entry:null,
      calls:0,sends:0,touchActive:false,invoked:false});job=j;
    function message(e){try{
      timed(j);
      if(job!==j||!j.pending||j.status==='uncertain'||!j.requestObserved||e.isTrusted!==true||e.target!==j.ws||
        typeof e.data!=='string'||e.data.length>MAX_JSON)return;
      var value;try{value=JSON.parse(e.data);}catch(_){return;}
      if(!value||value.packet_id!==j.packet||!int(value.code,0,1000000))return;
      if(j.responseObserved){if(value.code!==j.code)uncertain(j,'response_mismatch');return;}
      j.responseObserved=true;j.code=value.code;agreement(j);
    }catch(_){uncertain(j,'context_changed');}}
    function closed(e){try{if(e&&e.isTrusted===true&&e.target===j.ws)uncertain(j,'socket_closed');}catch(_){uncertain(j,'socket_closed');}}
    function onSettled(resolved){try{timed(j);if(job!==j||!j.pending||j.status==='uncertain')return;
      if(j.promiseSettled){if(j.resolved!==resolved)uncertain(j,'response_mismatch');return;}
      j.promiseSettled=true;j.resolved=resolved;agreement(j);
    }catch(_){uncertain(j,'context_changed');}}
    function observedSend(){
      if(job===j&&j.pending&&j.status!=='uncertain'&&j.touchActive){
        try{var raw=arguments[0],v=typeof raw==='string'&&raw.length<=8192?JSON.parse(raw):null,param=v&&v.param;
          var payload=j.kind!=='touch'?param&&param.prop_id===j.prop.id&&
            !Object.prototype.hasOwnProperty.call(param,'block_state'):param&&param.block_state===0;
          if(this!==j.ws||++j.sends!==1||!v||v.packet_id!==j.packet||v.command!==(j.kind!=='touch'?'CMD_USE_PROP':'CMD_TOUCH_BLOCK')||
            !param||param.block_id!==j.rawID||!payload||param.uid!==j.uid||param.rid!==j.rid)
            uncertain(j,'request_mismatch');
          else{j.requestObserved=true;j.reason='awaiting_server';}
        }catch(_){uncertain(j,'request_mismatch');}
      }
      try{return j.send.apply(this,arguments);}catch(e){uncertain(j,'original_exception');throw e;}
    }
    function observedOperation(){
      var track=job===j&&j.pending&&j.status!=='uncertain';
      if(track){try{
        var expected=j.kind!=='touch'?[j.prop.id,j.rawID]:[j.rawID,0];
        if(this!==j.socket||++j.calls!==1||arguments.length!==2||arguments[0]!==expected[0]||arguments[1]!==expected[1]||!live(j,null))throw Error('request');
        if(j.prop&&(penetrate(j.store,j.uid,j.kind).row!==j.prop.row||penetrate(j.store,j.uid,j.kind).count!==j.prop.count))throw Error('prop');
        j.packet=own(j.socket,'packetId');if(!int(j.packet,1,9007199254740990)||own(j.map,String(j.packet))!==undefined)throw Error('packet');
        j.touchActive=true;
      }catch(_){uncertain(j,'request_mismatch');track=false;}}
      var returned;
      try{returned=j.operation.apply(this,arguments);}
      catch(e){uncertain(j,'original_exception');throw e;}
      finally{j.touchActive=false;}
      if(track&&j.status!=='uncertain'){
        try{j.entry=own(j.map,String(j.packet));
          if(!j.requestObserved||j.sends!==1||own(j.socket,'packetId')!==j.packet+1||own(j.socket,'responseMap')!==j.map||
            !object(j.entry)||typeof own(j.entry,'resolve')!=='function'||typeof own(j.entry,'reject')!=='function')throw Error('entry');
          // Observe the actual returned native Promise. Never replace its identity.
          Promise.prototype.then.call(returned,function(){onSettled(true);},function(){onSettled(false);});
        }catch(_){uncertain(j,'outbound_not_observed');}
      }
      return returned;
    }
    try{
      [['message',message],['close',closed],['error',closed]].forEach(function(pair){
        j.listeners.push({name:pair[0],fn:pair[1]});j.add.call(j.ws,pair[0],pair[1]);});
      j.undo.push(shadow(j.socket,j.operationKey,observedOperation));j.undo.push(shadow(j.ws,'send',observedSend));
      if(j.status!=='submitted'||!j.pending)throw Error('observer');
      armLease(j,'response');
      if(!live(j,s)||j.ws.readyState!==1)throw Error('context');
      if(j.prop&&(penetrate(j.store,j.uid,j.kind).row!==j.prop.row||penetrate(j.store,j.uid,j.kind).count!==j.prop.count))throw Error('prop');
    }catch(_){restoreHooks(j);removeObservers(j);job=null;last={status:'blocked',reason:'observer_unavailable',kind:kind};return false;}
    j.invoked=true;attempts=Math.min(10000,attempts+1);
    try{invoke();}catch(_){uncertain(j,'original_exception');}
    finally{if(!restoreHooks(j))uncertain(j,'observer_restore_failed');}
    if(j.status!=='uncertain'&&(!j.requestObserved||j.calls!==1))uncertain(j,'outbound_not_observed');
    return true;
  }
  function consistent(s,j){
    if(!s||typeof s.signature!=='string'||!s.signature||!s.refs||typeof s.refs.forEach!=='function'||
      !int(s.refs.size,0,512))return null;
    var entries=new Map(),count=0;
    for(var z=0;z<3;z++){
      var list=own(j.store,['pile_blocks','hand_blocks','storage_blocks'][z]);
      if(!Array.isArray(list)||list.length>512)return null;var flat=[];
      for(var i=0;i<list.length;i++){
        var v=list[i];if(z===2&&Array.isArray(v)){if(v.length>512)return null;flat=flat.concat(v);}else flat.push(v);
        if(flat.length>512)return null;
      }
      for(var k=0;k<flat.length;k++){
        if(z===2&&flat[k]===null)continue;
        var info=flat[k],key=own(info,'id'),type=own(info,'type');
        if(!identity(key)||!int(type,0,10000)||own(info,'state')!==z||entries.has(key)||++count>512)return null;
        entries.set(key,{zone:['board','tray','reserve'][z],type:'type:'+type});
      }
    }
    if(entries.size!==s.refs.size)return null;
    var seen=new Set(),ok=true;s.refs.forEach(function(c){
      var e=c&&entries.get(c.rawID);if(!e||seen.has(c.rawID)||e.zone!==c.zone||e.type!==c.type)ok=false;else seen.add(c.rawID);});
    if(!ok)return null;return {chosen:entries.get(j.rawID)};
  }
  function observe(s){var j=job;if(!j||!j.pending||j.status==='uncertain')return;
    timed(j);if(j.status==='uncertain')return;
    try{
      if(!live(j,s)){uncertain(j,'context_changed');return;}
      if(j.ws.readyState!==1){uncertain(j,'socket_closed');return;}
      if(!s||document.visibilityState!=='visible'){j.stable=null;return;}
      if(!j.responseObserved||!j.promiseSettled||j.status==='submitted'){j.stable=null;return;}
      var state=consistent(s,j),chosen=state&&state.chosen;
      if(!state||j.status==='rejected'&&(!chosen||chosen.zone!=='board'||chosen.type!==j.type)){
        j.stable=null;if(!j.recoveryExpired)j.reason='awaiting_stability';return;}
      if(j.kind!=='touch'&&j.status==='accepted'&&chosen&&(chosen.zone!=='tray'||chosen.type!==j.type)){
        j.stable=null;if(!j.recoveryExpired)j.reason='effect_not_confirmed';return;}
      var t=now();
      if(!j.stable||j.stable.signature!==s.signature||t<j.stable.time){j.stable={signature:s.signature,time:t};if(!j.recoveryExpired)j.reason='awaiting_stability';return;}
      if(t-j.stable.time<STABLE){if(!j.recoveryExpired)j.reason='awaiting_stability';return;}
      j.effectObserved=j.status==='accepted'&&(!chosen||chosen.zone==='tray'&&chosen.type===j.type);
      j.reason=j.status==='rejected'?'server_rejected':j.effectObserved?'server_200':'effect_not_confirmed';
      j.pending=false;j.phase='complete';removeObservers(j);
    }catch(_){uncertain(j,'context_changed');}
  }
  return Object.freeze({dispatch:dispatch,observe:observe,invalidate:invalidate,busy:busy,diagnostic:diagnostic,block:block});
})

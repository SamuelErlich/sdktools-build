/* SDKtools V3.11: current Store-to-HandArea-to-Card binding.
 * No writes to game objects, no requests, no ID/texture history. The native
 * button installs this factory through the existing WebView bridge. Internal
 * references never cross that bridge; only bounded counters are exported.
 */
(function makeCardRoot() {
  'use strict';
  var cc=null,scene=null,doc=null,store=null,gamers=null,Card=null,token,state;
  var rows=new Map(),seen=new Map(),loaded=false,reason='root_unavailable';
  function own(o,k){if(!o||(typeof o!=='object'&&typeof o!=='function'))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);return d&&Object.prototype.hasOwnProperty.call(d,'value')?d.value:undefined;}
  function integer(v,max){return typeof v==='number'&&Number.isInteger(v)&&v>=0&&v<=max;}
  function named(o,name){for(var i=0;o&&i<5;i++,o=Object.getPrototypeOf(o))if(own(o,'__classname__')===name)return true;return false;}
  function oneCard(n){var a=own(n,'_components');if(!Array.isArray(a)||a.length>16)return null;var found=null;for(var i=0;i<a.length;i++){var c=own(a,String(i));if(named(c,'Card')){if(found)return null;found=c;}}return found;}
  function values(info){return [own(info,'id'),own(info,'type'),own(info,'color'),own(info,'num')];}
  function equalValues(a,b){return a.every(function(v,i){return v===b[i];});}
  function clear(){cc=scene=doc=store=gamers=Card=null;rows=new Map();seen=new Map();loaded=false;reason='root_unavailable';token=state=undefined;}
  function begin(engine,root){clear();cc=engine;scene=root;doc=document;}
  function load(component){
    if(loaded)return;loaded=true;
    var loader=own(window,'__require');if(typeof loader!=='function'||!named(component,'Card'))return;
    var C=own(loader('Card'),'default'),proto=own(C,'prototype');
    if(!proto||!Object.prototype.isPrototypeOf.call(proto,component))return;
    var s=own(loader('GameStore'),'default'),gs=own(s,'gamers');
    if(!Array.isArray(gs)||gs.length>8)return;
    Card=C;store=s;gamers=gs;token=own(store,'start_time');state=own(store,'state');
    var ids=new Map(),all=[],total=0;
    for(var slot=0;slot<gs.length;slot++){
      var gamer=own(gs,String(slot)),cards=own(gamer,'cards'),uid=own(gamer,'uid');
      if(!Array.isArray(cards)||cards.length>256){reason='root_incomplete';rows.clear();return;}
      total+=cards.length;if(total>256){reason='root_limit';rows.clear();return;}
      for(var index=0;index<cards.length;index++){
        var info=own(cards,String(index)),v=values(info);
        if(!info||typeof info!=='object'||!integer(v[0],65535))continue;
        var row={gamer:gamer,cards:cards,info:info,uid:uid,slot:slot,index:index,values:v};
        all.push(row);ids.set(v[0],(ids.get(v[0])||0)+1);
        if(rows.has(info))rows.set(info,null);else rows.set(info,row);
      }
    }
    all.forEach(function(row){if(ids.get(row.values[0])!==1)rows.set(row.info,null);});
    reason='root_ready';
  }
  function owner(node){
    var parent=node.parent,p=parent;
    for(var depth=0;p&&depth<6;depth++,p=p.parent){
      var a=own(p,'_components');if(!Array.isArray(a))continue;if(a.length>16)return null;
      var match=null;
      for(var i=0;i<a.length;i++){var c=own(a,String(i));if(named(c,'HandArea')&&own(c,'itemsNode')===parent){if(match)return null;match=c;}}
      if(match)return {component:match,parent:parent};
    }return null;
  }
  function current(row,node,component,binding){
    if(document!==doc||window.cc!==cc||!cc||!cc.director||cc.director.getScene()!==scene||
       own(store,'gamers')!==gamers||own(store,'start_time')!==token||own(store,'state')!==state||
       own(gamers,String(row.slot))!==row.gamer||own(row.gamer,'cards')!==row.cards||
       own(row.cards,String(row.index))!==row.info||own(row.gamer,'uid')!==row.uid||
       !equalValues(row.values,values(row.info))||!node||node.isValid!==true||node.active!==true||node.activeInHierarchy===false||
       oneCard(node)!==component||own(component,'cardInfo')!==row.info)return null;
    var p=node,depth=0;while(p&&p!==scene&&depth++<24)p=p.parent;if(p!==scene)return null;
    var hand=owner(node);if(!hand||own(hand.component,'gamer')!==row.gamer||own(hand.component,'uid')!==row.uid)return null;
    if(typeof row.uid!=='string'&&typeof row.uid!=='number')return null;
    var siblings=hand.parent.children;if(!Array.isArray(siblings)||siblings.length>256)return null;
    var matches=0;
    for(var i=0;i<siblings.length;i++){
      var n=own(siblings,String(i)),c=oneCard(n),info=own(c,'cardInfo');
      if(info===row.info||own(info,'id')===row.values[0]){matches++;if(n!==node||c!==component)return null;}
    }
    if(matches!==1)return null;
    if(binding&&(binding.hand!==hand.component||binding.parent!==hand.parent))return null;
    return hand;
  }
  function resolve(node,component){
    try{
      load(component);var info=own(component,'cardInfo'),row=rows.get(info),hand;
      if(reason!=='root_ready'||!row||!(hand=current(row,node,component))) {seen.set(node,'unbound');return null;}
      var type=row.values[1],color=row.values[2],special=type===4||type===6||type===10;
      var known=integer(type,10)&&type>0&&integer(color,4)&&(special||color>0);
      seen.set(node,known?'known':'unknown');
      return {kind:known?'known':'unknown',color:known?(special?0:color):null,row:row,
        component:component,info:info,hand:hand.component,parent:hand.parent,token:token,state:state};
    }catch(_){reason='root_unavailable';rows.clear();seen.set(node,'unbound');return null;}
  }
  function valid(binding,node){try{return !!binding&&binding.token===token&&binding.state===state&&
    rows.get(binding.info)===binding.row&&!!current(binding.row,node,binding.component,binding);}catch(_){return false;}}
  function same(a,b){return !!a&&!!b&&a.kind===b.kind&&a.color===b.color&&a.info===b.info&&a.component===b.component&&
    a.hand===b.hand&&a.parent===b.parent&&a.token===b.token&&a.state===b.state&&
    a.row.gamer===b.row.gamer&&a.row.cards===b.row.cards&&a.row.index===b.row.index&&equalValues(a.row.values,b.row.values);}
  function stats(){var out={rootStatus:reason,rootBound:0,rootKnown:0,rootUnknown:0,rootUnbound:0};
    seen.forEach(function(v){if(v==='unbound')out.rootUnbound++;else{out.rootBound++;if(v==='known')out.rootKnown++;else out.rootUnknown++;}});return out;}
  return Object.freeze({begin:begin,resolve:resolve,valid:valid,same:same,stats:stats,clear:clear});
})

/* SDKtools V3.19.6: current Store-to-HandArea-to-Card binding.
 * Selected-card facts are bounded to one document/scene/socket/round and owner.
 * No game writes, requests, ID formulas or cross-round/texture history. Native
 * button installs this factory through the existing WebView bridge. Internal
 * references never cross that bridge; only bounded counters are exported.
 */
(function makeCardRoot() {
  'use strict';
  var cc=null,scene=null,doc=null,store=null,gamers=null,Card=null,token,state;
  var rows=new Map(),seen=new Map(),byId=new Map(),uidCounts=new Map(),loaded=false,reason='root_unavailable';
  var hands=[],handAnchors=new Map(),countsReady=false;
  var facts=new Map(),retired=new Set(),epoch=null,lastNow=null,frameTime=null,selectedRejected=0;
  var MAX_AGE=120000,MAX_GAP=1500;
  function own(o,k){if(!o||(typeof o!=='object'&&typeof o!=='function'))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);return d&&Object.prototype.hasOwnProperty.call(d,'value')?d.value:undefined;}
  function integer(v,max){return typeof v==='number'&&Number.isInteger(v)&&v>=0&&v<=max;}
  function named(o,name){for(var i=0;o&&i<5;i++,o=Object.getPrototypeOf(o))if(own(o,'__classname__')===name)return true;return false;}
  function oneCard(n){var a=own(n,'_components');if(!Array.isArray(a)||a.length>16)return null;var found=null;for(var i=0;i<a.length;i++){var c=own(a,String(i));if(named(c,'Card')){if(found)return null;found=c;}}return found;}
  function values(info){return [own(info,'id'),own(info,'type'),own(info,'color'),own(info,'num')];}
  function equalValues(a,b){return a.every(function(v,i){return v===b[i];});}
  function uid(v){return typeof v==='string'?v.length>0&&v.length<=128:typeof v==='number'&&Number.isSafeInteger(v)&&v>0;}
  function now(){if(frameTime!==null)return frameTime;var p=own(window,'performance'),f=p&&p.now;return typeof f==='function'?f.call(p):Date.now();}
  function forget(){facts.clear();retired.clear();epoch=null;lastNow=null;}
  function retire(id){facts.delete(id);if(retired.size<256)retired.add(id);}
  function clear(){forget();cc=scene=doc=store=gamers=Card=null;rows.clear();seen.clear();byId.clear();uidCounts.clear();hands=[];handAnchors.clear();countsReady=false;loaded=false;reason='root_unavailable';token=state=undefined;frameTime=null;selectedRejected=0;}
  function begin(engine,root,time){
    if(cc!==engine||scene!==root||doc!==document)clear();
    cc=engine;scene=root;doc=document;frameTime=typeof time==='number'&&Number.isFinite(time)&&time>=0?time:null;rows.clear();seen.clear();byId.clear();uidCounts.clear();hands=[];handAnchors.clear();countsReady=false;loaded=false;reason='root_unavailable';selectedRejected=0;
  }
  function face(info){
    var v=values(info),special=v[1]===4||v[1]===6||v[1]===10;
    if(!integer(v[0],65535)||v[0]===0||!integer(v[1],10)||v[1]===0||!integer(v[2],4)||(!special&&v[2]===0)||!integer(v[3],9)||(v[1]===1?v[3]===0:v[3]!==0))return null;
    return {id:v[0],type:v[1],color:special?0:v[2],num:v[3]};
  }
  function sameFace(a,b){return a&&b&&['id','type','color','num'].every(function(k){return a[k]===b[k];});}
  function hidden(v){return v[1]===0&&v[2]===0&&v[3]===0;}
  function reconcileSelected(loader){
    var selected=own(store,'select_give_card'),candidate=face(selected),time=now();
    var tokenOK=(typeof token==='number'&&Number.isSafeInteger(token)&&token>0)||(typeof token==='string'&&token.length>0&&token.length<=128);
    if(!tokenOK||!Number.isFinite(time)||[3,4,5,6,9,10,11].indexOf(state)<0){forget();return;}
    if(!candidate&&!facts.size){return;}
    var client=own(loader('Socket'),'default'),socket=own(client,'socket');
    if(!socket||typeof socket!=='object'){forget();selectedRejected=candidate?1:0;return;}
    if(!epoch||epoch.store!==store||epoch.token!==token||epoch.client!==client||epoch.socket!==socket||lastNow===null||time<lastNow||time-lastNow>MAX_GAP){
      forget();epoch={store:store,token:token,client:client,socket:socket};
    }
    lastNow=time;
    var discarded=own(store,'discard_cards');
    if(!Array.isArray(discarded)||discarded.length>256){forget();selectedRejected=candidate?1:0;return;}
    var gone=new Set();
    for(var d=0;d<discarded.length;d++){var id=own(own(discarded,String(d)),'id');if(integer(id,65535))gone.add(id);}
    facts.forEach(function(fact,id){
      var row=byId.get(id),valid=row&&uidCounts.get(row.uid)===1&&row.uid===fact.uid&&!gone.has(id)&&time-fact.at<=MAX_AGE&&
        (hidden(row.values)||sameFace(face(row.info),fact.face));
      if(!valid)retire(id);
    });
    if(!candidate)return;
    var row=byId.get(candidate.id);
    if(retired.size>=256||retired.has(candidate.id)||!row||uidCounts.get(row.uid)!==1||!uid(row.uid)||!hidden(row.values)||gone.has(candidate.id)){
      selectedRejected=1;return;
    }
    var prior=facts.get(candidate.id);
    if(prior&&(!sameFace(prior.face,candidate)||prior.uid!==row.uid)){
      retire(candidate.id);selectedRejected=1;return;
    }
    if(!prior&&facts.size<256)facts.set(candidate.id,{face:candidate,uid:row.uid,at:time});
  }
  function load(component){
    if(loaded)return;loaded=true;
    var loader=own(window,'__require');if(typeof loader!=='function'||!named(component,'Card'))return;
    var C=own(loader('Card'),'default'),proto=own(C,'prototype');
    if(!proto||!Object.prototype.isPrototypeOf.call(proto,component))return;
    var s=own(loader('GameStore'),'default'),gs=own(s,'gamers');
    if(!Array.isArray(gs)||gs.length>8)return;
    Card=C;store=s;gamers=gs;token=own(store,'start_time');state=own(store,'state');
    var ids=new Map(),all=[],total=0;
    for(var slot=0;slot<gs.length;slot++){
      var gamer=own(gs,String(slot)),cards=own(gamer,'cards'),ownerUID=own(gamer,'uid');
      uidCounts.set(ownerUID,(uidCounts.get(ownerUID)||0)+1);
      if(!Array.isArray(cards)||cards.length>256){reason='root_incomplete';rows.clear();return;}
      total+=cards.length;if(total>256){reason='root_limit';rows.clear();return;}
      var handRow={gamer:gamer,cards:cards,uid:ownerUID,slot:slot,length:cards.length,entries:[]};hands.push(handRow);
      for(var index=0;index<cards.length;index++){
        var info=own(cards,String(index)),v=values(info);
        handRow.entries.push({info:info,values:v});
        if(!info||typeof info!=='object'||!integer(v[0],65535))continue;
        var row={gamer:gamer,cards:cards,info:info,uid:ownerUID,slot:slot,index:index,values:v};
        all.push(row);ids.set(v[0],(ids.get(v[0])||0)+1);byId.set(v[0],row);
        if(rows.has(info))rows.set(info,null);else rows.set(info,row);
      }
    }
    all.forEach(function(row){if(ids.get(row.values[0])!==1){rows.set(row.info,null);byId.set(row.values[0],null);}});
    countsReady=hands.length>0&&hands.every(function(h){return uid(h.uid)&&uidCounts.get(h.uid)===1&&h.entries.every(function(e){return e.info&&typeof e.info==='object'&&integer(e.values[0],65535)&&e.values[0]>0&&ids.get(e.values[0])===1;});});
    try{reconcileSelected(loader);}catch(_){forget();selectedRejected=1;}
    reason='root_ready';
  }
  function owner(node){
    var parent=node.parent,p=parent;
    for(var depth=0;p&&depth<6;depth++,p=p.parent){
      var a=own(p,'_components');if(!Array.isArray(a))continue;if(a.length>16)return null;
      var match=null;
      for(var i=0;i<a.length;i++){var c=own(a,String(i));if(named(c,'HandArea')&&own(c,'itemsNode')===parent){if(match)return null;match=c;}}
      if(match)return {component:match,parent:parent,node:p};
    }return null;
  }
  // Count current Store membership independently of rendered cards. A fan can
  // hide cards, and an animation can temporarily move its nodes to the center.
  // Hand anchors are optional geometry hints; they never determine card totals.
  function observeHand(node,component){
    var proto=own(Card,'prototype'),info=own(component,'cardInfo'),row=byId.get(own(info,'id'));
    if(!proto||!Object.prototype.isPrototypeOf.call(proto,component)||oneCard(node)!==component||!row||uidCounts.get(row.uid)!==1)return;
    var p=node,depth=0;while(p&&p!==scene&&depth++<24)p=p.parent;if(p!==scene)return;
    var hand=owner(node),gamer=hand&&own(hand.component,'gamer');
    if(!hand||own(hand.component,'uid')!==row.uid||own(gamer,'uid')!==row.uid)return;
    var prior=handAnchors.get(row.uid);
    if(prior&&(prior.component!==hand.component||prior.node!==hand.node||prior.parent!==hand.parent)){handAnchors.set(row.uid,null);return;}
    if(prior!==null)handAnchors.set(row.uid,{component:hand.component,node:hand.node,parent:hand.parent,uid:row.uid,gamer:gamer});
  }
  function freshHands(){
    var tokenOK=(typeof token==='number'&&Number.isSafeInteger(token)&&token>0)||(typeof token==='string'&&token.length>0&&token.length<=128);
    if(!countsReady||reason!=='root_ready'||document!==doc||window.cc!==cc||!cc||!cc.director||cc.director.getScene()!==scene||
       !tokenOK||[2,3,4,5,6,9,10,11].indexOf(state)<0||own(store,'gamers')!==gamers||own(store,'start_time')!==token||own(store,'state')!==state||gamers.length!==hands.length)return false;
    return hands.every(function(h){return own(gamers,String(h.slot))===h.gamer&&own(h.gamer,'uid')===h.uid&&own(h.gamer,'cards')===h.cards&&h.cards.length===h.length&&
      h.entries.every(function(e,index){return own(h.cards,String(index))===e.info&&equalValues(e.values,values(e.info));});});
  }
  function handSummary(){try{
    if(!freshHands())return null;
    var time=now(),discarded=own(store,'discard_cards'),gone=new Set();
    var factScope=epoch&&epoch.store===store&&epoch.token===token&&own(epoch.client,'socket')===epoch.socket&&Number.isFinite(time)&&lastNow!==null&&time>=lastNow&&time-lastNow<=MAX_GAP&&Array.isArray(discarded)&&discarded.length<=256;
    if(factScope)for(var d=0;d<discarded.length;d++){var id=own(own(discarded,String(d)),'id');if(integer(id,65535))gone.add(id);}
    var result=hands.map(function(h){
      var colors=[0,0,0,0,0],selected=0;
      h.entries.forEach(function(e){
        var f=face(e.info),fact=facts.get(e.values[0]);
        if(!f&&hidden(e.values)&&factScope&&fact&&fact.uid===h.uid&&!gone.has(e.values[0])&&time-fact.at<=MAX_AGE){f=fact.face;selected++;}
        if(f)colors[f.color]++;
      });
      var known=colors.reduce(function(a,b){return a+b;},0),anchor=handAnchors.get(h.uid),handNode=null;
      if(anchor&&anchor.node&&anchor.node.isValid===true&&anchor.node.active===true&&anchor.parent&&anchor.parent.parent===anchor.node&&
         own(anchor.component,'itemsNode')===anchor.parent&&own(anchor.component,'uid')===h.uid&&own(anchor.component,'gamer')===anchor.gamer&&own(anchor.gamer,'uid')===h.uid){
        var p=anchor.node,depth=0;while(p&&p!==scene&&depth++<24)p=p.parent;if(p===scene)handNode=anchor.node;
      }
      return {slot:h.slot,total:h.length,known:known,unknown:h.length-known,special:colors[0],colors:colors,selected:selected,handNode:handNode};
    });
    return freshHands()?result:null;
  }catch(_){return null;}}
  function current(row,node,component,binding){
    if(document!==doc||window.cc!==cc||!cc||!cc.director||cc.director.getScene()!==scene||
       own(store,'gamers')!==gamers||own(store,'start_time')!==token||own(store,'state')!==state||
       own(gamers,String(row.slot))!==row.gamer||own(row.gamer,'cards')!==row.cards||
       own(row.cards,String(row.index))!==row.info||own(row.gamer,'uid')!==row.uid||
       !equalValues(row.values,values(row.info))||!node||node.isValid!==true||node.active!==true||node.activeInHierarchy===false||
       oneCard(node)!==component||own(component,'cardInfo')!==row.info)return null;
    var p=node,depth=0;while(p&&p!==scene&&depth++<24)p=p.parent;if(p!==scene)return null;
    var hand=owner(node);if(!hand||own(hand.component,'gamer')!==row.gamer||own(hand.component,'uid')!==row.uid)return null;
    if(typeof row.uid!=='string'&&typeof row.uid!=='number')return null;
    var siblings=hand.parent.children;if(!Array.isArray(siblings)||siblings.length>256)return null;
    var matches=0;
    for(var i=0;i<siblings.length;i++){
      var n=own(siblings,String(i)),c=oneCard(n),info=own(c,'cardInfo');
      if(info===row.info||own(info,'id')===row.values[0]){matches++;if(n!==node||c!==component)return null;}
    }
    if(matches!==1)return null;
    if(binding&&(binding.hand!==hand.component||binding.parent!==hand.parent))return null;
    return hand;
  }
  // The shipped client checks hands by UID + current card IDs, not by object
  // identity: every CMD_SYNC replaces Store objects while Card keeps push data.
  // Use that separate protocol proof ONLY for an actually observed selected face.
  function selectedHand(row,node,component,binding){
    if(document!==doc||window.cc!==cc||!cc||cc.director.getScene()!==scene||!epoch||epoch.store!==store||epoch.token!==token||own(epoch.client,'socket')!==epoch.socket||
       own(store,'gamers')!==gamers||own(store,'start_time')!==token||own(store,'state')!==state||
       own(gamers,String(row.slot))!==row.gamer||own(row.gamer,'cards')!==row.cards||own(row.cards,String(row.index))!==row.info||
       own(row.gamer,'uid')!==row.uid||uidCounts.get(row.uid)!==1||!equalValues(row.values,values(row.info))||
       !node||node.isValid!==true||node.active!==true||node.activeInHierarchy===false||oneCard(node)!==component)return null;
    var p=node,depth=0;while(p&&p!==scene&&depth++<24)p=p.parent;if(p!==scene)return null;
    var hand=owner(node),handGamer=hand&&own(hand.component,'gamer');
    if(!hand||!uid(row.uid)||own(hand.component,'uid')!==row.uid||own(handGamer,'uid')!==row.uid)return null;
    var siblings=hand.parent.children,found=false,used=new Set();
    if(!Array.isArray(siblings)||siblings.length!==row.cards.length||siblings.length>256)return null;
    for(var i=0;i<siblings.length;i++){
      var n=own(siblings,String(i)),c=oneCard(n),info=own(c,'cardInfo'),v=values(info),r=byId.get(v[0]);
      if(!n||n.isValid!==true||n.active!==true||!c||!Object.prototype.isPrototypeOf.call(own(Card,'prototype'),c)||
         !r||r.gamer!==row.gamer||r.cards!==row.cards||used.has(v[0])||!equalValues(v,r.values))return null;
      used.add(v[0]);if(n===node&&c===component)found=true;
    }
    if(!found)return null;
    if(binding&&(binding.hand!==hand.component||binding.parent!==hand.parent||binding.uiGamer!==handGamer||
       binding.uiInfo!==own(component,'cardInfo')||!equalValues(binding.uiValues,values(binding.uiInfo))))return null;
    return hand;
  }
  function resolve(node,component){
    try{
      load(component);if(reason==='root_ready')observeHand(node,component);var info=own(component,'cardInfo'),row=rows.get(info),hand;
      if(reason==='root_ready'){
        var protocolRow=byId.get(own(info,'id')),fact=protocolRow&&facts.get(protocolRow.values[0]);
        if(fact&&fact.uid===protocolRow.uid&&hidden(protocolRow.values)&&(hand=selectedHand(protocolRow,node,component))){
          seen.set(node,'selected');
          return {kind:'known',source:'select_give_card',color:fact.face.color,fact:fact,row:protocolRow,
            component:component,info:protocolRow.info,uiInfo:info,uiValues:values(info),uiGamer:own(hand.component,'gamer'),
            hand:hand.component,parent:hand.parent,token:token,state:state};
        }
      }
      if(reason!=='root_ready'||!row||!(hand=current(row,node,component))) {seen.set(node,'unbound');return null;}
      var type=row.values[1],color=row.values[2],special=type===4||type===6||type===10;
      var known=integer(type,10)&&type>0&&integer(color,4)&&(special||color>0);
      seen.set(node,known?'known':'unknown');
      return {kind:known?'known':'unknown',color:known?(special?0:color):null,row:row,
        component:component,info:info,hand:hand.component,parent:hand.parent,token:token,state:state};
    }catch(_){reason='root_unavailable';rows.clear();seen.set(node,'unbound');return null;}
  }
  function valid(binding,node){try{
    if(binding&&binding.source==='select_give_card')return binding.token===token&&binding.state===state&&
      facts.get(binding.row.values[0])===binding.fact&&binding.fact.uid===binding.row.uid&&!!selectedHand(binding.row,node,binding.component,binding);
    return !!binding&&binding.token===token&&binding.state===state&&
    rows.get(binding.info)===binding.row&&!!current(binding.row,node,binding.component,binding);}catch(_){return false;}}
  function same(a,b){return !!a&&!!b&&a.kind===b.kind&&a.color===b.color&&a.info===b.info&&a.component===b.component&&
    a.hand===b.hand&&a.parent===b.parent&&a.token===b.token&&a.state===b.state&&a.source===b.source&&a.fact===b.fact&&
    a.row.gamer===b.row.gamer&&a.row.cards===b.row.cards&&a.row.index===b.row.index&&equalValues(a.row.values,b.row.values);}
  function stats(){var summary=handSummary(),out={rootStatus:reason,rootBound:0,rootKnown:0,rootUnknown:0,rootUnbound:0,selectedKnown:0,selectedRetained:facts.size,selectedRejected:selectedRejected,
      handsStatus:summary?'ready':'unavailable',handCounts:[],handTotal:0,handKnown:0,handUnknown:0};
    if(summary)summary.forEach(function(h){out.handCounts.push({slot:h.slot,total:h.total,known:h.known,unknown:h.unknown,special:h.special,colors:h.colors.slice(),selected:h.selected});out.handTotal+=h.total;out.handKnown+=h.known;out.handUnknown+=h.unknown;});
    seen.forEach(function(v){if(v==='unbound')out.rootUnbound++;else{out.rootBound++;if(v==='known'||v==='selected')out.rootKnown++;else out.rootUnknown++;if(v==='selected')out.selectedKnown++;}});return out;}
  return Object.freeze({begin:begin,resolve:resolve,valid:valid,same:same,stats:stats,handSummary:handSummary,clear:clear});
})

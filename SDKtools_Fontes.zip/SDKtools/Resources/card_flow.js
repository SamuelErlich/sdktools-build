/* SDKtools V3.8. Explicit game-2007 diagnostic, not a card revealer.
 * Observes game-initiated calls only. Copies a numeric allowlist, never payloads.
 * Native binds the game/document. Each temporary method wrapper preserves this,
 * arguments, return value and thrown value. Promise observation adds a reaction.
 * No module enumeration, socket interception, requests or gameplay actions.
 */
(function makeCardFlow() {
  'use strict';
  var MAX={cards:256,players:8,array:256,queue:96,queueBytes:262144,eventBytes:32768,drainBytes:49152,total:4096,lease:1800,duration:90000};
  var root=null,engine=null,doc=null,store=null,socket=null,patches=[],queue=[],queueBytes=0;
  var status='waiting',reason='no_verified_cards',started=false,stopped=false,timer=null,born=now(),heartbeat=born;
  var sequence=0,call=0,dropped=0,errors=0,round=1,startToken,objects=new WeakMap(),nextObject=0,nodes=new WeakMap(),nextNode=0;
  function now(){return window.performance&&typeof window.performance.now==='function'?window.performance.now():Date.now();}
  function object(v){return v!==null&&(typeof v==='object'||typeof v==='function');}
  function own(o,k){if(!object(o))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);return d&&Object.prototype.hasOwnProperty.call(d,'value')?d.value:undefined;}
  function method(o,k){for(var i=0;object(o)&&i<6;i++,o=Object.getPrototypeOf(o)){var d=Object.getOwnPropertyDescriptor(o,k);if(d)return Object.prototype.hasOwnProperty.call(d,'value')&&typeof d.value==='function'?d.value:null;}return null;}
  function integer(v,max){return typeof v==='number'&&Number.isInteger(v)&&v>=0&&v<=max;}
  function alias(map,o,prefix){if(!object(o))return undefined;if(!map.has(o)){var n=prefix==='fo'?++nextObject:++nextNode;if(n>1000000)return undefined;map.set(o,prefix+n);}return map.get(o);}
  function close(why){
    if(stopped)return;stopped=true;status='stopped';reason=why;
    if(timer!==null){window.clearInterval(timer);timer=null;}
    for(var i=patches.length-1;i>=0;i--){var p=patches[i];try{if(own(p.target,p.key)===p.wrapper){if(p.prior)Object.defineProperty(p.target,p.key,p.prior);else delete p.target[p.key];}}catch(_){errors++;}}
    patches=[];
  }
  function live(){
    if(stopped)return false;
    try{
      if(document!==doc||window.cc!==engine||engine.director.getScene()!==root){close('context_changed');return false;}
      if(document.hidden===true||document.visibilityState==='hidden'){close('hidden_document');return false;}
      if(now()-born>=MAX.duration){close('duration_limit');return false;}
      if(now()-heartbeat>MAX.lease){close('lease_expired');return false;}
      for(var i=0;i<patches.length;i++){if(own(patches[i].target,patches[i].key)!==patches[i].wrapper){close('method_replaced');return false;}}
      return true;
    }catch(_){close('read_error');return false;}
  }
  function observe(stage,value,callID,component,pushEvent){
    if(!live())return;
    try{
      if(sequence>=MAX.total){dropped++;close('event_limit');return;}
      var begin=now(),out={sequence:++sequence,stage:stage,callID:callID,elapsedMs:Math.max(0,Math.round(begin-born)),round:round,truncated:false,cards:[]};
      if(integer(pushEvent,19)&&pushEvent>0&&pushEvent!==14)out.pushEvent=pushEvent;
      if(component){var node=own(component,'node')||own(component,'_node');var nid=alias(nodes,node,'fn');if(nid)out.nodeID=nid;}
      var token=own(value,'start_time');if(integer(token,Number.MAX_SAFE_INTEGER)){if(startToken!==undefined&&token!==startToken)round++;startToken=token;out.round=round;}
      ['state','mode','game_mode_type','bet_level'].forEach(function(k){var v=own(value,k);if(integer(v,65535))out[k]=v;});
      function card(v,zone,slot,index){
        if(!object(v))return;
        if(out.cards.length>=MAX.cards||now()-begin>3){out.truncated=true;return;}
        var row={zone:zone,index:index,present:0};if(slot!==null)row.slot=slot;
        var ref=alias(objects,v,'fo');if(ref)row.objectID=ref;
        ['id','type','color','num'].forEach(function(k,i){var x=own(v,k),max=i===0?65535:i===1?10:i===2?4:99;if(integer(x,max)){row[k]=x;row.present|=1<<i;}});
        out.cards.push(row);
      }
      function list(a,zone,slot){if(!Array.isArray(a))return;var len=own(a,'length');if(!integer(len,1000000)){out.truncated=true;return;}if(len>MAX.array)out.truncated=true;for(var i=0;i<Math.min(len,MAX.array);i++){card(own(a,String(i)),zone,slot,i);if(out.truncated&&(out.cards.length>=MAX.cards||now()-begin>3))break;}}
      if(stage==='card_setup_input'||stage==='card_setup_after')card(value,'visual',null,0);
      else{
        var gamers=own(value,'gamers');if(Array.isArray(gamers)){var count=own(gamers,'length');if(count>MAX.players)out.truncated=true;for(var i=0;i<Math.min(count,MAX.players);i++)list(own(own(gamers,String(i)),'cards'),'hand',i);}
        list(own(value,'discard_cards'),'discard',null);list(own(value,'cards'),'event',null);list(own(value,'look_over_cards'),'look_over',null);
        card(own(value,'card'),'draw',null,0);card(own(value,'select_give_card'),'selected',null,0);
      }
      // ASCII-only output; no field names/strings from the game cross this boundary.
      while(JSON.stringify(out).length>MAX.eventBytes&&out.cards.length){out.cards.pop();out.truncated=true;}
      var bytes=JSON.stringify(out).length;
      if(queue.length>=MAX.queue||queueBytes+bytes>MAX.queueBytes){dropped++;return;}
      queue.push({event:out,bytes:bytes});queueBytes+=bytes;
    }catch(_){errors++;}
  }
  function patch(target,key,build){
    var prior=Object.getOwnPropertyDescriptor(target,key),original=method(target,key);
    if(!original||(prior&&(!Object.prototype.hasOwnProperty.call(prior,'value')||(!prior.configurable&&!prior.writable))))throw 0;
    var wrapper=build(original);var descriptor=prior?Object.assign({},prior,{value:wrapper}):{value:wrapper,writable:true,configurable:true,enumerable:false};
    Object.defineProperty(target,key,descriptor);patches.push({target:target,key:key,prior:prior,wrapper:wrapper});
  }
  function paired(before,after){return function(original){return function(){var active=live(),id=active?++call:0;if(active)observe(before,arguments[0],id,null);var result=original.apply(this,arguments);if(active)observe(after,this,id,null);return result;};};}
  function findCard(scene){
    var stack=[scene],seen=new Set(),begin=now();
    while(stack.length&&seen.size<4096&&now()-begin<8){var n=stack.pop();if(!object(n)||seen.has(n))continue;seen.add(n);var components=own(n,'_components');
      if(n.width===224&&n.height===295&&Array.isArray(components))for(var i=0;i<Math.min(components.length,16);i++){
        var c=own(components,String(i)),p=c;
        for(var depth=0;object(p)&&depth<5;depth++,p=Object.getPrototypeOf(p))if(own(p,'__classname__')==='Card'&&method(c,'setup')&&object(own(c,'cardInfo'))&&object(own(c,'skinNode'))&&object(own(c,'bgSprite'))&&object(own(c,'typeSprite'))&&object(own(c,'backSprite')))return c;
      }
      var children=n.children;if(Array.isArray(children)&&children.length<=512)for(var j=0;j<children.length;j++)if(stack.length<4096)stack.push(children[j]);
    }return null;
  }
  function install(){
    var cc=window.cc,scene;
    if(!cc||(cc.ENGINE_VERSION!=='2.4.5'&&window.CocosEngine!=='2.4.5')||(cc.ENGINE_VERSION&&cc.ENGINE_VERSION!=='2.4.5')||(window.CocosEngine&&window.CocosEngine!=='2.4.5')){status='unsupported';reason='unsupported_engine';return;}
    if(document.hidden===true||document.visibilityState==='hidden'){status='blocked';reason='hidden_document';return;}
    if(!cc.director||typeof cc.director.getScene!=='function'||!(scene=cc.director.getScene())){reason='scene_unavailable';return;}
    var component=findCard(scene);if(!component){reason='no_verified_cards';return;}
    var loader=own(window,'__require');if(typeof loader!=='function'){status='unsupported';reason='module_loader_unavailable';return;}
    // Card is already live; these exact dependencies were loaded by the game.
    // Resolve only the three known exports, and reject a different Card class.
    var Card=own(loader('Card'),'default'),proto=own(Card,'prototype');
    if(!proto||!Object.prototype.isPrototypeOf.call(proto,component)){status='unsupported';reason='module_contract_mismatch';return;}
    store=own(loader('GameStore'),'default');socket=own(loader('Socket'),'default');
    if(!object(store)||!Array.isArray(own(store,'gamers'))||!method(store,'sync')||!method(store,'updatePushMessage')||!object(socket)||!method(socket,'sync')||typeof own(socket,'pushHandler')!=='function'||!method(proto,'setup')){status='unsupported';reason='module_contract_mismatch';return;}
    root=scene;engine=cc;doc=document;heartbeat=now();
    try{
      patch(store,'sync',paired('store_input','store_after'));
      patch(store,'updatePushMessage',paired('store_update_input','store_update_after'));
      patch(socket,'sync',function(original){return function(){var active=live(),id=active?++call:0,result=original.apply(this,arguments);if(active){try{Promise.prototype.then.call(result,function(value){try{observe('socket_sync_result',value,id,null);}catch(_){errors++;}},function(){if(live())errors++;});}catch(_){errors++;}}return result;};});
      patch(socket,'pushHandler',function(original){return function(){if(live()&&integer(arguments[0],19)&&arguments[0]>0&&arguments[0]!==14)observe('push_input',arguments[1],++call,null,arguments[0]);return original.apply(this,arguments);};});
      patch(proto,'setup',function(original){return function(){var active=live(),id=active?++call:0;if(active)observe('card_setup_input',arguments[0],id,this);var result=original.apply(this,arguments);if(active)observe('card_setup_after',own(this,'cardInfo'),id,this);return result;};});
      started=true;status='ready';reason='observing';timer=window.setInterval(function(){live();},400);observe('store_snapshot',store,++call,null);
    }catch(_){errors++;close('install_failed');}
  }
  function tick(){
    try{if(!stopped){if(now()-born>=MAX.duration)close('duration_limit');else if(!started)install();else if(live())heartbeat=now();}}catch(_){errors++;close('read_error');}
    var events=[],bytes=0;while(queue.length&&bytes+queue[0].bytes<=MAX.drainBytes){var item=queue.shift();events.push(item.event);bytes+=item.bytes;queueBytes-=item.bytes;}
    return {version:1,status:status,reason:reason,started:started,events:events,dropped:dropped,errors:errors,queued:queue.length,lastSequence:sequence};
  }
  return Object.freeze({tick:tick,clear:function(){close('explicit_stop');queue=[];queueBytes=0;store=null;socket=null;root=null;engine=null;doc=null;objects=new WeakMap();nodes=new WeakMap();}});
})

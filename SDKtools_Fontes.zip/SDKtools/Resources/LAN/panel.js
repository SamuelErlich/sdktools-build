(function(root){'use strict';
 const speeds=Object.freeze([
  {name:'Baixo',ms:500,detail:'Ritmo baixo. Mantém a quantidade escolhida no menu do iPhone.'},
  {name:'Moderado',ms:250,detail:'Ritmo moderado. Mantém a quantidade escolhida no menu do iPhone.'},
  {name:'Normal',ms:100,detail:'Avaliação a cada 100 ms. Fluxo original.'},
  {name:'Turbo',ms:40,detail:'Avaliação a cada 40 ms. Confirmação continua obrigatória.'},
  {name:'Máximo',ms:20,detail:'Super Fast: ritmo máximo. Mantém a quantidade escolhida no menu do iPhone; aguarda confirmação do jogo.'},
  {name:'Teste 10 ms',ms:10,detail:'Experimental: consulta a cada 10 ms. Cada grupo ainda aguarda confirmação do jogo.'},
  {name:'Teste 5 ms',ms:5,detail:'Experimental: consulta a cada 5 ms. Cada grupo ainda aguarda confirmação do jogo.'},
  {name:'Teste 2 ms',ms:2,detail:'Experimental: consulta a cada 2 ms. Cada grupo ainda aguarda confirmação do jogo.'},
  {name:'Teste 0,5 ms',ms:0.5,detail:'Intervalo solicitado de 0,5 ms. Tempo real depende do iPhone; pode elevar consumo.'},
  {name:'Super 0,05 ms',ms:0.05,detail:'Intervalo solicitado de 0,05 ms. Não garante essa frequência real. Aguarda todas as confirmações do jogo.'}
 ]);
 const integer=(n,max=1000000)=>typeof n==='number'&&Number.isInteger(n)&&n>=0&&n<=max;
 function counts(state){const c=state&&state.fresh===true&&state.counts;if(!c)return null;
  for(const k of ['board','tray','reserve','types','sharedCards'])if(!integer(c[k],512))return null;
  const total=c.board+c.tray+c.reserve+c.sharedCards;return total<=512&&c.tray<=6&&c.types<=total?{...c,total}:null;
 }
 function preferences(level,extended,powers,xray){if(!Number.isInteger(level)||level<1||level>10||[extended,powers,xray].some(v=>typeof v!=='boolean'))throw Error('invalid_preferences');
  return {speedLevel:level,extendedPlanning:extended,powersEnabled:powers,xrayEnabled:xray};}
 function client(fetcher){let key='',sequence=0,busy=false,downloadController=null,downloadCancelled=false;
  async function request(path,method='GET',body,auth=true){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),2500);
   try{const headers={};if(body)headers['Content-Type']='application/json';if(auth){if(!key)throw Error('pairing_required');headers['X-SDKTools-Key']=key;}
    const r=await fetcher(path,{method,headers,body:body?JSON.stringify(body):undefined,signal:controller.signal,cache:'no-store',credentials:'omit',redirect:'error'});
    const raw=await r.text();if(raw.length>32768)throw Error('invalid_response');const data=JSON.parse(raw);
    if(!data||typeof data!=='object')throw Error('invalid_response');if(integer(data.nextSequence,1000000001)&&data.nextSequence>0)sequence=data.nextSequence;
    if(!r.ok)throw Error(data.reason||'network_error');return data;
   }finally{clearTimeout(timer);}
  }
  return Object.freeze({
   async pair(code){if(busy||!/^[0-9]{8}$/.test(code))throw Error('invalid_pairing');busy=true;
    try{const data=await request('/api/pair','POST',{code},false);if(data.ok!==true||!/^[a-f0-9]{64}$/.test(data.key))throw Error('invalid_response');key=data.key;return data;}finally{busy=false;}},
   async state(){if(busy)throw Error('command_pending');busy=true;try{const data=await request('/api/state');if(data.ok!==true||!data.state||data.state.version!==1)throw Error('invalid_response');return data.state;}finally{busy=false;}},
   async command(action,prefs){if(busy)throw Error('command_pending');if(!['start','pause','preferences','capture_start','capture_stop','report_export','sources_export'].includes(action))throw Error('command_denied');
    if(!integer(sequence,1000000000)||sequence<1)throw Error('state_required');
    const body={action,sequence};if(action==='preferences')body.preferences=preferences(prefs.speedLevel,prefs.extendedPlanning,prefs.powersEnabled,prefs.xrayEnabled);
    busy=true;try{const data=await request('/api/control','POST',body);if(typeof data.ok!=='boolean')throw Error('invalid_response');return data;}finally{busy=false;}
   },
   async download(job,progress){
    if(busy)throw Error('command_pending');
    if(!job||!/^[a-f0-9-]{36}$/i.test(job.id)||!integer(job.bytes,67108864)||job.bytes<1)throw Error('invalid_download');
    if(!key)throw Error('pairing_required');busy=true;downloadCancelled=false;
    try{const bytes=new Uint8Array(job.bytes);
     for(let offset=0;offset<job.bytes;){if(downloadCancelled)throw Error('download_interrupted');const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),2500);downloadController=controller;
      try{const r=await fetcher('/api/export',{method:'GET',headers:{'X-SDKTools-Key':key,'X-SDKTools-Export':job.id,'X-SDKTools-Offset':String(offset)},
        signal:controller.signal,cache:'no-store',credentials:'omit',redirect:'error'});
       if(!r.ok)throw Error('download_unavailable');const chunk=new Uint8Array(await r.arrayBuffer());
       if(downloadCancelled)throw Error('download_interrupted');if(chunk.length!==Math.min(262144,job.bytes-offset))throw Error('invalid_download');bytes.set(chunk,offset);offset+=chunk.length;
       if(progress)progress(offset,job.bytes);
      }finally{clearTimeout(timeout);downloadController=null;}
      if(offset<job.bytes)await new Promise(resolve=>setTimeout(resolve,100));
     }return bytes;
    }finally{downloadController=null;busy=false;}
   },
   cancelDownload(){downloadCancelled=true;if(downloadController)downloadController.abort();}
  });
 }
 const api=Object.freeze({speeds,counts,preferences,client});if(typeof module==='object'&&module.exports){module.exports=api;return;}
 const doc=root.document;if(!doc)return;const $=id=>doc.getElementById(id),set=(id,v)=>{$(id).textContent=String(v);};
 const link=client(root.fetch.bind(root));let connected=false,busy=false,state=null,timer=null,dirty=false,started=0,firstMoves=0,pauseWhenIdle=false;
 function controls(){for(const id of ['start','pause','apply'])$(id).disabled=!connected||busy||(id!=='pause'&&(!state||state.fresh!==true));
  for(const id of ['capture-start','capture-stop','report-export','sources-export','download'])$(id).disabled=!connected||busy;
  const capture=state&&state.capture,recording=capture&&capture.recording===true,owned=capture&&capture.owned===true;
  if(recording)$('capture-start').disabled=true;
  if(!recording||!owned)$('capture-stop').disabled=true;
  if(recording&&!owned)for(const id of ['report-export','sources-export'])$(id).disabled=true;
  if(!state||!state.export||state.export.state!=='ready')$('download').disabled=true;
  if(state&&state.export&&state.export.state==='collecting')for(const id of ['capture-start','report-export','sources-export'])$(id).disabled=true;
  if(state&&state.canStart!==true)$('start').disabled=true;$('reconnect').disabled=busy;$('pair').disabled=busy;}
 function speed(){const n=Number($('speed').value),s=speeds[n-1];set('speed-name',s.name);set('speed-value',`${s.ms} ms`);set('speed-detail',s.detail);}
 function render(s){state=s;const c=counts(s);for(const k of ['board','tray','reserve','total'])set(k,c?c[k]:'—');set('types',c?`${c.types} tipos`:'Leitura não atual');
  set('status',s.statusText||'Aguardando leitura');set('reading',s.fresh?`Snapshot ${s.phaseRevision} · idade ${s.ageMs} ms`:`Sem snapshot atual · ${s.reason||'aguardando mesa'}`);
  set('auto-state',s.autoplayEnabled?'Auto ativo':'Pausado');set('moves',integer(s.confirmedMoves)?s.confirmedMoves:'—');
  const seconds=Math.max(0,(Date.now()-started)/1000);set('elapsed',`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(Math.floor(seconds%60)).padStart(2,'0')}`);
  set('rate',seconds>=5&&integer(s.confirmedMoves)&&s.confirmedMoves>=firstMoves?((s.confirmedMoves-firstMoves)*60/seconds).toFixed(1):'—');
  const m=s.mission||{};set('mission',integer(m.current)&&integer(m.total)?`Missão: ${m.current}/${m.total}`:'Missão: sem progresso disponível');
  const f=s.superFast||{},limit=s.preferences&&s.preferences.cardsPerBatch;
  let batch=[1,2,3,6].includes(limit)?`Lote: até ${limit} ${limit===1?'carta':'cartas'}`:'Lote: configuração indisponível';
  if(s.batchPending===true){const valid=f.pending===true&&integer(f.submitted,6)&&f.submitted>0&&integer(f.requests,6)&&integer(f.responses,6)&&f.responses<=f.requests&&f.requests<=f.submitted;
   batch+=valid?` · em curso: pedidos ${f.requests}/${f.submitted} · respostas ${f.responses}`:' · em curso: aguardando confirmação';
  }else batch+=f.compatibility===true?' · indisponível: 1 por vez':' · aguardando';
  if(typeof f.dispatchElapsedMs==='number'&&Number.isFinite(f.dispatchElapsedMs)&&f.dispatchElapsedMs>=0&&f.dispatchElapsedMs<=60000)batch+=` · último envio: ${f.dispatchElapsedMs.toFixed(3)} ms (sem ACK/animação)`;
  set('batch',s.fresh===true?batch:'Lote: sem leitura atual');
  set('version',`SDKtools ${s.toolVersion||'?'} / build ${s.frameworkBuild||'?'}`);
  set('export-status',s.export&&s.export.state==='ready'?`Arquivo pronto · ${Math.ceil(s.export.bytes/1024)} KB`:s.export&&s.export.state==='collecting'?'Preparando arquivo no iPhone…':s.export&&s.export.state==='error'?'Não foi possível exportar. Feche janelas e tente novamente.':s.capture&&s.capture.recording?'Capturando a partida no iPhone…':'Captura pronta para iniciar.');
  if(!dirty&&s.preferences){const p=s.preferences;$('speed').value=integer(p.speedLevel,10)&&p.speedLevel>0?p.speedLevel:3;$('planning').checked=p.extendedPlanning===true;$('powers').checked=p.powersEnabled===true;$('xray').checked=p.xrayEnabled===true;speed();}controls();
 }
 function clear(){if(timer!==null)clearTimeout(timer);timer=null;}
 function disconnected(message){clear();connected=false;state=null;pauseWhenIdle=false;
  for(const id of ['board','tray','reserve','total','moves','rate'])set(id,'—');
  set('types','Leitura não atual');set('reading','Sem snapshot atual · conexão interrompida');set('status','Conexão interrompida; atualize o estado.');
  set('auto-state','Auto: estado indisponível');set('mission','Missão: estado indisponível');set('batch','Lote: sem leitura atual');
  set('export-status','Estado da captura indisponível; atualize a conexão.');set('connection','Desconectado');set('notice',message);controls();}
 async function refresh(){if(busy)return;clear();busy=true;controls();try{const s=await link.state();connected=true;set('connection','Pareado · LAN');render(s);
   if(doc.visibilityState==='visible')timer=setTimeout(refresh,500);
  }catch(_){disconnected('Conexão interrompida. O Auto iniciado pelo navegador pausa quando a sessão expirar (até ~8 s). Atualize a conexão ou gere novo código no iPhone.');}finally{busy=false;controls();}
  if(connected&&pauseWhenIdle){pauseWhenIdle=false;await command('pause');}}
 async function resume(){if(!connected)return;if(pauseWhenIdle){pauseWhenIdle=false;await command('pause');}else await refresh();}
 async function command(action,prefs){if(busy||!connected)return;clear();busy=true;controls();
  try{const result=await link.command(action,prefs);const messages={preferences:'Opções aplicadas. Iniciar é separado.',start:'Auto solicitado ao iPhone.',pause:'Pausa solicitada.',capture_start:'Captura iniciada. Reproduza o problema no iPhone.',capture_stop:'Captura encerrada. Gere o relatório para baixar.',report_export:'Gerando relatório. Aguarde e use Baixar JSON.',sources_export:'Extraindo os fontes carregados no iPhone. Aguarde e use Baixar JSON.'};
   set('notice',result.ok?messages[action]:`Comando não aplicado: ${result.reason||'guarda nativa'}`);if(result.ok&&action==='preferences')dirty=false;
  }catch(_){disconnected('Resposta do comando ausente ou recusada. Nenhum reenvio automático. Atualize o estado antes de tentar outra vez.');}
  finally{busy=false;if(action==='pause')pauseWhenIdle=false;controls();}await resume();
 }
 $('pair-form').addEventListener('submit',async e=>{e.preventDefault();if(busy)return;busy=true;controls();set('error','');
  try{await link.pair($('code').value.trim());$('code').value='';started=Date.now();$('pairing').hidden=true;$('dashboard').hidden=false;busy=false;
   const s=await link.state();connected=true;firstMoves=integer(s.confirmedMoves)?s.confirmedMoves:0;render(s);await refresh();
  }catch(_){set('error','Não conectou. Confira o código, a rede e se o compartilhamento está ativo. Após 5 tentativas ou expiração, gere outra sessão no iPhone.');}
  finally{busy=false;controls();}});
 $('start').addEventListener('click',()=>command('start'));$('pause').addEventListener('click',()=>command('pause'));
 $('apply').addEventListener('click',()=>command('preferences',preferences(Number($('speed').value),$('planning').checked,$('powers').checked,$('xray').checked)));
 for(const [id,action] of [['capture-start','capture_start'],['capture-stop','capture_stop'],['report-export','report_export'],['sources-export','sources_export']])$(id).addEventListener('click',()=>command(action));
 $('download').addEventListener('click',async()=>{if(busy||!connected||!state||!state.export||state.export.state!=='ready')return;
  const job={...state.export};clear();busy=true;controls();
  try{const bytes=await link.download(job,(n,total)=>set('export-status',`Baixando ${Math.round(n*100/total)}%…`));
   const url=root.URL.createObjectURL(new root.Blob([bytes],{type:'application/json'})),a=doc.createElement('a');a.href=url;a.download=`SDKtools-export-${job.id}.json`;
   doc.body.appendChild(a);a.click();a.remove();setTimeout(()=>root.URL.revokeObjectURL(url),1000);set('notice','JSON salvo no PC. Envie esse arquivo para análise.');
  }catch(_){set('notice','Download interrompido. Atualize a conexão e tente baixar novamente; a captura não será repetida.');}
  finally{busy=false;controls();}await resume();
 });
 $('reconnect').addEventListener('click',()=>{if(!busy)refresh();});
 for(const id of ['speed','planning','powers','xray'])$(id).addEventListener('input',()=>{dirty=true;speed();});
 doc.addEventListener('visibilitychange',()=>{if(doc.visibilityState!=='visible'){clear();if(connected&&(busy||(state&&state.autoplayEnabled))){
   if(busy){pauseWhenIdle=true;if(state&&state.autoplayEnabled)link.cancelDownload();}else command('pause');
  }}else if(connected&&!busy)refresh();});
 speed();controls();
})(globalThis);

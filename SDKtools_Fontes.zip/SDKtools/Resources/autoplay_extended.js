/* Bounded multi-trio beam search. The original planner remains the fallback.
 * Only the first complete trio is dispatched; every action is live-revalidated.
 * Beam exhaustion means bounded search, never proof of global impossibility. */
(function (base) {
  'use strict';
  var job=null;
  return function extended(input) {
    if (!input || input.extendedPlanning !== true) { job=null; return base(input); }
    var stamp=JSON.stringify([input.stateKey,input.mission,input.cards,input.tray,input.capacity]);
    if (!job || job.stamp!==stamp) job={stamp:stamp,fallback:null,slices:0,nodes:0,depth:0,best:null,done:false};
    var j=job, start=Date.now();
    if (!j.fallback) {
      var original=base(input);
      if (original.status!=='move') return original;
      j.fallback=original;
      var cards=input.cards, index=new Map(cards.map(function(c,i){return [c.id,i];}));
      j.cards=cards; j.index=index;
      j.beam=[{path:[],removed:new Set(),counts:new Map(),occupancy:input.tray.length,triples:0,first:null,firstType:null,peak:input.tray.length}];
      input.tray.forEach(function(c){var m=j.beam[0].counts;m.set(c.type,(m.get(c.type)||0)+1);});
      j.next=[];j.cursor=0;j.scan=0;j.seen=new Set();
    }
    function expired(){return Date.now()-start>=6;}
    function finish(){
      j.done=true;
      var output=j.best ? Object.assign({},j.fallback,j.best.proof) : Object.assign({},j.fallback);
      output.stats=Object.assign({},j.fallback.stats,{goal:'multi_trio',searchMode:'bounded_beam',lookaheadDepth:j.depth,
        lookaheadTriples:j.best?j.best.triples:1,lookaheadNodes:j.nodes,lookaheadSlices:j.slices,
        completeSearch:false,completeSolution:j.best?false:j.fallback.stats.completeSolution,limit:'bounded_lookahead'});
      if(input.mission && input.mission.current<input.mission.total)
        output.stats.missionStatus=output.matchedType===input.mission.type?'priority':'fallback';
      j.output=output;return output;
    }
    if(j.done)return j.output;
    function eligible(s,c){return !s.removed.has(c.id) && c.locked!==true && c.selectable!==false &&
      (c.available || c.blockedBy.length>0) && c.blockedBy.every(function(id){return s.removed.has(id);});}
    function proof(path){
      var counts=new Map(),groups=new Map(),peak=input.tray.length,occupancy=input.tray.length;
      input.tray.forEach(function(c){counts.set(c.type,(counts.get(c.type)||0)+1);var a=groups.get(c.type)||[];a.push(c.id);groups.set(c.type,a);});
      for(var k=0;k<path.length;k++){
        var c=j.cards[j.index.get(path[k])],a=groups.get(c.type)||[];a.push(c.id);groups.set(c.type,a);
        occupancy++;peak=Math.max(peak,occupancy);var count=(counts.get(c.type)||0)+1;counts.set(c.type,count);
        if(count===3)return {sequence:path.slice(0,k+1),actions:path.slice(0,k+1),cardID:path[0],proofKind:'local_trio',
          matchedType:c.type,tripleCardIDs:a.slice(),peakTrayCount:peak};
      }
      return null;
    }
    function rank(s){
      var mission=input.mission, priority=mission && mission.current<mission.total && s.firstType===mission.type ? 1:0;
      var accessible=new Map(s.counts);
      j.cards.forEach(function(c){if(eligible(s,c))accessible.set(c.type,(accessible.get(c.type)||0)+1);});
      var next=0;accessible.forEach(function(n,t){if(n>=3 && 3-(s.counts.get(t)||0)<=input.capacity-s.occupancy)next++;});
      return [priority,s.triples,-s.occupancy,next,-s.peak,-s.path.length];
    }
    function compare(a,b){for(var k=0;k<a.length;k++)if(a[k]!==b[k])return a[k]-b[k];return 0;}
    j.slices++;
    while(j.nodes<12000 && j.slices<=24 && j.depth<18){
      if(expired())break;
      if(j.cursor>=j.beam.length){
        if(!j.next.length)return finish();
        j.next.sort(function(a,b){return compare(b.score,a.score);});
        j.beam=j.next.slice(0,24);j.next=[];j.cursor=0;j.scan=0;j.seen=new Set();j.depth++;
        continue;
      }
      var s=j.beam[j.cursor];
      if(j.scan>=j.cards.length){j.cursor++;j.scan=0;continue;}
      var c=j.cards[j.scan++];
      if(!eligible(s,c))continue;
      var count=s.counts.get(c.type)||0,trio=count===2;
      if(s.occupancy>=input.capacity || (!trio && s.occupancy+1>=input.capacity))continue;
      j.nodes++;
      var n={path:s.path.concat(c.id),removed:new Set(s.removed),counts:new Map(s.counts),occupancy:s.occupancy+1-(trio?3:0),
        triples:s.triples+(trio?1:0),first:s.first,firstType:s.firstType,peak:Math.max(s.peak,s.occupancy+1)};
      n.removed.add(c.id);n.counts.set(c.type,trio?0:count+1);
      if(!n.first && trio){n.first=proof(n.path);n.firstType=c.type;}
      var key=JSON.stringify(Array.from(n.removed).sort());
      if(j.seen.has(key))continue;j.seen.add(key);
      n.score=rank(n);j.next.push(n);
      // Keep memory bounded even before the end-of-depth beam cut.
      if(j.next.length>192){j.next.sort(function(a,b){return compare(b.score,a.score);});j.next.length=48;}
      if(trio && n.triples>=2 && (!j.best || compare(n.score,j.best.score)>0)){
        // Never downgrade a proved mission-first baseline for a normal route.
        if(j.fallback.stats.missionStatus==='priority' && n.firstType!==input.mission.type)continue;
        j.best={proof:n.first,triples:n.triples,score:n.score,empty:n.removed.size===j.cards.length&&n.occupancy===0};
      }
    }
    if(j.nodes>=12000 || j.slices>=24 || j.depth>=18)return finish();
    return {status:'searching',reason:'search_in_progress',stats:Object.assign({},j.fallback.stats,
      {goal:'multi_trio',lookaheadDepth:j.depth,lookaheadNodes:j.nodes,lookaheadSlices:j.slices,completeSearch:false})};
  };
})

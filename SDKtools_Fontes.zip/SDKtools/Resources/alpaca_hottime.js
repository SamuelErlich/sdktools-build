/* Original HandArea renders current_value/full_value in cc.ProgressBar.
 * The client does not establish the charge added by a diamond trio. Until a
 * verified rule exists, Auto excludes every diamond; other cards are unchanged.
 * This observer never invokes game actions, writes progress, or learns a delta. */
(function () {
  'use strict';
  var charge=null;
  function object(v){return v!==null&&(typeof v==='object'||typeof v==='function');}
  function own(o,k){if(!object(o))return undefined;var d=Object.getOwnPropertyDescriptor(o,k);
    if(d&&!Object.prototype.hasOwnProperty.call(d,'value'))throw Error('accessor');return d?d.value:undefined;}
  function finite(v){return typeof v==='number'&&isFinite(v);}
  function diagnostic(){return Object.freeze({version:1,status:'protected',reason:charge===null?'diamond_charge_unavailable':'diamond_charge_unverified',
    chargePercent:charge,trioChargePercent:null,thresholdPercent:null});}
  function reset(){charge=null;}
  function inspect(s){
    reset();
    try {
      var cc=s&&s.cc,p=s&&s.playState,records=s&&s.records;
      if(!p||!object(cc)||typeof window!=='object'||window.cc!==cc||typeof document!=='object'||document.visibilityState!=='visible'||
        !cc.director||typeof cc.director.getScene!=='function'||cc.director.getScene()!==s.root||
        typeof cc.Component!=='function'||typeof cc.ProgressBar!=='function'||!cc.js||typeof cc.js.getClassName!=='function'||
        !records||typeof records.has!=='function'||typeof records.get!=='function')return diagnostic();
      function visible(n){return object(n)&&n.isValid===true&&n.activeInHierarchy===true&&(n===s.root||n.active===true)&&
        finite(n.opacity)&&n.opacity>0&&n.opacity<=255;}
      function descends(n,ancestor){
        for(var depth=0;n&&depth<=24;depth++){
          if(!visible(n)||!records.has(n))return false;
          if(n===ancestor)return true;
          var parent=records.get(n);if(!parent||n.parent!==parent)return false;n=parent;
        }
        return false;
      }
      function component(c,name){
        if(!(c instanceof cc.Component)||c.isValid!==true||cc.js.getClassName(c)!==name||!descends(c.node,s.root))return false;
        // Cocos 2.4.4 Node._components is the same array used by getComponent.
        var list=own(c.node,'_components');
        return Array.isArray(list)&&list.length<=32&&list.filter(function(v){return v===c;}).length===1;
      }
      var game=own(p,'game'),layer=own(p,'layer'),hand=own(layer,'HandArea');
      if(!component(game,'Game')||own(game,'GameLayer')!==layer||!component(layer,'GameLayer')||layer.node!==s.gameLayer||
        !descends(layer.node,game.node)||!component(hand,'HandArea')||!descends(hand.node,layer.node)||
        own(hand,'AreaNode')!==s.trayNode||!descends(s.trayNode,hand.node))return diagnostic();
      var bar=own(hand,'HotTimeProgressBar');
      if(!(bar instanceof cc.ProgressBar)||!component(bar,'cc.ProgressBar')||bar.enabledInHierarchy!==true||
        !descends(bar.node,hand.node)||own(bar.node,'_components').filter(function(v){return v instanceof cc.ProgressBar;}).length!==1)return diagnostic();
      // The original engine synthesizes progress as an accessor over this own
      // backing value. Never execute progress getters or its updating setter.
      var value=own(bar,'_N$progress');
      if(finite(value)&&value>=0&&value<=1&&window.cc===cc&&cc.director.getScene()===s.root&&
        own(layer,'HandArea')===hand&&own(hand,'HotTimeProgressBar')===bar&&own(bar,'_N$progress')===value)charge=value*100;
    } catch (_) { reset(); }
    return diagnostic();
  }
  function allows(s,c){try {var type=own(c,'type');return typeof type==='string'&&type!=='type:1';}catch(_){return false;}}
  return Object.freeze({allows:allows,inspect:inspect,diagnostic:diagnostic,reset:reset});
})

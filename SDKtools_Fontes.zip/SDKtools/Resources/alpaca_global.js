/* Whole-known-board SOLO search. Pure data only: no scene, transport, stock
 * writes, timers, purchases, or random choices. A solved route is a replayed
 * proof for this snapshot and these ordinary rules, never a server victory.
 * Unknown server-selected power effects are deliberately not invented.
 */
(function makeAlpacaGlobal(config) {
  'use strict';
  config=config&&typeof config==='object'?config:{};
  function bound(v,d,l,h){return Number.isInteger(v)?Math.max(l,Math.min(h,v)):d;}
  var MAX_STATES=bound(config.maxStates,60000,1,200000),SLICE_NODES=bound(config.sliceNodes,96,1,128),SLICE_MS=bound(config.sliceMs,3,1,8);
  var session=null,last={version:1,status:'unavailable',reason:'awaiting_snapshot',model:'known_board_deterministic_powers'};
  function clock(){return typeof performance==='object'&&typeof performance.now==='function'?performance.now():Date.now();}
  function text(v){return typeof v==='string'&&v.length>0&&v.length<=128;}
  function ordinary(c){
    if(!c||typeof c!=='object'||c.locked===true||c.selectable===false)throw Error('unsupported_rules');
    if(c.specialType!==undefined&&c.specialType!==0||c.metadata&&c.metadata.specialType!==0)throw Error('unsupported_rules');
    if(!text(c.type)||/^(unknown|unreadable|special)$/i.test(c.type))throw Error('unknown_type');
  }
  function inert(o,fields){
    if(!o||typeof o!=='object')throw Error('invalid_snapshot');
    var names=Object.getOwnPropertyNames(o);if(names.length>1024)throw Error('excessive_properties');
    names.forEach(function(k){var d=Object.getOwnPropertyDescriptor(o,k);if(d&&(!Object.prototype.hasOwnProperty.call(d,'value')))throw Error('accessor_input');});
    if(Array.isArray(o)){if(o.length>1024)throw Error('excessive_array');for(var i=0;i<o.length;i++)if(!Object.prototype.hasOwnProperty.call(o,i))throw Error('sparse_array');}
    (fields||[]).forEach(function(k){if(k in o&&!Object.prototype.hasOwnProperty.call(o,k))throw Error('inherited_input');});
  }
  function prepare(input){
    inert(input,['mode','snapshotVerified','capacity','matchSize','signature','cards','tray','inventory','withdraw']);
    if(!input||input.mode!==1||input.snapshotVerified!==true)throw Error('unverified_solo_snapshot');
    if(input.capacity!==7||input.matchSize!==undefined&&input.matchSize!==3)throw Error('unsupported_rules');
    if(typeof input.signature!=='string'||!input.signature.length||input.signature.length>262144||!Array.isArray(input.cards)||!Array.isArray(input.tray)||
      input.cards.length+input.tray.length>512||input.tray.length>7)throw Error('invalid_snapshot');
    var cards=[],tray=[],ids=new Map(),all=new Set(),types=[],typeMap=new Map(),edgeCount=0,stock=[0,0,0,0,0,0];
    function type(v){if(!typeMap.has(v)){typeMap.set(v,types.length);types.push(v);}return typeMap.get(v);}
    inert(input.cards);inert(input.tray);
    input.cards.forEach(function(c,i){
      inert(c,['id','type','zone','available','selectable','blockedBy','locked','specialType','metadata','storageVerified']);if(c.metadata)inert(c.metadata,['specialType']);if(Array.isArray(c.blockedBy))inert(c.blockedBy);
      ordinary(c);
      if(!text(c.id)||all.has(c.id)||!['board','reserve'].includes(c.zone)||!Array.isArray(c.blockedBy)||
        c.blockedBy.length>64||typeof c.available!=='boolean'||c.selectable!==true)throw Error('invalid_card');
      if(c.zone==='reserve'&&c.storageVerified!==true)throw Error('unverified_reserve');
      all.add(c.id);ids.set(c.id,i);edgeCount+=c.blockedBy.length;
      cards.push({id:c.id,type:type(c.type),zone:c.zone,available:c.available,links:c.blockedBy.slice(),blockers:[],covers:[]});
    });
    var trayGroups=new Set(),previousType=null;
    input.tray.forEach(function(c){inert(c,['id','type','locked','selectable','specialType','metadata']);if(c.metadata)inert(c.metadata,['specialType']);ordinary(c);if(!text(c.id)||all.has(c.id))throw Error('invalid_tray');
      if(c.type!==previousType){if(trayGroups.has(c.type))throw Error('noncanonical_tray');trayGroups.add(c.type);previousType=c.type;}
      all.add(c.id);tray.push({id:c.id,type:type(c.type)});});
    if(edgeCount>8192)throw Error('excessive_blockers');
    var indegree=cards.map(function(){return 0;});
    cards.forEach(function(c,i){
      var seen=new Set();c.links.forEach(function(id){var b=ids.get(id);if(!text(id)||b===undefined||b===i||seen.has(b)||cards[b].zone!==c.zone)throw Error('invalid_blocker');
        seen.add(b);c.blockers.push(b);cards[b].covers.push(i);indegree[i]++;});
      if(c.available!==(c.blockers.length===0))throw Error('inconsistent_availability');
    });
    function acyclic(list,degree){var q=[];degree.forEach(function(n,i){if(!n)q.push(i);});for(var p=0;p<q.length;p++)list[q[p]].covers.forEach(function(n){if(--degree[n]===0)q.push(n);});return q.length===list.length;}
    if(!acyclic(cards,indegree))throw Error('cyclic_board');
    var totals=new Array(types.length).fill(0),counts=totals.slice();
    cards.forEach(function(c){totals[c.type]++;});tray.forEach(function(c){totals[c.type]++;if(++counts[c.type]>=3)throw Error('unsettled_tray');});
    if(input.inventory!==undefined){
      if(!Array.isArray(input.inventory)||input.inventory.length>6)throw Error('invalid_inventory');
      inert(input.inventory);var stockTypes=new Set();input.inventory.forEach(function(p){inert(p,['type','count']);if(!p||!Number.isInteger(p.type)||p.type<0||p.type>5||stockTypes.has(p.type)||
        !Number.isInteger(p.count)||p.count<0||p.count>1000000)throw Error('invalid_inventory');stockTypes.add(p.type);stock[p.type]=p.count;});
    }
    var normalCount=cards.length,withdraw=null;
    if(input.withdraw!==undefined){
      var w=input.withdraw;inert(w,['verified','id','zone','blockedBy','covers']);if(Array.isArray(w.blockedBy))inert(w.blockedBy);if(Array.isArray(w.covers))inert(w.covers);
      var origin=w&&tray.filter(function(c){return c.id===w.id;});
      if(!w||w.verified!==true||w.zone!=='board'||!origin||origin.length!==1||!Array.isArray(w.blockedBy)||!Array.isArray(w.covers)||
        w.blockedBy.length>64||w.covers.length>512)throw Error('unverified_withdraw');
      var wi=cards.length,links=[],covered=[],seenW=new Set();
      w.blockedBy.forEach(function(id){var i=ids.get(id);if(i===undefined||cards[i].zone!=='board'||seenW.has(id))throw Error('invalid_withdraw');seenW.add(id);links.push(i);});
      seenW.clear();w.covers.forEach(function(id){var i=ids.get(id);if(i===undefined||cards[i].zone!=='board'||seenW.has(id)||links.includes(i))throw Error('invalid_withdraw');seenW.add(id);covered.push(i);});
      // Verify the complete restored graph, not merely each geometry edge.
      var graph=cards.map(function(c){return {covers:c.covers.slice()};}).concat([{covers:covered.slice()}]),deg=cards.map(function(c){return c.blockers.length;}).concat([links.length]);
      links.forEach(function(i){graph[i].covers.push(wi);});covered.forEach(function(i){deg[i]++;});
      if(!acyclic(graph,deg))throw Error('cyclic_withdraw');
      withdraw={id:w.id,index:wi,type:origin[0].type,blockers:links,covers:covered};
      cards.push({id:w.id,type:origin[0].type,zone:'board',available:links.length===0,links:w.blockedBy.slice(),blockers:links,covers:covered});
      ids.set(w.id,wi);
    }
    var bits=new Uint32Array(Math.ceil(cards.length/32));if(withdraw)bits[withdraw.index>>>5]|=1<<(withdraw.index&31);
    var inventory=stock.map(function(n,t){return [t,n];});
    var fingerprint=JSON.stringify([input.signature,7,input.snapshotVerified,1,input.cards.map(function(c){return [c.id,c.type,c.zone,c.available,c.selectable,c.locked,c.specialType,c.metadata&&c.metadata.specialType,c.blockedBy,c.storageVerified];}),
      input.tray.map(function(c){return [c.id,c.type,c.specialType,c.metadata&&c.metadata.specialType];}),inventory,withdraw&&[withdraw.id,withdraw.blockers,withdraw.covers]]);
    return {cards:cards,tray:tray,types:types,ids:ids,normalCount:normalCount,withdraw:withdraw,stock:stock,total:normalCount+tray.length,
      upperBound:totals.reduce(function(n,k){return n+Math.floor(k/3)*3;},0),fingerprint:fingerprint,
      initial:{bits:bits,counts:counts,occupancy:tray.length,remaining:normalCount,penLeft:Math.min(stock[3],Math.floor((normalCount+tray.length)/3)),withdrawAllowed:!!withdraw&&stock[1]>0,withdrawUsed:false,captures:0}};
  }
  function gone(s,i){return (s.bits[i>>>5]&(1<<(i&31)))!==0;}
  function open(m,s,i){
    if(gone(s,i))return false;
    if(m.cards[i].blockers.some(function(b){return !gone(s,b);}))return false;
    return !(m.withdraw&&s.withdrawUsed&&!gone(s,m.withdraw.index)&&m.withdraw.covers.includes(i));
  }
  function actions(m,s){
    if(s.occupancy>=7)return [];
    var result=[],equiv=new Set();
    m.cards.forEach(function(c,i){
      if(gone(s,i))return;var exposed=open(m,s,i),same=s.counts[c.type];
      if(exposed&&(same===2||s.occupancy+1<7)){
        // Exposed same-type cards with identical effects are interchangeable.
        // This is an automorphism, not a depth/beam heuristic that drops paths.
        var identity=c.type+'|'+c.zone+'|'+c.covers.join(',')+'|'+Number(!!m.withdraw&&m.withdraw.blockers.includes(i))+'|'+Number(!!m.withdraw&&m.withdraw.covers.includes(i));
        if(!equiv.has(identity)){
          equiv.add(identity);var benefit=0;
          c.covers.forEach(function(n){if(gone(s,n))return;var blockers=m.cards[n].blockers.filter(function(b){return !gone(s,b);}).length;
            benefit+=(s.counts[m.cards[n].type]===2?500:s.counts[m.cards[n].type]===1?60:3)/(blockers||1);});
          result.push({kind:'card',id:c.id,index:i,score:(same===2?10000:same===1?2000:0)+benefit+c.covers.length});
        }
      }else if(!exposed&&c.zone==='board'&&s.penLeft>0&&same===2){
        result.push({kind:'power',powerType:3,id:c.id,index:i,score:9000+c.covers.length});
      }
    });
    if(s.withdrawAllowed&&m.withdraw)result.push({kind:'power',powerType:1,id:m.withdraw.id,index:m.withdraw.index,score:-100});
    result.sort(function(a,b){return b.score-a.score||a.index-b.index||((a.powerType||0)-(b.powerType||0));});return result;
  }
  function advance(m,s,a){
    var b=s.bits.slice(),c=s.counts.slice(),occupancy=s.occupancy,remaining=s.remaining,pen=s.penLeft,used=s.withdrawUsed,captures=s.captures;
    if(a.powerType===1){b[a.index>>>5]&=~(1<<(a.index&31));c[m.cards[a.index].type]--;occupancy--;remaining++;used=true;}
    else{b[a.index>>>5]|=1<<(a.index&31);var type=m.cards[a.index].type,match=c[type]===2;c[type]=match?0:c[type]+1;
      occupancy+=1-(match?3:0);remaining--;captures++;if(a.powerType===3)pen--;}
    return {bits:b,counts:c,occupancy:occupancy,remaining:remaining,penLeft:pen,withdrawAllowed:false,withdrawUsed:used,captures:captures};
  }
  function key(s){return Array.prototype.join.call(s.bits,'.')+'|'+s.penLeft+'|'+Number(s.withdrawAllowed)+'|'+Number(s.withdrawUsed);}
  function action(a){return a.kind==='card'?{kind:'card',id:a.id}:{kind:'power',powerType:a.powerType,id:a.id};}
  function frame(m,s,via){return {state:s,actions:actions(m,s),cursor:0,via:via};}
  function closedReplay(valid,reason,total,hand,left,first,uses){return {valid:valid,complete:valid&&left+hand===0,cleared:valid?total-left-hand:0,
    totalCards:total,remaining:left+hand,firstTrioIndex:first,reason:reason,powerUses:uses};}
  function replayPrepared(m,route){
    if(!Array.isArray(route)||route.length>m.total+2)return closedReplay(false,'invalid_route',m.total,m.tray.length,m.normalCount,null,0);
    inert(route);
    // Intentionally independent of DFS bits/counts/advance: replay original
    // identities, concrete hand membership and mutable dependency sets.
    var board=new Map(),hand=m.tray.map(function(c){return {id:c.id,type:c.type};}),stock=m.stock.slice(),first=null,uses=0;
    m.cards.slice(0,m.normalCount).forEach(function(c){board.set(c.id,{id:c.id,type:c.type,zone:c.zone,blockers:new Set(c.links)});});
    for(var at=0;at<route.length;at++){
      var a=route[at];inert(a,['kind','id','powerType']);
      if(!a||!text(a.id)||hand.length>=7)return closedReplay(false,'illegal_action',m.total,hand.length,board.size,first,uses);
      if(a.kind==='power'&&a.powerType===1){
        var w=m.withdraw,found=w&&hand.findIndex(function(c){return c.id===w.id;});
        if(at!==0||!w||found<0||a.id!==w.id||stock[1]<1)return closedReplay(false,'illegal_withdraw',m.total,hand.length,board.size,first,uses);
        var returned=hand.splice(found,1)[0];board.set(w.id,{id:w.id,type:returned.type,zone:'board',blockers:new Set(w.blockers.map(function(i){return m.cards[i].id;}))});
        w.covers.forEach(function(i){board.get(m.cards[i].id).blockers.add(w.id);});stock[1]--;uses++;continue;
      }
      var c=board.get(a.id),covered=c&&Array.from(c.blockers).some(function(id){return board.has(id);}),matching=c&&hand.filter(function(h){return h.type===c.type;}).length;
      if(!c)return closedReplay(false,'unknown_card',m.total,hand.length,board.size,first,uses);
      if(a.kind==='card'){if(covered)return closedReplay(false,'covered_card',m.total,hand.length,board.size,first,uses);}
      else if(a.kind==='power'&&a.powerType===3){
        if(c.zone!=='board'||!covered||matching!==2||stock[3]<1)return closedReplay(false,'illegal_penetrate',m.total,hand.length,board.size,first,uses);
        stock[3]--;uses++;
      }else return closedReplay(false,'unsupported_action',m.total,hand.length,board.size,first,uses);
      if(matching!==2&&hand.length+1>=7)return closedReplay(false,'tray_capacity',m.total,hand.length,board.size,first,uses);
      board.delete(c.id);var lastSame=-1;hand.forEach(function(h,n){if(h.type===c.type)lastSame=n;});
      hand.splice(lastSame<0?hand.length:lastSame+1,0,{id:c.id,type:c.type});
      if(matching===2){hand=hand.filter(function(h){return h.type!==c.type;});if(first===null)first=at;}
    }
    return closedReplay(true,board.size+hand.length===0?'clear':'partial',m.total,hand.length,board.size,first,uses);
  }
  function replay(input,route){try{return replayPrepared(prepare(input),route);}catch(e){return {valid:false,complete:false,cleared:0,totalCards:0,remaining:0,firstTrioIndex:null,reason:e&&e.message||'invalid_snapshot',powerUses:0};}}
  function report(){
    var q=session,m=q.model,r=q.bestRoute||[],proof=replayPrepared(m,r);
    if(!proof.valid){session=null;return last={version:1,status:'unavailable',reason:'internal_replay_rejected',model:'known_board_deterministic_powers',route:[],firstAction:null};}
    var publish=q.done,solved=proof.complete&&publish;
    last={version:1,status:publish?(solved?'solved':'best'):'searching',reason:q.reason,model:'known_board_deterministic_powers',wholeBoard:true,
      complete:solved,exhaustive:q.exhaustive,optimal:publish&&(solved||q.exhaustive||proof.cleared===m.upperBound),route:publish?r.map(action):[],
      firstAction:publish&&r.length?action(r[0]):null,bestCleared:proof.cleared,totalCards:m.total,remaining:proof.remaining,
      upperBound:m.upperBound,powerUses:proof.powerUses,states:q.states,transpositions:q.transpositions,slices:q.slices,
      bounds:{maxStates:MAX_STATES,sliceNodes:SLICE_NODES,sliceMs:SLICE_MS},sourceFingerprint:m.fingerprint};
    return JSON.parse(JSON.stringify(last));
  }
  function considerRoute(q,s,route){
    var cleared=q.model.total-s.remaining-s.occupancy,uses=route.filter(function(a){return a.kind==='power';}).length;
    if(!q.bestRoute||cleared>q.bestCleared||cleared===q.bestCleared&&(uses<q.bestUses||uses===q.bestUses&&route.length<q.bestRoute.length)){
      q.bestCleared=cleared;q.bestUses=uses;q.bestRoute=route.slice();
    }
    if(cleared===q.model.total&&s.remaining===0&&s.occupancy===0){q.done=true;q.reason='whole_route_replayed';}
    else if(cleared===q.model.upperBound){q.done=true;q.reason='clearance_upper_bound';}
  }
  function consider(q){var f=q.stack[q.stack.length-1];considerRoute(q,f.state,q.stack.slice(1).map(function(x){return x.via;}));}
  function plan(input){
    var m;try{m=prepare(input);}catch(e){session=null;return last={version:1,status:'unavailable',reason:e&&e.message||'invalid_snapshot',model:'known_board_deterministic_powers',route:[],firstAction:null,complete:false,exhaustive:false,optimal:false};}
    if(!session||session.model.fingerprint!==m.fingerprint){
      session={model:m,stack:[frame(m,m.initial,null)],seen:new Set([key(m.initial)]),bestRoute:null,bestCleared:-1,bestUses:Infinity,
        done:false,exhaustive:false,reason:'searching_whole_board',states:1,transpositions:0,slices:0,guide:0,guideState:m.initial,guideRoute:[]};
    }
    var q=session;if(q.done)return report();q.slices++;var start=clock(),work=0;
    while(!q.done&&work++<SLICE_NODES&&clock()-start<SLICE_MS){
      // Two deterministic, whole-route witness searches precede DFS. These
      // never authorize local guesses: only a complete replay or the sound
      // clearance bound can finish early. A failed guide proves nothing.
      // The total state budget includes guide steps and remains unchanged.
      if(q.guide<2){
        var choices=actions(q.model,q.guideState);
        if(!choices.length||q.states>=MAX_STATES){
          considerRoute(q,q.guideState,q.guideRoute);if(q.done)break;
          if(q.states>=MAX_STATES){q.done=true;q.reason='state_limit_best_observed';break;}
          q.guide++;q.guideState=q.model.initial;q.guideRoute=[];continue;
        }
        choices.sort(function(a,b){
          var an=Number(a.kind!=='card'),bn=Number(b.kind!=='card');if(an!==bn)return an-bn;
          if(q.guide===1){var ac=q.guideState.counts[q.model.cards[a.index].type],bc=q.guideState.counts[q.model.cards[b.index].type];
            var complete=Number(bc===2)-Number(ac===2);if(complete)return complete;}
          return a.index-b.index||((a.powerType||0)-(b.powerType||0));
        });
        var selected=choices[0];q.guideRoute.push(selected);q.guideState=advance(q.model,q.guideState,selected);q.states++;continue;
      }
      var f=q.stack[q.stack.length-1];
      if(!f.actions.length){consider(q);if(q.done)break;}
      if(f.cursor>=f.actions.length){q.stack.pop();if(!q.stack.length){q.done=true;q.exhaustive=true;q.reason='all_modeled_routes_evaluated';}continue;}
      if(q.states>=MAX_STATES){consider(q);q.done=true;q.reason='state_limit_best_observed';break;}
      var a=f.actions[f.cursor++],next=advance(q.model,f.state,a),stamp=key(next);
      if(q.seen.has(stamp)){q.transpositions++;continue;}
      q.seen.add(stamp);q.states++;q.stack.push(frame(q.model,next,a));
    }
    return report();
  }
  function validate(input,decision){
    if(!decision||!Array.isArray(decision.route))return {valid:false,complete:false,reason:'invalid_decision'};
    try{var m=prepare(input);if(decision.sourceFingerprint!==undefined&&decision.sourceFingerprint!==m.fingerprint)return {valid:false,complete:false,reason:'snapshot_changed'};
      var r=replayPrepared(m,decision.route);
      if(r.valid&&(decision.complete===true&&!r.complete||decision.bestCleared!==undefined&&decision.bestCleared!==r.cleared||decision.totalCards!==undefined&&decision.totalCards!==r.totalCards||
        decision.remaining!==undefined&&decision.remaining!==r.remaining||decision.powerUses!==undefined&&decision.powerUses!==r.powerUses))return Object.assign({},r,{valid:false,reason:'false_claim'});
      return r;
    }catch(e){return {valid:false,complete:false,reason:e&&e.message||'invalid_snapshot'};}
  }
  return {plan:plan,replay:replay,validate:validate,invalidate:function(){session=null;last={version:1,status:'unavailable',reason:'invalidated',model:'known_board_deterministic_powers'};},diagnostic:function(){return JSON.parse(JSON.stringify(last));}};
})

# SDK Client 3.23.11 / build 61 — retomada Auto/Raio X

Corrige a confusão entre avaliação física em andamento e avaliação capaz de
jogar: uma leitura somente Raio X não desabilita mais o botão Auto nem aparece
como ação enviada. Play apenas arma intenção; não inicia outra avaliação até
terminar a leitura atual. Uma avaliação capaz de agir, timeout incerto, carta
experimental ou contexto perdido continuam com seus bloqueios preservados.

Após o primeiro bootstrap confirmado no documento, ticks nativos usam comando
curto e o runtime já vinculado, sem reenviar todos os scripts a cada 20/40/100ms.
Namespace/documento ausente ou diferente retorna falha fechada; nunca recria
silenciosamente um runtime que possa esquecer uma requisição pendente.

O snapshot não perde estabilidade por simples troca de arrays do Store de
conteúdo equivalente ENTRE leituras completas. Identidade de sessão, conteúdo,
locks, missões, estoque e trocas DURANTE aquisição continuam sendo validados.
A prova exige duas leituras coerentes e estáveis por ao menos 80ms.

O relatório somente leitura agora preserva os resumos sanitizados do snapshot
e do lote Super Fast. O menu distingue falha de sincronização de leitura lenta.
Não inclui IDs de cartas/pacotes, credenciais ou vídeo do usuário no pacote.

Bilhar, Cartas, lógicas de poderes e protocolo Super Fast não foram alterados.
A causa exata de toda espera vista no vídeo não está comprovada sem o JSON
interno. Há regressões reproduzíveis corrigidas; não há promessa de vitória,
latência ou ausência de outros bugs no aparelho. Compilação Apple e execução
física da 3.23.11 permanecem pendentes até nova evidência.

Ver Analysis/V3_23_11-runtime-recovery.md e Validation/V3_23_11-validation.json.

## Histórico preservado — não descreve a versão atual


## Evidência recebida e limites

- Vídeo local mostra a interface 3.23.10 e o botão Auto em Aguarde com Raio X
  ativo. O contexto também apresenta uma reconexão de rede por volta de 02:24.
- O relatório 3.23.10/build60 correspondente registra waiting_stability /
  plan_ready, 12 cartas e 3 tipos. O experimento de carta coberta está idle,
  sem tentativas. Isso NÃO prova ausência de pendência no Auto ou no Super Fast.
- A projeção antiga removia os resumos de snapshot e Super Fast; logo o relatório
  não permite atribuir toda a espera inicial a um guard específico.
- Comparativo sintético reproduz reset contínuo da estabilidade por troca de
  arrays de mesmo conteúdo: versão antiga não fica pronta no intervalo de
  480ms; nova versão conclui a prova em 80ms. Não é medição do iPhone.
- Medição de payload: bootstrap de 193600 bytes, comando quente 581 bytes na
  configuração de teste. Não equivale a medição de FPS/latência no aparelho.
- Timeouts de consultas conhecidamente somente leitura não são classificados
  como jogada enviada. A exclusão física permanece até o callback terminar;
  avaliações capazes de agir continuam incertas e bloqueadas em timeout.

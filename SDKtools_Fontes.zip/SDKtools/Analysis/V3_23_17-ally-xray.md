# Raio X ao assistir aliados — 3.23.17 / build 67

## Falha e correção

A 3.23.16 herda a regra da 3.23.4 que limpa o Raio X quando
`GameStore.isWatcher` está ativo ou `Game.WatchMaskNode` aparece. O teste
anterior exigia esse comportamento. Isso explica a perda dos ícones ao
mudar para a mesa de um aliado.

A leitura visual agora usa a cena exibida, após verificar o vínculo entre
Game, GameLayer e GameStore. O modo de espectador aceita a máscara de assistir
e não exige permissão para tocar cartas. Continua exigindo geometria, cartas
e SpriteFrames válidos; modais, HotTime e transições não verificadas suspendem
o desenho. Não procura dados ocultos na rede nem inventa cartas ausentes.

O caminho visual não consulta as listas da própria mesa no Store como fonte
das cartas do aliado. Desenha os ícones locais com a profundidade escolhida,
sem reutilizar a prova de trio da mesa anterior. A preferência de Raio X
desligado continua sendo respeitada.

## Separação de comandos

Assistir não autoriza jogadas, poderes, retiradas cooperativas ou comandos
experimentais, mesmo quando Auto está ligado. A leitura de fase usada para
ações continua restrita à própria mesa. O resultado de ação conserva
`blocked / external_mode_active`; o resultado visual pode ser `ready`.

Trocar de mesa invalida planos e amostras consecutivas, preservando os
pedidos originais pendentes. A mesa observada não confirma nem repete esses
pedidos. Voltar à própria mesa exige nova estabilidade e as verificações
de confirmação originais. Os ícones são atualizados a partir dos nós atuais,
inclusive ao trocar de aliado.

## Base e compilação

Base de fontes: 3.23.16/build 66, commit
`1545d6fd31eeb100545a5216dad48ac1a3df6c1c`, ZIP SHA-256
`924023956fec0c6791d2fc5dd766f2cff44d5a094f09ff499f0605bb89c25635`.

Entrada para integrar: Release `base-us-6.6.2`, arquivo
`WePlay_US_6.6.2_base.ipa`, SHA-256
`b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4`.
Atualizar ZIP e workflow no mesmo commit. O IPA 3.23.16 recebido é uma
referência do produto anterior, não a entrada do integrador.

## Validação e limites

Os testes JavaScript exercitam o adaptador e o renderer reais com cenas
simuladas, incluindo troca de mesa, máscaras e comandos pendentes.
Os resultados finais e hashes constam de `Validation/V3_23_17-validation.json`.

A compilação nativa Foundation/iPhoneOS requer o workflow macOS/Xcode.
Nenhum IPA 3.23.17 é declarado pronto por esta entrega de fontes; teste físico
pendente. No aparelho, conferir Raio X ligado/desligado, profundidades 1–4,
dois aliados diferentes, retorno à própria mesa e troca durante uma ação
pendente, mantendo os diagnósticos caso o visual seja recusado.

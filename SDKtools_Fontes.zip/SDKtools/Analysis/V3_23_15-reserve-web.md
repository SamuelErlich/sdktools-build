# Reserva e diagnóstico LAN — 3.23.15/build 65

Base: main 3.23.14/build 64, commit 9d375c5d758fa5988d40e800534dc6320d4a0f94.

## Causa e correção

O poder Armazenar usa GameStore.storage_blocks e Block.blockInfo.storage_info
(layer/index). As pilhas podem continuar sem máscara escura, embora uma carta
cubra outra. prepareReserves anteriormente atribuía profundidade zero a toda
carta sem máscara. A profundidade visual agora segue a geometria verificada e
as relações hintBlockedBy. X-ray usa essa profundidade para a reserva; os
campos available/blockedBy e o caminho de comandos originais não mudam.
Reservas sem geometria comprovada não recebem dicas inventadas nem bordas
verdes sobre cartas encobertas. Limite visual de quatro camadas preservado.

reserveXray é um diagnóstico limitado a 32 linhas com tipo, camada, coluna,
posição, profundidade e máscara; totais limitados a 512. Sanitização nativa
fechada, sem IDs originais, URLs, usuários ou mensagens do servidor. O relatório
existente inclui esse diagnóstico após uma leitura do Auto/Raio X.

## Captura manual e fontes pelo painel web

Comandos explícitos capture_start/capture_stop/report_export/sources_export
reutilizam o gravador, gerador de relatório e exportador de fontes existentes.
A captura manual pausa Auto e Raio X. scene_probe registra seis propriedades
observadas de Block: type/state/storageLayer/storageIndex/canTouch/isTouched.
Exige Cocos Creator 2.4.4, componente Block único e geometria 80x90; lê membros
por descritores sem executar accessors. O sanitizador repete versão/geometria,
limites e whitelist. Codec/decoder preservam os campos em full/delta/reference.
Não captura ID original, texto arbitrário, credenciais ou tráfego bruto.

GET /api/export exige o mesmo pareamento/IP/key, UUID de exportação e offset
decimal; nenhuma seleção de caminho ou URL. Um arquivo JSON regular sob
Documents/SDKtools, até 64 MiB, é servido em blocos de 256 KiB. Geração e
estado invalidam callbacks tardios, troca de captura e fim de sessão. Captura
local não passa a ser propriedade da sessão LAN. O cliente verifica tamanho
exato dos blocos e não reenvia comandos automaticamente. A sessão expira pelo
heartbeat original; HTTP continua sem criptografia em rede privada.

## Evidências e limites

Regressão reproduziu zero ícones numa pilha de três reservas sem máscara;
depois da correção aparecem duas cartas encobertas sem alterar disponibilidade.
Testes cobrem download pareado, limites, comandos fechados, exportação por
geração/pasta, privacidade, getters, metadados e reconstrução do relatório.
Testes Foundation compilam os includes/métodos reais no macOS da CI oficial.
O manifesto registra resultados locais; CI e teste físico são estados separados.
Não houve teste físico pelo agente. O usuário deve validar o poder Armazenar,
abrir/fechar chat, retomar a própria mesa e baixar os JSONs no PC.

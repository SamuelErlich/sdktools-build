# 3.23.6 / build 56 — relatório do teste no menu compacto

## Falha corrigida

O menu compacto 3.23.5 manteve o experimento de cartas cobertas, mas não expôs o diagnóstico necessário para investigar a recusa 500. Pedir ao usuário esse arquivo não era operacionalmente viável naquele menu.

Acrescenta **Exportar relatório do teste** nos ajustes avançados de Alpaca. O botão exporta somente estado nativo já observado: não inicia captura, não solicita JavaScript/WebSocket, não envia jogada, não reexecuta o experimento e não limpa suas travas. Continua disponível durante pendência/incerteza e sem uma partida ativa, para salvar a última observação do processo ou um relatório vazio explícito.

## Uso

1. Abra Alpaca no menu e toque a engrenagem.
2. Toque **Exportar relatório do teste** e use a folha do iOS para salvar em Arquivos ou compartilhar o JSON.
3. Envie esse arquivo para examinar `coveredCardExperiment`, inclusive `diagnostic`, `events`, `pending` e `contextLost`.

Não é necessário fazer outra jogada para exportar. Compartilhar ou cancelar não confirma/refaz uma tentativa. Não reinstalar ou reiniciar o app antes de exportar quando quiser preservar a observação da sessão atual.

## Limites e privacidade

Relatório pequeno, limitado a 64 KiB e aos últimos 24 estados fechados. Não contém IDs de usuário, sala, carta, packet_id, URL do servidor, credenciais, payloads ou mensagens arbitrárias. Inclui versão/build públicos e flags/códigos numéricos necessários. O arquivo é local, protegido e excluído de backup; nenhum upload automático ocorre.

É um snapshot do último estado nativo recebido, não uma nova leitura em tempo real. Se o app foi reiniciado ou atualizado, a observação antiga em memória não pode ser recuperada. A mensagem original do servidor relativa ao 500 da versão anterior não foi preservada; exportar agora não a reconstrói. O 500 permanece recusa do protocolo observada, sem causa interna comprovada.

Todos os JS/Lua, o evento original, correlação de ACK/Promise, bloqueios de repetição, física do Bilhar, Cartas e Raio X permanecem byte a byte iguais à base 3.23.5. A alteração não tenta contornar a recusa 500.

## Validação

Testes portáteis e hashes pertencem ao manifesto `Validation/V3_23_6-validation.json`. Fixtures Foundation testam produção com colaboradores simulados; execução desses fixtures, compilação Apple, integração/assinatura do IPA e teste de compartilhamento físico exigem macOS/CI ou aparelho e não são comprovados por uma suíte Windows.

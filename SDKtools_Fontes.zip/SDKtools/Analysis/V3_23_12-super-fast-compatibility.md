# Super Fast — v3.23.12 / build 62

## Evidência e limites

A fixture `Tests/fixtures/super-fast-preflight-v61.json` é projeção fechada do
relatório enviado pelo operador (SHA-256 da origem preservado). App declarado:
WePlay US 6.6.2/build 132. Framework declarado: 3.23.11/build 61.

- Snapshot ready/verified/complete; 5 cartas no board, 1 na bandeja, 2 tipos.
- Super Fast idle/observer_unavailable; submitted=requests=responses=batches=0.
- Tentativa coberta not_armed, attempts=0; sem relação causal demonstrada.
- action_disabled é a última leitura. Não comprova que Auto sempre esteve off.
- Só o bloco catch do preflight pode produzir esse idle+reason na implementação
  antiga. Uma falha posterior de hooks já registraria blocked, não idle.
- `alpaca_fast.js` e `autoplay_tool.js` eram idênticos entre 3.23.10 e 3.23.11.
  Portanto não se atribui uma regressão nova de protocolo à v61 sem evidência.

A implementação agrupava contexto, transporte, métodos, aridade e timers numa
recusa genérica. O próximo ciclo escolhia o mesmo trio e repetia o preflight,
sem tentar o caminho normal. Esse é o deadloop reproduzível. A captura não
distingue aridade, URL, contexto ou outra condição; não se inventa essa causa.

## Alteração estreita

1. Retirar somente a exigência de Function.length: pode ser 0 em wrapper válido.
   A chamada real mantém this e arguments e é encaminhada exatamente uma vez.
2. Exportar observerIssue fechado e compatibility boolean estrito. Sem URLs,
   mensagens de exceção, IDs de cartas/pacotes/salas ou credenciais.
3. Caso de capacidade sem despacho: mesmo contexto, flags normais, socket aberto,
   nenhuma chamada possível, hooks/listeners/timer restaurados => fallback para
   o planejador/controle normal existente, uma carta por vez. TTL 3000ms e nova
   validação de contexto antes de usar; a preferência Super Fast fica ligada.
4. Rajadas ainda exigem WSS e observação de envio, ACK trusted e Promise original.
   Um socket ws:// válido do próprio host só pode usar o controle normal;
   nenhum socket é criado, nenhuma URL ou configuração de TLS é alterada.
5. Contexto inválido, operação ausente, candidato inválido ou Promise ausente não
   recebem fallback. 500, timeout, mismatch, prefixo ou incerteza após invocação
   continuam pendentes; nenhuma quarta tentativa é liberada por um prazo.
6. Falha de restaurar hook mesmo com zero eventos permanece uncertain+pending;
   não é convertida indevidamente em blocked sem pendência.

## Confirmação não é a mesma em todas as rotas

- Rajada: cada pacote correspondente + settlement original + efeito coerente.
- Compatibilidade: caminho original Auto normal, uma ação por ciclo e prova
  estável de efeito local. Não equivale a confirmação explícita pelo servidor.
- Nenhum caminho modifica permissões do GameStore ou fabrica CMD_TOUCH_BLOCK.

## Verificação

Fixtures sintéticas, sem chamadas a servidor ou ao iPhone: wrappers rest/default;
preflight ws/API/hook/timer sem evento; 6 cartas em série; pause/export read-only;
no-op pendente; invalidação por contexto; cooldown retornando a rajadas; restauração
incerta; 500/timeout/mismatch sem fallback. A fronteira Foundation valida os novos
campos e rejeita contradições/valores arbitrários (execução somente macOS CI).

Os totais e hashes finais constam em Validation/V3_23_12-validation.json e no par
ZIP/workflow entregue. Nenhuma compilação Apple nem execução física foi realizada
neste host Windows. Validar especialmente início do mapa, fim da primeira trinca,
modo compatível, novos mapas, cartas retornadas por poder e pausa/toque manual.

## Próxima evidência necessária

Em caso de nova parada, exportar o relatório mesmo sem carta coberta. Conferir
3.23.12/build 62, observerIssue, compatibility, status e contadores submitted /
requests / responses / settled. Um reason diferente ou snapshot incompleto exige
investigar sua própria guarda; não presumir a mesma causa para todo travamento.

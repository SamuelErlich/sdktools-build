# Auto cooperativo — 3.23.16/build 66

Usuário aprovou a estratégia de avançar cedo e finalizar com ajuda dos aliados.
Base oficial: 3.23.15, commit c49ae1c70133ed7ef6b553208061e35e893b884a.
Não usa um serviço de linguagem; é busca local limitada por tempo e nós.

## Estratégia

O planejador compara a continuação após cada trio candidato. Uma continuação
comprovada supera uma saída comprovadamente sem próximo trio; estouro do
orçamento fica desconhecido. Isso permite buscar alternativas ao trio guloso,
sem exigir resolver a partida toda antes de jogar. A busca ampliada entra
automaticamente a 75% ou com até 36 cartas restantes, e continua opt-in antes
dessa fase. O progresso é o current_progress original do próprio jogador,
validado entre 0 e 100, sem inferir porcentagem de contadores de processo.

Máximo continua podendo executar uma rota exposta verificada. O atalho de
escolha rápida deixa de anteceder a avaliação cooperativa. Confirmações,
compatibilidade de transporte e todos os bloqueios de contexto permanecem.

## Ajuda do armazém

O coordenador usa a fase completa para incluir até três cartas compartilhadas
num planejamento virtual. Reproduz independentemente o trio e só pode tocar
uma carta de aliado que participe dele. Não retira cartas próprias ou especiais
desconhecidas e não abre a seleção de envio.

Evidência estática: Block.touchBlock trata state=Common(3) pelo UseCommonBlock
original. CommonStoreItem.onBtnClick é o fluxo de envio ao slot vazio; não serve
para retirada. O novo código emite apenas o touchBlock já registrado, sem chamar
Socket/UseCommonBlock diretamente, sem hooks, mutações de estoque ou pedidos
de protocolo próprios. Lock do slot vazio não é inventado como bloqueio de uma
carta ocupada; o handler original mantém as verificações do jogo.

Antes do toque, revalida fase, slot, identidade, componente, registro e entrada.
Uma pendência bloqueia toda nova ação até duas leituras estáveis confirmarem o
slot vazio, o conjunto de cartas locais preservado e a bandeja exatamente
esperada (incluindo o trio removido). Chat/pausa/timeout não liberam reenvio.
Troca de Store/loader/controlador na mesma partida preserva a pendência;
apenas UID/RID/início comprovadamente diferentes permitem aposentar o pedido
após estabilidade, sem contar sucesso. Efeitos mantêm comparação exata por ID.
Sem rota útil, Auto permanece armado esperando mudança do armazém.

## Integração e limites

Extraídos insertAndMatch/validateRoute do adaptador para autoplay_coop.js,
preservando o orçamento explícito. Adaptador continua abaixo de 64 KiB.
Recurso exigido pelo bridge, build e integrador do IPA; mensagens PT/EN e
diagnóstico fechado de fase/progresso/ajudas/pendência nos relatórios e LAN.
Poderes conservam a preferência existente; nenhuma compra ou mensagem.

Testes incluem armadilha de curto prazo, progresso desconhecido, retirada serial
de duas ajudas, slot trocado durante preparação do toque, confirmação exata e
nenhum reenvio após interrupção, missão coberta e caminho serial quando o
transporte não admite Super Fast (inclusive decisão reaproveitada do cache).
A revisão independente reproduziu e verificou as três correções.
A captura do usuário é parcial; não é benchmark
de taxa de vitória. Não houve teste físico pelo agente e não se promete avanço
de 70–80% ou vitória de 100% em toda partida.

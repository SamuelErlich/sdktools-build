# V3.18.1 / build35 — correção do cenário de teste

## Falha recebida

Log: sdktools-build.log, da execução informada https://github.com/SamuelErlich/sdktools-build/actions/runs/38940653922/job/117107136600 .

O log registra Xcode16.4 / SDK18.5, 491 testes JavaScript aprovados, políticas nativas aprovadas e a etapa Billiards live snapshot com 2.589 verificações e seis falhas. Não há erro de compilação mostrado; o processo terminou porque o teste retornou falha. A página do job não pôde ser consultada nesta sessão; a análise se baseia no log anexado.

## Causa reproduzida

O cenário chain_three_balls devolvia uma caçapa a distância8 a partir de cada consulta. A terceira bola inicia em world.z=4; seu segmento terminava em z=12. A câmera sintética projeta y=960+100*z, resultando y=2160, acima da altura1920.

STBilliardsSanitizeSnapshot passa esse ponto a STBLVector e STBLValidPoint. O teste de viewport corretamente retorna falso, e o snapshot sanitizado vira nil. As seis verificações seguintes dependiam desse snapshot: desenho disponível, contadores, segmentos, cadeia, serialização e bloqueio durante movimento.

## Correção

Tests/test_billiards_probe.lua mantém a caçapa fixa em world.z=8 e calcula a distância pela origem e direção. A terceira trajetória termina em y=1760. Permanecem três segmentos, dois contatos entre bolas, três bolas afetadas e os mesmos limites.

scripts/test_billiards_probe.py verifica posição da caçapa, profundidade e limites da tela para os seis extremos. Tests/billiards_live_snapshot_test.m mantém o cenário defeituoso como entrada que deve ser rejeitada, tanto em aiming quanto moving.

O código de física, renderer, sanitizador, ponte, políticas e exportação do produto não mudou. Atualizaram-se somente os metadados para3.18.1/build35. Alpaca permanece igual e Cartas desativado.

## Evidência de validação

56 testes Lua,28 de empacotamento e9 de propriedades Objective-C aprovados. Política C:196 verificações aprovadas.

Foi compilada a própria função STBLValidPoint do header de produção para receber as coordenadas geradas pelas versões antiga e corrigida. O teste reproduziu exatamente um extremo inválido na antiga, y2160, e aceitou todos os seis extremos corrigidos. Resultado em Validation/V3_18_1-viewport-regression.json.

O harness Foundation ampliado está no fluxo macOS. Ainda não foi executado nesta revisão no ambiente local Linux; não há IPA compilado nem novo resultado de GitHub confirmado. Não foram removidos testes ou relaxadas proteções.

## Como retomar

Enviar juntos SDKtools_Fontes.zip e .github/workflows/compilar.yml deste pacote ao repositório. Iniciar uma nova execução no commit atualizado; repetir o job antigo usa fontes antigas. Confirmar V3.18.1 nos nomes do preflight/artefatos.

Após build aprovado, assinar e instalar WePlay_US_6.6.2_SDKtools_v3_18_1_unsigned.ipa. A validação funcional das guias ampliadas continua pendente: mira parada, sequência entre bolas, rebate, caçapa e captura imediatamente após a tacada.

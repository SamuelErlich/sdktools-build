# V4.0.3/build 78 — Timeout intent and full-hand ally X-ray

The user reports Auto stops after table updates and displays
“Auto pausado: confira a partida”. That text confirms an automatic safety
pause; the floating Pause control alone did not establish that Auto was armed.
No current device diagnostic JSON has been supplied, so these fixes cover
reproduced paths rather than uniquely identifying the physical incident.

## Intermediate callback timeout

The bridge emits dispatch_uncertain/evaluation_timeout with physicalPending
true after two seconds without its WebKit completion. It retains its exclusive
inFlight lock and batch latch. The recorder nevertheless cancelled Play
intent permanently; a valid late completion could not continue normal play.

Only this intermediate notification now preserves Auto intent. The existing
physical lock and autoplayBusy prevent any second evaluation, and native batch
reconciliation still requires the final callback. Submission errors, final
unknown results, lost context, server/ACK uncertainty and explicit user pause
retain their existing behavior. No late callback turns Auto back on after a
manual pause. The wait message is localized to English and Portuguese.

The production boolean pause policy is exercised across all eight boolean
cases in portable JS and native C. The Foundation bridge fixture checks the
actual delayed callback and exclusivity with the same production policy.

## Read-only full hand

Snapshot rejected tray length >=7 before rendering X-ray, including spectator
tables whose original input was already disabled. Read-only verified ally
snapshots now accept exactly seven hand cards; >7 and own full hands remain
blocked. No ally actions, confirmations or trio recommendations are enabled.

Tests reproduce tray_full before the fix and check icons, untouched input,
absence of dispatched events and the full-hand limits. Existing spectator
ownership, modal, batch/warehouse pending and own-board guards remain.

## Ally move suggestion clarified by the user

The user clarified that icons were visible but the move suggestion was absent.
The spectator branch explicitly passed null proof, suppressing all trio borders.
It now builds a hypothetical availability model in SDK-owned rows only and
asks the existing independent advisory planner to prove a trio after stable
visual reads. Only ordinary, unlocked, geometrically exposed cards are initially
available; original buttons/flags, Store and pending own actions are untouched.
The branch always returns before action code and never advances own phase proof.

Any model change discards the old suggestion and requires a new stable proof.
No border is shown without a valid trio, including a full hand with no legal
pick. Current physical incident still requires its JSON for unique attribution.

## Validation limits

Local and official CI evidence is recorded in the manifest and delivery files.
Physical iPhone behavior is not tested here. A separate exploratory Node VM
benchmark on old 228-card geometry is not a phone performance measurement;
no time-budget increase or speculative performance change was shipped.

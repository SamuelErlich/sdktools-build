# SDKtools V4.0.0 / build 75 — Auditoria e correções

Data: 20/10/2026. Base de comparação: 3.23.24/build 74, commit local
`89e399e589205dd73117c33df8711dbe4c3f8945`.

## Resultado e alcance

A V4 consolida correções de falhas reproduzidas no menu, nos poderes do Auto,
na ponte nativa, nos indicadores da cena, no navegador e nas ferramentas de
captura/empacotamento. A auditoria combinou leitura dos caminhos de execução,
reprodução contra a base anterior, simulações determinísticas, regressões e
revisão independente das alterações mais sensíveis. Não significa ausência
comprovada de todos os bugs possíveis.

Foram revisados o menu e os controles flutuantes; contexto e autorização de
ações; planejador, cooperação, lotes, poderes e armazém; Raio X e contagens;
observadores de cartas; bilhar/Lua; painel LAN, exportadores, codec e integrador.
Arquivos históricos de análise e fixtures antigas foram preservados. As fontes
originais do jogo foram usadas como evidência estática, sem executar o cliente
ou contatar seu servidor.

## Falhas corrigidas

Gravidades abaixo indicam impacto funcional neste projeto, sem classificação CVSS.

| ID | Gravidade | Falha e reprodução | Correção |
|---|---|---|---|
| M01 | Média | O label de status do Raio X era criado oculto e nunca atualizado; ativar a opção não revelava erros ou estado. | Vincular texto ao estado do recorder e exibir enquanto a opção estiver ativa. |
| M02 | Média | O status do Auto com lote/poder/missão era limitado a duas linhas. | Permitir quebra completa dentro do painel rolável já limitado pela tela. |
| M03 | Média | Super Fast podia alterar a preferência com contexto de jogo obsoleto. | Revalidar o jogo no momento da ação, como os demais controles. |
| M04 | Baixa | Títulos localizados longos excediam botões em painéis estreitos. | Escala mínima de 0,8 para o título, mantendo área de toque de 44 pt. |
| M05 | Baixa | Abrir/fechar idiomas substituía o valor acessível do idioma selecionado. | Preservar a vinculação do valor selecionado. |
| A01 | Média | Abrir poder pelo Auto, pausar, confirmar manualmente e retomar deixava o coordenador em `opening`. | Consumo exato de uma unidade muda para observação; o efeito exato e duas leituras estáveis continuam obrigatórios. |
| A02 | Média | Trocar `Socket.uid` após abrir o poder ainda permitia confirmar; sala inicial divergente também era aceita. | Exigir igualdade de UID/RID entre socket e GameStore antes de abrir, confirmar ou reconciliar o poder. |
| N01 | Média | Uma avaliação sem autorização para agir, iniciada antes de Play, podia retornar sem documento/resultado válido e pausar o Auto como envio incerto. | Classificar pelo potencial de ação da avaliação original; falha de leitura é bloqueio, falha de possível envio continua incerta. |
| N02 | Alta | Exceção em callback de validação de contexto/observação podia escapar e impedir reconciliação. | Conter exceções e reportar falha de contexto; preservar incerteza de ações possivelmente emitidas. |
| N03 | Alta | Timeout físico sem diagnóstico de lote marcava perda definitiva de contexto; resposta válida tardia não recuperava o latch. | Preservar estado enquanto a avaliação física está pendente e reconciliar somente a resposta final. |
| X01 | Média | Remover/destruir indicador ou linha de contagem com snapshot idêntico mantinha o Raio X em `ready` sem o visual. | Validar nós, componentes e parentesco antes de usar o cache; recriar apenas visuais inválidos e limpar filhos próprios destacados. |
| X02 | Média | Marcadores de cores e badges de mão do módulo de cartas apresentavam a mesma falha de vida útil. | Validar e reconstruir o visual correspondente, preservando nós válidos. |
| L01 | Baixa | O navegador mostrava sempre pedidos `/3`, inclusive lote 2 ou já concluído. | Separar limite escolhido de quantidade realmente submetida; esconder contadores antigos e reconhecer pendência provisória. |
| L02 | Média | Perda de conexão mantinha totais e idade de leitura com aparência atual. | Limpar os dados vivos, indicar indisponibilidade e exigir reconexão para nova leitura. |
| L03 | Baixa | Botões de captura/exportação permaneciam habilitados contra as regras nativas de propriedade da gravação. | Refletir gravação ativa, dono da captura e coleta em andamento. |
| L04 | Média | Ocultar a aba durante download deixava Auto ativo: os blocos renovavam a sessão enquanto `busy` impedia pausa. | Cancelar o download em curso quando Auto está ativo e solicitar uma pausa sequenciada após liberar o transporte. |
| D01 | Média | `sceneNodesEncoding: []`, `status: []` ou `cocos: null` em diagnóstico causavam `TypeError`/`AttributeError`. | Validar discriminadores, raiz e objeto Cocos antes de acessar campos ou consultar conjuntos. |
| D02 | Média | JSON com `1e9999` era aceito como infinito apesar do limite de números finitos. | Rejeitar overflow numérico na leitura; preservar valores finitos como `1e308`. |
| D03 | Baixa | Inteiro acima do limite de dígitos do Python escapava da API com `ValueError` genérico. | Normalizar falhas do parser para `CaptureDecodeError`; CLI continua sem traceback/arquivo parcial. |
| R01 | Baixa | Exportadores de fontes e bilhar ainda identificavam o resultado como 3.21.0. | Alinhar relatórios, menu, framework e integrador em 4.0.0/build 75; adicionar teste de consistência. |
| P01 | Média | `LC_TWOLEVEL_HINTS` era considerado sem payload; hints zerados podiam ser sobrescritos pela dependência injetada. | Validar comando e intervalo de `nhints × 4`; proteger esses bytes no cálculo de espaço livre. |
| P02 | Média | Diretórios ZIP implícitos com grafia/case/normalização Unicode divergentes eram aceitos; `dir//` também. | Validar todos os prefixos de caminho e rejeitar aliases e separadores repetidos. |

P01/P02 são defeitos latentes demonstrados em fixtures sintéticas. Não há evidência
de que o IPA base conhecido contenha esses layouts problemáticos.

## Evidência dos cenários críticos

### Auto e poderes

O caso A01 foi reproduzido para Storage, Withdraw e Refresh. A recuperação não
repete a confirmação: apenas observa a queda exata de estoque e aguarda o efeito
esperado no tabuleiro. Estoque sem efeito, efeito errado, modal remanescente,
mudança de sala/rodada e confirmação tardia foram exercitados. Uma revisão
independente executou oito cenários adicionais sem encontrar reenvio indevido.

A02 foi verificado contra o bundle original: `Socket.send` usa UID/RID da conexão.
Antes da correção, mudar UID entre abertura e confirmação produzia dois eventos,
quando somente o primeiro deveria existir. Mudar UID durante estabilidade ainda
confirmava o efeito. Os testes agora recusam essas situações e sala divergente.

O teste portátil de N03 removeu deliberadamente a nova guarda de avaliação física
pendente: quatro verificações falharam. Com a correção, uma resposta tardia válida
pode liberar o estado provisório; uma resposta final sem contexto/diagnóstico
válido continua preservando a incerteza. Timeout não cancela uma requisição e não
autoriza repetição. Os testes Foundation da ponte foram escritos, mas não executados.

Os testes existentes cobrem 1/2/3 cartas, ACK parcial/recusado, capacidade antes
da animação, mesa de aliados, rota com continuação coberta e proteção dos diamantes.
Incluem oráculo independente de 120 tabuleiros e 80 simulações de grafos de cobertura.

### Visuais, menu e navegador

Quatro novos grupos de regressão falhavam antes das correções de cache; passaram
em 23 cenários de nós/componentes danificados. Objetos válidos permanecem no cache,
sem redesenho desnecessário. As seis verificações novas do menu demonstram as cinco
regressões M01–M05; a extração de fontes continua exclusiva do navegador.

No navegador, foram exercitados disconnect durante consulta/comando, lote 2,
lote provisório, captura pertencente a outro fluxo e aba oculta durante download
ou resposta de Start. Uma resposta de comando perdida encerra a conexão local
sem repetição automática. A pausa enfileirada usa a próxima sequência somente
quando o transporte tem resposta conhecida. Download interrompido não salva
arquivo parcial e não repete a captura. A revisão independente também encontrou
pausa duplicada ao ocultar durante uma pausa manual já pendente; a correção final
reconhece essa pausa em curso e um novo teste verifica ACK e resposta perdida
sem emitir uma segunda pausa.

### Capturas e integrador

O decoder agora recusa os três casos de metadados que anteriormente provocavam
traceback. O CLI retorna código 2 e não cria saída nesses casos. Capturas válidas
de schema 2/3, deltas, referências e valores numéricos finitos continuam cobertos.

Os novos testes do integrador produziam dez falhas contra a base 24. Depois das
correções, 47 testes passaram. Uma varredura determinística de 2.000 mutações
(seed 20261020) obteve 410 injeções válidas, com payload preservado, e 1.590
rejeições controladas, sem exceções inesperadas. Revisão independente adicionou
200 casos de fronteiras Mach-O, assinatura, Unicode e ordens de diretórios ZIP.

## Validação executada

| Verificação | Resultado local |
|---|---:|
| `node --test Tests/*.test.cjs` | 1.162 aprovados, zero falhas/ignorados |
| `python3 -m unittest discover -s Tests -p 'test_*.py' -v` | 178 executados; 177 aprovados; 1 ignorado |
| Política C de jogo | 51 verificações aprovadas |
| Layout compacto C | 164 verificações aprovadas |
| Controles flutuantes C | 10.676 verificações aprovadas |
| Política C de nova captura | 22 verificações aprovadas |
| Política C de ação/lote | 50 verificações aprovadas |
| IO C de fontes | 120 verificações aprovadas |
| Política C de bilhar ao vivo | 250 verificações aprovadas |
| Política numérica C, com sanitizers | 55 verificações aprovadas |
| IO C de recursos do bilhar | 116 verificações aprovadas |
| Identidade/contexto Lua | 8 casos aprovados |
| Probe Lua do bilhar | 68 testes aprovados |
| Estratégia Lua do bilhar | 124 assertions aprovadas |
| Fronteira de callbacks Lua | 10 casos aprovados |

As suítes focadas dos módulos são subconjuntos dos totais JavaScript/Python;
não devem ser somadas novamente. O teste Python ignorado é interoperabilidade
do codec Foundation, que exige macOS. As contagens C/Lua são verificações de
políticas e simulações, não testes em iPhone. O adapter Auto tem 64.730 bytes,
abaixo do limite de 65.536 bytes.

## Estado dos pedidos anteriores

- Mantidos lote 1/2/3, pausa/play externos, contornos vermelhos, Raio X de aliados
  e lista lateral de ícones/quantidades. Os lotes usam callbacks originais na
  mesma execução, com pedidos e confirmações individuais; não existe endpoint
  atômico de múltiplas cartas identificado no cliente original.
- Não foi medido o tempo real para atingir 50–60%. Nenhum ganho percentual de
  velocidade é alegado a partir de simulações.
- O Auto continua bloqueando **todos os diamantes**, em qualquer carga. O código
  original fornece porcentagem atual, mas não ganho por trio; o limite exato de
  “falta um trio para 100%” permanece desconhecido. Esta proteção conservadora
  não controla ações de aliados, ações manuais ou eventos do servidor.
- Extração de fontes permanece no navegador; nenhum botão correspondente foi
  acrescentado ao menu mobile.

## Compilação e entrega

Fontes e workflow preparados para 4.0.0/build 75, mantendo a Release original
`base-us-6.6.2`, asset `WePlay_US_6.6.2_base.ipa`, bundle
`com.wejoy.weplay.us`, versão 6.6.2/build 132, arm64/iOS 15.

O ambiente local é Linux, sem Xcode/iPhoneOS SDK, xcrun, codesign ou clang.
**Não foi compilado, assinado, instalado nem executado um novo IPA.** A compilação
Apple e os testes Foundation/UIKit permanecem como gates do workflow macOS.
Testes no jogo real ainda precisam confirmar comportamento visual, latência,
troca de mesa, pausas e retomadas. A validação local não substitui esses gates.

O par entregue deve ser atualizado junto: `SDKtools_Fontes.zip` e
`.github/workflows/compilar.yml`. O preflight do workflow valida tamanho, SHA-256,
caminhos, CRC e todos os hashes do manifesto antes de extrair. O resultado
previsto é `WePlay_US_6.6.2_SDKtools_v4_0_0_unsigned.ipa`.

Esta entrega é uma consolidação de fontes revisadas com correções verificadas no
escopo disponível. O manifesto `Validation/V4_0_0-validation.json` registra a
base, os arquivos alterados, os hashes e as limitações da validação.

# SDKtools V3.6: menu por jogo

## Navegação e controles

O painel mantém a bolha flutuante, o fundo escuro e as cores laranja/vermelho. O seletor **Alpaca / Cartas** mostra apenas um módulo de cada vez; a última seleção fica salva no dispositivo. Selecionar outro módulo muda somente a interface, sem iniciar, pausar ou confirmar ações.

**Crazy Alpaca** contém Iniciar/Pausar autoplay, Raio X, Camadas abaixo (1–5), Meu armazém e os controles Esquerdo/Central/Direito dos poderes originais. A confirmação do poder continua separada e o estoque continua sob controle do jogo. Os nomes dos efeitos não são inferidos pela posição do botão.

**Ah, minha carta** contém Ver cartas/Ocultar cartas e o estado atual da leitura. O texto descreve ícones das cartas identificadas pelo jogo; não afirma que cartas desconhecidas ou versos tenham identidade disponível.

**Suporte** começa recolhido. Contém apenas Iniciar/Parar diagnóstico, estado da coleta e Exportar relatório. O diagnóstico do módulo Cartas chama a investigação local do jogo 2007, com limite de 90 segundos. O diagnóstico do módulo Alpaca chama a captura original. Apenas tocar para iniciar ativa uma coleta; abrir Suporte ou fechar o painel não grava nada. O botão Parar encerra a coleta ativa mesmo após trocar o módulo exibido.

Não existem botões de detecção de novo jogo, marcação de entrada/partida, exportação de código ou ReplayKit na árvore de views do menu. Os métodos nativos preexistentes foram mantidos internamente para evitar alterações desnecessárias nos fluxos de ciclo de vida.

## Revisão de integração

- `togglePanel`, `selectModule` e `toggleData` não chamam ações de jogo nem métodos de gravação.
- A observação de toques existente em `STObservedSendEvent` ignora janelas SDKtools antes de pausar autoplay por toque manual; fechar a bolha não equivale a tocar no tabuleiro.
- Os botões removidos foram retirados das propriedades e dos arrays de atualização. Os nove botões que recebem ajuste de opacidade são criados incondicionalmente em `loadView`; não há entrada nil de controles removidos em literais NSArray.
- Exportação sem histórico (`SDKtools.Recorder`, código 1) orienta usar uma ferramenta ou iniciar o diagnóstico em Suporte; outros erros preservam a mensagem anterior.
- O compartilhamento de relatório ancora no botão existente. O caminho interno de compartilhamento de código usa a bolha, mesmo sem botão dedicado na interface.
- Cada módulo e a seção Suporte usam um wrapper recolhível com restrição inferior de prioridade 999. Os controles internos preservam alvos de toque sem disputar a altura zero dos módulos ocultos.
- A largura máxima é 350 pontos, limitada à área segura. A altura é limitada à tela e o conteúdo pode rolar. O módulo Cartas ocupa menos altura que Alpaca.
- Os controles interativos possuem pelo menos 44 pontos de altura. Fontes usam UIFontMetrics; no tamanho de acessibilidade os três poderes passam para disposição vertical. O slider aceita incrementos inteiros por VoiceOver de 1 a 5.
- Botões e cabeçalhos possuem rótulos de acessibilidade; a mudança de módulo anuncia o controle principal. O painel aberto concentra a navegação assistiva e o painel fechado mantém a partida acessível.

## Verificação e limites

Foi feita revisão estática dos alvos de ação, propriedades remanescentes, limites de altura, wrappers ocultos e separação entre navegação/ações. A verificação de estrutura confirmou delimitadores balanceados e nenhuma implementação de método dentro de uma interface Objective-C.

Não houve execução UIKit, compilação com SDK Apple ou interação no iPhone neste ambiente. O Actions deve compilar a versão e a revisão no dispositivo deve confirmar abertura/fechamento, troca de módulos, rolagem em tela pequena, slider de camadas, pausa explícita, confirmação original dos poderes e exportação de relatório.

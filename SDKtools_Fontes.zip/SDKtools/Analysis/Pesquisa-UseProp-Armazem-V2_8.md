# UseProp e armazém — SDKtools V2.8

Análise de 14/10/2026. Alvo: WePlay US, `com.wejoy.weplay.us`, versão 6.6.2, build 132, minijogo 60, Cocos 2.4.4. As conclusões abaixo separam código observado, comportamento registrado e perguntas ainda abertas. A V2.8 acrescenta coleta; a abertura irrestrita de armazéns e o uso ilimitado de poderes não foram implementados.

## O caminho de UseProp já identificado

O componente `Prop` abre a confirmação original com `showUsePropAlert(this.propInfo)`. O método observado verifica antes `getIsWatcher()`. Isso evidencia uma condição de espectador, mas não identifica o proprietário de cada armazém.

Na janela `UsePropAlert`, o método `setup` reconhece os tipos `Storage`, `Withdraw`, `Refresh`, `Penetrate`, `Bomb` e `remove`. Quando `count === 0`, desabilita e acinzenta o botão de uso e mostra o aviso de estoque vazio. A janela agenda seu fechamento em quatro segundos.

O método completo capturado da confirmação contém este encadeamento:

```javascript
onBtnUseClick() {
  if (h.default.playClickCommonBtnAudio(), this.close(),
      this.propInfo.type === r.PropType.Penetrate) {
    return d.default.setIsUsingPenetrateProp(!0),
      this.close(),
      void l.Emitter.fire(g.CustomMessage.UpdatePileBlockTouchState);
  }
  c.default.UseProp(this.propInfo.id);
}
```

O código acima é evidência capturada, não um método novo executado pelo SDKtools. Há um caminho especial para `Penetrate`; não se deve presumir que todos os poderes terminem na mesma chamada.

**Falta o corpo de `c.default.UseProp`.** `c` é uma dependência lexical do módulo. O texto de uma função não fornece o valor dessa variável. Os relatórios atuais não mostram o decremento real do estoque, a solicitação completa nem sua confirmação. Mudar `num`, `propInfo.count` ou a aparência de um botão não demonstraria alteração dessas regras.

Proveniência: `V2_7-power-consumption.json`, cinco métodos completos e sete observações reconstruídas da janela. O relatório principal tem SHA-256 `463e48a56efb0328b65813a3f6598af751e148f78868635ccb9b79f90b81b129`. As cenas foram reconstruídas pelo decoder de deltas de schema 3, sem executar os métodos capturados.

## Dois caminhos distintos de armazenamento

| Elemento observado | Evidência | O que ainda falta |
|---|---|---|
| Poder `Storage` | Três cartas saem da barra e aparecem em uma reserva de 240 × 90 | Regra completa de consumo e retorno das cartas |
| Controles `CommonStoreItem` | Três espaços de 84 × 94, em uma linha de 260 × 94 e painel de 272 × 126; cada botão resolve `onBtnClick` no próprio componente | Corpo do método, dono, condições de abertura e efeito de cada clique |
| Mudança de observador | Existe `Game.onClickChangeWatcherBtn` | Relação entre tela observada, jogador local e disponibilidade do armazém |

O painel dos `CommonStoreItem` tem a identificação de sprite `d0a9f790`, local à captura. Sua geometria e o evento registrado formam a assinatura observada usada pelo coletor. Os três espaços não provam a existência de três armazéns diferentes. O clique pode inserir, retirar ou liberar uma posição; ainda não há evidência suficiente para chamá-lo de “abrir armazém”.

Foram examinadas 659 amostras de seis relatórios. O relatório principal contém 299 observações de controles `CommonStoreItem`, sendo 297 em cenas completas. Não contém o corpo de `CommonStoreItem.onBtnClick`. Uma carta aparece brevemente em um espaço em outra sequência, mas esse dado não identifica seu proprietário nem confirma uma transferência entre jogadores. Os detalhes estão em `V2_8-warehouse-evidence.json`.

## Como a V2.8 obtém a evidência que falta

### Rastrear poderes e armazém

Com o rastreamento explicitamente ativado, o probe procura uma única linha que corresponda à assinatura observada, verifica os três eventos `onBtnClick` e lê os métodos dos respectivos componentes. Registra também campos primitivos permitidos, como estado, índice, quantidade e indicadores de abertura, quando existirem, e os nomes limitados dos componentes da linha e do painel.

Os métodos registrados dos poderes e dos espaços têm prioridade sobre métodos auxiliares. O orçamento de fonte é compartilhado: 49.152 caracteres, até 8.192 por método. Cenas incompletas, alvos ambíguos e trechos truncados são identificados. A camada nativa limita novamente o resultado antes de gravá-lo. Nenhum método do armazém é invocado por essa inspeção.

### Exportar código do jogo

A análise do carregador nativo identificou `WPDownloadManager.gameResDownloadPath:` e `WPCocosGameViewController.loadCurrentGame`. O caminho derivado para o jogo 60 em produção é:

```text
Caches/littleGame/60_game/game_res/web-mobile/index.html
```

A V2.8 confirma a identidade do app, o controlador do jogo e a página local atualmente aberta. Depois lê somente arquivos `.js` dessa raiz. O botão produz um arquivo `SDKtools-GameSources-….json` com caminhos relativos, fonte completa dos arquivos aceitos, SHA-256, posições de termos relevantes e limites ou omissões encontrados. Não carrega módulos nem executa os fontes para descobrir dependências.

O Cocos 2.4 pode colocar código compilado em `index.js` ou `game.js` de cada bundle, além dos scripts de inicialização. Por isso a busca contempla a raiz, `src` e bundles em `assets`, inclusive nomes versionados; não depende de um único `project.js` presumido.

Limites: 16 MiB por arquivo, 32 MiB de fonte incluída, 128 arquivos incluídos, 256 candidatos, 4.096 entradas, profundidade 8 e orçamento cooperativo de 10 segundos. O JSON final tem teto de 64 MiB. Links e arquivos especiais são recusados. Arquivos alterados durante a leitura são descartados; o diretório, a entrada e o contexto da tela são conferidos novamente ao concluir. A coleta pausa captura e autoplay e precisa ser iniciada pelo usuário. O compartilhamento é escolhido no iOS.

O resultado representa os arquivos presentes no disco durante a leitura. Não é uma captura atômica do pacote inteiro nem prova de que esses bytes sejam exatamente os já carregados na memória. Códigos remotos ou arquivos ausentes podem continuar fora da coleta.

## Próxima captura no iPhone

1. Com a V2.8 instalada, abra o Crazy Alpaca, aguarde o tabuleiro e deixe o autoplay pausado.
2. Toque em **Exportar código do jogo** e salve o JSON. Mantenha a partida aberta até concluir.
3. Ative **Rastrear poderes e armazém**, inicie uma captura manual e use os controles originais para mostrar a abertura e o fechamento do seu armazém. Registre a colocação e retirada de uma carta se esse fluxo estiver disponível.
4. Se o jogo permitir visualizar um armazém de aliado, registre essa navegação também e indique qual é o seu. Não é necessário gastar poderes apenas para preencher uma lista.
5. Se usar algum poder, deixe a confirmação visível por cerca de um segundo e aguarde seu efeito e a atualização da contagem. Pare a captura e exporte `SDKtools-Capture-….json`.
6. Envie os dois JSONs e indique quais ações realizou. Vídeo ajuda a associar a interface aos componentes, mas não substitui o código e as mudanças de estado.

Com esses dados, o próximo trabalho é resolver estaticamente o módulo de `UseProp`, seguir suas dependências e mapear o método de armazém até seu efeito e confirmação. A existência de um botão ou de código cliente não basta para concluir que seja possível abrir o próprio armazém em qualquer estado ou abrir armazéns de outros jogadores.

## Referências e validação

Evidências locais: `Return-limit-investigation.json`, `V2_7-power-consumption.json`, `V2_8-warehouse-evidence.json` e os hashes dos relatórios ali registrados. A evidência nativa corresponde ao executável SHA-256 `2a1d3c9832a5e7158e72404ce0d139165bb3e348707d5e427271b264da6c79cc`, UUID `22f12a1a-f282-346a-9c98-a4646d8802ef`.

Referências primárias consultadas:

- Cocos Creator 2.4, conteúdo de Asset Bundles: https://docs.cocos.com/creator/2.4/manual/en/asset-manager/bundle.html
- Cocos Creator 2.4, carregamento e versionamento de bundles: https://docs.cocos.com/creator/2.4/manual/en/scripting/asset-bundle.html
- Cocos Creator 2.4, publicação web: https://docs.cocos.com/creator/2.4/manual/en/publish/publish-web.html
- Apple, carregamento de arquivo no WKWebView: https://developer.apple.com/documentation/webkit/wkwebview/loadfileurl(_:allowingreadaccessto:)
- WePlay e central de ajuda: https://www.weplayapp.com/ e https://help.weplayapp.com/

A consulta pública não forneceu uma regra oficial verificável de abertura dos armazéns do Crazy Alpaca. Isso não prova que a regra inexista. As referências Cocos e Apple explicam o mecanismo técnico, não as regras particulares do minijogo.

Resultados finais dos testes e hashes ficam em `Validation/V2_8-validation.json` e `VALIDACAO_PACOTE.json`. Testes portáveis não substituem compilação com o SDK Apple, assinatura nem teste no iPhone. Essas etapas serão feitas pelo workflow e pelo aparelho.

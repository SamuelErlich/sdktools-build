# Lista na lateral esquerda — 3.23.22 / build 72

Referência visual: imagem menu previel.png enviada pelo usuário. Apenas as
marcações vermelhas foram usadas; os textos da imagem foram ignorados.
Na referência de 739×1600, os espaços ficam aproximadamente entre x=34 e 92,
começando em y=160, com cerca de 58 px de altura e intervalo de 6 px.

A lista foi reposicionada para a margem esquerda, começando a cerca de 10%
da altura da camada do jogo abaixo do topo. Cada tipo ocupa uma célula
compacta, com o ícone original em cima e a quantidade embaixo. A lista não
muda para a direita quando não cabe. A geometria deve permanecer dentro do
jogo e sem sobrepor as cartas ou os recipientes conhecidos; caso contrário,
a lista é ocultada inteira, sem truncar tipos ou interferir no Raio X.

O total permanece sendo mesa + reserva + bandeja da mesa exibida, incluindo
cartas cobertas carregadas em qualquer profundidade. A identidade do tipo,
a confirmação das jogadas, o Auto e os controles do menu permanecem iguais.

Base: 3.23.21/build 71, commit local
f9e20c0d71871f7479fe2b46d4110544d583d552.
Entrada do integrador: WePlay_US_6.6.2_base.ipa da Release base-us-6.6.2.
Resultados locais em Validation/V3_23_22-validation.json.
Compilação Apple e conferência visual no iPhone continuam pendentes.

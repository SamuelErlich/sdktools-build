# V3.5 — significado dos dados da investigação de cartas

Revisão independente do novo `Resources/card_probe.js` e do contrato de sanitização, sem editar código de produção. A investigação é distinta do renderer de ícones e não promove dados coletados a identidades conhecidas.

## Separação entre observação e identidade

- O probe exige o padrão estrutural observado de raiz 224×295, quatro filhos, base comum com hash **e** retângulo correspondentes e uma frente ou verso compatível. Isso identifica um candidato estrutural; não estabelece valor, naipe ou regra do jogo.
- A captura limitada inclui os ramos base, frente e verso, mesmo quando estão inativos, e preserva `active`, `activeInHierarchy`, `frontActive`, `backActive` e o caminho do filho. Não ativa esses nós nem altera seus sprites.
- Cada carta e nó emitido contém `identityVerified:false`. O sanitizador nativo força esse valor novamente, inclusive no resultado geral, independentemente do valor recebido. O relatório marca `hiddenIdentitiesProven:false`.
- `cpn`, `cpf`, `cpt`, `cpc` e `cpo` identificam objetos locais do probe, dentro do documento/`sceneEpoch`. Não são IDs do servidor, de jogadores ou do scene codec. Compartilhar um frame não significa compartilhar a identidade de uma carta.
- Componentes são examinados por descritores próprios de dados. Accessors são registrados como ignorados; funções, strings e arrays não são expostos como valores. Objetos aninhados são limitados a campos de estado de carta com um nível de profundidade.
- O probe não consulta módulos/catálogos, não executa callbacks do jogo, não envia ações ou rede e não abastece automaticamente o renderer com frentes inativas.

## Como interpretar uma captura futura

Um frame na frente inativa pode ser padrão do prefab, um estado antigo do objeto reutilizado ou a frente atual. Um número em `cardData` ou campo semelhante continua sendo um valor observado sem semântica comprovada. Nenhum desses dois fatos, sozinho, justifica mostrar um ícone sobre uma carta ainda virada.

Para estabelecer um mapeamento será necessário correlacionar uma sequência antes/depois da revelação: mesma época de cena, mesma raiz, mesmos componentes, alterações de estado e a frente real que fica ativa. Repetir com cartas diferentes e objetos reutilizados distingue dados atuais de dados residuais. A continuidade do `nodeID` por si só não prova que uma carta física permaneceu a mesma após uma nova distribuição.

Ausências não devem ser interpretadas como zero ou inexistência: há limites de cartas, nós por ramo, componentes, campos, tempo e payload. As flags `truncated`/`truncationReasons` e gaps no índice da amostra precisam acompanhar qualquer conclusão posterior.

## Limites e revisão estática

O probe limita a descoberta a 4.096 nós e 64 cartas, com 16 nós de ramo e 8 componentes por carta; campos são filtrados e limitados, tempo nominal de 8 ms e payload de 49.152 bytes. A camada nativa aplica limites e esquema novamente. Campos como `seatIndex`/`playerIndex` admitem somente inteiros 0–7; nomes associados a conta, sessão, token, URL, caminho e dados pessoais são filtrados.

Na revisão estática inicial não foi encontrada promoção indevida de frente inativa a identidade comprovada. A classificação continua diagnóstica mesmo quando um ramo inativo contém um símbolo plausível. O significado dos campos comerciais ainda depende dos novos relatórios e da leitura estática de fontes efetivamente exportadas.

`node --test Tests/card_probe.test.cjs` passou **18/18 testes** na execução independente. Os testes incluem raiz estrutural inativa, ambos os ramos, isolamento de IDs, descritores/accessors, filtragem de campos privados, referências restritas à carta, transições sem promoção de identidade, limites e ausência de mutações. São verificações do contrato em fixtures; não constituem observação dos componentes comerciais no dispositivo.

## Atualização da validação final

A revisão independente acima executou os 18 casos existentes naquele momento. Após os dois casos adicionais, a validação final coordenada pelo agente principal registrou **20/20 testes focalizados do probe** e **373/373 testes JavaScript na suíte completa**, sem falhas. Os 20 casos finais incluem os 18 iniciais; não são contagens somadas. A validação no dispositivo permanece pendente.

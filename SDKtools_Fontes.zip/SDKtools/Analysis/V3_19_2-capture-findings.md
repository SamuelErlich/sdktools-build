# V3.19.1 — bloqueio de perfil físico e ausência da guia

Análise somente de leitura, baseada na captura `upload/02-SDKtools-BilliardsLive-8ED89130-14C8-4A58-824D-81810EB2A186.json`, no projeto `sdktools-us-v3191` e na base Unity/XLua recuperada. Nenhum fonte de produto foi alterado nesta investigação.

## Evidência da captura

SHA-256 da captura: `8d1cc27b2f029de0b8aadb466ce537e2becc1afba5db7571c9416f3bfb7571d9`; tamanho 2.955.989 bytes; versão declarada 3.19.1.

- 98 amostras `not_ready`: 95 têm `reason=physics_profile_mismatch` e três têm `reason=aim_snapshot_stale`. O bloco `physics.reason` registra `physics_profile_mismatch` nas 98.
- 1.568 observações de bolas: 16 ativas, nenhuma encaçapada, velocidades linear e angular nulas, posições constantes.
- `power=0` em todas; `sliderMax=powerReference=312.5`; `deadzone=.08`.
- `framePowerValue=221.1949242` e `shotPower` constantes, portanto não representam uma força atual puxada no slider nesta captura. `lastShotObservation` e `lastAimBeforeMotion` ausentes.
- A resolução da partida está selecionada: recurso 20, tipo 1003, `BiFrameLogic` localizado. O problema não é falta de partida, câmera ou coleção de bolas.

| Campo exportado | Valor observado | Critério V3.19.1 | Resultado |
|---|---:|---:|---|
| Massa | 0.4499999881 | 0.45 ± 0.0001 | Passa |
| Drag/angularDrag | 0.5/0.5 | 0.5 ± 0.0001 | Passa |
| Tensor I, três eixos | 0.004900500178 | Positivo, isotrópico | Passa |
| fixedDeltaTime | 0.01999999955 | 0.02 ± 0.000001 | Passa |
| Gravidade Y | -9.81000042 | -9.81 ± 0.01 | Passa |
| Gravidade X/Z | 0/0 | 0 ± 0.00001 | Passa |
| Corte linear²/angular | 0.008/0.2 | 0.008/0.2 ± 0.000001 | Passa |
| I comparado a 0.4mR² | 0.004900500178 | ± 5% de I | Passa **se** R vivo for 0.165; R não foi exportado |

Não há sustentação para mudar esses coeficientes a fim de remover o bloqueio.

## Origem possível do motivo genérico

Em `Resources/billiards_probe.lua`, linhas 641–643 validam globais: todos os campos correspondentes exportados passam. Linhas 668–677 agrupam, em um único motivo, constraints, centro do collider, centro de massa, maxAngularVelocity, massa, damping, raio, relação I/mR² e material da bola. Os últimos dados necessários não aparecem na captura.

A primeira bola que produz um motivo o conserva com `physicsReason = physicsReason or ...`. Uma propriedade ausente costuma gerar `physics_body_unavailable` antes da comparação, mas uma divergência numa bola anterior pode esconder campos ausentes nas seguintes. Assim, `physics_profile_mismatch` sozinho não identifica nem a bola nem o campo.

Fontes recuperados sustentam o perfil esperado, mas não substituem observação viva:

- `BallBehavior:reset`, linhas 623–624: maxAngularVelocity 500 e `CS.UnityEngine.RigidbodyConstraints.FreezePositionY`.
- `ballNotPot`, linha 527: também restabelece FreezePositionY.
- `ballPot`, linha 490: usa None, mas bolas encaçapadas/inativas não participam da validação desta captura.
- Prefab original: collider.center e centerOfMass nulos, constraints 4, massa/drag compatíveis. Inércia automática: o tensor serializado 1,1,1 não deve ser usado.

## Defeito concreto na comparação de enums

O código compara `record.constraints ~= 4` e `tostring(record.constraints) ~= "FreezePositionY"`. Material usa a mesma estratégia para Maximum/3 e Multiply/1. Isso contempla números Lua e nomes puros, mas não o formatter da ponte da própria base.

A auditoria independente encontrou `XLua.StaticLuaCallbacks.ToString` na metadata Main.dll, método 33402, token `0x0600827b`, VA de arquivo ARM64 `0x40c7700`. O trecho contém dois dispatches virtuais, conversão Int32 para texto, literal `": "`, String.Concat e PushAny, correspondendo ao callback upstream `obj.ToString() + ": " + obj.GetHashCode()`.

Evidência: `Analysis/V3_19_2-xlua-tostring-arm64.json`. VA de arquivo não é endereço de processo com ASLR.

Consequência: um enum encapsulado pode ser apresentado como `FreezePositionY: 4`, `Maximum: 3` ou `Multiply: 1`, recusado pelos checks atuais apesar de correto. A incompatibilidade do check está demonstrada; a captura atual não exporta os enums para confirmar qual deles causou o bloqueio na sessão.

## Compatibilidade legítima proposta

1. Comparar o getter com o membro tipado correspondente em `CS.UnityEngine.RigidbodyConstraints` ou `PhysicMaterialCombine`, usando pcall e registrando o resultado.
2. Aceitar número Lua inteiro somente quando for exatamente o valor permitido. Não usar truthiness ou somente presença de userdata.
3. Quando necessário, recorrer a uma conversão explícita disponível da ponte, ou chamada gerenciada `ToString()` em vez do `tostring` Lua. Registrar qual método resolveu o enum. Disponibilidade dos wrappers ainda precisa ser verificada.
4. Se houver fallback textual, aceitar somente formas delimitadas e verificadas para o enum esperado, incluindo o formato XLua identificado. Não aceitar substring `FreezePositionY`: combinações com eixos/rotações adicionais continuam incompatíveis. Não usar hash isolado de objeto arbitrário como valor do enum.
5. Preservar validações numéricas do corpo/material. Um valor físico realmente diferente deve produzir um motivo específico e manter a previsão finita indisponível.

## Campos de diagnóstico necessários

Exportar uma lista limitada de verificações por bola, no máximo 16 bolas e quantidade fixa de campos; separar a primeira falha do conjunto completo. Cada verificação deve informar `tag`, `field`, `available`, `passed`, valor observado normalizado, esperado/tolerância e método/fonte da leitura. Erros de getter devem ser distinguíveis de nil por um código breve, sem serializar objetos nativos.

Campos vivos mínimos: `radiusWorld`, `radiusLocal`, `lossyScale`, `colliderCenter`, `centerOfMass`, `maxAngularVelocity`, constraints (tipo Lua, texto limitado, inteiro normalizado, método), material disponível/ID, dynamicFriction, staticFriction, bounciness, e ambos combine modes com o mesmo diagnóstico de enum. Manter massa, damping, tensor e vetores já existentes.

Separar `expectedProfile=cache1084_physics_v1` de `materialObservationSource=live/cache/unavailable`. A string atual `materialSource=cache1084_profile` não informa que o material vivo foi efetivamente lido e comparado.

Esses campos precisam atravessar a fronteira nativa: `Sources/SDKtools/STBilliardsLiveSnapshot.m`, `STBLBallDynamics` linhas 216–228 e `STBLPhysics` linhas 229–275 têm whitelist explícita. Acrescentar chaves somente no Lua não as torna disponíveis no arquivo exportado.

## Potência zero é um segundo bloqueio independente

Após corrigir o enum/perfil, essas mesmas amostras resultariam em `power_below_deadzone`: 0 < 312.5 × .08 = 25. Não deve ser reaproveitado `framePowerValue` antigo para fabricar alcance atual.

Para preservar a guia de mira, separar previsão geométrica da previsão finita: geometria depende de mesa/bolas/direção atuais e guardas visuais/turno; alcance e parada dependem também de potência atual válida e perfil físico compatível. A guia geométrica pode continuar visível com força zero, marcada como geométrica; não deve apresentar endpoint de repouso, tempo de chegada ou força como se fossem calculados. Ao puxar força acima do limite, habilitar a previsão finita apenas quando os checks passarem.

## Regressões que realmente cobrem a falha

- Enums numéricos, membros tipados e formatter XLua `Nome: inteiro` válidos; invalidar None, combinação de flags e combine mode diferente.
- Perfil com cada campo ausente/divergente deve exportar exatamente a causa e a bola; diagnóstico deve sobreviver ao parser nativo.
- Slider 0 e framePowerValue antigo não produzem repouso previsto; guia geométrica continua elegível quando os demais requisitos de mira passam.
- Força acima da deadzone, perfil validado e cena de mira permitem caminho finite; conflito físico real não é liberado por fallback de enum.

Conclusão: corrigir a representação de enum e tornar o diagnóstico específico resolve uma incompatibilidade concreta sem afrouxar a física. Restaurar a guia em força zero exige separação explícita entre geometria de mira e previsão finita. Nenhum desses dois pontos demonstra execução corrigida no iPhone até uma nova captura.


## Identidade dos fontes revisados

- `sdktools-us-v3191/SDKtools/Resources/billiards_probe.lua`: SHA-256 `bdc68fad8f315a4d6fc2df75753692b1b55dbcef06713dff2449d22bc6708168`.
- `sdktools-us-v3191/SDKtools/Sources/SDKtools/STBilliardsLiveSnapshot.m`: SHA-256 `bc82090819bc6621e8171a8b7b0f0c66f1b4564c268c5c975811a8a1d79f3440`.
- Evidência de enum e identidade da base: `Analysis/V3_19_2-xlua-enum-profile-review.md` e `Analysis/V3_19_2-xlua-tostring-arm64.json`.

## Revisão independente do candidato V3.19.2

Leitura de `sdktools-us-v3192/SDKtools/Resources/billiards_probe.lua` depois de o autor informar estabilidade do helper e gate, sem editar o produto. Nenhum bloqueador estático foi identificado nesse escopo.

- `enumValue`, perto das linhas 548–560, aceita inteiro dentro do domínio, igualdade protegida com membro tipado ou formas textuais exatas `Nome` e `Nome: valor`. Não usa substring nem extrai o hash de qualquer objeto como valor. Uma combinação como `FreezePositionY, FreezeRotation` permanece rejeitada. A forma exata com sufixo de valor cobre os enums Int32 identificados; conversão gerenciada e `matchedVia` permanecem melhorias opcionais de observabilidade.
- `physicalProfile` agora conserva raio vivo, centros, maxAngularVelocity, tipo/texto/valor normalizado de constraints e material. `mismatchField` e `mismatchBallTag` indicam a primeira rejeição. Isso depende da atualização correspondente do parser nativo, a cargo da revisão dessa camada.
- `runGeometricGuide` é selecionado somente depois dos guardas de cena, bolas imóveis, turno, UI, snapshot de mira coerente e API de consulta disponível. O seletor fica antes de qualquer consulta do solver finito. Não ocorre fallback depois de uma falha parcial do solver finito.
- O fallback troca explicitamente para `model=geometric`, `chainVersion=1`, e não inclui finalStates, duração, stepCount ou repouso previsto. A escala de velocidade/horizonte sintética não é apresentada como força ou tempo. O motivo da indisponibilidade física permanece em `physics`.
- A cauda finita desde o comentário `Pure local predictor` até o final está idêntica à V3.19.1: 18.988 caracteres, SHA-256 `dc67527e2485fa547d9e9e93cf3498c890b1c9f28ed5520fe8bd33d526d57e25` em ambos. As mudanças de normalização/diagnóstico ficam antes dessa cauda.

Esta revisão não executou uma segunda cópia da suíte: o autor estava atualizando testes direcionados de enums e potência zero em paralelo. Aprovação estática do helper/gate não comprova execução no aparelho nem muda as limitações físicas já identificadas.

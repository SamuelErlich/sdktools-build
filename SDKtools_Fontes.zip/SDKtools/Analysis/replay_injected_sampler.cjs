'use strict';
// Replays captured Store fields using the production reader. UI and UID aliases
// are simulated: this demonstrates the data path, NOT iPhone pixel validation.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const sourceRoot=path.resolve(process.argv[2]),capturePath=path.resolve(process.argv[3]),out=path.resolve(process.argv[4]);
const {setup:fixture}=require(path.join(sourceRoot,'Tests/card_sampler_fixture.cjs'));
const {attachCard}=require(path.join(sourceRoot,'Tests/card_hints_fixture.cjs'));
const capture=JSON.parse(fs.readFileSync(capturePath,'utf8').replace(/^\uFEFF/,''));
const events=capture.cardEarly.samples.flatMap(s=>s.observation.events||[]).filter(e=>e.stage==='store_after'&&e.cards.some(c=>c.zone==='hand'));
const f=fixture({selected:{id:0,type:0,color:0,num:0},cards:[]});let last=null,connection=null;const records=[];
for(const e of events){
 if(last!==null)for(let t=last+150;t<e.elapsedMs;t+=150){f.setTime(t);f.sampler.tick();}
 if(e.connectionGeneration!==connection){f.socket.socket={};connection=e.connectionGeneration;}
 f.setTime(e.elapsedMs);f.store.start_time=e.round;f.store.state=e.state;f.store.discard_cards=e.cards.filter(c=>c.zone==='discard').map(c=>({id:c.id,type:c.type,color:c.color,num:c.num}));
 const sel=e.cards.find(c=>c.zone==='selected');f.store.select_give_card=sel?{id:sel.id,type:sel.type,color:sel.color,num:sel.num}:{id:0,type:0,color:0,num:0};
 const slots=Array.from({length:e.payloadFields.find(p=>p.path==='gamers'&&p.presence==='array').count},(_,i)=>i);
 for(let slot=0;slot<=Math.max(...slots);slot++)while(f.hands.length<=slot)f.addHand('slot-'+f.hands.length,[]);
 f.store.gamers=slots.map(slot=>{const h=f.hands[slot],infos=e.cards.filter(c=>c.zone==='hand'&&c.slot===slot).map(c=>({id:c.id,type:c.type,color:c.color,num:c.num}));
  h.uid='slot-'+slot;h.hand.uid=h.uid;h.hand.gamer.uid=h.uid;
  const old=new Map(h.nodes.map(x=>[x.component.cardInfo.id,x]));
  h.nodes=infos.map((info,index)=>{let x=old.get(info.id);if(!x){const c=f.card({face:info.type!==0,parent:h.items,x:index*250}),component=attachCard(f,c,{...info});Object.setPrototypeOf(component,f.Card.prototype);x={c,component};}return x;});
  for(const x of old.values())if(!infos.some(i=>i.id===x.component.cardInfo.id)){x.c.node.removeFromParent();x.c.node.destroy();}
  h.items.children=h.nodes.map(x=>x.c.node);h.gamer={uid:h.uid,cards:infos};return h.gamer;});
 f.store.sync({gamers:f.store.gamers});const rows=[];
 const stats=f.sampler.tick();assert.equal(stats.samplerHiddenKnown,0,'this capture supplies no new current hidden face');assert.equal(stats.handsStatus,'ready');
 const expected=slots.map(slot=>{const cs=e.cards.filter(c=>c.zone==='hand'&&c.slot===slot);const known=cs.filter(c=>c.colorState==='known'||c.colorState==='special').length;return {slot,total:cs.length,known,unknown:cs.length-known};});
 for(let i=0;i<expected.length;i++){const actual=stats.handCounts[i];for(const k of ['slot','total','known','unknown'])assert.equal(actual[k],expected[i][k],'seq'+e.sequence+' '+k);}
 assert.equal(rows.length,0,'no selected face from this capture enters a hidden hand');
 records.push({sequence:e.sequence,elapsedMs:e.elapsedMs,round:e.round,state:e.state,hands:stats.handCounts,totals:{total:stats.handTotal,known:stats.handKnown,unknown:stats.handUnknown},samplerHiddenKnown:stats.samplerHiddenKnown,recovered:rows.length});last=e.elapsedMs;
}
const result={captureSHA256:crypto.createHash('sha256').update(fs.readFileSync(capturePath)).digest('hex'),productionResourceSHA256:crypto.createHash('sha256').update(fs.readFileSync(path.join(sourceRoot,'Resources/card_sampler.js'))).digest('hex'),scope:'captured Store values; simulated coherent UI and synthetic slot UID aliases; not device or physical-seat validation',pollingSimulationMs:150,frames:records.length,knownColorsNotGuessed:true,records};
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'replay_injected_sampler.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({frames:result.frames,first:records[0],last:records.at(-1)}));

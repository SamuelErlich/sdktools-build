# V3.17.1 (build 34) — somente Cartas

Base: SDKtools V3.17/build33. Bilhar e seus testes, Lua e runtime foram preservados byte a byte a pedido do operador. Não há revisão de física, frame, posições ou guia nesta atualização.

- Reativação explícita de Cartas/gameType2007, sem downgrade do projeto.
- Hooks de setup (void) e loadCurrentGame (BOOL) separados, retorno original preservado e restauração com encoding correto.
- Menu de Cartas: captura desde a entrada, histórico ao vivo das cores recebidas, marcadores atuais e exportação do JS baixado.
- Histórico nativo limitado a oito registros de skin_bg_complete com binding válido. Não revela cores desconhecidas nem associa por ID entre capturas.
- Transporte mantido em 250 ms e limites preservados de 90 s / 512 amostras.
- Booleano da cauda exportado como bool; analisador aceita somente o 0/1 legado desse campo específico.
- Testes nativos exercitam os wrappers void/BOOL e o feed real; o renderer habilitado e o modo desativado são testados separadamente.

No aparelho: no lobby, armar a captura de Cartas, entrar no jogo, aguardar 90 s e exportar o JSON. Os marcadores atuais são um modo separado do histórico de captura. A validação no aparelho ainda depende dessa nova captura.

# V4.0.6 / build 81 — Reserve dependencies and refresh recovery

Baseline:V4.0.5/80, commit688c6ed207281575c6b3ca41e980908aa617d7ae.
User reports wrong X-ray triples after refresh and permanently stopped Auto.
Screenshots alone do not establish the actual transport or runtime failure.

## Confirmed regressions

1. Verified sparse reserve geometry annotated hidden cards only for icons.
   With original masks/canTouch permissive, ordinary planning treated every
   lower card as immediately available. A six-card tray with two corn cards
   recommended corn beneath cheese without accounting for cheese first.
2. Accepted batch pending state required identical visual containers. Replacing
   board/reserve/GameLayer/root during the same round permanently marked the
   batch uncertain and removed observers, even with all ACKs/effects available.
   Replacing only cards/Store arrays already worked and is not claimed as new.
3. Serial mode retired pending state when its WeakMap node ID disappeared in
   a rebuilt board. Recreating the same original ID still selectable allowed
   a duplicate event on resumed Play; incomplete Store/scene could also retire it.

## Shared fixes

- Model every higher verified card in the same storage column as a dependency.
  Planner, phase witness, route validator, fast prefix and X-ray share the model.
  Each earlier pick must fit the tray before the first trio. False/missing,
  cross-column, cross-zone and reverse-layer dependencies fail closed.
  Only SDK-owned rows change; original controls/stock/game state are untouched.
- Separate same-round transport identity from visual identity. Dispatch remains
  strict. Continue observing the exact requests through visual reconstruction.
  Reconciliation requires all ACK200/resolved Promises plus a complete stable
  census with the entire expected rawID/type/zone map and ordered tray.
  Rebuilt results are resynced, not fabricated successful move counters.
- Serial reconstruction requires coherent Store/scene and the entire expected
  effect by original IDs before retiring the action. A new local node ID alone
  cannot release it. Preserve special terminal-board transition handling.

No retry by timeout, new packets, server changes, stock edits, scheduler or menu
changes. Missing/failed responses, incomplete effects and changed socket/map,
player/room/round remain pending. Full document loss is not silently reset.

## Verification boundaries

Synthetic production-resource fixtures reproduced RED and GREEN states for
capacity5/6, reserve DAG validation, batch rebuild before/after ACK, root hiding,
serial duplicate prevention and incoherent census. These are local causal proofs,
not a replay of the user's exact live match. Physical performance/appearance and
the precise live refresh trigger remain unmeasured. Official Apple CI and source
archive verification are required separately before delivery.

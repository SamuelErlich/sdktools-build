#!/usr/bin/env python3
"""Read-only numeric audit of V3.18.1 captures. No package changes."""
import collections, hashlib, json, math, pathlib, statistics, argparse
parser=argparse.ArgumentParser(description="Audit the four original captures; expects case1/capture.json through case4/capture.json")
parser.add_argument("--capture-directory", type=pathlib.Path, required=True)
ROOT=parser.parse_args().capture_directory.resolve()
Q=.99;H=.02;G=9.81;C=Q*H*G;VSTOP=math.sqrt(.008)
def pos(b):return [b['world'][k]for k in('x','z')]
def distance(a,b):return math.dist(pos(a),pos(b))
def ball(s,tag):return next((b for b in s.get('balls',[])if b['tag']==tag),{})
def summary(xs):
 if not xs:return None
 return {'n':len(xs),'min':min(xs),'median':statistics.median(xs),'max':max(xs)}
def model(v,n,c):
 a=Q**n;s=Q*(1-a)/(1-Q)
 return v*a-c*(1-a)/(1-Q),H*(v*s-c/(1-Q)*(n-s))
allout={'schemaVersion':1,'model':{'fixedStepSeconds':H,'dampingMultiplierPerStep':Q,'equivalentContinuousRate':-math.log(Q)/H,'slideConstantPerStep':C,'slideGravityEquivalent':G,'stopSpeedSquaredFromSource':.008,'stopSpeed':VSTOP},'cases':[]}
for case in range(1,5):
 p=ROOT/f'case{case}/capture.json';d=json.loads(p.read_text());ev=d['lastAimBeforeMotion'];aim=ev['aim'];motion=ev['firstMotion'];t0=motion['elapsedMs'];alls=sorted({s['elapsedMs']:s for s in d['samples']+[aim,motion]}.values(),key=lambda s:s['elapsedMs']);alls=[s for s in alls if s['elapsedMs']>=t0]
 cutoff=next((i for i,s in enumerate(alls)if s['status']!='moving'),len(alls));shot=alls[:cutoff];after=alls[cutoff:];firstend=after[0]if after else None
 # Later local aiming can expose stopped positions from the same shot, before any new motion.
 settled=[]
 for s in after:
  if s['status']=='moving':break
  if s['status']=='aiming':settled.append(s)
 points=[aim]+shot+settled
 dt=[(b['elapsedMs']-a['elapsedMs'])/1000 for a,b in zip(shot,shot[1:])]
 frames=[b['frameNumber']-a['frameNumber']for a,b in zip(shot,shot[1:])]
 w0=ball(aim,1);w1=ball(motion,1);delta=[b-a for a,b in zip(pos(w0),pos(w1))];ln=math.hypot(*delta);ad=[aim['cue']['direction'][k]for k in('x','z')];dot=sum(x*y for x,y in zip(delta,ad))/ln;angle=math.degrees(math.acos(max(-1,min(1,dot))))
 o={'case':case,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'retainedCounts':dict(collections.Counter(s['status']for s in d['samples'])),'aimTimeSeconds':aim['elapsedMs']/1000,'firstMotionTimeSeconds':t0/1000,'associatedMovingEndSeconds':shot[-1]['elapsedMs']/1000,'firstNonmovingGate':{'timeSeconds':firstend['elapsedMs']/1000,'reason':firstend['reason']}if firstend else None,'subsequentMotionExcluded':any(s['status']=='moving'for s in after),'sampleIntervalSeconds':summary(dt),'renderFrameIntervals':summary(frames),'launchObservation':{'cueAimDirection':aim['cue']['direction'],'cueDisplacementBeforeFirstMotion':delta,'displacementLength':ln,'angleToAimDegrees':angle,'cueSpeedAtFirstMotion':w1.get('speed'),'otherMovingTagsAtFirstMotion':[b['tag']for b in motion['balls']if b['tag']!=1 and b.get('speed',0)>.001],'isLaunchSpeedUncollidedObservation':not any(b['tag']!=1 and b.get('speed',0)>.001 for b in motion['balls']),'powerFraction':'not_exported_do_not_infer'},'balls':[],'modelIntervals':[]}
 for tag in range(1,17):
  rows=[(s['elapsedMs']/1000,ball(s,tag))for s in points];rows=[(t,b)for t,b in rows if b.get('world')];states=[(s['elapsedMs']/1000,ball(s,tag))for s in points];newpots=[t for t,b in states if b.get('potted')and not ball(aim,tag).get('potted')]
  speeds=[b.get('speed',0)for t,b in rows]
  if not speeds or(max(speeds)<=.001 and not newpots):continue
  nonzero=[i for i,(t,b)in enumerate(rows)if b.get('speed',0)>.001];lastnonzero=nonzero[-1]if nonzero else None;stopped=lastnonzero is not None and lastnonzero+1<len(rows);last=rows[-1]
  x={'tag':tag,'number':tag-1,'maxObservedSpeed':max(speeds),'positionSamples':len(rows),'sampledChordDistanceFromAim':sum(distance(a,b)for(_,a),(_,b)in zip(rows,rows[1:])),'largestPositionGapSeconds':max((tb-ta for(ta,a),(tb,b)in zip(rows,rows[1:])),default=0),'lastObservedWorld':last[1]['world'],'lastWorldTimeSeconds':last[0],'lastObservedSpeed':last[1].get('speed'),'newlyPotted':bool(newpots),'pottedFirstObservedSeconds':newpots[0]if newpots else None,'stoppedObserved':stopped,'stopTimeBracketSeconds':[rows[lastnonzero][0],rows[lastnonzero+1][0]]if stopped else None,'stopTimeBracketSinceFirstMotionSeconds':[rows[lastnonzero][0]-t0/1000,rows[lastnonzero+1][0]-t0/1000]if stopped else None,'speedBeforeStop':rows[lastnonzero][1]['speed']if stopped else None}
  o['balls'].append(x)
  for i,((ta,a),(tb,b))in enumerate(zip(rows,rows[1:])):
   dt=tb-ta;va,vb=a.get('speed',0),b.get('speed',0)
   if not(.07<dt<.23 and va>.095 and vb>.095):continue
   dist=distance(a,b);candidates=[]
   for n in range(max(1,math.floor(dt/H)-1),math.ceil(dt/H)+2):
    for name,c in [('rolling',0),('sliding',C)]:
     pv,pd=model(va,n,c);err=abs(pv-vb);derr=abs(pd-dist)
     candidates.append((err+derr/H,name,n,pv,pd,err,derr))
   _,name,n,pv,pd,err,derr=min(candidates)
   if err<max(.0001,va*.00003)and derr<.002:
    # A full n-step interval independently matches speed and positional displacement.
    effective_c=(va*Q**n-vb)*(1-Q)/(1-Q**n)
    o['modelIntervals'].append({'tag':tag,'t0':ta,'t1':tb,'steps':n,'class':name,'v0':va,'v1':vb,'distance':dist,'speedResidual':err,'distanceResidual':derr,'distanceRelativeResidual':derr/max(dist,1e-9),'inferredGravityEquivalent':effective_c/Q/H})
 o['matchingModelCounts']=dict(collections.Counter(x['class']for x in o['modelIntervals']))
 for modelname in ['rolling','sliding']:
  ints=[x for x in o['modelIntervals']if x['class']==modelname]
  o[modelname+'Validation']={'distanceRelativeResidual':summary([x['distanceRelativeResidual']for x in ints]),'speedAbsoluteResidual':summary([x['speedResidual']for x in ints]),'inferredGravityEquivalent':summary([x['inferredGravityEquivalent']for x in ints])}
 allout['cases'].append(o)
allout['limitations']=['Sampling is approximately10Hz, not physics50Hz; rendering frames are not physics step IDs.','The0.99 damping and9.81 sliding terms are validated on intervals matching speed and positions; model classification does not prove phase for unclassified collision intervals.','Angular velocity, contact impulses, selected shot power and spin are not exported. Transition from sliding to rolling cannot be identified universally from scalar speed alone.','Initial movement sampling is delayed; case2 already includes first ball collision at firstMotion. First observed speed is not launch speed or power fraction.','Case1 omits about0.602s immediately after firstMotion and contains a later opponent shot that is excluded.','Sampled chord distances underestimate paths when collision or curvature occurs between samples.','Potted balls lose world positions; final pocket location is not exported by these captures.','Stopping is zeroed in onUpdate, and angular motion may keep status=moving after positional stopping; stop intervals are observations, not exact physics times.']
(ROOT/'motion-calibration.json').write_text(json.dumps(allout,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:c[k]for k in['case','matchingModelCounts','rollingValidation','slidingValidation']}for c in allout['cases']],indent=2))
# Validate finite stopping only on the final uninterrupted rolling tail whose
# endpoint already approaches the cutoff. This is not a full-shot simulator.
for o in allout['cases']:
 d=json.loads((ROOT/f"case{o['case']}/capture.json").read_text());ev=d['lastAimBeforeMotion'];ss=sorted({s['elapsedMs']:s for s in d['samples']+[ev['aim'],ev['firstMotion']]}.values(),key=lambda s:s['elapsedMs']);lookup={(s['elapsedMs']/1000,b['tag']):b for s in ss for b in s['balls']}
 o['rollingTailStopValidation']=[]
 for b in o['balls']:
  if not b['stoppedObserved']:continue
  tag=b['tag'];ints=[x for x in o['modelIntervals']if x['tag']==tag and x['class']=='rolling'];groups=[]
  for x in ints:
   if groups and abs(groups[-1][-1]['t1']-x['t0'])<1e-7:groups[-1].append(x)
   else:groups.append([x])
  if not groups:continue
  g=groups[-1]
  if len(g)<3 or g[-1]['v1']>.12:continue
  a=g[0];n=max(0,math.ceil(math.log(VSTOP/a['v0'])/math.log(Q)));_,predD=model(a['v0'],n,0);start=lookup[(a['t0'],tag)];last=b['lastObservedWorld'];obs=math.dist(pos(start),[last[k]for k in('x','z')]);predT=a['t0']+n*H
  o['rollingTailStopValidation'].append({'tag':tag,'startTime':a['t0'],'startSpeed':a['v0'],'modeledStopTime':predT,'observedStopBracket':b['stopTimeBracketSeconds'],'modeledDistance':predD,'observedStraightDisplacementToLastPosition':obs,'distanceDifference':obs-predD,'distanceRelativeDifference':(obs-predD)/max(predD,1e-9),'warning':'Tail starts after collision/sliding phases; final cutoff occurs in render onUpdate, not exact physics-tick event.'})
(ROOT/'motion-calibration.json').write_text(json.dumps(allout,ensure_ascii=False,indent=2)+'\n')
report=['# V3.19 — calibração das quatro capturas V3.18.1','',
'Análise somente leitura. Foram usados os JSONs e as fórmulas conferidas no código recuperado; vídeo e contato contínuo de física não foram usados para preencher dados ausentes.','',
'## Resultado principal','',
'Há dois regimes distintos de desaceleração observáveis. Em trechos estabilizados, cada passo de 0,02 s multiplica a velocidade por 0,99. Logo após certos impactos há também uma perda de 9,81 × 0,02 antes desse multiplicador. Uma previsão somente com drag prolongaria demais vários trajetos.','',
'As recorrências que reproduzem velocidade e deslocamento juntos são:','',
'- Rolamento: `v[k+1] = 0.99 * v[k]`.','- Deslizamento observado: `v[k+1] = 0.99 * (v[k] - 9.81 * 0.02)`.','- Integração: `posição[k+1] = posição[k] + 0.02 * velocidade[k+1]`.','',
'Nos quatro arquivos, 453 intervalos completos combinam com o primeiro regime e oito com o segundo, sob tolerâncias explícitas no script. Isso é validação de intervalos selecionados por velocidade e deslocamento; não significa que toda a tacada siga um regime único. O equivalente contínuo do primeiro regime é `k = -ln(0.99)/0.02 = 0.5025168 s⁻¹`.','',
'Os dois intervalos livres da bola tag 7 no caso 4 estimam gravidade equivalente de 9,8099589 e 9,8100053. O caso 3 confirma 9,8100230. A combinação é compatível com atrito de deslizamento μ≈1 sobre gravidade 9,81.','',
'## Limite indispensável para a implementação','',
'Não há velocidade angular, torque, potência escolhida nem estado de deslizamento nos JSONs. Assim, o instante de mudança entre os regimes não pode ser calculado de maneira geral somente pela velocidade escalar. No caso 3, a bola tag 6 ainda mostra deslizamento entre 6,318 e 6,416 s, muda durante 6,416–6,517 s e já segue apenas drag depois de 6,517 s. Esse intervalo concreto não define uma duração universal.','',
'O código BallBehavior só zera angularVelocity na colisão com bumper quando reboundPos/reboundDir estão presentes; não faz isso em todo choque com borda nem em toda colisão entre bolas. A física de contato continua responsável pela maior parte da rotação.','',
'## Lançamento e associação','']
for o in allout['cases']:
 l=o['launchObservation'];report.append(f"Caso {o['case']}: mira {o['aimTimeSeconds']:.6f} s; primeira amostra em movimento {o['firstMotionTimeSeconds']:.6f} s; velocidade observada da branca {l['cueSpeedAtFirstMotion']:.6f}; desvio do deslocamento inicial em relação à mira {l['angleToAimDegrees']:.6f}°. Outras bolas já em movimento: {l['otherMovingTagsAtFirstMotion'] or 'nenhuma'}. Potência percentual não exportada.")
report+=['','No caso 2, a primeira amostra já vem depois do impacto: branca a 0,1154 e bola tag 4 a 20,4768. Não é uma medição da velocidade inicial da branca. No caso 1, falta um intervalo de aproximadamente 0,602 s depois de firstMotion, e o movimento que reaparece a 23,216 s é posterior à troca de turno; foi excluído.','',
'## Paradas e trajetos observados','',
'`BALL_MIN_VEL = 0.008` é aplicado à velocidade ao quadrado em BallBehavior:onUpdate; o limiar linear é 0,0894427. A maioria das últimas amostras antes de zerar está entre 0,090 e 0,094. O estado global moving pode continuar por rotação e outras bolas. Distância abaixo é soma de cordas entre posições, portanto não substitui trajetória contínua.','',
'| Caso | Tag / número | Distância amostrada | Parada, tempo absoluto da captura | Última posição X, Z | Resultado |','|---|---|---:|---|---|---|']
for o in allout['cases']:
 for b in o['balls']:
  span=b['stopTimeBracketSeconds'];t=f'{span[0]:.3f}–{span[1]:.3f} s'if span else'Não observada';w=b['lastObservedWorld'];state='Encaçapada; posição da caçapa ausente'if b['newlyPotted']else('Parada observada'if b['stoppedObserved']else'Movimento final desconhecido')
  report.append(f"| {o['case']} | {b['tag']} / {b['number']} | {b['sampledChordDistanceFromAim']:.5f} | {t} | {w['x']:.6f}, {w['z']:.6f} | {state} |")
report+=['','## Conferência de parada nas caudas em rolamento','',
'Para uma velocidade já em rolamento: `n = ceil(log(sqrt(0.008)/v0)/log(0.99))`, limitado a zero; `D = 0.02*v0*0.99*(1-0.99^n)/(1-0.99)`. Os números seguintes começam depois dos impactos e da fase transitória. As diferenças restantes incluem amostragem, posição renderizada e zeragem em onUpdate.','',
'| Caso | Tag | Início | Distância modelada | Distância observada até última posição | Diferença |','|---|---|---:|---:|---:|---:|']
for o in allout['cases']:
 for t in o['rollingTailStopValidation']:report.append(f"| {o['case']} | {t['tag']} | {t['startTime']:.3f} s | {t['modeledDistance']:.6f} | {t['observedStraightDisplacementToLastPosition']:.6f} | {t['distanceDifference']:+.6f} |")
report+=['','## Rebotes e restituição','',
'Os dados registram inversões reais de direção, mas não contatos a 50 Hz nem vetores de velocidade angular. No caso 3, tag 6 muda o sinal de Z entre 6,0177 e 6,1160 s junto da borda superior, depois muda o sinal de X entre 6,2176 e 6,3184 s junto da borda esquerda. No caso 2, tag 4 apresenta inversões de Z entre 24,916–25,0157 s e 25,6203–25,7177 s.','',
'Não é correto dividir a velocidade depois pela velocidade antes e chamar o resultado de restituição: cada intervalo pode conter drag, atrito, rotação e parte do trajeto antes/depois do contato. A direção também evolui nas amostras seguintes ao rebote, mostrando que uma reflexão especular simples não reproduz toda a resposta. O material serializado continua sendo evidência separada; estes JSONs não isolam um coeficiente de restituição único.','',
'No caso 4, a bola tag 7 desaparece das posições e passa a potted entre 7,3122 e 7,4098 s. A última posição observada ainda é anterior à caçapa.','',
'## Arquivos','',
'`motion-analysis.py` reproduz os cálculos; `motion-calibration.json` contém hashes, intervalos classificados, resíduos, limites de associação e coordenadas por bola. Nenhuma alteração de produto foi feita.']
(ROOT/'motion-report.md').write_text('\n'.join(report)+'\n')

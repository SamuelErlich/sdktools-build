# SDKtools 4.0.11 / build86 — poderes de estoque com critério

Alpaca → **Powers + Auto**. Win local continua opcional e somente leitura.
O planejador tenta uma rota normal antes de gastar; não compra, não altera
estoque nem habilita controles bloqueados. Usa no máximo um poder antes de
outra jogada normal confirmada. Operação incerta não é repetida por timeout.

- **Penetrate (3):** uma carta comum coberta do mesmo tipo das duas cartas
  já na bandeja. Uma chamada original UseProp com estoque positivo, observação
  do pedido/resposta e Promise, débito de uma unidade e desaparecimento exato
  das três cartas. Não usa o experimento manual de estoque zero.
- **Retornar (1):** última carta real; simula posição/cobertura e exige trio
  acessível depois. **Guardar (0):** só com reserva vazia; todo subconjunto
  possível de três cartas escolhido pelo servidor deve permitir um trio.
- **Remover (5):** exige trio acessível depois para TODOS os subconjuntos
  possíveis de três cartas removidas da bandeja. Não escolhe essas três.
- **Embaralhar (2):** resgate aleatório, só com bandeja apertada, um par e
  faces correspondentes misturáveis. Não inventa ganho percentual.
- **Bomba (4):** reconhecida e preservada. O cliente aplica a lista recebida
  do servidor; seleção e quantidade não foram comprovadas. Uso automático
  permanece desativado até obter essa regra, em vez de gastar às cegas.

O modelo Win é local, ponderado e **sem poderes futuros**, não taxa de vitória
no servidor. Uma simulação isolada avalia o estado posterior do trio dirigido;
100% exato sem poder conserva estoque, e uma piora exata comprovada impede
esse gasto. Estimativa parcial/aleatória não prova melhora. Trio útil não
garante resolver fases futuras, missões especiais ou ações de aliados.

Antes de confirmar o popup, contexto, inventário e censo são revalidados.
Pausa mantém a observação sem reenviar. Penetrate rejeitado só libera após
rollback estável e estoque intacto; efeito divergente continua bloqueado.

Detalhes: `Analysis/V4_0_11-owned-powers.md`. Resultados exatos dos testes,
compilação e artefatos constam do relatório da entrega; teste no iPhone é
uma etapa separada. Não há garantia de vitória nem de estoque ilimitado.

## Histórico preservado — notas abaixo pertencem a versões anteriores


## Contratos e implementação

Fontes primários reabertos e hashes conferidos nesta atualização:
`V4_0_11-owned-powers-evidence.json`. Constant mapeia 0..5. UsePropAlert tem
um ramo especial para Penetrate: a confirmação comum só abre a seleção;
Block.touchBlock chama Socket.UseProp(id,blockID). Socket conserva a Promise
do transporte original. GameLayer.PenetrateBlock aplica a carta informada e
limpa o modo. Nenhum desses métodos foi executado durante a análise.

`autoplay_powers.js`: coordenação/decisão privada e projeção contrafactual;
`alpaca_covered.js`: observador original reutilizado por uma instância privada,
kind penetrate_owned, com preflight positivo e par no censo completo. O
coordenador do experimento manual é OUTRA instância e permanece separado.
`autoplay_tool.js`: passa observador e analisador; só aciona a política depois
de o planner não fornecer rota. `alpaca_win.js`: fork de sessões isoladas.
Bridge nativo sanitiza tipos 0..5, política fechada e números finitos limitados;
UI explica a decisão e a Bomba preservada. Não exporta cardID/propID/UID/socket.

O contador de poderes confirmados indica estoque + efeito local estável; para
Penetrate também exige resposta correlacionada e Promise concordantes. Os
poderes antigos continuam sem observador protocolar: não chamar seu efeito
visual de confirmação independente do servidor.

## Teste físico mínimo

1. Instalar/assinar o IPA da versão correta e entrar na própria mesa US.
2. Auto OFF/Powers OFF: observar Win, confirmar ausência de consumo.
3. Usar mesa com estoque positivo de Penetrate, par na bandeja e terceira
   carta comum coberta, sem trio normal acessível; ligar Powers + Auto.
4. Conferir alvo, débito exatamente 1, trio correto e retomada; repetir pausa
   durante confirmação. Se houver divergência, pausar e exportar captura.
5. Guardar/Retornar/Remover: conferir posição/conjunto real e efeito antes
   de contar uso correto. Bomba não será gasta automaticamente.

Não foi realizado teste no aparelho ou chamada ao servidor pelo agente.

## Reconhecimento dos controles de poderes

BlockSkinManager.setPropSkin carrega icon/prop_${type}; os seis nomes e seu
factory foram conferidos e hashados. O caminho privado ownedInventory de
return_tool valida nome exato, Prop.type/id/num, propInfo, inventário atual,
modo, geometria e evento registrado para os três slots, permitindo Remover
sem inventar um novo hash de ícone. São testadas as 20 combinações de três
tipos distintos e divergências de stock/ícone/contexto. Os controles manuais
sem esse vínculo mantêm a whitelist histórica; não aceitam combinações
arbitrárias só porque um ícone parece conhecido. O layout ainda exige três
slots: inventários/interfaces com outro layout são recusados.

# V3.17 — evidência das duas capturas

Análise somente leitura. O JSON auxiliar registra hashes, contagens, trajetórias por bola, transformação da câmera e exemplos reproduzíveis.

## Sucesso observado

As duas capturas acessam os módulos `package.loaded`, validam `GameType=1003`, obtêm `Game/BiFrameLogic` e usam a câmera `35208` da cena `BilliardInGame`, handle `-7158`. A ausência de `Enum`/`Const` nos globais continua aparecendo, mas deixou de bloquear a leitura.

Primeira captura: 239 tentativas totais, 229 aceitas, zero rejeitadas; dos 120 snapshots retidos, 118 são `aiming` e dois `aim_snapshot_stale`. As 16 bolas têm identidade consistente. A janela retida vai de 11,914 a 24,228 segundos. Nos snapshots válidos as bolas estão paradas, enquanto a mira muda. Mediana de leitura 8,099 ms, máximo 25,015 ms.

## Limitação da linha demonstrada nos dados

Há exatamente um segmento `object` em cada um dos 118 snapshots de mira. Em 110 ele parte da bola número 13, em oito da bola 11. A identidade aqui é inferida por proximidade: início a aproximadamente 0,001 unidade do centro, pois a V3.17 ainda não registra IDs nos segmentos.

Em 86 snapshots o segmento da bola 13 termina a aproximadamente 0,33 unidade do centro da bola 14, compatível com contato de duas bolas de raio 0,165. Não existe ramo seguinte saindo da bola 14. Outros contatos finais observados são 13→12 (oito), 13→15 (sete), 13→7 (quatro) e 13→4 (dois). Assim, os dados já contêm casos concretos para ampliar a propagação após o segundo impacto.

Fixtures indicadas: primeira captura `samples[20]`, `samples[60]` e `samples[119]` apresentam branca→13→14. Os índices são base zero. Isso identifica a geometria prevista naquela mira; não comprova qual tacada foi executada depois.

## Segunda captura: movimento e limites

432 tentativas totais, 374 aceitas, zero rejeitadas. Dos 120 snapshots retidos, 65 são `moving`, 54 `not_local_turn` e um `not_aiming`. A janela retida começa em 31,919 segundos e termina em 44,222 segundos. Foram omitidas 312 amostras anteriores. Mediana 10,179 ms, máximo 18,501 ms.

Na parte retida, aparecem em movimento a branca (número 0, tag 1) e as bolas 6 (tag 7), 7 (tag 8), 9 (tag 10), 10 (tag 11), 12 (tag 13). A bola 14 (tag 15) já está `potted=true`, `active=false` desde a primeira amostra retida. A trajetória da bola 6 mostra inversões de direção próximas das bordas x negativo e z negativo; a bola 7 também inverte x junto da borda positiva. Isso permite conferir qualitativamente rebotes, mas não recuperar de forma exata restituição, atrito ou momento do contato.

Não há `cue` válido nem segmentos de previsão em nenhum snapshot retido da segunda captura. A tacada inicial e seu primeiro contato não foram preservados; não é correto ligar automaticamente a última mira da primeira captura à tacada da segunda. Nas 55 amostras após a fase `moving`, os registros de bolas preservam identidade/estado, mas omitem posição e velocidade.

## Projeção

A transformação entre mundo XZ e tela é consistente nas duas capturas, tela 1242×2688:

- screen.x ≈ 621 − 147,6923 × world.z
- screen.y ≈ 1256,8615 + 147,6923 × world.x
- erro máximo da regressão afim: 0,000152 pixel
- raio de tela ≈ 24,3692 pixels, equivalente a 0,165 unidade de mundo

Esses números validam a coerência dos dados exportados nessa câmera. Devem ser calculados novamente a partir da câmera ativa, sem fixá-los no produto. Não demonstram alinhamento visual perfeito no aparelho por si sós, embora o usuário tenha confirmado as marcações.

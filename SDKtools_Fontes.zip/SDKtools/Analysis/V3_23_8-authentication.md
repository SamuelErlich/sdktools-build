# Autenticação e limites de confiança — SDKtools 3.23.8/build 58

Auditoria em 2026-10-19. Base imutável: 3.23.7/build 57, fontes ZIP SHA-256
`09231bd4086885eec610cebd8527d6107dabce0fa6cf3fa8844f99e3a3988b34`.
Este documento separa **SDKtools**, **sessão do WePlay** e **GitHub Actions**.
Não há backend do WePlay nem servidor de licença SDKtools no projeto entregue.

## 1. Componentes e o que realmente autentica

| Componente | Função observada | Não confundir com |
|---|---|---|
| `SDKtools.m / STSupportedHost` + `Info.plist` | Compara bundle ID, versão, build e executável; instala overlay somente no host esperado | Login de usuário, licença ou assinatura criptográfica do servidor |
| `STClientContext`, `STNativeActionPolicy`, `STAutoplayRecorder` | Autoriza contexto local: jogo correto, primeiro plano, WebView/documento e operação pendente | Autorização remota para mudar regras do jogo |
| `Platform / PlatformApi` recuperados | Obtêm host, UID, RID, watch info e `selfSecret` da ponte nativa | Emissão local de uma nova credencial |
| `Socket` recuperado | Conserva `secret`, abre conexão, faz heartbeat/entrada, correlaciona packet IDs | O SDKtools não implementa um login alternativo |
| `alpaca_covered.js` | Observa uma chamada original e exige envelope/Promise correspondentes | Um ACK sintético, assinatura do servidor ou concessão de poder |
| `STCardEarlyCapture` | Nonce UUID e handler aleatório para correlacionar mensagens JS/nativo | Token de conta WePlay; não é credencial remota |
| Workflow + downloader | `GITHUB_TOKEN` temporário e URL HTTPS secreta da base, quando selecionada | Credencial de jogo ou token que deva ir no IPA |

A busca nos fontes atuais não encontrou implementação de KeyAuth, login próprio,
refresh token SDKtools, `SecItem`/Keychain SDKtools ou cliente HTTP de autenticação.
`Resources/Brand/sdk-tokens.json` contém design tokens; `license@3x.png` é um asset.
Isso não prova ausência de autenticação no aplicativo hospedeiro ou em frameworks.

## 2. Fluxo real de requisições do Alpaca

```text
Login do aplicativo WePlay (fora dos fontes completos disponíveis)
    ↓ sessão nativa já existente
Platform.setup / preGet
    GetServerHost → GetSelfUid → GetRid → GetWatchInfo → GetSelfSecret
    ↓ callbacks: host, selfUid, rid, selfSecret em memória JS
Game.onLoad
    Socket.establish(platform.host, platform.selfUid, platform.selfSecret, platform.rid)
    ↓ WebSocket original
Socket.onOpen → heart_check(secret) → RegisterSucc
    ↓
Game.enterGame → Socket.enterGame(secret) → sync(uid) → GameStore.sync
    ↓
Método original TouchBlock(block_id, block_state) ou UseProp(prop_id, block_id)
    ↓ Socket.send acrescenta uid e rid
{packet_id, command, param}
    ↓
Socket.onMessage: packet_id + code; decodifica corpo quando indicado
    200 → resolve Promise original
    outro código → reject Promise original
    sem packet_id → push, filtrado por rid no módulo recuperado
```

Equivalente resumido do código recuperado, **não um emissor executável**:

```javascript
// nomes/campos do artefato; nenhum valor de credencial foi extraído
establish(server, uid, secret, rid);       // secret é opaco
heart_check() => send(HeartBeat, {secret, accept_encoding});
enterGame()   => send(EnterGame, {secret});
TouchBlock(block_id, block_state) => send(TouchBlock, {block_id, block_state});
UseProp(prop_id, block_id)        => send(UseProp, {prop_id, block_id});
// send inclui uid/rid e packet_id; o servidor continua decidindo permissão.
```

`uid`, `rid`, `block_id` e `prop_id` são identificadores, **não autenticação**.
`packet_id` correlaciona respostas; não é comprovado como nonce antirreplay.
Não foi estabelecido se `secret` é JWT, assinatura, chave curta, qual TTL possui,
como é revogado ou como o servidor o vincula à conta/rodada. Não se deve adivinhar.
`Config.WEB_TEST` está false no artefato recuperado; o ramo de teste com `TEST`
não é uma credencial válida demonstrada para produção.

## 3. Credenciais, tokens, persistência e logs

| Item | Origem/uso | Tratamento observado e limites |
|---|---|---|
| `Platform.selfSecret` / `Socket.secret` | Callback `GetSelfSecret`, heartbeat e EnterGame | Memória JS do host; o módulo `destroy` não limpa secret/UID/RID e a reconexão reutiliza-os. Persistência nativa e revogação desconhecidas |
| UID/RID/start_time/socket/documento | Identidade da própria sessão no SDK | Revalidados; mudança invalida correlação, não autentica outro usuário |
| Nonce `STCardEarlyCapture.token` | UUID aleatório por arm, validado com geração, frame, WebView e documento | Só correlação local. Está em `pageWorld`; não é segredo isolado de todo JS da página e não é prova de servidor. Não exportado no relatório |
| Opções `NSUserDefaults` | Idioma, menu e opções de jogo | Não foram identificadas como armazenamento de senha/licença SDKtools |
| Relatório de camadas | Último diagnóstico nativo, allowlists | Não contém secret, URL, corpo de pacote ou IDs de jogador/carta. Limites de tamanho/eventos e proteção do arquivo iOS |
| `GITHUB_TOKEN` | GitHub cria por job | Agora build read-only; escrita só no job publish, manual na branch padrão. Não é compilado no cliente |
| `BASE_IPA_URL` / `SDKTOOLS_BASE_IPA_URL` | Secret configurado no repositório | Só no passo autorizado de download; HTTPS, sem userinfo/fragmento, tamanho/SHA fixos, erros genéricos, temporário removido. Não se publica o valor |
| Credencial do `gh` local | Sessão do operador | Fora do código entregue. O 401 GitHub anterior não é o 500 do jogo; não são o mesmo sistema |

Os fontes de diagnóstico capturam alguns métodos de jogo em modos específicos.
Allowlists e ausência de leitura de credential stores não demonstram que todo
código de terceiro seja livre de literais sensíveis. Revise exportações antes de
publicá-las; esta auditoria não publica capturas pessoais nem valores de token.

## 4. Achados, correções e pendências

### A1 — CI com escrita durante build/PR e publicação sem gate [corrigido no workflow]

O workflow 3.23.7 tinha `contents: write` no próprio job que compila o ZIP, entrega
`GH_TOKEN` ao download e publica Release. O passo de publicação não tinha condição
para impedir PRs do mesmo repositório. Não foi demonstrado ataque de fork: eles já
eram excluídos pelo gate do job. Risco: privilégio excessivo e publicação de build
não aprovado como release.

Correção: build apenas `contents: read`; publisher em **outro job/runner**, dependente
do build bem-sucedido, só `workflow_dispatch` na branch padrão. Publisher não faz
checkout nem roda scripts do ZIP: baixa apenas o artefato da mesma execução,
revalida digest/manifesto/checksum e então usa `contents: write`. URL secreta de
download fica igualmente restrita à execução manual da branch padrão. PRs e
branches de teste ainda podem gerar artefatos, mas não Releases.

Isso não substitui branch protection/revisão do próprio workflow. Quem puder
alterar o workflow confiável ou os secrets administrativos continua sendo parte
da fronteira de confiança. Tags de actions ainda são mutáveis; não se afirma
que SHA do ZIP autentique o fornecedor ou substitua revisão de código.

### A2 — transporte sem TLS possível no módulo original [mitigação limitada no SDK]

`Socket.getConnectUrl` escolhe `wss://` somente quando o texto da porta é `443`;
caso contrário retorna `ws://`. `heart_check` e EnterGame incluem `secret`.
Isso estabelece **um caminho potencial de credencial em claro**, não que o aparelho
tenha usado esse caminho na partida analisada. Não há captura de rede atual.

Correção local: o coordenador dos **dois testes experimentais** exige URL canônica
`wss://`, sem userinfo/fragmento ou formato inválido, antes de instalar/enviar.
URL ausente também bloqueia com `secure_transport_required`. A URL nunca entra no
diagnóstico; mudança posterior invalida correlação. O SDK não muda endereço,
secret nem configuração do servidor para forçar TLS.

**Limite:** isso não protege retroativamente o login/heartbeat do próprio WePlay,
nem altera o autoplay/poderes normais. Correção completa exige ajuste do cliente
original e endpoint TLS confirmado pelo responsável. Não basta trocar uma string
`ws` por `wss`: porta, certificado e serviço devem suportar o contrato.

### A3 — secret enviado ao caminho de telemetria original [confirmado estático, não corrigido no host]

`Socket.establish` e `enterGame` passam `secret` a `RequestUtil.sendSocketLog`.
`RequestUtil` encaminha `log_content` ao logger sem redigir esse campo no wrapper
observado. O corpo de EnterGame também passa pelo warn genérico de `Socket.send`.
É exposição potencial nos logs originais. Persistência, destino efetivo e acesso
ao logger não foram medidos nesta sessão.

Não há patch aplicado no app proprietário nem interceptação global de logs:
alterá-los sem contrato completo pode quebrar o host e não remove logs anteriores.
Correção para o código original: não registrar `secret`, tokens, cookie, senha ou
Authorization; logar apenas comando, código e estado não sensível. Rotação/revogação
de segredos já expostos é responsabilidade do servidor e não pode ser simulada aqui.

### A4 — responseMap/Promises e ciclo de vida [pendência do host]

O Socket recuperado não remove a entrada após resolver/rejeitar. `destroy` troca
o mapa, mas não rejeita as Promises pendentes e conserva o secret para reconexão.
Isso pode acumular entradas/pendências; retenção e impacto em runtime não medidos.
O SDK preserva seu latch diante de resultado incerto; não altera silenciosamente
o resolvedor do jogo. Ajuste do host requer timeout/cancelamento por geração e
limpeza após settlement, com testes do servidor/reconexão próprios.

## 5. Binário: o que foi explorado e o que não foi alterado

Artefato: `work/weplay-base/selected/weplay-us.app/weplay-us`, 78.612.768 bytes,
SHA-256 `2a1d3c9832a5e7158e72404ce0d139165bb3e348707d5e427271b264da6c79cc`.
Mach-O thin ARM64, UUID `22f12a1a-f282-346a-9c98-a4646d8802ef`, plataforma iOS,
minOS 15, SDK declarado 26.2. `LC_ENCRYPTION_INFO_64` declara `cryptid=0`; isso não
comprova sozinho descriptografia, assinatura válida ou execução.

REA abriu o binário e confirmou identidade. `inspect_macho` nativo não estava
disponível neste Windows; Hopper exige macOS, IDA não está configurado e o provider
Ghidra Windows anunciado não suporta este Mach-O. Não se inventou pseudocódigo.
Um parser local somente leitura confirmou load commands/seções e inventariou
nomes Objective-C/imports candidatos, com offsets e cobertura explícita. Nomes
de login/Keychain/Apple/Facebook são pistas, não uma prova de qual token é guardado
ou de como é validado. Não foram lidos Keychain, memória de conta ou tokens reais.

Evidências estão em `MACHO_LOCAL.json`, `BINARY_AUTH_INVENTORY.json`, `REA_OPEN.json`,
`REA_SESSION.json` e `REA_MACHO_UNAVAILABLE.json` na pasta da entrega. A análise REA
inerte dos sete módulos recuperados teve sete parses e zero falhas; 143 arquivos
ficaram fora da seleção. Parent Evidence:
`ev_1a6fc0778deccc5fe45f04f583f74b81b76368727b4aac7d52789d153d93bd19`.

**Não foi patchado o executável WePlay.** Código de máquina não possui “linhas”
equivalentes ao fonte. Um patch requer função/instrução alvo, contrato ABI,
precondições de bytes/hash, limites de seção e validação de assinatura/integrador.
Esta investigação não estabeleceu offsets seguros de instruções de autenticação
ou de envio. Offset de string/selector não autoriza tratá-lo como função ou patch.

## 6. Escrever/editar o formato sem expor credenciais nem enviar

Acrescentado `scripts/game_request_preview.py`, editor/validador **offline** de dois
contratos conhecidos. Rejeita comandos arbitrários, campos extras, UID/RID,
packet_id, secret/token/Authorization, chaves duplicadas, JSON inválido, IDs fora
do limite, estados inválidos e entrada >8 KiB. Erros não ecoam a entrada/argumentos.
O script não tem HTTP/WebSocket, modo `--send` ou autenticação.

Exemplo com valores sintéticos, a partir da pasta dos fontes:

```json
{"command":"CMD_TOUCH_BLOCK","param":{"block_id":"fixture-card","block_state":0}}
```

```powershell
python scripts/game_request_preview.py --input request.json --set-block-id fixture-other
```

Saída marca `dryRun:true` e `networkEnabled:false`. É prévia de **parâmetros de
método**, não pacote pronto para o servidor. Validação de formato não autentica
IDs nem garante permissão. Para ação real, o runtime existente continua usando
somente os métodos originais e a sessão própria verificada, sem editor de pacotes
arbitrários no menu. Recusa 500 continua recusa; não é resolvida copiando UID,
RID ou formato de uma jogada exposta.

## 7. Verificação e fontes

Testes JS/Python e contratos estáticos YAML, mais preflight que aceita o ZIP atual
e rejeita o anterior/adulterado. Contagens exatas em Validation/V3_23_8-validation.json.
Nenhuma chamada ao servidor do jogo, extração de credencial, compilação Apple,
assinatura, instalação ou teste no iPhone foi feito nesta auditoria.

Fontes principais do SDK: SDKtools.m, STAutoplayRecorder.inc,
STAutoplayBridge.inc, STAutoplaySanitizer.inc, STCardEarlyCapture.m,
STCoveredCardReport.inc e scripts/download_base.py. Fontes recuperados: Game,
Platform, PlatformApi, Socket, RequestUtil, Config e gameConfig do Alpaca_US.
Origem e hashes individuais dos módulos estão no ledger da entrega, não em
credenciais ou capturas novas.

Documentação oficial consultada em 2026-10-19:
- GitHub: GITHUB_TOKEN e privilégio mínimo por job:
  https://docs.github.com/en/actions/tutorials/authenticate-with-github_token
- GitHub: dependências e permissões de jobs:
  https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax
- actions/download-artifact: mesma execução por padrão e verificação de digest:
  https://github.com/actions/download-artifact

Limitar permissões ao mínimo é a base da separação aplicada aqui; documentação
não substitui execução da CI nem valida o conteúdo proprietário analisado.

from pathlib import Path
import sys,json,hashlib,math
from pathlib import Path
import struct,json,re,hashlib
class Reader:
 def __init__(self,b,p=0):self.b=b;self.p=p
 def get(self,fmt):v=struct.unpack_from('<'+fmt,self.b,self.p);self.p+=struct.calcsize('<'+fmt);return v[0] if len(v)==1 else v
 def cstr(self):e=self.b.index(b'\0',self.p);s=self.b[self.p:e].decode('utf8','replace');self.p=e+1;return s
 def align(self):self.p=(self.p+3)&~3
 def astr(self):
  n=self.get('i');assert 0<=n<=10*1024**2;s=self.b[self.p:self.p+n].decode('utf8','replace');self.p+=n;self.align();return s

def objects(path):
 b=Path(path).read_bytes();assert struct.unpack_from('>I',b,8)[0]==22 and b[16]==0
 meta,sz,do,unk=struct.unpack_from('>IQQQ',b,20);assert sz==len(b);r=Reader(b,48);unity=r.cstr();platform=r.get('i');tree=r.get('?')
 types=[]
 for i in range(r.get('i')):
  cid=r.get('i');strip=r.get('?');script=r.get('h')
  if cid==114:r.p+=16
  r.p+=16
  if tree:
   nodes,strings=r.get('ii');assert 0<=nodes<100000 and 0<=strings<16*1024**2
   r.p+=nodes*32+strings
   deps=r.get('i');assert 0<=deps<100000;r.p+=deps*4
  assert r.p<len(b)
  types.append({'class':cid,'scriptIndex':script})
 rows=[];count=r.get('i');assert count<1000000
 for i in range(count):
  r.align();pid,start,size,tid=r.get('qqIi');assert 0<=tid<len(types);start+=do;assert start+size<=len(b)
  rows.append({'path_id':pid,'offset':start,'size':size,**types[tid]})
 return b,rows


assert len(sys.argv)==3, 'usage: script.py sceneFile outputJSON'
path=Path(sys.argv[1])
b,rows=objects(path);gameobjects={};transforms={};errors=[]
for o in rows:
 try:
  r=Reader(b,o['offset'])
  if o['class']==1:
   n=r.get('i');assert 0<n<128
   components=[r.get('iq') for _ in range(n)];layer=r.get('I');name=r.astr()
   assert layer<32 and len(name)<256
   gameobjects[o['path_id']]={'id':o['path_id'],'name':name,'layer':layer,'components':components,'object':o}
  elif o['class']==4:
   go=r.get('iq');rotation=r.get('ffff');position=r.get('fff');scale=r.get('fff');n=r.get('i');assert 0<=n<256
   children=[r.get('iq') for _ in range(n)];parent=r.get('iq')
   transforms[o['path_id']]={'id':o['path_id'],'gameObject':go,'rotation':rotation,'localPosition':position,'localScale':scale,'children':children,'parent':parent,'object':o}
 except Exception as e:errors.append({'object':o,'error':type(e).__name__})
def name(t):return gameobjects.get(t['gameObject'][1],{}).get('name','?')
def ancestry(t):
 result=[name(t)]
 for _ in range(16):
  p=transforms.get(t['parent'][1])
  if not p:break
  result.append(name(p));t=p
 return '/'.join(reversed(result))
def rotate(q,v):
 x,y,z,w=q;vx,vy,vz=v
 tx,ty,tz=2*(y*vz-z*vy),2*(z*vx-x*vz),2*(x*vy-y*vx)
 return (vx+w*tx+y*tz-z*ty,vy+w*ty+z*tx-x*tz,vz+w*tz+x*ty-y*tx)
def world(t):
 v=t['localPosition'];seen=set()
 while t['parent'][1] in transforms:
  t=transforms[t['parent'][1]];assert t['id'] not in seen;seen.add(t['id']);assert len(seen)<32
  v=rotate(t['rotation'],tuple(a*c for a,c in zip(v,t['localScale'])))
  v=tuple(a+c for a,c in zip(v,t['localPosition']))
 return v
selected=[]
for t in transforms.values():
 route=ancestry(t)
 if 'Table' in route or 'Pots' in route or name(t).startswith('pot'):
  selected.append({'path':route,'name':name(t),'worldPosition':world(t),**t})
report={'source':str(path),'sha256':hashlib.sha256(b).hexdigest(),'method':'bounded binary GameObject/Transform layout parser; local transforms only, not executed',
 'objectCount':len(rows),'gameObjectCount':len(gameobjects),'transformCount':len(transforms),'parseErrors':errors,'selected':selected}
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
for t in selected:print(t['path'],'pos',t['localPosition'],'scale',t['localScale'],'rot',t['rotation'],'children',len(t['children']))
print('errors',len(errors))

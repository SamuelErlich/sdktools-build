# Amostragem injetada — implementação e prova limitada

## Contrato observado nos fontes recuperados

GameStore.sync(e) atribui os campos do estado e gamers; updatePushMessage(e) usa Object.assign. Card.setup(e,back) conserva o cardInfo e atualiza a skin; callbacks de skin são assíncronos. Socket.sync(), ao contrário, envia CMD_SYNC: não foi usado como botão de leitura local.

Esses módulos vieram do GameSourcesF15B, cujo assets/main/index.js tem SHA256 `6f468e5dfce59961916ea835f0286b725aca61d48cb29d855308134e223a480a`. O código não foi executado para inferir esse contrato. A captura early anterior já demonstrava observadores compatíveis com essas superfícies no aparelho.

## Diferença da3.19.6

Antes: leitura dependia de um Card encontrado na cena e principalmente do instante de polling. Agora:3wrappers capturam cópias numéricas na chamada original, com censo direto de GameStore para o menu, sem varrer a cena. Um botão nativo ativa/renova o modo e solicita tick via a ponte single-flight existente.

O script novo é Resources/card_sampler.js. Não redefine o baralho nem força requests. Instrumentação altera temporariamente descritores de métodos (registrado no relatório), não os campos originais das cartas. A limpeza só restaura descritores ainda pertencentes ao SDKtools; não atropela hooks de terceiros.

## Teste discriminante

Em mock, Card.setup recebe azul9 e o método original zera o argumento antes de retornar. Polling posterior só veria zeros. O novo wrapper copia antes, verifica depois o componente/dono/mão atuais e o menu mostra known1/unknown0; a carta original permanece Back0. Outro teste expõe e limpa selected em dois syncs entre polls; o fato observado permanece corretamente associado à mão.

Testes também cobrem retorno Promise preservado, exceção original sem captura indevida, falha no observador sem impedir original, rollback, lease, hook estrangeiro, remoção/transferência/round/socket,recursos JS≤64KiB, retenção120s, IDs duplicados, nós ausentes, orçamento visual esgotado, contagem e marcador branco. Sem chamadas de rede ou ações de jogo por iniciativa do sampler.

## Evidência antiga não virou descoberta nova

Replay de41Store_after do relatório885A (SHA256 `a7d46b4a1eefe9e4c5b69c7a9fea5a845d624df050d61f0686740d9e47b0ad2f`) mantém totais[7,7,7,7]→[9,4,1,3] e **zero novas faces ocultas**. Isso usa UIDs/nós simulados e apenas os campos gravados; não é prova visual nem captura nova. A carta81vermelho4 nunca entrou em mão, logo não é atribuída a outro jogador.

Próxima evidência necessária: relatório da3.19.7 com sampler ativo durante compras/rodada, especialmente samplerHooks3, counters de sync/setup, samplerHiddenKnown e distribuição handCounts. Não declarar todas as cores recuperadas antes desse teste físico.

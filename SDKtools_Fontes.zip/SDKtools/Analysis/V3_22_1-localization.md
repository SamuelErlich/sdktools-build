# SDK Client 3.22.1 / build 49 — continuação PT/EN

## Pedido e ponto de partida

Em 17/10/2026, o usuário pediu retomar a tradução para português e inglês. O pacote recebido continha o IPA 3.22.0/build 48 já compilado e um rascunho separado de fontes 3.22.1/build 49. Esta etapa continua esse rascunho, preservando os algoritmos dos minijogos e a interface de marca da 3.22.0.

O IPA `WePlay_US_6.6.2_SDKtools_v3_22_0_unsigned.ipa` é a última compilação recebida e verificada. Seu SHA-256 registrado é `9c24a8aaf268a16051b03bfdce0db7689140bc4e5eb3174c7b33ba9f4b246f37`. Ele não contém a tradução nova. A produção de `WePlay_US_6.6.2_SDKtools_v3_22_1_unsigned.ipa` exige uma compilação própria no macOS, integração e verificação do artefato. Nenhuma afirmação neste documento substitui esse resultado.

## Comportamento esperado

O usuário escolhe **English** ou **Português** no seletor **Language / Idioma**, no início do menu. A preferência é persistida em `SDKClient.language`. Sem valor salvo válido, o SDK usa o primeiro idioma suportado na lista de preferências do aparelho, reduzindo variantes regionais a `en` ou `pt`; se a lista não contiver nenhum, usa inglês.

A mudança aplica o novo idioma a textos do menu, ações, avisos, estados, contagens, informações de acessibilidade e ao HUD do Bilhar. O texto de origem é preservado por propriedade para que a alternância repetida não traduza traduções acumuladas. Nomes da marca e dos idiomas permanecem estáveis.

Trocar o idioma altera apresentação e preferência. Não aciona a partida, não reinicia leitura, não muda a seleção dos módulos, não dispara tacadas e não rearma Auto/Aim. As proteções de entrada manual, mudança de cena, abertura do menu e segundo plano continuam as da base. Abrir o menu para alcançar o seletor pode pausar uma automação pela política já existente; essa pausa não foi criada pela tradução.

O catálogo não traduz a interface do próprio WePlay e não preenche dados de jogo desconhecidos. As mensagens de estado conhecidas têm tradução; números, identificadores necessários e conteúdo desconhecido de runtime permanecem disponíveis conforme o contrato de apresentação.

## Arquivos e contrato

| Área | Arquivo | Função |
| --- | --- | --- |
| Catálogo | `Resources/Brand/menu-localizations.json` | `schemaVersion: 1`, idiomas `en` e `pt`, entradas de texto e aliases internos opcionais. |
| Tradução | `Sources/SDKtools/STLocalization.h/.m` | Seleção persistida, catálogo Foundation, tradução e notificação. |
| UIKit | `Sources/SDKtools/STLocalizedUI.h/.m` | Texto de origem por propriedade e reaplicação em views vivas. |
| Menu | `Sources/SDKtools/STOverlay.m` | Seletor, títulos, avisos, estados e acessibilidade. |
| HUD | `Sources/SDKtools/STBilliardsRuntime.m` | Integração da apresentação traduzida do estado de Bilhar. |
| Build | `scripts/build_framework.sh` | Compila os `.m`, roda os contratos e copia o catálogo como recurso. |
| Integrador | `scripts/integrate_ipa.py` | Exige a versão/build e um catálogo válido junto aos recursos da marca. |
| Testes | `Tests/test_localization_catalog.py`, `Tests/localization_test.m`, `Tests/test_packaging.py` | Consistência, execução Foundation e preservação no pacote. |

O catálogo revisado contém 311 entradas e faz parte do framework. Não depende de download, serviço remoto ou chave. O empacotador aceita os layouts de recursos já suportados, direto no framework ou sob `Resources/`, mas recusa cópias duplicadas do catálogo. O build de produção copia o diretório `Brand/` diretamente para o framework.

Adicionar traduções exige preservar os parâmetros de formatação e os aliases sem ambiguidades. Não renomear razões internas, campos exportados ou comandos de jogo para traduzi-los. Acrescentar sua apresentação ao catálogo e exercitar a frase resultante no teste Foundation.

## Verificações e limites

Os testes Python verificam ambas as línguas, placeholders, aliases, cobertura dos textos de cliente e razões de estado do Bilhar. Os testes de empacotamento usam um IPA sintético e comparam os bytes reais do catálogo depois da integração. Catálogos inválidos e duplicados não devem produzir IPA ou manifesto parcial.

O teste Foundation executa o código Objective-C de produção com o catálogo real, verifica ida e volta entre idiomas, estados compostos, contagens, seleção regional, preferência persistida e notificação emitida somente quando a escolha muda. Esse teste requer macOS/Xcode. A compilação UIKit/arm64 e o carregamento no iPhone são verificações distintas.

Nesta retomada Linux, os runners Lua existentes usam a biblioteca de sistema `libtexlua53.so.5` pelo adaptador `ctypes`, sem executar ferramentas binárias recebidas do outro ambiente. Foram aprovados 68 testes do observador, 114 casos de estratégia, oito de identidade de contexto e dez da fronteira Lua. Os 691 testes JavaScript também passaram. Esses resultados verificam regressões portáteis; não substituem Foundation/UIKit e não provam o funcionamento do jogo no aparelho. O resultado consolidado de Python e os demais registros ficam no manifesto de validação desta versão, com skips e ambiente.

Até que a CI 3.22.1 e seu artefato sejam obtidos, não reapresentar os resultados históricos da 3.22.0 como validação da tradução. O IPA novo deve ser entregue junto ao `SDKtools_Fontes.zip` correspondente, com versão/build, checksum e condição de assinatura conferidos.

## Conferência no iPhone após compilar e assinar

1. Com o aparelho em português e sem preferência salva, abrir o menu e verificar português; repetir o primeiro uso em inglês quando viável.
2. Alternar para English e voltar para Português com o mesmo menu aberto. Verificar títulos, estados, avisos, acessibilidade e valores, sem controles duplicados ou ações inesperadas.
3. Fechar e reabrir o aplicativo. A escolha deve continuar salva. Mudar o idioma do aparelho não deve substituir a escolha explícita do SDK Client.
4. Conferir uma tela pequena, paisagem, texto ampliado e VoiceOver. Textos não podem impedir acesso ao seletor nem aos controles; a área de conteúdo continua rolável.
5. Verificar os estados reais de Alpaca, Cartas e Bilhar em cada idioma. Para Bilhar, conferir o HUD e seus estados de espera/pausa/execução, sem mudar os contratos da automação.
6. Confirmar que marcar um idioma não rearma funções, não inicia leitura e não dispara uma jogada. Validar separadamente a pausa já existente causada pela abertura do menu.

Registrar vídeo, versão instalada, idioma inicial, sequência de toques e mensagem divergente se houver. Ajustar o catálogo ou o vínculo de apresentação correspondente, sem alterar o algoritmo do minijogo para corrigir um texto.

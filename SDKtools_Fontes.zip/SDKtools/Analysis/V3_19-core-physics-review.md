# Revisão independente do núcleo físico V3.19

Arquivo revisado: `sdktools-us-v319/SDKtools/Resources/billiards_probe.lua`, leitura inicial das linhas600–1046. Nenhum fonte de produto foi alterado por este revisor. Revisão matemática e comparação com fonte recuperado, sem execução em Unity/iPhone.

## Conferências positivas

- O lançamento usa a potência atual do slider, CUE_POWER_MAX como denominador, massa viva e divisão por massa para Impulse.
- Torque baseline tem fator0.008×0.1 e sinal negativo de cross(up,J), gerando backspin leve com controle centralizado. O uso de inverso escalar de inércia é coerente porque o código rejeita tensor anisotrópico.
- O tensor é lido do Rigidbody; não é usado o placeholder serializado(1,1,1). Perfil físico tolera5% de desvio de uma esfera ideal e divulga o valor observado.
- O contato do pano calcula slip `v+omega×r`, limita impulso a Coulomb, aplica torque/inércia e depois damping linear/angular. Os dois coeficientes são lidos e validados.
- Contato de duas esferas usa massas explicitamente, restituição1 e conserva omega (material nominal bola-bola tem atrito0).
- Contato com parede usa restituição0.8 e duas tangentes de atrito. Tangente vertical remove o termo1/m por FreezePositionY, mantendo torque; fórmula coerente para esfera isotrópica e normal horizontal.
- Os cortes são aplicados separadamente: linear abaixo de sqrt(.008), angular abaixo de.2; só declara repouso depois de ambos zero.
- Tempo, eventos, consultas e segmentos têm limites; um limite gera estado parcial/unknown, não transforma arbitrariamente o ponto final em repouso.
- Telemetria de massa, damping, tensor e vetores de velocidades é coletada antes do retorno moving.
- Tutorial e spin selecionado relevante são recusados com motivo próprio; não reutiliza silenciosamente fórmula da partida normal para o tutorial.

## Bloqueador encontrado e comunicado

`materialMatches` exigia dynamicFriction e staticFriction iguais ao mesmo parâmetro. Para bumper, a chamada exigia ambos0.5, mas o material real do cache possui dynamic0.5/static0/bounce0.8. Com leitura de material disponível, uma tabela legítima era rejeitada. O autor do núcleo foi avisado para separar os dois coeficientes e incluir teste com material realista.

## Ajustes adicionais comunicados

- Fonte original dispara na igualdade com a deadzone: condição de cancelamento é `p < max*deadzone`, enquanto a primeira implementação usava `<=`.
- O modelo assume FreezePositionY e centro de massa/collider central. Recomendada validação/leitura explícita desses campos, pois massa/drag/raio não provam essas condições.
- Coeficientes numéricos de material não bastam se combine modes mudarem. Perfil recuperado é frictionCombine3=Maximum e bounceCombine1=Multiply; conferir quando acessíveis.

## Limitações que permanecem materiais

O próprio snapshot declara `modelLimit=no_custom_contact_correction`: não replica reposicionamentos e zeragem angular por `reboundPos/reboundDir` da guia original. A ordem entre primeira colisão de uma bola antes parada, atrito do pano e geração de omega ainda não foi identificada pelas capturas antigas (elas só têm velocidade escalar). A validação `sliding-transition-validation.md` confirma fases de deslizamento e endpoints condicionados ao rolamento, mas mostra que supor omega zero ao final do primeiro tick pode atrasar a transição.

Assim, “estimativa física finita” é uma descrição sustentada. “Calibração completa”, “ponto final exato” ou “solver idêntico ao jogo” ainda não são sustentados.

## Releitura após correções

Os quatro pontos comunicados foram corrigidos pelo autor e conferidos novamente no código:

- `materialMatches` recebe o atrito estático separadamente; bumper é validado com dynamic 0.5, static 0 e bounce 0.8.
- Combine modes são conferidos quando disponíveis: Maximum/3 para atrito e Multiply/1 para restituição.
- O corpo precisa expor centro do collider, centro de massa, constraints e maxAngularVelocity; o perfil exige os dois centros nulos, FreezePositionY e maxAngularVelocity 500.
- A comparação da deadzone passou a usar `<`, correspondendo à igualdade aceita pelo código original.

Não foi encontrado outro bloqueador físico na revisão estática do núcleo atualizado. Esta conclusão não substitui execução no Unity/iPhone nem elimina as limitações de ordem de contatos e correções nativas descritas acima. A execução da suíte do produto ficou com o autor do núcleo, evitando duplicar o trabalho paralelo.

# WePlay US 6.6.2: alvo do SDKtools V2

Inspeção estática do arquivo recebido em 14/10/2026. Nenhum código do aplicativo foi executado. Os arquivos de entrada permaneceram inalterados, e nenhum fonte do SDKtools foi modificado nesta análise.

## Identidade confirmada

| Campo | WePlay US recebido | WePlay anterior |
|---|---|---|
| Bundle ID | `com.wejoy.weplay.us` | `com.wejoy.weplay` |
| Versão / build | 6.6.2 / 132 | 6.12.0 / 275 |
| App interno | `Payload/weplay-us.app` | `Payload/weplay.app` |
| Executável | `weplay-us` | `weplay` |
| Arquitetura / plataforma | ARM64 / iOS | ARM64 / iOS |
| iOS mínimo declarado | 15.0 | 15.0 |
| Tamanho do IPA | 408.919.954 bytes | 513.643.006 bytes |
| Entradas no ZIP | 6.842 | 7.198 |
| Bytes expandidos | 658.815.174 | 774.693.830 |
| UUID principal | `22f12a1a-f282-346a-9c98-a4646d8802ef` | `a5b5432e-b628-380e-9269-625b1060927d` |
| Folga zerada do cabeçalho | 1.736 bytes | 1.376 bytes |
| gameType de Sheep | 60, confirmado neste binário | 60, confirmado no anterior |

“US” é o identificador observado do pacote. A presença de tradução portuguesa foi confirmada; a análise não demonstra quais regiões, servidores ou funcionalidades estarão disponíveis para a conta do usuário.

SHA-256 do novo alvo:

```text
RAR  75bcfa8ecd4427e8f4ccfffcf8a3c192ecc96c997a292014e104684f518db8b1
IPA  b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4
main 2a1d3c9832a5e7158e72404ce0d139165bb3e348707d5e427271b264da6c79cc
```

O RAR5 contém um único IPA regular. O inventário ZIP foi verificado antes da extração seletiva: nomes absolutos, `..`, barras invertidas, nomes duplicados após normalização, links, entradas especiais, criptografia ZIP, tamanho por membro, tamanho total e razão de expansão. Não foram encontrados problemas nessas verificações. Os limites foram 100.000 entradas, 2 GiB por membro ZIP, 6 GiB no total e razão máxima de expansão de 1.000.

## Sheep e Crazy Alpaca

As classes `WPLGSheepGameHomeViewController`, `WPLGSheepTeamPKLogic`, `WPCocosGameViewController` e `WPCocosGameDataProviderWrapper` existem no novo executável. As traduções portuguesas `LGSheepBroadcastTextKey` e `LGSheepCntKey` identificam o conteúdo como alpacas. O texto literal “Crazy Alpaca” não apareceu nas strings e JSONs examinados.

O identificador **gameType 60 foi confirmado novamente**, sem reaproveitar endereços da versão anterior:

| Evidência ARM64 no novo executável | Resultado |
|---|---|
| `WPLGSheepGameHomeViewController.preloadCocosIfNeeded`, VA `0x100a3d7e4` | Carrega 60 em `w2`, depois chama `preloadCocosIfNeededWithGameType:` |
| `enterMatchTeamWithMode:betLevel:`, VA `0x100a3c494` | Carrega 60 em `w2`, depois chama `setGameType:` |
| `enterSingleModeLGSheepGameWithRoomInfo:`, VA `0x100a4e390` | Passa 60 no argumento gameType de `createEnterRoomParamWithEnterType:gameType:isQuickStart:rid:inviteUid:` |
| `practiceGame`, VA `0x100a3bb64` | Chama o pré-carregamento Cocos e `startSingleModeLGSheepSuccess:failure:` |

A correspondência visual com a partida que o usuário abriu ainda precisa da gravação real. Classes, identificadores e traduções fornecem evidência estática; não substituem essa confirmação.

## Contêineres e WebView

A rota Sheep continua preparando Cocos. O `WPCocosGameViewController` mantém um ivar `_wkWebView` de tipo `@"WKWebView"`. Seu `loadCurrentGame`, VA `0x1009afa90`, contém chamadas `loadFileURL:allowingReadAccessToURL:` e `loadRequest:`. Existem métodos para baixar e atualizar recursos WebMobile por gameType.

Foi encontrada também uma rota de **`WPStandaloneCocosGameViewController`**, derivada de `WPBaseViewController`. A associação com Cocos/WebView foi verificada por chamadas, não apenas pelo nome:

1. O wrapper `viewDidLoad`, VA `0x100ab5198`, chama a implementação Swift em `0x100ab4f24`.
2. Essa implementação chama o helper em `0x100ab7e00`.
3. O helper referencia `WPCocosGameViewController`, usa `initWithDelegate:gameDataProvider:`, adiciona um child controller e sua view e solicita `loadCurrentGame`.
4. O contêiner filho é o mesmo que possui `_wkWebView` e carregamento WebKit confirmados acima.

Isso sustenta observar o standalone como contêiner Cocos adicional. Ele não identifica Sheep sozinho: é compartilhado entre jogos. No standalone, os ivars Swift `dataProvider` e `cocosGameViewController` têm encoding vazio no metadado Objective-C; eles não devem ser lidos como objetos por offsets assumidos.

O IPA ainda traz Unity/IL2CPP, com global-metadata versão 31. A busca de strings identificou callbacks `OnSheepGameStart`, `OnSheepGameEnd` e `playingSheepGame`; isso, isoladamente, não é o código do tabuleiro. Não foi encontrado um pacote JavaScript identificável do tabuleiro Sheep entre os arquivos `.js`, `.jsc`, `.lua`, `.luac` e `.html` do IPA. Os scripts nomeados disponíveis estão ligados a players de URL/YouTube/VK e recursos HTML genéricos.

## Contratos que devem ser respeitados

`WPCocosGameViewController.gameType` mantém assinatura `q16@0:8` e propriedade readonly. **Não existe `_gameType` nessa classe.** O getter encaminha para `gameDataProviderWrapper.cocosGameType`, que consulta seu provider.

O ivar `_gameDataProviderWrapper` mudou do offset estático 32 na versão anterior para 40 nesta. Esses números servem apenas para demonstrar a mudança do layout. Não são offsets prontos para uso no dispositivo, onde o runtime pode ajustá-los devido à superclasse.

A nova classe Swift `_TtC12HWLittleGame29WPStandaloneCocosDataProvider` expõe getters `gameType` e `cocosGameType` com assinatura `q16@0:8`. Ela também tem metadado `gameType:q`, tamanho 8. A existência desses campos não justifica percorrer objetos ou usar offsets fixos no gravador inicial.

A captura pode registrar hierarquia UIKit, classes presentes, geometria, orientação, eventos de toque, vídeo e confirmação explícita do usuário. Um contêiner Cocos ou canvas pode oferecer apenas uma superfície visível, sem cards individuais na hierarquia. Não declarar cartas ocultas, regras de pareamento, vitória ou possibilidade de autoplay apenas a partir desses metadados.

## Empacotamento e assinatura

No principal, `LC_ENCRYPTION_INFO_64` declara `cryptoff=16384`, `cryptsize=61849600`, `cryptid=0`. Os 16 executáveis identificados por Info.plist, incluindo UnityFramework, também declaram `cryptid=0`. Isso descreve os arquivos recebidos, sem alegar descriptografia realizada ou funcionamento comprovado.

O principal mede 78.612.768 bytes. Os load commands terminam em 14.648 e a primeira seção começa em 16.384, deixando 1.736 bytes zerados. Há `LC_CODE_SIGNATURE` com offset 76.646.272 e tamanho 1.966.496. Não existe `embedded.mobileprovision` no IPA. A assinatura criptográfica não foi verificada.

A integração deve conferir bundle, versão, build e hash deste alvo. Não aceitar automaticamente a versão anterior somente porque ela também contém Sheep=60. A nova assinatura precisa contemplar o bundle e seus componentes; o teste real no iPhone continua necessário.

Não foi executada compilação com SDK Apple, instalação, login, chamada a servidor do app nem partida nesta análise. O SDKtools V2 deve manter a separação entre captura comprovada, identificação candidata, confirmação do usuário e observação ainda indisponível.

## Método

Inventário e extração seletiva com libarchive 3.7.2 e ZIP da biblioteca padrão. Leitura de Mach-O e metadados Objective-C com parser limitado ao formato observado `DYLD_CHAINED_PTR_64_OFFSET` (6), seguido de decodificação limitada de referências ARM64 e resolução de seletores. Não houve decompilação geral. A definição de ponteiros foi conferida com [fixup-chains.h da Apple](https://github.com/apple-oss-distributions/dyld/blob/main/include/mach-o/fixup-chains.h) na análise anterior.

Este relatório e seu JSON não incluem tokens, dados privados, imagens comerciais nem binários do aplicativo.

# Correção da compilação V3.19.1

Execução informada: https://github.com/SamuelErlich/sdktools-build/actions/runs/38952582887/job/117147385895

O log enviado contém 2.856 verificações Foundation e uma falha: `chain fixture retains its three paths`. Os 61 testes Lua e os 491 testes JavaScript passaram nessa execução. O aviso de função não utilizada não é o bloqueador.

O cenário nativo passou a receber `finite_chain` na V3.19. Ele produz cinco segmentos: bola 1 toca 2; bola 2 toca 3; bola 3 chega à caçapa; bola 1 para; bola 2 para. O teste de regressão de viewport ainda exigia três e selecionava `lastObject`. Na previsão finita, o último segmento é a parada da bola 2, não a caçapa da bola 3.

A correção mantém cinco segmentos esperados para esse cenário e seleciona a caçapa por `ballTag=3` e `terminal=pocket`. Confere y=1760 antes de alterar para y=2160 e mantém as rejeições tanto em aiming quanto em moving, para tela com altura1920. Nenhuma proteção nativa foi removida ou ampliada.

A física, a leitura, o desenho, Alpaca e Cartas não receberam mudanças funcionais. A identificação passou para 3.19.1/build37. Os arquivos de fontes e workflow devem ser atualizados juntos e usados em uma nova execução.

## Verificação local

O produtor Lua real gerou os cinco segmentos. Todos os 13 pontos originais passaram pela função C de viewport usada no produto, compilada e executada localmente. O ponto mutado y=2160 foi rejeitado. O harness Foundation corrigido ainda exige execução macOS; este resultado não substitui a compilação Apple.

SHA-256 do log enviado: a30a245c83eda9dfaacfe2860a3d9ccb7559407d3f8f3a5def6a5c725858220b

# Bilhar ativo com comandos recusados — 3.23.2/build 52

O usuário testou a 3.23.1 e enviou uma captura: aba Bilhar “Ativo”, Guia selecionada e aviso “Abra o minijogo correspondente antes de usar este controle”. Essa evidência identifica o bloqueio no gate de novos comandos; não demonstra erro de projeção de câmera ou de estratégia de tacada.

O scanner estrito STClientFindGame recusava qualquer presentedViewController na raiz de qualquer janela elegível, antes de localizar a UnityView. A identidade passiva ignorava essa condição. Já o runtime percorria os controladores apresentados e aceitava o jogo dentro da tela superior. Assim, uma apresentação legítima do próprio jogo podia produzir exatamente a contradição da imagem. A captura não fornece a hierarquia UIKit real do aparelho; a correção cobre esse caminho comprovado no código, sem alegar teste físico.

STClientHostViewAllowsActions agora é compartilhado pelo scanner e pelo runtime. Percorre até 16 controladores apresentados; exige que o superior contenha a UnityView e não esteja em transição. Confere ancestrais visíveis, bounds, cadeia de controladores e hit-test na janela do jogo. Uma janela alheia sem UnityView não veta o host identificado. Continuam exigidos foreground, tela/cena correta, UnityView única e identidade Lua positiva. Um modal acima do host bloqueia; um controlador que hospeda o próprio jogo não.

A identidade passiva conserva o opt-in durante uma oclusão temporária. Toque, teclado e comandos em outro módulo continuam sujeitos às verificações existentes. O aviso de comando diferencia contexto ausente de impedimento temporário e expira ao aceitar uma ação. EN/PT preservados, com uma mensagem nova traduzida. Estratégia Lua, física e rotas de disparo não foram alteradas nesta revisão.

Regressão: Tests/client_host_test.m inclui os dois arquivos de produção, sem reimplementar o gate, com uma fronteira UIKit simulada em Foundation. Cobre host direto, apresentado e aninhado; modal acima; hit-test externo/descendente; teclado/toque; transições; host invisível/vazio; Unity duplicada; janela alheia apresentada; modal SDK; identidade Lua inválida; outros módulos; background/cena/tela; ciclos e nil. scripts/test_client_host.sh integra o caso ao build oficial. Os testes anteriores continuam no workflow. A simulação não é execução UIKit nem teste no iPhone.

Entrega exige CI oficial do ZIP atualizado, integração e comparação de recursos/hash do IPA. Assinatura, instalação e validação física são etapas distintas.

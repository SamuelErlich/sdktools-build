# SDKtools 4.0.12 / build87 — rota global SOLO

O Auto SOLO passa a planejar **todas as cartas da fase atualmente carregada**,
com dependências de cobertura, bandeja, reserva verificada e estoque real.
Não usa combinações aleatórias. O objetivo é maximizar cartas eliminadas,
procurando primeiro uma continuação integral, não uma porcentagem do Win.

- Aguarda censo estável e completo Store + cena. Carta sem tipo/regra confiável
  impede jogadas automáticas. Não inventa cartas de fases futuras.
- Busca determinística retomável, memoização e limite de 60.000 estados;
  fatias pequenas evitam uma busca síncrona longa na WebView. Pode demorar.
- **Rota integral comprovada no modelo:** sequência inteira foi reproduzida
  por replay independente. Antes de cada evento original, revalida a prova.
- **Melhor rota encontrada:** a busca atingiu limite ou não achou solução
  integral. Não significa rota ótima provada nem impossibilidade da mesa.
  Só libera prefixo de uma rota reproduzida com eliminação comprovada.
- **Penetrate (3):** previsto na sequência somente com estoque positivo e
  terceira carta comum coberta para um par exato na bandeja. Confirma pedido,
  resposta, Promise, débito de uma unidade e remoção das três identidades.
- **Retornar (1):** modelado inicialmente quando origem real na mesa e
  geometria de retorno são verificáveis. Reserva de origem desconhecida não
  é inventada. Retornos posteriores exigem novo estado observado/prova.
- **Guardar (0), Embaralhar (2), Bomba (4), Remover (5):** preservados no SOLO;
  sua seleção/colocação futura pelo servidor não tem contrato determinístico
  comprovado. O fallback heurístico antigo não pode gastar sem certificado.
  No modo equipe, a política anterior continua separada.
- Após efeito confirmado, reproduz o restante da rota no novo snapshot. Se
  houver divergência ou mudança de fase/estoque/preferência, recalcula.
  Uma operação física incerta nunca é reenviada por timeout, pausa ou reset.
- SOLO sem rota não aparece mais como aguardando oferta compartilhada.

**Não existe garantia de zero erro ou de 100% em toda mesa.** O gerador do
servidor não foi recuperado; a hipótese de que todas as mesas são resolvíveis
não foi provada. Mesmo uma mesa solúvel pode exceder o orçamento de busca.
Uma prova local cobre apenas regras conhecidas da fase carregada, não missão
especial, outra fase, taxa Win, vitória reconhecida ou conteúdo do servidor.

O IPA precisa de assinatura própria. iPhone e servidor não foram testados.
Arquitetura e validação: `Analysis/V4_0_12-global-solo.md`.

## Histórico preservado — notas abaixo pertencem a versões anteriores


## Mapa para o programador

1. `alpaca_snapshot.js`: censo completo observado, regras, DAG, reserva,
   inventário e escopo/revisão. `total_num` não é o tamanho do censo atual.
2. `alpaca_global.js`: modelo puro + DFS iterativo + transposições; ordenação
   determinística, nunca Math.random. Integra estoque finito 1/3 na transição.
   `replay` separado refaz agrupamento/inserção e trio adjacente, capacidade7,
   acessibilidade e consumo. `complete` só se nenhuma carta restar.
3. `alpaca_global_runtime.js`: associa modelo ao contexto privado real,
   normaliza IDs locais e emite certificado privado; não envia ações.
   Prefixo normal até trio ou poder, com continuação integral quando exigida.
   `advance` só carrega sufixo integral após efeito confirmado, refazendo replay.
4. `autoplay_tool.js`: chama controller SOLO antes de fast/extended/coop;
   evento serial, sem Super Fast speculative batch para essa rota. A equipe
   mantém planejamento próprio. `globalPending` é marcador, não autorização
   para limpar a trava física. Preferências/pausa invalidam a prova, não a ação.
5. `autoplay_powers.js`: `beginPlanned` consome somente a prescrição validada;
   reutiliza eventos originais e coordenador owned de `alpaca_covered.js`.
   Não altera estoque/permissões/flags/payload. Rejeita novo begin se ocupado.
6. `STWebProbe.m`, `STAutoplayBridge.inc`: dois resources obrigatórios de
   até64KiB, composição no bootstrap e reutilização do mesmo runtime no hot
   path. `STAutoplaySanitizer.inc` exporta somente contadores/enums fechados.
7. `STAutoplayRecorder.inc`, catálogo PT/EN: separa busca, prova integral e
   rota parcial na fase atual. Não exporta IDs ou a sequência no diagnóstico.

`optimal` significa máximo eliminado no modelo conhecido quando o solver
prova limite superior/exaustão. Não minimiza custo de poderes. Desconhecidos
não entram como transição fictícia. A busca interrompida não prova derrota.

## Testes e reprodução

`alpaca_global.test.cjs`: núcleo puro. `alpaca_global_oracle.test.cjs`: outro
oráculo de inserção/trios/DAG, enumeração independente e comparações pequenas.
`alpaca_global_runtime.test.cjs`: certificados, estoques, mutações, carry.
`alpaca_global_integration.test.cjs`: adapter de produção, censo real simulado,
18 cartas com armadilha local e solução global; 12 cartas com Penetrate
correlacionado e continuação integral; dados inválidos, pausa e timeout.
Mocks explícitos não substituem teste físico. Nenhum fonte comercial foi
executado; são fixtures, não evidência de vitória no jogo.

Base factual de regras e poderes: hashes congelados do cliente recuperado
em `V4_0_11-owned-powers-evidence.json`. O cliente recebe a geração do servidor;
não há contrato provando que todo payload/fase tem uma solução integral.

## Ensaio físico mínimo

Auto OFF/Powers OFF primeiro: conferir censo da mesa atual sem eventos.
Ativar Auto SOLO e aguardar busca. Fotografar status completo/parcial.
Em rota completa, conferir sequência, mudanças da bandeja e novo snapshot.
Testar PowerOFF e estoque zero, alteração manual de carta, troca de fase,
pausa durante pedido e resposta atrasada: jamais pode duplicar ação incerta.
Penetrate: verificar trio exato e estoque. Nunca confundir diagnóstico local
com confirmação de vitória. Guardar relatório fechado, versão e horário.

## Limite medido, não ocultado

Antes do DFS, dois passes determinísticos procuram um testemunho completo
por topologia/ordenação. Não executam cartas durante o teste; só publicam
rota depois de replay completo. A fatia de3ms controla o loop de busca,
não é prazo rígido para toda avaliação (normalização/replay/GC também custam).

Benchmark Node/V8 sintético reproduzível em Tests/alpaca_global.benchmark.cjs;
resultados congelados em V4_0_12-synthetic-benchmark.json. Casos228/510 com
solução construída foram completados. Porém um DAG228 reordenado, com solução
conhecida e validada, atingiu60.000 estados e encontrou somente105/228 no
modelo. O status correto é melhor encontrada/optimal=false, não mesa impossível.
Isso refuta qualquer promessa de que esta implementação já encontra sempre100%.
Os tempos/memória são de Windows/Node; não representam WebKit ou iPhone.

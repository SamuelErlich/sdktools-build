# Bilhar 3.21.0 / build 47 — evidência, implementação e limites

## Identidade e REA

Base SDK 3.20.0, commit aad34127ce44ad85918fd20d0235c0c709d85c7d.
WePlay US 6.6.2/build132, UnityFramework UUID 26e49e8150e8396ba9f2b3bf243a464b.
REA abriu e inventariou `Bilhar_fontes_Lua_cache_1084.zip`, SHA256
0214a0bac5e1e9b9dc94940dc4603f056ca9cc0936541b5d43d70d6cb16a7ca2.
282 nós/ocorrências, sem contradição de integridade no inventário. Evidência
pai ev_fa7c77d4558aa886af92f06eda1ceabc59871330dc36d22b6fec43f284e3c6e2.
O inventário REA vincula o artefato, **não interpreta Lua nem prova comportamento
no aparelho**. A análise semântica abaixo vem da leitura dos Lua recuperados,
com hashes/linhas no ledger. Não foi executado o Lua original do jogo nesta estação.
As análises ARM64/IL2CPP anteriores permanecem em Analysis/V3_14…V3_19.

## Física e fluxo originais rastreados

- `ui/panel/bigamepanel.lua:413–432`: onPowerRelease lê o slider e o cueAngle
  local. Direção `(sin(rad(angle)),0,cos(rad(angle)))`. Deadzone usa máximo
  **do slider**. Chama setShotData e shotBall, além dos efeitos/coroutines originais.
- `core/game/biframelogic.lua:1036–1052`: updateCueDir muda curDir e chama
  handleCueRotation, que também atualiza o cueAngle fechado do painel. Alterar
  apenas curDir não bastaria: o release poderia lançar na direção antiga.
  updatePower ajusta slider/display sem soltar a tacada.
- `core/game/biframelogic.lua:1098–1156`: impulso
  `J = 0.031*p*sqrt(p/CUE_POWER_MAX)`; velocidade `J/massa`, sem multiplicar
  dt outra vez. Denominador CUE_POWER_MAX e máximo do slider são distintos no break.
- `components/ballbehavior.lua:158–188,500–507`: corte linear compara
  squaredSpeed a 0.008; velocidade de corte é sqrt(0.008). Torque inicial com
  efeito zero mantém o termo 0.008; usa tensor de inércia, não massa.
- `core/game/biailogic.lua:28–48,142–199,211–315,406–412`: IA original lê
  Table/Pots, faz SphereCast e reflexão de tabela, usa ghost-ball e força
  heurística `(distâncias)*50 + fatorAngular*40`. O SDK **não chama** essa IA:
  ela contém randomização, alterações da branca e coroutines próprias.
- `core/game/bigamedatalogic.lua:7–38`: gameId vincula a partida, mesmo se
  o objeto gameInfoData for reutilizado. Só é mantido no estado local; não é exportado.
- `core/game/biframestatelogic.lua` e `const/enum.lua`: break3, aberta5,
  grupo definido7, fim10; cor0 indefinida/1 lisas/2 listradas. Bola8 só é
  candidata quando todas as próprias já saíram; na aberta, apenas se sobrou a8.
- `components/auxiliarylinebehavior.lua`: updateAuxiliary modifica aimBall,
  aimBallPos e correções de rebound. Não é uma consulta pura. Nenhuma busca de
  candidatos do SDK o chama; só o fluxo original de release o faz como no jogo.

## Conferência binária adicional da cena

O UnityFS Scene cache1084 (SHA256 99110f8cb6061c9476addbfef64efefb397e4dce31136eae1c17169237fce199)
contém BuildPlayer-BilliardInGame (SHA256 de641a5b11a8130a0a8fab4d110bf0019f7187394c97bb3ff861c2fe2f7e872e),
generator2022.3.62f1. Parser binário limitado de GameObject/Transform recuperou
a hierarquia e compôs TRS/quaternions, sem executar o jogo. Código e resultados
reproduzíveis estão nos arquivos V3_21_0-read-scene-geometry.py e
V3_21_0-binary-scene-geometry.json; não se trata de pseudocódigo produzido pelo REA.

**Correções encontradas antes da entrega final:** Table/Pots tem sete filhos:
seis caçapas e PotsRollBalls. As centrais têm z≈2.93597 e−2.96946, mas os cantos
usados pela IA para tabela ficam em≈2.83122 e−2.84941. Usar extremos de todas
as caçapas ou exigir childCount6 tornaria a automação inoperante/incorreta.
O código filtra as seis caçapas conhecidas e usa os cantos potUpRight/potDownLeft,
com os insets0.07/0.15 e raio vivo. Fixture numérico derivado desta cena fixa
a regressão. Mais um cast vertical revalida a superfície/material vivo sob a
branca; tabelas também exigem material vivo correspondente.

## Implementado

1. **Leitura** continua inerte. `sample` e `stop` não alteram jogo/mesa.
2. **Aim** e **Autoplay** são opt-ins separados no menu Bilhar. Aim ajusta
   direção **e força** pelos métodos originais, mas nunca chama release.
3. Planner numérico puro: candidatos bola/caçapa, ghost-ball, oclusão com raio
   vivo, ângulo de corte, distância/folga, risco geométrico de scratch e tabela
   de uma reflexão da bola-alvo. Até8 candidatos físicos,12 iterações de força
   cada. Desempate determinístico. Sem rota de encaçapamento, tenta contato
   direto legal/safety; no break, contato direto forte com máximo vivo.
4. Força calculada por impulso original e integração escalar contato-slip →
   rolamento, dt0.02, massa/inércia/raio vivos validados, drag/angularDrag0.5,
   atrito1, cutoff0.008. Banco usa perda estimada de restituição0.8. Modelo
   físico reduzido, **não execução do solver Unity**, nem simulação completa
   de colisões simultâneas, efeitos ou posição final de todas as bolas.
5. Antes de preparar: SphereCastAll vivo confirma primeira bola e trajeto do
   objeto/caçapa/tabela, normal/reflexão. Antes do release: outro cast confirma
   novamente a primeira bola. Não move transforms, não escreve Rigidbody,
   não altera materiais/constantes e não usa Physics.Simulate.
6. Espera mesa estável150ms/frames distintos; prepara mira; espera pelo menos
   300ms e guia original coerente. Latch instalado **antes** de um único
   onPowerRelease. Exceção/ausência de movimento não autoriza reenvio.
   O latch por partida/turno sobrevive a desligar/religar no menu.
7. Revalida dono do turno, gameId, roundId/turnCount, cena/câmera, started,
   canShot, controles habilitados, slider, perfil físico, bolas paradas e
   ausência do diálogo de efeito. Troca de partida/câmera, fim/rewind param.
   Requer as16 identidades da mesa e nenhum slot inativo/não encaçapado ambíguo.
   Um comando de armamento **somente de leitura** vincula a partida no instante
   do clique, antes de qualquer decisão. Aim e Auto têm permissões distintas;
   recarga/troca da VM não herda permissão. O lado nativo também vincula
   sessão/cena/câmera/viewport e não rearma ao reencontrar outra mesa.
8. Calibração de lançamento: apenas um trecho reto de40–200ms por tacada,
   antes do primeiro contato possível; exige velocidade/direção/deslocamento
   coerentes, rejeita correções/teleports. EWMA limitada0.9–1.1; só influencia
   força depois de3 amostras qualificadas. Não calibra resultados/ganhos nem
   promete identificar todo erro de PhysX. Contador zero significa sem ajuste.
9. Toque manual, abrir menu e segundo plano pausam. Nova ativação é explícita.
   Final de partida é terminal. Nenhuma chamada a reqReady, reqMatch, revanche
   ou Continuar. O SDK não compra nada nem inicia nova fila.
10. HUD passivo compacto: estado, bola/caçapa, força, tacadas solicitadas na ativação atual,
    amostras de calibração e tempo desde início da leitura. Export inclui
    até64 registros de automação. Solicitação não equivale a acerto confirmado.

## Limites que não podem ser escondidos

- Ball-in-hand requer colocação manual; toque pausa e depois é preciso rearmar.
- Tutorial, offline, spin selecionado, perfil/material/cor/identidade
  incompatíveis e rota não confirmada aguardam ou param; não improvisam jogadas.
- Tabela retangular vem dos mesmos transforms/insets da IA original; casts
  vivos rejeitam modelos de tabela que não coincidirem com os colliders reais.
- Há heurística de risco e planejamento de uma tacada, não busca global de
  vitória nem “aim perfeito”. Break não garante as quatro tabelas da regra;
  safety não garante que a branca pare sem follow/spin residual.
- As suítes são mocks com Lua5.3 real e fixtures históricos. CI Apple valida
  compilação/link/empacotamento, **não** compatibilidade viva ou taxa de acerto.
  Sem iPhone conectado, não há como declarar funcionamento final no aparelho.

## Validação no iPhone

1. Instalar IPA assinado; abrir a partida atual. Começar com **Aim sem disparar**.
   Conferir bola/caçapa/força e que nenhuma tacada foi enviada sozinha.
2. Testar diretas e depois uma tabela; comparar guia/movimento/export de cada
   tentativa. Excluir spin, tutorial e ball-in-hand da primeira medição.
3. Ativar Autoplay; confirmar exatamente uma tacada por turno. Tocar na mesa,
   abrir menu e ir ao fundo: precisa pausar sem retomada silenciosa.
4. Completar partida: precisa parar sem revanche/fila. Exportar leitura.
5. Examinar automation.last/history, motivo de espera, shots e calibração.
   Separar tacada enviada, movimento observado e bola efetivamente encaçapada.
   Não declarar ganhos/perdas de moeda: nenhuma moeda foi identificada aqui.

Alpaca (missões/Turbo/planejamento/poderes) e todos os15 JavaScripts de recursos
permanecem byte a byte na versão3.20.0. Alteração de STRecorder é apenas pausa
passiva do Bilhar e string de versão; Cartas não recebe novas suposições de cor.

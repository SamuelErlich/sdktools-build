# V3.23.14 / build 64 — falha de compilação no parser LAN

## Evidência recebida

- Origem: SDKtools-v3.23.13-US-Diagnostico.zip, 314144 bytes.
- SHA-256: c18b5512a211dc0d079d5254908f615774ca74bff3eb5a2dab0c37f6d51ffbc5.
- sdktools-build.log: 6184 linhas. Xcode 16.4 / build 16F6, iOS SDK 18.5.
- Manifesto recebido coincide byte a byte com a base imutável 3.23.13/build 63;
  todos os 524 hashes de fontes dessa base foram reconferidos antes da cópia.
- O texto colado é somente o início do log. A causa consta no log completo ZIP.
- Linhas 6175 e 6178: STLANProtocol.inc:17:18 e :22:18, erro
  `property 'count' not found on object of type '__strong id'`.
- Os 976 testes JS e os 151 testes Python anteriores passaram no CI recebido.
  O build parou compilando Tests/lan_server_test.m, antes do framework iPhoneOS.
  Warnings de funções/parâmetros não usados não são a causa desse encerramento.

## Causa e correção

`isKindOfClass:` valida o objeto em execução, mas não altera seu tipo estático
`id` para a resolução de propriedades pelo Clang. Não é falha de GitHub, Xcode
instalado, PIN ou conexão do iPhone. A correção valida o dicionário primeiro e
atribui `NSDictionary *command=value` antes de usar `.count`. O objeto de
preferências recebe validação equivalente, antes de acessar propriedades.

Não foram removidos testes, suprimidos erros do compilador, alteradas flags
para ignorar a falha ou ampliados os comandos aceitos. Tipos inválidos continuam
retornando nil; contagem exata de chaves, números inteiros não booleanos e
booleanos estritos continuam obrigatórios. Casos nativos adicionais cobrem
nil/NSNull/string/array/número, ações válidas, preferências inválidas, nível
booleano, flag numérica e chave extra. O contrato Python verifica a ordenação
das guardas e evita reintroduzir `.count` sobre os objetos genéricos.

## Preservação e limites

Nenhuma alteração em lógica JS/Lua do jogo, assets LAN ou transporte TCP.
Versão/build foram atualizados consistentemente para 3.23.14/build 64.
Contrato Python de fontes não é prova de compilação: Windows não tem SDK Apple.
Os testes nativos continuam obrigatórios no workflow, seguidos do build arm64
iPhoneOS. Não foi executada nova compilação Apple nem conexão a servidor de
jogo ou iPhone a partir deste host. Ver manifesto e STATUS_BUILD da entrega
para os resultados locais e hashes finais. Validação LAN real continua pendente.

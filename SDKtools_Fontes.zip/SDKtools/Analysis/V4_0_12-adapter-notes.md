# Adapter notes retained from 4.0.11

Whole-line comments moved here to keep the original 64 KiB resource bound.
Code is not minified; new global logic lives in separate modules.

40: Read-only: no overlay work, preferences, input, power popup or pending reconciliation.

260: Task.setup uses task_info; reward animations may display the old task.

269: The Game component must own the gameplay layer and task subtree.

416: The original locked-card badge is static; bomb/hot-time branches are not.

590: Freeze proof progress, retaining every pending original request.

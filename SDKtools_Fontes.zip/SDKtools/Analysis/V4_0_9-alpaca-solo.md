# Alpaca solo — V4.0.9/build84

O vídeo de 23/10/2026 mostra um jogador, Auto e Raio X ativos e o aviso persistente
"armazém ainda não sincronizado". A exportação SDKtools.Capture schema3 da4.0.8
não iniciou gravação, mas retém96eventos:71 phase_snapshot_unavailable, snapshot
invalid_slots e195cartas/16tipos;42ícones de camadas e0contornos, sem envio.

Fontes originais recuperadas em `recuperacao/alpaca-rea-2026-10-22/logic-only/`
comprovam Enums.GameMode.ModeThreeGame=0 eModeSingle=1. GameLayer.init exibe e
inicializa CommonStore apenas em equipe; solo oculta o nó e pula init. GameStore.sync
copia common_blocks em ambos. O leitor exigia ownership e nós visíveis sempre que
houvesse linhas recebidas, invalidando a fase no solo. autoplay_tool exige essa fase
tanto para agir quanto para fornecer uma prova ao contorno do Raio X.

A correção usa o modo original1, não o número de jogadores: equipe pode ter só
um participante restante. No solo o snapshot produz sharedSlots=[] e não lê o
prefab oculto; common_blocks ausente/nulo é ausência de dado não utilizado, e um
container fornecido continua exigindo array de até3itens. Preserva a identidade
do container no epoch e a verificação de troca durante a aquisição. Modo faz parte
da representação canônica; trocar modo invalida a estabilidade. Equipe e modos
desconhecidos mantêm a validação anterior. Sem alteração de flags do jogo, mensagens
de rede, ownership, confirmação de efeitos pendentes, KeyAuth ou revogação.

RED/GREEN: testes do snapshot reproduzem armazém oculto/não inicializado, campos
omitidos, transições entre modos e containers inválidos. A integração usa o runtime,
leitor, planejador e overlay reais: no solo envia o evento original da carta própria,
produz3contornos com Auto desligado e não envia nenhuma ação nesse caso. A mesma
estrutura inválida em equipe continua bloqueada. A revisão independente não
encontrou bypass para buscar itens compartilhados: coop requer3slots verificados.

Evidências locais, captura sanitizada, quadros e relatórios em
`recuperacao/alpaca-solo-2026-10-23/`. A captura não contém os objetos CommonStore
brutos; o diagnóstico liga o motivo observado às regras do jogo e a uma reprodução
determinística. CI e entrega posteriores ficam em CONTEXTO.md, sem alterar o ZIP
já compilado. Não houve teste físico da correção nem garantia de tempo real0,05ms
ou taxa de vitória.

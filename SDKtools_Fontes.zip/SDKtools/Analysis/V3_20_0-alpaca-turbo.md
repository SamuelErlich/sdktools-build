# Alpaca Turbo: contratos e revisão 3.20.0

## Escopo e proveniência

Alterações no SDK próprio, base imutável3.19.9/45. Nenhuma requisição real enviada desta estação. Fonte original do Alpaca analisado estaticamente, SHA256 `cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`.

Evidência REA histórica: `ev_dd6444e1867e31b5754942583b950411648ed71ae31b661765736bcc48a0649c` (estoque/partida) e `ev_3f2c82f2b6a506cd75eec2c0024106e49a9e80a7ab2b9959726e71325cf77b74` (missão). O bundle histórico completo teve128 módulos extraídos por AST, sem executar código capturado. `UsePropAlert` foi relido no mesmo bundle, intervalo de caracteres3632251–3635265: setup recebe propInfo, desabilita estoque zero, fecha em4s; confirmação usa Socket.UseProp(propInfo.id), exceto Penetrate, que exige seleção adicional. Intervalos de caracteres não são offsets binários UTF8.

## Separação de responsabilidades

- `autoplay_planner.js`: preservado byte a byte; próximo trio, prioridade de missão e fallback normais existentes.
- `autoplay_extended.js`: envelope opcional. Validação inicial pelo planejador original; busca incremental multitrio com corte de feixe e orçamento limitado. Não possui controle do jogo. Publica somente a sequência até o primeiro trio, submetida ao replay independente existente no adapter.
- `autoplay_tool.js`: snapshot vivo e cartas por EventHandler/EventTouch originais. Turbo reduz cadência/estabilidade, mas mantém duas observações e planejamento/execução em ticks diferentes. Preferências não apagam envio incerto.
- `autoplay_powers.js`: coordenador opcional. Lê Game→GameLayer→PropArea e GameStore/Socket vivos. Usa `return_tool.js` existente, preservado, para abrir/confirmar. Sem transporte próprio, alteração de inventário ou compra.
- Nativo: três opções de sessão, consentimento explícito para consumo, timer serializado e telemetria saneada. Troca de documento com poder não resolvido bloqueia reinício automático.

## Poderes

PropType original: Storage0, Withdraw1, Refresh2, Penetrate3, Bomb4, remove5. Automação cobre somente0–2. Cruza Prop.propInfo com props_blocks; o wrapper original verifica a assinatura visual completa dos3 slots e eventos registrados. Não deduz tipo apenas da posição.

Guarda: jogador vivo/não espectador, Started2, modos especiais inativos, conexão aberta, rodada/sala/usuário/Socket/websocket estáveis, estoque positivo coerente entre Store e componentes. Não exporta identificadores.

Reserva exige trio imediatamente acessível para cada possível subconjunto de3 cartas transferidas. Desfazer exige trio após a volta e considera cobertura criada pela carta que retorna. Não garante aceitação pelo servidor. Refresh é estocástico e avaliado só após o uso.

Confirmação exige estoque específico diminuído exatamente1 e efeito correspondente: Reserva move3 identidades de mão para reserva; Desfazer move a última carta à origem; Refresh conserva identidades/zonas/mão e altera ao menos um tipo fora da mão. Duas observações coerentes separadas por80ms, quebradas por snapshot incompleto. Estoque sem efeito ou efeito sem estoque não prova sucesso. Refresh que sorteie exatamente a mesma distribuição fica incerto e nunca é reenviado automaticamente.

Não há correlação nova de packet_id/ack para poderes: o contrato observado é estoque mais efeito da mesa pelo fluxo original. Não rotular disparo como confirmação de servidor. A tentativa de trava anterior, cujo500 foi relatado pelo usuário sem novo relatório anexado, está suspensa/oculta; não identifica uma regra de servidor.

## Limites

Busca em feixe não é exaustiva: uma rota melhor pode ser descartada. No máximo18 seleções hipotéticas,24 estados por camada,12000 expansões e24 fatias de6ms. O resultado publicado prova o primeiro trio, não a vitória. Turbo40ms é cadência alvo, não duração garantida da jogada: WebKit, animação e rede continuam limitando.

Bilhar e recursos de Cartas preservados. Arquivos de exportação nativos do Bilhar só recebem a string de versão. Fixtures são mocks/capturas históricas, não execução nova em Unity/Cocos/iPhone.

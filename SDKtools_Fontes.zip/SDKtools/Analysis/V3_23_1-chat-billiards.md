# SDK Client 3.23.1 / build 51

Correções motivadas por relato físico do usuário: chat, teclado e emojis desligavam os recursos; Mira/Auto do Bilhar permaneciam ligados sem agir e o menu mostrava “Conferindo a mesa e a câmera”.

## Ciclo de vida

A identidade do jogo para manter uma opção ligada agora é separada da autorização de um comando. A descoberta passiva aceita a mesma instância positiva sob apresentação/oclusão temporária. A fronteira de ação continua exigindo contexto visível, não obstruído, aplicativo ativo e minijogo correto. Cartas também exige o mesmo WebView, controlador e URL. Identidade ausente, navegação, saída real e background não concedem retomada automática em outro jogo.

O observador de eventos antes desarmava automações em qualquer toque fora da janela SDK. Agora faz apenas bookkeeping na main, sem texto ou posições. Toques em andamento, teclado visível e 350 ms após encerrar interação suspendem novos comandos. Uma nova interação invalida ações preparadas; não apaga ações já enviadas/incertas. A chamada original de sendEvent continua exatamente uma vez.

A resposta assíncrona do Alpaca antes reusava a autorização de novo comando: abrir chat entre envio e callback gerava `dispatch_uncertain` artificial. Agora o envio exige a fronteira estrita; o callback exige aplicação ativa, mesmo WebView, janela, controlador, gameType 60, URL, carregamento encerrado e namespace/documento nativo verificado. A resposta ainda cruza o sanitizador e erros reais/timeouts continuam pausando. Essa validação somente aceita evidências, não emite nem repete uma ação.

No Bilhar, a retomada usa `suspend`, sem `stop`/`arm`: limpa estabilidade/mira preparada, conserva lease explícito, identidade da partida, pending e lastAttempt. Redimensionamento da tela exige viewport válido e novo preparo; mudança de sessão, cena, câmera, recuo de frame ou estado terminal continuam bloqueando. Abrir o próprio menu SDK continua pausando a automação, como antes.

## Bilhar

A confirmação de frames confundia intervalo entre leituras com TTL de desenho. Se o produtor + planejador + agendamento ultrapassassem 350 ms, leituras novas sempre voltavam a warmup. Agora a continuidade tolera até 1 s entre frames comprovadamente avançados. O desenho e frames repetidos continuam expirando em 350 ms, medidos do início da captura; uma lacuna maior ou troca de contexto exige duas observações. Não se renova o prazo de um frame congelado.

`settingItem.touchable` não prova que uma janela está aberta: era um falso bloqueio do controlador. Foi removido como autoridade de modal; permanecem as verificações da UI original de taco/força, turno, canShot, partida, geometria e janela nativa. O status real do controlador deixa de ser sobrescrito pela mensagem genérica de warmup.

## Evidências e limites

Regressão Lua 5.3 usa o produtor/estratégia reais com objetos Unity sintéticos: botão de configurações habilitado, sample intercalado com Aim/Auto, suspensão, novo preparo e nenhuma repetição de tacada pendente. O teste Foundation extrai os métodos nativos reais de automação e bookkeeping para simular teclado, toque, cancelamento, SDK, viewport, contexto e terminal incerto. A política C cobre leituras a 360–900 ms, frame congelado, expiração e reconfirmação. Essas simulações não comprovam execução no aparelho. Compilação iPhoneOS e integração devem passar na CI oficial do ZIP desta versão; instalação e teste físico permanecem separados.

# Bilhar: o que o material disponível permite identificar

Análise estática de 16/10/2026, a partir dos fontes SDKtools V3.12 e de dois exports reais de minigames. Nenhum código dos jogos foi executado. O executável e o IPA original não estavam disponíveis para uma nova varredura binária.

## Resultado

**O ID do bilhar ainda não está comprovado.** Os exports disponíveis contêm os jogos 60 e 2007, sem um catálogo geral que identifique bilhar. Isso não demonstra que bilhar esteja ausente do aplicativo e não estabelece necessidade de comprar outro IPA.

| Export examinado | Identidade registrada | Motor encontrado no código |
| --- | --- | --- |
| `SDKtools-GameSources-8B4DDC11-2958-4B0D-BDE3-811A3F4B11DD(1).json` | `gameID=60`, Alpaca; exportador 3.0.0 | Cocos Creator 2.4.4, `web-mobile` |
| `SDKtools-GameSources-4CC51D29-6885-441A-8726-D42A25F92F56.json` | `gameID=2007`, cartas; exportador 3.5.1 | Cocos Creator 2.4.5, `web-mobile` |

Ambos registram WePlay US 6.6.2, build 132, pacote `com.wejoy.weplay.us`. Foram recalculados e conferidos os SHA-256 de todos os 15 arquivos JavaScript embutidos. `scopeComplete=true` descreve o escopo do pacote do jogo exportado, não o conjunto de todos os minigames do aplicativo.

SHA-256 dos exports completos:

```text
Game 60:
ae2d416e6b90ca841b87fa37a86e040d4524e7c104efe83e0f05f5829c7dc593

Game 2007:
22cf7f4e66bf1ba760444d4cdd9ea4423aa175d12920d1d86d967f394e5dc010
```

## Busca e falsos positivos

A busca foi feita nos textos JavaScript decodificados dos JSONs, ignorando maiúsculas/minúsculas, pelos termos `billiard`, `snooker`, `8ball`, `8-ball`, `8 ball`, `台球`, `桌球`, `sinuca` e `bilhar`. Não houve correspondências. Também não foi identificado um catálogo que associe outros títulos a IDs de jogo.

As ocorrências de `pool` são de `poolSize`, pools de memória/objetos do motor ou substrings em dados opacos do Alpaca. Não identificam bilhar. No Alpaca, `Ball=11` pertence a `BlockType`, a lista de peças que inclui `Cheese`, `Carrot` e `Scarf`. Esse valor não é um `gameID`.

As análises nativas preservadas são recortes voltados ao Alpaca, e não uma listagem completa das classes, strings e recursos do IPA. Em particular, a antiga análise Unity não foi uma investigação de bilhar. Sua ausência nesses recortes não permite excluir uma implementação nativa, Unity, Cocos ou carregada depois.

## Caminho reaproveitável no mesmo aplicativo

O material já registra uma rota nativa de identificação de jogos Cocos. `WPCocosGameViewController.gameType` tem ABI `q16@0:8`; o getter encaminha a consulta por `gameDataProviderWrapper.cocosGameType`. Não existe evidência para inventar um offset `_gameType` nesse controlador.

O mecanismo anterior de descoberta em `STNewGameCapture.inc` espera duas observações consecutivas estáveis do tipo numérico, controlador, WebView e documento. A fase de descoberta não avalia JavaScript. A identidade numérica e o título são evidências distintas: abrir o bilhar e confirmar a tela é necessário para associar o número observado ao jogo correto.

Essas características podem ser reaproveitadas para descobrir o bilhar no app já instalado. A existência desse caminho não prova que o bilhar use o mesmo contêiner. Se ele usar outro motor, primeiro será necessário identificar o controlador e a rota reais. Não atribuir ao bilhar o ID 60, 2007 nem uma versão de Cocos por analogia.

Referências verificadas na base V3.12:

* `Analysis/WePlay-US-CrazyAlpaca.md` e `.json`: identidade do app, rota compartilhada Cocos/WebView e getter nativo.
* `Analysis/V3_3-new-game-capture.json`: escopo, condições e limites da descoberta existente.
* `Sources/SDKtools/STRecorder.m`: verificação de classe, assinatura Objective-C e vínculo com a WebView.
* `Sources/SDKtools/STNewGameCapture.inc` e `STNewGameCapturePolicy.h`: estabilidade do contexto e confirmação da identidade.

O JSON ao lado preserva os hashes dessas referências **na base V3.12**, antes de eventuais mudanças da V3.13. Uma mudança posterior no fonte não transforma uma evidência histórica em observação nova do bilhar.

## Limites da conclusão

Não foi observada uma sessão de bilhar nesta análise, não há `gameID` comprovado, não há fonte do bilhar nos dois exports e não foi avaliada disponibilidade por região. Não foi realizada nova análise de Mach-O porque os bytes do IPA não estavam disponíveis. Os hashes históricos do IPA e do executável constam do JSON, identificados como provenientes da análise anterior.

A próxima evidência útil é o bilhar aberto no mesmo aplicativo, com controlador, motor e identidade numérica registrados. Depois de confirmar essa identidade, pode-se avaliar um export do pacote local correspondente. Este relatório não implementa recursos de bilhar nem altera as rotinas do Alpaca.

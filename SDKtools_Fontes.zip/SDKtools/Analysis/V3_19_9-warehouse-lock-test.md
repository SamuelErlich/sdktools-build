# Teste de escrita do lock — escopo e evidência

O alvo é a barreira local de CommonStoreItem.commonBlock.lock_state recuperada na análise REA `ev_dd6444e1867e31b5754942583b950411648ed71ae31b661765736bcc48a0649c`. Bundle original SHA-256 `cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`. A regra de servidor permanece desconhecida.

## Experimento

- Requer contexto nativo Alpaca, Cocos2.4.4, modo em time, não espectador, Game/GameLayer/CommonStore válidos, único slot isSelf, vazio com lock1..3, Socket conectado e candidatos originais de seleção.
- Instala observador de uma escolha e listener do mesmo WebSocket; não chama o comando de escolha.
- Salva descritor de lock_state; define valor zero; chama warehouse_tool original (inalterado) para abrir; restaura no finally antes da seleção manual.
- A escolha manual continua o fluxo original de Block.touchBlock/ChooseCommonBlock. Uma sombra de send existe somente na pilha síncrona dessa chamada e é restaurada no finally; bytes são encaminhados intactos.
- Header de resposta exige evento do mesmo WebSocket, isTrusted=true, packet_id correspondente e code numérico. Não retém/exporta corpos/credenciais/identificadores.
- 200 e carta observada são fatos distintos. Confirmar carta exige o mesmo ID privado selecionado no slot atual e coerência Store/componente. O ID nunca sai do runtime.
- Lease30s/15s remove observadores. Cancelamento ou timeout não reenvia pedido; tentativa já usada permanece travada nesse runtime. O menu nativo é ainda mais restrito: não oferece novo arm após um teste iniciado, até reiniciar o app.
- Não sobrescreve objeto novo recebido nem um hook de terceiro que substituiu o nosso. Conflitos de limpeza/restauração são sinalizados.

## Preservação

Os recursos existentes, inclusive warehouse_tool, autoplay_planner, autoplay_tool e todos os de Cartas/Bilhar, permanecem byte-idênticos à3.19.8. Há um recurso adicional warehouse_test.js. O código nativo adiciona o menu, serialização, telemetria e guardas de exclusão durante o experimento; o algoritmo de missão não mudou.

## Não demonstrado

Aceitação real de uma escolha com slot bloqueado; motivo exato de uma eventual recusa; regra de avanço de lock_state; reuso depois da retirada; desbloqueio permanente; compatibilidade física do fluxo neste iPhone. A versão analisada historicamente pode não ser idêntica ao módulo atualmente carregado.

A observação também fica vinculada ao start_time da rodada, à sala e à instância da conexão (valores somente em memória). Troca de rodada/sala/reconexão invalida a confirmação do slot, mesmo com IDs de carta reutilizados.

# Unity, IL2CPP e a pista Sheep

Análise estática do pacote WePlay 6.12.0 fornecido, realizada em 14/10/2026. O app não foi executado. Os hashes e os registros selecionados estão em [Unity-Sheep-evidence.json](Unity-Sheep-evidence.json).

## Resultado

O IPA contém Unity, mas os metadados examinados não identificam um motor de cartas do Crazy Alpaca. As únicas referências específicas a `Sheep` estão no ciclo de renderização de `Main.dll` e em wrappers XLua. Isso permite localizar uma pista de integração, sem demonstrar que o tabuleiro roda em Unity.

Essa distinção importa para o SDKtools: procurar um array de cartas em classes Unity com nomes inventados não produziria uma captura confiável. A análise nativa paralela encontrou uma rota Cocos/WebView; a captura da V1 deve registrar a tela realmente aberta antes de escolher uma ponte específica para os elementos da partida.

## Identidade e verificação

| Item | Observação |
|---|---|
| Framework | `Payload/weplay.app/Frameworks/UnityFramework.framework` |
| Metadados | `Data/Managed/Metadata/global-metadata.dat`, 28.265.552 bytes |
| SHA-256 dos metadados | `097c94473049aa2c4d7cb7273ba616ce47b0d0fa5a8009df9df7517af3f5c842` |
| Cabeçalho IL2CPP | Magic `0xFAB11BAF`, versão 31, cabeçalho de 256 bytes |
| Tabelas | 29.134 tipos, 231.265 métodos, 137.898 campos, 144 imagens |
| Unity do bundle principal | Cabeçalho UnityFS de `Data/data.unity3d`: `2022.3.62f1` |
| Recursos padrão | `unity default resources` contém cabeçalho `2022.3.54f1`; não substituir a identidade do bundle principal por essa versão |
| Framework Info.plist | Plataforma iPhoneOS, mínimo iOS 12.0, SDK declarado iPhoneOS 18.5, Xcode declarado 16.4 |

Foram conferidos os limites das regiões declaradas no cabeçalho, os índices dos nomes de todos os tipos e métodos, e o tipo declarante de cada método. O formato usado para a versão 31 tem registros de tipo de 88 bytes e de método de 36 bytes. Essa leitura valida a interpretação dessas tabelas; não valida execução, assinatura, integridade completa do app ou endereços em memória.

## Referências Sheep realmente encontradas

| Assembly e tipo | Membros relevantes | Interpretação permitida |
|---|---|---|
| `Main.dll`, `NLRenderData` | `OnSheepGameStart`, `OnSheepGameEnd`, `playingSheepGame` | Integração com o ciclo de renderização é uma hipótese sustentada pelos nomes e pelos membros vizinhos de câmera, luz e resolução |
| `Main.dll`, `NLRenderMgr` | Os mesmos nomes | Segunda implementação relacionada ao renderizador; não presumir qual está ativa |
| `Main.dll`, `XLua.CSObjectWrap.NLRenderDataWrap` | `_m_OnSheepGameStart`, `_m_OnSheepGameEnd` | Wrappers de ligação XLua presentes |
| `Main.dll`, `XLua.CSObjectWrap.NLRenderMgrWrap` | Os mesmos nomes de wrapper | Outra ligação XLua presente |

Os métodos `OnSheepGameStart` e `OnSheepGameEnd` declaram zero parâmetros gerenciados. Os wrappers declaram um parâmetro. Seus endereços nativos, a assinatura ABI completa, os tipos desse parâmetro, o contexto de thread e a instância ativa não foram resolvidos. Nenhum deles deve ser chamado ou substituído com base apenas nesta tabela.

`__Hotfix0_OnSheepGameStart` e `__Hotfix0_OnSheepGameEnd` também aparecem como campos dos renderizadores. Isso confirma a presença desses nomes nos metadados, sem demonstrar uma alteração dinâmica ativa nesta sessão.

## O que não foi encontrado

A busca, sem diferenciar maiúsculas, por `sheep`, `alpaca` e `crazy` nos nomes de todos os 29.134 tipos retornou zero tipos. Os únicos nomes de classes que contêm `Card` são `RoleCardPanel`, `RoleCardShowPanel` e tipos genéricos de bibliotecas; nenhum desses nomes estabelece um modelo das cartas do minigame.

Não foi identificado, nesta análise:

1. Um array de cartas, IDs das figuras, camadas ou regras de bloqueio do Crazy Alpaca.
2. A condição de eliminação, inclusive se o modo exige pares, trincas ou outra regra.
3. Dados de cartas encobertas disponíveis ao cliente.
4. Endereços nativos ou offsets de campos para leitura em execução.
5. A correspondência visual entre o nome mostrado Crazy Alpaca e a rota interna Sheep.

A ausência nas tabelas embarcadas não exclui código removido por otimização, recursos baixados, Lua, assemblies carregados depois, JavaScript ou um jogo em WebView. Não é prova de inexistência do recurso.

## Recursos e atualização dinâmica

`ScriptingAssemblies.json` lista 182 nomes. Nem todos aparecem nas 144 imagens do arquivo global de metadados. Entre os nomes do manifesto existem assemblies terminados em `Hotfix`, `HotUpdate` e `GameAssembly`. Nos metadados há `HybridCLR.Runtime`, classes XLua e infraestrutura de AssetBundle. Esses sinais demonstram infraestrutura compatível com carregamento e atualização de conteúdo, mas não provam que uma partida específica baixou ou executou determinado pacote.

`Data/Raw/ResVersions/versions.json` declara `codeVersion` igual a `4.0.1` e `Infos` vazio. `Data/Raw/db.json` está vazio. Portanto, esses dois arquivos não fornecem um inventário do tabuleiro Sheep.

Não foi feita uma extração completa de objetos serializados de `data.unity3d`. Buscas de texto em conteúdo comprimido não foram tratadas como inventário completo de assets. Também não houve acesso ao cache privado do app no iPhone nem aos arquivos que ele eventualmente baixa depois da instalação.

## Consequências para a captura da V1

Registrar com relógio monotônico os toques, a orientação, os limites da tela, as mudanças de controladores e as imagens visíveis. Ao entrar no minigame, associar esses eventos à superfície efetivamente apresentada, por exemplo um `WKWebView`. A presença de Unity no processo não basta para classificá-la como superfície Unity.

Elementos de UIKit, DOM ou uma árvore de cena Cocos, quando acessíveis por interfaces confirmadas, são observações diferentes de uma captura de tela. Um canvas pode mostrar cartas sem expor cada uma como elemento DOM. O JSON deve dizer de onde cada observação veio e registrar `unknown` para identidade, regra ou visibilidade que ainda não foi comprovada.

A confirmação Crazy Alpaca/Sheep precisa associar uma imagem legível do jogo a uma identificação interna observada na mesma navegação. Uma string encontrada no binário, isoladamente, não resolve a correspondência visual.

O relatório desta etapa não sustenta anunciar raio X ou autoplay. A captura fornece a evidência necessária para avaliar posteriormente as regras, quais cartas estão visíveis e quais estados podem ser lidos com segurança.

## Referência do formato

O parser estático foi conferido com as definições de formato do próprio [Il2CppDumper, MetadataClass.cs](https://github.com/Perfare/Il2CppDumper/blob/master/Il2CppDumper/Il2Cpp/MetadataClass.cs), consultadas em 14/10/2026. O hash do arquivo consultado consta no JSON. Esse projeto foi usado como referência do formato; seu executável não foi executado sobre o app.

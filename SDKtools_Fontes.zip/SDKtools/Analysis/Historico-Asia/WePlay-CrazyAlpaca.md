# WePlay 6.12.0: Crazy Alpaca / Sheep

Análise estática do arquivo fornecido pelo usuário, concluída em 14/10/2026. O aplicativo não foi executado neste ambiente. As observações abaixo identificam componentes e chamadas do binário; não demonstram o estado de uma partida ao vivo.

## Identidade e integridade

| Item | Resultado |
|---|---|
| Arquivo recebido | `com.wejoy.weplay_6.12.0_und3fined.rar` |
| Contêiner externo | RAR5, um membro regular IPA |
| RAR | 502.726.184 bytes |
| IPA interno | 513.643.006 bytes |
| ZIP interno | 7.198 entradas; 774.693.830 bytes descompactados |
| App | WePlay, `com.wejoy.weplay` |
| Versão / build | 6.12.0 / 275 |
| Executável | `Payload/weplay.app/weplay` |
| Plataforma | ARM64, iOS; mínimo declarado 15.0 |
| SDK de origem declarado | iphoneos26.2 |
| UUID Mach-O principal | `a5b5432e-b628-380e-9269-625b1060927d` |

Hashes SHA-256:

```text
RAR  957f3d2fc9e6209e0802de223eedc8831f7e78c5d8a09a37c121aa037976c68f
IPA  4e8abf8d0b9b97cfabc65290b748e98e15a4b2020b55a98068e9f61e070b06e8
main eb12c3232e51b095cbadd2e46fdd4425e876151feb5c1ed18be272e2873c9d21
```

O inventário completo foi verificado antes da extração seletiva: nomes absolutos, `..`, barras invertidas, nomes duplicados após normalização, links, entradas especiais, criptografia ZIP e limites de tamanho. Nenhuma dessas condições foi encontrada. Limites usados: 100.000 entradas, 2 GiB por membro ZIP, 6 GiB no total e razão de expansão máxima de 1.000. A extração ocorreu em diretório novo, sem executar os arquivos.

## O que corresponde a Sheep

Há evidência textual direta da associação entre o nome interno Sheep e alpacas. No recurso inglês `en.lproj/Localizable.strings`, as chaves `LGSheepBroadcastTextKey` e `LGSheepCntKey` exibem textos sobre alpacas. Recursos `lg_sheep_*` e classes `WPLGSheep*` integram a mesma área do aplicativo.

O título literal “Crazy Alpaca” não apareceu nas strings inspecionadas. Um sprite extraído somente para inspeção de `lg_sheep_team_pk.svga` representa o personagem alpaca. Isso não substitui a comparação com a tela que o usuário chama de Crazy Alpaca. A confirmação visual do minijogo fica pendente da gravação no dispositivo e da marcação explícita do usuário.

O identificador interno **gameType 60** possui evidência estática de chamadas, além de nomes:

| Método no executável principal | Evidência observada |
|---|---|
| `WPLGSheepGameHomeViewController.preloadCocosIfNeeded` | Carrega 60 em `w2` e chama `preloadCocosIfNeededWithGameType:` |
| `WPLGSheepGameHomeViewController.enterMatchTeamWithMode:betLevel:` | Carrega 60 em `w2` antes de `setGameType:` |
| `WPLGSheepTeamPKLogic.enterSingleModeLGSheepGameWithRoomInfo:` | Passa 60 como gameType ao construir o parâmetro de entrada |
| `WPLGSheepGameHomeViewController.practiceGame` | Chama `preloadCocosIfNeeded` e `startSingleModeLGSheepSuccess:failure:` |

Esses resultados vieram de metadados Objective-C, limites `LC_FUNCTION_STARTS`, decodificação limitada das instruções ARM64 de salto/carregamento imediato e resolução dos stubs de seletores. Não houve decompilação de alto nível nem validação de execução. Os endereços no JSON associado pertencem exclusivamente ao SHA-256 acima e não devem ser usados como offsets universais.

## Arquitetura encontrada

A tela inicial possui classe nativa `WPLGSheepGameHomeViewController`, derivada de `WPBaseViewController`. A navegação tem prática, busca de partida, criação de sala e modalidades de equipe.

O caminho Sheep pré-carrega Cocos. O contêiner `WPCocosGameViewController` possui `WKWebView`, `WKWebViewJavascriptBridge` e `WPCocosGameJavascriptBridge`. Seu método `loadCurrentGame` acessa `gameResDownloadPath:`, verifica arquivo local e chama `loadFileURL:allowingReadAccessToURL:`. Também contém uma alternativa de `loadRequest:`. A classe `WPLittleGameResourceLoader` possui métodos para baixar e atualizar recursos WebMobile por gameType.

A conclusão sustentada pelo binário é que o caminho nativo de Sheep prepara um minijogo Cocos hospedado em WebView. A versão concreta do pacote e o estado do tabuleiro que forem carregados no iPhone ainda precisam ser observados. O IPA também contém Unity/IL2CPP, mas a mera presença do UnityFramework não o torna o motor do tabuleiro Sheep. A análise complementar está em [Unity-Sheep.md](Unity-Sheep.md).

Não foi encontrado pacote JavaScript identificável do tabuleiro Sheep nas entradas do IPA. Entre os arquivos `.js`, `.jsc`, `.html`, `.lua` e `.luac` inventariados, aparecem apenas quatro HTML ligados a outros recursos. Não foi realizada conexão com os serviços do app para baixar conteúdo adicional.

## Consequências para o gravador SDKtools

1. Registrar classe da tela, hierarquia visível, geometria de elementos, orientação, instantes monotônicos e fases dos toques permite reconstruir o caminho até o minijogo.
2. A presença de `WPLGSheepGameHomeViewController` é uma evidência da tela inicial. A presença isolada de `WPCocosGameViewController` ou de um canvas não identifica Sheep, pois o contêiner é compartilhado.
3. `gameType` no contêiner tem assinatura `q16@0:8`, propriedade somente leitura e nenhum ivar `_gameType`. O getter encaminha a `gameDataProviderWrapper.cocosGameType`, que encaminha ao provider. Portanto não tratar esse getter como leitura de um campo simples nem inventar um offset.
4. Se a versão inicial observar apenas nomes de classes, ela deve exportar uma candidatura a Sheep e a confirmação visual separada do usuário. Não declarar confirmação automática de uma partida apenas pelo nome da tela.
5. Toques, elementos visíveis e vídeo não revelam automaticamente o conteúdo de cartas escondidas. Um canvas pode apresentar uma única superfície à hierarquia UIKit/DOM. O relatório deve indicar essa limitação.
6. O app possui lógica relacionada à proteção de captura de tela. Se a gravação retornar conteúdo vazio, protegido ou erro, registrar isso sem modificar a proteção do aplicativo.
7. Não capturar credenciais, valores de autenticação, mensagens privadas, identificadores pessoais ou todos os dados arbitrários do JavaScript bridge. A captura deve ser iniciada e encerrada pelo usuário, com limites de duração e tamanho.

O raio-x, a solução perfeita do tabuleiro e o autoplay não foram implementados nem demonstrados por essa análise. A primeira entrega deve gerar evidência suficiente para avaliar o que realmente é observável, qual regra de combinação está em uso e quais informações estão disponíveis no cliente.

## Integração, assinatura e limites

O principal e o UnityFramework contêm `LC_ENCRYPTION_INFO_64` com `cryptid=0`. Isso é o estado declarado no arquivo, não uma prova de funcionamento e não uma descriptografia realizada nesta análise.

No principal, o fim dos load commands é 15.008 e a primeira seção começa em 16.384: há 1.376 bytes zerados de folga no cabeçalho. O principal já declara `@executable_path/Frameworks` e `@loader_path/Frameworks`. Esses dados permitem avaliar a adição controlada de um load command, sempre em uma cópia e com validação posterior.

Existe `LC_CODE_SIGNATURE`, com CodeDirectories SHA-1/SHA-256 e CMS. Não foi feita verificação criptográfica da assinatura. Não há `embedded.mobileprovision` no pacote. Alterar o executável exige nova assinatura do bundle e dos componentes pertinentes; assinar ou compilar não demonstra que o app abrirá, que todos os entitlements estarão disponíveis ou que os serviços remotos aceitarão essa instalação.

O ambiente atual não dispõe de Xcode/iPhone para comprovar a compilação com o SDK Apple ou o funcionamento no aparelho. A versão final do pacote deve manter essa distinção entre análise estática, testes locais, build do Actions e teste real pelo usuário.

## Referência técnica do parser

O parser de ponteiros usou o formato observado `DYLD_CHAINED_PTR_64_OFFSET` (6), conferido com as definições públicas da Apple em [fixup-chains.h](https://github.com/apple-oss-distributions/dyld/blob/main/include/mach-o/fixup-chains.h). Os parsers auxiliares e os arquivos comerciais extraídos ficam no espaço de análise, fora dos fontes redistribuíveis do SDKtools.

# Raio X durante Auto — V4.0.1/build 76

Base oficial V4.0.0/build 75, commit 0c17ba8da42e554c21bb1acbbb09bd948054fc9e.
Usuário confirmou desaparecimento dos contornos durante o Auto.

Dois caminhos reproduzidos: o cache conferia miniícones, mas não o Graphics dos
contornos; e os ramos de lote/cooperação/poder pendente renderizavam sempre com
prova nula. Com dois trios, o Auto enviava o primeiro e mantinha o segundo sem
bordas durante a espera pelos ACKs, apesar do Raio X indicar ready.

O renderer revalida seu Graphics e restaura visibilidade/transformação somente
do container SDK. Repinta no máximo três contornos (seis strokes) por leitura;
ícones e contagens válidos continuam em cache. Componente destruído ou
substituído provoca reconstrução dos visuais próprios. Não muda nós do jogo.

Os leitores de ações pendentes podem pedir uma indicação visual independente,
por outra instância do planejador base. Exige fase completa quando aplicável,
ausência de regras desconhecidas, 80 ms de estabilidade e replay independente
da rota. Busca de 2 ms, replay com orçamento de 4 ms; chave muda com a mesa e
com a política de seleção. Respeita a proteção de diamantes durante Auto.
Não prepara nem emite toque, não libera ACKs, não conta confirmação, não muda
a rota nem o estado de estabilidade/espera do Auto. Prova nula nos demais
caminhos continua limpando indicação; não se mantém borda de carta antiga.

Regressões: Graphics limpo/destruído/substituído/desabilitado, layer oculto,
transparente ou transformado; três ciclos de chat, HotTime, poder, pausa e
geração; 200 reparos sem novos nós; segundo trio durante lote pendente sem
quarto pedido. Toggle off, contexto inválido e prova ausente/ inválida removem
os contornos. Testes usam fontes de produção e fixtures Cocos/Socket; não são
validação física. A imagem não permite garantir todos os eventos do aparelho.

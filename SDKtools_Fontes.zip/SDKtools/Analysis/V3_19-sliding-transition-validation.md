# V3.19: validação independente do deslizamento, rolamento e parada

Foram lidos os quatro `v319-analysis/caseN/capture.json`. Todas as medições abaixo usam coordenadas mundiais e velocidades exportadas, sem estimar pixels. Não houve alteração no produto. O JSON complementar contém hashes dos dados, índices das amostras, fórmulas, hipóteses e resultados completos.

## 1. Deslizamento: confirmação numérica forte

Parâmetros testados: dt0.02 s, q0.99, aceleração de atrito9.81. Recorrência: `v_next=q*(v-9.81*dt)`; deslocamento por passo `v_next*dt`.

| Caso / bola tag | Amostras | Passos | Erro da velocidade final | Erro do deslocamento |
|---|---|---:|---:|---:|
| 2 / 4 |11→12|5|−0.0001556812|−0.0000154463|
| 3 / 6 |43→44|5|+0.0000022291|+0.0000006851|
| 4 / 7 |62→63|5|−0.0000039866|+0.0000002210|
| 4 / 7 |63→64|5|+0.0000005150|+0.0000005673|

O primeiro deslocamento a partir da posição estacionária também permite inferir quantos passos móveis ocorreram antes da primeira amostra:

| Caso / tag | Primeira amostra móvel | Passos móveis | Velocidade após o primeiro passo de contato | Erro da distância desde a posição parada |
|---|---:|---:|---:|---:|
|2 / 4|11|1|20.47675075|+0.0000001775|
|3 / 6|43|4|14.75901376|+0.0000006133|
|4 / 7|62|3|19.31663436|+0.0000168912|

A velocidade da tabela é a velocidade reconstruída **ao fim do primeiro passo que moveu a bola**, não impulso puro antes do solver. O primeiro contato e o atrito desse mesmo passo não estão separados nas capturas.

## 2. Os três trajetos pedidos não isolam a transição angular

- Caso2/tag4 rebate já entre12 e13; rebate novamente entre19 e20.
- Caso3/tag6 rebate entre44 e45 e entre46 e47, e posteriormente encontra outras bolas.
- Caso4/tag7 apresenta apenas três amostras móveis antes de entrar na caçapa; não chega ao rolamento livre observado.

Por isso esses trechos confirmam a lei de velocidade durante deslizamento, mas não medem o tensor de inércia nem permitem assumir omega zero ao fim do primeiro passo. Uma mudança de direção ou rebate não pode ser usada para ajustar só o amortecimento.

## 3. Transições adicionais: ressalva importante para I=0.4*m*R²

Encontrei trajetos iniciais mais úteis: caso1/tag5, amostras5–6, e caso2/tag9, amostras26–27. Foram testados passos inteiros, velocidade inicial reconstruída e contato com `u=v-omega*R`, massa efetiva `1+1/k` para `I=k*m*R²`, atrito limitado a9.81*dt e damping0.99 linear/angular.

**Assumindo omega zero ao fim do primeiro tick de contato**, o modelo com k0.4 faz a transição tarde:

| Caso / tag | Velocidade observada na segunda amostra | Prevista com k0.4 e omega inicial0 | Erro |
|---|---:|---:|---:|
|1 / 5|2.102864913|1.919437443|−0.183427470|
|2 / 9|1.807489286|1.655663330|−0.151825956|

Um ajuste nessa hipótese produziria k≈0.278 e0.282. **Isso não prova inércia real0.28 e não justifica gravá-la no produto.** A angular não foi exportada; contato/atrito no próprio passo da colisão e estado angular anterior não estão observados.

Mantendo k0.4, o mesmo trecho fica compatível com valores de velocidade angular inicial não-zero ao final do primeiro tick: `omega*R≈0.6819008822` no caso1 e≈0.5644206582 no caso2. As velocidades finais então coincidem, e os erros de distância do segundo intervalo são aproximadamente0.00000375 e0.00002436. Esses valores também são **ajustes condicionais**, não medições de omega.

O passo correto é ler `rb.inertiaTensor`, `angularVelocity` e tempos em runtime e validar o contato. Não substituir essa lacuna por um fator de inércia ajustado só a duas tacadas.

## 4. Parada desde rolamento medido: precisão muito boa

Depois de entrar em trecho reto e já em rolamento, `v_next=0.99*v` explica velocidade e distância. Somando passos até `v<sqrt(.008)`:

| Caso / tag | Trecho | Velocidade inicial | Passos previstos | Distância prevista | Distância observada | Erro |
|---|---|---:|---:|---:|---:|---:|
|2 / 4|36→76|0.6774487115|202|1.165211317|1.165954628|−0.000743311|
|3 / 6|64→105|0.7367992341|210|1.282093843|1.282128477|−0.000034634|
|2 / 14|43→75|0.4599586742|163|0.733739588|0.734320583|−0.000580995|
|3 / 5|64→99|0.5393238272|179|0.891170096|0.891623813|−0.000453718|

Unidade é a unidade mundial do jogo; raio da bola é≈0.165. Os quatro erros ficam abaixo de0.001 unidade. O código aplica zeragem em `Core.timer`, não comprovadamente na mesma fase do FixedUpdate; sobra de uma fração de passo e ajuste mínimo de contato são compatíveis com os resíduos observados.

Esses resultados validam bem **a previsão condicionada a um estado já observado de rolamento, sem novos contatos**. Não validam por si só o ponto final antes do disparo, porque nesse caso é necessário prever a fase de slip, spin, contatos e rebates.

## 5. Consequências para o modelo V3.19

- Usar passos físicos0.02 e fatores vivos de damping; a hipótese0.99 por passo está diretamente sustentada nas capturas analisadas.
- Usar contato tangencial e omega para decidir a transição; não usar um tempo de deslizamento fixo.
- Ler tensor vivo. Não usar o tensor serializado automático(1,1,1), nem concluir k0.28 a partir dos ajustes acima.
- Separar pré-disparo, primeira amostra pós-contato, rolamento e fim; guardar inputs antes do reset da UI.
- Exportar vetores velocity/angularVelocity, material e métricas de eventos. Velocidade escalar não permite fechar spin.
- Ponto final só deve ser marcado como parada quando o simulador atingir repouso; limite de orçamento não é repouso.

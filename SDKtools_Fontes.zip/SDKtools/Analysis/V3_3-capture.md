# V3.3 — diagnóstico da captura V3.2

O print mostra **“Auto: busca sem rota completa confirmada · 258 cartas · 17 jogadas”**. A mensagem corresponde à política da V3.2 que só libera uma sequência após provar uma rota completa para o objetivo observado. A imagem não prova que não havia trios jogáveis nem que uma vitória sem poderes era possível.

O JSON enviado é um **relatório sem gravação iniciada** (`durationSeconds: 0`, `stopReason: notStarted`), sem cenas, toques ou imagens nativas. Ele preserva os últimos 96 eventos do processo, sequências 58–153, cobrindo 61,66 segundos. Em todos eles, o autoplay está desligado e apenas o X-ray está ligado. Portanto, os zero movimentos confirmados do arquivo não anulam as 17 jogadas mostradas no print: são estados/escopos diferentes e não devem ser fundidos.

## Busca e parada

- Dois eventos `search_limit_reached`: 195 cartas / 20.044 nós / 80 fatias; 192 cartas / 20.045 nós / 82 fatias. Ambos ocorreram com autoplay desligado e X-ray disponível.
- O planejador V3.2 limita a busca a 20.000 transposições ou 120.000 nós. Os números são compatíveis com o limite de memória; o campo de limite exato não foi exportado, então isso permanece uma inferência.
- O restante do histórico inclui animação externa (22), carta ainda não reconhecida (21), estabilização (19), busca (15), geometria (8), barra cheia (7) e modal (2). Não há novos `unsupported_card_rules` nesse trecho.
- O estado final é pausa por toque manual; a leitura mais recente está bloqueada por barra cheia. Nenhuma ação pendente ou enviada aparece no trecho preservado.

## X-ray

O renderizador está `ready` em 36 eventos e bloqueado em 60. Na profundidade 2, desenha 27–32 ícones, oculta 142–154 por profundidade, zero por colisão de layout e nenhuma borda de trio. Esse volume sustenta a necessidade de agrupamento/compactação solicitada, mas o print não permite medir o posicionamento dos ícones porque eles não estão visíveis nele.

As interrupções de leitura limpam o overlay. Não atribuir todas as mudanças visuais a erro de desenho: parte do histórico coincide com animações, transições e barra cheia.

## Novo jogo

O JavaScript original disponível foi inspecionado estaticamente. Há referências semânticas de Sheep; nenhuma identificação confiável de **Ah minha carta**. Ocorrências amplas de `MyCard`/`OhMy` dentro de texto codificado são falsos positivos, não identidade de jogo.

O novo fluxo deve registrar evidências observadas, permitir confirmação explícita do usuário e manter `não identificado` quando faltar evidência. Esta captura não permite confirmar esse novo jogo ou reconstituir seu tabuleiro.

## Consequência para V3.3

A alteração solicitada é retornar a **progresso calculado**: validar uma sequência curta que produza um trio e respeite a capacidade da barra, executá-la com confirmação após cada jogada e recalcular. Não exigir prova de vitória integral para começar, não fazer ação aleatória e não prometer vitória. A avaliação final no iPhone continua necessária.

# V3.22.1 / build 49 — correção de compilação r1

Em 17/10/2026 foi recebido `SDKtools-v3.22.1-US-Diagnostico.zip`.
O manifesto recebido é idêntico ao incluído no primeiro pacote PT/EN.
A execução usa Xcode 16.4 (16F6), iPhoneOS SDK 18.5.

## Falha e correção

O compilador interrompeu `scripts/test_localization.sh` ao incluir
`Sources/SDKtools/STLocalization.h`, linhas 4 e 8:
`error: unknown type name 'nullable'` e `error: expected ')'`.

As declarações são funções C exportadas. O qualificador contextual
`nullable` usado antes do tipo só é apropriado naquela forma para métodos
Objective-C. Os parâmetros foram corrigidos para `NSString * _Nullable`.
O inicializador `- (nullable instancetype)initWithData:` permanece válido.
Não há alteração de assinatura binária, idioma, preferência ou lógica dos jogos.

## Evidências e limites

A CI recebida aprovou 107 testes Python, 691 JavaScript, 68 testes Lua do
observador, 114 casos de estratégia, 8 de contexto e 10 da fronteira Lua.
Ela falhou ao compilar o teste Foundation de tradução, antes do build ARM64
do framework. Isso não comprova aprovação da tradução nativa nem gerou um IPA.

Depois da correção foram executados localmente os 107 testes Python:
106 aprovados e um dependente de Foundation/macOS pulado. A revisão independente
do código não encontrou outro bloqueio concreto nessa área. O teste Foundation
e a compilação iPhoneOS continuam obrigatórios no workflow, sem remoção de gates.
Não há execução em iPhone nesta etapa.

Versão e build permanecem 3.22.1/49 porque não houve uma compilação dessa versão
concluída neste fluxo. A revisão r1 tem novos hashes no manifesto, no ZIP e no
workflow. O pacote PT/EN anterior permanece preservado como referência.

Enviar juntos `SDKtools_Fontes.zip` à raiz do repositório e `compilar.yml` a
`.github/workflows/compilar.yml`, na mesma branch. Executar **Compilar SDKtools US**
com `base_source=release` e `release_tag=base-us-6.6.2`. Reexecutar o job antigo
reutiliza o commit antigo e não aplica esta correção.

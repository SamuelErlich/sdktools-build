# SDKtools V3.2: leitura independente da regressão

A captura V3.1 registra três avaliações com `unsupported_card_rules`, zero movimentos enviados e busca ainda não iniciada. A verificação nativa estava pronta nesses três eventos. Portanto a falha registrada ocorre no leitor JavaScript da mesa, antes do planejador.

O valor `cardsRead: 0` não comprova que a primeira carta falhou: na V3.1 esse contador só é atribuído depois de a leitura inteira terminar. O mesmo motivo genérico cobre nome do componente, metadados, ID, campos especiais e divergência de controle.

## Evidência disponível

Foram lidos o JavaScript original previamente exportado, o adaptador V3.1 e as 19 amostras da nova captura. Dessas amostras, 16 têm leitura de cena truncada e três são completas segundo o exportador. Nenhuma registra `Block.blockInfo`, `canTouch` ou `isTouched`. Não é possível reconstruir o campo exato que provocou o bloqueio no aparelho a partir deste arquivo.

A investigação usou leitura estática e hashes com Python, seguindo os métodos das skills REA e iOS. O motor REA não foi executado. Nenhum JavaScript original foi executado, nem houve interação com servidores do jogo.

## Incompatibilidades comprováveis no código

| Caso | Original exportado | V3.1 | Implicação |
| --- | --- | --- | --- |
| Carta comum com `special_info.type = 0` | Não consulta o bloqueio dessa carta comum. | Exige `lock_state` inteiro sempre que `special_info` existe. | Um objeto comum sem esse campo pode bloquear toda a leitura. |
| ID com partes adicionais | A cobertura usa os elementos 1 e 2 de `id.split('-')`. | Exige exatamente três partes. | Um sufixo válido para o original é recusado pelo adaptador. |
| Carta na barra | A área usa índice da lista, ID e tipo; define o estado `Hand`. | Exige também camada e coordenadas da pilha. | Metadados irrelevantes à barra podem interromper a leitura. |
| Carta na reserva | A área usa `storage_info.layer/index`; define o estado `Storage`. | Exige também camada e coordenadas da pilha. | O adaptador impõe campos que a área original não utiliza. |

Esses são defeitos de compatibilidade demonstrados por comparação estática. A captura não permite afirmar qual deles ocorreu neste iPhone. A versão corrigida precisa registrar um motivo de campo específico para eliminar essa ambiguidade em futuros relatórios.

## Propriedades e representação dos dados

O construtor de `Block` atribui `canTouch`, `isTouched` e as referências de sprites/nós diretamente ao objeto; `init` atribui `blockInfo` diretamente. O caminho de entrada inspecionado utiliza `JSON.parse`. Não apareceu evidência de que `blockInfo` fosse disponibilizado somente por um getter do Cocos. A revisão deve preservar leitura de campos sem executar getters arbitrários.

O tipo de carta usa igualdade estrita na combinação original. Por isso não se deve inventar tipos a partir da imagem, nem converter valores indiscriminadamente e alegar equivalência. Campos desconhecidos usados no planejamento precisam continuar identificados como desconhecidos.

## Relação com o X-ray

Na V3.1, um erro do leitor compartilhado limpa o X-ray antes que o desenho seja atualizado. Isso permite que uma incompatibilidade de metadados interrompa os dois recursos simultaneamente. A correção pode manter o desenho de ícones quando sua leitura visual estiver completamente verificada, mesmo que o planejamento não possa agir.

Nesta captura, entretanto, `xrayEnabled` está falso, a profundidade salva é cinco, e os três eventos de erro registram X-ray desligado. O arquivo não comprova diretamente o comportamento do X-ray ligado; esse resultado depende de validação posterior no aparelho.

## Rastreabilidade e limites

O JSON acompanhante contém dez intervalos de bytes UTF-8, fim exclusivo e SHA-256, além dos hashes dos quatro arquivos analisados. Inclui apenas conclusões e metadados mínimos; não distribui os fontes comerciais originais ou a captura pessoal.

Continuam desconhecidos o valor exato do campo recusado no aparelho, o formato real dos IDs daquela mesa, a correspondência integral entre os bytes carregados e o export anterior, e o resultado de execução da V3.2 no iPhone. A correção dos contratos e os testes locais não substituem esse último teste.

## Revisão independente do patch V3.2

A comparação do adaptador corrigido e seus testes não encontrou defeito concreto novo nos caminhos revisados. Foram executados 15 testes focados, todos aprovados: cartas especiais bloqueadas e desbloqueadas, campos comuns opcionais, sufixos de ID, barra/reserva sem coordenadas da pilha, bloqueios de ação preservados, confirmação pendente e X-ray independente quando a geometria completa continua válida. O JSON registra os hashes dos arquivos revisados. Foram executados somente o código próprio do SDKtools e os mocks de teste; o original exportado permaneceu sem execução. Essa revisão não confirma o resultado no iPhone.

# XLua enum representation and V3.19.1 physics profile guard

Read-only regression review. No product source changed.

## Finding

`sdktools-us-v3191/SDKtools/Resources/billiards_probe.lua` compares the Lua value directly with an integer and otherwise expects Lua `tostring` to equal a bare enum name. This occurs for `Rigidbody.constraints` and both `PhysicMaterial` combine fields. That string expectation is incompatible with the standard XLua C# object formatter present in the supplied native base.

The official Tencent XLua `StaticLuaCallbacks.ToString` appends a colon, space and object hash to the C# `ToString()` result. For ordinary boxed instances of these enums, expected representations include `FreezePositionY: 4`, `Maximum: 3` and `Multiply: 1`. The current guard rejects these correct representations. This is a concrete compatibility defect; because the V3.19.1 capture does not export these fields, identifying it as the exact runtime failure remains an inference until one such value is observed.

## Native evidence

Base identity:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| UnityFramework | 130798400 | `3687cc2e600a2e9767517f0cc4787bdec7c74a68b20768ed701dfae58b02e97a` |
| global-metadata.dat | 29894292 | `be20fd45c444d641780cf476d40af10e97fcfc0bf5dd8a749d477ac985494a5f` |

`Main.dll`, `XLua.StaticLuaCallbacks.ToString`, metadata method index `33402`, token `0x0600827b`, maps to ARM64 image VA `0x40c7700`. This is an image virtual address, not a runtime address.

The bounded disassembly saved as `xlua-tostring-arm64.json` shows:

- retrieval of the C# object via `XLua.ObjectTranslator.getCsObj`;
- two virtual dispatches corresponding to the formatter's object string and hash operations;
- `System.Int32.ToString` at `0x40c77c4`;
- the literal `: ` loaded at `0x40c77d4`;
- `System.String.Concat` at `0x40c77e0`;
- `XLua.ObjectTranslator.PushAny` at `0x40c7800`;
- the alternative literal `<invalid c# object>`.

This matches the official formatter's structure. Metadata also contains `System.Enum.ToString()` and `System.Enum.Equals(System.Object)`. No specifically named `UnityEngineRigidbodyWrap`, `UnityEngineRigidbodyConstraintsWrap`, `UnityEnginePhysicMaterialWrap` or `UnityEnginePhysicMaterialCombineWrap` appeared in the metadata type list; that absence does not prove the currently active binding route.

## Proposed comparison contract

Use a small, explicit normalizer for the known enum type and allowed members:

1. Accept the existing finite integer representation.
2. Try protected equality with the corresponding typed constant under `CS.UnityEngine.RigidbodyConstraints` or `CS.UnityEngine.PhysicMaterialCombine`. A protected `Equals` call with that same typed constant is another value comparison route.
3. Try protected invocation of the C# `ToString` method and map an exact member name. This is distinct from the Lua `tostring` formatter.
4. If needed, accept an exact, anchored Lua string form `MemberName: integer`, mapping the complete name to the expected enum value. Do not interpret the suffix as an enum numeric value: it is a hash. Reject arbitrary suffixes and compound flag names.
5. Otherwise report an unsupported representation; do not silently approve an unknown value.

In particular, `FreezePositionY, FreezeRotation` must not match `FreezePositionY`. A substring search would weaken the physics constraint incorrectly.

## Diagnostics

For every compared enum, export bounded primitive fields: `luaType`, protected `luaString`, protected `methodString`, `normalizedValue` and `matchedVia`. Export `profileMismatch` with the exact field, ball tag where applicable, expected value and observed value. Keep missing, unreadable, unsupported representation and an actual unequal value distinct.

Suggested targeted regression cases: a numeric enum; a boxed mock whose Lua string contains `: hash` but whose C#-style `ToString` is bare; a correct typed enum; a wrong enum from the same type; compound Rigidbody flags; throwing/unavailable `ToString`; an unknown name ending with the expected numeric hash. The last case must remain rejected.

## Primary references consulted

- Tencent XLua, `Assets/XLua/Src/StaticLuaCallbacks.cs`: https://github.com/Tencent/xLua/blob/master/Assets/XLua/Src/StaticLuaCallbacks.cs
- Tencent XLua, `Assets/XLua/Src/Utils.cs`: reflection object metatable registers `__tostring` to the translator's formatter: https://github.com/Tencent/xLua/blob/master/Assets/XLua/Src/Utils.cs
- Tencent XLua, enum field access and casting: https://github.com/Tencent/xLua/blob/master/Assets/XLua/Doc/XLua_Tutorial_EN.md

The native artifact confirms formatter compatibility for the supplied base. Upstream source alone is not used to claim an observed runtime enum representation.

# V3.19 — leitura visual das quatro gravações

Análise somente de leitura. Os quatro vídeos locais têm 384 × 832 px; duração de 28,690 s, 38,093 s, 15,608 s e 14,325 s. Os JSONs correspondentes informam SDKtools 3.18.1. Foram extraídas folhas de contato e janelas a 4 quadros/s com FFmpeg. Tempos abaixo são aproximados no vídeo; não são o relógio `elapsedMs` do exportador.

## Evidência principal

A barra de força está visível à direita. Nas quatro gravações seu preenchimento aumenta e muda de verde/amarelo para laranja/vermelho antes da soltura. As trajetórias do SDK permanecem essencialmente iguais quando só essa força muda. Isso confirma visualmente a limitação do modelo geométrico atual: existe controle de força no jogo, mas sua intensidade não está sendo usada para encurtar a guia.

As linhas desaparecem durante o movimento e reaparecem na mira seguinte. Em especial nos casos 1 e 3, a guia antes da tacada ocupa grande parte da mesa com vários rebates, enquanto a jogada real termina bem antes de percorrer aquela malha. A duração finita observada não calibra por si só um modelo de atrito ou uma fórmula de distância final.

O pequeno seletor de efeito, no canto inferior direito, aparece com o marcador vermelho no centro nos quadros examinados. Não vi abertura ou ajuste desse seletor. Isso sustenta apenas “nenhuma seleção fora do centro visível”; os JSONs não confirmam vetor de efeito zero nem ausência de torque interno.

## Por gravação

| Caso | Tacada visível | O que a gravação permite afirmar | Relação com o JSON |
|---|---|---|---|
| 1, tentativa vermelha/amarela | Soltura entre aproximadamente 12,50 e 12,75 s | Branca acerta vermelha; a amarela também muda de posição, há rebate posterior na borda inferior e movimentos posteriores de outras bolas. A malha prevista é extensa, mas as bolas desaceleram e encerram o movimento. Não aparece nova bola encaçapada nessa tentativa. | `aim=10014,966 ms`, `firstMotion=10112,473 ms`. O anel retido começa em 10714 ms e já está em movimento. Os potted retidos continuam tags 11 e 15. A previsão da mira dizia 5 colisões, 5 rebates e horizonte truncado; isso não é contagem de eventos reais. |
| 2, segunda colisão | **Duas tacadas**, aproximadamente 12,25–12,50 s e 27,00–27,25 s | Na primeira, a vermelha atinge a laranja e a laranja entra visualmente na caçapa inferior direita por volta de 13 s, depois aparecendo no canal lateral. Na segunda, a vermelha percorre a mesa e há contatos na parte superior; a branca termina na parte inferior direita. Não tratar esse vídeo inteiro como uma única tacada. | `lastAimBeforeMotion` corresponde à **segunda** tacada: `aim=24720,655 ms`, `firstMotion=24816,216 ms`. As 120 amostras retidas vão de 23721 a 35721 ms; o trecho físico da primeira tacada saiu do anel. O potted da laranja já aparece entre os estados iniciais retidos. |
| 3, rebate | Soltura entre aproximadamente 7,50 e 7,75 s | A força sobe enquanto a malha permanece estável. Branca acerta laranja; a laranja rebate na região inferior e alcança a roxa. O movimento real fica principalmente na metade inferior e termina antes da extensa malha que incluía a parte superior. A vez do oponente aparece perto de 14 s. | `aim=5623,046 ms`, `firstMotion=5713,855 ms`; moving até a transição not_ready em 12318 ms. Nenhum novo potted no anel. A mira previa 10 colisões e 12 rebates com horizonte truncado, sem provar esses eventos reais. |
| 4, direto | Soltura entre aproximadamente 8,50 e 8,75 s | Verde entra na caçapa superior esquerda perto de 9 s. A branca para na metade esquerda, abaixo da antiga posição da verde. A guia volta após a parada. O indicador de força estava vermelho antes da soltura. | `aim=6916,312 ms`, `firstMotion=7011,267 ms`; tag 7, número 6, passa a potted em 7410 ms. Há 34 amostras moving; not_ready em 10412 ms e aiming em 10523 ms. É o caso com confirmação visual e no estado de encaçapamento. |

Os tempos do vídeo foram lidos nas janelas densas; as folhas globais a 0,5/1 fps servem para orientação e podem selecionar um quadro mais adiante dentro de seu intervalo. Não usar esses tempos para ajustar milissegundos da física. O pareamento vídeo–JSON é contextual, sem marcador comum de sincronização.

No caso 1 há `moving → not_ready` aos 18511 ms e outro `moving` aos 23216 ms, já depois da troca de vez. Portanto, o último snapshot desse arquivo não deve ser usado automaticamente como posição final da tacada associada à mira: a próxima movimentação já pode ter começado. No caso 4, a mira reaparece após a parada; sua previsão atual também não deve substituir a mira guardada antes da tacada.

## Força e posições finais

Nos quatro `lastAimBeforeMotion.aim`, `cue` contém somente `world` e `direction`. Não há força selecionada, força máxima, posição do seletor, torque/efeito ou vetor de velocidade inicial nesse objeto. Os vídeos provam que há um indicador visual de força, mas não identificam o campo Lua/UI que o alimenta nem a função que converte esse indicador em impulso.

É viável extrair uma proporção visual aproximada do preenchimento da barra para comparação offline. Isso não fornece força física exata: a barra pode ter curva não linear, escala dependente do taco e fase de retorno após a soltura. O caminho preferível no produto é ler o valor de arrasto/força e os parâmetros do taco já existentes no jogo, confirmando-os contra a barra; ainda falta validar esse campo em uma captura.

Para uma guia com fim definido, a aquisição precisa capturar o comando selecionado antes da tacada, velocidade vetorial e rotação após a soltura, identidade do taco e parâmetros de amortecimento/atrito. O estado posterior pode validar onde cada bola parou. Estes vídeos ajudam a escolher casos e verificar a tela, mas não autorizam anunciar que o cálculo completo de posição final já está calibrado.

## Arquivos de inspeção

- `case1/contact-sheet.jpg`, `case1/release.jpg`, `case1/release-motion.jpg`.
- `case2/contact-sheet.jpg`, `case2/release1.jpg`, `case2/release1-motion.jpg`, `case2/release2.jpg`.
- `case3/contact-sheet.jpg`, `case3/release.jpg`.
- `case4/contact-sheet.jpg`, `case4/release.jpg`.

Nenhum código do produto foi alterado nesta análise.

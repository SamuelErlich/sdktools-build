# V3.19 — calibração das quatro capturas V3.18.1

Análise somente leitura. Foram usados os JSONs e as fórmulas conferidas no código recuperado; vídeo e contato contínuo de física não foram usados para preencher dados ausentes.

## Resultado principal

Há dois regimes distintos de desaceleração observáveis. Em trechos estabilizados, cada passo de 0,02 s multiplica a velocidade por 0,99. Logo após certos impactos há também uma perda de 9,81 × 0,02 antes desse multiplicador. Uma previsão somente com drag prolongaria demais vários trajetos.

As recorrências que reproduzem velocidade e deslocamento juntos são:

- Rolamento: `v[k+1] = 0.99 * v[k]`.
- Deslizamento observado: `v[k+1] = 0.99 * (v[k] - 9.81 * 0.02)`.
- Integração: `posição[k+1] = posição[k] + 0.02 * velocidade[k+1]`.

Nos quatro arquivos, 453 intervalos completos combinam com o primeiro regime e oito com o segundo, sob tolerâncias explícitas no script. Isso é validação de intervalos selecionados por velocidade e deslocamento; não significa que toda a tacada siga um regime único. O equivalente contínuo do primeiro regime é `k = -ln(0.99)/0.02 = 0.5025168 s⁻¹`.

Os dois intervalos livres da bola tag 7 no caso 4 estimam gravidade equivalente de 9,8099589 e 9,8100053. O caso 3 confirma 9,8100230. A combinação é compatível com atrito de deslizamento μ≈1 sobre gravidade 9,81.

## Limite indispensável para a implementação

Não há velocidade angular, torque, potência escolhida nem estado de deslizamento nos JSONs. Assim, o instante de mudança entre os regimes não pode ser calculado de maneira geral somente pela velocidade escalar. No caso 3, a bola tag 6 ainda mostra deslizamento entre 6,318 e 6,416 s, muda durante 6,416–6,517 s e já segue apenas drag depois de 6,517 s. Esse intervalo concreto não define uma duração universal.

O código BallBehavior só zera angularVelocity na colisão com bumper quando reboundPos/reboundDir estão presentes; não faz isso em todo choque com borda nem em toda colisão entre bolas. A física de contato continua responsável pela maior parte da rotação.

## Lançamento e associação

Caso 1: mira 10.014966 s; primeira amostra em movimento 10.112473 s; velocidade observada da branca 20.712870; desvio do deslocamento inicial em relação à mira 0.000000°. Outras bolas já em movimento: nenhuma. Potência percentual não exportada.
Caso 2: mira 24.720655 s; primeira amostra em movimento 24.816216 s; velocidade observada da branca 0.115401; desvio do deslocamento inicial em relação à mira 0.302620°. Outras bolas já em movimento: [4]. Potência percentual não exportada.
Caso 3: mira 5.623046 s; primeira amostra em movimento 5.713855 s; velocidade observada da branca 17.311753; desvio do deslocamento inicial em relação à mira 0.000442°. Outras bolas já em movimento: nenhuma. Potência percentual não exportada.
Caso 4: mira 6.916312 s; primeira amostra em movimento 7.011267 s; velocidade observada da branca 20.311474; desvio do deslocamento inicial em relação à mira 0.000000°. Outras bolas já em movimento: nenhuma. Potência percentual não exportada.

No caso 2, a primeira amostra já vem depois do impacto: branca a 0,1154 e bola tag 4 a 20,4768. Não é uma medição da velocidade inicial da branca. No caso 1, falta um intervalo de aproximadamente 0,602 s depois de firstMotion, e o movimento que reaparece a 23,216 s é posterior à troca de turno; foi excluído.

## Paradas e trajetos observados

`BALL_MIN_VEL = 0.008` é aplicado à velocidade ao quadrado em BallBehavior:onUpdate; o limiar linear é 0,0894427. A maioria das últimas amostras antes de zerar está entre 0,090 e 0,094. O estado global moving pode continuar por rotação e outras bolas. Distância abaixo é soma de cordas entre posições, portanto não substitui trajetória contínua.

| Caso | Tag / número | Distância amostrada | Parada, tempo absoluto da captura | Última posição X, Z | Resultado |
|---|---|---:|---|---|---|
| 1 | 1 / 0 | 4.00354 | 15.019–15.120 s | 0.549491, -1.564277 | Parada observada |
| 1 | 2 / 1 | 1.62330 | 14.821–15.019 s | 0.356119, 0.450737 | Parada observada |
| 1 | 4 / 3 | 10.64645 | 15.212–15.311 s | -2.084065, 1.585328 | Parada observada |
| 1 | 5 / 4 | 3.66322 | 16.817–17.014 s | 0.187550, 1.838279 | Parada observada |
| 2 | 1 / 0 | 0.48554 | 25.320–25.421 s | -3.526336, -1.108146 | Parada observada |
| 2 | 4 / 3 | 13.67372 | 31.318–31.416 s | 4.548325, 0.086691 | Parada observada |
| 2 | 9 / 8 | 3.47850 | 31.519–31.619 s | 3.465840, 2.332622 | Parada observada |
| 2 | 13 / 12 | 0.40827 | 27.819–27.917 s | 4.268047, -1.336633 | Parada observada |
| 2 | 14 / 13 | 0.83041 | 31.218–31.318 s | 5.222156, -1.981735 | Parada observada |
| 3 | 1 / 0 | 4.36321 | 10.014–10.116 s | -2.821421, -0.189379 | Parada observada |
| 3 | 5 / 4 | 0.96923 | 11.522–11.622 s | -2.617527, -1.519917 | Parada observada |
| 3 | 6 / 5 | 10.01098 | 12.116–12.216 s | -4.417039, -0.985135 | Parada observada |
| 4 | 1 / 0 | 2.71637 | 10.314–10.523 s | 0.943703, 1.914203 | Parada observada |
| 4 | 7 / 6 | 4.43957 | Não observada | 4.953099, 2.353055 | Encaçapada; posição da caçapa ausente |

## Conferência de parada nas caudas em rolamento

Para uma velocidade já em rolamento: `n = ceil(log(sqrt(0.008)/v0)/log(0.99))`, limitado a zero; `D = 0.02*v0*0.99*(1-0.99^n)/(1-0.99)`. Os números seguintes começam depois dos impactos e da fase transitória. As diferenças restantes incluem amostragem, posição renderizada e zeragem em onUpdate.

| Caso | Tag | Início | Distância modelada | Distância observada até última posição | Diferença |
|---|---|---:|---:|---:|---:|
| 1 | 1 | 10.714 s | 1.380065 | 1.380730 | +0.000664 |
| 1 | 2 | 10.714 s | 1.277999 | 1.278515 | +0.000516 |
| 1 | 4 | 11.315 s | 1.108257 | 1.108724 | +0.000467 |
| 1 | 5 | 12.617 s | 1.365385 | 1.365945 | +0.000560 |
| 2 | 1 | 24.916 s | 0.048296 | 0.048788 | +0.000492 |
| 2 | 4 | 27.219 s | 1.234339 | 1.235143 | +0.000804 |
| 2 | 9 | 30.121 s | 0.184345 | 0.184986 | +0.000641 |
| 2 | 14 | 27.917 s | 0.780674 | 0.781257 | +0.000583 |
| 3 | 1 | 6.916 s | 0.701702 | 0.702143 | +0.000441 |
| 3 | 5 | 7.918 s | 0.946212 | 0.946655 | +0.000443 |
| 3 | 6 | 7.918 s | 1.357278 | 1.357312 | +0.000035 |
| 4 | 1 | 7.213 s | 0.679909 | 0.680392 | +0.000483 |

## Rebotes e restituição

Os dados registram inversões reais de direção, mas não contatos a 50 Hz nem vetores de velocidade angular. No caso 3, tag 6 muda o sinal de Z entre 6,0177 e 6,1160 s junto da borda superior, depois muda o sinal de X entre 6,2176 e 6,3184 s junto da borda esquerda. No caso 2, tag 4 apresenta inversões de Z entre 24,916–25,0157 s e 25,6203–25,7177 s.

Não é correto dividir a velocidade depois pela velocidade antes e chamar o resultado de restituição: cada intervalo pode conter drag, atrito, rotação e parte do trajeto antes/depois do contato. A direção também evolui nas amostras seguintes ao rebote, mostrando que uma reflexão especular simples não reproduz toda a resposta. O material serializado continua sendo evidência separada; estes JSONs não isolam um coeficiente de restituição único.

No caso 4, a bola tag 7 desaparece das posições e passa a potted entre 7,3122 e 7,4098 s. A última posição observada ainda é anterior à caçapa.

## Arquivos

`motion-analysis.py` reproduz os cálculos; `motion-calibration.json` contém hashes, intervalos classificados, resíduos, limites de associação e coordenadas por bola. Nenhuma alteração de produto foi feita.

# V4.0.5 / build 80 — Compact controls

Request: compact customer popup, direct navigation, discreet Play/Pause and
experimental 2/5/10 ms speed control. Baseline V4.0.4 / build 79, commit
86808c9e9d3f3ddbd7ad89a2e6e01a528d392b42.

- Maximum popup 264 × 340 points, 44-point header/tabs/footer; overflow scrolls.
- Auto, X-ray, extended planning and owned powers are one direct action strip;
  eight-step speed slider and card batch selector immediately follow.
- One 44-point floating Play/Pause target with a 32-point visible chip;
  transparent surroundings, no full-width background, existing explicit arming.
- Billiards Guide/Aim/Auto use the same compact strip. Active-game gating,
  fresh action context, accessible labels and capped type remain.
- LAN is one footer icon. Sharing details/stop appear only while sharing.
  Internal covered-card, zero-stock and test-report buttons/glue were removed
  from the customer menu; recorder and browser diagnostics remain.
- One shared native cadence table: 500,250,100,40,20,10,5,2 milliseconds.
  Native and LAN setters accept only levels1–8; default remains3 (100ms).
  Timer tolerance is bounded by10% of the requested interval, maximum10ms.
  Legacy Turbo/Super Fast setters explicitly exit experimental profiles.

Intervals are requested polling cadence, not action throughput or guaranteed
iOS scheduling. Changing preferences restarts only the timer once, does not
start Auto or release submitted evaluation/pending/ACK/effect latches.
Short polling may increase device load; the game still confirms each batch.
No planner, powers-eligibility, game-protocol or server changes.

Regression coverage: shared cadence/bounds fixture, native setters including
legacy transitions and no-op changes, closed LAN parser, actual browser
round trips, compact layout geometry, client/UI/localization contracts.
HTML preview mirrors the design in PT/EN with 44pt targets and capped type;
it does not execute UIKit. Apple compilation/Foundation checks require the
official macOS workflow; physical device performance remains unmeasured.

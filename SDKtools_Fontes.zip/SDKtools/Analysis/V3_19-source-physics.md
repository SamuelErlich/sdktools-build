# V3.19: física recuperada e contrato para previsão de parada

Análise somente de leitura em 2026-10-16. Nenhum arquivo de produto foi alterado. Este relatório trata do fonte Lua e assets do cache 1084, não conclui calibração dos quatro vídeos/capturas.

Raiz dos fontes `L/`:
`/workspace/scratch/93d3b09386b0/bilhar-followup-1084/bilhar_fontes_1084/fontes/assets/localresources/billiard/lua/`

## Conclusão prática

Já é possível calcular um **impulso inicial fundamentado no código** e ler os parâmetros físicos reais por bola. Isso permite substituir a velocidade normalizada da V3.18.1 por um modelo de parada finita, mas **drag + esfera igual-massa não reproduz automaticamente a física completa**. O pano, o solver, os torques e as correções Lua exigem comparação com trajetórias reais. Não rotular uma distância calculada apenas com drag como ponto final calibrado.

## 1. Potência e velocidade inicial na partida normal

`L/ui/panel/bigamepanel.lua:413–432`, `onPowerRelease`:

- Potência relevante é `frame.gameView.powerSld.value`, com limite `powerSld.max`.
- Não dispara se `value < max * Const.Billiard.CUE_POWER_DEADZONE` (default 0.08).
- Direção é `(sin(rad(cueAngle)), 0, cos(rad(cueAngle)))`.
- Chama `frame:setShotData(value,dir,max)` e `frame:shotBall(value,dir)`.

`L/core/game/biframelogic.lua:1098–1139,1154–1156`:

- `frame.powerValue` só é atualizado em `setShotData`: durante a mira pode conter a tacada anterior.
- `shotBall` zera velocidade linear e angular da branca antes do impulso.
- Impulso: `J = direction * 0.031 * p * sqrt(p / Const.Billiard.CUE_POWER_MAX)`.
- Velocidade adicionada pelo modo Impulse: `deltaV = J / rb.mass`; não multiplicar novamente por `fixedDeltaTime`.
- `frame.shotPower` guarda **vetor impulso**, não potência de slider nem velocidade.
- A massa serializada ≈0.45 daria módulo `0.0688889*p*sqrt(p/Pmax)` antes do solver; usar massa viva, não assumir a do prefab.

`L/ui/panel/bigamepanel.lua:1075–1092`: no break o limite do slider vem de `Random.Range(CUE_POWER_MAX_RANG_A, CUE_POWER_MAX_RANG_B)`; nas outras fases é `CUE_POWER_MAX`. **Denominador da fórmula é CUE_POWER_MAX, não necessariamente slider.max**.

`L/const/const.lua:424–432`: atributos do taco recalculam `CUE_POWER_MAX` e `HIT_BALL_ANGLE`. Ler a constante vigente ao disparar.

Após o disparo o slider anima até zero em 0.3 s (`bigamepanel.lua:435–446`) e o efeito é resetado (`biframelogic.lua:1138,1253–1255`). Para calibração, congelar os inputs imediatamente antes da transição mira→movimento; não tentar reconstruir potência/efeito do slider vários frames depois.

## 2. Torque e ponto de impacto

`L/components/ballbehavior.lua:500–507`, `fireBall`:

- `AddForceAtPosition(J,shotPos,Impulse)`; no modo normal `shotPos` é a posição central da branca (`biframelogic.lua:1116–1123`).
- Impulso angular lateral: `L1 = -up * (spin.x * HIT_BALL_ANGLE) * |J| * 0.1`.
- Impulso angular frontal/traseiro: `L2 = -cross(up,J) * (spin.y * HIT_BALL_ANGLE + 0.008) * 0.1`.
- Mesmo `spin=(0,0)` contém o termo 0.008. Não equivale a ausência garantida de rotação.
- Converter impulso angular em velocidade requer tensor de inércia mundial (`rb.inertiaTensor`, `inertiaTensorRotation`, `rotation`); não dividir por massa.

Leitura direta: `frame.trickShotAdd.x/y`, `Const.Billiard.HIT_BALL_ANGLE`. O método `GetTrickShotAdd` retorna o campo, mas a leitura direta evita chamar o jogo. Não chamar `SetTrickShotAdd`, `fireBall` ou `shotBall` para obter uma previsão.

## 3. Repouso, amortecimento e passo

`L/components/ballbehavior.lua:158–188`:

- Quando `ballInMovement` está true, `velocity.sqrMagnitude < minVelocity` zera velocidade.
- `minVelocity` é capturado no carregamento do módulo a partir de `Const.Billiard.BALL_MIN_VEL` (linha4), default0.008.
- O limiar linear correspondente é `sqrt(0.008) ≈ 0.0894427191` unidades/s, **não 0.008**.
- `angularVelocity.magnitude < minAngularVelocity` zera angular; default0.2.
- Se ativa e ambos abaixo, chama `Sleep` e desliga `ballInMovement`.
- `onUpdate` chama `onFixedUpdate` (159), mas é agendado em `Core.timer` (625). O agendamento `Core.fixedTimer` está comentado (626). Portanto a aplicação do corte não é comprovadamente sincronizada exatamente a cada passo físico de0.02.
- `ballInMovement` também é ligado se não está dormindo e **ambas** as velocidades são não-zero (178–180). Para telemetria, ler velocidades reais e `IsSleeping`, sem depender só desse flag.

`L/core/game/bigamesettinglogic.lua:108–136` configura passo0.02, solverIterations10, sleepThreshold0.000001, contactOffset0.0001, autoSyncTransforms true, improvedPatchFriction false, bounceThreshold0, timeScale1; restaura ao sair (138–153).

Prefab em `bilhar-v315-analysis/capture/prefabs/-5584106740932664150_Rigidbody.json`: massa≈0.45, drag0.5, angularDrag0.5, useGravity true, constraints4 (FreezePositionY), collisionDetection2. `ballbehavior.lua:623` aplica maxAngularVelocity500. Ler valores vivos para detectar alterações.

**Modelo de amortecimento candidato:** o integrador público PhysX consultado aplica multiplicador `max(0,1-damping*dt)` à velocidade sem restrições; para drag0.5/dt0.02 isso é0.99 por passo. É referência externa, **não prova do código nativo exato usado por este UnityFramework**. Não afirmar que damping exponencial contínuo ou `1/(1+d*dt)` são equivalentes exatos ao executável.

Um caminho sem colisões e sem atrito adicional pode ser limitado por passos até o corte, somando deslocamentos das velocidades amortecidas. Isso é somente um modelo base. Com material, restrições e rotação, a curva observada deve validar ou corrigir o modelo.

## 4. Materiais, atrito e restituição

Assets em `bilhar-v315-analysis/capture/physicmaterials/*_PhysicMaterial.json`:

| Material | dynamicFriction | staticFriction | bounciness | frictionCombine | bounceCombine |
|---|---:|---:|---:|---:|---:|
| BallMaterial / BreakBallMaterial | 0 | 0 | 1 |3|1|
| TableMaterial / BreakTableMaterial | 1 | 1 | 0 |3|1|
| BumpersMaterial |0.5|0|≈0.8|3|1|
| BallPotedMaterial |0|0|0|1|1|

O enum do metadata real v31 em `weplay-unity-base/extracted/Payload/weplay-us.app/Frameworks/UnityFramework.framework/Data/Managed/Metadata/global-metadata.dat` confirma: Average0, Minimum2, Multiply1, Maximum3. Os bytes comprimidos dos defaults desses quatro campos são0,4,2,6 respectivamente. Assim: frictionCombine3=Maximum e bounceCombine1=Multiply. Restituição nominal bola-bola1, bola-bumper0.8, bola-pano0.

**Ler `collider.sharedMaterial`, nunca usar `collider.material` num observador:** o getter material pode duplicar e atribuir material ao collider. Usar sharedMaterial só para ler os seis campos e identidade; não escrever nele.

`biframelogic.lua:989–1002` troca materiais de break/normal. No cache os pares possuem valores iguais; nomes distintos não provam comportamento distinto.

Não inserir automaticamente desaceleração `mu*g`: o movimento possui FreezePositionY, solver de contato, atrito e rotação. Coeficiente do material não é diretamente a desaceleração escalar efetiva da bola. Calibrar trechos sem colisão contra `rb.velocity`, posição e tempo.

## 5. Colisões e correções do próprio jogo

`L/components/auxiliarylinebehavior.lua:60–181,269–304` calcula a mira, grava `frame.aimBall/aimBallPos` e dados de rebate das bolas. A função **muda estado** e não pode ser chamada como consulta pura.

`BallBehavior:setFirstCollision` (`ballbehavior.lua:509–520`) muda a branca para layer2 quando há alvo; `onFixedUpdate:132–152` pode reposicioná-la em `aimBallPos` e volta ao layer0. É uma correção discreta do contato inicial, não presente num modelo genérico de esferas.

`onCollisionEnter:257–321`, especialmente287–298: quando objeto se chama `bumpers` e a bola possui `reboundPos/reboundDir`, o callback reposiciona a bola, redireciona velocidade preservando sua magnitude lida naquele momento, zera angular e limpa a correção. A magnitude já foi afetada pela resposta física: **não aplicar 0.8 duas vezes por material + callback**. Ler `ball.reboundPos/reboundDir` e as normais/objetos atingidos para identificar qual previsão tem essa regra.

As bolas usam o solver Unity para colisões, não uma função Lua que forneça a posição final pronta. A decomposição normal/tangente da mira original é geométrica. Um solver igual-massa com restituição nominal pode ser um modelo inicial, condicionado à confirmação de massas iguais, mas não cobre impulso tangencial, rotação, contatos simultâneos, depenetração e correções.

Ao encaçapar, `ballPot` (487–492) marca poted/inativa, libera constraints e muda material; `OnBallPot` (461–478) limita velocidade horizontal, aplica Y=-2 e abaixa posição. A bola potted tem resultado “encaçapada”; não apresentar o ponto da canaleta como posição final na mesa.

## 6. Tutorial é outra física

`L/core/game/bitutoriallogic.lua:142–158`: força shotPower=100 independente do slider, spin=(0,0.05), impulso `0.06*100=6`, ponto de aplicação deslocado abaixo do centro. `ballbehaviortuto.lua:283–286` aplica só AddForceAtPosition; não usa os dois AddTorque normais. Em135–152 as zeragens explícitas e Sleep estão comentados.

Não aplicar fórmula nem calibração da partida normal em `BilliardTutorial`. Rotular separadamente ou manter previsão geométrica até validar esse modelo.

## 7. Campos somente de leitura recomendados

| Referência já disponível | Campos/métodos de observação | Uso |
|---|---|---|
| `frame.gameView.powerSld` | value,max,min,touchable | Potência atual/deadzone, não frame.powerValue stale |
| `frame` | curDir,trickShotAdd,shotPower,shotPos,powerValue,powerMax,aimBall,aimBallPos,ballsInMovement,isServer,offlineMode | Inputs congelados, confirmação do lançamento e correções |
| `frame.frameStateLogic` | frameState,turnData | Separar break/normal e identidade da rodada |
| `ball` de `frame.balls` | ballTag,ballNum,ballActive,poted,ballInMovement,reboundPos,reboundDir,initShotPos | Identidade, ciclo de vida, correções |
| `ball.rigidbody` | position,velocity,angularVelocity,mass,drag,angularDrag,inertiaTensor,inertiaTensorRotation,rotation,worldCenterOfMass,maxAngularVelocity,constraints,useGravity,isKinematic,IsSleeping() | Estado dinâmico/repouso |
| `ball.collider` | radius,sharedMaterial,enabled,isTrigger | Geometria/material vivo |
| `hit.collider` | sharedMaterial,gameObject.layer,gameObject.name,transform | Rebate e material da superfície realmente atingida |
| `CS.UnityEngine.Time` | time,fixedTime,frameCount,fixedDeltaTime,timeScale | Sequência, dt e calibração |
| `CS.UnityEngine.Physics` | gravity,bounceThreshold,defaultContactOffset,defaultSolverIterations,sleepThreshold | Condições físicas vivas |
| `Const.Billiard` | CUE_POWER_MAX,HIT_BALL_ANGLE,CUE_POWER_DEADZONE,BALL_MIN_VEL,BALL_MIN_ANGVEL | Contrato de lançamento/corte |

Usar os getters já disponíveis via XLua, `pcall` e validação de tipo/finito; disponibilidade de cada binding novo precisa ser observada, não pressuposta. Leituras de referência devem ser feitas na mesma sessão/main thread sob as proteções existentes. Não chamar `Physics.Simulate`, setter de material, Sleep/AddForce, métodos de shot ou updateAuxiliary para medir.

## 8. Contrato de calibração útil

Capturar posições, **vetores** de velocidade/rotação e tempos antes do retorno `moving` do probe. Guardar inputs da tacada antes de reset UI/efeito. Separar:

1. trecho inicial sem contato: validar Δv=J/m e damping/atrito;
2. contato entre bolas: velocidades antes/depois por tag;
3. contato com bumper: normal, material, correção Lua e velocidades antes/depois;
4. repouso: último frame móvel e primeiro realmente parado;
5. potted e updates de rede: não ajustar modelo a teleporte/canaleta.

No adversário, `biframelogic.lua:489–518` aplica `inputServerCmd`, e `ballbehavior.lua:118–121` recebe pos/vel/ang quantizados por10000. Esses saltos são sincronização, não amortecimento. Não calibrar o mesmo trecho como movimento local contínuo.

Só mostrar “parada prevista” quando todas as bolas simuladas atingirem o critério num horizonte físico suficiente. Se encerrar por limite de eventos/tempo/orçamento, rotular “previsão parcial”, nunca o ponto de corte como repouso. A curva mais simples deve ser validada primeiro; precisão de spin e contatos simultâneos exige evidência adicional.

## Fontes públicas primárias conferidas

- Unity2022.3 AddForce: modo Impulse aplica deltaV=impulso/massa no próximo passo de simulação. https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Rigidbody.AddForce.html
- Unity Collider.material documenta a duplicação por getter quando compartilhado: https://docs.unity.cn/2022.1/Documentation/ScriptReference/Collider-material.html ; leitura por sharedMaterial: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Collider-sharedMaterial.html
- PhysX3.4, bodyCoreComputeUnconstrainedVelocity, referência para candidato de damping, não prova da versão nativa do jogo: https://github.com/NVIDIAGameWorks/PhysX-3.4/blob/master/PhysX_3.4/Source/LowLevelDynamics/src/DyBodyCoreIntegrator.h
- Unity2022.3 PhysicMaterialCombine: regras de combinação de materiais. https://docs.unity.cn/2022.3/Documentation/ScriptReference/PhysicMaterialCombine.html

## 9. Atualização: transição deslizamento→rolamento compatível com as capturas

O agente principal mediu nos novos dados a sequência de deslizamento `v_next = 0.99*(v - 9.81*0.02)` seguida de rolamento `v_next = 0.99*v`. Isso acrescenta evidência empírica à ressalva da seção4: o uso de atrito equivalente a g durante o deslizamento já tem suporte nos trechos observados, embora ainda não prove todos os ângulos, efeitos, colliders e tacadas.

Uma reconstrução fisicamente consistente do contato com o pano, que evita cortar artificialmente o atrito em um tempo escolhido, é:

- contato inferior relativo ao centro de massa: `r=(0,-R,0)` para esfera centralizada sobre pano horizontal;
- velocidade de escorregamento no contato: `u=(v + omega × r)_XZ`;
- direção tangencial `t=u/|u|` quando há escorregamento;
- inverso de massa efetiva `D = 1/m + (r × t) · I_world^-1(r × t)`;
- magnitude do impulso que elimina slip: `j_stop = |u| / D`;
- impulso de atrito `P = -t * min(mu*m*g*dt, j_stop)`;
- atualizar `v += P/m` e `omega += I_world^-1(r × P)`;
- em seguida aplicar amortecimento linear e angular pelos respectivos coeficientes, na ordem observada.

Para esfera homogênea isotrópica, `I=2/5*m*R²`, então `D=3.5/m`, `j_stop=2/7*m*|u|`. Com m0.45 e R0.165, I≈0.0049005. O efeito do impulso angular sobre slip impede ultrapassar a condição de rolamento. Com damping linear e angular iguais, o fator0.99 preserva `u≈0` depois da transição.

**Confirmado no asset:** esfera local center=(0,0,0), radius0.5, escala uniforme0.33, COM local0. `m_ImplicitCom=true` e `m_ImplicitTensor=true`. O tensor serializado `(1,1,1)` é configuração automática, não o tensor físico calculado. Não usar1 no simulador. Preferir o tensor vivo; aproximação da esfera só como hipótese explícita quando a identidade/escala foram confirmadas.

**Confirmado no fonte normal:** shotPos permanece no transform.position mesmo com spin diferente de zero. O cálculo `sectionDir` na linha1119 não é usado para deslocar o contato. Se COM vivo também for central, o AddForceAtPosition não acrescenta torque além dos dois AddTorque explícitos. Se worldCenterOfMass diferir do shotPos, acrescentar `(shotPos-worldCenterOfMass) × J`.

Sinal útil para teste: direção+Z, efeito escolhido zero → termo0.008 dá impulso angular em−X, logo pequeno backspin inicial; `omega × (0,-R,0)` aponta+Z e soma ao slip. O atrito produz omega+X até rolamento. Inverter esse sinal altera o momento da transição e o ponto final.

Esta é uma formulação proposta para o preditor, não uma função Lua recuperada do jogo. O retorno ao repouso continua exigindo os dois cortes reais: velocidade linear abaixo de sqrt(.008) e angular abaixo de0.2. A função original pode zerar a velocidade enquanto ainda há rotação; um modelo que para definitivamente só por speed baixo perde a transferência de rotação no passo seguinte.

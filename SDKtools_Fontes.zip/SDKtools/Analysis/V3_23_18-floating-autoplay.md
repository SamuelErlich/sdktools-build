# Controles flutuantes do Auto — 3.23.18 / build 68

## Comportamento

Ativar o Auto no Alpaca disponibiliza dois botões fora do menu, junto ao
ícone flutuante. Pausar interrompe o agendamento pelo método original do
gravador. Play retoma por uma solicitação explícita, com as verificações
de contexto e operações pendentes já usadas pelo menu.

Os dois botões permanecem visíveis durante a pausa; esconder ambos assim
que `autoplayEnabled` fosse falso impediria retomar. A ativação dos controles
é temporária, sem preferência persistida. Abrir o menu oculta o atalho;
fechá-lo revela os botões novamente. Sair do Alpaca, ir para segundo plano
ou mudar a cena nativa encerra essa ativação. Não há retomada automática.

Somente a ação aplicável fica habilitada: Pausar com Auto em execução;
Play com Auto pausado e condições de início disponíveis. Uma operação já
enviada pode terminar após a pausa. O atalho não limpa pendências, não
substitui confirmações e não modifica os coordenadores de jogo.

## Visual e posicionamento

O conjunto reutiliza fundo escuro, borda, cantos arredondados e destaque
laranja do menu. Símbolos nativos indicam pausa e reprodução; nomes e dicas
de acessibilidade têm versões em português e inglês.

Cada botão mede 44 × 44 pontos. O conjunto mede 106 × 56, com espaçamento
e margem interna de 6. Acompanha a bolha arrastável, procura espaço no lado
interno da tela e usa o lado oposto, abaixo ou acima se necessário. Mantém-se
na área segura, inclusive após rotação; não reduz os alvos de toque.
O texto compacto anterior fica oculto enquanto os controles ocupam seu lugar.

Somente os retângulos dos botões recebem toques nessa área. Espaços entre
os botões e o restante da tela continuam disponíveis ao jogo. Toques no
overlay já são excluídos pelo observador de interação existente.

## Base e verificação

Parte da correção local 3.23.17/build 67. A identidade do IPA original
continua sendo WePlay US 6.6.2/build 132 da Release `base-us-6.6.2`.
Fontes, manifesto, ZIP e workflow desta versão formam um único conjunto.

O helper de posicionamento é executado por testes C com tamanhos de tela,
posições de arraste, bordas, falta de espaço e valores inválidos. A suíte
de traduções confere as novas mensagens. Os resultados e hashes ficam em
`Validation/V3_23_18-validation.json`.

O ambiente local não executa UIKit. Compilação Foundation/iPhoneOS pelo
Actions e teste no aparelho permanecem pendentes. Conferir no iPhone:
ativar Auto, pausar, tocar Play, abrir/fechar menu, arrastar a bolha, girar
a tela, trocar de minijogo e voltar do segundo plano. Confirmar também que
Play recusado por uma ação pendente não a repete.

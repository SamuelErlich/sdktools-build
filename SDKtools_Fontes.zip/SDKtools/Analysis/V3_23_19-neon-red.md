# Bordas em vermelho neon — 3.23.19 / build 69

As bordas de recomendação do Raio X usam RGB (255, 24, 48), `#FF1830`,
com opacidade total. O contorno externo usa RGB (35, 3, 8), alpha 245.
A cor vale tanto para cartas expostas como para ícones de cartas cobertas.

As verificações existentes do renderer foram atualizadas para a nova cor.
Espessura, posicionamento, escolha das combinações e comandos do jogo não
recebem alterações nesta revisão. O pacote inclui as melhorias anteriores
dos botões flutuantes e do Raio X ao assistir aliados.

Base: fontes 3.23.18/build 68, commit local
`c2e27196c30e1154fcb8a4c5c16741f99bce9b20`.
A entrada do integrador continua sendo o IPA original da Release
`base-us-6.6.2`. Resultados locais em Validation/V3_23_19-validation.json.
Compilação Apple e conferência visual no iPhone permanecem pendentes.

# SDK Client 3.23.9 / build 59 — Alpaca Super Fast

Super Fast opt-in: até três cartas expostas do mesmo tipo por ciclo, via eventos
originais do jogo. Exige snapshot completo, ACK individual e efeito confirmado.
Falha 500, resposta incerta ou perda de contexto bloqueiam novas ações; não
fabrica pacotes, não libera cartas cobertas e não altera estoque do servidor.

Corrige leitura e Raio X das reservas elevadas pelo poder quando há geometria
verificada; células nulas de storage_blocks são aceitas conservadoramente.
Mission priority e fallback para o planejador normal são preservados.

Menu Alpaca → engrenagem → Super Fast (desativado por padrão). Habilitar Auto
separadamente. Normal, Turbo, planejamento e poderes continuam disponíveis.
Bilhar e Cartas mantêm os módulos anteriores sem mudança de algoritmo.

Leia Analysis/V3_23_9-super-fast.md e Validation/V3_23_9-validation.json.
Fontes e workflow são pareados por SHA-256; compilação Apple, assinatura e teste
físico são etapas separadas. Não há garantia de vitória ou de latência no aparelho.

## Histórico preservado — não descreve o estado atual


## Estado de desenvolvimento anterior ao pedido de build

# Alpaca — Super Fast + cartas devolvidas/guardadas (WIP local)

**2026-10-19 — somente fontes, sem build/publicação.** Continuação da etapa de snapshot verificável.
Base: `work/sdktools-next-snapshot/fontes/SDKtools`, derivada de 3.23.8/build 58.
A etapa anterior e os 494 hashes da base imutável foram reconferidos. Versão/build não alterados.
`Validation/V3_23_8-validation.json` dentro dos fontes é histórico, não valida este WIP.

## Menu e comportamento

Menu Alpaca → avançado → **Super Fast**, desligado por padrão. Ativar a preferência NÃO inicia Auto.
O modo usa consulta nativa com alvo de 20 ms, contra 40 ms no Turbo e 100 ms no Normal.
NSTimer tem avaliação serializada: o alvo de consulta não garante essa frequência no iPhone.
Pode coexistir com missão, planejamento ampliado, poderes próprios e X-ray.

- Primeiro procura trio já acessível, pelo tipo numérico original, com prioridade à missão quando possível.
- Usa cartas do tabuleiro e das reservas. Se a bandeja já tem uma/duas do mesmo tipo,
  envia somente as duas/uma necessárias. Dá preferência a reservas disponíveis dentro do tipo escolhido.
- Sem trio exposto, reaproveita o planner existente e sua execução normal; não força carta coberta.
- Até três eventos originais registrados `touchBlock` podem sair **na mesma avaliação JS**.
  São até três pedidos independentes do próprio jogo, NÃO uma transação atômica do servidor.
- A janela adicional de despacho é limitada a 4 ms, depois da aquisição validada (orçamento de leitura 18 ms).
  Cada alvo é conferido outra vez; se flag, alvo, frame, lock ou orçamento mudarem, para no prefixo já enviado.
- Não escreve flags, inventário, posições ou pacotes. Não chama diretamente transporte de gameplay.
  O evento registrado chama o próprio `Socket.TouchBlock`; o observador apenas encaminha e acompanha.
- Só permite outro lote após ACK correspondente + Promise original + efeito/censo consistente.
  Visualização otimista sozinha não confirma. Não reenvia automaticamente pedidos sem resposta.
- Timeout, 500, inconsistência de resposta ou perda de contexto interrompem o modo sem repetir o lote.
  Desligar/trocar modo, pausar ou resetar observações não apaga pedidos pendentes.
- Ajuda/HotTime que altera outras cartas pode resultar em `resynced`: libera o censo já aceito e consumido,
  mas NÃO atribui ao Auto o trio que não conseguiu provar exatamente.
- Transição de fase no mesmo container é reconciliada com ACKs, modal observado, trio terminal e novo censo.
  Vitória local final exige os ACKs e duas leituras estáveis do Store vinculado indicando self-Win e coleções vazias.
  O modo não aperta “jogar novamente” nem automatiza os aliados.

## Correções de Storage/Withdraw para todos os modos

Contratos recuperados usados: `StorageArea.removeBlock` mantém células `null` na matriz;
`StorageArea.calculateBlockPosition` usa colunas de 80 px e deslocamento vertical de 7 px por camada.
`GameLayer.withdrawBlock` pode devolver à pilha OU à reserva; `Block.touchBlock` usa estado 0 ou 2.

Falhas locais encontradas e corrigidas:

1. O novo snapshot rejeitava células `null` válidas nas reservas, bloqueando leitura/Auto após retirada de cartas.
   Agora aceita os buracos somente em `storage_blocks`; não ignora registros inválidos de board/hand.
2. O adapter aplicava às reservas a igualdade de máscara/dependências da pilha, que só conhece blockers de board.
   Disponibilidade de reserva continua vindo do Button/`canTouch` originais, sem inventar desbloqueio.
3. X-ray filtrava cartas cobertas com `zone === board`. Agora inclui reservas com `storage_info` e geometria conferidas.
   Ícones ficam ancorados na pilha verificada da reserva. Sem metadados suficientes, informa a omissão em vez de adivinhar.
4. O snapshot inclui posição lógica da reserva, máscara e `hintBlockedBy`; essas arestas são **visuais**,
   não autorização para o planner tocar uma carta inacessível. Reavalia quando o jogo libera a carta.
5. Conciliação de pendências e o observador coberto também reconhecem as células vazias válidas.
6. A prova geométrica pura é memorizada por conteúdo (IDs locais, coordenadas, camadas e arestas),
   evitando refazer o mesmo O(n²) em toda leitura. Censo, contexto, tipos/locks e concordância continuam revalidados.

Essas correções compartilham a leitura entre Normal, Turbo, planejamento ampliado, Super Fast e X-ray.
Nenhuma animação do jogo foi acelerada/cancelada. Só cartas realmente liberadas podem ser colhidas.

## Arquitetura / arquivos principais

- `Resources/alpaca_fast.js`: seleção rápida, lote limitado, observação de ACK/Promise e reconciliação.
- `Resources/autoplay_tool.js`: integração com planner/phase, eventos originais e latches exclusivos.
- `Resources/alpaca_snapshot.js`: matriz esparsa, anotação de reservas e prova geométrica reutilizável.
- `Resources/xray_overlay.js`: badges de reservas verificadas, sem alterar os nós do jogo.
- `STAutoplayBridge.inc` / `STWebProbe.*`: factory adicional e opção `superFastEnabled`.
- `STAutoplaySanitizer.inc`: resumo fechado `superFast`, sem IDs reais/pacotes/credenciais.
- `STAutoplayRecorder.inc` / `STRecorder.*`: preferência, timer e latch nativo prévio à avaliação.
  Callback perdido ou documento diferente não autoriza recriar a ação em outra tela.
  Recusa comprovada ANTES da avaliação não vira falsamente um envio incerto.
- `STOverlay.m` e catálogo bilíngue: novo switch e descrição.
- Contratos de recursos do build/integrador atualizados APENAS nos fontes. Não foram executados.

A leitura `runtime({command:'phase_snapshot'})` continua sem enviar ações.
O resumo nativo `superFast` expõe somente status/motivo, pending, contagem de lotes e até 3 enviados,
requests/responses/settled/accepted, efeito e total confirmado. IDs, URLs e payloads ficam privados.

## Validação realizada (não confundir com execução no aparelho)

- **950 testes JS aprovados**, zero falhas. Incluem 3 eventos no mesmo tick, ACKs fora de ordem,
  ACK ausente/falso, Promise pendente, 500, timeout, mudança de socket/rodada/mapa, pausa/troca de modo,
  prefixo interrompido, missão, poderes Storage/Withdraw, matriz com buracos, X-ray das reservas,
  ajuda/HotTime, fase seguinte e finalização com self-Win.
- **93 testes Python selecionados: 92 aprovados, 1 ignorado (Foundation/macOS)**.
- Testes Objective-C de sanitização e bridge foram estendidos, mas NÃO compilados/executados.
- Excluídos testes que chamam compiler/preprocessor ou empacotador. Nenhum framework/IPA/ZIP foi gerado.
- Módulos específicos de Bilhar e Cartas preservados; ponte/menu compartilhados receberam somente integração Alpaca.

### Ensaio offline do agendador

`validation/benchmark-superfast.cjs` usa geometria capturada + métodos/ACKs sintéticos,
rede e animação com latência zero. NÃO acessa servidor ou dispositivo.
No ensaio pequeno, os três pedidos ocorreram em ticks separados no Normal/Turbo,
mas no primeiro despacho do Super Fast saíram três no mesmo tick.
Há também cenário de 228 cartas com relógio CPU real e guardas de orçamento preservadas.
Os números completos estão em `validation/synthetic-scheduler.json`.
Não extrapolar milissegundos desse modelo para velocidade, vitórias ou compatibilidade no iPhone.
Cold start/GC podem exceder uma fatia cooperativa; o runtime bloqueia novas ações ao detectar orçamento esgotado.

## Ainda precisa de validação real, após autorização para compilar

1. Primeiro testar Super Fast numa fase simples; conferir se o servidor aceita os três pedidos originais.
2. Se houver recusa, não repetir nem forçar flags. Conferir `superFast` no relatório completo.
3. Testar Storage: subir cartas, retirar uma, verificar as restantes e os ícones após animação.
4. Testar Withdraw para board e reserva, nos modos usados no aparelho.
5. Conferir transição de fase e ajuda dos aliados, latência real, pausas e consumo de CPU.

É uma implementação experimental local; testes simulados não provam que três pedidos simultâneos serão aceitos
pelo servidor nem garantem instantaneidade, ausência de falhas ou 100% de vitória.

**Não compilar, empacotar, mudar versão, publicar ou acionar Actions sem nova instrução.**

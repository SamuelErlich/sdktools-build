# V4.0.4/build 79 — All eligible cards, including diamonds

The user explicitly revoked the previous instruction to avoid diamonds.
The goal is maximum feasible progress and completion. No win rate or
completion percentage is established by the supplied screenshot.

## Policy removal

Removed type:1 vetoes from planner inputs, cached-route replay, final original
events, exposed batches and cooperative warehouse candidates/revalidation.
The cooperative path no longer requires an optional diamond permission
callback. Diamonds use the same existing type-matching, capacity, dependency
and continuation rules as other ordinary cards. They receive no invented
guarantee, guessed charge threshold or blind priority over a better proved route.

The HotTime observer remains read-only telemetry; its permission API was
removed. Its closed native diagnostic reports observed charge or unavailable
charge, never card permission. Old diamond-protection UI copy and action
reasons were removed. Getter/ownership/finite-number validation is retained.

Native/JS phase, turn, input, special-card, modal, actual HotTime, socket,
request/ACK and pending-effect guards are unchanged. This does not synthesize
packets, buy powers, act for allies, or repeat requests without confirmation.
An available diamond trio is tried before opening a rescue power; powers
still require their existing original controls, stock and effect proof.

## Validation

Twelve new integration scenarios failed under the previous policy. Tests
cover diamond-only routes with a real/missing/failed/legacy observer, serial
and 2/3-card batches in normal/cooperative planning, acknowledged effects,
diamond warehouse pickup, and no rescue power when a diamond trio is playable.
Superseded exclusion tests were replaced; telemetry validation and the
existing context/ACK/no-retry cases remain exercised. Native closed-payload
tests were updated to the observation-only diagnostic.

Local and official CI results are recorded in the manifest/delivery reports.
Physical iPhone execution and victory/progress rates have not been measured.

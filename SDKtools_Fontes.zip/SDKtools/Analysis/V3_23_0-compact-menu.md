# Menu compacto — 3.23.0/build 50

Pedido: reduzir a obstrução do jogo, corrigir fontes fora dos limites, usar abas/ícones, tornar idioma e redes discretos e retirar as tarjas no estado minimizado.

- Uma seção visível; abas de 44 pt com ícone acima do nome curto. Bilhar/Billiards cabe nos dois idiomas.
- Header 48 pt, abas 44 pt, rodapé 44 pt. Painel até 288 × 380 pt (altura limitada também a 82% da área segura). O corpo rola quando se abre ajustes, profundidade ou um aviso longo.
- Fontes do popup de 9–12 pt, com crescimento limitado a mais 3 pt. Controles conservam alvos de toque de pelo menos 44 pt. Ícones de 16 pt são redimensionados uma vez e guardados em cache.
- Dropdown interno de idioma 148 × 96 pt; não apresenta outro controlador nem altera a verificação do jogo. A preferência persiste na infraestrutura existente.
- Ajustes Alpaca recolhidos por padrão. Cinco ações na barra de poderes; em largura excepcional menor que 244 pt, ela passa para disposição vertical.
- Símbolo flutuante de 44 pt, estado verde em uma linha sem fundo. Avisos/diagnósticos nunca alimentam o indicador minimizado. Tarja do Bilhar removida; comandos e histórico continuam iguais.
- Website/YouTube somente por ícones no rodapé; nenhum destino inventado. Menu sem captura, extração, exportação ou controles experimentais.

Preservação: corpo de `@implementation STOverlay` idêntico ao da main 3.22.1; mudanças em STBilliardsRuntime limitadas ao HUD. Recursos JavaScript/Lua e políticas de ação comparados por hash com essa base.

Catálogo: 338 entradas EN/PT, assinaturas de parâmetros preservadas. Cobertura inclui abas, textos condicionais e acessibilidade de botões por ícone. Testes C usam as mesmas funções de dimensões e indicadores chamadas pelo UIKit.

Conferência física pendente: área segura em retrato/paisagem; cada minijogo e comandos bloqueados nas outras abas; ajustes e idioma; arrastar o ícone; Auto/Raio X com texto verde sem tarja; pausa do Bilhar por toque e por reabertura; VoiceOver. Prévia e compilação Apple não comprovam uma partida real.

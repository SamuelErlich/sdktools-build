# V3.19.5/build41 — memória passiva de select_give_card

Base: V3.19.4/build40, fontes SHA-256 61ea6fa8deae74e3f377e33b2670264aeefa08245cfb1f7f1e11907bdc196605.

## Evidência e contrato

A investigação do export local verificou GameStore.sync/getSelectGiveCard, game.showSelectGive/onTakeCard/onKeepCard, HandArea.checkHandCards/isCardInHand e Socket.play. O jogo usa UID e card_id para associar cartas, não igualdade permanente de objetos: CMD_SYNC substitui os objetos do Store e os nós podem continuar apontando para o objeto anterior do push.

Na captura de teste, uma compra expôs type=1/color=2/num=9 em select_give_card para ID98, enquanto a entrada da mão tinha type=0/color=0/num=0. Depois o campo selecionado zerou, mas o ID continuou na mesma mão. Essa é uma revelação pontual, não uma tabela de todas as cartas.

## Implementação

- Memória SDK-privada apenas de faces efetivamente observadas em select_give_card e com ID único numa mão atualmente oculta.
- Escopo: documento, cena, Store, socket, start_time da rodada e UID exato do dono.
- Não usa índice como identidade, ID global, textura antiga ou informação de outra rodada.
- Só associa ao nó após validar o dono HandArea, Card real, conjunto completo de IDs e valores atuais da mão, unicidade e estabilidade antes/depois da geometria.
- Mantém a informação quando o campo zera e os objetos do Store são substituídos, desde que a carta continue na mesma mão.
- Descarta por saída da mão, descarte, troca de dono, conflito, fim, cena/documento/socket/rodada novos, pausa/leitura interrompida e prazo máximo de 120 s.
- Limites: 256 fatos e 256 IDs retirados por época; intervalo sem leitura maior que 1.500 ms invalida a memória. Lease visual de 600 ms preservado.
- Não modifica Card.cardInfo, não vira sprites do jogo e não envia sync, play ou qualquer outra ação.
- Anel externo branco indica marcador de origem select_give_card. O painel e o JSON incluem selectedKnown/Retained/Rejected/Shown; IDs e faces não atravessam essa ponte visual nativa.

## Alcance e limites

O modo de marcadores precisa estar ativo quando a informação passa pelo campo. Não recupera uma revelação que ocorreu antes da ativação ou da instalação desta versão.

Não revela automaticamente as mãos iniciais. Uma carta sem exposição continua desconhecida. Captura inicial e marcadores permanecem modos separados; o histórico de captura não é importado como estado atual.

O replay offline usa os campos realmente capturados, mas a UI e os aliases de UID são simulados; ele não comprova alinhamento de pixels, tempo real no iPhone ou os UIDs removidos do relatório por privacidade.

## Preservação

Alpaca e Bilhar não recebem mudanças de lógica ou física. Seus recursos JS/Lua são preservados. Os emissores de relatório recebem somente a nova versão. Limite Lua de 128 KiB e demais guardas permanecem.

## Teste no iPhone

1. Conferir V3.19.5 no menu e entrar numa rodada nova de Ah, minha carta.
2. Sem captura inicial ativa, habilitar os marcadores antes das compras dos jogadores.
3. Observar se cresce selectedRetained e se selectedShown aparece no JSON/painel quando uma carta exposta encontra vínculo válido com a mão.
4. Círculo colorido com anel branco significa face recebida via select_give_card; X cinza continua desconhecida.
5. Conferir remoção quando a carta sai da mão, mudança de rodada e pausa/background. Um marcador antigo nunca deve migrar para outra carta.
6. Se selectedRetained ficar zero, o campo pode não ter exposto uma face elegível nessa rodada. Isso não autoriza dedução por ID.

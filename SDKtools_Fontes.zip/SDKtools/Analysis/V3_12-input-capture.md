# Leitura de entrada para SDKtools V3.12

Arquivo analisado: `SDKtools-Capture-31D1FDE2-BF6A-41E9-B8AA-CDCD27211588.json`.
SHA-256: `0e0854eae26fb169f6bda4e59c39565b3639817c5a6434d8d8a2b4ece46036e0`.

O original tem 13.662.648 bytes, informa SDKtools **3.11.0**, esquema de captura 3 e duração **90,003643 segundos**. A parada foi pelo limite de duração. Esta análise não altera o original nem o SDK. Os arquivos derivados não incluem identidade de jogadores, credenciais, URLs ou respostas completas.

## Descoberta principal

Há **duas respostas de sincronização em que um campo lateral contém uma face conhecida para o mesmo ID numérico de uma carta ainda zerada na mão**. O caminho exportado como `zone: selected` corresponde a `select_give_card` no observador V3.11.

| Evento | Tempo do observador | Campo lateral | Mão na mesma resposta | Referências |
|---|---:|---|---|---|
| 279, `CMD_SYNC` | 65.431 ms | ID 69, `type:1`, `color:1`, `num:7` | Slot 1, ID 69, `type:0`, `color:0`, `num:0` | Objetos distintos |
| 303, `CMD_SYNC` | 71.567 ms | ID 65, `type:1`, `color:1`, `num:8` | Slot 1, ID 65, `type:0`, `color:0`, `num:0` | Objetos distintos |

São duas respostas independentes. Cada uma se repete em `socket_sync_result`, `store_input` e `store_after`, totalizando oito observações nos quatro pontos. Não são oito descobertas independentes.

Nos dois casos, o push anterior contém a carta comprada zerada, e o `Card.setup` seguinte também recebe a carta zerada. Na sincronização seguinte, aproximadamente um segundo depois, `select_give_card` volta a `id:0/type:0/color:0/num:0`. Os IDs 69 e 65 permanecem zerados na mão até o fim desta captura; não há revelação posterior deles em descarte ou evento registrado.

Essa é uma **correspondência candidata**, não uma identidade visual comprovada. É necessário confirmar o significado de `select_give_card`, a posse e o ciclo de vida do valor. A posição 1 é índice do array `gamers`, não identidade confirmada de adversário. Não usar esse achado para manter um cache de cores por ID ou pintar automaticamente uma carta.

O achado justifica que a V3.12 exporte separadamente `hiddenZeroAtIngress` e `knownSideFieldSameIDCandidate`, preservando momento, rodada observada, slot, origem e referências locais. O critério deve exigir presença simultânea na mesma resposta, ID único entre as mãos, valor válido e ausência de conflito; mesmo assim, a classificação continua candidata até comprovar o contrato do jogo.

## Cobertura real dos 90 segundos

Foram coletadas 179 amostras de fluxo, 376 eventos com sequência contínua e 67 respostas decodificadas: 59 `CMD_SYNC` e 8 `CMD_PLAY_CARD`. Os contadores finais de perdas de decodificador, eventos descartados, erros e omissões nativas são zero. Não houve evento de fluxo truncado.

A primeira coleta nativa foi solicitada aos 510 ms e a última aos 89.505 ms. A fila estava vazia na última drenagem. O formato avisa que eventos surgidos entre a última drenagem e a parada podem ser perdidos.

O primeiro evento é um `store_snapshot`, já com 25 cartas nas mãos e seis no descarte. Portanto, **o registro não cobre a abertura do documento, a primeira conexão ou a primeira sincronização da partida**. O contador `decoderMissed:0` descreve somente o período em que o observador já estava instalado.

Há uma única rodada observada pelo token de início; isso não é identificação de rodada pelo servidor. O estado numérico observado varia entre 3 e 4. Não atribuímos nomes a esses números sem o enum correspondente. Nenhum evento possui `afterGameOver:true` e nenhum push 12 foi registrado.

## Cores por origem

Os números abaixo são observações repetidas, não quantidades de cartas únicas.

| Origem | Eventos | Conhecidas | Desconhecidas |
|---|---:|---:|---:|
| Snapshot inicial | 1 | 12 | 20 |
| Push recebido | 59 | 25 | 11 |
| Resposta decodificada | 67 | 1.328 | 854 |
| Resultado de sync | 59 | 1.328 | 854 |
| Entrada do Store | 59 | 1.328 | 854 |
| Saída do Store | 59 | 1.328 | 854 |
| Entrada de `Card.setup` | 36 | 25 | 11 |
| Saída de `Card.setup` | 36 | 25 | 11 |

Dentro das respostas decodificadas, a zona `hand` contém **807 observações com `type/color/num` todos zero, referentes a 26 IDs distintos**, e 229 observações conhecidas referentes a oito IDs. As cartas conhecidas de mão estão somente no slot 2. Os slots 0, 1 e 3 têm, respectivamente, 329, 281 e 197 observações zeradas.

As 59 comparações `store_input` → `store_after` têm arrays exportados idênticos, incluindo os campos numéricos e aliases de objeto. As 36 comparações `card_setup_input` → `card_setup_after` também. Cada uma das 59 respostas `CMD_SYNC` foi seguida por um resultado de sync com o mesmo array exportado.

Assim, **a captura não mostra esses campos sendo apagados entre entrada e saída do Store ou do `Card.setup`**. A maioria das cartas ocultas já chega zerada ao ponto decodificado observado. A informação lateral em `select_give_card` deve ser investigada independentemente desse fato.

## Campos adicionais

`look_over_cards` não aparece como array em nenhum evento. Nas respostas e pushes está ausente; no snapshot/Store após atualização aparece com presença `invalid`, sem conteúdo copiado. `invalid` indica um valor fora dos tipos exportados pelo observador, não uma falha de decodificação comprovada.

`punish.cards`, exportado pelo descritor `punish_cards`, aparece como array em três pushes. São seis cartas, todas zeradas, duas por ocorrência. Os slots associados são 0, 3 e 1. Em outros 19 pushes de punição esse campo é `null`. `punish_list` está ausente.

Não há arrays `rank_infos`, `game_over_info.rank_infos`, nem cartas nas zonas de resultado. Não é possível concluir como a revelação final se comporta a partir desta captura.

## Limites da associação visual

As 179 amostras de `cardInvestigation` estão truncadas: todas atingem `component_limit`; 177 também indicam `payload_limit` e duas indicam `time_budget`. Nenhuma declara identidade visual verificada. Os IDs `cp*` desse módulo são independentes dos IDs `fo*`/`fn*` do fluxo.

O histórico de hints contém as últimas 48 mudanças do processo, sem garantir que correspondam ao mesmo intervalo de 90 segundos. Nele, `rootBound` chega a 28, `rootKnown` a 7 e `rootUnknown` a 21; `rootShown` permanece zero. `unknownShown` significa um marcador de desconhecido, não uma cor oculta descoberta. O hint está desativado no momento da exportação.

## O que a próxima captura precisa responder

1. A preparação ocorreu antes da cena e antes de `Socket.establish`, ou entrou tardiamente? Exportar isso como evidência explícita.
2. Quais etapas de registro, entrada e primeiro sync ficaram efetivamente cobertas? Zero erros não substitui cobertura de início.
3. `select_give_card` corresponde de fato à carta oculta com o mesmo ID e em qual intervalo isso é válido?
4. A mudança de objeto, jogador, rodada ou nó invalida essa correspondência imediatamente?
5. Os setters visuais e a conclusão assíncrona da textura ainda estão ligados ao mesmo objeto da carta?
6. As mensagens finais e a última fila foram drenadas antes da exportação?

O conjunto atual sustenta uma investigação mais precisa de um campo transitório já presente. Ele ainda não sustenta afirmar que todas as cores estão disponíveis, nem que há uma rotina local apagando as cores antes do Store.

Os cálculos completos desta leitura estão em `V3_12-input-capture.json`. Para capturas novas com o bloco `cardEarly`, use `scripts/analyze_card_early.py --input captura.json --output resumo.json`.

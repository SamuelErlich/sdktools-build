from pathlib import Path
import collections,json,hashlib,re,sys
import UnityPy
ROOT=Path('/workspace/scratch/93d3b09386b0')
P=ROOT/'weplay-unity-base/extracted/Payload/weplay-us.app/Frameworks/UnityFramework.framework/Data'
OUT=ROOT/'weplay-unity-analysis/resources'; (OUT/'text-assets').mkdir(exist_ok=True)
E=UnityPy.load(str(P/'data.unity3d')); rows=[]; texts=[]; hits=[]; errors=[]; scenes=[]
pat=re.compile(r'billiard|snooker|eight.?ball|8.?ball|cue|pool|ball|table|台球|桌球|bilhar|sinuca|lua|bootstrap|gameconfig|resversion',re.I)
for o in E.objects:
 row={'file':o.assets_file.name,'pathId':o.path_id,'type':o.type.name,'bytes':o.byte_size}
 if o.type.name in {'TextAsset','MonoScript','GameObject','BuildSettings','MonoBehaviour','ResourceManager'}:
  try:
   d=o.read(check_read=False)
   for attr in ['m_Name','m_ClassName','m_Namespace','m_AssemblyName']:
    if hasattr(d,attr): row[attr]=getattr(d,attr)
   if o.type.name=='MonoBehaviour':
    try:
     s=d.m_Script.read(); row['scriptClass']=s.m_ClassName; row['scriptAssembly']=s.m_AssemblyName
    except Exception as x:row['scriptError']=str(x)[:160]
   if o.type.name=='BuildSettings':
    scenes=list(d.scenes); row['scenes']=scenes
   if o.type.name=='TextAsset':
    raw=d.m_Script.encode('utf-8','surrogateescape') if isinstance(d.m_Script,str) else d.m_Script
    fn=re.sub(r'[^A-Za-z0-9_.-]','_',str(o.assets_file.name))+'_'+str(o.path_id)+'_'+re.sub(r'[^A-Za-z0-9_.-]','_',d.m_Name)
    (OUT/'text-assets'/fn).write_bytes(raw);row.update(sha256=hashlib.sha256(raw).hexdigest(),textBytes=len(raw),localFile=fn,headerHex=raw[:16].hex())
    texts.append(dict(row));
    for m in re.finditer(rb'[\x20-\x7e]{5,}',raw):
     s=m.group().decode()
     if pat.search(s):hits.append({'file':str(o.assets_file.name),'pathId':o.path_id,'name':d.m_Name,'offset':m.start(),'text':s[:4000]})
  except Exception as ex:errors.append({'file':o.assets_file.name,'pathId':o.path_id,'type':o.type.name,'error':str(ex)})
 rows.append(row)
for fn,obj in E.files.items():
 for name,f in obj.files.items():
  if hasattr(f,'reader'):raw=f.reader.bytes
  elif hasattr(f,'bytes'):raw=f.bytes
  else:continue
  for m in re.finditer(rb'[\x20-\x7e]{6,}',raw):
   s=m.group().decode()
   if re.search('billiard|snooker|eight.?ball|8.?ball|cueball|sinuca|bilhar|poolgame',s,re.I):hits.append({'file':name,'offset':m.start(),'text':s[:4000]})
report={'sourceSha256':hashlib.sha256((P/'data.unity3d').read_bytes()).hexdigest(),'unityVersion':'2022.3.62f1','parser':'UnityPy '+UnityPy.__version__,'objectCount':len(rows),'types':dict(collections.Counter(r['type'] for r in rows)),'scenes':scenes,'textAssets':texts,'nameMatches':[r for r in rows if pat.search(json.dumps(r,ensure_ascii=False))],'contentMatches':hits,'errors':errors}
(OUT/'object-inventory.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(OUT/'resources-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:report[k] for k in ['sourceSha256','unityVersion','objectCount','types','scenes']},ensure_ascii=False,indent=2))
print('errors',len(errors),'matches',len(hits),'texts',[(r.get('m_Name'),r['textBytes'],r['headerHex'])for r in texts])

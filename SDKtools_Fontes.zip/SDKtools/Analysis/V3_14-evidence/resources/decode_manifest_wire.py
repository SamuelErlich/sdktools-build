from pathlib import Path
import json,hashlib
P=Path(__file__).parent
b=(P/'text-assets/resources.assets_136_billiard_asset_records_ios.svga').read_bytes()
def varint(b,pos):
 v=0;s=0
 while True:
  if pos>=len(b) or s>=70:raise ValueError('invalid varint')
  x=b[pos];pos+=1;v|=(x&127)<<s
  if not x&128:return v,pos
  s+=7
def parse(b,base=0,depth=0):
 pos=0;rows=[]
 while pos<len(b):
  start=pos;k,pos=varint(b,pos);f,w=k>>3,k&7
  if not f:raise ValueError('fieldzero')
  r={'field':f,'wire':w,'offset':base+start}
  if w==0:r['value'],pos=varint(b,pos)
  elif w in (1,5):
   n=8 if w==1 else 4
   if pos+n>len(b):raise ValueError('shortfixed')
   r['hex']=b[pos:pos+n].hex();pos+=n
  elif w==2:
   n,pos=varint(b,pos)
   if pos+n>len(b):raise ValueError('shortlen')
   x=b[pos:pos+n];r['bytes']=n
   try:
    t=x.decode('utf8')
    if any(ord(c)<32 and c not in '\n\r\t' for c in t):raise ValueError()
    r['text']=t
   except (UnicodeError,ValueError):
    try:
     if depth>10:raise ValueError()
     r['message']=parse(x,base+pos,depth+1)
    except ValueError:r['hex']=x.hex()
   pos+=n
  else:raise ValueError('wireunknown')
  rows.append(r)
 return rows
D={'source':'resources.assets/TextAsset#136/billiard_asset_records_ios.svga','sourceBytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'fields':parse(b),'note':'Protobuf wire decoded; semantic field names require metadata schema corroboration.'}
(P/'billiard-manifest-wire.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)); print(json.dumps(D,ensure_ascii=False,indent=2))

from pathlib import Path
import sys,json,struct,re
sys.path[:0]=[str(Path(__file__).parent/'vendor'),str(Path(__file__).parent.parent/'metadata')]
from analyze_macho import MachO
from parse_metadata import parse
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM

base=Path('/workspace/scratch/93d3b09386b0')
mp=base/'weplay-unity-base/extracted/Payload/weplay-us.app/Frameworks/UnityFramework.framework/Data/Managed/Metadata/global-metadata.dat'
r,types,full=parse(mp);raw=mp.read_bytes();span=r['metadata']['spans'];m=MachO(base/'weplay-unity-base/extracted/Payload/weplay-us.app/Frameworks/UnityFramework.framework/UnityFramework');cs=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
ptrs=struct.unpack_from('<60841Q',m.data,m.offset(0x756a190,60841*8));funcs=sorted(set(v for v in ptrs if v));names={};byidx={}
modules={x['name']:x for x in json.loads((Path(__file__).parent/'unity/codegen_modules.json').read_text())}
moduleptrs={k:struct.unpack_from('<%dQ'%v['methodCount'],m.data,m.offset(int(v['tableVA'],16),v['methodCount']*8)) for k,v in modules.items() if v['methodCount']}
for t in types:
 for meth in full(t)['methods']:
  idx=meth['index'];label=(t['namespace']+'.'if t['namespace']else'')+t['name']+'.'+meth['name'];byidx[idx]=dict(meth,qualifiedName=label)
  rid=int(meth['token'],16)&0xffffff;table=moduleptrs.get(t['assembly'],())
  if 0<rid<=len(table):names.setdefault(table[rid-1],[]).append(label)
def literal(idx):
 if not 0<=idx<span['stringLiteral']['bytes']//8:return None
 length,off=struct.unpack_from('<2I',raw,span['stringLiteral']['offset']+idx*8)
 return raw[span['stringLiteralData']['offset']+off:span['stringLiteralData']['offset']+off+length].decode('utf8','replace')
exports={x['va']:x['name']for x in m.exports if 'va'in x}
out=[]
for idx in map(int,sys.argv[2:]):
 va=ptrs[idx];end=next(v for v in funcs if v>va);regs={};ins=[];lits=[]
 for i in cs.disasm(m.data[m.offset(va):m.offset(end)],va):
  d={'va':hex(i.address),'op':i.mnemonic,'args':i.op_str};a=i.op_str.split(', ')
  if i.mnemonic=='adrp' and len(a)==2:regs[a[0]]=int(a[1][1:],0)
  elif i.mnemonic=='add' and len(a)==3 and a[2].startswith('#') and a[1]in regs:regs[a[0]]=regs[a[1]]+int(a[2][1:],0)
  elif i.mnemonic=='ldr':
   match=re.fullmatch(r'(x\d+), \[(x\d+)(?:, #(0x[0-9a-f]+|\d+))?\]',i.op_str)
   if match and match[2]in regs:
    addr=regs[match[2]]+int(match[3]or'0',0)
    try:
     enc=m.qword(addr)
     if enc&1 and enc>>29==5:
      lit=literal((enc>>1)&0xfffffff);d['stringLiteral']=lit;d['metadataSlotVA']=hex(addr);lits.append(lit)
    except ValueError:pass
   if a:regs.pop(a[0],None)
  elif i.mnemonic in ['b','bl'] and i.op_str.startswith('#'):
   target=int(i.op_str[1:],0);d['targetNames']=names.get(target,[])
   if target in exports:d['targetExport']=exports[target]
   for k in list(regs):
    if int(k[1:])<=18:regs.pop(k,None)
  elif a and re.match(r'^[xw]\d+$',a[0])and i.mnemonic not in ['str','stp','cmp','tst','cbz','cbnz','tbz','tbnz']:
   regs.pop('x'+a[0][1:],None)
  ins.append(d)
 obj={'method':byidx[idx],'va':hex(va),'endVA':hex(end),'stringLiterals':lits,'instructions':ins};out.append(obj)
 print(idx,obj['method']['qualifiedName'],hex(va),'literals=',lits,'calls=',sorted(set(n for x in ins for n in x.get('targetNames',[]))))
Path(sys.argv[1]).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')

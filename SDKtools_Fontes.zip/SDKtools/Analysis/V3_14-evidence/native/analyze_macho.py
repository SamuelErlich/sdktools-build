#!/usr/bin/env python3
"""Read-only, bounds-checked thin Mach-O indexer for the supplied target."""
from pathlib import Path
import argparse, hashlib, json, re, struct, uuid

class MachO:
    def __init__(self,path):
        self.path=Path(path);self.data=self.path.read_bytes();self.sections=[];self.segments=[];self.commands=[];self.symbols=[];self.exports=[]
        self.header=struct.unpack_from('<8I',self.data)
        assert self.header[0]==0xfeedfacf and self.header[1]==0x100000c
        assert 0<self.header[4]<4096 and 32+self.header[5]<=len(self.data)
        p=32
        for _ in range(self.header[4]):
            cmd,size=struct.unpack_from('<II',self.data,p)
            assert size>=8 and size%8==0 and p+size<=32+self.header[5]
            c={'cmd':cmd,'offset':p,'size':size};self.commands.append(c)
            if cmd==0x19:
                name=self.cstr(p+8,16);va,vs,off,fs,mp,ip,nsec,flags=struct.unpack_from('<4Q4I',self.data,p+24)
                assert size==72+nsec*80 and off+fs<=len(self.data)
                seg=dict(name=name,va=va,vsize=vs,offset=off,size=fs,maxprot=mp,initprot=ip);self.segments.append(seg)
                for i in range(nsec):
                    q=p+72+i*80;sn=self.cstr(q,16);sg=self.cstr(q+16,16);a,s,o,al,ro,nr,fl,r1,r2,r3=struct.unpack_from('<2Q8I',self.data,q+32)
                    self.sections.append(dict(name=sn,segment=sg,va=a,size=s,offset=o,flags=fl,reserved1=r1,reserved2=r2))
            elif cmd==0x1b:c['uuid']=str(uuid.UUID(bytes=self.data[p+8:p+24]))
            elif cmd in (0xc,0xd,0x80000018,0x8000001f,0x80000023):c['name']=self.cstr(p+struct.unpack_from('<I',self.data,p+8)[0],size)
            elif cmd in (0x21,0x2c):c.update(zip(('cryptoff','cryptsize','cryptid'),struct.unpack_from('<3I',self.data,p+8)))
            elif cmd==0x32:c.update(zip(('platform','minos','sdk','ntools'),struct.unpack_from('<4I',self.data,p+8)))
            elif cmd==0x25:c.update(zip(('minos','sdk'),struct.unpack_from('<2I',self.data,p+8)))
            p+=size
        assert p==32+self.header[5]
        self.base=min(s['va'] for s in self.segments if s['size'])
        for c in self.commands:
            p=c['offset'];cmd=c['cmd']
            if cmd==2:
                so,n,st,sz=struct.unpack_from('<4I',self.data,p+8);assert so+n*16<=len(self.data) and st+sz<=len(self.data)
                for i in range(n):
                    si,t,se,d,v=struct.unpack_from('<IBBHQ',self.data,so+i*16)
                    assert si<sz
                    name=self.cstr(st+si,sz-si)
                    self.symbols.append(dict(name=name,va=v,type=t,section=se,desc=d))
            if cmd in (0x22,0x80000022):
                off,sz=struct.unpack_from('<2I',self.data,p+40)
                if sz:self.parse_exports(off,sz)
            if cmd==0x80000033:
                off,sz=struct.unpack_from('<2I',self.data,p+8)
                if sz:self.parse_exports(off,sz)
    def cstr(self,p,limit=100000):
        assert 0<=p<len(self.data);e=self.data.find(b'\0',p,min(len(self.data),p+limit))
        if e<0:e=min(len(self.data),p+limit)
        return self.data[p:e].decode('utf8','replace')
    def offset(self,va,size=1):
        for s in self.segments:
            if s['va']<=va and va+size<=s['va']+s['size']:return s['offset']+va-s['va']
        raise ValueError(f'Unmapped VA {va:x}')
    def qword(self,va):return struct.unpack_from('<Q',self.data,self.offset(va,8))[0]
    def parse_exports(self,off,size):
        assert off+size<=len(self.data);b=self.data[off:off+size]
        def uleb(p):
            v=0
            for i in range(10):
                assert p<len(b);x=b[p];p+=1;v|=(x&127)<<(7*i)
                if not x&128:return v,p
            raise ValueError('Oversized ULEB')
        stack=[(0,'',())]
        while stack:
            p,name,anc=stack.pop();assert p not in anc and len(anc)<1024
            start=p;term,p=uleb(p);end=p+term;assert end<=len(b)
            if term:
                flags,q=uleb(p);item={'name':name,'flags':flags}
                if flags&8:
                    ordinal,q=uleb(q);item.update(reexportOrdinal=ordinal)
                else:
                    addr,q=uleb(q);item['va']=self.base+addr
                    if flags&16:resolver,q=uleb(q);item['resolverVA']=self.base+resolver
                self.exports.append(item)
            p=end;assert p<len(b);n=b[p];p+=1
            for _ in range(n):
                end=b.find(b'\0',p);assert end>=p
                label=b[p:end].decode('utf8','replace');child,p=uleb(end+1)
                stack.append((child,name+label,anc+(start,)))
    def report(self):
        return {'path':str(self.path),'bytes':len(self.data),'sha256':hashlib.sha256(self.data).hexdigest(),'header':self.header,'commands':self.commands,'segments':self.segments,'sections':self.sections,'symbolCount':len(self.symbols),'exportCount':len(self.exports)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('binary');ap.add_argument('out');a=ap.parse_args();m=MachO(a.binary);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    for name,value in [('identity',m.report()),('symbols',m.symbols),('exports',m.exports)]:
        (out/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
    needles=re.compile(r'(?i)(il2cpp|billiard|snooker|unitysend|unityget|unityset|unityload|weplay|billiards|cueball|cue_ball)')
    matched=[x for x in m.symbols if needles.search(x['name'])]
    (out/'symbol_candidates.json').write_text(json.dumps(matched,indent=2)+'\n')
    print(json.dumps(dict(bytes=len(m.data),sha256=hashlib.sha256(m.data).hexdigest(),uuid=[c['uuid'] for c in m.commands if 'uuid'in c],symbols=len(m.symbols),exports=len(m.exports),candidates=len(matched))))
if __name__=='__main__':main()

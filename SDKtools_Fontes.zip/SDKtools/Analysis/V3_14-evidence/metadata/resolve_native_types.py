#!/usr/bin/env python3
"""Resolve selected metadata signatures using this exact image's registered type table."""
import hashlib,json,pathlib,struct,sys
ROOT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT.parent/'native'))
from analyze_macho import MachO
from parse_metadata import parse
BASE=ROOT.parent.parent/'weplay-unity-base/extracted/Payload/weplay-us.app/Frameworks/UnityFramework.framework'
m=MachO(BASE/'UnityFramework')
_,types,_=parse(BASE/'Data/Managed/Metadata/global-metadata.dat')
TYPE_TABLE=0x6e38790
TYPE_COUNT=112734
TYPE_DEFS_WITH_INDEX={1,2,3,4,5,6,7,8,9,10,11,12,13,14,17,18,22,24,25,28}
PRIMITIVES={1:'System.Void',2:'System.Boolean',3:'System.Char',4:'System.SByte',5:'System.Byte',6:'System.Int16',7:'System.UInt16',8:'System.Int32',9:'System.UInt32',10:'System.Int64',11:'System.UInt64',12:'System.Single',13:'System.Double',14:'System.String',22:'System.TypedReference',24:'System.IntPtr',25:'System.UIntPtr',28:'System.Object'}
def readptr(ptr,depth=0):
 if depth>8:raise ValueError('Type nesting limit')
 data,bits=struct.unpack_from('<QI',m.data,m.offset(ptr,12))
 code=bits>>16&255
 out={'nativeTypeStructVA':hex(ptr),'data':hex(data),'bits':hex(bits),'typeCode':hex(code),'attrs':hex(bits&65535),'byref':bool(bits&0x40000000)}
 if code in TYPE_DEFS_WITH_INDEX:
  if not 0<=data<len(types):raise ValueError('Bad type definition index')
  t=types[data];out.update(typeDefinitionIndex=data,assembly=t['assembly'],name=(t['namespace']+'.' if t['namespace'] else '')+t['name'])
  if code in PRIMITIVES and out['name']!=PRIMITIVES[code]:raise ValueError('Primitive identity mismatch')
 elif code in (15,29):
  child=readptr(data,depth+1);out.update(elementType=child,name=(child.get('name') or '?')+('[]' if code==29 else '*'))
 else:out.update(name=None,unresolvedReason='Shape deliberately not resolved by this bounded parser')
 return out
def resolve(index):
 if not 0<=index<TYPE_COUNT:raise ValueError('Type index out of bounds')
 ptr=m.qword(TYPE_TABLE+8*index)
 return dict(typeTableIndex=index,**readptr(ptr))
def walk(obj):
 if isinstance(obj,list):return [walk(x) for x in obj]
 if not isinstance(obj,dict):return obj
 out={k:walk(v) for k,v in obj.items()}
 for key in ('typeTableIndex','returnTypeTableIndex','parentTypeTableIndex'):
  if key in obj and isinstance(obj[key],int) and obj[key]>=0:out[key+'Resolved']=resolve(obj[key])
 return out
def main():
 for filename in sys.argv[1:]:
  p=ROOT/filename;data=walk(json.loads(p.read_text()));out={'binaryIdentity':{'path':str(m.path),'sha256':hashlib.sha256(m.data).hexdigest()},'registeredTypeTable':{'count':TYPE_COUNT,'va':hex(TYPE_TABLE),'source':'../native/unity/metadataRegistration recovered by sibling native analysis'},'runtimeObserved':False,'declarations':data,'limitations':['Signatures describe compiled declarations and do not execute methods.','Method invocation ABI must still be respected.','Unsupported generic or multidimensional array forms remain unresolved.']}
  dest=p.with_name(p.stem+'-resolved.json');dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(dest)
if __name__=='__main__':main()

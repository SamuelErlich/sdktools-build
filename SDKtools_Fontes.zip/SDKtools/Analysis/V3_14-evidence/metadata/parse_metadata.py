#!/usr/bin/env python3
"""Bounded read-only IL2CPP v31 metadata inventory. No runtime address inference."""
import argparse, collections, hashlib, json, pathlib, re, struct

PAIRS = ['stringLiteral','stringLiteralData','string','events','properties','methods',
 'parameterDefaultValues','fieldDefaultValues','fieldAndParameterDefaultValueData',
 'fieldMarshaledSizes','parameters','fields','genericParameters','genericParameterConstraints',
 'genericContainers','nestedTypes','interfaces','vtableMethods','interfaceOffsets',
 'typeDefinitions','images','assemblies','fieldRefs','referencedAssemblies','attributeData',
 'attributeDataRange','unresolvedVirtualCallParameterTypes','unresolvedVirtualCallParameterRanges',
 'windowsRuntimeTypeNames','windowsRuntimeStrings','exportedTypeDefinitions']
STRONG = re.compile(r'billiard|snooker|eight.?ball|8.?ball|cue.?ball|sinuca|bilhar|台球|桌球',re.I)
BROAD = re.compile(r'ball|billiard|snooker|cue|pocket|cushion|trajectory|predict|table|pool|rail|physics',re.I)
BRIDGE = re.compile(r'LuaEnv|LuaManager|LuaMgr|NLRender|UnityMessage|GameManager|GameMgr|Native.*Bridge|Bridge.*Native|ResLoader|ResourceLoader|GameType|Unity.*Manager',re.I)

def parse(p):
 b=p.read_bytes()
 if not 256<=len(b)<=128*1024*1024: raise ValueError('Unsupported metadata size')
 magic,version=struct.unpack_from('<II',b)
 if magic!=0xFAB11BAF or version!=31: raise ValueError(f'Unsupported magic/version {magic:x}/{version}')
 spans={}
 for i,n in enumerate(PAIRS):
  off,sz=struct.unpack_from('<II',b,8+8*i)
  if off>len(b) or sz>len(b)-off: raise ValueError(f'Out-of-bounds table {n}')
  spans[n]={'offset':off,'bytes':sz}
 def arr(n,fmt):
  f=struct.Struct(fmt); s=spans[n]
  if s['bytes']%f.size: raise ValueError(f'Wrong record size {n}')
  return list(f.iter_unpack(b[s['offset']:s['offset']+s['bytes']]))
 ss=spans['string'];sb=b[ss['offset']:ss['offset']+ss['bytes']]
 cache={}
 def string(i):
  if i not in cache:
   if not 0<=i<len(sb): raise ValueError(f'Invalid name string index {i}')
   end=sb.find(b'\0',i)
   if end<0 or end-i>65536: raise ValueError('Unterminated or giant name')
   cache[i]=sb[i:end].decode('utf-8')
  return cache[i]
 types=arr('typeDefinitions','<16i8H2I');methods=arr('methods','<7i4H')
 fields=arr('fields','<3i');params=arr('parameters','<3i');images=arr('images','<10i')
 ntypes,nmethods,nfields,nparams=len(types),len(methods),len(fields),len(params)
 def rng(start,count,total,what):
  if count==0 and start==-1: return
  if start<0 or count<0 or start>total or count>total-start: raise ValueError(f'Bad {what} range {start}/{count}/{total}')
 owners=[None]*ntypes;imageout=[]
 for ii,row in enumerate(images):
  name=string(row[0]);start,count=row[2:4];rng(start,count,ntypes,'image types')
  imageout.append({'index':ii,'name':name,'typeStart':start,'typeCount':count,'token':f'0x{row[7]:08x}'})
  for ti in range(start,start+count):
   if owners[ti] is not None: raise ValueError('overlapping type image ownership')
   owners[ti]=name
 methodowners=[None]*nmethods;fieldowners=[None]*nfields;typeout=[]
 for ti,row in enumerate(types):
  name,ns=string(row[0]),string(row[1]);ms,mc=row[9],row[16];fs,fc=row[8],row[18]
  rng(ms,mc,nmethods,'type methods');rng(fs,fc,nfields,'type fields')
  typeout.append({'index':ti,'namespace':ns,'name':name,'assembly':owners[ti],'byvalTypeIndex':row[2],'parentTypeTableIndex':row[4],
   'fieldStart':fs,'fieldCount':fc,'methodStart':ms,'methodCount':mc,'token':f'0x{row[25]:08x}'})
  for mi in range(ms,ms+mc):
   if methodowners[mi] is not None: raise ValueError('overlap method owners')
   methodowners[mi]=ti
   if methods[mi][1]!=ti: raise ValueError('Method declaring type disagreement')
  for fi in range(fs,fs+fc):
   if fieldowners[fi] is not None: raise ValueError('overlap field owners')
   fieldowners[fi]=ti
 for i,row in enumerate(methods):
  string(row[0]);rng(row[4],row[10],nparams,'method params')
  if not 0<=row[1]<ntypes: raise ValueError('Bad method owner')
 for row in fields: string(row[0])
 for row in params: string(row[0])
 for row in arr('properties','<5i'): string(row[0])
 for row in arr('events','<6i'): string(row[0])
 byval={t['byvalTypeIndex']:t for t in typeout}
 def typehint(i):
  t=byval.get(i)
  return (t['namespace']+'.' if t['namespace'] else '')+t['name'] if t else None
 def method(i):
  row=methods[i]
  return {'index':i,'name':string(row[0]),'declaringTypeIndex':row[1],'token':f'0x{row[6]:08x}',
   'returnTypeTableIndex':row[2],'returnTypeHint':typehint(row[2]),'parameterCount':row[10],
   'parameters':[{'index':pi,'name':string(params[pi][0]),'token':f'0x{params[pi][1]:08x}',
    'typeTableIndex':params[pi][2],'typeHint':typehint(params[pi][2])} for pi in range(row[4],row[4]+row[10])],
   'flags':row[7],'isStatic':bool(row[7]&0x10)}
 def field(i):
  row=fields[i];return {'index':i,'name':string(row[0]),'token':f'0x{row[2]:08x}',
   'typeTableIndex':row[1],'typeHint':typehint(row[1])}
 def fulltype(t):
  return dict(t,fields=[field(i) for i in range(t['fieldStart'],t['fieldStart']+t['fieldCount'])],
   methods=[method(i) for i in range(t['methodStart'],t['methodStart']+t['methodCount'])])
 strongtypes=set();strongmembers=[];broadtypes=[];bridges=[];broadmembers=[]
 for t in typeout:
  fullname=t['namespace']+'.'+t['name']
  if STRONG.search(fullname): strongtypes.add(t['index'])
  if BROAD.search(fullname): broadtypes.append(t)
  if BRIDGE.search(fullname): bridges.append(t)
 for kind,rows,owneridx in [('method',methods,methodowners),('field',fields,fieldowners)]:
  for i,row in enumerate(rows):
   name=string(row[0]);ti=owneridx[i]
   if ti is None: raise ValueError('Unowned member')
   out={'kind':kind,'index':i,'name':name,'owner':typeout[ti]}
   if STRONG.search(name): strongmembers.append(out);strongtypes.add(ti)
   if BROAD.search(name): broadmembers.append(out)
 literalhits=[];lst=spans['stringLiteralData']
 for i,(length,off) in enumerate(arr('stringLiteral','<Ii')):
  if off<0 or off>lst['bytes'] or length>lst['bytes']-off: raise ValueError('Bad literal bounds')
  val=b[lst['offset']+off:lst['offset']+off+length].decode('utf-8',errors='replace')
  if STRONG.search(val): literalhits.append({'index':i,'dataOffset':lst['offset']+off,'byteLength':length,'value':val[:20000],'valueTruncated':len(val)>20000})
 counts={'types':ntypes,'methods':nmethods,'fields':nfields,'parameters':nparams,'images':len(images),'stringLiterals':spans['stringLiteral']['bytes']//8}
 result={'schema':'SDKtools.US.UnityMetadata.Static.v1','runtimeObserved':False,'source':{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},
  'metadata':{'magic':hex(magic),'version':version,'headerBytes':256,'spans':spans,'counts':counts,
   'recordBytes':{'typeDefinition':88,'methodDefinition':36,'fieldDefinition':12,'parameterDefinition':12,'imageDefinition':40},
   'validation':{'allTableRanges':True,'allTypeMethodFieldParamNames':True,'allTypeAndMethodOwnership':True,'allParameterRanges':True,'allLiteralRanges':True}},
  'images':imageout,'strongTypes':[fulltype(typeout[i]) for i in sorted(strongtypes)],'strongMemberHits':strongmembers,
  'broadTypeHits':broadtypes,'broadMemberHits':broadmembers,'bridgeTypeHits':bridges,'strongLiteralHits':literalhits,
  'limitations':['Metadata indexes/tokens are not native or process addresses.','byval type hints resolve only exact type-definition matches, not complete signature types.',
   'Names indicate declarations, not runtime instances or verified control/data flow.','No gameID, object positions or runtime field offsets are inferred.'],
  'schemaReference':'https://github.com/Perfare/Il2CppDumper/blob/master/Il2CppDumper/Il2Cpp/MetadataClass.cs'}
 return result,typeout,fulltype

def main():
 ap=argparse.ArgumentParser();ap.add_argument('metadata');ap.add_argument('--output',required=True);ap.add_argument('--types',nargs='*',default=[]);a=ap.parse_args()
 result,types,full=parse(pathlib.Path(a.metadata))
 if a.types:
  names=set(a.types);result['requestedTypes']=[full(t) for t in types if t['name'] in names]
 pathlib.Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'output':a.output,'counts':result['metadata']['counts'],'strongTypes':[t['name'] for t in result['strongTypes']],
  'strongLiterals':len(result['strongLiteralHits']),'broadTypes':len(result['broadTypeHits']),'broadMembers':len(result['broadMemberHits'])},ensure_ascii=False))
if __name__=='__main__':main()

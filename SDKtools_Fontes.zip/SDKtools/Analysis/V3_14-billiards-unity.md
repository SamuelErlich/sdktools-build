# Bilhar WePlay US — marco V3.14

Análise estática da base fornecida, confrontada com a captura V3.13. Data: 2026-10-16.

## Identidade do alvo

| Artefato | Tamanho | SHA-256 |
|---|---:|---|
| IPA US 6.6.2/132 | 408.919.954 | `b45bc7bba77461008459793bca85d85930668bf6b5af27e91a387889093a00d4` |
| `weplay-us` | 78.612.768 | `2a1d3c9832a5e7158e72404ce0d139165bb3e348707d5e427271b264da6c79cc` |
| `UnityFramework` | 130.798.400 | `3687cc2e600a2e9767517f0cc4787bdec7c74a68b20768ed701dfae58b02e97a` |
| `global-metadata.dat` | 29.894.292 | `be20fd45c444d641780cf476d40af10e97fcfc0bf5dd8a749d477ac985494a5f` |

Bundle `com.wejoy.weplay.us`, executável `weplay-us`, iOS mínimo 15. Unity ARM64 UUID `26e49e81-50e8-396b-a9f2-b3bf243a464b`, `cryptid=0`. Esse estado é declarado no Mach-O; nenhuma descriptografia foi realizada. Engine: Unity 2022.3.62f1.

## Captura e mudança de camada

A captura `161BDC37-9182-40A5-B10C-FAAF8ECAAA2D` tem SHA-256 `e832a393a3bc3f563b7ae89b1a62b798e9879696eecdd1a55e735f5d3e489bd9`. Mostra 141 snapshots com Unity em aproximadamente 107,37 segundos. Não contém amostras WebView, objetos Unity, posições de bolas ou parâmetros de física. Foram observados `UnityDefaultViewController`, `UnityView` e `CAMetalLayer`.

A identificação Cocos V3.13 depende de `WPCocosGameViewController` e WKWebView. A ausência desses componentes explica por que esse leitor não coletou o estado do bilhar. Isso não prova criptografia, exclusividade no servidor ou impossibilidade de leitura local.

## Bilhar confirmado nos recursos

`data.unity3d` foi descomprimido e inventariado com UnityPy: 9.859 objetos, incluindo 5.271 MonoScripts e 40 TextAssets. A cena `Assets/OtherResources/Loading/BilliardLoading/LoadingBilliard.unity` e o TextAsset `billiard_asset_records_ios.svga`, em `resources.assets`, pathId 136, são evidências diretas do bilhar.

O TextAsset é protobuf `Recordconfig.AssetBundleRecords`, conforme as constantes de campos dos metadados. SHA-256 dos 1.423 bytes: `dd5e85ab92eb8ce2b6b75464ac9d58e3939335a93163e3f1856d99cc2c69fdbf`.

| Campo | Valor | Limite da interpretação |
|---|---|---|
| `gameId` | 20 | Identidade de recursos; não confirma `gameType` nativo |
| `version` | 1047 | Revisão do catálogo; não é ID da partida nem versão de código do nome local |
| `buildTime` | 2025-09-08 21:12:14 | Data registrada no catálogo embutido |
| `packBranch` | `pub_newRender_us` | Rótulo registrado |
| `records` | 14; 29.741.077 bytes | Tamanhos declarados; pacotes ainda não examinados |

O inventário do IPA não contém os nomes desses bundles como entradas. Catálogo, cena de carregamento e código de atualização sustentam a próxima leitura no cache. Isso não demonstra ausência absoluta de conteúdo equivalente sob outra representação.

| Grupo selecionado | Bytes | Pergunta que pode ajudar a responder |
|---|---:|---|
| `cres` | 90.072 | Há código ou configuração? Conteúdo ainda desconhecido. |
| `scene` | 115.010 | Como se organizam mesa, câmera e objetos? |
| `prefabs` | 75.356 | Quais componentes descrevem bolas e mesa? |
| `physicmaterials` | 1.117 | Existem parâmetros de atrito/restituição? São usados? |
| `model` | 11.897 | Qual geometria e escala estão nos modelos? |

Total: 293.452 bytes nesta revisão. Os pacotes atuais podem ser diferentes.

## Caminho comprovado no ARM64

1. `Application.get_persistentDataPath` resolve uma icall que termina em `NSSearchPathForDirectoriesInDomains(9, 1, YES)` e seleciona o primeiro resultado: Documents no domínio do usuário.
2. `AssetBundleManager..ctor` concatena `/AssetBundles/` e guarda `prefixLocalPath`.
3. `LoadLocalRecond(gameId)` passa por `GetAssetBundleVersionKey`, `AssetBundleRecordsLoader..ctor` e `LoadFromFile`.
4. A chave concatena `pro_` ou `dev_`, `AssetBundleRecord_`, região opcional, gameId, versão de código `HWGameInfo.version` com pontos substituídos por sublinhados e `_v2` ou `_v3`. O manifesto fica diretamente em Documents, com extensão `.svga`.
5. O bundle usa o nome do registro sob `Documents/AssetBundles`. `GetRuntimeBundleFile` acrescenta `.lz4` à representação de runtime.
6. O caminho alternativo usa `Library/UnityCache/Shared/<bundleName>`. O carregador enumera subdiretórios imediatos e arquivos imediatos cujo nome contém `_data`; múltiplos candidatos impedem a escolha automática.

O manifesto baixado, portanto, não precisa se chamar `billiard_asset_records_ios.svga`. Não colocar 1047 no nome por suposição. As instruções, chamadas e literais estão em `V3_14-evidence/native/`.

`AssetBundle.RecompressAssetBundleAsync` gera a representação LZ4. O MD5 do catálogo pertence à origem; não comprova igualdade dos bytes recomprimidos. A exportação registra SHA-256 dos bytes realmente lidos e mantém os identificadores do catálogo separados.

## Escopo da V3.14

O botão usa Foundation/POSIX nos caminhos comprovados. Lê os catálogos locais de bilhar, valida `gameId=20` no protobuf e considera cinco famílias. Não invoca Unity, Lua, scripts dos bundles ou serviços de rede.

Limita tamanho e tempo, usa descritores sem seguir links e revalida arquivos lidos. Alterações detectadas são registradas; bytes afetados não devem ser apresentados como coleta estável. O resultado é evidência em disco: não estabelece snapshot atômico da partida nem qual catálogo está ativo.

## Runtime: confirmado e pendente

Foram recuperados 241 exports IL2CPP e 410 exports Lua/XLua. Metadados v31: 31.623 tipos, 245.912 métodos, 148.620 campos e 135 imagens. Os 60.841 ponteiros de métodos de Main.dll foram relacionados ao CodeGenModule. A busca por nomes e literais nos metadados não encontrou referências diretas ao bilhar; essa busca limitada não abrange os pacotes baixados.

`LuaManager.LoadGame` chega a `LuaEnv.Global.Core.LoadGame`. Existem loaders Lua e HybridCLR; ainda não está estabelecido qual executa a lógica do bilhar.

`HallManager` contém `curGameInfo`, `sceneType` e `gameType`. Alguns getters atualizam caches e têm despacho hotfix; não são observações puras. A V3.14 não os chama. Contratos de Camera, Transform, Scene, Array e demais APIs estão guardados para a próxima etapa; formas genéricas não resolvidas permanecem marcadas.

Continuam sem observação real: identidade da partida; IDs, centros e raios das bolas; mira; parâmetros da tacada; transformação mundo/tela; limites, caçapas e colisores; física de colisão e efeito/spin. Uma linha desenhada antes dessa confirmação seria uma aproximação sem validação.

## Continuação

Receber o JSON `SDKtools.BilliardsResources` com o bilhar já carregado. Validar hashes e limites antes de extrair bytes. Inventariar bundles sem executar scripts e seguir componentes/referências até o estado de bolas, câmera e tacada. Depois implementar o leitor e confrontar a previsão com trajetórias observadas.

Ferramentas usadas: parsers Python, Capstone e UnityPy, seguindo as skills iOS/REA. Não houve sessão REA conectada, execução do IPA, compilação Apple ou teste no aparelho nesta etapa. A validação V3.14 registra separadamente os testes realmente executados.

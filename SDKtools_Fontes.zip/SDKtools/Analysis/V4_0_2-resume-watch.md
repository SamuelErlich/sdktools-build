# V4.0.2/build 77 — Auto resume and ally X-ray

Video evidence: the floating Play control fails to stay armed in V4.0.1.
No diagnostic export accompanied the video, so the physical cause cannot be
uniquely established. Two related failures were reproduced in the existing
runtime fixtures before changing production code.

## Accepted batch observation timeout

All original TouchBlock Promises and matching trusted WebSocket replies
can settle successfully while the board is hidden by a modal, spectator
view, or delayed polling. After 15 seconds the old effect timeout promoted
the batch to permanent uncertainty, preventing native Play from restarting.

An effect timeout now produces `waiting_effect` only when dispatch is done
and every invoked row has exactly one call/send, its observed request,
matching reply with code 200, and a resolved original Promise. The pending
latch remains. Existing context/round/socket validation and stable effect
or terminal-Win proof reconcile the batch without repeating any event.
Polling this state is idempotent. Response timeouts, unknown replies,
unsettled Promises, server rejection and context replacement stay uncertain.

The native boundary accepts this closed status only with positive equal
submitted/request/response/accepted/settled counters, pending true, effect
false and the effect_timeout reason. No native pause or request guard was
removed. Requests or identifiers are not exported.

## Spectator mask geometry

The original Game.WatchMaskNode can match board, tray, reserve or popup
dimensions. Read-only spectator snapshots now exclude that exact reference
from geometry candidates, while preserving hierarchy traversal and the
existing Game/GameLayer/Store ownership and spectator checks. No mask is
hidden or changed. Other overlays/modals still block observation. Ally
X-ray remains read-only icons/counts; Auto only acts on the player's board.

## Validation and limits

Regression coverage includes all four mask geometries; accepted two/three
card batches observed late on own board, after a modal, and after spectating;
stable Win after deadline; context replacement; unknown/unsettled responses;
and native closed-counter validation. Local and official CI results are
recorded in the version manifest and external delivery report.

Physical iPhone installation/interaction was not tested here. These fixes
cover reproduced causes, not a guarantee for every unknown gameplay event.

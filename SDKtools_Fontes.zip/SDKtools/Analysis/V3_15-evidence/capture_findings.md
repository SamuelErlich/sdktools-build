# Bilhar V3.14: captura decodificada e contratos para V3.15

## Identidade e conteúdo real

Captura `SDKtools-BilliardsResources-AC462B8D-69E5-4AFB-8B7A-D88F64399A95.json`: 1.481.216 bytes; SHA-256 `3c63be39a801d7c43bc69d254cbcaae1192d8a1527bdd4cefc6b918d2465bb76`. `toolVersion=3.14.0`, `collectionMode=local_cached_catalogs`, `currentMatchIdentified=false`, `nativeGameType=null`.

O catálogo local aceito é `pro_AssetBundleRecord_B_20_3_0_1_v3.svga`, resourceGameId=20, revisão1084, 15 registros declarados/5 selecionados. É diferente do manifesto embutido revisão1047. SHA catálogo declarado `f4c26965ae70b9b498d6b22b401cfff78934632669c981ca510b30b59135c3a8`; os bytes do catálogo não vieram exportados para recomputar esse SHA.

As cinco variantes LZ4 vieram completas e tiveram base64 estrito, tamanho e SHA256 conferidos. Total1.094.254 bytes. Não foi executado código do app. UnityPy1.25.4 leu somente os assets.

| Categoria | Bytes | Conteúdo decisivo |
|---|---:|---|
| CRes |577578|259 TextAssets; fontes Lua legíveis + descriptors protobuf|
| Model |28249|2 meshes, inclusive bumpers/canvas|
| Physicmaterials |1925|6 materiais físicos|
| Prefabs |145927|Ball com Rigidbody/SphereCollider; TargetLine, HandMoveBall|
| Scene |340575|BilliardInGame, BilliardMain, LoadingBilliardAB, BilliardTutorial|

`inventory.json` contém identidades por SerializedFile+pathID, evitando confundir pathIDs repetidos entre cenas. Fontes exportados com caminhos originais de m_Container ficam em `lua/lua`; `lua-index.json` associa nome original/pathID/SHA256. São códigos estáticos, não prova de que o estado de partida está vivo.

## Estado e coordenadas confirmados pelo fonte

- `Const.Billiard.GameType=1003` e `Enum.Billiard.GameType=1003`. Isso é o identificador no módulo Lua, distinto de resourceGameId20. Não equivale por si só a comprovar gameType da ponte Objective-C.
- Plano de jogo XZ, centro da bola em Y=0. `Const.Billiard.BALL_RADIUS=0.165`.
- Ball prefab: SphereCollider radius0.5, escala0.330000013 nas três direções; raio resultante≈0.165. Rigidbody mass0.45, drag0.5, angularDrag0.5, gravity=true, constraints4; BallBehavior:ballNotPot aplica FreezePositionY.
- ballTag1=branca; tags2..8=bolas numeradas1..7; tag9=bola8; tags10..16=bolas9..15. `getBallNum()` retorna `ballTag-1` (BallBehavior109–115).
- `Core.logicMgr:get(Enum.Billiard.Logic.frame)` fornece BiFrameLogic. `frame.balls` guarda BiBallBehavior, com transform.position, rigidbody.velocity/angularVelocity, ballTag, ballActive, poted.
- `frame.gameDataLogic.gameInfoData.table_balls` é estado de dados; preferir corpos vivos ao desenhar. `BallBehavior:inputServerCmd` divide posições/velocidades/angulares da mensagem por10000. Não aplicar essa divisão novamente a transform.position/rigidbody.position.
- `frame:cueDirection()` retorna curDir. `updateCueDir(angle)` cria `(sin(rad(angle)),0,cos(rad(angle)))` (BiFrameLogic1032–1045).
- ballTag é identidade estável adequada para invalidar cache, não nome do GameObject (todos nascem do prefab Ball).

## Projeção

A cena BilliardInGame inclui MainCamera ortográfica, posição(.59,9.1,0), quaternion(.5,.5,-.5,.5), orthographicSize9.1. A direita da câmera aponta para -Z e o topo para +X. O campo de visão81° não rege a escala ortográfica.

`BiGameSettingLogic:worldPos2UIPos`(92–106) usa Camera.WorldToScreenPoint, inverte o Y por Screen.height e converte via GRoot. Uma overlay UIKit deve usar projeção viva e escalar pixels de Screen para bounds da janela; não usar ao mesmo tempo coordenadas FairyGUI/GRoot. Métodos adjustPadCamera/adjustPhoneCamera existem, mas suas chamadas estão comentadas no fonte capturado. Não assumir tamanho4.05 ou5.26.

## Mesa e caçapas estáticas

As matrizes hierárquicas foram compostas incluindo Table rotação/escala, table e collider. Não usar a posição local do collider como world.

- Topo do mesh canvas em Y≈-0.165, consistente com raio da bola.
- Bumpers mesh pathID1256734347948202143:893 vértices/893 triângulos. Collider `Table/table/bumpers`, GameObject transform com ancestrais. Mesh canvas pathID8912561475133496089:588 vértices/584 triângulos.
- `bumpers-worldmesh.json` e `canvas-worldmesh.json` contêm triângulos em mundo.
- `bumpers-crosssection-y0.json`:446 segmentos da interseção exata dos triângulos com planoY0, incluindo jaws arredondados. `bumper-crosssection-simplified.json` arredonda1e-5 e funde colineares (tolerânciaangular1e-4),425segmentos. A caixa exterior não substitui o contorno interior ou aberturas.
- Trechos internos longos em X≈-5.48285 e+5.48977; Z≈-2.68324 e+2.68881 (um dos trechos de cima tem leve inclinação). O centro da bola deve recuar pelo raio. Valores são da cena em cache, não foram validados no dispositivo.

| Caçapa | X | Y | Z | Raio do trigger em mundo |
|---|---:|---:|---:|---:|
|potDownLeft|5.5409699|-.1539919|-2.8494104|.1926|
|potUpLeft|5.5393653|-.1539927|2.8200926|.1926|
|potDownRight|-5.5506503|-.1539919|-2.8312205|.1926|
|potUpRight|-5.5506503|-.1539927|2.8312205|.1926|
|potUpCenter|.0090699|-.1539927|2.9359735|.1605|
|potDownCenter|.0008310|-.1539919|-2.9694645|.1605|

Esses nomes são os nomes do asset. Não remapear left/right pela tela sem a câmera. O trigger está abaixo do plano da bola. Um círculo2D com o raio cru é uma simplificação que exige validação; há gravidade e abertura real da malha.

## Física e previsão existente

AuxiliaryLineBehavior87 usa Physics.SphereCast da branca, raio.165, direção do taco, maxDistance20, layerMask1. Para bola atingida usa normal centroimpacto→centrobola e decomposição `v_alvo=n*dot(d,n)`, `v_branca=d-n*dot(d,n)`; para borda usa Vector3.Reflect(d,hit.normal). Calcula trechos posteriores por SphereCast e SphereCastAll; não é um integrador completo de tacada. `getAuxLineMaxLength`(183) busca collider com tagbumper. As constantes padrão limitam trechos secundários a.6 e rebatebranca a.7.

Materiais serializados: Ball/BreakBall restitution1 friction0; Bumpers restitution.8 dynamicFriction.5 static0; Table/BreakTable restitution0 friction1. O fonte de BiGameSettingLogic configura timestep.02, solverIterations10, contactOffset.0001,bounceThreshold0. Isso não basta para reproduzir PhysX exatamente.

`BallBehavior:fireBall`(500) aplica impulso e torques de spin; a previsão geométrica sem spin deve declarar essa limitação e não prometer ponto final.

**Cuidado de implementação:** `AuxiliaryLineBehavior:updateAuxiliary()` NÃO é observacional. Ela limpa/escreve reboundPos/reboundDir das bolas e frame.aimBallPos; `BallBehavior:onCollisionEnter`(286–299) usa isso para reposicionar a bola, corrigir velocity e zerar angularVelocity. Não chamar updateAuxiliary como função de leitura nem alterar Const.HAS_* para implementar overlay. Ler auxData existente ou consultar Physics de modo independente, sem escrever nos objetos. Também não chamar métodos que executam tacadas, selectors ou reqResult.

## Lacunas para o dispositivo

Esta captura não contém posições ao vivo, IDs de instância em partida, orientação/pixelRect atual, nem prova da ponte Lua→SDK. A V3.15 precisa obter esses campos no estado Lua vivo, preservar thread/main runtime e bloquear visual quando cena, coleção, timestamp, câmera ou direções não forem válidos. BilharTutorial deve ser distinto de partidaonline. O código legível diminui a incerteza do caminho de leitura; o teste nativo continua necessário.

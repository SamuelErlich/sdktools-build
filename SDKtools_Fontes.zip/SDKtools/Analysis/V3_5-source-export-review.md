# V3.5 — revisão do exportador JavaScript para o jogo 2007

Revisão independente, somente leitura, do fluxo herdado da V3.4 no início da alteração V3.5. Nenhum código comercial foi executado. Os JSONs de captura foram inspecionados sem copiar URLs, caminhos privados, contas ou sessões para este resumo.

## Evidência dos relatórios recebidos

| Arquivo | Amostras | `isFileURL` | `urlProtocolOnly` | Identidade confirmada |
|---|---:|---|---|---|
| `SDKtools-Capture-6325276E-71E9-4854-8DE3-29B4804F8DCC.json` | 260 | Todas `true` | Todas `file` | Getter nativo: `gameType=2007`; Cocos 2.4.5; título confirmado pelo usuário |
| `jogando.json` | 204 | Todas `true` | Todas `file` | Não possui identidade nativa própria no bloco `newGameCapture` |

Os dois relatórios informam `privacy.urls=false`. Não contêm host, caminho, raiz de armazenamento ou formato de pacote verificável. Isso sustenta tentar exportar **o documento local do próprio WKWebView confirmado**, mas não prova que o pacote esteja em `Documents`, `Caches`, `2007_game`, `dev_2007_game` ou outro nome.

`jogando.json` registra `sourceExport.attempted=true`, `lastErrorCode=21`, `nativePathStatus=not_requested`, `lastPathDiagnostic={}`. A exportação falhou antes do getter de caminhos e antes do exportador. As amostras locais não provam o estado exato no instante da falha, mas o erro é compatível com o bloqueio do gate restrito ao jogo 60. O outro relatório não tentou exportar.

## O que está restrito ao jogo 60

1. `STRecorder.exportCurrentGameSourcesWithCompletion:` usa `STFindReturnActionWebView`, que chama `STFindHostedGameWebView(@60, ...)`. O mesmo gate 60 é repetido ao entregar o arquivo. A mensagem do erro 21 pede Crazy Alpaca.
2. `STGameSourceNativePath.inc` chama `WPDownloadManager.sharedManager`, valida assinaturas Objective-C exatas e executa `gameResDownloadPath:60`. A chamada é explicitamente `60LL`; não há evidência que autorize assumir semântica equivalente para 2007 apenas porque o argumento é um inteiro.
3. `STGSResolveRoot` aceita sem getter somente `littleGame/60_game/game_res/web-mobile/index.html` ou `littleGame/dev_60_game/game_res/web-mobile/index.html`. Um nome alternativo só é aceito quando o caminho do getter previamente verificado coincide exatamente com a pasta `game_res` do documento.
4. `STGameSourceExporter` escreve `gameID=60`, `rootSelection` com nomes de proveniência do jogo 60 e mensagens específicas de Crazy Alpaca. O catálogo de palavras-chave também está direcionado a props/armazém; isso não limita quais arquivos `.js` são lidos, mas não constitui detecção semântica do jogo 2007.
5. Os comentários de contrato no header do exportador e em `STGameSourceIO.h` pressupõem que o chamador verificou o jogo 60. Abrir um overload genérico sem revisar esses contratos pode produzir um arquivo identificado incorretamente.

## O que pode ser reaproveitado para 2007

O `WKWebView.URL` é um documento observado diretamente no WebView pertencente ao controlador nativo verificado; não exige consultar objetos da página nem adivinhar um getter. O mecanismo existente já separa leitura em segundo plano, âncoras fornecidas pelo sistema, abertura relativa a descritores e exportação estática de texto UTF-8.

Um caminho mínimo e explícito para 2007 pode aceitar somente um conjunto limitado de formatos de pacote sob `NSCachesDirectory` ou `NSDocumentDirectory`, a partir dessa URL exata. Os nomes `2007_game`/`dev_2007_game` seriam **formatos permitidos, não formatos comprovados pelos relatórios**. Se o documento real usar outro formato, o resultado correto é diagnóstico estrutural redigido; não enumerar outras pastas nem chamar `gameResDownloadPath:2007` por analogia.

É preciso transportar o tipo nativo verificado para o exportador e registrar metadados corretos. `nativeResourceURL` deve continuar sendo específico da implementação comprovada do jogo 60; para o fluxo 2007 baseado no documento, deve permanecer ausente. A descoberta somente leitura já tem `STFindCaptureGame`, que preserva os diagnósticos independentes das ações de Crazy Alpaca.

## Checks mínimos para a mudança

- Verificar app US 6.6.2/132, controlador exato, ABI do getter `gameType`, tipo 2007, único WebView visível, janela/controlador sem transição ou modal e documento não carregando.
- Copiar a URL desse WebView no momento da solicitação. Aceitar `file:` com autoridade local, sem credenciais/porta; obter âncoras somente pelas APIs Foundation. Não usar URL enviada pelo JavaScript, por relatório ou pelo usuário como raiz de coleta.
- Validar a combinação tipo/pasta: 60 não aceita pasta 2007 e vice-versa; tipo desconhecido não habilita exportação. Rejeitar traversal, separadores codificados, raízes parecidas, `index.html` falso, autoridade remota e links. A normalização `/var` ↔ `/private/var` não pode resolver links dentro do pacote.
- Preservar `openat`/`O_NOFOLLOW`, arquivo regular com um link, mesmo dispositivo, limites de bytes/entradas/tempo e verificações de mutação já existentes. Não executar o JS coletado nem fazer acesso de rede.
- Antes de entregar: confirmar controlador, tipo, WebView, janela, URL e geração/contexto esperados. Descartar a saída recém-criada se a tela mudou. Manter bloqueios de captura/ação/exportação concorrentes.
- Diagnóstico deve registrar apenas shape fixo ou `<other>`, flags de armazenamento e classificação. Não serializar caminho absoluto, host, query, fragmento ou mensagem arbitrária de erro do sistema.
- Metadados devem distinguir `gameID=2007`, seleção pelo documento atual e fonte estática de disco. Não afirmar equivalência com código carregado em runtime, snapshot atômico de todo o bundle ou identidade de cartas ocultas.

Não há evidência nova de um getter de recursos para 2007. A disponibilidade local do documento está confirmada; a elegibilidade concreta do seu diretório permanece pendente da nova validação no dispositivo.

## Revisão do patch V3.5 do exportador

O patch congelado de `STGameSourceExporter.h/.m` e `STGameSourceIO.h` foi revisado independentemente. Ele acrescenta `observedGameType` explícito, preserva os wrappers antigos como jogo 60, aceita 2007 somente pelos dois formatos literais e rejeita qualquer `nativeResourceURL` para 2007. Pastas 60/2007 cruzadas são rejeitadas, inclusive quando um caminho nativo acompanha a solicitação. Os metadados agora incluem o tipo correto, versão 3.5.0, proveniência do documento e `hiddenCardIdentityProven=false`.

`bash scripts/test_game_source_export.sh` passou **120 checks, 0 falhas** nesta revisão. Não houve defeito concreto nos limites/cross-game/layout desse patch. A camada Foundation não foi executada neste ambiente; validação de compilação Apple e da integração assíncrona no `STRecorder` continua sendo etapa separada.

# V3.19.3 — correção do empacotamento

O log da execução 38961056454, job 117175919208, mostra que o build anterior passou pelos testes e compilação nativa, mas parou na validação dos recursos feita ao final de build_framework.sh. O erro está em framework_files, no integrador.

O leitor billiards_probe.lua da V3.19.2 tem 75.363 bytes. O empacotador limitava todos os recursos a 65.536 bytes. O leitor nativo já aceita até 131.072 bytes. Portanto, o arquivo estava presente, mas era rejeitado pelo tamanho. Os avisos de APIs antigas e dSYM não provocaram essa interrupção.

A V3.19.3 altera apenas o limite de empacotamento desse Lua para 128 KiB. JavaScript continua em 64 KiB; total do framework, nomes, duplicatas, UTF-8, identidade da base e validação Mach-O permanecem controlados. Os erros distinguem ausência/duplicação de tamanho e mostram os bytes e o limite.

A falha não foi detectada antes porque os testes de integração usavam um Lua fictício de 11 bytes. A nova regressão usa os 12 recursos reais, gera um IPA de teste com binários sintéticos e compara todos os bytes incorporados, tanto na raiz quanto na subpasta Resources. Casos de borda verificam Lua em 131.072/131.073 bytes e JavaScript em 65.536/65.537, além de arquivo vazio, ausente, duplicado e UTF-8 inválido.

89 testes Python executados: 88 passaram e um foi pulado por exigir Foundation/macOS. O log enviado já registra 68 testes Lua, 491 testes JavaScript e 3.020 verificações do snapshot nativo, sem falha. Esses resultados pertencem ao build anterior; não representam execução Apple da V3.19.3.

O Lua, desenho, previsão física e ponte nativa permanecem idênticos à V3.19.2. As demais alterações nativas são apenas strings de versão para 3.19.3/build39. Alpaca preservado e Cartas desativado. O cabeçalho do recurso Lua continua identificando sua revisão 3.19.2, pois seus bytes não foram alterados.

A entrega contém fontes e workflow pareados. Ainda é necessário iniciar novo build no macOS e validar no iPhone. Nenhum IPA compilado foi produzido nesta correção local.

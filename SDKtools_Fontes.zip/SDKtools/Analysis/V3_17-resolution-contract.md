# V3.17 — resolução dos módulos do bilhar

## Evidência e escopo

Captura V3.16 de 2026-10-16T16:38:26Z, SHA-256 `db697e54b019e6cceb4beded0a1ada088d9cbb58036e53b64cf05d383d16dac1`. O resumo reproduzível está em `V3_17-capture-audit.json`; a entrega inclui o JSON original fora do ZIP de fontes.

- 401 tentativas totais; somente as 120 últimas estão disponíveis, sequências 282–401. Cobrem aproximadamente 13,21 segundos.
- As 120 pararam em `billiards_contract_mismatch`, na cena `BilliardInGame`, handle -7158. Não há bolas ou segmentos capturados.
- Os módulos canônicos Enum e Const existem como tabelas em entradas cruas de `package.loaded`; seus GameTypes observados são 1003. O diagnóstico V3.16 não distingue se o GameType interno era cru ou herdado por tabela. Os fontes recuperados o declaram como campo direto.
- `_G.Enum`, `_G.Const` e `_G.BiLogic` não são campos crus; a inspeção encontrou `__index` funcional e não o chamou.
- `_ENV` da função carregada Init é a mesma tabela `_G`. Essa função não sustenta a hipótese de outro ambiente. A inspeção limitada a 24 módulos não exclui outros ambientes no processo.
- Core e logicMgr foram observados como tabelas. O método `get`, o frame ativo e a câmera não foram alcançados pelo leitor V3.16.

A revisão atua na resolução inicial. Não altera a ponte nativa, o algoritmo geométrico ou os contratos posteriores de desenho.

## Seleção e chamada

1. Exigir cena carregada `BilliardInGame` ou `BilliardTutorial` pelos critérios existentes.
2. Preferir o par global completo. Valores crus de namespace com tipo inválido ou par completo inválido não são ignorados para selecionar outro candidato.
3. Se necessário, ler exclusivamente as chaves `Billiard/Lua/Const/Enum` e `Billiard/Lua/Const/Const` por `rawget` no cache existente. Não usar busca aproximada, aliases lowercase, funções descobertas no scan ou `_ENV` alternativo como fallback.
4. Qualquer módulo Billiard global parcialmente presente deve ser a mesma tabela canônica correspondente (`rawequal`). Rejeitar conflito; não montar um contrato misturando objetos independentes.
5. Exigir tabelas e `GameType` cru numérico 1003 em ambos os módulos. Exigir `Logic` cru, descritor cru da cena e campos crus exatos:

| Cena | Chave | Name | PkgName |
|---|---|---|---|
| BilliardInGame | frame | Game/BiFrameLogic | Billiard |
| BilliardTutorial | tutorial | Game/BiTutorialLogic | Billiard |

6. Resolver Core.logicMgr/get apenas por campo cru ou `__index` de tabela, com limite de profundidade 4 e detecção de ciclos. Callbacks funcionais não são executados por essa resolução. Proteção opaca de metatable interrompe a busca; a limitação de sentinela `__metatable` que seja tabela continua aplicável.
7. Chamar o getter já existente uma vez, protegido por pcall, com o descritor original, sem copiar ou construir outra tabela. Erro, nil, tipo inesperado ou frame destruído interrompem a leitura.
8. Continuar pelas validações anteriores de câmera, cena, tela, bolas, movimento e mira. A resolução dos módulos sozinha não autoriza desenho.

Não há `require`, execução de Init, alteração dos namespaces do jogo ou cache persistente de referências dos módulos. O estado próprio mantém os mesmos metadados escalares e referência fraca de frame do leitor anterior.

Os fontes recuperados `const/enum.lua`, `const/init.lua`, `core/game/bigamelogic.lua` e `loader.lua` sustentam os nomes e a chamada do getter. BiGameLogic obtém frame/tutorial na inicialização e inicia o frame quando a cena carrega. A implementação de Core.logicMgr não está entre os 243 scripts recuperados: não se pode afirmar que seu getter nunca inicialize um objeto em uma situação inesperada. A revisão não adiciona chamadas explícitas de criação ou inicialização.

## Telemetria `resolution`

Bloco opcional de esquema 1, separado do diagnóstico estrutural `environment`.

Campos obrigatórios: `schemaVersion`, `source`, `contractStatus`, `enumType`, `constType`, `descriptorType`, `managerType`, `managerGetType`, `managerLookup`, `frameCallAttempted`, `frameCallSucceeded`, `frameType`.

- source: `none`, `globals` ou `package_loaded`. Indica a origem selecionada após validação; permanece `none` se nenhum contrato for selecionado.
- contractStatus: `missing`, `invalid`, `conflict` ou `selected`.
- Tipos: somente os oito tokens Lua (`nil`, `boolean`, `number`, `string`, `table`, `function`, `userdata`, `thread`).
- managerLookup: `not_attempted`, `raw`, `metatable_table`, `absent`, `function_index_blocked`, `protected_metatable`, `cycle`, `depth_limit`, `non_table` ou `error`.
- Flags da chamada: booleanos reais. Sucesso exige tentativa, mas não exige retorno válido; pcall pode devolver nil normalmente.

Campos opcionais: `enumGameType`, `constGameType` inteiros observados de 0 a INT32_MAX; `descriptorName` somente um dos dois nomes acima; `descriptorPackage` somente Billiard; `frameDestroyed` somente quando observado booleano.

O sanitizador nativo copia apenas campos permitidos. Campo conhecido malformado remove o bloco opcional inteiro; campos desconhecidos são omitidos sem serialização de seu conteúdo. O bloco não altera as regras de aceitação de snapshot ou desenho. Não exporta endereços, mensagens de exceção arbitrárias ou referências de objetos.

## Critérios e pendências

Os testes reproduzem o arranjo observado em V3.16 com objetos Unity sintéticos: globais ausentes, `__index` funcional bloqueado, módulos canônicos, Init com `_ENV` igual a `_G` e gerenciador existente. Devem verificar a identidade do descritor, zero chamadas ao loader/Init/índice funcional, ausência de modificações do jogo, caminhos inválidos, retorno nil/erro/destruído, tutorial e perda de módulos entre amostras.

O workflow macOS executa os testes Foundation e recebe JSON gerado pelo produtor Lua para conferir a preservação do contrato entre linguagens. Esses testes não foram executados no ambiente Linux desta entrega; não são substitutos de build Apple e validação no aparelho.

A próxima evidência necessária é o JSON V3.17 com resolução, retorno do frame e primeiro motivo posterior de interrupção, acompanhado de prints. Não há promessa de que esta alteração sozinha produza uma guia visível.

Permanecem abertas: caçapas layer19 excluídas pela máscara 1, confirmação de alinhamento câmera/tela, identidade de partida além de frame/cena, física completa de efeito/força/atrito e validação real de rebotes. Crazy Alpaca permanece preservado; Cartas desativado.

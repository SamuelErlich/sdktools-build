# V3.4 — evidência da hierarquia de cartas

Os dois JSONs foram decodificados offline com o decoder de captura da V3.3.1, sem executar JavaScript comercial. `V3_4-card-hints-capture.json` contém somente métricas, descritores gráficos e exemplos estruturais limitados. O script auxiliar e as cenas completas não integram o pacote.

## Identidade e qualidade da captura

| Captura | Amostras | Nós máximos | Amostras truncadas | Identidade nativa |
|---|---:|---:|---:|---|
| `SDKtools-Capture-6325276E-71E9-4854-8DE3-29B4804F8DCC.json` | 260 | 279 | 0 | `gameType=2007`, `WPCocosGameViewController`, Cocos 2.4.5; título **Ah, minha carta** confirmado pelo usuário |
| `jogando.json` | 204 | 342 | 1 (`time_budget`) | Sem identidade nativa confirmada no relatório; estrutura gráfica compatível com a outra captura |

Ambas são schema 3 / SDKtools 3.3.1. As cenas foram amostradas aproximadamente a cada 250 ms. A primeira captura durou 65,05 s; a segunda, 51,16 s. A identidade 2007 é observação nativa, enquanto o nome é confirmação humana: o relatório não afirma reconhecimento automático do título.

## Contrato estrutural observado

Uma raiz candidata a carta tem `local.width=224`, `local.height=295`, `childCountReal=4`, categoria heurística `card` e não possui sprite direto. Nos exemplos, os filhos ativos representam:

| Filho direto (`siblingIndex`) | Evidência | Limite |
|---|---|---|
| 0 | Presente em parte das cartas selecionadas/realçadas | Não é identidade da carta |
| 1 | Base comum, tag `260ca2c4`, atlas `(909,212,216,286)` | Comum entre cartas; não distingue valor |
| 2 | Contêiner da frente; filhos com sprites reais da composição | Só aparece no JSON quando a frente está ativa |
| 3 | Sprite do verso | Dois frames comuns, insuficientes para distinguir cartas |

Na frente, o filho de índice 0 contém o fundo visual; o filho 2 contém o símbolo. Há variações decorativas nos índices 1 e 3. Nenhum nome original desses nós nem classe de componente foi exportado. Estes índices e medidas descrevem a versão observada e exigem validação estrutural em runtime antes de uso; não são um contrato universal do jogo.

Descritores dos dois versos sob essas raízes:

- Tag `811c9dc5`, atlas `(1357,208,224,295)`.
- Tag `4dbc405b`, atlas `(1138,212,210,280)`.

**A tag `811c9dc5` também ocorre em um sprite de 1090×1090 que não é carta. É o valor inicial FNV-1a, compatível com nome vazio. A tag isolada não identifica verso, carta ou asset.** `frameID`, `textureID` e `nodeID` são locais ao contexto. Não se deve mapear `f13`, por exemplo, entre capturas nem usar `frameNameTag` como identidade semântica.

## Frente visível e carta oculta

Na primeira amostra da captura confirmada havia 29 raízes candidatas: 7 frentes na mão inferior, 1 frente na pilha central e 21 versos distribuídos em três mãos de 7. As escalas observadas foram 0,8 na mão inferior, 0,7 na pilha e 0,4 nas outras mãos. A classificação de posição é geométrica; não identifica jogadores.

Ao final havia 30 raízes observadas: 14 frentes na pilha, 4 na mão inferior e 12 versos em outras mãos. Ao longo da captura apareceram 16 combinações distintas de fundo/símbolo e 10 transições de verso para frente. `jogando.json` contém 42 raízes candidatas ao longo do tempo e 8 dessas transições. Não equivale a 42 cartas simultâneas no início.

Exemplo verificável: na captura confirmada a raiz `n65` está em verso até a sequência 42. Na sequência 43 surge sua frente, composta pelas tags `d348dbc4` e `6a39d063`; na sequência 44 ela foi movida para a pilha `n46`. A frente não estava serializada nas amostras anteriores. Usar informação revelada posteriormente não prova que o runtime expunha a frente antes da jogada.

O probe informa `inactiveDescendantsSkipped=true` em **todas** as amostras, com 144–173 nós inativos omitidos na captura confirmada e 181–221 na segunda. Portanto, a ausência de frente nos JSONs de cartas viradas pode resultar da política de captura. Ela **não prova** que a frente inexista no objeto vivo, nem prova que esteja corretamente preenchida nele.

## O que é possível afirmar para “Ver cartas”

As frentes observadas permitem vincular um ícone à própria raiz de carta quando o sprite verdadeiro está presente nessa raiz. Um desenho fiel pode reaproveitar os frames reais da composição; inventar cor/valor por posição, hash, catálogo genérico ou ordem de filhos seria incorreto. O JSON guarda referências e retângulos, não os pixels da textura.

Para cartas ainda viradas, estes arquivos não estabelecem um mapeamento entre a raiz e sua frente. Uma futura leitura limitada do objeto específico precisaria confirmar se existe um componente/estado próprio da carta ou uma frente inativa preenchida, distinguir valor real de valor padrão/antigo e invalidar o vínculo quando a carta for reciclada ou o contexto mudar. Até essa confirmação, a condição correta é identidade desconhecida.

## Dados ausentes

Não há `CardInfo`, classes/componentes, valores de cartas, UUIDs, nomes originais de spriteframes, caminhos de assets, código JavaScript exportado ou regras de jogo nestes arquivos. Todos os nós exportados possuem somente campos estruturais; sprites trazem `present`, `frameID`, `frameNameTag`, `textureID` e `atlasRect`. `visibilityVerified=false`, `occlusionResolved=false` e `cardRulesKnown=false` permanecem explícitos no probe.

Não é possível deduzir cartas adversárias ou justificar que todos os versos possam ser revelados apenas com esta evidência. Também não é adequado ativar o solver do Crazy Alpaca para o jogo 2007: semântica, quantidade de cartas e estrutura observada são diferentes.

# SDKtools 3.23.5/build55: tentativa experimental de carta coberta

## Base e escopo

Base imutável: SDKtools 3.23.4/build54, commit `bc14dc64c299f2ce8fac676677f300ce088f0a98`, fonte ZIP SHA-256 `951df789de4791dcd920512d15eddc4b97ac89fbeefadfec33857135f8efa3ae`, WePlay US 6.6.2/build132. Não reintroduz a experiência suspensa do armazém e não altera física/Bilhar ou inferência de cores/Cartas.

Acrescenta um experimento manual, não uma política de autoplay que escolhe cartas cobertas continuamente. A tentativa usa o evento original da carta já presente e identificada no snapshot validado; não escreve máscara, canTouch, interactable, lock, inventário ou pacote de rede.

## Como usar

1. Na própria partida de Alpaca, abra a engrenagem dos ajustes compactos.
2. Desligue **Auto**, ative o **Raio X** e escolha a profundidade disponível. O experimento não possui chave de ativação persistente nem execução automática.
3. Com a mesa estável e sem outra ação pendente, pressione **Testar 1 carta coberta**. Cada pressão elegível emite no máximo um evento original. Se a mesa ainda não estiver estável, o clique é recusado sem fila; aguarde e pressione novamente.
4. Leia o estado dentro do menu. Autoplay, poderes e outra tentativa ficam bloqueados enquanto o resultado correspondente é acompanhado.
5. Rejeição só conclui após rollback da carta e consistência do tabuleiro. Aceitação protocolar só conclui após resposta e estabilidade; pode continuar sem efeito confirmado.

Não existe compra, revanche, reenvio por timeout ou tentativa em lote. Uma ação incerta mantém o bloqueio até reiniciar o app; alterar preferências, abrir o menu ou receber um sync visual não apaga essa incerteza. Sair/recarregar perde a capacidade de atribuir a resposta antiga, não a transforma em sucesso.

A seleção é determinística entre cartas comuns cobertas, dentro da profundidade do Raio X: prefere tipo já presente na mão, depois missão e menor profundidade. Descarta carta especial, controle incompatível e jogada que completaria a mão sem eliminar trio. Não oferece seleção manual de um ID específico nem garante encontrar uma tentativa em toda mesa.

## O que foi encontrado nos módulos recuperados

Bundle recuperado de Alpaca: SHA-256 `cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`. As referências abaixo são da representação `selecionados_formatados` dos módulos, não linhas do bundle minificado.

- `PileArea.js:27-41,96-99` calcula cobertura; `Block.js:45-47` modifica máscara e controle visual.
- `Block.touchBlock`, `Block.js:107-127`, não volta a consultar essa cobertura; verifica estados globais e lock especial. Isso indica viabilidade do caminho cliente, não aceitação do servidor.
- O método emite TouchPileBlock antes do transporte. `GameLayer.js:45-49,80-84`, `HandArea.js:71-73` e `PileArea.js:65-68` movem e alteram Store otimisticamente. Carta mover, trio desaparecer e Store atualizar não são prova de resposta.
- `Socket.js:140-142` retorna a Promise de send para `CMD_TOUCH_BLOCK`; `Socket.js:108-115` registra responseMap e envia o envelope original com packet_id, comando e parâmetros normais.
- `Socket.js:71-87` extrai packet_id e code do cabeçalho, decodifica o corpo quando necessário e resolve somente com code numérico 200; outro código rejeita com message. O Promise retornado por Block.touchBlock não aguarda essa resposta.
- `Socket.js:84-86` não apaga entradas por resposta; `destroy`, `:105-107`, troca responseMap e reinicia packetId sem rejeitar todos os pendentes. Resposta perdida, corpo inválido e reconnect podem abandonar uma Promise.

REA parent Evidence `ev_994f5cb75ba657b28843b809117e07306ce5d7f0707bb8b2eab6ba17ad5404fe`, root SHA-256 `59bbe0113a7be53447d3b07deda9fc4a54490c16ae976465b855bd2a58436ca5`: 128 arquivos inventariados, 6 analisados, 122 fora do escopo, zero falhas de parsing. Esse root identifica o diretório derivado `modulos_factory`, não o bundle. O factory Socket possui SHA-256 `061aed301b96213a82ac3cfb9405fe5456de3145d462d4dc49cb4ffde7d2f903`; o formatado é `66719de18f9800fffbc1eabd2b723f4e6b6f61299da1bd9e07814621743f9878`. Leitura manual de controle/ordem não é atribuída ao grafo; nenhuma análise estática comprova versão carregada ou comportamento do servidor atual.

## Protocolo de confirmação implementado

O módulo isolado `Resources/alpaca_covered.js` mantém somente uma tentativa em voo. O adapter fornece o snapshot completo e revalida o evento registrado antes de invocá-lo.

1. Instala observers temporários antes de invocar o evento. Falha anterior à invocação é bloqueio sem envio.
2. Dentro da chamada original Socket.TouchBlock, valida singleton, argumentos da carta e estado Pile=0, captura packetId e responseMap. Não presume o próximo contador antes dos callbacks internos síncronos.
3. Observa o envelope original sem alterar bytes/argumentos e acompanha o objeto Promise original, sem substituir sua identidade ou forçar seu settlement.
4. Um listener aditivo de WebSocket considera somente evento confiável do socket capturado, packet_id correspondente e code numérico no cabeçalho. Não substitui onmessage nem consome o evento original.
5. Exige header200 + Promise resolvida, ou header não200 + Promise rejeitada. Header isolado, Promise isolada, heartbeat, push, outro jogador, sync e mudança visual não concluem a tentativa. Header200 com corpo comprimido inválido pode não alcançar o resolver original e permanece incerto.
6. Após concordância, exige dois snapshots completos iguais por no mínimo 80 ms e um censo de pile/hand/storage consistente com todos os cards renderizados. Na rejeição, exige a carta original novamente na pilha. Na aceitação, registra separadamente se a carta foi observada fora da pilha/na mão ou removida; ACK sem esse efeito não é apresentado como efeito confirmado.
7. Mantém o bloqueio compartilhado com autoplay e poderes enquanto houver pending. O experimento não incrementa confirmedMoves das jogadas normais.
8. Timeout de 15 segundos, socket fechado, exceção após invocação ou troca de cena/rodada/socket/responseMap torna o resultado incerto e bloqueado. Resposta atrasada não apaga o latch e não há retry automático.

Hooks são restaurados apenas se ainda pertencerem ao SDK. Os listeners originais e os argumentos, retornos/Promises e exceções originais são preservados. O diagnóstico tem campos fechados de estado, flags e código numérico; não contém credenciais, identidades reais, IDs de cartas ou corpos de rede.

## Testes e limites materiais

Suítes cobrem execução única, retorno/this/argumentos, resposta real correlacionada, rejeição com rollback, ACK sem efeito, censos inconsistentes, erro/timeout/reconnect, colisão de packetId, mensagens sintéticas, resposta comprimida inválida, hooks de terceiros e bloqueio de novas ações na incerteza. Colaboradores são mocks explícitos; esses testes não executam o jogo recuperado nem chamam servidor.

Os números finais pertencem ao manifesto `Validation/V3_23_5-validation.json`, gerado apenas após congelar os fontes efetivamente testados. Build Apple, integração IPA, assinatura, instalação e uma tentativa física continuam etapas separadas. Nenhum teste local prova que o servidor aceitará uma carta coberta nem autoriza alegar bypass universal.

# LAN control — 3.23.13 / build 63

## Arquitetura implementada

Browser HTTP mesmo Wi-Fi -> STLANServer -> STLANProtocol -> STLANRecorder ->
setters/start/pause existentes do STRecorder -> bridge/runtime originais.
Nenhum comando remoto constrói pacote do jogo ou recebe JavaScript do navegador.

O servidor IPv4 não bloqueante usa fila serial separada da UI. Bind no IP
privado do Wi-Fi en0, porta 0/efêmera. Só o provider/handler fechado acessa a
thread principal. Limites: 8 conexões, 30 requests/s, 8192 bytes de headers,
1024 de body, request máximo 9216, timeouts de conexão de 3s, resposta JSON
máxima 32768. Uma request por conexão; sem chunking, pipelining, Expect ou
Content-Length duplicado. Métodos/path/headers têm validação fechada.

Assets locais /, /panel.js, /panel.css; CSP sem terceiros, frame-ancestors none,
Cache-Control no-store, no-referrer. Sem dependências de CDN ou telemetria.

## Pareamento e comandos

1. Usuário toca Browser control no iPhone. Nenhuma sessão LAN nasce no init.
2. URL IP:porta e PIN de 8 dígitos, 5 tentativas globais, prazo 120s.
3. Primeiro pareamento correto fecha o PIN e recebe chave CSPRNG de 256 bits,
   separada de credenciais WePlay, mantida somente na memória da página.
4. Peer IPv4 fica vinculado; APIs exigem header X-SDKTools-Key, Host exato e
   Origin/fetch-site coerentes. POST exige application/json e Origin exato.
5. Sequência estritamente crescente consumida antes do handoff para main.
   Duplicatas/fora de ordem são recusadas sem invocar o handler. Perda da
   resposta não gera reenvio; página pede nova leitura/inspeção.
6. Estado e controles são serializados no browser. Poll 500ms; sair/ocultar a
   página tenta uma pausa e deixa de renovar heartbeat. Sessão expira em ~8s.
7. Stop/background revogam listener/chave/conexões. Auto iniciado remotamente
   pausa, preservando todas as pendências de requisições do jogo.

HTTP NÃO é TLS: chave e PIN podem ser observados por quem interceptar a rede.
Não tratar o PIN como proteção contra um adversário no mesmo Wi-Fi. Não há
mecanismo de exposição pública, relay, NAT/UPnP ou conexão externa. A versão
inicial deliberadamente exige rede privada confiável e entrada manual do IP.

Apple TN3179 registra que aceitar TCP de entrada, por si, não exige permissão de
rede local. Não se usa Bonjour nem conexões de saída para outros dispositivos.
Por isso não se altera o Info.plist do app principal nesta implementação:
https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy
O SDK continua sujeito à suspensão/inatividade normal de iOS; não há bypass de
background. A opção fecha a ponte em application/scene inativa.

## Dados e velocidades

Amostragem read-only continua mesmo com Auto e X-ray desligados enquanto LAN
estiver ativo, limitada a 5 Hz quando apenas o painel estiver observando.
Auto, X-ray e respostas pendentes mantêm suas cadências existentes. O guard actionAllowed ainda exige autoplayEnabled e todos os
bloqueios originais. Não há evaluateJavaScript iniciado por /api/state.
Snapshot: tipo nativo 60, foreground, idade <2s e phaseSummary complete. Dados
incompletos/antigos viram null, não 0. Contagens incluem sharedCards no total;
"jogadas confirmadas" é efeito local do Auto, não ACK universal ou vitórias.
Missão expõe apenas current/total; nada de uid/rid, token, salas ou card IDs.

Nível 1 500ms / 2 250ms / 3 100ms / 4 Turbo 40ms / 5 Super Fast 20ms.
O nível máximo continua limitado a até três cartas expostas, ACK + settlement
+ efeito. A compatibilidade 3.23.12 pode fazer uma carta por vez. Trocar o nível
não inicia jogo, não limpa latches, não muda estoque e não promete taxa fixa.
O getter acompanha alterações dos switches nativos Turbo/Super Fast.

## Escopo e limites verificáveis

Esta versão controla autoplay/opções, não faz streaming de pixels nem clique
manual por carta no PC. O servidor WePlay e sua sessão continuam no iPhone.
Cartas/Bilhar e gameplay JS são preservados byte a byte frente à 3.23.12.

Node testa o cliente real e uma DOM sintética: contagens, níveis, preferências
sem start, correlação, comandos proibidos, concorrência e perda de resposta sem
replay, DOM textContent, pause ao ocultar. Python protege wiring/privacidade/
recursos. macOS CI compila e executa servidor TCP Foundation real em loopback
com callbacks sintéticos, parser, auth/origin, duplicatas e lease, mais o setter
de velocidade extraído do código de produção. Windows não executa Foundation.

Compilação UIKit/iPhoneOS, assinatura e execução física não foram feitas neste
host. Exigem validação especialmente: IP en0, AP isolation, pareamento no Chrome,
background, fechar aba, Auto já pendente, slowloris, reiniciar link, poderes e
nenhum aumento de timeout ou liberação de latch ao mudar velocidade.

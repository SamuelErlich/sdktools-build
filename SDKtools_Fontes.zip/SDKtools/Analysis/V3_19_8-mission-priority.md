# Alpaca: contrato de missão e prioridade — 3.19.8

## Evidência estática, sem executar o jogo exportado

Exportação histórica `SDKtools-GameSources-8B4DDC11-2958-4B0D-BDE3-811A3F4B11DD.json`: 5.530.425 bytes, SHA-256 `ae2d416e6b90ca841b87fa37a86e040d4524e7c104efe83e0f05f5829c7dc593`.

`assets/main/index.js`: 3.641.464 bytes, SHA-256 `cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`. Os sete arquivos da exportação conferem tamanho/hash e marcadores completeFile/readMetadataStable. Isso é evidência de exportação completa, não atestado da versão atualmente carregada.

128 módulos Browserify delimitados via AST, sem avaliar suas funções. REA analisou Task, TaskFinishAlert, GameStore, Game e GameLayer: 5 fontes, 9.059 nós AST, nenhum erro de parse. Evidence `ev_3f2c82f2b6a506cd75eec2c0024106e49a9e80a7ab2b9959726e71325cf77b74`. Limites semânticos/dinâmicos desse relatório não foram tratados como execução comprovada.

## Contrato observado

- `Task.setup` consulta `GameStore.getTaskInfo()`: tipo em target_block_type; rótulos current_num/total_num; barra current_num/total_num.
- `GameStore.sync` guarda task_info; `setTaskInfo` substitui esse campo. `Block.init` conserva blockInfo.type, que já é a identidade usada pelo autoplay.
- PushEvent.UpdateCommonTask = 11. `Game.updateCommonTask` exibe current_task_info e imediatamente armazena new_task_info. `reward_prop` é aplicado pelo jogo e anima/abre TaskFinishAlert. Por isso não se deve inferir a missão pelo ícone antigo durante a transição.
- `TaskFinishAlert` fecha normalmente no fluxo original; o SDK não precisa consumir um poder nem fazer requisição para receber a recompensa.

## Implementação

Leitura opcional de campos próprios, sem chamar getters: exige Game único na cena, Game.GameLayer ligado à mesa, Task descendente válido e módulo original GameStore. Falha desse contrato desativa apenas prioridade de missão, não o autoplay existente.

O planejador procura o próximo trio, não uma solução global. A missão domina o desempate entre rotas comprovadas e pode estender a busca a bloqueadores mesmo com um trio normal já disponível. A perseguição de alvos cobertos tem teto de oito slices (até 8ms cada) / 2.400 escolhas geradas. O restante do tick/leitura conserva as guardas existentes. Limite de busca não significa ausência matemática de solução.

Fallback: conserva a prova normal disponível; sem prova, reinicia a ordem/orçamento normais independentemente da tentativa prioritária. Missão/progresso integra o fingerprint de continuação. Ações preparadas/rotas são invalidadas na mudança; latch de ação física incerta não é descartado.

A telemetria nativa aceita apenas enums e números limitados. Progresso não é aumentado localmente. Não há novos hooks, timers, requisições, alterações de inventário, gasto/compra de poderes ou chamadas a Socket.

## Verificação e limite

42 novos testes JavaScript incluem prioridade sobre par, bloqueadores, missões ausentes/travadas, bandeja cheia, orçamento, troca antes do envio, preservação de envio incerto, getters não invocados e modal de recompensa. Um teste enumera 120 DAGs sintéticos com um oráculo independente de alcance do próximo trio. Testes Foundation verificam o contrato numérico e remoção de campos inválidos sem apagar o resultado de uma ação enviada.

Cartas: todos os recursos byte-idênticos à 3.19.7. Bilhar: apenas versão nos dois emissores de relatório e no teste correspondente; algoritmo/recurso Lua preservado. Assinatura, instalação, leitura real de missão e recompensas no iPhone não foram executadas nesta estação Windows.

# SDKtools 3.23.7 / build 57 — Penetrate experimental

Data: 2026-10-19. Base imediata imutável: 3.23.6/build 56, ZIP SHA-256
`f465f1d08652abe557d8c56f122e02f3040a3c25548771cbed2e4279b8c6a36e`.

## O que foi implementado

Um botão manual separado em **Alpaca → engrenagem → Testar Penetrate (estoque 0)**.
Cada clique pode solicitar **uma** chamada do método original `Socket.UseProp`.
O botão não concede poderes, não compra, não altera estoque ou flags do jogo e
não monta nem envia pacotes diretamente. A aceitação do servidor é desconhecida.
O experimento anterior **Testar 1 carta coberta** permanece separado na interface,
mas ambos usam o mesmo coordenador e a mesma trava nativa de operação pendente.

## Condições antes da chamada

- Auto desligado, Raio X ligado e mesa própria em jogo normal, estável.
- UID/RID, documento, cena, Store e socket atuais verificados; sem assistir aliado.
- Nenhum comando normal, poder, captura ou experimento concorrente pendente.
- `GameStore.props_blocks` real, com no máximo 16 linhas, contém exatamente uma
  linha de tipo numérico `3`, `count` numérico exatamente `0` e `id` real igual a
  `3-${uid}`. Não se cria uma linha ausente nem se adivinha um identificador.
- Estoque positivo bloqueia o teste para não gastar um poder existente.
- Uma carta ordinária coberta, identificada no Raio X e dentro da profundidade
  selecionada, é elegível; capacidade da bandeja e estado da mesa são conferidos.
- As condições são revalidadas até a chamada original. Clique durante leitura
  instável não fica enfileirado: é necessário outro clique manual depois.

## Caminho estabelecido pelos fontes recuperados

Em `Alpaca_US/selecionados_formatados`, `Constant.PropType.Penetrate` vale `3`.
`UsePropAlert` bloqueia a confirmação normal com estoque zero. No ramo original
de Penetrate de `Block.touchBlock`, a chamada é
`Socket.UseProp(\`3-${GameStore.getUid()}\`, blockInfo.id)`.
`UseProp` encaminha `CMD_USE_PROP` com `prop_id` e `block_id`; não é o mesmo
comando `TouchBlock`, que envia `block_id` e `block_state`.

Esta versão consulta o método `UseProp` **depois** de instalar observação, conserva
o receiver e retorna sua Promise original. O próprio jogo constrói o pacote e usa
seu transporte. Não há cópia de uma jogada válida para fingir que uma carta coberta
ficou exposta, alteração de `canTouch`, `isUsingPenetrateProp` ou de contagem.

Proveniência estática já preservada no marco 3.20.0 e na análise 3.23.5:
`outputs/SDKtools_Marco_Continuidade_V3_20_0/02_FONTES_RECUPERADOS/Alpaca_US`.
Bundle `assets/main/index.js` SHA-256:
`cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`.
Factory Socket SHA-256:
`061aed301b96213a82ac3cfb9405fe5456de3145d462d4dc49cb4ffde7d2f903`.
REA Evidence:
`ev_994f5cb75ba657b28843b809117e07306ce5d7f0707bb8b2eab6ba17ad5404fe`.
É evidência de código estático; não prova de execução ou aceitação do servidor.

## Resposta, efeito e recuperação são diferentes

1. O estado local `submitted` apenas informa que a avaliação foi iniciada.
2. `requestObserved` identifica a chamada original e seu packet ID no socket
   físico atual. Heartbeat, push ou resposta de outro pedido não são confirmação.
3. `responseOutcome` só vira `accepted` ou `rejected` quando envelope correspondente
   e resolução/rejeição da Promise original concordam.
4. `200` não significa poder ilimitado. Para Penetrate, a carta escolhida deve
   sair da mesa e aparecer na bandeja com o tipo correto e censo completo.
5. Liberação exige dois snapshots consistentes separados por pelo menos 80 ms.
   Recusa exige recuperação/rollback verificado. Não há retry automático.

A janela de resposta é de 15 s. Sem confirmação correspondente, o resultado é
incerto e permanece bloqueado. Depois de uma resposta conhecida, existe uma
janela de recuperação separada de 15 s. Se ela expirar, `recovery_timeout`
**preserva** a resposta conhecida e bloqueia nova tentativa. Observação passiva
pode concluir recuperação tardia na mesma sessão; perda real de contexto não.

## Correção confirmada pelo relatório do aparelho

O relatório `SDKtools-CoveredCard-29CBF982-17AC-4291-9604-A84E6873775D.json`
(3.23.6/build 56, SHA-256
`80deb38375e0eef9e3804d50927807be7b8ebfb2117121f0deb3c3c9c18dc951`)
registrou `server_rejected`, código `500`, resposta observada e Promise liquidada.
Depois foi incorretamente reclassificado como `response_timeout` pela antiga
janela única. A nova janela separada corrige essa classificação: uma recusa
conhecida não vira ausência de resposta. Isso **não corrige nem contorna a recusa
500 do servidor**. O significado interno específico desse código não foi provado.

## Relatório e teste no aparelho

**Alpaca → engrenagem → Exportar relatório do teste** continua disponível durante
pendência/incerteza e sem partida. Exportação nativa, somente leitura: não envia
outro pedido, não consulta WebKit, não rearma e não limpa a trava.
O JSON conserva o schema v1 e acrescenta `kind`, `responseOutcome`, `phase` e
`lastObservation` fechado (status, motivo e contagens/detalhes permitidos da
última leitura). Não exporta IDs de jogador/carta, corpo de pacote ou texto
arbitrário recebido. Limites: menos de 64 KiB e até 24 eventos.

Após compilar/instalar, entrar na própria partida, manter Auto OFF e Raio X ON,
aguardar mesa estável e usar o novo botão uma vez. Se indisponível, a linha de
Penetrate com estoque zero pode não existir naquele modo; não se fabrica esse
estado. Exportar o relatório após resposta/pendência. Não interpretar uma mudança
visual otimista ou um `200` isolado como concessão de poder.

## Validação e preservação

Suítes JavaScript e Python portáteis, regressões 500/timeout, casos de estoque/ID,
contratos do menu/bridge/report e preflight ZIP/workflow. Contagens e hashes exatos
ficam em `Validation/V3_23_7-validation.json` e nos logs da entrega.
Fixtures Foundation foram ampliadas e estão ligadas ao workflow macOS, mas não
executadas neste Windows; UIKit/Xcode/linkagem, assinatura e iPhone não validados.
Nenhuma tentativa no servidor do jogo foi executada por este agente.

17 dos 19 recursos JS/Lua continuam byte a byte iguais à 3.23.6; somente
`autoplay_tool.js` e `alpaca_covered.js` mudam. Bilhar, Cartas, planners, poderes
normais e Raio X não recebem novo algoritmo nesta versão.

Entregar e subir juntos `SDKtools_Fontes.zip` na raiz e `compilar.yml` como
`.github/workflows/compilar.yml` no repositório. O workflow valida tamanho, SHA-256,
manifesto e versão/build antes da extração. Executar o commit novo, não repetir
um job antigo. Esta entrega é fonte + workflow; não contém novo IPA compilado.

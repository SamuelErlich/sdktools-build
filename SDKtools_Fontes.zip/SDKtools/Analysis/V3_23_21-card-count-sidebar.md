# Lista lateral de cartas — 3.23.21 / build 71

A lista integra o renderer somente visual do Raio X. Agrupa o snapshot atual
por tipo interno, usa o SpriteFrame original e exibe uma quantidade por ícone.
Nenhum nome de desenho ou tipo ausente é inferido.

## Escopo da quantidade

Soma s.cards (mesa + reserva) e s.tray (bandeja). Inclui cartas bloqueadas e
cobertas de todas as profundidades, independentemente do filtro visual 1–4.
Não inclui o armazém compartilhado, outras mesas ou cartas não carregadas.
A ida de uma carta à bandeja não altera a quantidade; a remoção de um trio
reduz o total em três. A troca para um aliado usa a mesa exibida já validada
pelo adaptador e não mistura dados de sua mesa original.

## Apresentação e atualização

Ícone e número ficam numa coluna lateral que respeita os limites da mesa e
da camada do jogo. Margem direita preferencial, esquerda como alternativa.
Não são instalados componentes de toque nem alterados nós originais.
A falta de espaço ou de dados consistentes oculta a lista; não mostra totais
parciais como se fossem completos. A atualização reutiliza nós quando possível.
Desligar o Raio X, trocar a cena ou perder a leitura limpa os elementos próprios.

O bloqueio de um lote incerto também limpa as imagens anteriores, preservando
as pendências e a proibição de repetir pedidos já enviados.

## Base e validação

Base: 3.23.20/build 70, commit local
28a857e9fa6468e54579be7e0e5324aadafadabc.
A entrada continua WePlay_US_6.6.2_base.ipa da Release base-us-6.6.2.
Resultados locais em Validation/V3_23_21-validation.json.
Compilação Foundation/UIKit/iPhoneOS e validação visual no iPhone continuam
pendentes; este ambiente é Linux.

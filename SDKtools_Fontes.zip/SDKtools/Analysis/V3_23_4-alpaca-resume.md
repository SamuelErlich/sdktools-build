# Alpaca: retomada e dicas — 3.23.4/build 54

Relato físico: Auto e Raio X ligados sem bordas verdes; interrupções após a lhama e ao assistir aliados. O usuário solicitou dicas ocultas no tabuleiro aliado, com retomada no próprio jogo.

## Causas comprovadas no código

- `Block.touchBlock` consulta `GameStore.isHotTiming`, `isCanTouchBlock`, modo espectador, estado do jogador e outros modos globais. O adaptador validava botão e máscara, mas não essas condições. Podia registrar como enviada uma ação ignorada pelo callback original.
- `Game.onHotTimeBomb` fecha o seletor, anima a lhama por dois segundos e limpa mão e parte da mesa. Portanto a máscara invisível não prova fim do efeito.
- A confirmação exigia que todas as outras cartas e a mão correspondessem exatamente à previsão. Efeitos concorrentes podiam impedir essa confirmação indefinidamente.
- Toda leitura durante uma ação pendente passava prova nula ao overlay, apagando os destaques verdes mesmo quando um trio atual era verificável.

## Correção

Leitura própria de campos do GameStore ligado ao Game/GameLayer observado, sem chamar métodos de ação nem alterar estado. Modos temporários invalidam preparos; não desarmam as preferências. Cada novo envio revalida o estado global no mesmo tick da leitura.

Uma ação consumida pode deixar de bloquear após duas leituras estáveis, se o contexto é a mesma partida/jogador e todas as cartas do Store coincidem com a cena por ID original, tipo e zona. O alvo precisa ter saído das zonas selecionáveis. Não conta essa reconciliação como jogada confirmada, não reenvia o alvo e não libera por timeout. Estado incoerente, outra partida, jogador, ID reutilizado ou alvo ainda na mesa preservam a pendência.

Dicas de trio são calculadas e verificadas independentemente enquanto se aguarda uma ação incerta, sem autorizar outro clique. Assistir a um aliado oculta os visuais; a volta exige estabilidade e replanejamento. Layout de quatro cantos, preferências, Cartas e Bilhar preservados.

## Evidência e validação

Exportação histórica GameSources `8B4DDC11-2958-4B0D-BDE3-811A3F4B11DD`, SHA-256 `ae2d416e6b90ca841b87fa37a86e040d4524e7c104efe83e0f05f5829c7dc593`; bundle `cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`. Extração validada e módulos delimitados por AST, sem executar o jogo. REA `ev_2e47752ddbeb9a7d5b92958888710e0a081c5285dd0e801c175f478181358fbc`: quatro arquivos, 9464 nós AST, zero erros de parse; análise estática parcial, sem prova do runtime atual.

Regressões reproduzidas antes da alteração: modo global não interrompia envio, HotTime deixava pendência, mudança concorrente impedia retomada, espectador sem máscara permitia dicas, pendência apagava trio. Testes incluem retomada, estabilidade interrompida por pausa/modo, tipo/zona divergentes, Store desatualizado, IDs duplicados/reutilizados, outra sala/jogador e ausência de reenvio.

Testes locais e CI são registrados no manifesto e nos registros de entrega. Não foi realizado teste físico novo no iPhone pelo agente. Os testes usam o adaptador real com cenas simuladas; não demonstram correção de todo evento possível do servidor.

# V3.19.6/build42 — contagens atuais e limite das cores

## Entradas e evidência

- Relatório SDKtools3.19.5, 1.107.257bytes, SHA256 `a7d46b4a1eefe9e4c5b69c7a9fea5a845d624df050d61f0686740d9e47b0ad2f`.
- Imagem SHA256 `1c578a9d02b5ad3afed3203a92276f033e2f42f8f5f377a290f09eb21d2abec2`.
- Captura early:90segundos,355amostras/579eventos,47respostas decodificadas, sem erros/perdas/truncamento. O JSON registra `cardHints.enabled=false`, `reason=not_started`, `events=[]`. A imagem tem marcadores ativos, mas não há relógio/correlação que prove o mesmo estado do JSON.
- A captura contém apenas `mode=3, game_mode_type=1, bet_level=4`, compatível com Free/time (também informado pelo usuário). Outros modos não foram capturados.

## Problemas confirmados

1. `shown/unknownShown` são quantidades de marcadores desenhados na cena, incluindo descarte. O renderer suprime marcadores em cartas sobrepostas/sem espaço. Não são contagem de mão. `liveColors.observations=35` é histórico de chamadas e repetições, não35cartas atuais; houve27IDs únicos no histórico.
2. `select_give_card` não é uma cópia de todas as mãos ocultas. Nesta captura, só a carta81 recebeu face nãozero: vermelho/4, seq276–278 e286–288. Ela foi comprada no seq273 e descartada no seq283; nunca aparece em `zone=hand`. Não pode colorir uma mão que nunca a contém.
3. No primeiro estado ativo (seq18,4.090s), as mãos por slot têm `[7,7,7,7]`, faces conhecidas `[7,0,7,0]`. No último (seq572,89.414s), `[9,4,1,3]`, conhecidas `[9,0,1,0]`. Slots são índices do Store, não posições físicas comprovadas na tela.
4. O15sobre o avatar na imagem é o countdown do jogo. No módulo Player extraído do GameSources anterior, `startCountDown` usa `state_left_time/1000` e decrementa `leftTimeLabel` por segundo; PlayerList encaminha a chamada. Não é total de cartas.

## Correção implementada

- Census atual de1–8mãos e até256cartas, obtido do Store autenticado por classe Card real. Total de cada mão é `gamers[slot].cards.length`; inclui cartas sem nó visível e exclui descarte/compra ainda fora da mão.
- Faces validadas são contadas por especial/vermelho/azul/amarelo/verde; Back0, resíduos e campos inconsistentes permanecem desconhecidos. Especiais entram em known, em categoria própria.
- Fatos de `select_give_card` já observados só contribuem enquanto associados unicamente à mão atual, dono, rodada e conexão originais. Nenhuma inferência por ID ou histórico de textura.
- Snapshot rasgado, UID/ID inválido/duplicado, troca de cena ou limite excedido resultam em `handsStatus=unavailable`, não num falso total válido de zero.
- Etiqueta independente por mão: `N cartas · ?U`. Pode faltar por falta de espaço/âncora atual; a contagem no menu/relatório não diminui por isso. Círculos/X continuam parciais, não contadores.
- Bridge exporta apenas contagens limitadas/whitelist, nunca UID, nomes, IDs ou referências do engine. Arrays/distribuições são comparados para registrar mudança mesmo quando soma permanece igual.
- Exportação de Cartas disponível também com marcadores ativos. Para investigar marcadores, não iniciar captura early ao mesmo tempo: ela os desliga por projeto.

## Verificação e limites

-550testes Node aprovados;93testes Python executados (89aprovados,4ignorados por plataforma); novos harnesses Foundation incluídos para CI.
- Replay dos41estados Store_after desta captura usando card_root.js de produção e UIDs/nós simulados: todos os totais/known/unknown conferiram; nenhuma nova cor oculta foi inventada. Primeiro total28/known14/unknown14; último17/10/7.
- Testes sintéticos cobrem Free/time e demais valores de modo2/3/5/6. Não comprovam todas as variantes ao vivo.
- Isto corrige contagem e apresentação, **não resolve a ausência de informação de todas as cores ocultas**. Para estas mãos, os dados fornecidos não permitem recuperar a cor inicial verdadeira.
- Alpaca e Bilhar preservados funcionalmente; apenas strings de versão dos relatórios de Bilhar mudam.
- Etiquetas novas ainda exigem teste visual no iPhone. Assinatura/instalação não realizadas nesta máquina.

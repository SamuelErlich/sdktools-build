# V3.16 — contrato do diagnóstico de ambiente

Escopo: investigar o bloqueio `billiards_contract_mismatch` observado na V3.15.1. Não selecionar automaticamente um ambiente alternativo nem remover gates. Não alterar o Alpaca, Cartas, física ou ponte ABI.

O probe acrescenta `environment` somente na cena de bilhar carregada, antes do gate Enum/Const. O objeto é diagnóstico; nunca autoriza desenho. Não executar require, inicializadores, __index funcional, callbacks de jogo ou escrever em tabelas do jogo. Lookups estruturais podem seguir apenas __index que seja tabela, com ciclo e profundidade limitados. Não serializar endereços, valores arbitrários, mensagens de erro ou dados de jogadores.

Schema opcional aditivo sob o snapshot1:

```json
{
  "environment": {
    "debugType": "table",
    "environments": [
      {
        "biLogicType": "nil",
        "constType": "nil",
        "contractValid": false,
        "coreType": "table",
        "enumType": "nil",
        "frameDescriptorType": "nil",
        "index": 1,
        "managerType": "table",
        "sameAsGlobal": true,
        "source": "_G",
        "tutorialDescriptorType": "nil"
      },
      {
        "biLogicType": "nil",
        "constGameType": 1003,
        "constType": "table",
        "contractValid": true,
        "coreType": "table",
        "enumGameType": 1003,
        "enumType": "table",
        "frameDescriptorType": "table",
        "index": 2,
        "managerType": "table",
        "sameAsGlobal": false,
        "source": "Billiard/Lua/Const/Init",
        "tutorialDescriptorType": "table"
      }
    ],
    "environmentsTruncated": false,
    "errorCount": 0,
    "getupvalueType": "function",
    "globals": [
      {
        "depth": 0,
        "indexType": "none",
        "lookup": "raw",
        "name": "Core",
        "rawType": "table",
        "resolvedType": "table"
      },
      {
        "depth": 0,
        "indexType": "none",
        "lookup": "absent",
        "name": "Enum",
        "rawType": "nil",
        "resolvedType": "nil"
      },
      {
        "depth": 0,
        "indexType": "none",
        "lookup": "absent",
        "name": "Const",
        "rawType": "nil",
        "resolvedType": "nil"
      },
      {
        "depth": 0,
        "indexType": "none",
        "lookup": "absent",
        "name": "BiLogic",
        "rawType": "nil",
        "resolvedType": "nil"
      },
      {
        "depth": 0,
        "indexType": "none",
        "lookup": "raw",
        "name": "package",
        "rawType": "table",
        "resolvedType": "table"
      },
      {
        "depth": 0,
        "indexType": "none",
        "lookup": "raw",
        "name": "debug",
        "rawType": "table",
        "resolvedType": "table"
      },
      {
        "depth": 0,
        "indexType": "none",
        "lookup": "raw",
        "name": "CS",
        "rawType": "table",
        "resolvedType": "table"
      }
    ],
    "limits": {
      "environments": 8,
      "lookupDepth": 4,
      "modules": 24,
      "scanKeys": 512,
      "upvalues": 16
    },
    "loadedType": "table",
    "matchedKeys": 1,
    "mode": "structural_only",
    "modules": [
      {
        "environmentIndex": 2,
        "environmentStatus": "found",
        "name": "Billiard/Lua/Const/Init",
        "source": "known_key",
        "upvaluesScanned": 1,
        "valueType": "function"
      }
    ],
    "modulesTruncated": false,
    "packageType": "table",
    "scanTruncated": false,
    "scannedKeys": 1,
    "schemaVersion": 1,
    "sequence": 1,
    "stage": "before_contract"
  }
}
```

O exemplo foi produzido pelo teste sintético env_distinct; não é uma captura do aparelho. Os gameTypes não observados devem ser omitidos, nunca inicializados em1003 nesse diagnóstico. `contractValid` exige Enum.Billiard.GameType e Const.Billiard.GameType observados iguais a1003, método manager:get e descritor acessíveis estruturalmente; não prova um frame ativo. frameDescriptorType pode ser string/table conforme o objeto observado; não impor o tipo do exemplo.

Limites nativos: globals<=7, modules<=24, environments<=8; somente escalares explícitos. `name` global em Core/Enum/Const/BiLogic/package/debug/CS. Nomes de módulo limitados a96caracteres de tokens seguros, prefixo Billiard/ ou billiard/ (forma com pontos pode ser registrada se filtrada explicitamente no Lua). Origem de ambiente: `_G` ou nome de módulo admitido. Tipos Lua: nil/boolean/number/string/table/function/userdata/thread. `lookup`: raw/metatable_table/absent/function_index_blocked/protected_metatable/cycle/depth_limit/non_table/error. `indexType`: tipo Lua ou none/protected. `environmentStatus`: found/no_env/no_debug/not_function/error/upvalue_limit/env_limit/non_table_env. `source` de módulo: known_key/loaded_scan. `stage`: before_contract. `mode`: structural_only. Inteiros: sequence0..INT32_MAX, profundidade0..4, indices1..8, scans0..512, matchedKeys0..536, upvalues0..16, errorCount0..128, gameTypes0..INT32_MAX. Booleanos reais obrigatórios.

Sanitization: inválido/muito grande remove environment inteiro (sem tornar leitura válida nem invalidar obrigatoriamente snapshot legado); campos desconhecidos omitidos. Linhas malformadas devem causar remoção do diagnóstico, não vazamento parcial de objetos. Campos opcionais de gameType/índice ausentes permitidos; se presentes inválidos, remover diagnóstico. Validação antiga dos campos de desenho permanece igual. Testar ida e volta pelo JSON e ausência de autorização de desenho em snapshots unsupported.

Limites Lua: conferir exatas chaves canônicas + minúsculas de Const/Enum, Const/Const, Const/Init e Loader; percorrer no máximo512chaves com next (não pairs); registrar módulos relacionados até24; _ENV de função já carregada via debug.getupvalue protegido até16upvalues; deduplicar tabelas de ambiente por rawequal até8 incluindo_G. Nenhuma chamada ao módulo. Ambiente é inspecionado estruturalmente, não inicializado. Recursos ausentes ou protegidos devem produzir motivo explícito. Scan incompleto não prova ausência. Nenhuma nova fonte de dados de gameplay é usada para desenho nesta revisão.

Limite de introspecção: getmetatable pode devolver o valor protegido de __metatable. Se esse valor também for uma tabela, a API padrão não permite distinguir a máscara da metatable real. Esta versão não usa debug.getmetatable para contornar essa proteção. Ausência ou resolução estrutural é evidência limitada e nunca autoriza desenho.

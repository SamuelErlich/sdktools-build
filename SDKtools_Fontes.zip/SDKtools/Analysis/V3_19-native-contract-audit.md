# V3.19 — conferência local do produtor e do contrato nativo

## Escopo e limite da evidência

Conferência realizada na árvore `sdktools-us-v319/SDKtools`, executando o produtor Lua real com os objetos Unity sintéticos já existentes em `Tests/test_billiards_probe.lua`. As saídas foram obtidas por `scripts/test_billiards_probe.py::run_case` e confrontadas, por verificações Python e leitura do código, com os requisitos de `Sources/SDKtools/STBilliardsLiveSnapshot.m`.

**O sanitizador Objective-C/Foundation não foi executado neste ambiente.** Esta conferência confirma a forma dos dados produzidos e os requisitos descritos abaixo; não equivale a compilação Apple, execução do teste Foundation, simulação da implementação de NSNumber ou validação no aparelho.

## Seis fixtures conferidas

| Fixture | Estado observado | Segmentos | Estados finais | Resultado da conferência |
|---|---|---:|---:|---|
| `env_distinct` | `unsupported` | 0 | 0 | Metadados finitos inicializados; sem desenho |
| `loaded_modules` | `aiming` | 3 | 1 | Resolução por módulos carregados e contrato finito compatíveis |
| `finite_chain` | `aiming` | 5 | 3 | Contatos entre três bolas; dois estados de repouso e uma caçapa |
| `finite_rest` | `aiming` | 1 | 1 | Repouso da bola branca com fim projetado dentro da tela |
| `finite_moving` | `moving` | 0 | 0 | Dinâmica observada, previsão indisponível |
| `finite_unknown_power` | `not_ready` | 0 | 0 | Potência ausente permanece ausente; sem previsão |

Os números acima descrevem as saídas no momento da conferência. Nenhuma dessas fixtures é uma captura real da nova versão.

## Campos e relações conferidos

- `prediction.chainVersion == 2` e `prediction.model == "finite"`.
- `durationSeconds` entre 0 e 15 e `stepCount` entre 0 e 750.
- Quantidade de `finalStates` igual a `affectedBallCount`.
- Identidades finais únicas e pertencentes às bolas inicialmente ativas e não encaçapadas.
- Toda origem e todo alvo de segmento pertencem ao conjunto inicial válido; índices de evento ficam entre 1 e `prediction.events`.
- `timeSeconds` de cada segmento é não negativo e não excede a duração informada.
- Pontos de tela de segmentos e estados finais ficam dentro da largura/altura e têm profundidade positiva.
- Previsão incompleta não declara resultado `rest`; previsão completa não declara resultado `unknown`.
- Para estados finais conhecidos com segmento anterior, `world` e `screen` coincidem com o último ponto emitido para a mesma bola, dentro da tolerância nativa de 0,00001.
- Nas previsões disponíveis, todos os identificadores usados pelos segmentos aparecem em `finalStates`.
- Nas previsões disponíveis, `physics.available` é verdadeiro e cada bola ativa contém `velocity`, `angularVelocity`, `inertiaTensor`, `mass`, `drag` e `angularDrag`.
- As chaves observadas em `physics` pertencem à lista aceita, incluindo `materialSource` e `localTurn`; valores ausentes não foram substituídos por estimativas na conferência.

Nenhuma divergência foi encontrada nesses itens nas seis saídas verificadas.

## Verificações adicionais já realizadas

A sintaxe Bash de `scripts/test_billiards_live_snapshot.sh` e o bloco Python embutido foram conferidos. A extração dos helpers reais do Runtime inclui identificação do conjunto de bolas, repouso observado e turno conhecido. Os helpers numéricos e a implementação de `STBLResolution` permanecem iguais à base V3.18.1.

O teste Foundation foi ampliado para os contratos novos e antigos, os seis produtores acima, o limite de viewport que causou a falha da V3.18, campos inválidos, associação de identidades, giro residual, medição angular ausente e turno adversário. Esses casos estão conectados ao script de teste, porém **sua execução permanece pendente no macOS**.

## Reprodução no ambiente adequado

Na raiz `SDKtools`, executar em macOS com Foundation e Lua 5.3 disponíveis:

```bash
bash scripts/test_billiards_live_snapshot.sh
```

Esse comando gera novamente as seis saídas pelo produtor Lua, extrai os helpers reais do Runtime, compila o sanitizador e executa o teste Foundation. Seu resultado futuro deve ser registrado separadamente desta conferência local.

# V3.15 — leitura ao vivo e guia geométrica do bilhar

## O que a nova captura comprovou

A exportação V3.14 enviada em 16/10/2026 contém cinco bundles completos, cujo tamanho e SHA-256 foram conferidos. O catálogo local é revisão 1084, com `resourceGameId=20`. O CRes forneceu 259 TextAssets, incluindo a implementação Lua da partida, das bolas e da linha auxiliar. A extração parcial anterior descrevia principalmente a revisão 1047 embutida no IPA.

`20` identifica os recursos. O código Lua recuperado declara `Const.Billiard.GameType=1003` e `Enum.Billiard.GameType=1003`. Esses dois identificadores têm funções diferentes. Não foi comprovado um `sceneType` numérico da ponte Objective-C.

As evidências resumidas e seus hashes estão em `V3_15-evidence/`. Os fontes comerciais completos e o IPA não são necessários no pacote de compilação. Para continuar a análise em outra conta, anexar também a exportação original `SDKtools-BilliardsResources-AC462B8D-69E5-4AFB-8B7A-D88F64399A95.json` e o IPA base US 6.6.2/132.

## Caminho implementado

1. O controle Bilhar no menu inicia uma sessão de observação na thread principal.
2. `STBilliardsLuaBridge` localiza a UnityFramework já carregada e confere UUID, versão do aplicativo, exports, Lua 5.3 e XLua 105.
3. APIs exportadas do IL2CPP encontram `Main.dll`, `LuaManager`, o ancestral `MonoSingleton< LuaManager >` e o campo `_instance` existente. Não há offsets de objetos nem chamada ao getter que criaria o singleton.
4. A ponte lê `m_luaEnv` e entra em `luaLock` sem esperar. Confere `_ready`, `disposed` e `rawL` sob o lock. Os objetos gerenciados ficam protegidos por GCHandles apenas durante a chamada síncrona.
5. A rotina própria `billiards_probe.lua` é executada por chamada Lua protegida. Ela procura `Core.logicMgr:get(Enum.Billiard.Logic.frame)` e observa as instâncias vivas de `frame.balls`.
6. A rotina retorna um JSON limitado com cena, geração de sessão, frame, câmera, bolas, direção e segmentos projetados. A ponte restaura a pilha Lua e libera lock/handles em todos os caminhos normais e erros Lua protegidos.
7. `STBilliardsRuntime` valida os campos antes de desenhar. A camada visual recebe coordenadas de tela da câmera viva e não intercepta os toques.

O leitor não força a inicialização de classes, não cria outra VM, não anexa uma thread estranha e não executa código baixado. Executa apenas o recurso próprio incluído no framework, com os comandos fixos `sample` e `stop`.

O ARM64 do ramo base de `LuaManager.DoString` passa `env=NULL` para `LuaEnv.DoString`. `InitCore` e o carregador de minigames procuram `Core` em `_G` desse mesmo ambiente. Isso sustenta a escolha da raiz global. Métodos substituídos por hotfix e a presença atual de `Core`, `Const` e `Enum` ainda são conferidos em cada leitura; obter `rawL` sozinho não comprova uma partida de bilhar ativa.

## Identidade e unidades

| Campo | Significado confirmado |
| --- | --- |
| `ballTag=1` | Branca; número 0 no relatório |
| `ballTag=2..8` | Bolas numeradas 1..7 |
| `ballTag=9` | Preta, número 8 |
| `ballTag=10..16` | Bolas numeradas 9..15 |
| `transform.position` | Coordenadas de mundo; não dividir novamente por 10000 |
| `table_balls` da rede | Valores de rede passam por escala 10000 no código original |
| Plano da mesa | XZ; centro da bola em Y=0 na cena recuperada |
| Raio nominal | 0,165; o leitor deve conferir a geometria viva |
| Direção do taco | `(sin(ângulo), 0, cos(ângulo))`, em graus no código original |
| Projeção | `Camera.WorldToScreenPoint`; origem inferior esquerda em pixels Unity |

A UIKit inverte Y e escala para a superfície Unity observada. Não misturar coordenadas FairyGUI/GRoot com as coordenadas da janela. O tamanho ortográfico de câmera e os limites da mesa não são fixados a partir do cache.

## O que a guia calcula

São consultas geométricas independentes aos colisores da cena viva. A trajetória inicial acompanha o taco. O contato com borda usa a normal real retornada pelo SphereCast; a bola alvo e a branca recebem os dois ramos geométricos após o primeiro contato. Há limites explícitos de consultas, segmentos e rebotes.

As bocas da mesa têm curvas e aberturas: um retângulo ideal não representa a malha recuperada. Por isso a implementação usa os colisores reais, em vez de deduzir as bordas pelos pixels da captura.

Essa previsão não integra toda a física da tacada: efeito, arrasto, perda de energia, força, rolamento, pequenas correções do servidor e colisões posteriores entre bolas em movimento exigem validação adicional. A guia não executa tacadas e não garante encaçapamento ou posição final.

## Método que não deve ser usado como leitor

`AuxiliaryLineBehavior:updateAuxiliary()` escreve `reboundPos`, `reboundDir` e dados de mira. `BallBehavior:onCollisionEnter()` usa esses valores para corrigir posição e velocidade reais. Invocar esse método manualmente ou mudar `Const.HAS_*` alteraria a simulação.

A V3.15 mantém a previsão independente: não chama esse método, não muda as constantes de habilidades e não escreve Transform, Rigidbody ou resultados da partida. O único estado persistente Lua criado pertence ao namespace do próprio SDKtools.

## Estados e falhas

Os campos `status` e `prediction.reason` explicam por que um snapshot não pode produzir guia. A ausência de uma VM, cena, frame, câmera, bolas válidas ou turno adequado encerra o desenho; não autoriza fabricar posições. Bolas em movimento e snapshots vencidos retiram a previsão. Erros nativos têm códigos estáveis no domínio `SDKtools.BilliardsLua` e mensagens limitadas.

A exportação de diagnóstico deve ser feita com o bilhar carregado. Ela permite distinguir: ponte indisponível; contrato Lua diferente; jogo ainda carregando; cena incompatível; projeção inválida; bolas válidas mas previsão temporariamente bloqueada. A exportação de recursos da V3.14 permanece disponível para investigar uma revisão nova de assets.

## Validação ainda necessária no aparelho

O cache provou o caminho de código, mas não trouxe um frame de partida ativa. Os testes locais verificam contratos, geometria em mocks, descarte de dados inválidos e empacotamento. Compilação com o Apple SDK, assinatura e teste no iPhone são etapas separadas.

Na primeira execução, verificar o alinhamento dos marcadores com as bolas, a direção inicial ao girar o taco, o primeiro contato com uma bola, uma borda reta e uma boca de caçapa. Depois verificar limpeza ao iniciar a tacada, sair da partida, trocar de cena, girar o aparelho e ir ao fundo. Exportar o relatório se o estado não chegar à leitura válida ou se houver desalinhamento.

Crazy Alpaca conserva seus 13 arquivos centrais por SHA-256. Cartas continua desativado. Não reativar o trabalho de cartas como consequência desta investigação do bilhar.

# V3.15.1: correção do bloqueio no build

Versão 3.15.1, build 31. Base mantida: WePlay US 6.6.2/build 132.

## Falha observada

O log fornecido da execução 38920201770 termina com `FAIL overflow identity rejected` e `Billiards live snapshot: 319 checks, 1 failures`. O script para nesse teste Foundation, antes da compilação do framework iPhoneOS e da integração do IPA.

O teste anterior injeta `UINT64_MAX` em seis campos com a mesma mensagem. O log comprova uma aceitação indevida; não identifica o campo nem a implementação concreta do NSNumber. A hipótese mais forte é a conversão do inteiro unsigned extremo para um negativo aceito por `cameraInstanceId`. A confirmação exata desse comportamento do Foundation depende de uma execução Apple.

## Alteração aplicada

`STBLInteger` passou a consultar `objCType` antes de converter:

| Representação | Tratamento |
|---|---|
| Inteiro sem sinal | `unsignedLongLongValue`; conferir limites antes de converter para int64 |
| Inteiro com sinal | `longLongValue`; conferir limites sem passar por double |
| Float/double | Exigir valor finito e integral, conferir `[-2^63, 2^63)` antes do cast e depois os limites do campo |
| Booleano ou tipo desconhecido | Rejeitar |

Os IDs negativos reais de Unity continuam válidos. O limite superior exclusivo para double evita que `(double)INT64_MAX`, arredondado para 2^63, cause uma conversão fora do intervalo. Os três validadores ficam em `STBilliardsNumericPolicy.h`, usados pelo código de produção e pelo teste C.

Os testes Foundation mantêm o caso literal que falhou e acrescentam construção unsigned em execução, valor vindo de bytes JSON, limites int32, negativos válidos, frações e valores não finitos. Os rótulos agora identificam campo, valor e `objCType`. Uma leitura parcial não desenhável deve omitir IDs inválidos e manter seu motivo de indisponibilidade.

Não foi removida nenhuma verificação obrigatória. O novo teste C roda com sanitizadores de comportamento indefinido e conversão float/integer antes do teste Foundation no build.

## Verificação efetivamente realizada

| Verificação | Resultado |
|---|---|
| Núcleo numérico C usado em produção, GCC com sanitizadores | 55 verificações, zero falhas |
| Empacotamento e integração em fixtures | 28 testes, zero falhas |
| Regras de propriedades Objective-C | 9 testes, zero falhas |
| Revisão independente dos casts e includes | Sem bloqueios encontrados |
| Foundation desta revisão no macOS | Não executado neste ambiente |
| Framework iPhoneOS, IPA, assinatura e aparelho | Não executados nesta revisão |

A validação do par ZIP/workflow, CRC, manifesto e rejeição de pacotes antigos/corrompidos fica em `VALIDACAO_PACOTE.json` na entrega. Os registros antigos em Analysis/Validation foram preservados como histórico; seus resultados não são apresentados como execução desta revisão.

## Limites e preservação

Alpaca, os 11 recursos JavaScript e o leitor Lua do bilhar permanecem iguais à V3.15. Cartas continua desativado. Mudaram a validação numérica, seus testes, as versões exibidas/exportadas e os metadados de compilação/entrega.

A pendência conhecida das caçapas na camada 19 continua fora deste patch de build. O funcionamento e o alinhamento da guia no aparelho ainda exigem confirmação.

## Nova execução

Substituir juntos `SDKtools_Fontes.zip` e `.github/workflows/compilar.yml`, fazer commit e iniciar uma nova execução de **Compilar SDKtools US**. Usar `base_source=release` e `release_tag=base-us-6.6.2`. O resultado esperado, somente após os testes e build passarem, é `WePlay_US_6.6.2_SDKtools_v3_15_1_unsigned.ipa`.

Reexecutar o job anterior usa os fontes daquele commit. Esta entrega contém fontes e workflow, não um IPA compilado.

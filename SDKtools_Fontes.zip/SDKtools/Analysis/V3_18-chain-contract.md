# V3.18 — contrato da previsão em sequência

## Evidências e origem

Base funcional: V3.17/build33, WePlay US6.6.2/build132, resourceGameId=20 e GameType=1003.

A captura de mira contém 118 amostras aiming entre 120 retidas, com 16 bolas. Em 86, a linha da bola número13 termina a aproximadamente 0,33 unidade do centro da14, sem continuação. A captura de movimento contém 65 amostras moving e 55 not_ready; 312 anteriores foram omitidas. Não preservou mira ou primeiro choque da tacada.

Hashes e contagens estão em V3_18-capture-audit.json e V3_18-capture-findings.md. O fixture Tests/fixtures/billiards-chain-v317-captured.json extrai o layout de samples[119] da primeira captura. O ambiente de teste é sintético e valida apenas os contatos iniciais tags1→14→15 (números0→13→14).

## Caminho mantido

A ponte ARM64 chama o observador no estado Lua existente. Ele verifica cena, resolve Enum/Const globais ou os dois módulos canônicos em package.loaded, passa o descritor original ao gerenciador e adquire frame/câmera/bolas/mira. Aquisição até a entrada da física e inspetor/resolvedor permanecem iguais à V3.17.

Não há chamadas require/Init, descritores fabricados ou troca automática de ambiente. O código de manager:get não foi recuperado; seus efeitos internos são desconhecidos. O diagnóstico de resolução não autoriza desenho sozinho.

## Simulação temporária

Cada bola ativa e não encaçapada recebe tag, raio e posição em uma tabela temporária. A branca começa com a direção normalizada da mira; as demais começam paradas. Nenhuma posição, velocidade, Rigidbody ou Transform do jogo é escrito.

O ciclo seleciona o evento mais próximo entre contatos bola–bola, calculados com posições e velocidades relativas, e contatos com a mesa por SphereCastAll. Todas as bolas previstas avançam até o mesmo instante. Uma colisão transfere a componente normal da velocidade relativa entre massas iguais. Um rebate reflete a velocidade na normal da tabela.

O cache de ambiente guarda instantes absolutos no relógio comum e só é invalidado quando a velocidade daquela bola muda. Após uma tabela, a consulta avança 0,0005 na direção refletida; esse deslocamento entra novamente na distância temporal. Todas as bolas Unity mapeadas são ignoradas nas consultas de ambiente: seus contatos são calculados nas posições futuras, evitando usar colliders em posições antigas.

Velocidades e horizonte são normalizados; não representam força real ou segundos.

## Mesa, caçapas e contatos incertos

A máscara 524289 inclui camadas0 e19. O contrato recuperado coloca caçapas e canvas na19. O classificador ignora canvas e triggers desconhecidos; reconhece bumpers/tag bumper e as caçapas potUpLeft, potUpRight, potUpCenter, potDownLeft, potDownRight, potDownCenter.

Physics.queriesHitTriggers é apenas lido. Quando falso, usa-se a sobrecarga QueryTriggerInteraction.Collide; ausência dela encerra com motivo explícito.

Uma consulta iniciada sobreposta a uma tabela encerra como environment_overlap, porque a normal de sobreposição não serve para esse rebate. Normais diferentes igualmente próximas e contatos simultâneos compartilhando uma bola encerram como simultaneous_contacts, sem ordem arbitrária de impulsos.

Referência da API: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/physics/spherecastall . Essa referência não substitui a validação dos overloads disponíveis no Unity/xLua do aplicativo.

## Limites

| Recurso | Teto |
|---|---:|
| Bolas |16|
| Eventos |64|
| Consultas Unity |96|
| Hits por consulta |96|
| Segmentos |48|
| Reflexões por bola |6|
| Distância por consulta |20 unidades do mundo|
| Horizonte normalizado |40|

Um limite encerra a previsão inteira; nenhuma bola é congelada enquanto outras continuam contra uma posição incorreta. Trechos já percorridos e limitados por geometria conhecida são preservados. Uma consulta vazia não autoriza uma linha arbitrária de20 unidades.

Motivos parciais incluem bounce_limit, segment_limit, event_limit, query_limit, horizon_limit, open_path_unknown, simultaneous_contacts, environment_overlap, overlapping_ball_geometry e degenerate_ball_contact. Geometria não classificada encontrada depois de um trecho válido pode manter esse trecho. Falhas de consulta/projeção ou dados inválidos podem invalidar toda a guia.

## Lua → Foundation

prediction.model permanece geometric; prediction.chainVersion=1 identifica o novo contrato.

| Campo | Validação |
|---|---|
| events, collisions, bounces |Inteiros0..64|
| queries |Inteiro0..96|
| affectedBallCount |Inteiro0..16|
| maxBounces |Inteiro0..6|
| truncated |Booleano JSON real|
| segments |Até48 itens|
| ballTag |Inteiro1..16; bola ativa e não encaçapada no mesmo snapshot|
| eventIndex |Inteiro1..64, não maior que prediction.events|
| terminal |ball, cushion, pocket, horizon ou limit|
| hitBallTag |Obrigatório apenas em terminal=ball; outra bola ativa do snapshot|

worldFrom/worldTo e from/to representam centros de bola. kind continua cue/object/rebound. eventIndex indica quando o trecho terminou e pode aparecer fora de ordem na lista ao descarregar ramos pendentes; não se deve inferir cronologia pela ordem no array.

Todos os retornos, inclusive moving/erro, inicializam os campos de cadeia. Metadados presentes mas inválidos não podem recuar para o contrato legado. Sem chainVersion, continuam os limites legados de12 segmentos/3 rebates. As verificações de viewport, estado, câmera, atualidade, identidade e números permanecem obrigatórias. Contadores não autorizam desenho.

## Renderização

STBilliardsGuideDrawing usa a projeção e o retângulo da view já selecionados pelo Runtime. A branca tem linha branca; outras cores são uma paleta estável por número, não cores lidas de texturas. Rebates mantêm a cor da bola.

Há contorno escuro, setas, redução suave de opacidade nos eventos posteriores e círculos do centro previsto em terminal=ball. Bolas envolvidas recebem anel e número; outras recebem anel discreto. O desenho é recortado à view e limitado a48 segmentos/16 bolas. Guias legadas sem tag mantêm cores por kind.

A captura enviada mostra WePlay; não há referência visual do SDKPool para equivalência exata.

## Exportação

STBilliardsRuntime guarda a última mira válida. No primeiro moving subsequente, associa os registros somente se sessionId, cameraInstanceId e scene coincidirem e o intervalo estiver entre0 e1000ms. A referência pendente é consumida; o último par fica em lastAimBeforeMotion, com association=same_context_next_motion.

Isso indica observação próxima no tempo, não comprova comando de tacada ou acerto. Ainda não há identificador independente de sala/rodada. Um par anterior pode continuar no relatório se nenhum novo par válido foi observado; elapsedMs e identificadores permitem distingui-lo.

STBilliardsEncodeCapture recebe o relatório sanitizado e limita o JSON a4194304 bytes. Uma busca binária retém o maior sufixo de até120 amostras que cabe. lastSnapshot e lastAimBeforeMotion permanecem. Descartes são somados a omittedOlderSamples e registrados em exportTrimmedSamples. Se a parte fixa sozinha exceder o teto, retorna erro.

## Validação e próximo passo

Passaram55 testes Lua,28 de empacotamento e9 de propriedades Objective-C. O fixture capturado reproduz os primeiros contatos dentro de0,002 unidade do mundo dos pontos exportados pela V3.17. Os demais casos cobrem cadeias, cortes, movimento relativo, rebates, caçapas, caches, colliders obsoletos, contatos ambíguos e limites.

O harness Foundation recebe saídas reais do produtor Lua nos cenários env_distinct, loaded_modules e chain_three_balls, além dos casos de sanitização e exportação. Está ligado ao build macOS, não executado neste Linux. O renderer UIKit depende também do build Apple.

Falta compilar com SDK Apple, instalar V3.18, conferir o visual pré-tacada e caçapas, comparar a cadeia com movimento real e medir o custo dos96 casts máximos. A geometria não inclui força, atrito, spin ou correções específicas do jogo; não promete posições finais.

Alpaca e recursos JavaScript foram preservados. Cartas permanece desativado.

# Alteração local — previsão de Win e ponto de trava

## O que aparece

Ao identificar o Alpaca com licença ativa, o SDK inicia uma leitura **sem ações**,
independente de Auto, Raio X e LAN. Depois do snapshot completo e estável, mostra
um HUD que não intercepta toques, além do detalhe no menu Alpaca:

- **Win local**, de 0 a 100%, distinguindo prova, cálculo e estimativa;
- melhor rota encontrada: porcentagem de cartas eliminadas e capturas realizadas;
- cartas restantes, ocupação da bandeja e motivo de parada;
- pares expostos na mesa/reserva, somados às cartas já na bandeja.

O Alpaca elimina **trios**. Um par visível não garante uma jogada: o terceiro
elemento pode estar coberto, inacessível ou exigir mais espaço que o disponível.
As reservas usam as dependências de `storage_info`, não apenas a máscara visual.

As capturas e o avanço são **simulados a partir da mesa atual**, não jogadas já
enviadas nem o progresso histórico da partida. “Melhor rota” significa o melhor
terminal encontrado na análise; uma busca/amostragem limitada não prova o máximo.
O avanço conta somente cartas eliminadas por trios, não cartas ainda na bandeja.

## Significado da taxa

**Não é taxa histórica de vitória do jogador, probabilidade calibrada do Auto ou
confirmação de vitória pelo servidor.** É a chance de limpar as cartas carregadas
no modelo local, sem poderes, ajuda de aliados, armazém compartilhado ou cartas
futuras. Uma missão diferente de limpar a mesa não é avaliada como objetivo.
O indicador não muda o planejador nem envia a rota simulada.

O modelo sorteia entre escolhas legais, favorecendo completar um trio (peso 6),
formar um par na bandeja (3) e as demais escolhas (1). Todos os caminhos legais
têm peso positivo. Só são consideradas cartas livres dos bloqueios, respeitando
sete espaços: a última posição precisa completar um trio. Retirar uma carta
libera as cartas normais que ela cobre; regras especiais desconhecidas invalidam
o modelo em vez de serem inventadas.

- Até 22 cartas fora da bandeja: busca exata, resumível, com memoização e limite
  de 2.048 estados gerados. Se terminar, calcula a probabilidade ponderada exata.
- Acima desse tamanho, ou ao atingir o limite: 128 simulações completas, com
  PRNG determinístico para o mesmo snapshot. A estimativa suavizada é
  `100 * (vitórias + 0,5) / (simulações + 1)`, para não tratar ausência de vitórias
  na amostra como impossibilidade. O HUD usa `<1%` e `>99%` perto dos extremos.
- **0% comprovado no modelo**: quantidades por tipo incompatíveis com trios,
  estado terminal sem continuidade legal, ou busca exata sem qualquer vitória.
- **100% comprovado no modelo**: busca exata em que todas as continuações legais
  consideradas limpam a mesa, inclusive mesa já vazia. Encontrar uma única rota
  vencedora ou vencer todas as amostras não autoriza exibir 100% garantido.

Exemplo: sete tipos diferentes expostos, com todas as cartas correspondentes
dependendo da retirada desses sete bloqueadores. A bandeja permite seis capturas
sem eliminar trio; a sétima não cabe com segurança. O modelo prova 0% e indica
seis capturas, zero cartas eliminadas e seis posições ocupadas na parada.

## Integração e limites

- `Resources/alpaca_win.js`: factory independente, somente leitura, até 512 cartas,
  orçamento-alvo de 2 ms e 256 passos por chamada; cache por snapshot e geometria.
- `autoplay_tool.js`: analisa somente snapshots válidos, sem requisição pendente.
  Leituras interrompidas/instáveis apagam a porcentagem visível. Bandeja cheia é
  observável pelo leitor de fase, mas continua bloqueada para qualquer captura.
- `STWebProbe.m` / `STAutoplayBridge.inc`: carregam a décima factory e passam a
  opção licenciada no bootstrap e no hot path; não alteram `allowAction`.
- `STAutoplayRecorder.inc`: polling passivo limitado a 5 Hz, separado da intenção
  de Play; resultado sanitizado em `winAnalysis` e ocultação de leituras antigas.
- `STOverlay.m`: habilita o observador apenas no Alpaca visível/autorizado e
  mostra o HUD quando o menu está fechado. Nenhum listener de toque novo.
- `STAutoplaySanitizer.inc`: campos fechados, números finitos e limitados; não
  exporta IDs, nós, rotas, socket ou dados do jogador. Preserva o diagnóstico nos
  relatórios de leitura. Revogação de licença desativa a observação.
- Traduções PT/EN e recurso obrigatório no build/integrador incluídos.

Cartas especiais, reserva sem ordem verificável, controles incoerentes, leitura
parcial, carregamento, animações e pendências mostram **—**, nunca um falso 0%.
O orçamento não é garantia de tempo real no iPhone. As simulações podem precisar
de vários ciclos; a taxa parcial é marcada como “calculando”.

## Verificação

`Tests/alpaca_win.test.cjs` verifica provas de 0/100%, pares sem trio, cobertura,
reserva, última posição da bandeja, dados inválidos, cache, amostragem sem falsa
certeza, 510 cartas e comparação com enumerador independente em grafos pequenos.
`Tests/autoplay_tool.test.cjs` executa as factories e os templates reais da ponte,
incluindo modo passivo, solo/equipe, bandeja cheia e preservação de pendências.
`Tests/test_alpaca_win_contract.py` verifica a integração nativa portátil.

Os testes Foundation em `autoplay_bridge_test.m` e `autoplay_lifecycle_test.m`
incluem a fronteira real e a nova factory; **exigem macOS para executar**.
Compilação Apple, assinatura do IPA e conferência visual/funcional no iPhone
continuam pendentes. Esta alteração local não muda a identidade 4.0.9/build84
nem modifica o ZIP original; um novo pacote deve ser gerado após os testes.

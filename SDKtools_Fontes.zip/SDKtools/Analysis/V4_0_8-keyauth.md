# KeyAuth — V4.0.8/build83

Cliente1.3 nativo Objective-C/Foundation, config pública Weplaysdk/Jdh0dfFTTT/1.0.
POST HTTPS somente keyauth.win/api/1.3, sessãoefêmera sem cookies/cache/redirects,
limite64KiB antes deacumular. Callback/delegate nomain para cancelamento serializado.
Verifica Ed25519 sobre timestampUTF8+corpooriginal antes doJSON, pk pública oficial,
janela simétrica±120s seguindo SDKC++1.3; semHMACsecret/nonceecho inventado. CryptoKit
do sistema usa única ponteSwift C, deployment15; restante permaneceObjective-C.

Somente success booleano verdadeiro e assinatura/owner/estrutura/expiração aceitos.
Sessão emmemória, lease online90s/check30s/foreground; timer deexpiração permanece
mesmo no check emvoo. Callback geração antiga não altera autorização. Rede falha
mantém chave/retry; negativa assinada requerretry/foreground, semofflineunlock.

KeychainGenericPassword, semsynchronização, WhenUnlockedThisDeviceOnly, serviço
próprio, contaslicense/installation. UUID aleatório só publicado após persistir ou
validar leitura; nãoéUDID/UIDWePlay. Removerchave não rotacionaUUID. Salva chave
somente apósvalidação; falha deescrita impedeativação. Nenhuma chave/sessionID/UUID
vai paralogs/LAN/exports. UIlimpa securefield e restaura janela host aoencerrar.

Guarda emcoordenadores ebridges bloqueia novasaçõesdeAlpaca/Cartas/Bilhar/LAN e
capturas/exports. Semguarda emrecepção de callbacks. Revogação usa geração deexport
própria, conservando actionContextGeneration/latches; pollingserial/powers continua
read-only a≤10Hz. Bilhar desarma diretamentee usaLua suspend, não stop queapagaria
pending. ReplayKit termina inclusive se revogado duranteStarting. Revalidar licença
não rearmaAuto. Arquivos anteriores nãosão apagados.

Validação dirigida: fixtureKeychain emmemória +respostasassinadasRFC8032fake; startup
automático, trocar/removerkey, rejeição/expiração, escrita/leiturafalhas, callbackantigo,
heartbeatpendenteexpirado, bytes adulterados, timestamps passados/futuros, transporte
bounded/redirect. Cripto24checks RFC/byte/limite. Licença real nãoéembutida nem criada
nestes testes. Inicialização real fornecida aceitouappconfig comassinaturaválida,
em recuperacao/keyauth-init-check.json; sessão não foi salva. ACIApple posterior
e entrega ficam registradas emCONTEXTO.md, semalterar oZIPjácompilado.

Limites: assinatura pode deixarKeychain inacessível ao trocarTeamID/grupo; conexão
é necessária para revalidar. Serviço élicenciamento, não proteção inviolável contra
patch local. KeyAuth pode rotacionarchavepública ou mudarprotocolo, exigindoatualização.
Cadastro/configurações administrativas, emissão/chaveválidareal e aparelho nãoforam
modificados/testados. Semgarantia deprecisão0,05ms, taxa devitória ou ausência debugs.

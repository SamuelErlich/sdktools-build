# V3.6 — análise dos dois relatórios V3.5.1

**Nenhuma carta foi capturada.** Os 220 registros aceitos são tentativas de avaliação que falharam, e não leituras válidas de cartas. A falha ocorre antes da análise de frente, verso ou valores de componentes.

| Evidência | Capturando cartas | Ganhei o jogo |
|---|---:|---:|
| Versão SDKtools | 3.5.1 | 3.5.1 |
| Duração | 50,82 s | 59,56 s |
| `webSamples` | 101 | 119 |
| `evaluation_failed` | 101 | 119 |
| Investigação `unavailable/probe_result_unavailable` | 101 | 119 |
| Cartas/componentes/frames observados | 0 | 0 |
| Cenas full/delta/reference | 0 / 0 / 0 | 0 / 0 / 0 |
| Tempo médio da avaliação | 8,18 ms | 9,14 ms |
| Tempo máximo da avaliação | 40,72 ms | 31,44 ms |
| Snapshots nativos / registros de toque | 55 / 4 | 66 / 6 |

Ambos confirmam nativamente `gameType=2007`, controlador `WPCocosGameViewController`, app US 6.6.2/132. Todos os documentos amostrados são `file:` e `loading=false`. Porém o engine permanece `pending_scene_probe`, com `sceneReadSupported=false`: estes relatórios não reconfirmam a versão do Cocos nem demonstram o estado do tabuleiro.

O decoder existente aceitou os dois relatórios como schema 3, com 101 e 119 amostras `nonScene`, máximo de zero nós e nenhuma cadeia de dependência. Não existe conteúdo de cena comprimido escondido nos deltas.

## Campos, transições e omissões

Cada `cardInvestigation.observation` contém somente `version`, `status` e `reason`. Não há `cards`, `nodes`, `components`, `frontActive`, `backActive`, `sceneEpoch`, frames ou valores por carta. Nenhuma identidade oculta foi efetivamente capturada; também não é possível concluir que os objetos do jogo não possuam tais dados.

As sequências são contínuas, 1–101 e 1–119. As avaliações foram concluídas aproximadamente a 2 Hz, sem timeout registrado, sem descarte de cauda na exportação e sem truncação de cena. Como todas falharam, `truncated=0` não significa cobertura completa do tabuleiro.

Os contadores nativos de omissão são `outsideConfirmedGame=4`/`sdktoolsOverlay=4` no primeiro arquivo e `outsideConfirmedGame=6`/`sdktoolsOverlay=23` no segundo. Eles representam exclusões do escopo de captura nativa; não explicam a ausência de dados JavaScript de todas as cartas.

O histórico de “Ver cartas” é explicitamente das últimas mudanças **no processo**, não apenas desta sessão. O segundo relatório contém um evento próprio do renderer com `waiting/no_verified_cards/shown=0`, seguido de desativação. Isso não é uma leitura bem-sucedida da investigação e não deve ser usado como prova de ausência de frentes no jogo. O nome “ganhei o jogo” é a descrição do arquivo enviado; o resultado da partida não pôde ser verificado por dados de cartas neste relatório.

Ambos registram exportação JavaScript com `status=exported`, `lastErrorCode=0` e `nativePathStatus=native_getter_unverified_for_game`. Esse último valor informa que o getter não comprovado de 2007 foi evitado; não é erro da exportação. Os arquivos de captura não contêm o conteúdo da exportação JavaScript nem o caminho local.

## Defeito de contrato reproduzido na V3.5.1

Foi inspecionado o código próprio do SDKtools, sem executar fontes comerciais:

- `scene_probe.js` é uma expressão imediatamente invocada, terminando em `}())`, e já retorna a função de captura.
- `card_probe.js` termina em `})`: é a factory, que ainda precisa ser invocada para obter a função de captura.
- `STWPCardInvestigationCaptureScript` insere ambos diretamente em `capture:(...)` e `cardProbe:(...)`.
- Assim, `s.cardProbe()` devolve uma **função**, que é atribuída a `out.cardInvestigation`, em vez de devolver o objeto do diagnóstico.

`reproduce-v351-bridge.cjs` executa o wrapper real e os dois resources reais do SDKtools em um ambiente vazio, por dois ticks. O resultado de produção contém `typeof cardInvestigation === 'function'`; uma serialização JSON omite essa propriedade. Invocar a factory apenas no diagnóstico produz um objeto normal. A reprodução não modifica produção e não usa Cocos nem código do jogo.

Esse resultado inválido para a ponte JavaScript/nativa é compatível com as 220 falhas rápidas do `WKWebView`. O código/domínio exato do `NSError` não foi preservado nos relatórios, portanto a reprodução não afirma ter obtido o mesmo número de erro WebKit.

O teste antigo do bridge usava um `cards` sintético já terminado em `})()`, diferente do resource real. Por isso passou mesmo com o contrato de produção incorreto. O teste isolado do probe também invocava a factory corretamente e não cobria essa composição.

## Verificação focalizada necessária na correção

Carregar os resources reais no wrapper real em um teste de integração; verificar resultado profundamente serializável, objeto `cardInvestigation`, contexto constante, múltiplas amostras, fallback de resource ausente e troca de documento. Preservar a distinção entre erro da avaliação e uma captura válida sem cartas. Um diagnóstico limitado de domínio/código de erro permite distinguir falha de execução de falha de transporte, sem exportar mensagem arbitrária, URL, query ou texto privado.

A próxima análise de identidade deve usar uma captura que contenha efetivamente cartas e transições. Estes dois relatórios sustentam corrigir a ponte, não deduzir valores de cartas ocultas.

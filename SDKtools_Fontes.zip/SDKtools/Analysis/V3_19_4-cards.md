# V3.19.4 / build 40 — Cartas reativado sobre V3.19.3

Base recebida: SDKtools_V3_19_3_US_Correcao_Empacotamento.zip.
SHA-256 do pacote base: 693eda3b704c89d24cc22fbfaf41fb57dd085440dd2d4a9c5755ca321186c959.
SHA-256 dos fontes base: e0145ed1eac1bb30631796689a5d59445419f77725b9a79b0c0f1ba2bd30bb8e.

O pedido atual reativa Cartas; a indicação de pausa nos documentos de continuidade é histórica, não uma instrução para manter a pausa.

## Alterações

- Cartas/gameType 2007 habilitado por padrão, com opt-out explícito de compilação para a regressão desativada.
- Hooks de ciclo de vida tipados: setupWKWebView retorna void; loadCurrentGame retorna BOOL. Preservados seletor, receptor, chamada única e retorno original.
- Restauração de cada hook com seu encoding original, sem substituir o ABI BOOL por void.
- Controles de captura desde a entrada, histórico de argumentos de cor, marcadores atuais e exportação no menu.
- Proteção do menu contra iniciar Bilhar com captura/marcadores de Cartas ativos ou operação de marcadores pendente.
- Histórico limitado e identificado como histórico, sem afirmar confirmação de textura ou conhecimento de cartas ocultas.
- Booleano nativo de cauda exportado corretamente; aceitação offline restrita ao 0/1 histórico desse campo.
- Testes da política padrão ativa, opção desativada, renderer ativo, hooks tipados e feed incluídos no build.

## Preservação

Nenhuma mudança de física, geometria, mira, previsão, movimento, Lua ou parâmetros de Bilhar. A correção de empacotamento Lua de até 128 KiB permanece. Arquivos dedicados de Bilhar só recebem atualização textual de versão nos dois emissores de relatório e no teste correspondente; o restante permanece byte a byte.

Os scripts JavaScript de Alpaca e de Cartas são preservados byte a byte. Não há novo código de descoberta de cores por ID, chamada de gameplay ou relaxamento dos guardas de desconhecido/indisponível.

## Limites deliberados

- Captura e marcadores continuam sendo modos separados. Esta atualização não remove o mutex nem promete gravação e marcadores simultâneos.
- A captura observa argumentos de renderização; isso não é prova de textura aplicada. O contrato assíncrono do jogo ainda exige verificação real.
- Marcadores verificam arte atual ou um vínculo atual forte com o modelo; informação ausente permanece desconhecida.
- A paleta indica categorias de cor, não RGB exato da tela.
- Build aprovado não equivale a validação no aparelho. Assinatura e instalação são etapas externas.

## Validação no iPhone

1. Confirmar V3.19.4 e os três módulos no menu.
2. No lobby, armar Capturar Cartas desde a entrada, entrar em Ah, minha carta e exportar após parar ou completar 90 s.
3. Separadamente, já na partida, ativar marcadores. Conferir as quatro cores, especiais, cartas desconhecidas e reorganização da mão.
4. Sair, reentrar, alternar rodada e colocar o app em background: nenhum marcador antigo pode permanecer.
5. Desativar Cartas antes de testar Alpaca/Bilhar e conferir que o comportamento aprovado da 3.19.3 permanece.
6. Enviar JSON e vídeo sincronizados caso haja cor errada, marcador deslocado ou informação indisponível inesperada.

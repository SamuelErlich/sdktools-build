# SDKtools V3.1: regras confirmadas no JavaScript original

O arquivo `assets/main/index.js` exportado contém 3.641.464 bytes, SHA-256 `cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`. A análise foi estática, com leitura, extração literal e hashes em Python. REA MCP/CLI não estavam disponíveis. O código original não foi executado.

O JSON acompanhante registra 31 trechos com offsets em bytes UTF-8, fim exclusivo e SHA-256. O pacote inclui somente estas conclusões e referências; os arquivos originais e seus trechos ficaram fora da distribuição.

| Questão | Regra encontrada | Consequência para SDKtools |
| --- | --- | --- |
| Cobertura | `PileArea.calculateBlockIsOver` exige outra carta com `layer` maior e diferenças nas coordenadas do ID menores que 16 e 20. | Ordem dos filhos/renderização não substitui a camada original. Cartas da mesma camada não se cobrem por essa regra. |
| Posição | A mesa usa `row`/`col`, grade 16×20 e dimensões atuais de `AreaNode`; cartas têm 80×90. | Conferir dados e posição na mesma leitura. Na mesa observada de 560×720, os fatores são 5 e 4,5 unidades. |
| Trio | A barra agrupa tipos; a primeira sequência de três `type` iguais é removida depois da chegada. | Planejar a sequência inteira, considerando os tipos que já ocupam a barra. Aparência semelhante não substitui o tipo numérico. |
| Capacidade | O próximo toque normal exige menos de sete cartas na barra. | A sétima carta pode completar um trio; sete cartas persistentes impedem novo toque normal. |
| Diamante | É o tipo 1 entre 16 tipos comuns. | Não há ramo que o transforme em curinga na combinação normal. |
| Especiais | `special_info.type != 0` identifica uma especial; `lock_state != 0` impede o toque. | Não presumir desbloqueios futuros que dependem de atualizações externas. |
| Especial desbloqueada | `Block.SetSpecialInfo` remove o `SpecialNode` após uma animação de 0,1 s quando o bloqueio chega a zero. | A carta válida passa de cinco para quatro filhos. Reconhecer os componentes por suas referências preserva sua leitura após o desbloqueio. |
| Reserva | `storage_blocks` é uma matriz com `storage_info.layer/index`; posição vertical é `7*layer`. | Largura configurada de três posições não prova limite total de três cartas. |
| Movimento | A carta sai da coleção, passa por `OperateLayer`, anima por 0,25 s e só então entra no destino. | Aumentar a frequência de leitura não elimina a necessidade de confirmar a chegada. |
| Próxima fase | `IncreaseLevel` sincroniza os novos dados e repovoa as mesmas áreas, depois de uma espera de 800 ms. | A identidade do container pode permanecer igual quando a mesa inteira muda. |
| Resultado | Vitória/derrota usam os estados recebidos em `GameOver` e `UpdateRemoveProgress`. | Uma rota que limpa a mesa atual não garante resultado de futuras fases ou do servidor. |

## Camadas do raio X

A profundidade visual pode ser calculada a partir do grafo de cobertura: cartas livres recebem profundidade zero; uma carta coberta recebe um mais a maior profundidade dos seus bloqueadores. Os filtros de 1 a 5 devem usar essa convenção de forma consistente. Essa profundidade não é o número literal de `blockInfo.layer`, e o código analisado não estabelece um limite de cinco camadas para o jogo.

## Planejamento até limpar a mesa

O objetivo verificável é esvaziar todas as cartas do estado atual completamente lido e sua barra, respeitando cobertura, bloqueios e capacidade. Encontrar o primeiro trio não demonstra que o restante terá solução. Esgotar o tempo de busca também não demonstra que não existe solução.

Após cada jogada, o estado observado precisa coincidir com o previsto. Embaralhamento, efeitos de alpaca, ações cooperativas, cartas especiais e novas fases podem alterar a mesa independentemente do plano. Uma diferença exige nova leitura e novo planejamento. O resultado deve distinguir rota completa, busca ainda sem conclusão e estado não suportado.

## Limites e anomalia encontrada

`StorageArea.updateRound` contém um callback de `findIndex` sem `return`. Pela semântica comum de JavaScript, esse callback devolve `undefined`, e aquela busca não encontra cobertura na reserva. Isso descreve o texto exportado; não comprova a regra pretendida. O adaptador deve conferir o botão e a máscara reais, sem inventar bloqueio entre cartas da reserva.

Os modos de enviar carta ao armazém e de usar Penetrate mudam o destino do mesmo callback de carta. O modo de seleção HotTime também interrompe o toque normal. A leitura precisa respeitar esses estados; uma carta aparentemente habilitada não basta para identificar uma jogada normal.

Nenhum método de autorização, estoque, bloqueio ou resultado recebido foi sobrescrito neste trabalho. Os hashes e trechos comprovam o código lido, não uma nova execução no iPhone nem equivalência com toda a lógica do servidor.

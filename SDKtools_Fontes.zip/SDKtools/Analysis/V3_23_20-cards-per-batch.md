# Cartas por vez — 3.23.20 / build 70

A seleção 1/2/3 fica abaixo do Auto no menu do Alpaca, com botões de 44 pt,
seleção laranja, fundo escuro, tradução PT/EN e estado selecionado acessível.
Padrão 1, salvo em SDKtools.autoplayCardsPerBatch. A preferência não inicia
jogadas nem libera pendências. Super Fast controla a cadência; o novo seletor
controla o tamanho máximo do grupo.

O bridge fornece cardsPerBatch explicitamente tanto na inicialização como no
caminho rápido. O bloqueio nativo provisório de envios múltiplos depende da
quantidade >1, mesmo com Super Fast desligado. Mudanças de quantidade não
apagam a avaliação em andamento nem sua confirmação.

O JavaScript valida a rota inteira que completa o trio e o espaço da bandeja
antes de enviar um prefixo limitado. O observador existente confirma somente
as cartas realmente enviadas, com respostas originais e estado exato da mesa.
Pausa, mesa de aliados, contexto inválido e transporte incompatível preservam
seus bloqueios e a compatibilidade serial existentes. Não há chamada direta
nova de protocolo nem promessa de simultaneidade ou aceitação pelo servidor.

Base: 3.23.19/build 69, commit local
56eec84dbe664469e1514d7d24340d63388e62ec.
A entrada do integrador continua sendo WePlay_US_6.6.2_base.ipa, da Release
base-us-6.6.2. Resultados em Validation/V3_23_20-validation.json.
Compilação Foundation/UIKit/iPhoneOS e teste físico dependem do Actions macOS
e de um iPhone; não foram executados neste ambiente Linux.

# SDKtools 2.8.1 — correção do build macOS

O log fornecido pelo usuário, referente à execução 38654565542 / job 116161152246, mostra que o processo parou ao compilar `Tests/game_source_io_test.c`. O framework iOS ainda não havia sido compilado.

## Evidência

Ambiente informado no log: Xcode 16.4, build 16F6, iPhoneOS SDK 18.5. Antes da falha, passaram 50 testes Python, 200 testes JavaScript e 37 verificações da política nativa. A etapa seguinte produziu 12 erros relacionados a `O_NOFOLLOW`, `st_mtimespec`, `st_ctimespec` e `mkdtemp`.

Arquivo recebido: `sdktools-build.log`, 56.278 bytes, SHA-256 `e9bf68d92b2306c0d65527a3a4846d54c60bde49923cc5138dc2c417a21aac8b`. O log completo não foi incluído no pacote.

## Causa e alteração

O teste definia `_POSIX_C_SOURCE=200809L` incondicionalmente antes dos headers. Nos headers Darwin, essa seleção restringe as declarações expostas. Os campos de tempo e a opção de abertura usados pelo leitor compartilhado precisam das extensões Darwin.

A 2.8.1 seleciona `_DARWIN_C_SOURCE=1` em plataformas Apple e conserva `_POSIX_C_SOURCE=200809L` nas demais. A seleção ocorre antes de qualquer include. Não foram inventados valores de flags, removidas verificações de links ou trocadas as comparações de nanossegundos por comparações menos precisas. O teste continua sendo compilado como C11, com `-Wall -Wextra -Werror`.

O código de leitura `STGameSourceIO.h`, os recursos JavaScript e o comportamento dos poderes/armazéns permanecem os da V2.8. Os identificadores de versão, o integrador e o par ZIP/workflow foram atualizados para 2.8.1, build 11. O relatório de captura também passa a identificar corretamente `toolVersion=2.8.1`; antes, mantinha um identificador antigo.

## Validação e próxima execução

Os resultados locais e os hashes finais constam em `Validation/V2_8_1-validation.json` e `VALIDACAO_PACOTE.json`. O teste C recompila e executa o mesmo leitor utilizado pelo exportador, com 70 verificações. A revisão dos headers Apple confirma a seleção de declarações aplicada; isso não substitui uma execução no SDK Apple.

Este pacote foi preparado em Linux. A nova execução do Actions precisa confirmar a compilação do teste C no macOS, os testes Foundation e a compilação/linkagem do framework iOS. O log recebido comprova o resultado da V2.8 anterior, não uma compilação da 2.8.1.

No repositório, substituir juntos `SDKtools_Fontes.zip` e `.github/workflows/compilar.yml`, fazer commit e iniciar uma nova execução por **Run workflow**. Reexecutar o job antigo pode reutilizar o commit anterior. Usar a Release `base-us-6.6.2` e o IPA base já definido. O artefato esperado ao concluir é `SDKtools-v2.8.1-US-IPA`.

## Fontes primárias conferidas

- Apple, seleção do namespace Darwin: https://github.com/apple/darwin-xnu/blob/main/bsd/sys/cdefs.h
- Apple, condição que expõe `O_NOFOLLOW`: https://github.com/apple/darwin-xnu/blob/main/bsd/sys/fcntl.h
- Apple, condição dos campos `st_mtimespec` e `st_ctimespec`: https://github.com/apple/darwin-xnu/blob/main/bsd/sys/stat.h
- Apple, declaração de `mkdtemp`: https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man3/mktemp.3.html

O repositório `apple/darwin-xnu` é uma referência oficial arquivada. A ocorrência concreta no ambiente atual vem do log enviado pelo usuário.

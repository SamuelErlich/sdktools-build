# SOLO: starvation por prazo acumulado

Relato23/10/2026: Auto lento e sem capturar cartas em4.0.12/build87. A imagem
mostra Win com21capturas e bandeja6/7, mas a bandeja real está vazia. O produtor
`winAnalysisStatusText` usa `bestCaptures`/`stopTrayCount`: previsão da rota,
não evidência de21envios nem de leitura incorreta da bandeja real.

O adapter iniciava um único prazo de18ms antes da cena. A mesma marca governava
duas leituras coerentes da fase, confirmação, previsão Win e conferência final.
Em mesas grandes, a fase recebia somente o tempo restante da cena. Um timeout
invalidava revisão/estabilidade; a próxima observação reiniciava a busca. Mesmo
uma rota pronta podia ser invalidada antes do evento.

Correção: cena, cada aquisição completa da fase e processamento da observação
usam prazos separados. Há verificação final do prazo ao terminar cena e censo.
Não há aumento do limite individual nem retirada de testemunhos, geometria,
contexto/socket, replay, estabilidade ou pending. Cada etapa continua limitada;
18ms não representa mais um limite para a chamada inteira. A soma das etapas
e cálculos pode ocupar múltiplos quadros; frequência física depende do aparelho.

Regressão determinística usa a cadeia de produção com228cartas sintéticas,
10ms simulados para getScene,2ms por contexto de fase e6ms para Win. Antes,
nenhum evento em20ticks e revisão reiniciada; depois, rota integral e um único
evento, preservado pendente. Leitura de fase individualmente acima de18ms e
troca de carta entre plano/envio continuam recusadas. Sem rede ou jogo real.

Sonda adicional com relógio real em Windows/V8 reproduziu zero eventos em120
ticks na base; após a correção, primeiro evento no tick18. São amostras ruidosas
de desempenho sintético, não garantia de latência no iPhone. `probe.cjs` e
`profile.cjs`, logs RED/GREEN e relatório de revisão ficam em recuperação.

Escopo preservado: busca global até60.000estados, cadência nativa, poderes,
KeyAuth e recursos anteriores. Mesas combinatórias difíceis ainda podem levar
tempo ou retornar rota parcial. A correção trata o ciclo de leitura/reinício;
não promete vitória universal nem tempo máximo de solução.

# V3.17.1 (build 34), sobre V3.17/build33

- Reativação explícita de Cartas, preservando Alpaca e o resolvedor Lua do Bilhar da V3.17.
- Hooks de setup (void) e loadCurrentGame (BOOL) separados, com retorno e encoding de restauração preservados.
- Menu de Cartas: captura desde a entrada, histórico ao vivo das cores recebidas, marcadores atuais e exportação do JS baixado.
- Histórico nativo limitado a oito registros de skin_bg_complete, com binding válido. Não revela cores desconhecidas nem associa por ID entre capturas.
- Transporte continua em 250 ms; mantidos limites de 90 s / 512 amostras.
- Booleano da cauda exportado como bool; analisador aceita somente o 0/1 legado desse campo específico.
- Bilhar mantém package.loaded/descritores canônicos e ganha acquisition.frameFound e acquisition.positions/positionCount, separados da autorização de desenho.
- As posições só são copiadas após validação de geometria/projeção; podem estar disponíveis mesmo com movimento ou turno que bloqueie a previsão.
- O leitor do Bilhar não é o observador Cocos/JS de Cartas. São pipelines independentes (Unity/Lua e WKWebView/Cocos).
- Nenhuma nova captura do aparelho foi fornecida para a V3.17. A captura histórica V3.16 não prova que o resolvedor novo encontrou o frame.
- Pendência de layer19 das caçapas e física aproximada preservadas, fora da aquisição solicitada.

Validação local Windows: 491 testes Node aprovados; 86 testes Python, 84 aprovados e dois pulados por recursos de plataforma. Testes Foundation, Lua e build iPhoneOS são obrigatórios no workflow, sem removê-los ou aceitar mocks como compilação Apple.

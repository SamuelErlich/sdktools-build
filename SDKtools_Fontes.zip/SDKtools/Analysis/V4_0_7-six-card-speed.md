# V4.0.7 — dois trios e intervalo solicitado

Base V4.0.6/81. O modo1/2/3/6 é independente da velocidade. Prova `two_trios` exige
capacidade7, bandeja vazia, exatamente6 referências/rawIDs únicos, dois grupos
consecutivos de3 do mesmo tipo, cada carta disponível/exposta/selecionável,
ordinária e sem dependências. Prioridade de missão existente ordena os grupos.
`alpaca_fast.plan` monta; `autoplay_coop.validateRoute` reproduz a prova de forma
independente. O adapter real cooperativePlanning=true aceita essa prova somente
no modo6; fallback permanece no planejador cooperativo anterior. Prefixos de
rotas normais continuam limitados a3, inclusive se o seletor estiver em6.

Todos eventos são os callbacks originais registrados. Cada envio revalida
controle, nó, face, flags, documento, rodada e transporte. Não modifica permissões,
estoque, pacotes nem jogo de aliado. Uma mudança após a terceira carta pode
interromper o restante; o prefixo já submetido continua pendente até reconciliação.
Nenhum próximo lote antes de todos ACKs/Promises e efeito inteiro estável. As
travas de refresh/reserva e efeito tardio da4.0.6 permanecem.

`STAutoplayIntervalMilliseconds` agora retorna double; níveis9/10 solicitam0.5/0.05ms.
NSTimer não garante precisão nem frequência física; WebKit continua no máximo
uma avaliação em voo. Não reduz estabilidade, orçamento, confirmação ou animação.
Selecionar velocidade não iniciaAuto nem limpa pendências. Default100ms inalterado.

`superFast.dispatchElapsedMs` usa relógio monotônico quando disponível e inclui
preparo dos observadores e chamadas locais do último lote, sem tempo de ACK,
animação ou intervalo entre lotes. Valor nulo significa indisponível. Sanitização
aceita somente número finito0..60000 ou nulo; rejeita booleanos/strings/NaN.
Não exporta identificadores. LAN distingue esse valor da cadência solicitada e
da taxa de cartas confirmadas/minuto. Nenhuma taxa de vitória garantida.

Validação: casos RED/GREEN fora do produto em recuperacao/six-batch-*.log;
provas negativas de capacidade, bloqueios, especial, identidade repetida;
integração bridge cooperativa,6ACKs, animação adiada e rejeição do segundo trio.
Compilação Apple, revisão independente e entrega são registradas em CONTEXTO.md.
Teste físico de taxa/consumo e comportamento do servidor pendente.

# Diamantes e HotTime — 3.23.23 / build 73

## Pedido e limite comprovável

O usuário pediu que o Auto evite diamantes quando faltar apenas um trio de três
para completar o HotTime. A exportação fornecida permite identificar o medidor,
mas não permite conhecer a contribuição de um trio. A regra exata permanece
não determinada. O usuário foi informado antes da implementação de que o
fallback seria mais conservador: bloquear diamantes enquanto o ganho não estiver
comprovado, mantendo os demais tipos disponíveis.

Não inventar um limite como 80%, 90% ou 95%. Não atribuir diferenças da barra a um
trio sem evidência causal: aliados, fases e eventos do servidor podem intervir.
Não usar um primeiro trio automático para calibração.

## Evidência original

Exportação: SDKtools-export-90D0BE10-B483-4674-B87F-3F5110E3A9D8.json.
SHA-256 do JSON: 15eb40dfc8304905e693642fd2a8e02faf762b46624a993aaa1580002add11a6.
Sete arquivos completos tiveram tamanho e SHA-256 conferidos. Game ID 60;
coletor informado 3.21.0; escopo completo; equivalência com o runtime não provada.

Arquivo interno `assets/main/index.js`: 3.641.464 bytes, SHA-256
cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6.
Os bytes coincidem com o bundle referenciado pelas análises históricas.
Nenhum código original foi executado durante a análise.

- `BlockType.Diamond` corresponde ao tipo 1.
- `HandArea.HotTimeProgressBar` é um `cc.ProgressBar`.
- `HandArea.updateHotTimeProgress(e)` mostra a barra se `e.full_value > 0`
  e atribui `progress = e.current_value / e.full_value`; senão a oculta.
- `Game.updateRemoveProgress` recebe `hot_time` e verifica carga cheia,
  partida iniciada, ausência de espectador/vitória e HotTime ainda inativo.
- A escolha do tipo de carta passa pelo callback original e depende do servidor.
- `Game.onHotTimeBomb` anima a lhama por 2 s, esvazia a bandeja e remove os IDs
  da mesa indicados pelo evento recebido.
- Os campos `current_value` e `full_value` são apenas lidos no bundle. Não há
  cálculo local de pontos por trio ou por diamante.
- O engine Cocos exportado transforma propriedades com notify em um getter
  sobre um campo próprio `_N$<nome>`. Para `progress`, é `_N$progress`.
  O leitor não deve invocar getters arbitrários ao procurar esse valor.

## Regra entregue

Enquanto o incremento não for comprovado, **todas** as seleções automáticas de
`type:1` são recusadas. Não é um bloqueio somente no último trio. O percentual
serve como diagnóstico, nunca como autorização por um limiar inventado.
O fallback também se aplica se o módulo, a barra ou sua leitura estiverem ausentes.

O filtro é aplicado às cópias destinadas ao planejamento e aos caminhos de
envio. As cartas continuam nas observações originais e no grafo de dependências.
A política é reaplicada aos planos preparados, aos grupos de 1/2/3 e à coleta
cooperativa. Pedidos pendentes não são apagados nem repetidos. A proteção não
bloqueia controles manuais e não adiciona interface mobile.

## Validação

Resultados locais serão registrados em `Validation/V3_23_23-validation.json`.
Os testes locais não substituem a compilação Apple nem o teste físico.
Base imediata: 3.23.22/build72, commit local
7575d5f1748d3254dec42f4a186dc60ae33850da; ZIP SHA-256
7ed00ea81ca8646ee61e8fb4ccab1252c1d85180e7b4cc8e984cfec5c5fd1fcf.

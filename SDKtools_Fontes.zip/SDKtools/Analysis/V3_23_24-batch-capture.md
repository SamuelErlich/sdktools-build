# Captura de 2/3 cartas — 3.23.24 / build 74

## Pedido

Corrigir o modo de 2/3 cartas que estava funcionando como captura individual.
O objetivo é emitir até a quantidade escolhida na mesma execução, reduzindo
as esperas entre cartas elegíveis; não prometer um tempo até 50–60% sem medição.

## Restrições comprovadas no SDK anterior

1. O cliente original usa `wss://` na porta 443 e `ws://` nas demais portas.
   `alpaca_fast.js` aceitava apenas `wss://`, fazendo uma conexão original válida
   `ws://` cair em compatibilidade serial por 3 segundos.
2. O bootstrap nativo sempre usa `cooperativePlanning:true`. Nesse caminho, o
   marcador de lote exigia que toda a rota até o primeiro trio já estivesse
   exposta. O coordenador ainda exigia até três cartas de um único tipo e um
   trio concluído. Um prefixo de duas cartas livres seguido de uma carta coberta
   não podia ser enviado junto.
3. O callback do adapter cortava os envios após apenas 4 ms. Uma reprodução no
   harness da versão 23, acrescentando 5 ms ao primeiro callback original,
   enviou somente uma carta apesar de três selecionadas. O relógio congelado
   dos fixtures anteriores escondia esse caso.

Esses são defeitos reproduzidos no SDK. Não há captura nova do aparelho para
atribuir a falha relatada a um único deles.

## Evidência original

Bundle fornecido pelo usuário: 3.641.464 bytes, SHA-256
`cbbf9dec2d3cbaf9595834934147344eca4e7c6c4fe3957b590f5c24660c19e6`.
Análise estática; nenhum código do jogo foi executado para extrair essa evidência.
Offsets em bytes UTF-8:

| Método/campo | Offset |
| --- | ---: |
| Block.touchBlock | 782083 |
| Config.BLOCKMOVETIME = .25 | 791954 |
| GameLayer.touchPileBlock | 3479270 |
| GameLayer.TouchStorageBlock | 3479619 |
| GameLayer.handleMoveEvent | 3480643 |
| GameStore.getIsCanTouchBlock | 3500602 |
| HandArea.insertListAndUpdataBlocks | 3536085 |
| Socket.getConnectUrl | 3614207 |
| Socket.send | 3618522 |
| Socket.TouchBlock | 3619829 |

`Block.touchBlock` aciona a movimentação local e chama `Socket.TouchBlock` sem
aguardar a animação. `Socket.send` cria uma entrada por packet ID em responseMap,
permitindo requisições pendentes distintas. Não existe endpoint atômico de lote
identificado. A inserção em HandArea.blocksList e GameStore.hand_blocks é
síncrona; a animação leva 250 ms e as remoções do trio aguardam o mapa visual.
Logo, a capacidade transitória precisa considerar as cartas emitidas antes de
qualquer remoção animada. O SDK deve preservar a prova da rota até o primeiro
trio e enviar somente seu prefixo atualmente exposto.

## Alterações e limites

- Reutilizar o mesmo socket original, com URL e identidade conferidas, aceitando
  seus dois esquemas suportados. Não abrir ou substituir conexões.
- Validar a rota completa e selecionar seu prefixo exposto de até 1/2/3 cartas;
  preparar os eventos somente desse prefixo e revalidar antes de cada envio.
- Permitir tipos diferentes dentro do prefixo, mantendo a prova do próximo trio,
  dependências e capacidade, incluindo o estado transitório da bandeja.
- Limitar a execução pelo número de callbacks, sem o corte de 4 ms entre eles.
- Acompanhar cada requisição, resposta e efeito das cartas realmente emitidas;
  nenhum timeout autoriza repetir uma carta ou apagar uma incerteza.
- Mostrar limite escolhido e envios pendentes separadamente, sem usar dados
  antigos de um lote concluído como se fossem atuais.
- Preservar a proteção conservadora de todos os diamantes no Auto da versão23,
  controles manuais, X-ray, pausa e contagem lateral.

Validação final em `Validation/V3_23_24-validation.json`. Os testes simulados
não substituem compilação Apple, confirmação do servidor real e teste no iPhone.

Base imediata: 3.23.23/build73, commit local
59b9851f14eaa21e9aef2149a36776ea44f90027; ZIP SHA-256
7b31f4ac980fda7371ace4dbcafcf0fa3dadd0a192fb80fe8a29458095a56fb0.

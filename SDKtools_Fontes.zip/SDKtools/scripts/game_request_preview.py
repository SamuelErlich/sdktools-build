#!/usr/bin/env python3
"""Validate/edit an inert game-method preview. No transport, credentials or session IDs."""
import argparse
import json
from pathlib import Path
import sys

MAX_BYTES=8192

class PreviewError(ValueError):
    pass

class PrivateArgumentParser(argparse.ArgumentParser):
    def error(self,message):
        self.exit(2,'Argumentos inválidos. Use --help; nenhum envio foi realizado.\n')

def unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise PreviewError('duplicate_field')
        result[key]=value
    return result

def identifier(value):
    return isinstance(value,str) and 0<len(value)<=128 and all(32<ord(c)<127 for c in value)

def validate(value):
    if type(value) is not dict or set(value)!={'command','param'}:raise PreviewError('invalid_shape')
    command,param=value['command'],value['param']
    if type(command) is not str or command not in ('CMD_TOUCH_BLOCK','CMD_USE_PROP'):raise PreviewError('unsupported_command')
    expected={'block_id','block_state'} if command=='CMD_TOUCH_BLOCK' else {'prop_id','block_id'}
    if type(param) is not dict or set(param)!=expected:raise PreviewError('invalid_fields')
    if not identifier(param['block_id']):raise PreviewError('invalid_identifier')
    if command=='CMD_TOUCH_BLOCK':
        if type(param['block_state']) is not int or param['block_state'] not in (0,1,2):raise PreviewError('invalid_state')
    elif not identifier(param['prop_id']):raise PreviewError('invalid_identifier')
    return value

def preview(raw,block_id=None,prop_id=None):
    if not isinstance(raw,bytes) or len(raw)>MAX_BYTES:raise PreviewError('input_limit')
    try:
        value=json.loads(raw.decode('utf-8'),object_pairs_hook=unique_object,
                         parse_constant=lambda _: (_ for _ in ()).throw(PreviewError('invalid_number')))
    except (ValueError,RecursionError,UnicodeError):raise PreviewError('invalid_json') from None
    validate(value) # Never silently discard authentication/session fields.
    if block_id is not None:value['param']['block_id']=block_id
    if prop_id is not None:
        if value['command']!='CMD_USE_PROP':raise PreviewError('wrong_command_for_edit')
        value['param']['prop_id']=prop_id
    validate(value)
    return {'schema':'SDKtools.GameRequestPreview.v1','dryRun':True,'networkEnabled':False,**value}

def main(argv=None):
    parser=PrivateArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--set-block-id')
    parser.add_argument('--set-prop-id')
    args=parser.parse_args(argv)
    try:
        if args.input.is_symlink() or not args.input.is_file():raise PreviewError('invalid_file')
        with args.input.open('rb') as stream:raw=stream.read(MAX_BYTES+1)
        result=preview(raw,args.set_block_id,args.set_prop_id)
    except (PreviewError,OSError):
        # Do not echo input, IDs, exceptions or any accidentally supplied token.
        print('Prévia recusada: formato/campos inválidos. Nenhum envio foi realizado.',file=sys.stderr)
        return 1
    print(json.dumps(result,ensure_ascii=True,indent=2))
    return 0

if __name__=='__main__':raise SystemExit(main())

#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-client-host.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
python3 - "$project_root" "$test_workspace" <<'PY'
from pathlib import Path
import sys
root,out=map(Path,sys.argv[1:])
for name in ['STClientHostVisibility','STClientContext']:
    text=(root/f'Sources/SDKtools/{name}.m').read_text()
    (out/f'{name}.inc').write_text('\n'.join(line for line in text.splitlines() if not line.startswith('#import')))
PY
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
  -Werror=implicit-function-declaration -framework Foundation -framework CoreGraphics \
  -I "$test_workspace" -I "$project_root/Sources/SDKtools" \
  "$project_root/Tests/client_host_test.m" -o "$test_workspace/client-host"
"$test_workspace/client-host"

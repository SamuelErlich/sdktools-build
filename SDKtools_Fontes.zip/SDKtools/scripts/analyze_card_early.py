#!/usr/bin/env python3
"""Read-only, bounded analyzer for SDKtools V3.12 cardEarly captures.

Usage: python3 scripts/analyze_card_early.py --input capture.json --output summary.json

All counts of fields are repeated observations unless explicitly scoped as
unique. A same-ID side-field overlap is a candidate, never a proven face or
player identity. The summary emits only a fixed allowlist of numeric evidence
and static labels; no user IDs, URLs, tokens, original payloads or game strings.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile

MAX_INPUT_BYTES = 40 * 1024 * 1024
MAX_SAMPLES = 4096
MAX_EVENTS = 16384
MAX_CARDS_PER_EVENT = 256
MAX_CARD_OBSERVATIONS = 300000
MAX_DEPTH = 64
STAGES = frozenset('loader_assignment before_scene socket_establish onmessage_entry socket_decoded_response push_input store_input store_after store_update_input store_update_after card_setup_input card_setup_after hand_setup_input hand_setup_after skin_bg_input skin_bg_complete skin_type_input skin_type_complete sync_called'.split())
ZONES = frozenset('visual hand discard event look_over draw selected result_rank result_sync punish punish_list'.split())
COMMANDS = frozenset('CMD_SYNC CMD_ENTER_GAME CMD_PLAY_CARD CMD_SELECT_COLOR CMD_DOUBT CMD_CHOOSE_GAMER CMD_END_LOOK_OVER CMD_GIVE_CARD CMD_UNO CMD_CATCH CMD_CANCEL_AUTO'.split())
MILESTONES = ('loaderSeen', 'modulesReady', 'beforeScene', 'beforeSocket', 'beforeFirstSync', 'hasInitialSync', 'lateAttach')
COUNTERS = ('lastSequence', 'totalEvents', 'dropped', 'truncated', 'errors', 'decodedResponses', 'decoderMissed', 'bytesQueued', 'totalBytes', 'staleBindings')
GAPS = frozenset('late_attach preexisting_socket initial_sync_unproven loader_contract_unverified missing_module_registry missing_push_registration missing_decoded_boundary missing_scene_event scene_already_running async_binding_changed transport_loss'.split())
OBSERVATION_REASONS = frozenset('observing awaiting_loader awaiting_engine awaiting_modules unsupported_engine loader_contract_mismatch loader_accessor loader_readonly bridge_unavailable bridge_rejected bridge_timeout lease_expired duration_limit event_limit byte_limit queue_limit hidden_document pagehide explicit_stop method_replaced install_failed document_changed'.split())
NATIVE_REASONS = OBSERVATION_REASONS | frozenset('not_requested awaiting_controller already_open_document game_type_abi_mismatch game_type_read_failed view_not_loaded ambiguous_webview view_scan_limit webview_unavailable controller_class_unavailable lifecycle_abi_mismatch lifecycle_method_replaced prepared_next_navigation prepared_lifecycle_checkpoint window_scan_limit ambiguous_controller controller_scan_limit unsupported_host application_inactive unsupported_webkit_api document_start_timeout native_checkpoint_error game_context_changed webview_changed early_script_missing early_script_invalid content_controller_unavailable script_install_failed controller_dismissed transport_timeout native_report_limit export context_changed native_export_limit'.split())
NATIVE_GAPS = frozenset('lifecycle_abi_mismatch lifecycle_method_replaced lifecycle_restore_contested transport_heartbeat_missing foreign_message_rejected invalid_envelope invalid_observation missing_hello duplicate_hello duplicate_or_reordered_event native_event_limit native_report_limit handler_removal_failed script_removal_failed undrained_tail_possible'.split())
FIELDS = frozenset('gamers cards card look_over_cards select_give_card punish punish_cards punish_list punish_list_cards rank_infos rank_infos_cards game_over_info game_over_rank_infos game_over_rank_infos_cards'.split())
PRESENCE = frozenset('absent null array object invalid accessor'.split())


class CaptureAnalysisError(ValueError):
    """The message is a fixed error code, never untrusted capture content."""


def fail(code):
    raise CaptureAnalysisError(code)


def integer(value, upper=9007199254740991, minimum=0):
    return type(value) is int and minimum <= value <= upper


def number(value, upper=9007199254740991):
    return type(value) in (int, float) and 0 <= value <= upper and math.isfinite(value)


def choice(value, choices):
    return isinstance(value, str) and value in choices


def require_object(value):
    if not isinstance(value, dict):
        fail('expected_object')
    return value


def bounded_list(value, maximum):
    if not isinstance(value, list):
        fail('expected_array')
    if len(value) > maximum:
        fail('array_limit')
    return value


def unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            fail('duplicate_json_key')
        result[key] = value
    return result


def reject_constant(_):
    fail('non_finite_json_number')


def check_depth(value):
    pending = [(value, 0)]
    while pending:
        item, depth = pending.pop()
        if depth > MAX_DEPTH:
            fail('nesting_limit')
        if isinstance(item, dict):
            pending.extend((v, depth + 1) for v in item.values())
        elif isinstance(item, list):
            pending.extend((v, depth + 1) for v in item)


def load_capture(path):
    try:
        with Path(path).open('rb') as handle:
            raw = handle.read(MAX_INPUT_BYTES + 1)
    except OSError:
        fail('input_unreadable')
    if len(raw) > MAX_INPUT_BYTES:
        fail('input_byte_limit')
    try:
        data = json.loads(raw, object_pairs_hook=unique_keys, parse_constant=reject_constant)
    except CaptureAnalysisError:
        raise
    except (UnicodeDecodeError, ValueError, RecursionError):
        fail('invalid_json')
    check_depth(data)
    return data, hashlib.sha256(raw).hexdigest()


def color_state(card):
    card_type, color = card.get('type'), card.get('color')
    if card_type == 0:
        return 'candidate' if integer(color, 4, 1) else 'unknown'
    if card_type in (4, 6, 10):
        return 'special' if integer(color, 4) else 'unavailable'
    if integer(color, 4, 1):
        return 'known' if integer(card_type, 10, 1) else 'candidate'
    return 'unavailable'


def count(values):
    return dict(sorted(collections.Counter(values).items()))


def safe_card(raw):
    require_object(raw)
    if not choice(raw.get('zone'), ZONES) or not integer(raw.get('index'), 255):
        fail('invalid_card_location')
    card = {'zone': raw['zone'], 'index': raw['index']}
    if card['zone'] == 'hand' and not integer(raw.get('slot'), 7):
        fail('invalid_hand_slot')
    for key, upper in [('slot', 7), ('group', 7), ('id', 65535), ('type', 10), ('color', 4), ('num', 99)]:
        if key in raw:
            if not integer(raw[key], upper):
                fail('invalid_card_number')
            card[key] = raw[key]
    if 'objectID' in raw:
        if not isinstance(raw['objectID'], str) or not re.fullmatch(r'ec[1-9][0-9]{0,8}', raw['objectID']):
            fail('invalid_object_alias')
        card['objectID'] = raw['objectID']
    card['colorState'] = color_state(card)
    if 'colorState' in raw and raw['colorState'] != card['colorState']:
        fail('inconsistent_color_state')
    return card


def safe_event(raw):
    require_object(raw)
    if not choice(raw.get('stage'), STAGES):
        fail('invalid_event_stage')
    if not integer(raw.get('sequence'), 4096, 1) or not integer(raw.get('callID'), 1000000, 1):
        fail('invalid_event_identity')
    if type(raw.get('truncated')) is not bool:
        fail('invalid_truncation_state')
    event = {key: raw[key] for key in ['stage', 'sequence', 'callID', 'truncated']}
    for key in ['elapsedMs', 'parentCallID', 'connectionGeneration', 'round', 'bindingGeneration']:
        if key in raw:
            if not integer(raw[key], 1000000):
                fail('invalid_event_number')
            event[key] = raw[key]
    for key in ['afterGameOver', 'bindingValid']:
        if key in raw:
            if type(raw[key]) is not bool:
                fail('invalid_event_boolean')
            event[key] = raw[key]
    if 'command' in raw:
        if not choice(raw['command'], COMMANDS):
            fail('invalid_command')
        event['command'] = raw['command']
    event['cards'] = [safe_card(c) for c in bounded_list(raw.get('cards'), MAX_CARDS_PER_EVENT)]
    event['fields'] = []
    for bucket in ['payloadFields', 'resultFields']:
        if bucket not in raw:
            continue
        for field in bounded_list(raw[bucket], 32):
            require_object(field)
            if not choice(field.get('path'), FIELDS) or not choice(field.get('presence'), PRESENCE):
                fail('invalid_field_presence')
            event['fields'].append({'path': field['path'], 'presence': field['presence']})
    # Never trust a supplied sideChannelCandidates claim. Recompute only from
    # the allowlisted cards present together in this exported event.
    return event


def side_candidates(event):
    if event['stage'] != 'socket_decoded_response' or event['truncated']:
        return []
    hands, selected = collections.defaultdict(list), collections.defaultdict(list)
    for card in event['cards']:
        if not integer(card.get('id'), 65535, 1):
            continue
        if card['zone'] == 'hand':
            hands[card['id']].append(card)
        elif card['zone'] == 'selected':
            selected[card['id']].append(card)
    found = []
    for card_id, choices in selected.items():
        hand_rows = hands.get(card_id, [])
        if len(choices) != 1 or len(hand_rows) != 1:
            continue
        chosen, hand = choices[0], hand_rows[0]
        if chosen['colorState'] != 'known' or hand.get('type') != 0 or hand.get('color') != 0:
            continue
        refs = (hand.get('objectID'), chosen.get('objectID'))
        row = {
            'eventSequence': event['sequence'],
            'connectionGeneration': event.get('connectionGeneration'),
            'round': event.get('round'),
            'elapsedMs': event.get('elapsedMs'),
            'cardID': card_id, 'handSlot': hand['slot'], 'handIndex': hand['index'],
            'source': 'select_give_card', 'type': chosen['type'], 'color': chosen['color'],
            'confidence': 'candidate', 'relation': 'same_response_id_only',
            'sameObjectReference': refs[0] == refs[1] if all(refs) else None,
        }
        if 'num' in chosen:
            row['num'] = chosen['num']
        if 'command' in event:
            row['command'] = event['command']
        found.append(row)
    return found


def analyze(capture):
    """Return a new sanitized summary; do not mutate the caller's capture."""
    require_object(capture)
    if not integer(capture.get('schemaVersion'), 3, 2):
        fail('unsupported_capture_schema')
    if capture.get('format', 'SDKtools.Capture') != 'SDKtools.Capture':
        fail('invalid_capture_format')
    summary = {
        'analysisSchemaVersion': 1,
        'sourceCaptureSchemaVersion': capture['schemaVersion'],
        'status': 'unavailable',
        'countsAreRepeatedObservations': True,
        'provenHiddenIdentities': 0,
        'unknownProvesUniversalAbsence': False,
        'interpretation': [
            'Unknown fields describe only the observed stage and time.',
            'Zero loss counters do not prove capture of document or connection startup.',
            'Same numeric ID across side field and hand is candidate correspondence, not identity proof.',
            'This report does not supply values to an overlay or modify game data.',
        ],
    }
    if 'cardEarly' not in capture:
        summary['coverage'] = {'status': 'unavailable', 'gaps': ['card_early_absent']}
        return summary
    early = require_object(capture['cardEarly'])
    if early.get('version') != 1 or type(early.get('version')) is not int or early.get('gameType') != 2007:
        fail('unsupported_card_early_schema')
    if not integer(early.get('generation')) or not integer(early.get('documentGeneration'), 1):
        fail('invalid_document_scope')
    if 'status' in early and not choice(early['status'], ('idle', 'armed', 'waiting_document', 'capturing', 'stopped', 'blocked', 'error')):
        fail('invalid_native_status')
    if 'reason' in early and not isinstance(early['reason'], str):
        fail('invalid_native_reason')
    native = require_object(early.get('native', {}))
    samples = bounded_list(early.get('samples', []), MAX_SAMPLES)
    milestones, counters, gaps = {}, {key: 0 for key in COUNTERS}, set()
    seen, events, duplicate_events, card_total = {}, [], 0, 0
    unknown_scope, omitted = False, 0
    kinds, observation_statuses = collections.Counter(), collections.Counter()
    last_elapsed = 0

    def observation(raw, sample_kind=None):
        nonlocal duplicate_events, card_total, unknown_scope, omitted, last_elapsed
        require_object(raw)
        if type(raw.get('version')) is not int or raw['version'] != 1:
            fail('unsupported_observation_schema')
        if not choice(raw.get('status'), ('waiting', 'ready', 'stopped', 'unsupported')) or not choice(raw.get('reason'), OBSERVATION_REASONS):
            fail('invalid_observation_state')
        observation_statuses[raw['status']] += 1
        if 'elapsedMs' in raw:
            if not integer(raw['elapsedMs'], 1000000):
                fail('invalid_observation_time')
            last_elapsed = max(last_elapsed, raw['elapsedMs'])
        for key, value in require_object(raw.get('milestones', {})).items():
            if key in MILESTONES:
                if type(value) is not bool:
                    fail('invalid_milestone')
                milestones[key] = value
        values = require_object(raw.get('counters', {}))
        for key in COUNTERS:
            if key in values:
                if not integer(values[key], 1000000000):
                    fail('invalid_counter')
                counters[key] = values[key] if key == 'bytesQueued' else max(counters[key], values[key])
        for gap in bounded_list(raw.get('gaps', []), 32):
            if not isinstance(gap, str) or gap not in GAPS:
                fail('invalid_gap')
            gaps.add(gap)
        if 'nativeOmittedEvents' in raw:
            if not integer(raw['nativeOmittedEvents'], 1000000000):
                fail('invalid_counter')
            omitted = max(omitted, raw['nativeOmittedEvents'])
        for item in bounded_list(raw.get('events', []), 96):
            event = safe_event(item)
            event_key = event['sequence']  # One document per native generation.
            canonical = json.dumps(event, sort_keys=True, separators=(',', ':'))
            if event_key in seen:
                if seen[event_key] != canonical:
                    fail('conflicting_event_sequence')
                duplicate_events += 1
                continue
            seen[event_key] = canonical
            events.append(event)
            card_total += len(event['cards'])
            if len(events) > MAX_EVENTS or card_total > MAX_CARD_OBSERVATIONS:
                fail('aggregate_limit')
            if 'connectionGeneration' not in event or 'round' not in event:
                unknown_scope = True

    for sample in samples:
        require_object(sample)
        if sample.get('kind') not in ('hello', 'batch', 'end'):
            fail('invalid_sample_kind')
        if 'nativeElapsedMs' in sample and not number(sample['nativeElapsedMs'], 1000000000):
            fail('invalid_native_time')
        kinds[sample['kind']] += 1
        observation(sample.get('observation'), sample['kind'])
    # latest repeats cumulative data and contains no events in the native
    # contract. It may be absent in an interrupted/partial export.
    if 'latest' in early:
        latest = require_object(early['latest'])
        if latest:
            latest = dict(latest)
            latest.setdefault('version', 1)
            latest.setdefault('events', [])
            observation(latest)
    native_safe = {}
    for key in ['hooksInstalled', 'hooksPrepared', 'scriptInstalled', 'helloReceived', 'loadCheckpoint', 'setupCheckpoint', 'pollingPreparation', 'finalDrainReceived', 'finalDrainConfirmed', 'undrainedTailMayBeLost']:
        if key in native:
            if type(native[key]) is not bool:
                fail('invalid_native_boolean')
            native_safe[key] = native[key]
    native_gaps = []
    for gap in bounded_list(native.get('gaps', []), 64):
        if not isinstance(gap, str):
            fail('invalid_native_gap')
        safe_gap = gap if gap in NATIVE_GAPS else 'unrecognized_native_gap'
        if safe_gap not in native_gaps:
            native_gaps.append(safe_gap)
        gaps.add('native_' + safe_gap)
    if native_gaps:
        native_safe['gaps'] = sorted(native_gaps)
    for key in ['receivedMessages', 'rejectedMessages', 'nativeOmittedEvents', 'sequenceGaps', 'events', 'reportBytes']:
        if key in native:
            if not integer(native[key], 1000000000):
                fail('invalid_native_counter')
            native_safe[key] = native[key]
    if early['documentGeneration'] != 1 and events:
        fail('events_without_document_scope')
    events.sort(key=lambda e: e['sequence'])
    if unknown_scope:
        gaps.add('event_scope_unavailable')
    if not native_safe.get('helloReceived'):
        gaps.add('native_hello_unconfirmed')
    if not native_safe.get('scriptInstalled'):
        gaps.add('document_script_unconfirmed')
    for key in ['loaderSeen', 'modulesReady', 'beforeScene', 'beforeSocket', 'beforeFirstSync', 'hasInitialSync']:
        if milestones.get(key) is not True:
            gaps.add('unconfirmed_' + key)
    if milestones.get('lateAttach'):
        gaps.add('late_attach')
    if not native_safe.get('finalDrainConfirmed'):
        gaps.add('final_drain_unconfirmed')
    if native_safe.get('undrainedTailMayBeLost'):
        gaps.add('undrained_tail_possible')
    if any(counters[key] for key in ['dropped', 'decoderMissed', 'errors']) or native_safe.get('rejectedMessages', 0):
        gaps.add('reported_capture_loss_or_error')
    if omitted or native_safe.get('nativeOmittedEvents', 0):
        gaps.add('native_omitted_events')
    truncated_events = sum(e['truncated'] for e in events)
    if truncated_events or counters['truncated']:
        gaps.add('truncated_events')
    missing_sequences = max(0, max([e['sequence'] for e in events] + [counters['lastSequence']]) - len(events))
    if missing_sequences or native_safe.get('sequenceGaps', 0):
        gaps.add('event_sequence_gap')
    if counters['bytesQueued']:
        gaps.add('undrained_queue')
    status = 'early_path_observed' if events and not gaps else 'partial' if events or milestones.get('modulesReady') else 'unavailable'
    summary['status'] = status
    summary['coverage'] = {
        'status': status, 'milestones': milestones, 'gaps': sorted(gaps),
        'native': native_safe, 'counterMaxima': {key: value for key, value in counters.items() if key != 'bytesQueued'},
        'lastReportedQueueBytes': counters['bytesQueued'],
        'sampleKinds': dict(sorted(kinds.items())), 'uniqueEvents': len(events),
        'duplicateEventDeliveriesIgnored': duplicate_events, 'missingEventSequenceCount': missing_sequences,
        'truncatedEventCount': truncated_events, 'lastObservedElapsedMs': last_elapsed,
        'scope': 'one_document_per_native_capture_generation',
        'claim': 'Coverage of observed client stages only; no claim of complete server state.',
    }
    if 'status' in early:
        summary['coverage']['nativeStatus'] = early['status']
    if 'reason' in early:
        summary['coverage']['nativeReason'] = early['reason'] if early['reason'] in NATIVE_REASONS else 'unrecognized_native_reason'
    for key in ['armElapsedMs', 'captureElapsedMs', 'durationLimitMs']:
        if key in early:
            if not integer(early[key], 1000000000):
                fail('invalid_native_time')
            summary['coverage'][key] = early[key]
    stages = {}
    all_scoped, hidden_scoped, known_scoped = set(), set(), set()
    for stage in sorted({e['stage'] for e in events}):
        selected = [e for e in events if e['stage'] == stage]
        cards = [c for e in selected for c in e['cards']]
        stages[stage] = {
            'events': len(selected), 'cardObservations': len(cards),
            'colorStates': count(c['colorState'] for c in cards),
            'zones': {zone: count(c['colorState'] for c in cards if c['zone'] == zone) for zone in sorted({c['zone'] for c in cards})},
        }
    decoded = [e for e in events if e['stage'] == 'socket_decoded_response']
    hidden_observations = 0
    for event in decoded:
        for card in event['cards']:
            if card['zone'] != 'hand':
                continue
            hidden = card.get('type') == card.get('color') == card.get('num') == 0
            hidden_observations += hidden
            if not integer(card.get('id'), 65535, 1) or 'connectionGeneration' not in event or 'round' not in event:
                continue
            key = (event['connectionGeneration'], event['round'], card['id'])
            all_scoped.add(key)
            if hidden:
                hidden_scoped.add(key)
            if card['colorState'] == 'known':
                known_scoped.add(key)
    candidates = [candidate for event in decoded for candidate in side_candidates(event)]
    summary['observations'] = {
        'uniqueDecodedResponseEvents': len(decoded),
        'decodedCommands': count(e.get('command', 'unavailable') for e in decoded),
        'hiddenZeroAtDecodedIngressRepeatedObservations': hidden_observations,
        'uniqueHandCardIDsScopedByDocumentConnectionRound': len(all_scoped),
        'uniqueHiddenZeroCardIDsScopedByDocumentConnectionRound': len(hidden_scoped),
        'uniqueKnownHandCardIDsScopedByDocumentConnectionRound': len(known_scoped),
        'uniqueIDsMeaning': 'Observed numeric IDs in an explicit document/connection/round scope, not proven physical cards.',
        'stages': stages,
    }
    summary['sideFieldCandidates'] = {
        'decodedResponseOccurrences': len(candidates),
        'uniqueResponseEvents': len({c['eventSequence'] for c in candidates}),
        'storeRepetitionsNotCountedAsDiscoveries': True,
        'values': candidates,
        'candidatesDoNotProveIdentityOrAuthorizeHistoricalReuse': True,
    }
    summary['fieldCoverage'] = {
        path: count(field['presence'] for e in events for field in e['fields'] if field['path'] == path)
        for path in sorted({field['path'] for e in events for field in e['fields']})
    }
    return summary


def atomic_write(path, value):
    path = Path(path)
    temporary = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile('w', encoding='utf-8', prefix='.card-early-', suffix='.tmp', dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write('\n')
        os.replace(temporary, path)
    except (OSError, ValueError):
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        fail('output_unwritable')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        if args.input.resolve() == args.output.resolve():
            fail('input_output_same_path')
        capture, digest = load_capture(args.input)
        summary = analyze(capture)
        summary['inputSHA256'] = digest
        atomic_write(args.output, summary)
    except CaptureAnalysisError as error:
        print('card_early_analysis: ' + str(error), file=sys.stderr)
        return 2
    print('card_early_analysis: summary_written')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

"""Conservative thin arm64/iOS Mach-O parser and SDKtools load-command patcher.

No code, section, segment or existing dependency ordinal is moved. This is not
an executable verifier or a decryptor. Unsupported layouts fail closed.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import struct

MAX_BINARY = 768 * 1024 * 1024
DYLIB = {0xC, 0x80000018, 0x8000001F, 0x80000023, 0x20}
LINKEDIT = {0x1D, 0x1E, 0x26, 0x29, 0x2B, 0x2E, 0x80000033, 0x80000034, 0x36}
# Commands with no payload pointer outside their own bytes.
INLINE = {0xD, 0x1B, 0x8000001C, 0x25, 0x32, 0x2A, 0x80000028, 0x2D, 0x16, 0x27}
ZEROFILL = {1, 0xC, 0x12}
LOAD_PATH = '@executable_path/Frameworks/SDKtools.framework/SDKtools'
INSTALL_NAME = '@rpath/SDKtools.framework/SDKtools'

class MachOError(ValueError):
    pass

def check(condition, message):
    if not condition:
        raise MachOError(message)

def command_name(command):
    kind, size = struct.unpack_from('<II', command)
    minimum = 12 if kind in (0x8000001C, 0x27, 0xE, 0xF) else 24
    check(size >= minimum, 'Comando de nome truncado.')
    offset = struct.unpack_from('<I', command, 8)[0]
    check(minimum <= offset < size, 'Offset do nome inválido.')
    end = command.find(b'\0', offset)
    check(end >= 0, 'Nome de load command sem terminador.')
    try:
        return command[offset:end].decode('utf-8')
    except UnicodeDecodeError as error:
        raise MachOError('Nome de load command não é UTF-8.') from error

@dataclass(frozen=True)
class MachO:
    data: bytes
    filetype: int
    commands: tuple[bytes, ...]
    command_end: int
    first_payload: int
    minos: int
    uuid: str | None

    def of_type(self, kind):
        return tuple(c for c in self.commands if struct.unpack_from('<I', c)[0] == kind)

    @property
    def dependencies(self):
        return tuple(command_name(c) for c in self.commands if struct.unpack_from('<I', c)[0] in DYLIB)

def parse(data, expected_type=None):
    check(32 <= len(data) <= MAX_BINARY, 'Tamanho do executável inválido.')
    magic, cpu, subtype, filetype, count, command_bytes, _, reserved = struct.unpack_from('<8I', data)
    check(magic == 0xFEEDFACF, 'Somente Mach-O thin little-endian 64 bits é suportado.')
    check(cpu == 0x100000C and (subtype & 0xFFFFFF) == 0, 'Somente arm64, sem arm64e, é suportado neste integrador.')
    check(reserved == 0, 'Campo reservado do Mach-O não é zero.')
    check(expected_type is None or filetype == expected_type, 'Tipo Mach-O inesperado.')
    end = 32 + command_bytes
    check(0 < count <= 4096 and end <= len(data), 'Tabela de load commands inválida.')
    payloads, commands, platforms, uuids = [], [], [], []

    def region(offset, size, label):
        check(0 <= offset <= len(data) and 0 <= size <= len(data) - offset, label + ' fora do arquivo.')
        if size:
            check(offset >= end, label + ' sobrepõe os load commands.')
            payloads.append(offset)

    cursor = 32
    for _ in range(count):
        check(cursor + 8 <= end, 'Load command truncado.')
        kind, size = struct.unpack_from('<II', data, cursor)
        check(size >= 8 and size % 8 == 0 and cursor + size <= end, 'Tamanho de load command inválido.')
        cmd = data[cursor:cursor + size]
        if kind == 0x19:
            check(size >= 72, 'Segmento truncado.')
            vmaddr, vmsize, fileoff, filesize = struct.unpack_from('<4Q', cmd, 24)
            sections = struct.unpack_from('<I', cmd, 64)[0]
            check(size == 72 + 80 * sections, 'Tabela de seções inválida.')
            check(fileoff <= len(data) and filesize <= len(data) - fileoff, 'Segmento fora do arquivo.')
            if fileoff and filesize:
                region(fileoff, filesize, 'Segmento')
            for index in range(sections):
                pos = 72 + 80 * index
                addr, length, offset = struct.unpack_from('<QQI', cmd, pos + 32)
                align, reloff, nreloc, flags = struct.unpack_from('<4I', cmd, pos + 52)
                check(addr >= vmaddr and addr - vmaddr <= vmsize and length <= vmsize - (addr - vmaddr), 'Seção fora da memória de seu segmento.')
                if length and flags & 0xFF not in ZEROFILL:
                    region(offset, length, 'Seção')
                    check(fileoff <= offset and length <= fileoff + filesize - offset, 'Seção fora de seu segmento.')
                if nreloc:
                    region(reloff, nreloc * 8, 'Relocações')
        elif kind == 0x2:
            check(size == 24, 'LC_SYMTAB inválido.')
            symoff, nsyms, stroff, strsize = struct.unpack_from('<4I', cmd, 8)
            region(symoff, nsyms * 16, 'Símbolos')
            region(stroff, strsize, 'Strings')
        elif kind == 0xB:
            check(size == 80, 'LC_DYSYMTAB inválido.')
            fields = struct.unpack_from('<18I', cmd, 8)
            for index, item_size in ((6,8),(8,56),(10,4),(12,4),(14,8),(16,8)):
                region(fields[index], fields[index + 1] * item_size, 'Símbolos dinâmicos')
        elif kind in (0x22, 0x80000022):
            check(size == 48, 'LC_DYLD_INFO inválido.')
            values = struct.unpack_from('<10I', cmd, 8)
            for index in range(0,10,2):
                region(values[index], values[index+1], 'Dyld info')
        elif kind in LINKEDIT:
            check(size == 16, 'Comando LINKEDIT inválido.')
            region(*struct.unpack_from('<II', cmd, 8), 'LINKEDIT')
        elif kind == 0x2C:
            check(size == 24, 'LC_ENCRYPTION_INFO_64 inválido.')
            off, length, cryptid, pad = struct.unpack_from('<4I', cmd, 8)
            check(cryptid == 0, 'Executável declara cifragem ativa. O integrador não descriptografa IPA.')
            check(pad == 0, 'Padding de criptografia inválido.')
            region(off, length, 'Região de criptografia')
        elif kind == 0x32:
            check(size >= 24, 'LC_BUILD_VERSION truncado.')
            platform, minos, sdk, tools = struct.unpack_from('<4I', cmd, 8)
            check(size == 24 + tools * 8 and sdk >= minos, 'LC_BUILD_VERSION inválido.')
            platforms.append((platform, minos))
        elif kind == 0x25:
            check(size == 16, 'LC_VERSION_MIN_IPHONEOS inválido.')
            platforms.append((2, struct.unpack_from('<I', cmd, 8)[0]))
        elif kind == 0x1B:
            check(size == 24, 'LC_UUID inválido.')
            uuids.append(cmd[8:].hex())
        elif kind == 0x80000028:
            check(size == 24, 'LC_MAIN inválido.')
            entry = struct.unpack_from('<Q', cmd, 8)[0]
            check(end <= entry < len(data), 'Entry point fora do arquivo.')
            payloads.append(entry)
        elif kind in DYLIB or kind in (0xD, 0x8000001C, 0x27, 0xE, 0xF):
            command_name(cmd)
        else:
            check(kind in INLINE, f'Load command não suportado: {kind:#x}. Análise manual necessária.')
        commands.append(cmd)
        cursor += size
    check(cursor == end, 'sizeofcmds diverge da tabela.')
    check(len(platforms) == 1 and platforms[0][0] == 2, 'Plataforma precisa ser iPhoneOS; arm64 de simulador não serve.')
    check(len(uuids) <= 1, 'Múltiplos UUIDs no executável.')
    check(payloads, 'Nenhuma seção ou payload no arquivo.')
    return MachO(data, filetype, tuple(commands), end, min(payloads), platforms[0][1], uuids[0] if uuids else None)

def dylib_command(name):
    raw = name.encode('utf-8') + b'\0'
    size = (24 + len(raw) + 7) & ~7
    return struct.pack('<6I', 0xC, size, 24, 0, 0x10000, 0x10000) + raw + bytes(size - 24 - len(raw))

def rebuild(macho, commands):
    encoded = b''.join(commands)
    end = 32 + len(encoded)
    check(end <= macho.first_payload, 'Não há espaço legítimo no cabeçalho para SDKtools; integração recusada.')
    check(end <= macho.command_end or not any(macho.data[macho.command_end:end]), 'O crescimento do cabeçalho sobrescreveria dados não vazios.')
    result = bytearray(macho.data)
    struct.pack_into('<II', result, 16, len(commands), len(encoded))
    result[32:max(end, macho.command_end)] = encoded + bytes(max(end, macho.command_end) - end)
    return bytes(result)

def strip_signature(data):
    before = parse(data)
    return rebuild(before, [c for c in before.commands if struct.unpack_from('<I', c)[0] != 0x1D])

def inject(data):
    before = parse(data, 2)
    check(LOAD_PATH not in before.dependencies and not any('SDKtools.framework/' in p for p in before.dependencies), 'SDKtools já está integrado. Use a base original.')
    commands = [c for c in before.commands if struct.unpack_from('<I', c)[0] != 0x1D]
    commands.append(dylib_command(LOAD_PATH))
    result = rebuild(before, commands)
    after = parse(result, 2)
    check(after.dependencies == before.dependencies + (LOAD_PATH,), 'Ordinais das bibliotecas foram alterados.')
    check(before.of_type(0x19) == after.of_type(0x19), 'Segmentos foram alterados.')
    preserved = [c for c in before.commands if struct.unpack_from('<I', c)[0] != 0x1D]
    check(list(after.commands[:-1]) == preserved, 'Load commands existentes foram alterados.')
    start = max(before.command_end, after.command_end)
    check(result[start:] == data[start:], 'Payload do executável foi alterado.')
    return result, {'before_sha256': hashlib.sha256(data).hexdigest(), 'after_sha256': hashlib.sha256(result).hexdigest(), 'new_dependency': LOAD_PATH, 'existing_dependency_ordinals_preserved': True, 'segments_and_payload_preserved': True, 'removed_signature_commands': len(before.of_type(0x1D)), 'signature_blob': 'retained_unreferenced', 'available_header_padding': before.first_payload - before.command_end, 'runtime_tested': False}

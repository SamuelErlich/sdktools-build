#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdk-keyauth-crypto.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
sdk_path="$(xcrun --sdk macosx --show-sdk-path)"
target="$(uname -m)-apple-macosx11.0"
xcrun --sdk macosx clang -target "$target" -isysroot "$sdk_path" -Wall -Wextra -Werror \
  -c "$project_root/Tests/keyauth_crypto_test.m" -o "$test_workspace/test.o"
xcrun --sdk macosx swiftc -target "$target" -sdk "$sdk_path" -parse-as-library -O \
  -emit-object "$project_root/Sources/SDKtools/STKeyAuthCrypto.swift" -o "$test_workspace/crypto.o"
xcrun --sdk macosx swiftc -target "$target" -sdk "$sdk_path" -emit-executable \
  "$test_workspace/test.o" "$test_workspace/crypto.o" -o "$test_workspace/keyauth-crypto"
"$test_workspace/keyauth-crypto"

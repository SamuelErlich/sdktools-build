#!/usr/bin/env python3
"""Strict, offline SDKtools scene decoder. No network or app interaction.

JSONL output has one report header followed by one expanded web sample per line.
`order` describes nodes observed in that sample, not cards removed from a match.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
from typing import Any, Iterator

MAX_INPUT_BYTES = 64 * 1024 * 1024
MAX_SAMPLES = 720
MAX_CHAIN_DEPTH = 19
NODE_LIMITS = {2: 768, 3: 1536}
REQUIRED_NODE_FIELDS = frozenset({"nodeID", "index", "parent", "parentID"})
ENCODING_FIELDS = frozenset({"sceneNodes", "sceneNodesRefSequence", "sceneNodesDelta"})
NON_SCENE_STATUSES = frozenset({"evaluation_timeout", "evaluation_failed", "evaluation_exception",
    "probe_script_missing", "probe_context_unverified", "probe_namespace_conflict",
    "invalid_probe_result", "native_sample_payload_limit"})


class CaptureDecodeError(ValueError):
    """The capture is malformed or exceeds this decoder's explicit limits."""


def _fail(message: str) -> None:
    raise CaptureDecodeError(message)


def _integer(value: Any, name: str, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        _fail(f"{name} must be an integer >= {minimum}")
    return value


def _identifier(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 256:
        _fail(f"{name} must be a nonempty string of at most 256 characters")
    return value


def _context(sample: dict[str, Any]) -> tuple[str | None, str | None]:
    values = []
    for key in ("contextID", "webViewID"):
        value = sample.get(key)
        if value is not None:
            _identifier(value, key)
        values.append(value)
    return tuple(values)  # type: ignore[return-value]


def _validate_rows(rows: Any, limit: int) -> list[dict[str, Any]]:
    if not isinstance(rows, list) or len(rows) > limit:
        _fail(f"sceneNodes must be an array with at most {limit} nodes")
    seen: set[str] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or not REQUIRED_NODE_FIELDS <= row.keys():
            _fail(f"node {index}: missing nodeID/index/parent/parentID")
        node_id = _identifier(row["nodeID"], f"node {index} nodeID")
        if node_id in seen:
            _fail(f"duplicate nodeID: {node_id}")
        seen.add(node_id)
        if type(row["index"]) is not int or row["index"] != index:
            _fail(f"node {node_id}: index does not match array order")
        if index == 0:
            if row["parent"] is not None or row["parentID"] is not None:
                _fail("root parent and parentID must both be null")
        else:
            parent = _integer(row["parent"], f"node {node_id} parent")
            if parent >= index:
                _fail(f"node {node_id}: parent must precede child")
            if row["parentID"] != rows[parent]["nodeID"]:
                _fail(f"node {node_id}: parentID disagrees with parent index")
        if "depth" in row:
            depth = _integer(row["depth"], f"node {node_id} depth")
            if index == 0 and depth != 0:
                _fail("root depth must be zero")
            if index and "depth" in rows[row["parent"]]:
                if depth != rows[row["parent"]]["depth"] + 1:
                    _fail(f"node {node_id}: depth disagrees with parent")
    return rows


def _apply_delta(base: list[dict[str, Any]], delta: Any, limit: int) -> list[dict[str, Any]]:
    if not isinstance(delta, dict) or set(delta) != {"version", "order", "added", "changed"}:
        _fail("sceneNodesDelta must contain exactly version/order/added/changed")
    if type(delta["version"]) is not int or delta["version"] != 1:
        _fail("unsupported sceneNodesDelta version")
    order, added, changed = (delta[key] for key in ("order", "added", "changed"))
    if not all(isinstance(value, list) for value in (order, added, changed)):
        _fail("delta order, added and changed must be arrays")
    if max(len(order), len(added), len(changed)) > limit:
        _fail(f"delta arrays exceed {limit} nodes")
    order_ids = [_identifier(value, "delta order nodeID") for value in order]
    order_set = set(order_ids)
    if len(order_set) != len(order_ids):
        _fail("duplicate nodeID in delta order")
    nodes = {row["nodeID"]: row for row in base}
    base_ids = set(nodes)
    for row in added:
        if not isinstance(row, dict) or not REQUIRED_NODE_FIELDS <= row.keys():
            _fail("added node must be a complete row")
        node_id = _identifier(row["nodeID"], "added nodeID")
        if node_id in nodes:
            _fail(f"added nodeID already exists: {node_id}")
        if node_id not in order_set:
            _fail(f"added node absent from order: {node_id}")
        nodes[node_id] = deepcopy(row)
    patched: set[str] = set()
    for change in changed:
        if not isinstance(change, dict) or set(change) != {"nodeID", "set", "unset"}:
            _fail("changed row must contain exactly nodeID/set/unset")
        node_id = _identifier(change["nodeID"], "changed nodeID")
        if node_id not in base_ids or node_id not in order_set:
            _fail(f"changed node must be a retained base node: {node_id}")
        if node_id in patched:
            _fail(f"duplicate changed nodeID: {node_id}")
        patched.add(node_id)
        assignments, removals = change["set"], change["unset"]
        if not isinstance(assignments, dict) or not isinstance(removals, list):
            _fail("changed set must be an object and unset must be an array")
        if not all(isinstance(key, str) and key for key in assignments):
            _fail("set field names must be nonempty strings")
        if not all(isinstance(key, str) and key for key in removals):
            _fail("unset field names must be nonempty strings")
        if len(set(removals)) != len(removals):
            _fail("duplicate unset field")
        if "nodeID" in assignments or REQUIRED_NODE_FIELDS.intersection(removals):
            _fail("patch cannot change nodeID or remove required node fields")
        if set(assignments).intersection(removals):
            _fail("patch cannot set and unset the same field")
        if not assignments and not removals:
            _fail("empty changed patch")
        row = dict(nodes[node_id])
        for key in removals:
            if key not in row:
                _fail(f"cannot unset absent field {key} on node {node_id}")
            del row[key]
        row.update(deepcopy(assignments))
        nodes[node_id] = row
    unknown = order_set.difference(nodes)
    if unknown:
        _fail("delta order contains unknown nodeID")
    return _validate_rows([nodes[node_id] for node_id in order_ids], limit)


class SceneResolver:
    """Resolve a bounded ordered stream without retaining expanded output copies."""

    def __init__(self, schema_version: int):
        if type(schema_version) is not int or schema_version not in NODE_LIMITS:
            _fail("supported schemaVersion values are 2 and 3")
        self.schema_version = schema_version
        self.limit = NODE_LIMITS[schema_version]
        self._states: dict[int, tuple[Any, list[dict[str, Any]], int, str]] = {}
        self._last_sequence = 0
        self.counts = {"full": 0, "reference": 0, "delta": 0, "nonScene": 0}
        self.maximum_chain_depth = 0

    def expand(self, sample: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(sample, dict):
            _fail("web sample must be an object")
        sequence = _integer(sample.get("sequence"), "sample sequence", 1)
        if sequence <= self._last_sequence:
            _fail("sample sequences must be unique and strictly increasing")
        if sum(self.counts.values()) >= MAX_SAMPLES:
            _fail(f"capture exceeds {MAX_SAMPLES} web samples")
        scope = _context(sample)
        encoding = sample.get("sceneNodesEncoding")
        present_fields = ENCODING_FIELDS.intersection(sample)
        if "sceneNodesEncoding" not in sample and not present_fields and sample.get("status") in NON_SCENE_STATUSES:
            self._last_sequence = sequence
            self.counts["nonScene"] += 1
            return deepcopy(sample)
        if encoding not in {"full", "reference", "delta"}:
            _fail("unknown or missing sceneNodesEncoding")
        required = {"full": {"sceneNodes"}, "reference": {"sceneNodesRefSequence"},
                    "delta": {"sceneNodesRefSequence", "sceneNodesDelta"}}[encoding]
        if present_fields != required:
            _fail(f"ambiguous or incomplete {encoding} encoding fields")
        if encoding == "full":
            rows = deepcopy(_validate_rows(sample["sceneNodes"], self.limit))
            depth = 0
        else:
            if encoding == "delta" and self.schema_version != 3:
                _fail("delta encoding requires schemaVersion 3")
            reference = _integer(sample["sceneNodesRefSequence"], "reference sequence", 1)
            if reference >= sequence or reference not in self._states:
                _fail("forward or dangling sceneNodesRefSequence")
            base_scope, base_rows, base_depth, base_encoding = self._states[reference]
            if base_encoding == "reference":
                _fail("references must target a full or delta sample")
            if scope[0] is None or (self.schema_version == 3 and scope[1] is None) or scope != base_scope:
                _fail("scene reference crosses document or web view context")
            depth = base_depth + 1
            if self.schema_version == 3 and depth > MAX_CHAIN_DEPTH:
                _fail(f"scene reference chain exceeds {MAX_CHAIN_DEPTH}")
            rows = base_rows if encoding == "reference" else _apply_delta(base_rows, sample["sceneNodesDelta"], self.limit)
        cocos = sample.get("cocos")
        if isinstance(cocos, dict) and "nodeCount" in cocos:
            if _integer(cocos["nodeCount"], "cocos nodeCount") != len(rows):
                _fail("cocos nodeCount disagrees with reconstructed array")
        expanded = deepcopy({key: value for key, value in sample.items() if key not in ENCODING_FIELDS})
        expanded["sceneNodesEncoding"] = "full"
        expanded["sceneNodes"] = deepcopy(rows)
        # A reference can be diagnosed, but is never allowed as another base.
        self._states[sequence] = (scope, rows, depth, encoding)
        self._last_sequence = sequence
        self.counts[encoding] += 1
        self.maximum_chain_depth = max(self.maximum_chain_depth, depth)
        return expanded


def _report_samples(report: Any) -> list[dict[str, Any]]:
    if not isinstance(report, dict):
        _fail("capture must be a JSON object")
    samples = report.get("webSamples")
    if not isinstance(samples, list) or len(samples) > MAX_SAMPLES:
        _fail(f"webSamples must be an array with at most {MAX_SAMPLES} entries")
    return samples


def iter_scenes(report: dict[str, Any]) -> Iterator[dict[str, Any]]:
    """Yield expanded samples; all non-codec sample metadata is preserved."""
    samples = _report_samples(report)
    resolver = SceneResolver(report.get("schemaVersion"))
    for sample in samples:
        try:
            yield resolver.expand(sample)
        except CaptureDecodeError as error:
            sequence = sample.get("sequence", "?") if isinstance(sample, dict) else "?"
            raise CaptureDecodeError(f"sample {sequence}: {error}") from error


def _header(report: dict[str, Any], output_format: str) -> dict[str, Any]:
    header = deepcopy({key: value for key, value in report.items() if key != "webSamples"})
    header["schemaVersion"] = 3
    header["decoderTransform"] = {
        "name": "SDKtools offline scene expansion", "version": 1,
        "sourceSchemaVersion": report["schemaVersion"], "outputFormat": output_format,
        "originalSampleMetadataPreserved": True,
        "originalCaptureStatisticsPreserved": True,
        "captureByteStatisticsDescribeOriginalFile": True,
        "membershipMeaning": "nodes_observed_in_this_sample_not_cards_removed",
    }
    return header


def resolve(report: dict[str, Any]) -> dict[str, Any]:
    """Return a schema-3 full-expanded report, preserving original report metadata."""
    samples = list(iter_scenes(report))
    expanded = _header(report, "json")
    expanded["webSamples"] = samples
    return expanded


def summarize(report: dict[str, Any]) -> dict[str, Any]:
    resolver = SceneResolver(report.get("schemaVersion"))
    maximum_nodes = truncated = 0
    for sample in _report_samples(report):
        expanded = resolver.expand(sample)
        maximum_nodes = max(maximum_nodes, len(expanded.get("sceneNodes", [])))
        truncated += int(expanded.get("cocos", {}).get("truncated") is True)
    return {"samples": sum(resolver.counts.values()), "encodings": resolver.counts,
            "maximumNodes": maximum_nodes, "maximumChainDepth": resolver.maximum_chain_depth,
            "truncatedSamples": truncated, "membershipMeaning": "observed_nodes_only"}


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result = {}
    for key, value in pairs:
        if key in result:
            _fail(f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def load_capture(path: Path, maximum_bytes: int = MAX_INPUT_BYTES) -> dict[str, Any]:
    with path.open("rb") as stream:
        raw = stream.read(maximum_bytes + 1)
    if len(raw) > maximum_bytes:
        _fail(f"input exceeds {maximum_bytes} bytes")
    def reject_constant(value: str) -> None:
        _fail(f"non-JSON numeric constant: {value}")
    try:
        report = json.loads(raw, object_pairs_hook=_unique_object, parse_constant=reject_constant)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as error:
        raise CaptureDecodeError(f"invalid JSON: {error}") from error
    _report_samples(report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path, nargs="?", help="new output path; existing files are never replaced")
    parser.add_argument("--format", choices=("jsonl", "json"), default="jsonl")
    parser.add_argument("--summary", action="store_true", help="print validation summary; output path is optional")
    parser.add_argument("--max-input-mib", type=int, default=64, help="input size bound (1–256 MiB; default 64)")
    args = parser.parse_args(argv)
    if not 1 <= args.max_input_mib <= 256:
        parser.error("--max-input-mib must be between 1 and 256")
    if args.output is None and not args.summary:
        parser.error("provide a new output path or use --summary")
    output_created = False
    try:
        if args.output is not None:
            if args.input.resolve() == args.output.resolve():
                _fail("output must differ from input")
            if args.output.exists() or args.output.is_symlink():
                _fail("output already exists; choose a new path")
        report = load_capture(args.input, args.max_input_mib * 1024 * 1024)
        # Validate completely before writing any expanded output.
        summary = summarize(report)
        if args.output is not None:
            with args.output.open("x", encoding="utf-8", newline="\n") as stream:
                output_created = True
                if args.format == "jsonl":
                    header = {"recordType": "capture", "report": _header(report, "jsonl")}
                    stream.write(json.dumps(header, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n")
                    for sample in iter_scenes(report):
                        stream.write(json.dumps({"recordType": "webSample", "sample": sample}, ensure_ascii=False,
                                                allow_nan=False, separators=(",", ":")) + "\n")
                else:
                    json.dump(resolve(report), stream, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
                    stream.write("\n")
        if args.summary:
            print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    except (OSError, CaptureDecodeError, ValueError, RecursionError) as error:
        if output_created and args.output is not None:
            args.output.unlink(missing_ok=True)
        print(f"decode_capture: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

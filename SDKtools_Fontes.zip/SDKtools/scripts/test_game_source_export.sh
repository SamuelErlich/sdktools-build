#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-source-io.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror "$project_root/Tests/game_source_io_test.c" -o "$test_workspace/game-source-test"
"$test_workspace/game-source-test"

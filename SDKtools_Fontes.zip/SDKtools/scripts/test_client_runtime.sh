#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-client-runtime.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
python3 - "$project_root" "$test_workspace" <<'PY'
from pathlib import Path
import sys
root, out = map(Path, sys.argv[1:])
source = (root/'Sources/SDKtools/STClientInteraction.m').read_text()
source = '\n'.join(line for line in source.splitlines() if not line.startswith('#import'))
(out/'interaction.inc').write_text(source)
runtime = (root/'Sources/SDKtools/STBilliardsRuntime.m').read_text()
helpers = runtime[runtime.index('static BOOL STBLShotFiniteNumber('):runtime.index('static NSError *STBLError(')]
(out/'shot_helpers.h').write_text(helpers)
methods = []
for signature in ['setAutomationMode:(NSUInteger)mode', 'pauseAutomationWithReason:(NSString *)reason',
                  'suspendForInteraction', 'runAutomationForSnapshot:(NSDictionary *)snapshot']:
    start = runtime.index('- (void)'+signature+' {')
    end = runtime.index('\n- (', start+1)
    methods.append(runtime[start:end])
(out/'automation.inc').write_text('\n'.join(methods))
PY
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
  -Werror=implicit-function-declaration -framework Foundation -framework CoreFoundation \
  -I "$test_workspace" -I "$project_root/Sources/SDKtools" \
  "$project_root/Tests/client_runtime_test.m" -o "$test_workspace/client-runtime"
"$test_workspace/client-runtime"

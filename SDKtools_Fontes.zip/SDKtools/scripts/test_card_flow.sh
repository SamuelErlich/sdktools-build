#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation e CoreFoundation.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-card-flow.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
cd "$project_root"
xcrun --sdk macosx clang -fobjc-arc -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation \
  Tests/card_flow_sanitizer_test.m -o "$test_workspace/card-flow-test"
"$test_workspace/card-flow-test"

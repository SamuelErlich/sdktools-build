#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdk-localization.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra -Werror=implicit-function-declaration \
  -framework Foundation -framework CoreFoundation "$project_root/Tests/localization_test.m" "$project_root/Sources/SDKtools/STLocalization.m" -o "$test_workspace/localization"
"$test_workspace/localization" "$project_root/Resources/Brand/menu-localizations.json"

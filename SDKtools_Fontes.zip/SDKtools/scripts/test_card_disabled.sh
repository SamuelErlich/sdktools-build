#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-card-disabled-test.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
cd "$project_root"
xcrun --sdk macosx clang -DST_CARD_GAME_FEATURE_ENABLED=0 -fobjc-arc -fmodules -Wall -Wextra \
  -framework Foundation Tests/card_early_disabled_test.m Sources/SDKtools/STCardEarlyCapture.m \
  -o "$test_workspace/card-early-disabled-test"
"$test_workspace/card-early-disabled-test"

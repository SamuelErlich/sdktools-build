#!/bin/bash
set -euo pipefail
fail() { printf '%s\n' "$*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail 'A compilação exige macOS com Xcode e iOS SDK. Use o workflow do GitHub Actions.'
project_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$project_root"
build_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-build.XXXXXX")"
trap 'rm -rf "$build_workspace"' EXIT
sdk_path="$(xcrun --sdk iphoneos --show-sdk-path)"
xcodebuild -version
xcrun --sdk iphoneos --show-sdk-version
python3 -m unittest discover -s Tests -p 'test_*.py' -v
python3 scripts/test_client_context.py
python3 scripts/test_billiards_probe.py
python3 scripts/test_billiards_strategy.py
python3 scripts/test_billiards_lua_boundary.py
command -v node >/dev/null || fail 'Node.js necessário para testar o probe WebKit.'
node --test Tests/*.test.cjs
bash scripts/test_localization.sh
bash scripts/test_client_game_policy.sh
bash scripts/test_client_runtime.sh
bash scripts/test_client_host.sh
bash scripts/test_native_action_policy.sh
bash scripts/test_game_source_export.sh
bash scripts/test_new_game_capture.sh
bash scripts/test_billiards_live_policy.sh
bash scripts/test_billiards_numeric_policy.sh
bash scripts/test_billiards_live_snapshot.sh
bash scripts/test_billiards_resource_io.sh
bash scripts/test_billiards_resource_foundation.sh
bash scripts/test_scene_codec.sh
bash scripts/test_web_probe.sh
bash scripts/test_autoplay_bridge.sh
bash scripts/test_lan.sh
bash scripts/test_card_hints_bridge.sh
bash scripts/test_card_investigation.sh
bash scripts/test_card_flow.sh
bash scripts/test_card_early.sh
bash scripts/test_card_live.sh
bash scripts/test_card_disabled.sh
bash scripts/test_game_source_foundation.sh
framework="$build_workspace/SDKtools.framework"
mkdir -p "$framework/Headers" "$framework/Modules" "$project_root/dist"
[[ ! -e dist/SDKtools.framework && ! -e dist/SDKtools_unsigned.framework.zip ]] || fail 'dist já contém build. Remova a saída anterior antes de compilar novamente.'
sources=( Sources/SDKtools/*.m )
[[ -f "${sources[0]}" ]] || fail 'Nenhum fonte Objective-C encontrado.'
xcrun --sdk iphoneos clang \
  -target arm64-apple-ios15.0 -isysroot "$sdk_path" \
  -dynamiclib -fobjc-arc -fmodules -O2 -g \
  -Wall -Wextra -Werror=implicit-function-declaration \
  -I Sources/SDKtools -install_name '@rpath/SDKtools.framework/SDKtools' \
  -Wl,-rpath,@loader_path/Frameworks -Wl,-headerpad_max_install_names \
  -Wl,-no_adhoc_codesign -current_version 3.23.15 -compatibility_version 1.0.0 \
  -framework Foundation -framework CoreFoundation -framework UIKit -framework WebKit -framework ReplayKit \
  -framework QuartzCore -framework CoreText -framework Security \
  "${sources[@]}" -o "$framework/SDKtools"
xcrun dsymutil "$framework/SDKtools" -o "$build_workspace/SDKtools.framework.dSYM"
[[ -f Resources/scene_probe.js ]] || fail 'O probe JavaScript está ausente.'
[[ -f Resources/return_tool.js ]] || fail 'O recurso dos poderes está ausente.'
[[ -f Resources/autoplay_tool.js && -f Resources/autoplay_planner.js && -f Resources/autoplay_extended.js && -f Resources/autoplay_powers.js ]] || fail 'Os recursos de autoplay estão ausentes.'
[[ -f Resources/alpaca_fast.js ]] || fail 'O coordenador Super Fast está ausente.'
[[ -f Resources/alpaca_snapshot.js ]] || fail 'O leitor de snapshot do Alpaca está ausente.'
[[ -f Resources/alpaca_covered.js ]] || fail 'O observador experimental das camadas do Alpaca está ausente.'
[[ -f Resources/xray_overlay.js && -f Resources/warehouse_tool.js && -f Resources/warehouse_test.js ]] || fail 'Os recursos de Raio X e armazém estão ausentes.'
[[ -f Resources/card_hints.js && -f Resources/card_root.js && -f Resources/card_sampler.js ]] || fail 'O recurso Ver cartas está ausente.'
[[ -f Resources/card_flow.js && -f Resources/card_early.js ]] || fail 'O exportador da origem das cartas está ausente.'
[[ -f Resources/card_probe.js ]] || fail 'O recurso Investigar cartas está ausente.'
[[ -f Resources/billiards_probe.lua && -f Resources/billiards_strategy.lua ]] || fail 'O leitor Lua do bilhar está ausente.'
python3 - "$framework" <<'PYRES'
from pathlib import Path
import shutil, sys
root = Path('Resources')
output = Path(sys.argv[1])
for item in root.rglob('*'):
    if item.is_symlink() or not (item.is_file() or item.is_dir()):
        raise SystemExit('Recurso deve ser arquivo ou pasta regular: ' + str(item))
    target = output / item.relative_to(root)
    if item.is_dir():
        target.mkdir(parents=True, exist_ok=True)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(item, target)
PYRES
cp Sources/SDKtools/SDKtools.h "$framework/Headers/SDKtools.h"
printf '%s\n' 'framework module SDKtools { umbrella header "SDKtools.h" export * module * { export * } }' > "$framework/Modules/module.modulemap"
python3 - "$framework" <<'PY'
from pathlib import Path
import sys
sys.path.insert(0, 'scripts')
from integrate_ipa import framework_files, load_identity
_, result = framework_files(Path(sys.argv[1]), load_identity(Path('config/base_identity.json')))
print(result)
PY
xcrun lipo "$framework/SDKtools" -verify_arch arm64
xcrun otool -L "$framework/SDKtools"
COPYFILE_DISABLE=1 /usr/bin/ditto -c -k --keepParent --norsrc --noextattr "$framework" "$build_workspace/SDKtools_unsigned.framework.zip"
COPYFILE_DISABLE=1 /usr/bin/ditto -c -k --keepParent --norsrc --noextattr "$build_workspace/SDKtools.framework.dSYM" "$build_workspace/SDKtools.framework.dSYM.zip"
mv "$framework" dist/SDKtools.framework
mv "$build_workspace/SDKtools_unsigned.framework.zip" dist/
mv "$build_workspace/SDKtools.framework.dSYM.zip" dist/
printf '%s\n' 'Framework iPhoneOS compilado. A integração e a assinatura ainda são etapas separadas.'

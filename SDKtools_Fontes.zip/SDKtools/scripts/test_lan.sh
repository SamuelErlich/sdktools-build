#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'LAN Foundation tests require macOS.' >&2; exit 1; }
root="$(cd "$(dirname "$0")/.." && pwd)"
workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-lan.XXXXXX")"
trap 'rm -rf "$workspace"' EXIT
cd "$root"
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra -Werror=implicit-function-declaration \
  -framework Foundation -framework CoreFoundation -framework Security Tests/lan_server_test.m -o "$workspace/server"
"$workspace/server"
python3 - "$workspace" <<'PY'
from pathlib import Path
import sys
s=Path('Sources/SDKtools/STLANRecorder.inc').read_text(encoding='utf-8')
start=s.index('- (NSUInteger)autoplaySpeedLevel {')
end=s.index('- (NSDictionary *)lanControlSnapshot {',start)
speed=s[start:end]
auto=Path('Sources/SDKtools/STAutoplayRecorder.inc').read_text(encoding='utf-8')
batch_start=auto.index('- (void)setAutoplayCardsPerBatch:')
batch_end=auto.index('- (void)setExtendedPlanning:',batch_start)
Path(sys.argv[1],'lan_speed.inc').write_text(speed+auto[batch_start:batch_end],encoding='utf-8')
start=s.index('- (NSDictionary *)lanDownloadChunk:')
end=s.index('- (BOOL)lanSharingEnabled',start)
Path(sys.argv[1],'lan_export.inc').write_text(s[start:end],encoding='utf-8')
PY
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra -framework Foundation \
  -I "$workspace" Tests/lan_speed_test.m -o "$workspace/speed"
"$workspace/speed"
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra -framework Foundation \
  -I "$workspace" Tests/lan_export_test.m -o "$workspace/export"
"$workspace/export"

#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdk-keyauth-manager.XXXXXX")"
trap 'rm -rf "$workspace"' EXIT
sdk="$(xcrun --sdk macosx --show-sdk-path)"
target="$(uname -m)-apple-macosx11.0"
xcrun --sdk macosx clang -target "$target" -isysroot "$sdk" -fobjc-arc -fblocks -fmodules -Wall -Wextra -Werror=implicit-function-declaration \
  -I "$root/Sources/SDKtools" -c "$root/Tests/keyauth_manager_test.m" -o "$workspace/test.o"
xcrun --sdk macosx swiftc -target "$target" -sdk "$sdk" -parse-as-library -O -emit-object "$root/Sources/SDKtools/STKeyAuthCrypto.swift" -o "$workspace/crypto.o"
xcrun --sdk macosx swiftc -target "$target" -sdk "$sdk" -emit-executable -framework Foundation -framework CoreFoundation -framework Security \
  "$workspace/test.o" "$workspace/crypto.o" -o "$workspace/manager"
"$workspace/manager" "$root/Tests/fixtures/keyauth-signed-responses.json"

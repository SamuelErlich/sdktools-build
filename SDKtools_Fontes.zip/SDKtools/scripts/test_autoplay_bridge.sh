#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation e CoreFoundation.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-auto-test.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
cd "$project_root"
xcrun --sdk macosx clang -fobjc-arc -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation \
  Tests/autoplay_bridge_test.m -o "$test_workspace/autoplay-bridge-test"
"$test_workspace/autoplay-bridge-test"
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation \
  Tests/autoplay_lifecycle_test.m -o "$test_workspace/autoplay-lifecycle"
"$test_workspace/autoplay-lifecycle"

# Extract the production native experiment coordinator verbatim for Foundation tests.
python3 - "$project_root" "$test_workspace" <<'PYCODE'
from pathlib import Path
import sys
root,out=map(Path,sys.argv[1:])
source=(root/'Sources/SDKtools/STAutoplayRecorder.inc').read_text(encoding='utf-8')
start=source.index('- (NSString *)coveredAttemptStatusText {')
end=source.index('- (BOOL)performCoveredAttempt {',start)
methods=source[start:end]
gate_start=source.index('- (BOOL)autoplayStartBlockedByEvaluation {')
gate_end=source.index('- (NSString *)autoplayStatusText {',gate_start)
methods=source[gate_start:gate_end]+methods
assert '- (void)acceptCoveredResult:' in methods
(out/'covered_recorder.inc').write_text(methods,encoding='utf-8')
recorder=(root/'Sources/SDKtools/STRecorder.m').read_text(encoding='utf-8')
start=recorder.index('- (NSURL *)writeCoveredAttemptReportWithError:')
end=recorder.index('- (NSURL *)writeReportWithError:',start)
(out/'covered_report_recorder.inc').write_text(recorder[start:end],encoding='utf-8')
PYCODE
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation -I "$test_workspace" \
  Tests/covered_recorder_test.m -o "$test_workspace/covered-recorder"
"$test_workspace/covered-recorder"

# Native-only serializer/writer, shared verbatim with STRecorder. No WebKit/game.
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation -I "$test_workspace" \
  Tests/covered_report_test.m -o "$test_workspace/covered-report"
"$test_workspace/covered-report"

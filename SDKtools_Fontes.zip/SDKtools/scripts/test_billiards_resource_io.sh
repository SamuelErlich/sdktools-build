#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-billiards-io.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror "$project_root/Tests/test_billiards_resource_io.c" -o "$test_workspace/billiards-resource-test"
"$test_workspace/billiards-resource-test" "$project_root/Tests/fixtures/billiard_manifest_baseline_v1047.svga"

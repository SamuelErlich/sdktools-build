#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdk-client-policy.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror "$project_root/Tests/client_game_policy_test.c" -o "$test_workspace/policy"
"$test_workspace/policy"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror "$project_root/Tests/compact_menu_layout_test.c" -o "$test_workspace/layout"
"$test_workspace/layout"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror "$project_root/Tests/floating_autoplay_layout_test.c" -o "$test_workspace/floating-layout"
"$test_workspace/floating-layout"

#!/usr/bin/env python3
"""Integrate SDKtools into the exact audited IPA; preserve the input unchanged.

Python 3.10+, stdlib only. This does not sign, install, decrypt or execute an app.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import stat
import sys
import tempfile
import unicodedata
import zipfile

from macho import parse, inject, strip_signature, command_name, MachOError, INSTALL_NAME

MAX_IPA = 2 * 1024**3
MAX_MEMBER = 768 * 1024**2
MAX_TOTAL = 5 * 1024**3
MAX_ENTRIES = 50000
MAX_CENTRAL = 64 * 1024**2

class IntegrationError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise IntegrationError(message)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()

def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()

def regular(path, limit):
    require(path.is_file() and not path.is_symlink(), 'É necessário arquivo regular: ' + str(path))
    require(path.stat().st_size <= limit, 'Arquivo excede o limite: ' + str(path))

def preflight_zip(path):
    """Bound central directory before ZipFile allocates one object per member."""
    import struct
    regular(path, MAX_IPA)
    length = path.stat().st_size
    with path.open('rb') as stream:
        stream.seek(max(0, length - 65557))
        tail = stream.read()
    pos = tail.rfind(b'PK\x05\x06')
    require(pos >= 0 and len(tail) - pos >= 22, 'ZIP sem diretório central válido.')
    _, disk, central_disk, on_disk, count, size, offset, comment = struct.unpack_from('<4s4H2IH', tail, pos)
    absolute = length - len(tail) + pos
    require(pos + 22 + comment == len(tail), 'ZIP possui dados após o comentário ou EOCD ambíguo.')
    require(disk == central_disk == 0 and on_disk == count, 'ZIP multidisco não é suportado.')
    require(count not in (0, 0xFFFF) and size != 0xFFFFFFFF and offset != 0xFFFFFFFF, 'ZIP64 ou ZIP vazio não é suportado.')
    require(count <= MAX_ENTRIES and size <= MAX_CENTRAL and offset + size == absolute, 'Diretório central ZIP inválido ou excessivo.')

def checked_entries(archive):
    entries = archive.infolist()
    require(0 < len(entries) <= MAX_ENTRIES, 'Quantidade de entradas ZIP inválida.')
    seen, total = {}, 0
    for entry in entries:
        raw = entry.filename
        require(raw == entry.orig_filename, 'Nome ZIP contém NUL ou normalização implícita.')
        clean = raw.rstrip('/') if entry.is_dir() else raw
        require(raw and '\\' not in raw and ':' not in raw and not any(ord(c) < 32 or ord(c) == 127 for c in raw), 'Nome ZIP inseguro.')
        require(len(clean) <= 4096 and not clean.startswith('/') and all(p not in ('', '.', '..') for p in clean.split('/')) and len(clean.split('/')) <= 128, 'Caminho ZIP inseguro: ' + raw)
        key = unicodedata.normalize('NFC', clean).casefold()
        require(key not in seen, 'Caminho duplicado ou ambíguo: ' + raw)
        mode = entry.external_attr >> 16
        kind = stat.S_IFMT(mode)
        require(kind in (0, stat.S_IFDIR, stat.S_IFREG), 'Link ou arquivo especial não aceito: ' + raw)
        require(not (kind == stat.S_IFDIR and not entry.is_dir()) and not (kind == stat.S_IFREG and entry.is_dir()), 'Tipo ZIP inconsistente.')
        require(not entry.flag_bits & 1 and entry.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), 'ZIP cifrado ou compressão não suportada.')
        require(0 <= entry.file_size <= MAX_MEMBER and (not entry.is_dir() or entry.file_size == 0), 'Tamanho ZIP inválido.')
        total += entry.file_size
        require(total <= MAX_TOTAL, 'Tamanho expandido excessivo.')
        seen[key] = entry.is_dir()
    for key in seen:
        parts = key.split('/')
        for index in range(1, len(parts)):
            parent = '/'.join(parts[:index])
            require(parent not in seen or seen[parent], 'Arquivo usado como pasta no ZIP.')
    return entries

def read_member(archive, name, limit):
    entry = archive.getinfo(name)
    require(entry.file_size <= limit, 'Entrada excede limite de leitura: ' + name)
    with archive.open(entry) as stream:
        data = stream.read(limit + 1)
    require(len(data) == entry.file_size and len(data) <= limit, 'Entrada truncada ou excessiva.')
    return data

def load_identity(path):
    regular(path, 16384)
    value = json.loads(path.read_text())
    for name in ('ipa_sha256', 'executable_sha256'):
        require(isinstance(value.get(name), str) and len(value[name]) == 64 and all(c in '0123456789abcdef' for c in value[name]), 'Identidade incompleta: ' + name)
    require(isinstance(value.get('ipa_bytes'), int) and value['ipa_bytes'] > 0, 'Tamanho esperado do IPA ausente.')
    require(value.get('minimum_ios') == '15.0', 'Este projeto exige iOS mínimo 15.0.')
    return value

def framework_files(path, expected_identity=None):
    require(path.name == 'SDKtools.framework' and path.is_dir() and not path.is_symlink(), 'Informe SDKtools.framework compilado.')
    files, seen, total = {}, set(), 0
    for entry in sorted(path.rglob('*')):
        require(not entry.is_symlink() and (entry.is_file() or entry.is_dir()), 'Link/arquivo especial no framework.')
        name = entry.relative_to(path).as_posix()
        key = unicodedata.normalize('NFC', name).casefold()
        require(key not in seen and not any(ord(c) < 32 for c in name) and ':' not in name and '\\' not in name, 'Nome ambíguo no framework.')
        seen.add(key)
        require(len(seen) <= 1000, 'Framework com entradas demais.')
        if entry.is_file():
            total += entry.stat().st_size
            require(total <= 64 * 1024**2, 'Framework excessivo.')
            files[name] = entry.read_bytes()
    require('SDKtools' in files and 'Info.plist' in files, 'Framework incompleto.')
    info = plistlib.loads(files['Info.plist'])
    require(info.get('CFBundleExecutable') == 'SDKtools' and info.get('CFBundlePackageType') == 'FMWK' and info.get('CFBundleSupportedPlatforms') == ['iPhoneOS'] and info.get('MinimumOSVersion') == '15.0', 'Info.plist do framework incompatível.')
    require(info.get('CFBundleShortVersionString') == '2.1' and info.get('CFBundleVersion') == '3', 'Este pacote exige SDKtools 2.1, build 3. Framework de outra versão recusado.')
    target = {}
    for plist_key, identity_key in [('SDKToolsTargetBundleIdentifier', 'bundle_id'), ('SDKToolsTargetVersion', 'version'), ('SDKToolsTargetBuild', 'build'), ('SDKToolsTargetExecutable', 'executable')]:
        value = info.get(plist_key)
        require(isinstance(value, str) and bool(value), 'Framework sem identidade de destino: ' + plist_key)
        target[identity_key] = value
        if expected_identity is not None:
            require(value == expected_identity.get(identity_key), 'Framework foi preparado para outra base: ' + plist_key)
    binary = parse(files['SDKtools'], 6)
    require(binary.minos == 0xF0000, 'Framework deve ser compilado para mínimo iOS 15.0.')
    require(len(binary.of_type(0xD)) == 1 and command_name(binary.of_type(0xD)[0]) == INSTALL_NAME, 'Install name do framework inválido.')
    require(binary.uuid is not None, 'Framework sem UUID compilado.')
    require(all(p.startswith(('/System/Library/', '/usr/lib/')) for p in binary.dependencies), 'Framework possui dependência não incorporada.')
    files['SDKtools'] = strip_signature(files['SDKtools'])
    return files, {'version': info.get('CFBundleShortVersionString'), 'build': info.get('CFBundleVersion'), 'binary_sha256': hash_bytes(files['SDKtools']), 'uuid': binary.uuid, 'platform': 'iPhoneOS arm64', 'minimum_ios': '15.0', 'target': target}

def fresh(path):
    require(not path.exists() and not path.is_symlink(), 'Saída já existe: ' + str(path))
    require(path.parent.is_dir(), 'Pasta de saída não existe: ' + str(path.parent))

def publish(source, target):
    # Hard-link is atomic and refuses replacement. The temp files are created
    # in the same output directory, so filesystem boundaries cannot interfere.
    os.link(source, target)

def integrate(ipa, framework, identity_path, output):
    identity = load_identity(identity_path)
    regular(ipa, MAX_IPA)
    require(ipa.stat().st_size == identity['ipa_bytes'] and digest(ipa) == identity['ipa_sha256'], 'IPA diferente da base analisada. Use os bytes originais, antes de reassinar.')
    require(output.suffix.lower() == '.ipa', 'A saída precisa terminar em .ipa.')
    report_path = output.with_suffix('.manifest.json')
    fresh(output); fresh(report_path)
    files, framework_info = framework_files(framework, identity)
    preflight_zip(ipa)
    removed, preserved, original_hashes, permission_changes = [], 0, {}, []
    temps, published = [], []
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, suffix='.ipa.tmp', delete=False) as tmp:
            temporary = Path(tmp.name)
        temps.append(temporary)
        with zipfile.ZipFile(ipa) as source:
            entries = checked_entries(source)
            app = identity['app_path']
            plist_name, executable = app + '/Info.plist', app + '/' + identity['executable']
            plists = [e.filename for e in entries if len(e.filename.split('/')) == 3 and e.filename.startswith('Payload/') and e.filename.endswith('.app/Info.plist')]
            require(plists == [plist_name], 'Payload contém app principal inesperado.')
            info = plistlib.loads(read_member(source, plist_name, 2 * 1024**2))
            for key, field in [('CFBundleIdentifier', 'bundle_id'), ('CFBundleShortVersionString', 'version'), ('CFBundleVersion', 'build'), ('CFBundleExecutable', 'executable')]:
                require(info.get(key) == identity[field], 'Identidade do app diverge: ' + key)
            require(info.get('MinimumOSVersion') == identity['minimum_ios'], 'MinimumOSVersion do app diverge.')
            original = read_member(source, executable, MAX_MEMBER)
            require(hash_bytes(original) == identity['executable_sha256'], 'Hash do executável diverge.')
            patched, patch_report = inject(original)
            require(parse(original).minos <= 0xF0000, 'O executável exige iOS acima do declarado.')
            prefix = app + '/Frameworks/SDKtools.framework/'
            require(not any(e.filename.startswith(prefix) for e in entries), 'A base já contém SDKtools.')
            with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=False) as target:
                for entry in entries:
                    components = entry.filename.split('/')
                    # The app and its nested components must be re-signed by the
                    # user's signer; old profiles and resource seals are stale.
                    if '_CodeSignature' in components or components[-1] == 'embedded.mobileprovision':
                        removed.append(entry.filename)
                        continue
                    if entry.is_dir():
                        target.writestr(entry, b'')
                        continue
                    meta = zipfile.ZipInfo(entry.filename, entry.date_time)
                    meta.create_system = 3
                    mode = entry.external_attr >> 16
                    permissions = (mode & 0o777) if (mode & 0o777) else 0o644
                    if entry.filename == executable:
                        permissions |= 0o111
                    if permissions != (mode & 0o777):
                        permission_changes.append({'path': entry.filename, 'before': oct(mode & 0o777), 'after': oct(permissions)})
                    meta.external_attr = (stat.S_IFREG | permissions) << 16
                    meta.compress_type = zipfile.ZIP_DEFLATED
                    hasher, size = hashlib.sha256(), 0
                    with target.open(meta, 'w') as writer:
                        if entry.filename == executable:
                            writer.write(patched)
                            hasher.update(patched)
                            size = len(patched)
                        else:
                            with source.open(entry) as reader:
                                for block in iter(lambda: reader.read(1024**2), b''):
                                    size += len(block)
                                    require(size <= entry.file_size, 'Entrada ultrapassa tamanho declarado.')
                                    hasher.update(block); writer.write(block)
                            preserved += 1
                    require(size == entry.file_size, 'Tamanho do arquivo mudou inesperadamente.')
                    original_hashes[entry.filename] = hasher.hexdigest()
                for name, data in files.items():
                    meta = zipfile.ZipInfo(prefix + name)
                    meta.create_system = 3
                    meta.compress_type = zipfile.ZIP_DEFLATED
                    meta.external_attr = (stat.S_IFREG | (0o755 if name == 'SDKtools' else 0o644)) << 16
                    target.writestr(meta, data)
                    original_hashes[prefix + name] = hash_bytes(data)
        # Re-open and verify every output payload against its source or precise
        # intentional replacement, including ZIP CRCs and executable mode.
        preflight_zip(temporary)
        with zipfile.ZipFile(temporary) as check_zip:
            checked_entries(check_zip)
            actual = {e.filename for e in check_zip.infolist() if not e.is_dir()}
            require(actual == set(original_hashes), 'Inventário do IPA final diverge.')
            for name, expected in original_hashes.items():
                h = hashlib.sha256()
                with check_zip.open(name) as stream:
                    for block in iter(lambda: stream.read(1024**2), b''):
                        h.update(block)
                require(h.hexdigest() == expected, 'Falha na verificação final: ' + name)
        result = {'schema': 'SDKtools.Integration.v1', 'created_utc': datetime.now(timezone.utc).isoformat(), 'base': identity, 'framework': framework_info, 'executable_patch': patch_report, 'preserved_file_count': preserved, 'permission_changes': permission_changes, 'removed_signing_metadata': removed, 'output_sha256': digest(temporary), 'output_bytes': temporary.stat().st_size, 'signing_required': True, 'runtime_tested': False, 'note': 'Reassinar aplicativo e componentes aninhados. Não houve descriptografia nem teste no iPhone.'}
        with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=output.parent, suffix='.manifest.tmp', delete=False) as stream:
            manifest = Path(stream.name); temps.append(manifest)
            json.dump(result, stream, ensure_ascii=False, indent=2); stream.write('\n')
            stream.flush(); os.fsync(stream.fileno())
        publish(temporary, output); published.append(output)
        publish(manifest, report_path); published.append(report_path)
        return result
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        for path in temps:
            path.unlink(missing_ok=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ipa', type=Path, required=True)
    parser.add_argument('--framework', type=Path, required=True)
    parser.add_argument('--identity', type=Path, default=Path(__file__).resolve().parents[1] / 'config/base_identity.json')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = integrate(args.ipa, args.framework, args.identity, args.output)
    except (IntegrationError, MachOError, OSError, ValueError, KeyError, zipfile.BadZipFile, RuntimeError) as error:
        print('Integração interrompida: ' + str(error), file=sys.stderr)
        return 1
    print(json.dumps({'output': str(args.output), 'sha256': result['output_sha256'], 'signing_required': True, 'runtime_tested': False}, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

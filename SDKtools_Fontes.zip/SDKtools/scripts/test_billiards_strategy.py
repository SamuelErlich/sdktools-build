"""Real Lua 5.3: pure strategy + opt-in controller with synthetic Unity only.

An explicit SDKTOOLS_TEST_LUPA_PATH supports the isolated Windows test runtime.
CI uses the same Lua 5.3 C library as the existing observer suite. No game code
or executable is run, no device/server behavior is inferred from these tests.
"""
from pathlib import Path
import json, os, sys
ROOT=Path(__file__).resolve().parents[1]
STRATEGY=ROOT/'Resources/billiards_strategy.lua'
PROBE=ROOT/'Resources/billiards_probe.lua'
FIXTURE=ROOT/'Tests/test_billiards_strategy.lua'

def execute(source,*args):
    explicit=os.environ.get('SDKTOOLS_TEST_LUPA_PATH')
    if explicit:
        sys.path.insert(0,explicit)
        from lupa.lua53 import LuaRuntime
        return LuaRuntime(unpack_returned_tuples=True).execute(source,*args)
    from test_billiards_probe import LUA,lua_string
    state=LUA.luaL_newstate()
    if not state: raise RuntimeError('Lua state unavailable')
    try:
        LUA.luaL_openlibs(state)
        b=source.encode();status=LUA.luaL_loadbufferx(state,b,len(b),b'@strategy_tests',b't')
        if status: raise AssertionError(lua_string(state))
        for a in args:
            b=a.encode();LUA.lua_pushlstring(state,b,len(b))
        if LUA.lua_pcallk(state,len(args),1,0,0,None):raise AssertionError(lua_string(state))
        return lua_string(state)
    finally:LUA.lua_close(state)

if __name__=='__main__':
    result=json.loads(execute(FIXTURE.read_text(encoding='utf-8'),str(STRATEGY),str(PROBE),str(ROOT/'Tests/test_billiards_probe.lua'),str(ROOT/'Tests/fixtures/billiards-scene-cache1084.lua')))
    assert result['passed']>=30,result
    print(json.dumps(result,indent=2))

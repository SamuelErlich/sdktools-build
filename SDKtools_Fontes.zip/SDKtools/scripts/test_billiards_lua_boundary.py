#!/usr/bin/env python3
"""Exercise the production C protected callback against a real Lua 5.3 VM.

This does not compile Foundation/UIKit or validate an iPhone session. The C
callback is extracted verbatim from STBilliardsLuaBridge.m rather than copied.
The portable host adapts Lua's pcall macro to the exported pcallk entry point.
"""
from pathlib import Path
import ctypes.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile


def main():
    root = Path(__file__).resolve().parents[1]
    source = (root / "Sources/SDKtools/STBilliardsLuaBridge.m").read_text()
    compiler = shutil.which("cc")
    library = (os.environ.get("SDKTOOLS_LUA_LIBRARY") or os.environ.get("SDKTOOLS_LUA53_LIBRARY")
               or ctypes.util.find_library("texlua53") or ctypes.util.find_library("lua5.3"))
    if not compiler or not library:
        raise SystemExit("C compiler and Lua 5.3 shared library required; set SDKTOOLS_LUA_LIBRARY.")
    declarations = source[source.index("typedef struct STILDomain"):source.index("typedef NS_ENUM")]
    enum_match = re.search(r"typedef NS_ENUM\(NSInteger, STBilliardsLuaFailure\) \{(.*?)\n\};", source, re.S)
    assert enum_match
    enum_decl = "typedef enum {" + enum_match[1] + "\n} STBilliardsLuaFailure;\n"
    execution_start = source.index("typedef struct {", source.index("static BOOL STLuaBridgeBusy"))
    execution_end = source.index("static NSError *STLuaError")
    production_callback = source[execution_start:execution_end]
    harness = r'''
#include <dlfcn.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
__DECLARATIONS__
__ENUM__
__PRODUCTION_CALLBACK__

static int (*real_pcallk)(STLuaState *, int, int, int, intptr_t, void *);
static int bridge_pcall(STLuaState *L, int nargs, int nresults, int errorfunc) {
    return real_pcallk(L, nargs, nresults, errorfunc, 0, NULL);
}
static void bind(void *lib, const char *name, void *destination, size_t size) {
    void *address = dlsym(lib, name);
    assert(address && size == sizeof(address));
    memcpy(destination, &address, size);
}
#define BIND(member) bind(lib, #member, &api.member, sizeof(api.member))
#define FN_BIND(name) bind(lib, #name, &name, sizeof(name))
int main(int argc, char **argv) {
    assert(argc == 2);
    void *lib = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!lib) { fprintf(stderr, "%s\n", dlerror()); return 2; }
    STBilliardsLuaAPI api = {0};
    STLuaState *(*luaL_newstate)(void) = NULL;
    void (*luaL_openlibs)(STLuaState *) = NULL;
    void (*lua_close)(STLuaState *) = NULL;
    FN_BIND(luaL_newstate); FN_BIND(luaL_openlibs); FN_BIND(lua_close);
    bind(lib, "lua_pcallk", &real_pcallk, sizeof(real_pcallk));
    BIND(lua_version); BIND(lua_gettop); BIND(lua_settop); BIND(lua_checkstack);
    BIND(lua_pushcclosure); BIND(lua_pushlstring); BIND(luaL_loadbufferx);
    BIND(lua_type); BIND(lua_tolstring);
    api.lua_pcall = bridge_pcall;
    assert(*api.lua_version(NULL) == 503.0);
    STLuaState *L = luaL_newstate(); assert(L); luaL_openlibs(L);
    struct Case { const char *source; const char *command; STBilliardsLuaFailure expected; int type; size_t size; } cases[] = {
        {"return '{\"command\":\"' .. (...) .. '\"}'", "sample", STLuaOK, 4, 20},
        {"return '{\"command\":\"' .. (...) .. '\"}'", "stop", STLuaOK, 4, 18},
        {"local = broken", "sample", STLuaCompileFailed, 0, 0},
        {"error('private-session-value')", "sample", STLuaExecutionFailed, 0, 0},
        {"error({private='value'})", "sample", STLuaExecutionFailed, 0, 0},
        {"return 123", "sample", STLuaOK, 3, 0},
        {"return {private='value'}", "sample", STLuaOK, 5, 0},
        {"return string.rep('x', 262145)", "sample", STLuaOK, 4, 262145},
        {"return nil", "sample", STLuaOK, 0, 0},
        {"\033Lua-not-text", "sample", STLuaCompileFailed, 0, 0}
    };
    for (size_t i = 0; i < sizeof(cases)/sizeof(cases[0]); ++i) {
        api.lua_settop(L, 0);
        api.lua_pushlstring(L, "preserved-stack", 15);
        int originalTop = api.lua_gettop(L); assert(originalTop == 1);
        assert(api.lua_checkstack(L, 8));
        STBilliardsLuaExecution execution = {
            .api=&api, .script=cases[i].source, .scriptLength=strlen(cases[i].source),
            .command=cases[i].command, .commandLength=strlen(cases[i].command), .failure=STLuaOK
        };
        STLuaCurrentExecution = &execution;
        api.lua_pushcclosure(L, STLuaProtectedExecute, 0);
        int status = api.lua_pcall(L, 0, 1, 0);
        STLuaCurrentExecution = NULL;
        assert(status == 0);
        assert(execution.failure == cases[i].expected);
        assert(api.lua_gettop(L) == originalTop + 1);
        assert(api.lua_type(L, -1) == cases[i].type);
        if (cases[i].type == 4) {
            size_t size = 0; const char *result=api.lua_tolstring(L, -1, &size);
            assert(result && size == cases[i].size);
        }
        api.lua_settop(L, originalTop);
        size_t sentinelSize = 0;
        const char *sentinel = api.lua_tolstring(L, -1, &sentinelSize);
        assert(api.lua_gettop(L) == originalTop && sentinelSize == 15);
        assert(memcmp(sentinel, "preserved-stack", 15) == 0);
    }
    lua_close(L); dlclose(lib);
    puts("10 production callback cases passed on Lua 5.3");
    return 0;
}
'''
    harness = harness.replace("__DECLARATIONS__", declarations).replace("__ENUM__", enum_decl)
    harness = harness.replace("__PRODUCTION_CALLBACK__", production_callback)
    with tempfile.TemporaryDirectory(prefix="sdktools-lua-boundary-") as temporary:
        work = Path(temporary)
        cfile = work / "boundary.c"
        executable = work / "boundary"
        cfile.write_text(harness)
        linker = [] if sys.platform == "darwin" else ["-ldl"]
        subprocess.run([compiler, "-std=c11", "-Wall", "-Wextra", "-Werror", "-O2", str(cfile), *linker, "-o", str(executable)], check=True)
        result = subprocess.run([str(executable), library], check=True, text=True, capture_output=True)
    print(json.dumps({"status": "PASS", "cases": 10, "engine": "Lua 5.3", "result": result.stdout.strip(),
                      "limitations": ["Foundation bridge not compiled on this host", "No iPhone runtime execution", "Output JSON validation remains in Objective-C"]}))


if __name__ == "__main__":
    main()

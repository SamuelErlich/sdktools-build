#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation e CoreFoundation.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-probe-test.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
cd "$project_root"
xcrun --sdk macosx clang -fobjc-arc -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation \
  Tests/web_probe_sanitizer_test.m -o "$test_workspace/web-probe-test"
"$test_workspace/web-probe-test"

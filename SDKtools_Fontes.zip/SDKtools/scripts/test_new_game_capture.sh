#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-new-game.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror "$project_root/Tests/new_game_capture_policy_test.c" -o "$test_workspace/new-game"
"$test_workspace/new-game"

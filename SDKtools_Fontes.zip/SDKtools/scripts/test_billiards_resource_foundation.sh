#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation e CommonCrypto.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-billiards-foundation.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
xcrun --sdk macosx clang -fobjc-arc -fmodules -Wall -Wextra -Werror=implicit-function-declaration \
  -framework Foundation "$project_root/Tests/billiards_resource_exporter_test.m" \
  "$project_root/Sources/SDKtools/STBilliardsResourceExporter.m" -o "$test_workspace/billiards-foundation-test"
"$test_workspace/billiards-foundation-test"

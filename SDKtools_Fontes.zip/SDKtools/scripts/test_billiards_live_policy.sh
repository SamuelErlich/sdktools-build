#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-billiards-live-policy.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror \
    "$project_root/Tests/billiards_live_policy_test.c" \
    -o "$test_workspace/billiards-live-policy" -lm
"$test_workspace/billiards-live-policy"

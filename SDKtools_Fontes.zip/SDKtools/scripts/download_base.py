#!/usr/bin/env python3
"""Download the exact audited IPA from an HTTPS secret, without exposing the URL."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request

class HTTPSRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        require_https(newurl)
        return super().redirect_request(request, fp, code, msg, headers, newurl)

def require_https(url):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise ValueError('URL precisa ser HTTPS, sem usuário/senha embutidos nem fragmento.')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--identity', type=Path, default=Path(__file__).resolve().parents[1] / 'config/base_identity.json')
    args = parser.parse_args()
    temporary = None
    try:
        identity = json.loads(args.identity.read_text())
        url = os.environ.get('SDKTOOLS_BASE_IPA_URL', '').strip()
        require_https(url)
        if args.output.exists() or args.output.is_symlink() or not args.output.parent.is_dir():
            raise ValueError('A saída precisa ser nova, em uma pasta existente.')
        expected_size = identity['ipa_bytes']
        opener = urllib.request.build_opener(HTTPSRedirect())
        request = urllib.request.Request(url, headers={'User-Agent':'SDKtools-Build/2.0','Accept-Encoding':'identity'})
        size, digest = 0, hashlib.sha256()
        with opener.open(request, timeout=90) as response, tempfile.NamedTemporaryFile(dir=args.output.parent, suffix='.download', delete=False) as stream:
            temporary = Path(stream.name)
            require_https(response.geturl())
            while True:
                block = response.read(1024**2)
                if not block: break
                size += len(block)
                if size > expected_size:
                    raise ValueError('Download excede o tamanho da base esperada.')
                stream.write(block); digest.update(block)
            stream.flush(); os.fsync(stream.fileno())
        if size != expected_size or digest.hexdigest() != identity['ipa_sha256']:
            raise ValueError('Download não corresponde à base verificada. Não use IPA reassinado ou arquivo RAR.')
        os.link(temporary, args.output)
        print('IPA base baixado e SHA-256 confirmado.')
        return 0
    except (ValueError, KeyError, OSError, urllib.error.URLError):
        # Exceptions from HTTP libraries can include the complete signed URL.
        print('Falha ao baixar/verificar a base. Confira o secret SDKTOOLS_BASE_IPA_URL, validade do link e os bytes originais do IPA.', file=sys.stderr)
        return 1
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)

if __name__ == '__main__':
    raise SystemExit(main())

"""Execute the production identity script on Lua 5.3, without gameplay reads."""
from pathlib import Path
import json
from test_billiards_probe import LUA, lua_string

probe=(Path(__file__).resolve().parents[1]/'Resources/billiards_context.lua').read_text()
cases=[('CS=nil',False), ('CS={}',False)]
for name,loaded,expected in [('BilliardInGame','true',True),('BilliardTutorial','true',True),('Lobby','true',False),('BilliardInGame','false',False),('BilliardInGame','1',False)]:
    cases.append((f'CS={{UnityEngine={{SceneManagement={{SceneManager={{GetActiveScene=function() return {{name="{name}",isLoaded={loaded}}} end}}}}}}}}',expected))
cases.append(('CS={UnityEngine={SceneManagement={SceneManager={GetActiveScene=function() error("unavailable") end}}}}',False))
for setup,expected in cases:
    state=LUA.luaL_newstate()
    try:
        LUA.luaL_openlibs(state)
        # A sentinel observer state and forbidden reads catch unintended capture
        # startup, module imports or access to frame/gameplay data.
        source=(setup+'\nlocal sentinel={}\n__SDKtoolsBilliards315=sentinel\nrequire=function() error("module load forbidden") end\nlocal result=(function()\n'+probe+'\nend)()\nassert(__SDKtoolsBilliards315==sentinel)\nreturn result').encode()
        assert LUA.luaL_loadbufferx(state,source,len(source),b'@client-context-test',b't')==0,lua_string(state)
        assert LUA.lua_pcallk(state,0,1,0,0,None)==0,lua_string(state)
        assert json.loads(lua_string(state))=={'format':'SDK.ClientContext','active':expected}
    finally:
        LUA.lua_close(state)
print(json.dumps({'status':'PASS','cases':len(cases),'scope':'production Lua identity, no iPhone execution'}))

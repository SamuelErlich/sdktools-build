#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || exit 1
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-card-live.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
cd "$project_root"
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation Tests/card_live_test.m Sources/SDKtools/STCardColorFeed.m -o "$test_workspace/card-live"
"$test_workspace/card-live"
xcrun --sdk macosx clang -fobjc-arc -fmodules -Wall -Wextra \
  -framework Foundation -framework CoreFoundation Tests/card_hints_enabled_test.m -o "$test_workspace/card-hints-enabled"
"$test_workspace/card-hints-enabled"

#!/usr/bin/env python3
"""Exercise the read-only Lua observer with mock Unity objects on Lua 5.3.

Uses SDKTOOLS_LUA_LIBRARY when provided by the build gate. No game source,
app binary or external service is executed; the fixtures are synthetic.
"""
from __future__ import annotations

import ctypes
import ctypes.util
import json
import math
import os
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / "Resources" / "billiards_probe.lua"
FIXTURE = ROOT / "Tests" / "test_billiards_probe.lua"


def load_lua53():
    configured = os.environ.get("SDKTOOLS_LUA_LIBRARY")
    names = [configured] if configured else [
        ctypes.util.find_library("lua5.3"),
        ctypes.util.find_library("texlua53"),
        "liblua5.3.so.0", "libtexlua53.so.5", "liblua5.3.dylib",
    ]
    errors = []
    for name in names:
        if not name:
            continue
        try:
            lib = ctypes.CDLL(name)
            lib.luaL_newstate.argtypes = []
            lib.luaL_newstate.restype = ctypes.c_void_p
            lib.luaL_openlibs.argtypes = [ctypes.c_void_p]
            lib.lua_close.argtypes = [ctypes.c_void_p]
            lib.luaL_loadbufferx.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t,
                                           ctypes.c_char_p, ctypes.c_char_p]
            lib.luaL_loadbufferx.restype = ctypes.c_int
            lib.lua_pushlstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
            lib.lua_pushlstring.restype = ctypes.c_void_p
            lib.lua_pcallk.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_ssize_t, ctypes.c_void_p]
            lib.lua_pcallk.restype = ctypes.c_int
            lib.lua_tolstring.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_size_t)]
            lib.lua_tolstring.restype = ctypes.c_void_p
            return lib
        except (OSError, AttributeError) as exc:
            errors.append(f"{name}: {exc}")
    raise RuntimeError("Lua 5.3 library required. Set SDKTOOLS_LUA_LIBRARY. " + "; ".join(errors))


LUA = load_lua53()


def lua_string(state):
    size = ctypes.c_size_t()
    value = LUA.lua_tolstring(state, -1, ctypes.byref(size))
    if not value:
        raise AssertionError("Lua did not return a string")
    return ctypes.string_at(value, size.value).decode("utf-8")


# Captured free-phase fixtures. Omega is a declared phase seed, not an observed
# value from V3.18.1. Full production solver runs; collision timing is not fitted.
CALIBRATION_CASES = {'finite_calibration_roll_1': {'expectedDistance': 0.07624694713162175,
                               'expectedSpeed': 0.7472324839,
                               'omega': 4.762074553939394,
                               'sourceSHA256': '976612cc606e245c4c8a8e442e5b53ce6154b34988309b99871bd5efcef5c606',
                               'sourceT0': 10.714289499999722,
                               'sourceTag': 1,
                               'speed': 0.7857423014,
                               'steps': 5},
 'finite_calibration_roll_2': {'expectedDistance': 0.01104214611454037,
                               'expectedSpeed': 0.1082316037,
                               'omega': 0.6897552042424242,
                               'sourceSHA256': '0c8e0cab2aa570fb0e2b87ebf1af403fb1147ff85568f063ae0a0dbae59cb2a4',
                               'sourceT0': 24.916000624994922,
                               'sourceTag': 1,
                               'speed': 0.1138096087,
                               'steps': 5},
 'finite_calibration_roll_3': {'expectedDistance': 0.15281821374112695,
                               'expectedSpeed': 1.881518695,
                               'omega': 11.870903915151516,
                               'sourceSHA256': '982a0de5dbd6b0c710faabfc4408ee0b3ba3528b9d2323b858a6a1d62977ae1d',
                               'sourceT0': 6.017688125000859,
                               'sourceTag': 1,
                               'speed': 1.958699146,
                               'steps': 4},
 'finite_calibration_roll_4': {'expectedDistance': 0.04198934971804838,
                               'expectedSpeed': 0.4114945176,
                               'omega': 2.6224303260606057,
                               'sourceSHA256': 'a8ef6372c896043368a26bfee635878c7e416b3ec9cc81ab9c1ed0fe80560469',
                               'sourceT0': 7.212785666662967,
                               'sourceTag': 1,
                               'speed': 0.4327010038,
                               'steps': 5},
 'finite_calibration_slide_2': {'expectedDistance': 1.929572968676899,
                                'expectedSpeed': 18.52138243,
                                'omega': 0,
                                'sourceSHA256': '0c8e0cab2aa570fb0e2b87ebf1af403fb1147ff85568f063ae0a0dbae59cb2a4',
                                'sourceT0': 24.8162160833308,
                                'sourceTag': 4,
                                'speed': 20.47675075,
                                'steps': 5},
 'finite_calibration_slide_3': {'expectedDistance': 1.622427655006571,
                                'expectedSpeed': 15.51135472,
                                'omega': 0,
                                'sourceSHA256': '982a0de5dbd6b0c710faabfc4408ee0b3ba3528b9d2323b858a6a1d62977ae1d',
                                'sourceT0': 5.713855499998317,
                                'sourceTag': 1,
                                'speed': 17.31175276,
                                'steps': 5},
 'finite_calibration_slide_4': {'expectedDistance': 1.7421686864425923,
                                'expectedSpeed': 16.68482042,
                                'omega': 0,
                                'sourceSHA256': 'a8ef6372c896043368a26bfee635878c7e416b3ec9cc81ab9c1ed0fe80560469',
                                'sourceT0': 7.111570416665927,
                                'sourceTag': 7,
                                'speed': 18.54569972,
                                'steps': 5},
 'finite_calibration_stop_1': {'expectedDistance': 1.3807296912490963,
                               'omega': 4.762074553939394,
                               'sourceSHA256': '976612cc606e245c4c8a8e442e5b53ce6154b34988309b99871bd5efcef5c606',
                               'sourceT0': 10.714289499999722,
                               'sourceTag': 1,
                               'speed': 0.7857423014},
 'finite_calibration_stop_2': {'expectedDistance': 0.04878777670783371,
                               'omega': 0.6897552042424242,
                               'sourceSHA256': '0c8e0cab2aa570fb0e2b87ebf1af403fb1147ff85568f063ae0a0dbae59cb2a4',
                               'sourceT0': 24.916000624994922,
                               'sourceTag': 1,
                               'speed': 0.1138096087},
 'finite_calibration_stop_3': {'expectedDistance': 0.702143209748316,
                               'omega': 2.6857399006060603,
                               'sourceSHA256': '982a0de5dbd6b0c710faabfc4408ee0b3ba3528b9d2323b858a6a1d62977ae1d',
                               'sourceT0': 6.916118541666947,
                               'sourceTag': 1,
                               'speed': 0.4431470836},
 'finite_calibration_stop_4': {'expectedDistance': 0.6803918243541978,
                               'omega': 2.6224303260606057,
                               'sourceSHA256': 'a8ef6372c896043368a26bfee635878c7e416b3ec9cc81ab9c1ed0fe80560469',
                               'sourceT0': 7.212785666662967,
                               'sourceTag': 1,
                               'speed': 0.4327010038}}


def run_case(name):
    state = LUA.luaL_newstate()
    if not state:
        raise MemoryError("luaL_newstate")
    try:
        LUA.luaL_openlibs(state)
        source = FIXTURE.read_bytes()
        status = LUA.luaL_loadbufferx(state, source, len(source), b"@SDKtools_probe_tests", b"t")
        if status:
            raise AssertionError(lua_string(state))
        arguments = [name, str(PROBE)]
        def literal(value):
            if isinstance(value, dict):
                return "{" + ",".join("[" + json.dumps(k) + "]=" + literal(v) for k, v in value.items()) + "}"
            if isinstance(value, list):
                return "{" + ",".join(literal(v) for v in value) + "}"
            if isinstance(value, bool):
                return "true" if value else "false"
            if isinstance(value, (int, float)):
                assert math.isfinite(value)
                return repr(value)
            return json.dumps(value)
        if name == "chain_real_capture":
            captured = json.loads((ROOT / "Tests" / "fixtures" / "billiards-chain-v317-captured.json").read_text())
            arguments.append("return " + literal({"balls": captured["balls"], "cue": captured["cue"]}))
        elif name in CALIBRATION_CASES:
            arguments.append("return " + literal(CALIBRATION_CASES[name]))
        for value in arguments:
            value = value.encode("utf-8")
            LUA.lua_pushlstring(state, value, len(value))
        status = LUA.lua_pcallk(state, len(arguments), 1, 0, 0, None)
        if status:
            raise AssertionError(lua_string(state))
        return [json.loads(line) for line in lua_string(state).splitlines()]
    finally:
        LUA.lua_close(state)


class BilliardsProbeTests(unittest.TestCase):
    def sample(self, case):
        result = run_case(case)[0]
        self.assertEqual(result["format"], "SDKtools.BilliardsLive")
        self.assertEqual(result["schemaVersion"], 1)
        self.assertEqual(result["resourceGameId"], 20)
        self.assertEqual(result["gameType"], 1003)
        self.assertIsInstance(result["balls"], list)
        self.assertIsInstance(result["segments"], list)
        self.assertLessEqual(len(result["balls"]), 16)
        self.assertLessEqual(len(result["segments"]), 48)
        if result["prediction"].get("chainVersion") == 2:
            prediction = result["prediction"]
            for field, maximum in {"events": 64, "queries": 96, "collisions": 64,
                                   "bounces": 64, "affectedBallCount": 16}.items():
                self.assertIsInstance(prediction[field], int)
                self.assertGreaterEqual(prediction[field], 0)
                self.assertLessEqual(prediction[field], maximum)
            self.assertIsInstance(prediction["truncated"], bool)
            self.assertEqual(prediction["maxBounces"], 6)
            self.assertEqual(prediction["model"], "finite")
            self.assertLessEqual(prediction["durationSeconds"], 15)
            self.assertGreaterEqual(prediction["durationSeconds"], 0)
            self.assertLessEqual(prediction["stepCount"], 750)
            self.assertIsInstance(prediction["complete"], bool)
            self.assertEqual(len(prediction["finalStates"]), prediction["affectedBallCount"])
            if prediction["complete"]:
                self.assertFalse(prediction["truncated"])
                self.assertTrue(all(f["outcome"] in {"rest", "pocket"} for f in prediction["finalStates"]))
            else:
                self.assertTrue(all(f["outcome"] in {"unknown", "pocket"} for f in prediction["finalStates"]))
            live_tags = {b["tag"] for b in result["balls"] if b["active"] and not b["potted"]}
            for segment in result["segments"]:
                self.assertIn(segment["ballTag"], live_tags)
                self.assertGreaterEqual(segment["timeSeconds"], 0)
                self.assertLessEqual(segment["timeSeconds"], prediction["durationSeconds"]+1e-8)
                self.assertGreaterEqual(segment["eventIndex"], 1)
                self.assertLessEqual(segment["eventIndex"], prediction["events"])
                self.assertIn(segment["terminal"], {"ball", "cushion", "pocket", "horizon", "limit", "rest"})
                if segment["terminal"] == "ball":
                    self.assertIn(segment["hitBallTag"], live_tags)
                    self.assertNotEqual(segment["hitBallTag"], segment["ballTag"])
                else:
                    self.assertNotIn("hitBallTag", segment)
        resolution = result["resolution"]
        self.assertEqual(resolution["schemaVersion"], 1)
        self.assertIn(resolution["source"], {"none", "globals", "package_loaded"})
        self.assertIn(resolution["contractStatus"], {"missing", "invalid", "conflict", "selected"})
        lua_types = {"nil", "boolean", "number", "string", "function", "userdata", "thread", "table"}
        for field in ["enumType", "constType", "descriptorType", "managerType", "managerGetType", "frameType"]:
            self.assertIn(resolution[field], lua_types)
        self.assertIsInstance(resolution["frameCallAttempted"], bool)
        self.assertIsInstance(resolution["frameCallSucceeded"], bool)
        if resolution["frameCallSucceeded"]:
            self.assertTrue(resolution["frameCallAttempted"])
        if not resolution["frameCallAttempted"]:
            self.assertEqual(resolution["frameType"], "nil")
        if result["status"] != "aiming":
            self.assertFalse(result["prediction"]["available"])
            self.assertEqual(result["segments"], [])
        return result

    def test_six_reflections_and_unsorted_nearest(self):
        result = self.sample("bank")
        self.assertTrue(result["prediction"]["complete"])
        self.assertGreater(result["prediction"]["bounces"], 0)
        self.assertLessEqual(result["prediction"]["bounces"], 6)
        self.assertEqual(result["segments"][-1]["terminal"], "rest")
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 2)
        self.assertLess(result["segments"][1]["worldTo"]["z"], result["segments"][1]["worldFrom"]["z"])
        self.assertAlmostEqual(result["balls"][0]["radiusPixels"], 16.5)

    def test_head_on_ball_collision(self):
        result = self.sample("ball")
        self.assertEqual(self.sample("child_collider")["segments"], result["segments"])
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 1.67)
        objects = [s for s in result["segments"] if s["ballTag"] == 2]
        self.assertAlmostEqual(objects[0]["worldFrom"]["z"], 2)
        self.assertEqual(result["prediction"]["bounces"], 0)
        # Cue rotation survives normal impact and may produce follow-on travel.
        self.assertTrue(result["prediction"]["complete"])

    def test_cut_splits_target_and_cue(self):
        result = self.sample("cut")
        first = result["segments"][0]
        self.assertEqual((first["ballTag"], first["hitBallTag"]), (1, 2))
        a = next(s for s in result["segments"] if s["ballTag"] == 2)
        b = next(s for s in result["segments"][1:] if s["ballTag"] == 1)
        av = {k: a["worldTo"][k]-a["worldFrom"][k] for k in "xz"}
        bv = {k: b["worldTo"][k]-b["worldFrom"][k] for k in "xz"}
        self.assertAlmostEqual(av["x"]*bv["x"]+av["z"]*bv["z"], 0, places=7)
        self.assertGreater(av["x"], 0); self.assertLess(bv["x"], 0)
        self.assertGreater(len([s for s in result["segments"] if s["terminal"] == "horizon"]), 1)

    def test_open_branch_retains_already_bounded_other_branch(self):
        result = self.sample("open_branch")
        self.assertTrue(result["prediction"]["available"])
        self.assertEqual(result["segments"][0]["terminal"], "ball")
        self.assertEqual({s["ballTag"] for s in result["segments"]}, {1, 2})

    def test_unbounded_path_not_drawn(self):
        result = self.sample("finite_rest")
        # An empty cast is sufficient when calculated rest is before its end.
        self.assertTrue(result["prediction"]["complete"])
        self.assertEqual(result["segments"][-1]["terminal"], "rest")
        self.assertLess(result["segments"][-1]["worldTo"]["z"], 20)

    def test_pocket_stops_before_wall(self):
        for case in ["pocket", "explicit_triggers"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(len(result["segments"]), 1)
                self.assertEqual(result["prediction"]["bounces"], 0)
                self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 2)

    def test_three_ball_chain_ignores_obsolete_unity_ball_colliders(self):
        result = self.sample("chain_three_balls")
        contacts = [s for s in result["segments"] if s["terminal"] == "ball"]
        self.assertEqual([(s["ballTag"], s["hitBallTag"]) for s in contacts], [(1,2),(2,3)])
        self.assertAlmostEqual(contacts[0]["worldTo"]["z"],1.67)
        self.assertAlmostEqual(contacts[1]["worldTo"]["z"],3.67)
        self.assertEqual(result["prediction"]["affectedBallCount"],3)
        self.assertTrue(result["prediction"]["complete"])
        self.assertEqual({f["outcome"] for f in result["prediction"]["finalStates"]},{"rest"})

    def test_chain_fixture_pocket_and_projected_endpoints_fit_viewport(self):
        result = self.sample("finite_chain")
        pocket = next(s for s in result["segments"] if s["terminal"] == "pocket")
        self.assertAlmostEqual(pocket["worldTo"]["z"],8)
        for segment in result["segments"]:
            for endpoint in ("from","to"):
                point=segment[endpoint]
                self.assertGreaterEqual(point["x"],0);self.assertLessEqual(point["x"],1080)
                self.assertGreaterEqual(point["y"],0);self.assertLessEqual(point["y"],1920)

    def test_captured_v317_layout_continues_from_tag14_to_tag15(self):
        result = self.sample("chain_real_capture")
        fixture = json.loads((ROOT / "Tests" / "fixtures" / "billiards-chain-v317-captured.json").read_text())
        contacts = [s for s in result["segments"] if s["terminal"] == "ball"][:2]
        self.assertEqual([(s["ballTag"], s["hitBallTag"]) for s in contacts], [(1, 14), (14, 15)])
        for segment, reference in zip(contacts, fixture["legacySegments"][:2]):
            # Existing Unity SphereCast contact points and analytical contacts
            # differ slightly; this is not a claim of observed shot accuracy.
            error = math.sqrt(sum((segment["worldTo"][k]-reference["worldTo"][k])**2 for k in "xyz"))
            self.assertLess(error, .002)
        self.assertGreaterEqual(result["prediction"]["affectedBallCount"], 3)

    def test_touching_chain_has_bounded_zero_time_propagation(self):
        result = self.sample("chain_touching")
        self.assertGreaterEqual(result["prediction"]["collisions"],2)
        self.assertLessEqual(result["prediction"]["events"],64)
        self.assertEqual(result["prediction"]["affectedBallCount"],3)
        self.assertGreater(result["prediction"]["stepCount"],0)

    def test_simultaneous_contacts_stop_before_arbitrary_impulse_order(self):
        result = self.sample("chain_simultaneous")
        self.assertEqual(result["prediction"]["reason"], "simultaneous_contacts")
        self.assertTrue(result["prediction"]["truncated"])
        self.assertEqual(result["prediction"]["collisions"], 0)
        self.assertEqual(result["segments"][0]["terminal"], "limit")
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 2-math.sqrt(.33**2-.2**2))

    def test_equally_early_rail_normals_are_not_arbitrarily_selected(self):
        result = self.sample("chain_corner")
        self.assertEqual(result["prediction"]["reason"], "simultaneous_contacts")
        self.assertTrue(result["prediction"]["truncated"])
        self.assertEqual(result["prediction"]["bounces"], 0)
        self.assertEqual(result["segments"][0]["terminal"], "limit")
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["x"], math.sqrt(2))

    def test_overlap_cannot_create_fabricated_contact_normal(self):
        for case, reason in [("chain_overlap", "overlapping_ball_geometry"),
                             ("chain_zero_cushion", "environment_overlap")]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], reason)
            self.assertFalse(result["prediction"]["available"])
        result = self.sample("chain_partial_overlap")
        self.assertEqual(result["prediction"]["reason"], "environment_overlap")
        self.assertTrue(result["prediction"]["truncated"])
        self.assertEqual(len(result["segments"]), 1)
        self.assertEqual(result["segments"][0]["terminal"], "ball")
        self.assertEqual(result["prediction"]["bounces"], 0)
        self.assertFalse(self.sample("chain_zero_pocket")["prediction"]["available"])

    def test_bank_then_ball_keeps_real_contact_and_accounts_cast_offset(self):
        result = self.sample("chain_bank_then_ball")
        first = result["segments"][0]
        contact = next(s for s in result["segments"] if s["terminal"] == "ball")
        self.assertEqual(first["terminal"],"cushion")
        self.assertEqual(contact["hitBallTag"],2)
        self.assertAlmostEqual(first["worldTo"]["z"],5.835)
        self.assertAlmostEqual(math.hypot(contact["worldTo"]["x"],contact["worldTo"]["z"]+2),.33,places=7)
        for segment in result["segments"]:
            if segment["terminal"]=="cushion":
                point=segment["worldTo"]
                self.assertTrue(abs(abs(point["x"])-3.835)<1e-7 or abs(abs(point["z"])-5.835)<1e-7)

    def test_query_event_segment_budgets_preserve_valid_prefix(self):
        for case, reason, maximum in [("chain_budget_query", "query_limit", 2),
                                      ("chain_budget_event", "event_limit", 1),
                                      ("chain_budget_segment", "segment_limit", 2)]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertTrue(result["prediction"]["available"])
                self.assertTrue(result["prediction"]["truncated"])
                self.assertEqual(result["prediction"]["reason"], reason)
                self.assertEqual(result["segments"][0]["hitBallTag"], 2)
                if "query" in case:
                    self.assertEqual(result["prediction"]["queries"], maximum)
                elif "event" in case:
                    self.assertEqual(result["prediction"]["events"], maximum)
                else:
                    self.assertLessEqual(len(result["segments"]), maximum)

    def test_later_unknown_geometry_does_not_erase_valid_prefix(self):
        result = self.sample("chain_partial_unknown")
        self.assertEqual(result["prediction"]["reason"], "unclassified_collider")
        self.assertTrue(result["prediction"]["truncated"])
        self.assertEqual(len(result["segments"]), 1)
        self.assertEqual(result["segments"][0]["terminal"], "ball")
        self.assertEqual(result["prediction"]["queries"], 2)

    def test_unchanged_moving_branch_uses_cached_environment_event(self):
        result = self.sample("finite_rest")
        # Hundreds of damping steps reuse the same verified empty corridor;
        # the second cast follows the final tiny rotation-to-translation step.
        self.assertGreater(result["prediction"]["stepCount"],200)
        self.assertLessEqual(result["prediction"]["queries"],3)

    def test_chain_relative_velocities_use_predicted_contact_positions(self):
        result = self.sample("chain_moving_collision")
        segments = result["segments"]
        paired = {}
        for segment in segments:
            if segment["terminal"] == "ball":
                paired.setdefault(segment["eventIndex"], []).append(segment)
        moving_pairs = [items for items in paired.values() if len(items) == 2]
        self.assertGreaterEqual(len(moving_pairs), 1)
        for a, b in moving_pairs:
            self.assertEqual(a["ballTag"], b["hitBallTag"])
            self.assertEqual(b["ballTag"], a["hitBallTag"])
            distance = math.sqrt(sum((a["worldTo"][k]-b["worldTo"][k])**2 for k in "xyz"))
            self.assertAlmostEqual(distance, .33, places=7)
        # Rotational follow sends cue into ball2 again AFTER ball2 hit ball3.
        # Both balls have moved away from their observed initial positions.
        ball2_later = [s for p in moving_pairs for s in p if s["ballTag"] == 2][0]
        self.assertGreater(ball2_later["worldTo"]["z"]-2, .1)
        self.assertTrue(result["prediction"]["complete"])

    def test_horizon_is_partial_and_keeps_only_bounded_geometry(self):
        result = self.sample("chain_horizon")
        self.assertLessEqual(result["prediction"]["durationSeconds"],15)
        for segment in result["segments"]:
            self.assertLessEqual(abs(segment["worldTo"]["x"]),3.835001)
            self.assertLessEqual(abs(segment["worldTo"]["z"]),5.835001)

    def test_full_runtime_query_budget_marks_all_remaining_endpoints_unknown(self):
        result=self.sample("finite_budget_stress")
        self.assertEqual(result["prediction"]["reason"],"query_limit")
        self.assertEqual(result["prediction"]["queries"],96)
        self.assertFalse(result["prediction"]["complete"])
        self.assertEqual({f["outcome"] for f in result["prediction"]["finalStates"]},{"unknown"})
        self.assertTrue(result["prediction"]["available"])

    def test_live_power_and_profile_inputs_are_required(self):
        expected={"finite_unknown_power":"power_unavailable", "finite_zero_power":"power_below_deadzone",
                  "finite_deadzone":"power_below_deadzone", "finite_spin":"spin_unsupported",
                  "finite_missing_inertia":"physics_body_unavailable", "finite_anisotropic_inertia":"inertia_tensor_unsupported",
                  "finite_mass_conflict":"physics_profile_mismatch", "finite_drag_conflict":"physics_profile_mismatch",
                  "finite_material_conflict":"physics_profile_mismatch", "finite_clock_conflict":"physics_profile_mismatch",
                  "finite_missing_gravity":"physics_unavailable", "finite_missing_spin":"spin_unavailable",
                  "finite_constraints":"physics_profile_mismatch", "finite_com_offset":"physics_profile_mismatch"}
        for case,reason in expected.items():
            with self.subTest(case=case):
                result=self.sample(case)
                self.assertFalse(result["prediction"]["available"])
                self.assertEqual(result["prediction"]["reason"],reason)
                self.assertEqual(result["prediction"]["queries"],0)
        self.assertTrue(self.sample("finite_deadzone_equal")["physics"]["available"])
        self.assertEqual(self.sample("finite_missing_material")["physics"]["materialSource"],"cache1084_profile")

    def test_force_changes_finite_rest_distance_without_invented_slider_power(self):
        low=self.sample("finite_low_power");high=self.sample("finite_high_power")
        self.assertTrue(low["prediction"]["complete"] and high["prediction"]["complete"])
        self.assertGreater(high["prediction"]["finalStates"][0]["world"]["z"],low["prediction"]["finalStates"][0]["world"]["z"]*2)
        self.assertAlmostEqual(low["physics"]["launchSpeed"],.031*80*math.sqrt(80/750)/.45,places=7)
        a=self.sample("bank")["physics"];b=self.sample("finite_slider_reference")["physics"]
        self.assertEqual(a["launchSpeed"],b["launchSpeed"])
        self.assertNotEqual(a["sliderMax"],b["sliderMax"])

    def test_motion_exports_actual_vectors_and_never_finite_guides(self):
        result=self.sample("finite_moving")
        self.assertEqual(result["status"],"moving")
        self.assertEqual(result["balls"][0]["velocity"],{"x":0,"y":0,"z":4})
        self.assertEqual(result["balls"][0]["angularVelocity"],{"x":3,"y":0,"z":0})
        self.assertEqual(result["balls"][0]["mass"],.45)
        self.assertEqual(result["physics"]["fixedDeltaTime"],.02)
        self.assertEqual(result["segments"],[])

    def test_production_solver_replays_measured_sliding_and_rolling_phases(self):
        for case,fixture in CALIBRATION_CASES.items():
            with self.subTest(case=case):
                result=self.sample(case)
                point=result["prediction"]["finalStates"][0]["world"]
                # Actual captures include render-sampled cutoff and float error.
                tolerance=.002 if "stop" in case else .00003
                self.assertAlmostEqual(point["z"],fixture["expectedDistance"],delta=tolerance)
                if "expectedSpeed" in fixture:
                    self.assertAlmostEqual(result["testFinalVelocity"]["z"],fixture["expectedSpeed"],delta=.0002)
                    self.assertFalse(result["prediction"]["complete"])
                    self.assertEqual(result["prediction"]["finalStates"][0]["outcome"],"unknown")
                else:
                    self.assertTrue(result["prediction"]["complete"])
                    self.assertEqual(result["prediction"]["finalStates"][0]["outcome"],"rest")
                    self.assertEqual(result["testFinalVelocity"],{"x":0,"y":0,"z":0})
                    self.assertEqual(result["testFinalOmega"],{"x":0,"y":0,"z":0})

    def test_motion_and_spin_hide_guides(self):
        for case in ["moving", "moving_flag", "angular"]:
            with self.subTest(case=case):
                self.assertEqual(self.sample(case)["status"], "moving")

    def test_nonlocal_turn_hides_guides(self):
        for case in ["not_turn", "contradictory_turn"]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], "not_local_turn")

    def test_foreign_scene_and_game_contract(self):
        self.assertEqual(self.sample("foreign_scene")["status"], "wrong_scene")
        self.assertEqual(self.sample("wrong_type")["prediction"]["reason"], "billiards_contract_mismatch")

    def test_in_hand_modal_and_hidden_cue(self):
        for case, reason in [("hand", "white_ball_in_hand"), ("modal", "cue_dialog_visible"), ("hidden", "aim_ui_hidden")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_stale_aim_cannot_reuse_old_guides(self):
        for case in ["stale_aim", "stale_angle"]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], "aim_snapshot_stale")

    def test_ball_identity_and_reuse_validation(self):
        for case, reason in [("duplicate_tag", "invalid_ball_identity"), ("reused_object", "reused_ball_object"),
                             ("too_many_balls", "invalid_ball_collection")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_potted_object_may_be_destroyed(self):
        result = self.sample("potted")
        row = result["balls"][1]
        self.assertFalse(row["active"])
        self.assertTrue(row["potted"])
        self.assertIsNone(row["world"])
        self.assertIsNone(row["screen"])
        self.assertEqual(result["status"], "aiming")

    def test_invalid_live_objects(self):
        for case, reason in [("bad_position", "invalid_ball_geometry"), ("camera_scene", "camera_scene_mismatch"),
                             ("destroyed_ball", "active_ball_object_unavailable"), ("zero_direction", "invalid_cue_direction")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_query_errors_are_bounded_and_clear_guides(self):
        for case, reason in [("query_error", "physics_query_failed"), ("unknown", "unclassified_collider"),
                             ("unmapped", "unmapped_ball_collider"), ("hit_limit", "physics_hit_limit"),
                             ("nan_hit", "invalid_physics_hit"), ("bad_normal", "invalid_cushion_normal"),
                             ("unknown_trigger_policy", "physics_trigger_policy_unknown"),
                             ("foreign_hit_scene", "unclassified_collider")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_tutorial_explicit_scene(self):
        result = self.sample("tutorial")
        self.assertEqual(result["scene"]["name"], "BilliardTutorial")
        self.assertEqual(result["prediction"]["reason"], "tutorial_physics_unsupported")

    def test_session_changes_only_for_identity_changes(self):
        values = run_case("sessions")
        ids = [v["sessionId"] for v in values]
        self.assertEqual(ids, [1, 1, 2, 3, 4])

    def test_stop_invalidates_session_and_outputs(self):
        first, stopped = run_case("stop")
        self.assertEqual(stopped["status"], "stopped")
        self.assertGreater(stopped["sessionId"], first["sessionId"])
        self.assertEqual(stopped["balls"], [])
        self.assertEqual(stopped["segments"], [])

    def test_unsupported_command_has_no_queries(self):
        self.assertEqual(self.sample("unsupported_command")["prediction"]["reason"], "unknown_command")

    def test_state_does_not_retain_game(self):
        self.assertEqual(self.sample("weak_state")["status"], "aiming")

    def environment(self, case):
        result = self.sample(case)
        self.assertEqual(result["status"], "not_ready" if case == "env_raw_absent" else "unsupported")
        self.assertEqual(result["prediction"]["reason"],
                         "frame_unavailable" if case == "env_raw_absent" else "billiards_contract_mismatch")
        if case == "env_raw_absent":
            self.assertEqual(result["resolution"]["source"], "package_loaded")
            self.assertTrue(result["resolution"]["frameCallSucceeded"])
            self.assertEqual(result["resolution"]["frameType"], "nil")
        self.assertEqual(result["balls"], [])
        environment = result["environment"]
        self.assertEqual(environment["schemaVersion"], 1)
        self.assertEqual(environment["mode"], "structural_only")
        self.assertEqual(environment["stage"], "before_contract")
        self.assertEqual(len(environment["globals"]), 7)
        self.assertLessEqual(len(environment["modules"]), 24)
        self.assertLessEqual(len(environment["environments"]), 8)
        self.assertLessEqual(environment["scannedKeys"], 512)
        self.assertLessEqual(environment["matchedKeys"], 536)
        self.assertLessEqual(environment["errorCount"], 128)
        self.assertEqual(environment["limits"], {"scanKeys": 512, "modules": 24,
                         "environments": 8, "upvalues": 16, "lookupDepth": 4})
        return environment

    @staticmethod
    def global_row(environment, name):
        return next(row for row in environment["globals"] if row["name"] == name)

    def test_environment_distinguishes_absent_from_other_types(self):
        absent = self.environment("env_raw_absent")
        enum = self.global_row(absent, "Enum")
        self.assertEqual((enum["rawType"], enum["resolvedType"], enum["lookup"]), ("nil", "nil", "absent"))
        self.assertNotIn("enumGameType", absent["environments"][0])
        self.assertFalse(absent["environments"][0]["contractValid"])
        self.assertEqual([r["gameType"] for r in absent["modules"] if "gameType" in r], [1003, 1003])
        self.assertEqual(absent["modules"][2]["environmentIndex"], 1)
        other = self.environment("env_raw_other")
        self.assertEqual(self.global_row(other, "Enum")["rawType"], "boolean")
        self.assertEqual(self.global_row(other, "Const")["rawType"], "string")
        self.assertEqual(self.global_row(other, "BiLogic")["rawType"], "number")

    def test_structural_table_lookup_does_not_enable_gameplay(self):
        environment = self.environment("env_metatable_table")
        enum = self.global_row(environment, "Enum")
        self.assertEqual(enum, {"name": "Enum", "rawType": "nil", "resolvedType": "table",
                         "lookup": "metatable_table", "indexType": "table", "depth": 1})
        self.assertTrue(environment["environments"][0]["contractValid"])

    def test_structural_lookup_blocks_functions_and_opaque_metatables(self):
        for case, reason in [("env_function_blocked", "function_index_blocked"),
                             ("env_protected", "protected_metatable"), ("env_cycle", "cycle"),
                             ("env_depth_limit", "depth_limit"), ("env_metatable_error", "error")]:
            with self.subTest(case=case):
                environment = self.environment(case)
                enum = self.global_row(environment, "Enum")
                self.assertEqual(enum["lookup"], reason)
                self.assertEqual(enum["resolvedType"], "nil")
                self.assertLessEqual(enum["depth"], 4)
                self.assertFalse(environment["environments"][0]["contractValid"])
                if case == "env_metatable_error":
                    self.assertGreater(environment["errorCount"], 0)

    def test_loaded_function_distinct_environment_is_evidence_only(self):
        environment = self.environment("env_distinct")
        self.assertEqual(len(environment["environments"]), 2)
        global_env, alternate = environment["environments"]
        self.assertFalse(global_env["contractValid"])
        self.assertTrue(global_env["sameAsGlobal"])
        self.assertFalse(alternate["sameAsGlobal"])
        self.assertTrue(alternate["contractValid"])
        self.assertEqual(alternate["enumGameType"], 1003)
        self.assertEqual(alternate["constGameType"], 1003)
        self.assertEqual(alternate["source"], "Billiard/Lua/Const/Init")
        module = environment["modules"][0]
        self.assertEqual(module["source"], "known_key")
        self.assertEqual(module["environmentStatus"], "found")
        self.assertEqual(module["environmentIndex"], 2)
        self.assertEqual(module["upvaluesScanned"], 1)

    def test_environment_aliases_deduplicate_by_identity(self):
        environment = self.environment("env_alias")
        self.assertEqual(len(environment["modules"]), 2)
        self.assertEqual(len(environment["environments"]), 2)
        self.assertEqual([r["environmentIndex"] for r in environment["modules"]], [2, 2])

    def test_nested_manager_proxy_is_not_invoked_to_validate_contract(self):
        environment = self.environment("env_nested_index_blocked")
        alternate = environment["environments"][1]
        self.assertEqual(alternate["enumGameType"], 1003)
        self.assertEqual(alternate["constGameType"], 1003)
        self.assertFalse(alternate["contractValid"])

    def test_observed_identity_requires_finite_in_range_integer(self):
        environment = self.environment("env_invalid_game_type")
        alternate = environment["environments"][1]
        self.assertNotIn("enumGameType", alternate)
        self.assertNotIn("constGameType", alternate)
        self.assertEqual(alternate["frameDescriptorType"], "string")
        self.assertFalse(alternate["contractValid"])
        self.assertTrue(all("gameType" not in module for module in environment["modules"]))

    def test_missing_throwing_and_non_environment_upvalues(self):
        for case, reason in [("env_no_debug", "no_debug"), ("env_debug_error", "error"),
                             ("env_no_env", "no_env"), ("env_non_table_env", "non_table_env"),
                             ("env_upvalue_limit", "upvalue_limit")]:
            with self.subTest(case=case):
                environment = self.environment(case)
                module = environment["modules"][0]
                self.assertEqual(module["environmentStatus"], reason)
                self.assertNotIn("environmentIndex", module)
                self.assertEqual(len(environment["environments"]), 1)
                self.assertLessEqual(module["upvaluesScanned"], 16)
                if case == "env_upvalue_limit":
                    self.assertEqual(module["upvaluesScanned"], 16)
                if case == "env_debug_error":
                    self.assertEqual(environment["errorCount"], 1)

    def test_structural_scan_and_environment_limits_are_explicit(self):
        scan = self.environment("env_scan_limit")
        self.assertEqual(scan["scannedKeys"], 512)
        self.assertEqual(scan["matchedKeys"], 512)
        self.assertEqual(len(scan["modules"]), 24)
        self.assertTrue(scan["scanTruncated"])
        self.assertTrue(scan["modulesTruncated"])
        environments = self.environment("env_environment_limit")
        self.assertEqual(len(environments["environments"]), 8)
        self.assertTrue(environments["environmentsTruncated"])
        self.assertEqual(sum(m["environmentStatus"] == "env_limit" for m in environments["modules"]), 5)

    def test_module_discovery_filters_names_and_never_initializes_modules(self):
        environment = self.environment("env_unknown_module")
        self.assertEqual({m["name"] for m in environment["modules"]},
                         {"Billiard/Lua/PreviouslyUnknown", "Billiard.Lua.Dotted"})
        self.assertTrue(all(m["source"] == "loaded_scan" for m in environment["modules"]))
        blocked = self.environment("env_loaded_proxy_blocked")
        self.assertEqual(blocked["packageType"], "table")
        self.assertEqual(blocked["loadedType"], "nil")
        self.assertEqual(blocked["modules"], [])

    def test_structural_report_only_runs_in_loaded_billiard_scene(self):
        for case in ["foreign_scene", "scene_not_loaded", "stop", "unsupported_command"]:
            result = run_case(case)[-1]
            self.assertNotIn("environment", result)
        first, second = run_case("env_sequence")
        self.assertEqual([first["environment"]["sequence"], second["environment"]["sequence"]], [1, 2])
        self.assertEqual(first["environment"]["environments"], second["environment"]["environments"])

    def test_cached_modules_resolve_captured_root_without_global_lookup(self):
        result = self.sample("loaded_modules")
        self.assertEqual(result["status"], "aiming")
        self.assertFalse(result["gates"]["hasEnum"])
        self.assertFalse(result["gates"]["hasConst"])
        self.assertTrue(result["gates"]["hasFrame"])
        self.assertTrue(result["gates"]["hasCamera"])
        self.assertEqual(result["resolution"], {
            "schemaVersion": 1, "source": "package_loaded", "contractStatus": "selected",
            "enumType": "table", "constType": "table", "enumGameType": 1003, "constGameType": 1003,
            "descriptorType": "table", "descriptorName": "Game/BiFrameLogic", "descriptorPackage": "Billiard",
            "managerType": "table", "managerGetType": "function", "managerLookup": "raw",
            "frameCallAttempted": True, "frameCallSucceeded": True, "frameType": "table", "frameDestroyed": False})
        environment = result["environment"]
        self.assertEqual(self.global_row(environment, "Enum")["lookup"], "function_index_blocked")
        init = next(m for m in environment["modules"] if m["name"] == "Billiard/Lua/Const/Init")
        self.assertEqual(init["environmentIndex"], 1)
        self.assertTrue(environment["environments"][0]["sameAsGlobal"])
        self.assertEqual(len(result["balls"]), 2)

    def test_global_pair_preferred_and_partial_identity_verified(self):
        for case, source in [("bank", "globals"), ("resolver_global_preferred", "globals"),
                             ("resolver_partial_enum", "package_loaded"),
                             ("resolver_partial_const", "package_loaded"),
                             ("resolver_global_namespace_proxy", "package_loaded")]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["status"], "aiming")
                self.assertEqual(result["resolution"]["source"], source)
        for case in ["resolver_partial_conflict_enum", "resolver_partial_conflict_const"]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "billiards_contract_conflict")
            self.assertEqual(result["resolution"]["contractStatus"], "conflict")
            self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_cached_module_contract_rejects_wrong_types_and_identity(self):
        for case in ["resolver_namespace_wrong", "resolver_global_module_wrong", "resolver_wrong_game_type",
                     "resolver_string_game_type", "resolver_nonfinite_game_type", "resolver_module_wrong",
                     "resolver_game_type_proxy"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "billiards_contract_mismatch")
                self.assertEqual(result["resolution"]["contractStatus"], "invalid")
                self.assertEqual(result["resolution"]["source"], "none")
                self.assertFalse(result["resolution"]["frameCallAttempted"])
        self.assertEqual(self.sample("resolver_wrong_game_type")["resolution"]["enumGameType"], 2007)
        self.assertNotIn("constGameType", self.sample("resolver_string_game_type")["resolution"])
        self.assertNotIn("enumGameType", self.sample("resolver_nonfinite_game_type")["resolution"])

    def test_only_raw_canonical_loaded_pair_is_eligible(self):
        for case in ["resolver_missing_module", "resolver_no_canonical", "resolver_package_proxy", "resolver_loaded_proxy"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "billiards_contract_mismatch")
                self.assertEqual(result["resolution"]["contractStatus"], "missing")
                self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_existing_descriptor_is_strict_and_scene_specific(self):
        for case in ["resolver_descriptor_missing", "resolver_descriptor_proxy"]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "logic_descriptor_missing")
            self.assertEqual(result["resolution"]["contractStatus"], "missing")
            self.assertFalse(result["resolution"]["frameCallAttempted"])
        for case in ["resolver_descriptor_invalid_name", "resolver_descriptor_invalid_package",
                     "resolver_descriptor_wrong_scene", "resolver_descriptor_wrong_type", "resolver_descriptor_field_proxy"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "logic_descriptor_invalid")
                self.assertEqual(result["resolution"]["contractStatus"], "invalid")
                self.assertFalse(result["resolution"]["frameCallAttempted"])
        tutorial = self.sample("resolver_tutorial")
        self.assertEqual(tutorial["prediction"]["reason"], "tutorial_physics_unsupported")
        self.assertEqual(tutorial["resolution"]["descriptorName"], "Game/BiTutorialLogic")
        self.assertNotIn("descriptorName", self.sample("resolver_descriptor_invalid_name")["resolution"])
        self.assertNotIn("descriptorPackage", self.sample("resolver_descriptor_invalid_package")["resolution"])

    def test_existing_manager_is_required_without_functional_lookup(self):
        for case, lookup, manager_type in [("resolver_manager_nil", "absent", "nil"),
                                           ("resolver_manager_wrong", "raw", "string"),
                                           ("resolver_manager_proxy", "function_index_blocked", "nil")]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "logic_manager_unavailable")
                self.assertEqual(result["resolution"]["managerLookup"], lookup)
                self.assertEqual(result["resolution"]["managerType"], manager_type)
                self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_manager_getter_lookup_blocks_functions_protection_and_cycles(self):
        for case, lookup in [("resolver_getter_blocked", "function_index_blocked"),
                             ("resolver_getter_protected", "protected_metatable"),
                             ("resolver_getter_cycle", "cycle"),
                             ("resolver_getter_depth_limit", "depth_limit"),
                             ("resolver_getter_error", "error")]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "logic_getter_blocked")
                self.assertEqual(result["resolution"]["managerLookup"], lookup)
                self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_manager_getter_missing_is_distinct_from_blocked(self):
        for case, getter_type in [("resolver_getter_missing", "nil"), ("resolver_getter_wrong", "boolean")]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "logic_getter_missing")
            self.assertEqual(result["resolution"]["managerGetType"], getter_type)
            self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_manager_and_getter_table_inheritance_is_bounded_and_supported(self):
        for case in ["resolver_manager_table", "resolver_getter_table", "resolver_getter_depth_four"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["status"], "aiming")
                self.assertEqual(result["resolution"]["managerLookup"], "metatable_table")
                self.assertTrue(result["resolution"]["frameCallSucceeded"])

    def test_getter_call_success_is_not_frame_success(self):
        thrown = self.sample("resolver_frame_throw")
        self.assertEqual(thrown["prediction"]["reason"], "frame_lookup_failed")
        self.assertTrue(thrown["resolution"]["frameCallAttempted"])
        self.assertFalse(thrown["resolution"]["frameCallSucceeded"])
        self.assertEqual(thrown["resolution"]["frameType"], "nil")
        self.assertNotIn("frameDestroyed", thrown["resolution"])
        for case, frame_type in [("resolver_frame_nil", "nil"), ("resolver_frame_wrong", "boolean"),
                                 ("resolver_frame_destroyed", "table")]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "frame_unavailable")
            self.assertTrue(result["resolution"]["frameCallSucceeded"])
            self.assertEqual(result["resolution"]["frameType"], frame_type)
            self.assertEqual(result["balls"], [])
            self.assertEqual(result["segments"], [])
        self.assertTrue(self.sample("resolver_frame_destroyed")["resolution"]["frameDestroyed"])

    def test_successful_cached_resolution_preserves_downstream_gates(self):
        for case, reason in [("resolver_camera_gate", "camera_unavailable"),
                             ("resolver_moving_gate", "balls_moving")]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], reason)
            self.assertEqual(result["resolution"]["source"], "package_loaded")
            self.assertTrue(result["resolution"]["frameCallSucceeded"])
        scene = self.sample("resolver_scene_gate")
        self.assertEqual(scene["prediction"]["reason"], "scene_not_billiards")
        self.assertFalse(scene["resolution"]["frameCallAttempted"])
        self.assertEqual(scene["resolution"]["source"], "none")

    def test_cached_module_loss_invalidates_session_and_clears_prior_output(self):
        first, unloaded = run_case("resolver_cached_unload")
        self.assertEqual(first["status"], "aiming")
        self.assertEqual(first["resolution"]["source"], "package_loaded")
        self.assertTrue(first["resolution"]["frameCallSucceeded"])
        self.assertTrue(first["balls"])
        self.assertTrue(first["segments"])
        self.assertEqual(unloaded["status"], "unsupported")
        self.assertEqual(unloaded["prediction"]["reason"], "billiards_contract_mismatch")
        self.assertEqual(unloaded["resolution"]["source"], "none")
        self.assertEqual(unloaded["resolution"]["contractStatus"], "missing")
        self.assertFalse(unloaded["resolution"]["frameCallAttempted"])
        self.assertFalse(unloaded["resolution"]["frameCallSucceeded"])
        self.assertEqual(unloaded["resolution"]["frameType"], "nil")
        self.assertEqual(unloaded["sessionId"], first["sessionId"] + 1)
        self.assertEqual(unloaded["balls"], [])
        self.assertEqual(unloaded["segments"], [])
        self.assertNotIn("hasFrame", unloaded["gates"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Exercise the read-only Lua observer with mock Unity objects on Lua 5.3.

Uses SDKTOOLS_LUA_LIBRARY when provided by the build gate. No game source,
app binary or external service is executed; the fixtures are synthetic.
"""
from __future__ import annotations

import ctypes
import ctypes.util
import json
import math
import os
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / "Resources" / "billiards_probe.lua"
FIXTURE = ROOT / "Tests" / "test_billiards_probe.lua"


def load_lua53():
    configured = os.environ.get("SDKTOOLS_LUA_LIBRARY")
    names = [configured] if configured else [
        ctypes.util.find_library("lua5.3"),
        ctypes.util.find_library("texlua53"),
        "liblua5.3.so.0", "libtexlua53.so.5", "liblua5.3.dylib",
    ]
    errors = []
    for name in names:
        if not name:
            continue
        try:
            lib = ctypes.CDLL(name)
            lib.luaL_newstate.argtypes = []
            lib.luaL_newstate.restype = ctypes.c_void_p
            lib.luaL_openlibs.argtypes = [ctypes.c_void_p]
            lib.lua_close.argtypes = [ctypes.c_void_p]
            lib.luaL_loadbufferx.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t,
                                           ctypes.c_char_p, ctypes.c_char_p]
            lib.luaL_loadbufferx.restype = ctypes.c_int
            lib.lua_pushlstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
            lib.lua_pushlstring.restype = ctypes.c_void_p
            lib.lua_pcallk.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_ssize_t, ctypes.c_void_p]
            lib.lua_pcallk.restype = ctypes.c_int
            lib.lua_tolstring.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_size_t)]
            lib.lua_tolstring.restype = ctypes.c_void_p
            return lib
        except (OSError, AttributeError) as exc:
            errors.append(f"{name}: {exc}")
    raise RuntimeError("Lua 5.3 library required. Set SDKTOOLS_LUA_LIBRARY. " + "; ".join(errors))


LUA = load_lua53()


def lua_string(state):
    size = ctypes.c_size_t()
    value = LUA.lua_tolstring(state, -1, ctypes.byref(size))
    if not value:
        raise AssertionError("Lua did not return a string")
    return ctypes.string_at(value, size.value).decode("utf-8")


def run_case(name):
    state = LUA.luaL_newstate()
    if not state:
        raise MemoryError("luaL_newstate")
    try:
        LUA.luaL_openlibs(state)
        source = FIXTURE.read_bytes()
        status = LUA.luaL_loadbufferx(state, source, len(source), b"@SDKtools_probe_tests", b"t")
        if status:
            raise AssertionError(lua_string(state))
        for value in [name, str(PROBE)]:
            value = value.encode("utf-8")
            LUA.lua_pushlstring(state, value, len(value))
        status = LUA.lua_pcallk(state, 2, 1, 0, 0, None)
        if status:
            raise AssertionError(lua_string(state))
        return [json.loads(line) for line in lua_string(state).splitlines()]
    finally:
        LUA.lua_close(state)


class BilliardsProbeTests(unittest.TestCase):
    def sample(self, case):
        result = run_case(case)[0]
        self.assertEqual(result["format"], "SDKtools.BilliardsLive")
        self.assertEqual(result["schemaVersion"], 1)
        self.assertEqual(result["resourceGameId"], 20)
        self.assertEqual(result["gameType"], 1003)
        self.assertIsInstance(result["balls"], list)
        self.assertIsInstance(result["segments"], list)
        self.assertLessEqual(len(result["balls"]), 16)
        self.assertLessEqual(len(result["segments"]), 12)
        resolution = result["resolution"]
        self.assertEqual(resolution["schemaVersion"], 1)
        self.assertIn(resolution["source"], {"none", "globals", "package_loaded"})
        self.assertIn(resolution["contractStatus"], {"missing", "invalid", "conflict", "selected"})
        lua_types = {"nil", "boolean", "number", "string", "function", "userdata", "thread", "table"}
        for field in ["enumType", "constType", "descriptorType", "managerType", "managerGetType", "frameType"]:
            self.assertIn(resolution[field], lua_types)
        self.assertIsInstance(resolution["frameCallAttempted"], bool)
        self.assertIsInstance(resolution["frameCallSucceeded"], bool)
        if resolution["frameCallSucceeded"]:
            self.assertTrue(resolution["frameCallAttempted"])
        if not resolution["frameCallAttempted"]:
            self.assertEqual(resolution["frameType"], "nil")
        if result["status"] != "aiming":
            self.assertFalse(result["prediction"]["available"])
            self.assertEqual(result["segments"], [])
        return result

    def test_three_reflections_and_unsorted_nearest(self):
        result = self.sample("bank")
        self.assertEqual(result["status"], "aiming")
        self.assertTrue(result["prediction"]["available"])
        self.assertEqual(result["prediction"]["bounces"], 3)
        self.assertEqual(result["prediction"]["queries"], 4)
        self.assertEqual(len(result["segments"]), 4)
        self.assertEqual(result["segments"][0]["kind"], "cue")
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 2)
        self.assertLess(result["segments"][1]["worldTo"]["z"], result["segments"][1]["worldFrom"]["z"])
        self.assertEqual(result["screen"], {"width": 1080, "height": 1920})
        self.assertAlmostEqual(result["balls"][0]["radiusPixels"], 16.5)
        self.assertEqual(result["balls"][0]["screen"], {"x": 540, "y": 960, "depth": 9.1})

    def test_head_on_ball_collision(self):
        result = self.sample("ball")
        child = self.sample("child_collider")
        self.assertEqual(child["segments"], result["segments"])
        self.assertEqual([s["kind"] for s in result["segments"]], ["cue", "object"])
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 1.67)
        self.assertAlmostEqual(result["segments"][1]["worldFrom"]["z"], 2.001)
        self.assertEqual(result["prediction"]["bounces"], 0)

    def test_cut_splits_target_and_cue(self):
        result = self.sample("cut")
        self.assertEqual([s["kind"] for s in result["segments"]], ["cue", "object", "cue"])
        a, b = result["segments"][1:]
        av = {k: a["worldTo"][k] - a["worldFrom"][k] for k in "xz"}
        bv = {k: b["worldTo"][k] - b["worldFrom"][k] for k in "xz"}
        self.assertAlmostEqual(av["x"] * bv["x"] + av["z"] * bv["z"], 0, places=7)
        self.assertGreater(av["x"], 0)
        self.assertLess(bv["x"], 0)

    def test_open_object_branch_does_not_cancel_cue_branch(self):
        result = self.sample("open_branch")
        self.assertEqual([s["kind"] for s in result["segments"]], ["cue", "cue"])
        self.assertEqual(result["prediction"]["reason"], "open_path_unknown")
        self.assertEqual(result["prediction"]["queries"], 3)

    def test_unbounded_path_not_drawn(self):
        result = self.sample("open")
        self.assertEqual(result["prediction"]["reason"], "no_bounded_trajectory")
        self.assertEqual(result["segments"], [])

    def test_pocket_stops_before_wall(self):
        for case in ["pocket", "explicit_triggers"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(len(result["segments"]), 1)
                self.assertEqual(result["prediction"]["bounces"], 0)
                self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 2)

    def test_motion_and_spin_hide_guides(self):
        for case in ["moving", "moving_flag", "angular"]:
            with self.subTest(case=case):
                self.assertEqual(self.sample(case)["status"], "moving")

    def test_nonlocal_turn_hides_guides(self):
        for case in ["not_turn", "contradictory_turn"]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], "not_local_turn")

    def test_foreign_scene_and_game_contract(self):
        self.assertEqual(self.sample("foreign_scene")["status"], "wrong_scene")
        self.assertEqual(self.sample("wrong_type")["prediction"]["reason"], "billiards_contract_mismatch")

    def test_in_hand_modal_and_hidden_cue(self):
        for case, reason in [("hand", "white_ball_in_hand"), ("modal", "cue_dialog_visible"), ("hidden", "aim_ui_hidden")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_stale_aim_cannot_reuse_old_guides(self):
        for case in ["stale_aim", "stale_angle"]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], "aim_snapshot_stale")

    def test_ball_identity_and_reuse_validation(self):
        for case, reason in [("duplicate_tag", "invalid_ball_identity"), ("reused_object", "reused_ball_object"),
                             ("too_many_balls", "invalid_ball_collection")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_potted_object_may_be_destroyed(self):
        result = self.sample("potted")
        row = result["balls"][1]
        self.assertFalse(row["active"])
        self.assertTrue(row["potted"])
        self.assertIsNone(row["world"])
        self.assertIsNone(row["screen"])
        self.assertEqual(result["status"], "aiming")

    def test_invalid_live_objects(self):
        for case, reason in [("bad_position", "invalid_ball_geometry"), ("camera_scene", "camera_scene_mismatch"),
                             ("destroyed_ball", "active_ball_object_unavailable"), ("zero_direction", "invalid_cue_direction")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_query_errors_are_bounded_and_clear_guides(self):
        for case, reason in [("query_error", "physics_query_failed"), ("unknown", "unclassified_collider"),
                             ("unmapped", "unmapped_ball_collider"), ("hit_limit", "physics_hit_limit"),
                             ("nan_hit", "invalid_physics_hit"), ("bad_normal", "invalid_cushion_normal"),
                             ("unknown_trigger_policy", "physics_trigger_policy_unknown"),
                             ("foreign_hit_scene", "unclassified_collider")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_tutorial_explicit_scene(self):
        result = self.sample("tutorial")
        self.assertEqual(result["scene"]["name"], "BilliardTutorial")
        self.assertEqual(result["status"], "aiming")

    def test_session_changes_only_for_identity_changes(self):
        values = run_case("sessions")
        ids = [v["sessionId"] for v in values]
        self.assertEqual(ids, [1, 1, 2, 3, 4])

    def test_stop_invalidates_session_and_outputs(self):
        first, stopped = run_case("stop")
        self.assertEqual(stopped["status"], "stopped")
        self.assertGreater(stopped["sessionId"], first["sessionId"])
        self.assertEqual(stopped["balls"], [])
        self.assertEqual(stopped["segments"], [])

    def test_unsupported_command_has_no_queries(self):
        self.assertEqual(self.sample("unsupported_command")["prediction"]["reason"], "unknown_command")

    def test_state_does_not_retain_game(self):
        self.assertEqual(self.sample("weak_state")["status"], "aiming")

    def environment(self, case):
        result = self.sample(case)
        self.assertEqual(result["status"], "not_ready" if case == "env_raw_absent" else "unsupported")
        self.assertEqual(result["prediction"]["reason"],
                         "frame_unavailable" if case == "env_raw_absent" else "billiards_contract_mismatch")
        if case == "env_raw_absent":
            self.assertEqual(result["resolution"]["source"], "package_loaded")
            self.assertTrue(result["resolution"]["frameCallSucceeded"])
            self.assertEqual(result["resolution"]["frameType"], "nil")
        self.assertEqual(result["balls"], [])
        environment = result["environment"]
        self.assertEqual(environment["schemaVersion"], 1)
        self.assertEqual(environment["mode"], "structural_only")
        self.assertEqual(environment["stage"], "before_contract")
        self.assertEqual(len(environment["globals"]), 7)
        self.assertLessEqual(len(environment["modules"]), 24)
        self.assertLessEqual(len(environment["environments"]), 8)
        self.assertLessEqual(environment["scannedKeys"], 512)
        self.assertLessEqual(environment["matchedKeys"], 536)
        self.assertLessEqual(environment["errorCount"], 128)
        self.assertEqual(environment["limits"], {"scanKeys": 512, "modules": 24,
                         "environments": 8, "upvalues": 16, "lookupDepth": 4})
        return environment

    @staticmethod
    def global_row(environment, name):
        return next(row for row in environment["globals"] if row["name"] == name)

    def test_environment_distinguishes_absent_from_other_types(self):
        absent = self.environment("env_raw_absent")
        enum = self.global_row(absent, "Enum")
        self.assertEqual((enum["rawType"], enum["resolvedType"], enum["lookup"]), ("nil", "nil", "absent"))
        self.assertNotIn("enumGameType", absent["environments"][0])
        self.assertFalse(absent["environments"][0]["contractValid"])
        self.assertEqual([r["gameType"] for r in absent["modules"] if "gameType" in r], [1003, 1003])
        self.assertEqual(absent["modules"][2]["environmentIndex"], 1)
        other = self.environment("env_raw_other")
        self.assertEqual(self.global_row(other, "Enum")["rawType"], "boolean")
        self.assertEqual(self.global_row(other, "Const")["rawType"], "string")
        self.assertEqual(self.global_row(other, "BiLogic")["rawType"], "number")

    def test_structural_table_lookup_does_not_enable_gameplay(self):
        environment = self.environment("env_metatable_table")
        enum = self.global_row(environment, "Enum")
        self.assertEqual(enum, {"name": "Enum", "rawType": "nil", "resolvedType": "table",
                         "lookup": "metatable_table", "indexType": "table", "depth": 1})
        self.assertTrue(environment["environments"][0]["contractValid"])

    def test_structural_lookup_blocks_functions_and_opaque_metatables(self):
        for case, reason in [("env_function_blocked", "function_index_blocked"),
                             ("env_protected", "protected_metatable"), ("env_cycle", "cycle"),
                             ("env_depth_limit", "depth_limit"), ("env_metatable_error", "error")]:
            with self.subTest(case=case):
                environment = self.environment(case)
                enum = self.global_row(environment, "Enum")
                self.assertEqual(enum["lookup"], reason)
                self.assertEqual(enum["resolvedType"], "nil")
                self.assertLessEqual(enum["depth"], 4)
                self.assertFalse(environment["environments"][0]["contractValid"])
                if case == "env_metatable_error":
                    self.assertGreater(environment["errorCount"], 0)

    def test_loaded_function_distinct_environment_is_evidence_only(self):
        environment = self.environment("env_distinct")
        self.assertEqual(len(environment["environments"]), 2)
        global_env, alternate = environment["environments"]
        self.assertFalse(global_env["contractValid"])
        self.assertTrue(global_env["sameAsGlobal"])
        self.assertFalse(alternate["sameAsGlobal"])
        self.assertTrue(alternate["contractValid"])
        self.assertEqual(alternate["enumGameType"], 1003)
        self.assertEqual(alternate["constGameType"], 1003)
        self.assertEqual(alternate["source"], "Billiard/Lua/Const/Init")
        module = environment["modules"][0]
        self.assertEqual(module["source"], "known_key")
        self.assertEqual(module["environmentStatus"], "found")
        self.assertEqual(module["environmentIndex"], 2)
        self.assertEqual(module["upvaluesScanned"], 1)

    def test_environment_aliases_deduplicate_by_identity(self):
        environment = self.environment("env_alias")
        self.assertEqual(len(environment["modules"]), 2)
        self.assertEqual(len(environment["environments"]), 2)
        self.assertEqual([r["environmentIndex"] for r in environment["modules"]], [2, 2])

    def test_nested_manager_proxy_is_not_invoked_to_validate_contract(self):
        environment = self.environment("env_nested_index_blocked")
        alternate = environment["environments"][1]
        self.assertEqual(alternate["enumGameType"], 1003)
        self.assertEqual(alternate["constGameType"], 1003)
        self.assertFalse(alternate["contractValid"])

    def test_observed_identity_requires_finite_in_range_integer(self):
        environment = self.environment("env_invalid_game_type")
        alternate = environment["environments"][1]
        self.assertNotIn("enumGameType", alternate)
        self.assertNotIn("constGameType", alternate)
        self.assertEqual(alternate["frameDescriptorType"], "string")
        self.assertFalse(alternate["contractValid"])
        self.assertTrue(all("gameType" not in module for module in environment["modules"]))

    def test_missing_throwing_and_non_environment_upvalues(self):
        for case, reason in [("env_no_debug", "no_debug"), ("env_debug_error", "error"),
                             ("env_no_env", "no_env"), ("env_non_table_env", "non_table_env"),
                             ("env_upvalue_limit", "upvalue_limit")]:
            with self.subTest(case=case):
                environment = self.environment(case)
                module = environment["modules"][0]
                self.assertEqual(module["environmentStatus"], reason)
                self.assertNotIn("environmentIndex", module)
                self.assertEqual(len(environment["environments"]), 1)
                self.assertLessEqual(module["upvaluesScanned"], 16)
                if case == "env_upvalue_limit":
                    self.assertEqual(module["upvaluesScanned"], 16)
                if case == "env_debug_error":
                    self.assertEqual(environment["errorCount"], 1)

    def test_structural_scan_and_environment_limits_are_explicit(self):
        scan = self.environment("env_scan_limit")
        self.assertEqual(scan["scannedKeys"], 512)
        self.assertEqual(scan["matchedKeys"], 512)
        self.assertEqual(len(scan["modules"]), 24)
        self.assertTrue(scan["scanTruncated"])
        self.assertTrue(scan["modulesTruncated"])
        environments = self.environment("env_environment_limit")
        self.assertEqual(len(environments["environments"]), 8)
        self.assertTrue(environments["environmentsTruncated"])
        self.assertEqual(sum(m["environmentStatus"] == "env_limit" for m in environments["modules"]), 5)

    def test_module_discovery_filters_names_and_never_initializes_modules(self):
        environment = self.environment("env_unknown_module")
        self.assertEqual({m["name"] for m in environment["modules"]},
                         {"Billiard/Lua/PreviouslyUnknown", "Billiard.Lua.Dotted"})
        self.assertTrue(all(m["source"] == "loaded_scan" for m in environment["modules"]))
        blocked = self.environment("env_loaded_proxy_blocked")
        self.assertEqual(blocked["packageType"], "table")
        self.assertEqual(blocked["loadedType"], "nil")
        self.assertEqual(blocked["modules"], [])

    def test_structural_report_only_runs_in_loaded_billiard_scene(self):
        for case in ["foreign_scene", "scene_not_loaded", "stop", "unsupported_command"]:
            result = run_case(case)[-1]
            self.assertNotIn("environment", result)
        first, second = run_case("env_sequence")
        self.assertEqual([first["environment"]["sequence"], second["environment"]["sequence"]], [1, 2])
        self.assertEqual(first["environment"]["environments"], second["environment"]["environments"])

    def test_cached_modules_resolve_captured_root_without_global_lookup(self):
        result = self.sample("loaded_modules")
        self.assertEqual(result["status"], "aiming")
        self.assertFalse(result["gates"]["hasEnum"])
        self.assertFalse(result["gates"]["hasConst"])
        self.assertTrue(result["gates"]["hasFrame"])
        self.assertTrue(result["gates"]["hasCamera"])
        self.assertEqual(result["resolution"], {
            "schemaVersion": 1, "source": "package_loaded", "contractStatus": "selected",
            "enumType": "table", "constType": "table", "enumGameType": 1003, "constGameType": 1003,
            "descriptorType": "table", "descriptorName": "Game/BiFrameLogic", "descriptorPackage": "Billiard",
            "managerType": "table", "managerGetType": "function", "managerLookup": "raw",
            "frameCallAttempted": True, "frameCallSucceeded": True, "frameType": "table", "frameDestroyed": False})
        environment = result["environment"]
        self.assertEqual(self.global_row(environment, "Enum")["lookup"], "function_index_blocked")
        init = next(m for m in environment["modules"] if m["name"] == "Billiard/Lua/Const/Init")
        self.assertEqual(init["environmentIndex"], 1)
        self.assertTrue(environment["environments"][0]["sameAsGlobal"])
        self.assertEqual(len(result["balls"]), 2)

    def test_global_pair_preferred_and_partial_identity_verified(self):
        for case, source in [("bank", "globals"), ("resolver_global_preferred", "globals"),
                             ("resolver_partial_enum", "package_loaded"),
                             ("resolver_partial_const", "package_loaded"),
                             ("resolver_global_namespace_proxy", "package_loaded")]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["status"], "aiming")
                self.assertEqual(result["resolution"]["source"], source)
        for case in ["resolver_partial_conflict_enum", "resolver_partial_conflict_const"]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "billiards_contract_conflict")
            self.assertEqual(result["resolution"]["contractStatus"], "conflict")
            self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_cached_module_contract_rejects_wrong_types_and_identity(self):
        for case in ["resolver_namespace_wrong", "resolver_global_module_wrong", "resolver_wrong_game_type",
                     "resolver_string_game_type", "resolver_nonfinite_game_type", "resolver_module_wrong",
                     "resolver_game_type_proxy"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "billiards_contract_mismatch")
                self.assertEqual(result["resolution"]["contractStatus"], "invalid")
                self.assertEqual(result["resolution"]["source"], "none")
                self.assertFalse(result["resolution"]["frameCallAttempted"])
        self.assertEqual(self.sample("resolver_wrong_game_type")["resolution"]["enumGameType"], 2007)
        self.assertNotIn("constGameType", self.sample("resolver_string_game_type")["resolution"])
        self.assertNotIn("enumGameType", self.sample("resolver_nonfinite_game_type")["resolution"])

    def test_only_raw_canonical_loaded_pair_is_eligible(self):
        for case in ["resolver_missing_module", "resolver_no_canonical", "resolver_package_proxy", "resolver_loaded_proxy"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "billiards_contract_mismatch")
                self.assertEqual(result["resolution"]["contractStatus"], "missing")
                self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_existing_descriptor_is_strict_and_scene_specific(self):
        for case in ["resolver_descriptor_missing", "resolver_descriptor_proxy"]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "logic_descriptor_missing")
            self.assertEqual(result["resolution"]["contractStatus"], "missing")
            self.assertFalse(result["resolution"]["frameCallAttempted"])
        for case in ["resolver_descriptor_invalid_name", "resolver_descriptor_invalid_package",
                     "resolver_descriptor_wrong_scene", "resolver_descriptor_wrong_type", "resolver_descriptor_field_proxy"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "logic_descriptor_invalid")
                self.assertEqual(result["resolution"]["contractStatus"], "invalid")
                self.assertFalse(result["resolution"]["frameCallAttempted"])
        tutorial = self.sample("resolver_tutorial")
        self.assertEqual(tutorial["status"], "aiming")
        self.assertEqual(tutorial["resolution"]["descriptorName"], "Game/BiTutorialLogic")
        self.assertNotIn("descriptorName", self.sample("resolver_descriptor_invalid_name")["resolution"])
        self.assertNotIn("descriptorPackage", self.sample("resolver_descriptor_invalid_package")["resolution"])

    def test_existing_manager_is_required_without_functional_lookup(self):
        for case, lookup, manager_type in [("resolver_manager_nil", "absent", "nil"),
                                           ("resolver_manager_wrong", "raw", "string"),
                                           ("resolver_manager_proxy", "function_index_blocked", "nil")]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "logic_manager_unavailable")
                self.assertEqual(result["resolution"]["managerLookup"], lookup)
                self.assertEqual(result["resolution"]["managerType"], manager_type)
                self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_manager_getter_lookup_blocks_functions_protection_and_cycles(self):
        for case, lookup in [("resolver_getter_blocked", "function_index_blocked"),
                             ("resolver_getter_protected", "protected_metatable"),
                             ("resolver_getter_cycle", "cycle"),
                             ("resolver_getter_depth_limit", "depth_limit"),
                             ("resolver_getter_error", "error")]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["prediction"]["reason"], "logic_getter_blocked")
                self.assertEqual(result["resolution"]["managerLookup"], lookup)
                self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_manager_getter_missing_is_distinct_from_blocked(self):
        for case, getter_type in [("resolver_getter_missing", "nil"), ("resolver_getter_wrong", "boolean")]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "logic_getter_missing")
            self.assertEqual(result["resolution"]["managerGetType"], getter_type)
            self.assertFalse(result["resolution"]["frameCallAttempted"])

    def test_manager_and_getter_table_inheritance_is_bounded_and_supported(self):
        for case in ["resolver_manager_table", "resolver_getter_table", "resolver_getter_depth_four"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(result["status"], "aiming")
                self.assertEqual(result["resolution"]["managerLookup"], "metatable_table")
                self.assertTrue(result["resolution"]["frameCallSucceeded"])

    def test_getter_call_success_is_not_frame_success(self):
        thrown = self.sample("resolver_frame_throw")
        self.assertEqual(thrown["prediction"]["reason"], "frame_lookup_failed")
        self.assertTrue(thrown["resolution"]["frameCallAttempted"])
        self.assertFalse(thrown["resolution"]["frameCallSucceeded"])
        self.assertEqual(thrown["resolution"]["frameType"], "nil")
        self.assertNotIn("frameDestroyed", thrown["resolution"])
        for case, frame_type in [("resolver_frame_nil", "nil"), ("resolver_frame_wrong", "boolean"),
                                 ("resolver_frame_destroyed", "table")]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], "frame_unavailable")
            self.assertTrue(result["resolution"]["frameCallSucceeded"])
            self.assertEqual(result["resolution"]["frameType"], frame_type)
            self.assertEqual(result["balls"], [])
            self.assertEqual(result["segments"], [])
        self.assertTrue(self.sample("resolver_frame_destroyed")["resolution"]["frameDestroyed"])

    def test_successful_cached_resolution_preserves_downstream_gates(self):
        for case, reason in [("resolver_camera_gate", "camera_unavailable"),
                             ("resolver_moving_gate", "balls_moving")]:
            result = self.sample(case)
            self.assertEqual(result["prediction"]["reason"], reason)
            self.assertEqual(result["resolution"]["source"], "package_loaded")
            self.assertTrue(result["resolution"]["frameCallSucceeded"])
        scene = self.sample("resolver_scene_gate")
        self.assertEqual(scene["prediction"]["reason"], "scene_not_billiards")
        self.assertFalse(scene["resolution"]["frameCallAttempted"])
        self.assertEqual(scene["resolution"]["source"], "none")

    def test_cached_module_loss_invalidates_session_and_clears_prior_output(self):
        first, unloaded = run_case("resolver_cached_unload")
        self.assertEqual(first["status"], "aiming")
        self.assertEqual(first["resolution"]["source"], "package_loaded")
        self.assertTrue(first["resolution"]["frameCallSucceeded"])
        self.assertTrue(first["balls"])
        self.assertTrue(first["segments"])
        self.assertEqual(unloaded["status"], "unsupported")
        self.assertEqual(unloaded["prediction"]["reason"], "billiards_contract_mismatch")
        self.assertEqual(unloaded["resolution"]["source"], "none")
        self.assertEqual(unloaded["resolution"]["contractStatus"], "missing")
        self.assertFalse(unloaded["resolution"]["frameCallAttempted"])
        self.assertFalse(unloaded["resolution"]["frameCallSucceeded"])
        self.assertEqual(unloaded["resolution"]["frameType"], "nil")
        self.assertEqual(unloaded["sessionId"], first["sessionId"] + 1)
        self.assertEqual(unloaded["balls"], [])
        self.assertEqual(unloaded["segments"], [])
        self.assertNotIn("hasFrame", unloaded["gates"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Exercise the read-only Lua observer with mock Unity objects on Lua 5.3.

Uses SDKTOOLS_LUA_LIBRARY when provided by the build gate. No game source,
app binary or external service is executed; the fixtures are synthetic.
"""
from __future__ import annotations

import ctypes
import ctypes.util
import json
import math
import os
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / "Resources" / "billiards_probe.lua"
FIXTURE = ROOT / "Tests" / "test_billiards_probe.lua"


def load_lua53():
    configured = os.environ.get("SDKTOOLS_LUA_LIBRARY")
    names = [configured] if configured else [
        ctypes.util.find_library("lua5.3"),
        ctypes.util.find_library("texlua53"),
        "liblua5.3.so.0", "libtexlua53.so.5", "liblua5.3.dylib",
    ]
    errors = []
    for name in names:
        if not name:
            continue
        try:
            lib = ctypes.CDLL(name)
            lib.luaL_newstate.argtypes = []
            lib.luaL_newstate.restype = ctypes.c_void_p
            lib.luaL_openlibs.argtypes = [ctypes.c_void_p]
            lib.lua_close.argtypes = [ctypes.c_void_p]
            lib.luaL_loadbufferx.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t,
                                           ctypes.c_char_p, ctypes.c_char_p]
            lib.luaL_loadbufferx.restype = ctypes.c_int
            lib.lua_pushlstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
            lib.lua_pushlstring.restype = ctypes.c_void_p
            lib.lua_pcallk.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_ssize_t, ctypes.c_void_p]
            lib.lua_pcallk.restype = ctypes.c_int
            lib.lua_tolstring.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_size_t)]
            lib.lua_tolstring.restype = ctypes.c_void_p
            return lib
        except (OSError, AttributeError) as exc:
            errors.append(f"{name}: {exc}")
    raise RuntimeError("Lua 5.3 library required. Set SDKTOOLS_LUA_LIBRARY. " + "; ".join(errors))


LUA = load_lua53()


def lua_string(state):
    size = ctypes.c_size_t()
    value = LUA.lua_tolstring(state, -1, ctypes.byref(size))
    if not value:
        raise AssertionError("Lua did not return a string")
    return ctypes.string_at(value, size.value).decode("utf-8")


def run_case(name):
    state = LUA.luaL_newstate()
    if not state:
        raise MemoryError("luaL_newstate")
    try:
        LUA.luaL_openlibs(state)
        source = FIXTURE.read_bytes()
        status = LUA.luaL_loadbufferx(state, source, len(source), b"@SDKtools_probe_tests", b"t")
        if status:
            raise AssertionError(lua_string(state))
        for value in [name, str(PROBE)]:
            value = value.encode("utf-8")
            LUA.lua_pushlstring(state, value, len(value))
        status = LUA.lua_pcallk(state, 2, 1, 0, 0, None)
        if status:
            raise AssertionError(lua_string(state))
        return [json.loads(line) for line in lua_string(state).splitlines()]
    finally:
        LUA.lua_close(state)


class BilliardsProbeTests(unittest.TestCase):
    def sample(self, case):
        result = run_case(case)[0]
        self.assertEqual(result["format"], "SDKtools.BilliardsLive")
        self.assertEqual(result["schemaVersion"], 1)
        self.assertEqual(result["resourceGameId"], 20)
        self.assertEqual(result["gameType"], 1003)
        self.assertIsInstance(result["balls"], list)
        self.assertIsInstance(result["segments"], list)
        self.assertLessEqual(len(result["balls"]), 16)
        self.assertLessEqual(len(result["segments"]), 12)
        if result["status"] != "aiming":
            self.assertFalse(result["prediction"]["available"])
            self.assertEqual(result["segments"], [])
        return result

    def test_three_reflections_and_unsorted_nearest(self):
        result = self.sample("bank")
        self.assertEqual(result["status"], "aiming")
        self.assertTrue(result["prediction"]["available"])
        self.assertEqual(result["prediction"]["bounces"], 3)
        self.assertEqual(result["prediction"]["queries"], 4)
        self.assertEqual(len(result["segments"]), 4)
        self.assertEqual(result["segments"][0]["kind"], "cue")
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 2)
        self.assertLess(result["segments"][1]["worldTo"]["z"], result["segments"][1]["worldFrom"]["z"])
        self.assertEqual(result["screen"], {"width": 1080, "height": 1920})
        self.assertAlmostEqual(result["balls"][0]["radiusPixels"], 16.5)
        self.assertEqual(result["balls"][0]["screen"], {"x": 540, "y": 960, "depth": 9.1})

    def test_head_on_ball_collision(self):
        result = self.sample("ball")
        child = self.sample("child_collider")
        self.assertEqual(child["segments"], result["segments"])
        self.assertEqual([s["kind"] for s in result["segments"]], ["cue", "object"])
        self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 1.67)
        self.assertAlmostEqual(result["segments"][1]["worldFrom"]["z"], 2.001)
        self.assertEqual(result["prediction"]["bounces"], 0)

    def test_cut_splits_target_and_cue(self):
        result = self.sample("cut")
        self.assertEqual([s["kind"] for s in result["segments"]], ["cue", "object", "cue"])
        a, b = result["segments"][1:]
        av = {k: a["worldTo"][k] - a["worldFrom"][k] for k in "xz"}
        bv = {k: b["worldTo"][k] - b["worldFrom"][k] for k in "xz"}
        self.assertAlmostEqual(av["x"] * bv["x"] + av["z"] * bv["z"], 0, places=7)
        self.assertGreater(av["x"], 0)
        self.assertLess(bv["x"], 0)

    def test_open_object_branch_does_not_cancel_cue_branch(self):
        result = self.sample("open_branch")
        self.assertEqual([s["kind"] for s in result["segments"]], ["cue", "cue"])
        self.assertEqual(result["prediction"]["reason"], "open_path_unknown")
        self.assertEqual(result["prediction"]["queries"], 3)

    def test_unbounded_path_not_drawn(self):
        result = self.sample("open")
        self.assertEqual(result["prediction"]["reason"], "no_bounded_trajectory")
        self.assertEqual(result["segments"], [])

    def test_pocket_stops_before_wall(self):
        for case in ["pocket", "explicit_triggers"]:
            with self.subTest(case=case):
                result = self.sample(case)
                self.assertEqual(len(result["segments"]), 1)
                self.assertEqual(result["prediction"]["bounces"], 0)
                self.assertAlmostEqual(result["segments"][0]["worldTo"]["z"], 2)

    def test_motion_and_spin_hide_guides(self):
        for case in ["moving", "moving_flag", "angular"]:
            with self.subTest(case=case):
                self.assertEqual(self.sample(case)["status"], "moving")

    def test_nonlocal_turn_hides_guides(self):
        for case in ["not_turn", "contradictory_turn"]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], "not_local_turn")

    def test_foreign_scene_and_game_contract(self):
        self.assertEqual(self.sample("foreign_scene")["status"], "wrong_scene")
        self.assertEqual(self.sample("wrong_type")["prediction"]["reason"], "billiards_contract_mismatch")

    def test_in_hand_modal_and_hidden_cue(self):
        for case, reason in [("hand", "white_ball_in_hand"), ("modal", "cue_dialog_visible"), ("hidden", "aim_ui_hidden")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_stale_aim_cannot_reuse_old_guides(self):
        for case in ["stale_aim", "stale_angle"]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], "aim_snapshot_stale")

    def test_ball_identity_and_reuse_validation(self):
        for case, reason in [("duplicate_tag", "invalid_ball_identity"), ("reused_object", "reused_ball_object"),
                             ("too_many_balls", "invalid_ball_collection")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_potted_object_may_be_destroyed(self):
        result = self.sample("potted")
        row = result["balls"][1]
        self.assertFalse(row["active"])
        self.assertTrue(row["potted"])
        self.assertIsNone(row["world"])
        self.assertIsNone(row["screen"])
        self.assertEqual(result["status"], "aiming")

    def test_invalid_live_objects(self):
        for case, reason in [("bad_position", "invalid_ball_geometry"), ("camera_scene", "camera_scene_mismatch"),
                             ("destroyed_ball", "active_ball_object_unavailable"), ("zero_direction", "invalid_cue_direction")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_query_errors_are_bounded_and_clear_guides(self):
        for case, reason in [("query_error", "physics_query_failed"), ("unknown", "unclassified_collider"),
                             ("unmapped", "unmapped_ball_collider"), ("hit_limit", "physics_hit_limit"),
                             ("nan_hit", "invalid_physics_hit"), ("bad_normal", "invalid_cushion_normal"),
                             ("unknown_trigger_policy", "physics_trigger_policy_unknown"),
                             ("foreign_hit_scene", "unclassified_collider")]:
            self.assertEqual(self.sample(case)["prediction"]["reason"], reason)

    def test_tutorial_explicit_scene(self):
        result = self.sample("tutorial")
        self.assertEqual(result["scene"]["name"], "BilliardTutorial")
        self.assertEqual(result["status"], "aiming")

    def test_session_changes_only_for_identity_changes(self):
        values = run_case("sessions")
        ids = [v["sessionId"] for v in values]
        self.assertEqual(ids, [1, 1, 2, 3, 4])

    def test_stop_invalidates_session_and_outputs(self):
        first, stopped = run_case("stop")
        self.assertEqual(stopped["status"], "stopped")
        self.assertGreater(stopped["sessionId"], first["sessionId"])
        self.assertEqual(stopped["balls"], [])
        self.assertEqual(stopped["segments"], [])

    def test_unsupported_command_has_no_queries(self):
        self.assertEqual(self.sample("unsupported_command")["prediction"]["reason"], "unknown_command")

    def test_state_does_not_retain_game(self):
        self.assertEqual(self.sample("weak_state")["status"], "aiming")


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Build a pinned host-only Lua 5.3 test dependency; never copy it into the IPA.

Upstream SHA-256 and byte count: https://www.lua.org/ftp/ (Lua 5.3.6).
This exercises Lua 5.3 syntax/behavior, not the game's XLua/Unity ABI.
"""
import argparse
import hashlib
import io
from pathlib import Path, PurePosixPath
import platform
import shutil
import subprocess
import sys
import tarfile
import urllib.parse
import urllib.request


URL = 'https://www.lua.org/ftp/lua-5.3.6.tar.gz'
SIZE = 303770
SHA256 = 'fc5fd69bb8736323f026672b1b7235da613d7177e72558893a0bdcd320466d60'


class SameOriginHTTPS(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, target):
        parsed = urllib.parse.urlsplit(target)
        if parsed.scheme != 'https' or parsed.netloc != 'www.lua.org':
            raise ValueError('Redirecionamento do download Lua para origem não permitida.')
        return super().redirect_request(request, fp, code, message, headers, target)


def prepare(destination):
    if platform.system() != 'Darwin':
        raise ValueError('Este preparador compila apenas a dependência de testes macOS.')
    destination = destination.absolute()
    if destination.exists() or destination.is_symlink():
        raise ValueError('A pasta da dependência deve ser nova.')
    if not destination.parent.is_dir():
        raise ValueError('A pasta pai da dependência não existe.')
    opener = urllib.request.build_opener(SameOriginHTTPS())
    with opener.open(URL, timeout=30) as response:
        data = response.read(SIZE + 1)
    if len(data) != SIZE or hashlib.sha256(data).hexdigest() != SHA256:
        raise ValueError('Tamanho ou SHA-256 da dependência Lua diverge do upstream fixado.')

    payloads = {}
    names = set()
    total = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if (len(names) >= 256 or member.name in names or path.is_absolute()
                    or '..' in path.parts or '.' in path.parts or '\\' in member.name
                    or str(path) != member.name.rstrip('/')
                    or not path.parts or path.parts[0] != 'lua-5.3.6'
                    or not (member.isfile() or member.isdir())):
                raise ValueError('Entrada de dependência Lua inválida: ' + member.name)
            names.add(member.name)
            if not 0 <= member.size <= 512 * 1024:
                raise ValueError('Entrada de dependência Lua excede limite.')
            total += member.size
            if total > 4 * 1024 * 1024:
                raise ValueError('Dependência Lua expandida excede limite.')
            if member.isfile() and len(path.parts) == 3 and path.parts[1] == 'src' and path.suffix in ('.c', '.h'):
                stream = archive.extractfile(member)
                if stream is None:
                    raise ValueError('Fonte Lua não pode ser lido.')
                with stream:
                    value = stream.read(member.size + 1)
                if len(value) != member.size:
                    raise ValueError('Fonte Lua truncado.')
                payloads[path.name] = value
    if not {'lua.h', 'lauxlib.h', 'lualib.h', 'luaconf.h', 'lapi.c', 'lstate.c'} <= payloads.keys():
        raise ValueError('Dependência Lua não contém os fontes obrigatórios.')

    destination.mkdir(mode=0o700)
    try:
        for name, value in payloads.items():
            (destination / name).write_bytes(value)
        sources = sorted(str(destination / name) for name in payloads
                         if name.endswith('.c') and name not in ('lua.c', 'luac.c'))
        library = destination / 'liblua53-sdktools-tests.dylib'
        subprocess.run(['xcrun', '--sdk', 'macosx', 'clang', '-dynamiclib', '-O2',
                        '-fPIC', '-DLUA_USE_MACOSX', *sources, '-o', str(library)],
                       check=True, stdout=sys.stderr, stderr=sys.stderr, timeout=120)
        if not library.is_file() or library.is_symlink():
            raise ValueError('A compilação não produziu a biblioteca de testes.')
        return library
    except BaseException:
        shutil.rmtree(destination)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', required=True, type=Path)
    args = parser.parse_args()
    try:
        print(prepare(args.output_directory))
    except (OSError, ValueError, tarfile.TarError, subprocess.SubprocessError) as error:
        raise SystemExit('Preparação Lua bloqueada: ' + str(error))


if __name__ == '__main__':
    main()

#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if [[ "$(uname -s)" != Darwin ]]; then
  echo "Native scene codec tests require macOS Foundation and Xcode command-line tools." >&2
  exit 2
fi
TEST_BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-codec.XXXXXX")"
trap 'rm -rf "$TEST_BUILD_DIR"' EXIT
xcrun --sdk macosx clang -fobjc-arc -Wall -Wextra -Werror \
  -I "$ROOT_DIR/Sources/SDKtools" \
  "$ROOT_DIR/Sources/SDKtools/STSceneCodec.m" "$ROOT_DIR/Tests/scene_codec_test.m" \
  -framework Foundation -framework CoreFoundation -o "$TEST_BUILD_DIR/scene_codec_test"
"$TEST_BUILD_DIR/scene_codec_test" "$@"

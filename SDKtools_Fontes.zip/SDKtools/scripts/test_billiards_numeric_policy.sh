#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-billiards-numeric.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror \
    -fsanitize=undefined,float-cast-overflow -fno-sanitize-recover=all \
    "$project_root/Tests/billiards_numeric_policy_test.c" \
    -o "$test_workspace/billiards-numeric" -lm
"$test_workspace/billiards-numeric"

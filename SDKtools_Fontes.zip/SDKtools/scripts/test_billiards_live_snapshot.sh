#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-billiards-live-snapshot.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
# Exercise the real Lua producer and the Foundation sanitizer together. This
# uses synthetic game objects, never the app or a live Lua state.
python3 - "$project_root" "$test_workspace" <<'PY'
import json
from pathlib import Path
import sys
root, workspace = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(root / 'scripts'))
from test_billiards_probe import run_case
for case, name in [('env_distinct','environment'), ('loaded_modules','resolution'),
                   ('finite_chain','chain'), ('finite_rest','finite_rest'),
                   ('finite_moving','finite_moving'), ('finite_unknown_power','finite_unknown_power')]:
    samples = run_case(case)
    if len(samples) != 1:
        raise SystemExit(f'Unexpected {case} fixture sample count')
    (workspace / (name + '.json')).write_text(json.dumps(samples[0]), encoding='utf-8')
# Compile the actual pure Foundation observation helpers, not test copies.
runtime = (root / 'Sources/SDKtools/STBilliardsRuntime.m').read_text()
helpers = runtime[runtime.index('static BOOL STBLShotFiniteNumber('):runtime.index('static NSError *STBLError(')]
assert 'static BOOL STBLShotSameContext(' in helpers and 'static BOOL STBLShotObservedRest(' in helpers
(workspace / 'shot_helpers.h').write_text('#import <Foundation/Foundation.h>\n#import <CoreFoundation/CoreFoundation.h>\n#include <math.h>\n' + helpers)
PY
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
    -Werror=implicit-function-declaration -framework Foundation -framework CoreFoundation \
    -DSTBL_TEST_RUNTIME_HELPERS=1 -I "$test_workspace" \
    "$project_root/Tests/billiards_live_snapshot_test.m" \
    "$project_root/Sources/SDKtools/STBilliardsLiveSnapshot.m" \
    "$project_root/Sources/SDKtools/STBilliardsCaptureReport.m" \
    -o "$test_workspace/billiards-live-snapshot"
"$test_workspace/billiards-live-snapshot" "$test_workspace/environment.json" "$test_workspace/resolution.json" "$test_workspace/chain.json" \
    "$test_workspace/finite_rest.json" "$test_workspace/finite_moving.json" "$test_workspace/finite_unknown_power.json"

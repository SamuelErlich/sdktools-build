#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-billiards-live-snapshot.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
# Exercise the real Lua producer and the Foundation sanitizer together. This
# uses synthetic game objects, never the app or a live Lua state.
python3 - "$project_root" "$test_workspace/environment.json" <<'PY'
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(sys.argv[1]) / 'scripts'))
from test_billiards_probe import run_case
samples = run_case('env_distinct')
if len(samples) != 1:
    raise SystemExit('Unexpected environment fixture sample count')
Path(sys.argv[2]).write_text(json.dumps(samples[0]), encoding='utf-8')
PY
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
    -Werror=implicit-function-declaration -framework Foundation -framework CoreFoundation \
    "$project_root/Tests/billiards_live_snapshot_test.m" \
    "$project_root/Sources/SDKtools/STBilliardsLiveSnapshot.m" \
    -o "$test_workspace/billiards-live-snapshot"
"$test_workspace/billiards-live-snapshot" "$test_workspace/environment.json"

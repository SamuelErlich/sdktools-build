#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { printf '%s\n' 'Este teste exige macOS com Foundation.' >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/sdktools-billiards-live-snapshot.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
xcrun --sdk macosx clang -fobjc-arc -fblocks -fmodules -Wall -Wextra \
    -Werror=implicit-function-declaration -framework Foundation -framework CoreFoundation \
    "$project_root/Tests/billiards_live_snapshot_test.m" \
    "$project_root/Sources/SDKtools/STBilliardsLiveSnapshot.m" \
    -o "$test_workspace/billiards-live-snapshot"
"$test_workspace/billiards-live-snapshot"

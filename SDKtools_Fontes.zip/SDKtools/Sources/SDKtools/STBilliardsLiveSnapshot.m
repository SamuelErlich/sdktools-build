#import "STBilliardsLiveSnapshot.h"
#import "STBilliardsLivePolicy.h"
#import "STBilliardsNumericPolicy.h"

static const NSUInteger STBLMaxSegments=12;
static BOOL STBLNumber(id value, double minimum, double maximum, double *out) {
    if (![value isKindOfClass:NSNumber.class] || CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID()) return NO;
    double number=[value doubleValue];
    if (!isfinite(number) || number<minimum || number>maximum) return NO;
    if (out) *out=number;
    return YES;
}
static BOOL STBLInteger(id value, int64_t minimum, int64_t maximum, int64_t *out) {
    if (![value isKindOfClass:NSNumber.class] || CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID()) return NO;
    const char *encoding=[value objCType];
    if (!encoding || !encoding[0] || encoding[1]) return NO;
    // Preserve signedness until after range validation. A large unsigned
    // NSNumber must never become a valid negative Unity instance ID.
    switch (encoding[0]) {
        case 'C': case 'S': case 'I': case 'L': case 'Q':
            return STBLReadUnsignedInteger([value unsignedLongLongValue],minimum,maximum,out);
        case 'c': case 's': case 'i': case 'l': case 'q':
            return STBLReadSignedInteger([value longLongValue],minimum,maximum,out);
        case 'f': case 'd':
            return STBLReadFloatingInteger([value doubleValue],minimum,maximum,out);
        default:
            return NO;
    }
}
static BOOL STBLBoolean(id value) {
    return [value isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID();
}
NSString *STBilliardsDiagnosticToken(id value) {
    if (![value isKindOfClass:NSString.class] || ![value length] || [value length]>96) return @"unavailable";
    static NSCharacterSet *invalid;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ invalid=[[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_ .:/()-"] invertedSet]; });
    return [value rangeOfCharacterFromSet:invalid].location==NSNotFound ? [value copy] : @"unavailable";
}
static NSDictionary *STBLVector(id value, BOOL screen, double width, double height) {
    if (![value isKindOfClass:NSDictionary.class]) return nil;
    double x,y,z;
    if (!STBLNumber(value[@"x"],-1000000,1000000,&x) || !STBLNumber(value[@"y"],-1000000,1000000,&y) ||
        !STBLNumber(value[screen?@"depth":@"z"],-1000000,1000000,&z)) return nil;
    if (screen && !STBLValidPoint((STBLPoint){x,y,z},width,height)) return nil;
    return screen ? @{@"x":@(x),@"y":@(y),@"depth":@(z)} : @{@"x":@(x),@"y":@(y),@"z":@(z)};
}

/* Environment evidence is optional and never an authority for drawing. Reject
 * the whole diagnostic on a malformed known field; unknown fields are simply
 * omitted, without traversing or serializing their values. */
static NSString *STBLEnvironmentToken(id value, NSArray<NSString *> *allowed) {
    return [value isKindOfClass:NSString.class] && [allowed containsObject:value] ? [value copy] : nil;
}
static NSString *STBLLuaType(id value) {
    return STBLEnvironmentToken(value,@[@"nil",@"boolean",@"number",@"string",@"table",@"function",@"userdata",@"thread"]);
}
static NSString *STBLBilliardsModuleName(id value) {
    if (![value isKindOfClass:NSString.class] || [value length]>96) return nil;
    NSString *name=value;
    if (![name hasPrefix:@"Billiard/"] && ![name hasPrefix:@"billiard/"] &&
        ![name hasPrefix:@"Billiard."] && ![name hasPrefix:@"billiard."]) return nil;
    static NSCharacterSet *invalid, *separators;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        invalid=[[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_/."] invertedSet];
        separators=[NSCharacterSet characterSetWithCharactersInString:@"/."];
    });
    if ([name rangeOfCharacterFromSet:invalid].location!=NSNotFound) return nil;
    for (NSString *part in [name componentsSeparatedByCharactersInSet:separators])
        if (!part.length) return nil;
    return [name copy];
}
static BOOL STBLEnvironmentInteger(NSDictionary *raw, NSMutableDictionary *safe, NSString *key,
                                 int64_t minimum, int64_t maximum, BOOL optional) {
    id item=raw[key];
    if (!item) return optional;
    int64_t value;
    if (!STBLInteger(item,minimum,maximum,&value)) return NO;
    safe[key]=@(value);
    return YES;
}
static NSDictionary *STBLEnvironment(id raw) {
    if (![raw isKindOfClass:NSDictionary.class]) return nil;
    NSDictionary *input=raw;
    NSString *mode=STBLEnvironmentToken(input[@"mode"],@[@"structural_only"]);
    NSString *stage=STBLEnvironmentToken(input[@"stage"],@[@"before_contract"]);
    if (!mode || !stage) return nil;
    NSMutableDictionary *safe=[@{@"mode":mode,@"stage":stage} mutableCopy];
    if (!STBLEnvironmentInteger(input,safe,@"schemaVersion",1,1,NO) ||
        !STBLEnvironmentInteger(input,safe,@"sequence",0,INT32_MAX,NO) ||
        !STBLEnvironmentInteger(input,safe,@"scannedKeys",0,512,NO) ||
        !STBLEnvironmentInteger(input,safe,@"matchedKeys",0,536,NO) ||
        !STBLEnvironmentInteger(input,safe,@"errorCount",0,128,NO)) return nil;
    for (NSString *key in @[@"packageType",@"loadedType",@"debugType",@"getupvalueType"]) {
        NSString *type=STBLLuaType(input[key]);
        if (!type) return nil;
        safe[key]=type;
    }
    for (NSString *key in @[@"scanTruncated",@"modulesTruncated",@"environmentsTruncated"]) {
        if (!STBLBoolean(input[key])) return nil;
        safe[key]=input[key];
    }
    NSDictionary *limits=input[@"limits"];
    if (![limits isKindOfClass:NSDictionary.class]) return nil;
    NSMutableDictionary *safeLimits=[NSMutableDictionary dictionary];
    NSDictionary *maximums=@{@"scanKeys":@512,@"modules":@24,@"environments":@8,@"upvalues":@16,@"lookupDepth":@4};
    for (NSString *key in maximums) {
        int64_t maximum=[maximums[key] longLongValue];
        if (!STBLEnvironmentInteger(limits,safeLimits,key,maximum,maximum,NO)) return nil;
    }
    safe[@"limits"]=safeLimits;
    NSArray *globals=input[@"globals"], *modules=input[@"modules"], *environments=input[@"environments"];
    if (![globals isKindOfClass:NSArray.class] || globals.count>7 ||
        ![modules isKindOfClass:NSArray.class] || modules.count>24 ||
        ![environments isKindOfClass:NSArray.class] || environments.count>8) return nil;
    NSMutableArray *safeGlobals=[NSMutableArray array], *safeModules=[NSMutableArray array], *safeEnvironments=[NSMutableArray array];
    for (id entry in globals) {
        if (![entry isKindOfClass:NSDictionary.class]) return nil;
        NSString *name=STBLEnvironmentToken(entry[@"name"],@[@"Core",@"Enum",@"Const",@"BiLogic",@"package",@"debug",@"CS"]);
        NSString *rawType=STBLLuaType(entry[@"rawType"]), *resolvedType=STBLLuaType(entry[@"resolvedType"]);
        NSString *lookup=STBLEnvironmentToken(entry[@"lookup"],@[@"raw",@"metatable_table",@"absent",@"function_index_blocked",@"protected_metatable",@"cycle",@"depth_limit",@"non_table",@"error"]);
        NSString *indexType=STBLLuaType(entry[@"indexType"]) ?: STBLEnvironmentToken(entry[@"indexType"],@[@"none",@"protected"]);
        if (!name || !rawType || !resolvedType || !lookup || !indexType) return nil;
        NSMutableDictionary *row=[@{@"name":name,@"rawType":rawType,@"resolvedType":resolvedType,@"lookup":lookup,@"indexType":indexType} mutableCopy];
        if (!STBLEnvironmentInteger(entry,row,@"depth",0,4,NO)) return nil;
        [safeGlobals addObject:row];
    }
    for (id entry in modules) {
        if (![entry isKindOfClass:NSDictionary.class]) return nil;
        NSString *name=STBLBilliardsModuleName(entry[@"name"]), *type=STBLLuaType(entry[@"valueType"]);
        NSString *source=STBLEnvironmentToken(entry[@"source"],@[@"known_key",@"loaded_scan"]);
        NSString *status=STBLEnvironmentToken(entry[@"environmentStatus"],@[@"found",@"no_env",@"no_debug",@"not_function",@"error",@"upvalue_limit",@"env_limit",@"non_table_env"]);
        if (!name || !type || !source || !status) return nil;
        NSMutableDictionary *row=[@{@"name":name,@"valueType":type,@"source":source,@"environmentStatus":status} mutableCopy];
        if (!STBLEnvironmentInteger(entry,row,@"upvaluesScanned",0,16,NO) ||
            !STBLEnvironmentInteger(entry,row,@"environmentIndex",1,8,YES) ||
            !STBLEnvironmentInteger(entry,row,@"gameType",0,INT32_MAX,YES)) return nil;
        [safeModules addObject:row];
    }
    for (id entry in environments) {
        if (![entry isKindOfClass:NSDictionary.class]) return nil;
        NSString *source=STBLEnvironmentToken(entry[@"source"],@[@"_G"]) ?: STBLBilliardsModuleName(entry[@"source"]);
        if (!source || !STBLBoolean(entry[@"sameAsGlobal"]) || !STBLBoolean(entry[@"contractValid"])) return nil;
        NSMutableDictionary *row=[@{@"source":source,@"sameAsGlobal":entry[@"sameAsGlobal"],@"contractValid":entry[@"contractValid"]} mutableCopy];
        if (!STBLEnvironmentInteger(entry,row,@"index",1,8,NO) ||
            !STBLEnvironmentInteger(entry,row,@"enumGameType",0,INT32_MAX,YES) ||
            !STBLEnvironmentInteger(entry,row,@"constGameType",0,INT32_MAX,YES)) return nil;
        for (NSString *key in @[@"coreType",@"enumType",@"constType",@"biLogicType",@"managerType",@"frameDescriptorType",@"tutorialDescriptorType"]) {
            NSString *type=STBLLuaType(entry[key]);
            if (!type) return nil;
            row[key]=type;
        }
        [safeEnvironments addObject:row];
    }
    safe[@"globals"]=safeGlobals;
    safe[@"modules"]=safeModules;
    safe[@"environments"]=safeEnvironments;
    return safe;
}

/* Resolution records where the reader obtained its contract. It is telemetry,
 * not permission to draw: the existing snapshot validators below remain the
 * only authority. Copy known scalars only and discard this optional block if
 * any known field is malformed. */
static NSDictionary *STBLResolution(id raw) {
    if (![raw isKindOfClass:NSDictionary.class]) return nil;
    NSDictionary *input=raw;
    NSString *source=STBLEnvironmentToken(input[@"source"],@[@"none",@"globals",@"package_loaded"]);
    NSString *status=STBLEnvironmentToken(input[@"contractStatus"],@[@"missing",@"invalid",@"conflict",@"selected"]);
    NSString *lookup=STBLEnvironmentToken(input[@"managerLookup"],@[@"not_attempted",@"raw",@"metatable_table",@"absent",@"function_index_blocked",@"protected_metatable",@"cycle",@"depth_limit",@"non_table",@"error"]);
    if (!source || !status || !lookup) return nil;
    NSMutableDictionary *safe=[@{@"source":source,@"contractStatus":status,@"managerLookup":lookup} mutableCopy];
    if (!STBLEnvironmentInteger(input,safe,@"schemaVersion",1,1,NO) ||
        !STBLEnvironmentInteger(input,safe,@"enumGameType",0,INT32_MAX,YES) ||
        !STBLEnvironmentInteger(input,safe,@"constGameType",0,INT32_MAX,YES)) return nil;
    for (NSString *key in @[@"enumType",@"constType",@"descriptorType",@"managerType",@"managerGetType",@"frameType"]) {
        NSString *type=STBLLuaType(input[key]);
        if (!type) return nil;
        safe[key]=type;
    }
    for (NSString *key in @[@"frameCallAttempted",@"frameCallSucceeded"]) {
        if (!STBLBoolean(input[key])) return nil;
        safe[key]=input[key];
    }
    // A protected call can complete successfully and still return nil.
    if ([safe[@"frameCallSucceeded"] boolValue] && ![safe[@"frameCallAttempted"] boolValue]) return nil;
    if (input[@"descriptorName"]) {
        NSString *name=STBLEnvironmentToken(input[@"descriptorName"],@[@"Game/BiFrameLogic",@"Game/BiTutorialLogic"]);
        if (!name) return nil;
        safe[@"descriptorName"]=name;
    }
    if (input[@"descriptorPackage"]) {
        NSString *package=STBLEnvironmentToken(input[@"descriptorPackage"],@[@"Billiard"]);
        if (!package) return nil;
        safe[@"descriptorPackage"]=package;
    }
    if (input[@"frameDestroyed"]) {
        if (!STBLBoolean(input[@"frameDestroyed"])) return nil;
        safe[@"frameDestroyed"]=input[@"frameDestroyed"];
    }
    return safe;
}

/* The bridge is an untrusted producer for drawing purposes. Preserve only the
 * explicit scalar schema; never serialize arbitrary objects returned by Lua. */
NSDictionary *STBilliardsSanitizeSnapshot(id raw, NSString **failure) {
    if (failure) *failure=@"invalid_snapshot";
    if (![raw isKindOfClass:NSDictionary.class]) return nil;
    NSString *format=raw[@"format"] ?: raw[@"schema"];
    int64_t schema;
    if (![format isEqual:@"SDKtools.BilliardsLive"] || !STBLInteger(raw[@"schemaVersion"],1,1,&schema)) return nil;
    NSString *status=[raw[@"status"] isKindOfClass:NSString.class]?[raw[@"status"] copy]:nil;
    if (!status || ![@[@"aiming",@"moving",@"not_ready",@"wrong_scene",@"unsupported",@"error",@"stopped"] containsObject:status]) return nil;
    NSDictionary *rawPrediction=[raw[@"prediction"] isKindOfClass:NSDictionary.class]?raw[@"prediction"]:nil;
    NSString *reason=STBilliardsDiagnosticToken(raw[@"reason"] ?: rawPrediction[@"reason"]);
    NSMutableDictionary *result=[@{@"format":@"SDKtools.BilliardsLive",@"schemaVersion":@1,@"status":status,
        @"reason":reason,@"balls":@[],@"segments":@[],
        @"prediction":@{@"available":@NO,@"reason":reason,@"model":@"geometric",@"maxBounces":@3}} mutableCopy];
    NSDictionary *environment=STBLEnvironment(raw[@"environment"]);
    if (environment) result[@"environment"]=environment;
    NSDictionary *resolution=STBLResolution(raw[@"resolution"]);
    if (resolution) result[@"resolution"]=resolution;
    NSDictionary *rawGates=[raw[@"gates"] isKindOfClass:NSDictionary.class]?raw[@"gates"]:nil;
    NSMutableDictionary *gates=[NSMutableDictionary dictionary];
    for (NSString *key in @[@"hasCore",@"hasEnum",@"hasConst",@"hasUnityEngine",@"hasSceneAPI",@"hasFrame",@"hasCamera"])
        if (STBLBoolean(rawGates[key])) gates[key]=rawGates[key];
    if (gates.count) result[@"gates"]=gates;
    // Keep partial identity when the reader stops before finding every field.
    // A failure report cannot draw, even if the producer supplies segments.
    for (NSString *key in @[@"resourceGameId",@"gameType",@"sessionId",@"frameNumber",@"cameraInstanceId"]) {
        int64_t value;
        if (STBLInteger(raw[key],INT32_MIN,INT32_MAX,&value)) result[key]=@(value);
    }
    NSDictionary *observedScene=[raw[@"scene"] isKindOfClass:NSDictionary.class]?raw[@"scene"]:nil;
    int64_t observedHandle;
    if (STBLInteger(observedScene[@"handle"],INT32_MIN,INT32_MAX,&observedHandle))
        result[@"scene"]=@{@"handle":@(observedHandle),@"name":STBilliardsDiagnosticToken(observedScene[@"name"])};
    NSDictionary *observedScreen=[raw[@"screen"] isKindOfClass:NSDictionary.class]?raw[@"screen"]:nil;
    int64_t observedWidth,observedHeight;
    if (STBLInteger(observedScreen[@"width"],16,16384,&observedWidth) && STBLInteger(observedScreen[@"height"],16,16384,&observedHeight))
        result[@"screen"]=@{@"width":@(observedWidth),@"height":@(observedHeight)};
    if (![@[@"aiming",@"moving"] containsObject:status]) {
        NSArray *partial=[raw[@"balls"] isKindOfClass:NSArray.class]?raw[@"balls"]:nil;
        if (partial && partial.count<=16) {
            NSMutableArray *identities=[NSMutableArray array]; uint32_t seen=0;
            for (id item in partial) {
                if (![item isKindOfClass:NSDictionary.class]) continue;
                int64_t tag,number;
                if (STBLInteger(item[@"tag"],1,16,&tag) && STBLInteger(item[@"number"],0,15,&number) &&
                    STBLValidIdentityBall(tag,number,&seen) && STBLBoolean(item[@"active"]) && STBLBoolean(item[@"potted"]))
                    [identities addObject:@{@"tag":@(tag),@"number":@(number),@"active":item[@"active"],@"potted":item[@"potted"]}];
            }
            result[@"balls"]=identities;
        }
        return result;
    }
    int64_t resourceID,gameType,session,frame,camera,sceneHandle,width,height;
    NSDictionary *scene=raw[@"scene"], *screen=raw[@"screen"];
    if (![scene isKindOfClass:NSDictionary.class] || ![screen isKindOfClass:NSDictionary.class] ||
        !STBLInteger(raw[@"resourceGameId"],20,20,&resourceID) || !STBLInteger(raw[@"gameType"],1003,1003,&gameType) ||
        !STBLInteger(raw[@"sessionId"],1,INT32_MAX,&session) || !STBLInteger(raw[@"frameNumber"],0,INT32_MAX,&frame) ||
        !STBLInteger(raw[@"cameraInstanceId"],INT32_MIN,INT32_MAX,&camera) || !camera ||
        !STBLInteger(scene[@"handle"],INT32_MIN,INT32_MAX,&sceneHandle) ||
        !STBLInteger(screen[@"width"],16,16384,&width) || !STBLInteger(screen[@"height"],16,16384,&height)) return nil;
    if (![scene[@"name"] isKindOfClass:NSString.class] || ![@[@"BilliardInGame",@"BilliardTutorial"] containsObject:scene[@"name"]]) {
        if (failure) *failure=@"scene_not_billiards";
        return nil;
    }
    NSArray *balls=raw[@"balls"], *segments=raw[@"segments"];
    if (![balls isKindOfClass:NSArray.class] || !balls.count || balls.count>16 ||
        ![segments isKindOfClass:NSArray.class] || segments.count>STBLMaxSegments) return nil;
    uint32_t mask=0;
    BOOL moving=[status isEqual:@"moving"], cueAvailable=NO;
    NSMutableArray *safeBalls=[NSMutableArray array];
    for (id item in balls) {
        if (![item isKindOfClass:NSDictionary.class]) return nil;
        int64_t tag,number;
        if (!STBLInteger(item[@"tag"],1,16,&tag) || !STBLInteger(item[@"number"],0,15,&number) ||
            !STBLValidIdentityBall(tag,number,&mask) || !STBLBoolean(item[@"active"]) || !STBLBoolean(item[@"potted"])) return nil;
        BOOL active=[item[@"active"] boolValue], potted=[item[@"potted"] boolValue];
        NSMutableDictionary *ball=[@{@"tag":@(tag),@"number":@(number),@"active":@(active),@"potted":@(potted)} mutableCopy];
        if (active && !potted) {
            NSDictionary *world=STBLVector(item[@"world"],NO,0,0), *point=STBLVector(item[@"screen"],YES,width,height);
            double speed,radius;
            if (!world || !point || !STBLNumber(item[@"speed"],0,100000,&speed) ||
                !STBLNumber(item[@"radiusPixels"],0.01,MIN(width,height)/4.0,&radius)) return nil;
            [ball addEntriesFromDictionary:@{@"world":world,@"screen":point,@"speed":@(speed),@"radiusPixels":@(radius)}];
            if (speed>STBL_MOVING_SPEED) moving=YES;
            if (tag==1) cueAvailable=YES;
        }
        [safeBalls addObject:ball];
    }
    NSDictionary *prediction=raw[@"prediction"];
    if (![prediction isKindOfClass:NSDictionary.class] || !STBLBoolean(prediction[@"available"])) return nil;
    int64_t bounces;
    if (!STBLInteger(prediction[@"maxBounces"],0,3,&bounces) || ![prediction[@"model"] isEqual:@"geometric"]) return nil;
    BOOL available=[prediction[@"available"] boolValue] && !moving && cueAvailable;
    NSMutableArray *safeSegments=[NSMutableArray array];
    if (available) {
        if (!segments.count) return nil;
        for (id segment in segments) {
            if (![segment isKindOfClass:NSDictionary.class] || ![segment[@"kind"] isKindOfClass:NSString.class] || ![@[@"cue",@"object",@"rebound"] containsObject:segment[@"kind"]]) return nil;
            NSDictionary *from=STBLVector(segment[@"from"],YES,width,height), *to=STBLVector(segment[@"to"],YES,width,height);
            NSDictionary *worldFrom=STBLVector(segment[@"worldFrom"],NO,0,0), *worldTo=STBLVector(segment[@"worldTo"],NO,0,0);
            if (!from || !to || !worldFrom || !worldTo) return nil;
            [safeSegments addObject:@{@"kind":[segment[@"kind"] copy],@"from":from,@"to":to,@"worldFrom":worldFrom,@"worldTo":worldTo}];
        }
    }
    NSDictionary *cue=[raw[@"cue"] isKindOfClass:NSDictionary.class]?raw[@"cue"]:nil;
    NSDictionary *cueWorld=STBLVector(cue[@"world"],NO,0,0), *cueDirection=STBLVector(cue[@"direction"],NO,0,0);
    if (available && (!cueWorld || !cueDirection)) return nil;
    [result addEntriesFromDictionary:@{@"resourceGameId":@(resourceID),@"gameType":@(gameType),@"sessionId":@(session),
        @"frameNumber":@(frame),@"cameraInstanceId":@(camera),@"scene":@{@"handle":@(sceneHandle),@"name":STBilliardsDiagnosticToken(scene[@"name"])},
        @"screen":@{@"width":@(width),@"height":@(height)},@"balls":safeBalls,@"segments":safeSegments,
        @"cue":cueWorld&&cueDirection?@{@"world":cueWorld,@"direction":cueDirection}:(id)NSNull.null,
        @"prediction":@{@"available":@(available),@"reason":moving?@"balls_moving":STBilliardsDiagnosticToken(prediction[@"reason"]),
            @"model":@"geometric",@"maxBounces":@(bounces)},@"status":moving?@"moving":status}];
    return result;
}


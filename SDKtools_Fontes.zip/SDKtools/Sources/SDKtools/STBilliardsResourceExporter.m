#import "STBilliardsResourceExporter.h"
#import <CommonCrypto/CommonDigest.h>
#import <TargetConditionals.h>
#include "STBilliardsResourceIO.h"

static const NSUInteger STBRJSONLimit = 48u * 1024u * 1024u;
static const NSUInteger STBRManifestLimit = 8;
static const NSUInteger STBRFileLimit = 128;

@interface STBRCapturedFile : NSObject {
@public STBRReceipt receipt;
}
@property(nonatomic) int root;
@property(nonatomic,copy) NSString *relative;
@property(nonatomic,copy) NSString *storage;
@property(nonatomic,copy) NSString *representation;
@property(nonatomic,copy) NSString *status;
@property(nonatomic,copy) NSString *sha256;
@property(nonatomic,strong) NSData *data;
@property(nonatomic,strong) NSArray<NSDictionary *> *cacheDirectoryReceipts;
@property(nonatomic) BOOL changed;
@end
@implementation STBRCapturedFile
@end

@interface STBRCatalog : NSObject {
@public STBRReceipt receipt;
@public STBRManifest *manifest;
}
@property(nonatomic,copy) NSString *name;
@property(nonatomic,copy) NSString *sha256;
@property(nonatomic,copy) NSString *status;
@property(nonatomic,strong) NSMutableArray<NSDictionary *> *records;
@property(nonatomic) BOOL changed;
@end
@implementation STBRCatalog
- (void)dealloc { free(manifest); }
@end

typedef struct {
    NSUInteger visited, found, accepted, missing, readCount;
    size_t bytesRead;
    BOOL truncated;
    double deadline;
} STBRBudget;

static NSError *STBRError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"SDKtools.BilliardsResources" code:code userInfo:@{NSLocalizedDescriptionKey:message}];
}
static NSString *STBRText(const char *value) {
    return value ? ([NSString stringWithUTF8String:value] ?: @"invalid") : @"invalid";
}
static NSString *STBRSHA(NSData *data) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    char result[CC_SHA256_DIGEST_LENGTH * 2 + 1];
    static const char hex[] = "0123456789abcdef";
    for (NSUInteger i=0;i<sizeof(digest);i++) { result[2*i]=hex[digest[i]>>4]; result[2*i+1]=hex[digest[i]&15]; }
    result[sizeof(result)-1]=0;
    return STBRText(result);
}
static BOOL STBRTimeAvailable(STBRBudget *budget) {
    double now=STGSNow();
    if (now<=0 || now>=budget->deadline) { budget->truncated=YES; return NO; }
    return YES;
}
static NSString *STBRLocalPath(NSURL *URL) {
    if (!URL.isFileURL) return nil;
    NSURLComponents *parts=[NSURLComponents componentsWithURL:URL resolvingAgainstBaseURL:NO];
    if ((parts.host.length && ![parts.host.lowercaseString isEqualToString:@"localhost"]) ||
        parts.user.length || parts.password.length || parts.port || parts.query.length || parts.fragment.length) return nil;
    NSString *encoded=parts.percentEncodedPath, *lower=encoded.lowercaseString;
    if (!encoded.length || encoded.length>8192 || [lower containsString:@"%2f"] ||
        [lower containsString:@"%5c"] || [lower containsString:@"%00"]) return nil;
    NSString *path=encoded.stringByRemovingPercentEncoding;
    if (![path hasPrefix:@"/"] || [path containsString:@"\\"]) return nil;
    for (NSString *part in path.pathComponents) if ([part isEqualToString:@"."] || [part isEqualToString:@".."]) return nil;
    return path;
}
static int STBROpenAnchor(NSURL *URL, dev_t *device) {
    if (!STBRLocalPath(URL)) return -1;
    // Only the caller's OS-owned anchor is resolved. Descendants are always
    // descriptor-relative and O_NOFOLLOW, including the output directory.
    NSURL *canonical=URL.URLByResolvingSymlinksInPath.URLByStandardizingPath;
    int fd=open(canonical.path.fileSystemRepresentation, O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    struct stat st;
    if (fd<0) return -1;
    if (fstat(fd,&st) || !S_ISDIR(st.st_mode)) { close(fd); return -1; }
    *device=st.st_dev;
    return fd;
}
static BOOL STBRDestinationMatches(NSURL *documents, NSURL *destination) {
    NSString *path=STBRLocalPath(destination);
    if (!path) return NO;
    if ([path hasSuffix:@"/"]) path=[path substringToIndex:path.length-1];
    for (NSString *anchor in @[STBRLocalPath(documents) ?: @"", documents.URLByResolvingSymlinksInPath.path ?: @""]) {
        const char *relative=STGSRelativeUnderOSAnchor(path.UTF8String, anchor.UTF8String);
        if (relative && !strcmp(relative,"SDKtools")) return YES;
    }
    return NO;
}
static BOOL STBRSafeComponent(const char *name) {
    size_t count=name?strlen(name):0;
    if (!count || count>128 || name[0]=='.') return NO;
    for (size_t i=0;i<count;i++) {
        unsigned char c=(unsigned char)name[i];
        if (!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-')) return NO;
    }
    return YES;
}
static BOOL STBRDirectorySafe(int fd, dev_t device) {
    struct stat st;
    return fd>=0 && !fstat(fd,&st) && S_ISDIR(st.st_mode) && st.st_dev==device;
}

/* This is the precise native cache fallback: one bundle directory, one level
 * of version directories, then immediate regular files whose name contains
 * '_data'. Never descend into unrelated Unity cache entries. */
static BOOL STBRDirectoriesUnchanged(int root,NSArray<NSDictionary *> *receipts) {
    for(NSDictionary *observation in receipts) {
        struct stat before,current;[observation[@"metadata"] getValue:&before size:sizeof(before)];
        int fd=STGSOpenRelative(root,[observation[@"relativePath"] UTF8String],true);
        if(fd<0)return NO;
        BOOL same=!fstat(fd,&current)&&S_ISDIR(current.st_mode)&&STGSStatSame(before,current);close(fd);
        if(!same)return NO;
    }
    return YES;
}
static NSString *STBRUnityCachePath(int libraryFD, dev_t device, NSString *bundle, STBRBudget *budget,
                                   NSString **reason,NSArray<NSDictionary *> **directoryReceipts) {
    if (reason) *reason=@"cache_unavailable";
    if(directoryReceipts)*directoryReceipts=nil;
    if (libraryFD<0 || !STBRTimeAvailable(budget)) return nil;
    NSString *base=[@"UnityCache/Shared/" stringByAppendingString:bundle];
    int baseFD=STGSOpenRelative(libraryFD,base.UTF8String,true);
    if (!STBRDirectorySafe(baseFD,device)) { if(baseFD>=0)close(baseFD); return nil; }
    struct stat baseBefore;
    if(fstat(baseFD,&baseBefore)){close(baseFD);return nil;}
    NSMutableArray *observations=[NSMutableArray arrayWithObject:@{@"relativePath":base,
        @"metadata":[NSValue valueWithBytes:&baseBefore objCType:@encode(struct stat)]}];
    int duplicate=dup(baseFD); DIR *dir=duplicate<0?NULL:fdopendir(duplicate);
    if (!dir) { if(duplicate>=0)close(duplicate); close(baseFD); return nil; }
    NSMutableArray<NSString *> *matches=[NSMutableArray array];
    NSUInteger versions=0, files=0; BOOL complete=YES;
    for (;;) {
        if (!STBRTimeAvailable(budget) || budget->visited>=4096) { budget->truncated=YES; complete=NO; break; }
        errno=0; struct dirent *entry=readdir(dir);
        if (!entry) { if(errno)complete=NO; break; }
        if (!strcmp(entry->d_name,".")||!strcmp(entry->d_name,"..")) continue;
        budget->visited++;
        if (!STBRSafeComponent(entry->d_name)) continue;
        struct stat st;
        if (fstatat(baseFD,entry->d_name,&st,AT_SYMLINK_NOFOLLOW) || !S_ISDIR(st.st_mode) || st.st_dev!=device) continue;
        if (++versions>16) { budget->truncated=YES; complete=NO; break; }
        int versionFD=openat(baseFD,entry->d_name,O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
        if (!STBRDirectorySafe(versionFD,device)) { if(versionFD>=0)close(versionFD); complete=NO; continue; }
        struct stat versionBefore;
        if(fstat(versionFD,&versionBefore)){close(versionFD);complete=NO;break;}
        NSString *version=STBRText(entry->d_name);
        [observations addObject:@{@"relativePath":[base stringByAppendingPathComponent:version],
            @"metadata":[NSValue valueWithBytes:&versionBefore objCType:@encode(struct stat)]}];
        int copy=dup(versionFD); DIR *child=copy<0?NULL:fdopendir(copy);
        if (!child) { if(copy>=0)close(copy); close(versionFD); complete=NO; continue; }
        for (;;) {
            if (!STBRTimeAvailable(budget) || budget->visited>=4096) { budget->truncated=YES; complete=NO; break; }
            errno=0; struct dirent *file=readdir(child);
            if (!file) { if(errno)complete=NO; break; }
            if (!strcmp(file->d_name,".")||!strcmp(file->d_name,"..")) continue;
            budget->visited++;
            if (++files>32) { budget->truncated=YES; complete=NO; break; }
            if (!STBRSafeComponent(file->d_name) || !strstr(file->d_name,"_data")) continue;
            struct stat fs;
            if (fstatat(versionFD,file->d_name,&fs,AT_SYMLINK_NOFOLLOW) ||
                !S_ISREG(fs.st_mode) || fs.st_nlink!=1 || fs.st_dev!=device) continue;
            [matches addObject:[[base stringByAppendingPathComponent:version] stringByAppendingPathComponent:STBRText(file->d_name)]];
        }
        closedir(child); close(versionFD);
        if (!complete) break;
    }
    closedir(dir); close(baseFD);
    if (!complete) { if(reason)*reason=@"cache_inventory_incomplete"; return nil; }
    if (matches.count!=1) { if(reason)*reason=matches.count?@"cache_ambiguous":@"cache_missing"; return nil; }
    if(!STBRDirectoriesUnchanged(libraryFD,observations)) { if(reason)*reason=@"cache_inventory_changed";return nil; }
    if(directoryReceipts)*directoryReceipts=observations;
    if (reason) *reason=@"ok";
    return matches.firstObject;
}

static STBRCapturedFile *STBRCapture(int root,dev_t device,NSString *relative,NSString *storage,
                                  NSString *representation,STBRBudget *budget,NSMutableDictionary *captures) {
    NSString *key=[storage stringByAppendingFormat:@":%@",relative];
    STBRCapturedFile *existing=captures[key]; if(existing)return existing;
    STBRCapturedFile *file=[STBRCapturedFile new]; file.root=root; file.relative=relative;
    file.storage=storage; file.representation=representation; file.status=@"unavailable";
    captures[key]=file;
    if (!STBRTimeAvailable(budget)) { file.status=@"timeout"; return file; }
    if (budget->readCount>=STBRFileLimit || budget->bytesRead>=STBR_MAX_TOTAL) {
        budget->truncated=YES; file.status=@"export_limit"; return file;
    }
    unsigned char *bytes=NULL;size_t count=0;
    size_t maximum=MIN((size_t)STBR_MAX_FILE,(size_t)STBR_MAX_TOTAL-budget->bytesRead);
    STBRReadStatus status=STBRRead(root,relative.UTF8String,device,maximum,budget->deadline,&bytes,&count,&file->receipt);
    file.status=STBRText(STBRReadStatusName(status));
    if (status==STBRReadOK) {
        budget->readCount++; budget->bytesRead+=count;
        file.data=[NSData dataWithBytesNoCopy:bytes length:count freeWhenDone:YES];
        file.sha256=STBRSHA(file.data);
    } else if (status==STBRReadChanged) file.changed=YES;
    else if (status==STBRReadTimeout || status==STBRReadSizeLimit) budget->truncated=YES;
    return file;
}

static BOOL STBRValidate(int documentsFD, NSArray<STBRCatalog *> *catalogs, NSDictionary *captures, NSArray *rejected) {
    BOOL changed=NO;
    for (STBRCatalog *catalog in catalogs) {
        if (catalog->receipt.valid && !catalog.changed && !STBRRevalidate(documentsFD,catalog.name.UTF8String,&catalog->receipt)) {
            catalog.changed=YES; catalog.status=@"changed"; changed=YES;
        }
    }
    for (STBRCapturedFile *file in captures.allValues) {
        if (file->receipt.valid && !file.changed &&
            (!STBRRevalidate(file.root,file.relative.UTF8String,&file->receipt)||
             !STBRDirectoriesUnchanged(file.root,file.cacheDirectoryReceipts))) {
            file.changed=YES; file.status=@"changed"; file.data=nil; changed=YES;
        }
    }
    for (NSMutableDictionary *entry in rejected) {
        NSValue *saved=entry[@"_receipt"];
        if(!saved || [entry[@"changed"] boolValue])continue;
        STBRReceipt receipt={0};[saved getValue:&receipt size:sizeof(receipt)];
        if(receipt.valid&&!STBRRevalidate(documentsFD,[entry[@"relativePath"] UTF8String],&receipt)) {
            entry[@"changed"]=@YES;entry[@"reason"]=@"manifest_changed";changed=YES;
        }
    }
    return changed;
}

static NSDictionary *STBRReport(NSArray<STBRCatalog *> *catalogs,NSDictionary *captures,NSArray *rejected,
                               STBRBudget budget,BOOL omitAllPayload,NSDictionary **diagnostic) {
    NSMutableArray *catalogRows=[NSMutableArray array];
    NSMutableArray *rejectedRows=[NSMutableArray array];
    NSMutableSet<NSString *> *exported=[NSMutableSet set];
    NSUInteger bytesExported=0,changedCatalogs=0,changedFiles=0;
    for(NSDictionary *entry in rejected) {
        BOOL changed=[entry[@"changed"] boolValue];if(changed)changedCatalogs++;
        [rejectedRows addObject:@{@"relativePath":entry[@"relativePath"],@"reason":entry[@"reason"],@"changed":@(changed)}];
    }
    for (STBRCapturedFile *file in captures.allValues) if(file.changed)changedFiles++;
    for (STBRCatalog *catalog in catalogs) {
        if(catalog.changed)changedCatalogs++;
        NSMutableArray *records=[NSMutableArray array];
        for (NSDictionary *record in catalog.records) {
            NSMutableDictionary *row=[record mutableCopy]; NSArray *variants=row[@"variants"];
            NSMutableArray *variantRows=[NSMutableArray array];
            for (STBRCapturedFile *file in variants) {
                NSMutableDictionary *v=[@{@"storageRoot":file.storage,@"relativePath":file.relative,
                    @"representation":file.representation,@"status":file.status,
                    @"manifestMD5Comparison":@"not_performed",@"manifestSizeComparison":@"not_applicable"} mutableCopy];
                if (file->receipt.valid) v[@"observedBytes"]=@(file->receipt.metadata.st_size);
                if (file.sha256) v[@"observedSHA256"]=file.sha256;
                if (catalog.changed) v[@"status"]=@"excluded_manifest_changed";
                else if (omitAllPayload) v[@"status"]=@"excluded_snapshot_unstable";
                else if (file.data && !file.changed) {
                    if ([file.representation isEqualToString:@"originalNamedBundle"])
                        v[@"manifestSizeComparison"]=file.data.length==[row[@"declaredBytes"] unsignedLongLongValue]?@"equal":@"different";
                    NSString *key=[file.storage stringByAppendingFormat:@":%@",file.relative];
                    v[@"fileId"]=key;
                    if (![exported containsObject:key]) {
                        v[@"encoding"]=@"base64";v[@"data"]=[file.data base64EncodedStringWithOptions:0];
                        [exported addObject:key];bytesExported+=file.data.length;
                    } else v[@"dataReference"]=key;
                }
                [variantRows addObject:v];
            }
            row[@"variants"]=variantRows;[records addObject:row];
        }
        [catalogRows addObject:@{@"relativePath":catalog.name,@"storageRoot":@"Documents",@"status":catalog.status,
            @"sourceSHA256":catalog.sha256?:@"",@"resourceGameId":@(catalog->manifest->gameId),
            @"manifestVersion":@(catalog->manifest->version),@"activeCatalogVerified":@NO,
            @"declaredRecordCount":@(catalog->manifest->recordCount),@"selectedRecordCount":@(catalog->manifest->selectedCount),@"records":records}];
    }
    NSString *outcome=exported.count?@"resources_exported":@"resources_missing";
    if(changedCatalogs||changedFiles||omitAllPayload)outcome=exported.count?@"partial_resources_changed":@"resources_changed";
    else if(budget.truncated)outcome=exported.count?@"partial_limit":@"resources_missing";
    else if(budget.missing||rejectedRows.count)outcome=exported.count?@"partial_resources_missing":@"resources_missing";
    NSString *status=exported.count?((changedCatalogs||changedFiles||omitAllPayload||budget.truncated||budget.missing||rejectedRows.count)?@"partial":@"exported"):@"resources_missing";
    NSDictionary *diag=@{@"status":status,@"manifestsFound":@(budget.found),@"manifestsAccepted":@(budget.accepted),
        @"manifestsChanged":@(changedCatalogs),@"filesExported":@(exported.count),@"filesMissing":@(budget.missing),
        @"filesChanged":@(changedFiles),@"bytesExported":@(bytesExported),@"entriesVisited":@(budget.visited),
        @"truncated":@(budget.truncated),@"errorCode":@0};
    if(diagnostic)*diagnostic=diag;
    return @{@"format":@"SDKtools.BilliardsResources",@"schema":@"SDKtools.BilliardsResources",@"schemaVersion":@1,@"toolVersion":@"3.15.0",@"outcome":outcome,
        @"currentMatchIdentified":@NO,@"nativeGameType":NSNull.null,@"sceneType":NSNull.null,
        @"billiardsPredictionAvailable":@NO,@"collectionMode":@"local_cached_catalogs",
        @"catalogSelection":@"all_bounded_candidates_no_active_catalog_assumption",@"diagnostic":diag,
        @"cachedCatalogs":catalogRows,@"rejectedCatalogs":rejectedRows,
        @"baselineEvidence":@{@"appVersion":@"6.6.2",@"appBuild":@"132",@"resourceGameId":@20,
            @"embeddedManifestVersion":@1047,@"resourceKey":@"billiard_asset_records_ios.svga",
            @"manifestSHA256":@"dd5e85ab92eb8ce2b6b75464ac9d58e3939335a93163e3f1856d99cc2c69fdbf",
            @"meaning":@"Static IPA resource identity; not the current native gameType or sceneType."},
        @"limits":@{@"manifestBytes":@(STBR_MAX_MANIFEST),@"fileBytes":@(STBR_MAX_FILE),@"totalReadBytes":@(STBR_MAX_TOTAL),
            @"jsonBytes":@(STBRJSONLimit),@"catalogs":@(STBRManifestLimit),@"files":@(STBRFileLimit),@"entries":@4096,@"seconds":@20,@"collectionSeconds":@15},
        @"notes":@[@"The cached catalog may differ from the active match.",@"SHA256 describes exported bytes; vendor MD5 is retained separately without an integrity claim.",
            @"LZ4 recompression and Unity cache representations are not compared with the original bundle MD5 or size.",
            @"No network request, game invocation, injection, physics modification or ball prediction was performed."]};
}

static BOOL STBRWriteFD(int fd,NSData *data,double deadline) {
    if(data.length>STBRJSONLimit || ftruncate(fd,0) || lseek(fd,0,SEEK_SET)<0)return NO;
    const unsigned char *bytes=data.bytes;size_t offset=0;
    while(offset<data.length) {
        if(STGSNow()>=deadline)return NO;
        ssize_t n=write(fd,bytes+offset,MIN((size_t)65536,data.length-offset));
        if(n<0&&errno==EINTR)continue;if(n<=0)return NO;offset+=(size_t)n;
    }
    return !fsync(fd);
}
static BOOL STBROutputSame(int directory,int fd,const char *name,dev_t device) {
    struct stat a,b;
    return !fstat(fd,&a)&&!fstatat(directory,name,&b,AT_SYMLINK_NOFOLLOW)&&
        S_ISREG(a.st_mode)&&S_ISREG(b.st_mode)&&a.st_nlink==1&&b.st_nlink==1&&
        a.st_dev==device&&b.st_dev==device&&a.st_ino==b.st_ino;
}
static BOOL STBROutputDirectoryAttached(int documents,int outputDirectory,dev_t device) {
    struct stat a,b;
    return !fstat(outputDirectory,&a)&&!fstatat(documents,"SDKtools",&b,AT_SYMLINK_NOFOLLOW)&&
        S_ISDIR(a.st_mode)&&S_ISDIR(b.st_mode)&&a.st_dev==device&&b.st_dev==device&&a.st_ino==b.st_ino;
}

@implementation STBilliardsResourceExporter
+ (NSURL *)writePackageFromDocumentsURL:(NSURL *)documents libraryURL:(NSURL *)library
                  destinationDirectory:(NSURL *)destination diagnostic:(NSDictionary **)diagnostic error:(NSError **)error {
    if(error)*error=nil;if(diagnostic)*diagnostic=nil;
    NSDictionary *failure=@{@"status":@"export_failed",@"manifestsFound":@0,@"manifestsAccepted":@0,@"manifestsChanged":@0,
        @"filesExported":@0,@"filesMissing":@0,@"filesChanged":@0,@"bytesExported":@0,@"entriesVisited":@0,@"truncated":@NO,@"errorCode":@1};
    if(diagnostic)*diagnostic=failure;
    if(NSThread.isMainThread) { if(error)*error=STBRError(1,@"A exportação do bilhar precisa ocorrer em segundo plano.");return nil; }
    if(!STBRLocalPath(documents)||!STBRLocalPath(library)||!STBRDestinationMatches(documents,destination)) {
        if(error)*error=STBRError(2,@"O destino precisa ser a pasta SDKtools dos documentos do aplicativo.");return nil;
    }
    double started=STGSNow(),finishDeadline=started+20;
    if(!isfinite(started)||started<=0) { if(error)*error=STBRError(7,@"O relógio da coleta não está disponível.");return nil; }
    STBRBudget budget={0};budget.deadline=started+15;
    dev_t documentsDevice=0,libraryDevice=0;
    int documentsFD=STBROpenAnchor(documents,&documentsDevice),libraryFD=STBROpenAnchor(library,&libraryDevice);
    if(documentsFD<0) { if(libraryFD>=0)close(libraryFD);if(error)*error=STBRError(3,@"Não foi possível abrir os documentos do aplicativo.");return nil; }
    NSMutableArray<STBRCatalog *> *catalogs=[NSMutableArray array];
    NSMutableArray<NSDictionary *> *rejected=[NSMutableArray array];
    NSMutableDictionary<NSString *,STBRCapturedFile *> *captures=[NSMutableDictionary dictionary];
    // Native code replaces dots in codeVersion with underscores; it does not
    // establish a numeric-only version grammar. Admit bounded ASCII components
    // and an exact resource-20 segment, then require protobuf gameId == 20.
    NSRegularExpression *pattern=[NSRegularExpression regularExpressionWithPattern:@"^(?:pro|dev)_AssetBundleRecord_(?:[A-Za-z0-9_-]{1,64}_)?20_[A-Za-z0-9_-]{1,64}_v[23]\\.svga$" options:0 error:nil];
    int copied=dup(documentsFD);DIR *dir=copied<0?NULL:fdopendir(copied);
    if(!dir&&copied>=0)close(copied);
    NSMutableArray<NSString *> *names=[NSMutableArray array];
    if(dir) {
        for(;;) {
            if(!STBRTimeAvailable(&budget)||budget.visited>=4096){budget.truncated=YES;break;}
            errno=0;struct dirent *entry=readdir(dir);
            if(!entry){if(errno)budget.truncated=YES;break;}
            if(!strcmp(entry->d_name,".")||!strcmp(entry->d_name,".."))continue;
            budget.visited++;NSString *name=STBRText(entry->d_name);
            if(name.length>200||![pattern numberOfMatchesInString:name options:0 range:NSMakeRange(0,name.length)])continue;
            budget.found++;
            if(names.count<64)[names addObject:name];else budget.truncated=YES;
        }
        closedir(dir);
    } else budget.truncated=YES;
    // Lexical ordering is deterministic only; it never chooses an active or
    // newest game version. At most eight valid cached catalogs are accepted.
    [names sortUsingSelector:@selector(compare:)];
    for(NSString *name in names) {
        if(!STBRTimeAvailable(&budget))break;
        if(rejected.count>=32){budget.truncated=YES;break;}
        if(catalogs.count>=STBRManifestLimit){budget.truncated=YES;break;}
        if(budget.bytesRead>=STBR_MAX_TOTAL){budget.truncated=YES;break;}
        unsigned char *bytes=NULL;size_t count=0;STBRReceipt receipt={0};
        STBRReadStatus read=STBRRead(documentsFD,name.UTF8String,documentsDevice,MIN((size_t)STBR_MAX_MANIFEST,(size_t)STBR_MAX_TOTAL-budget.bytesRead),budget.deadline,&bytes,&count,&receipt);
        if(read!=STBRReadOK){[rejected addObject:[@{@"relativePath":name,@"reason":STBRText(STBRReadStatusName(read)),@"changed":@(read==STBRReadChanged)} mutableCopy]];continue;}
        budget.bytesRead+=count;NSData *data=[NSData dataWithBytesNoCopy:bytes length:count freeWhenDone:YES];
        STBRCatalog *catalog=[STBRCatalog new];catalog->manifest=calloc(1,sizeof(STBRManifest));
        if(!catalog->manifest){budget.truncated=YES;break;}
        STBRParseStatus parsed=STBRParseManifest(data.bytes,data.length,catalog->manifest);
        if(parsed!=STBRParseOK){[rejected addObject:[@{@"relativePath":name,@"reason":STBRText(STBRParseStatusName(parsed)),
            @"_receipt":[NSValue valueWithBytes:&receipt objCType:@encode(STBRReceipt)]} mutableCopy]];continue;}
        catalog->receipt=receipt;catalog.name=name;catalog.sha256=STBRSHA(data);catalog.status=@"accepted_cached_catalog";
        catalog.records=[NSMutableArray array];[catalogs addObject:catalog];budget.accepted++;
        for(size_t i=0;i<catalog->manifest->recordCount;i++) {
            STBRRecord *record=&catalog->manifest->records[i];if(!record->selected)continue;
            NSString *bundle=STBRText(record->name);NSMutableArray *variants=[NSMutableArray array];
            BOOL available=NO;
            for(NSString *suffix in @[@"",@".lz4"]) {
                NSString *relative=[@"AssetBundles/" stringByAppendingString:[bundle stringByAppendingString:suffix]];
                STBRCapturedFile *file=STBRCapture(documentsFD,documentsDevice,relative,@"Documents",suffix.length?@"runtimeRecompressedLZ4":@"originalNamedBundle",&budget,captures);
                [variants addObject:file];if(file.data)available=YES;
            }
            NSString *fallback=@"not_needed";
            if(!available) {
                NSArray *directoryReceipts=nil;
                NSString *relative=STBRUnityCachePath(libraryFD,libraryDevice,bundle,&budget,&fallback,&directoryReceipts);
                if(relative) {
                    STBRCapturedFile *file=STBRCapture(libraryFD,libraryDevice,relative,@"Library",@"unityCache",&budget,captures);
                    if(!file.cacheDirectoryReceipts)file.cacheDirectoryReceipts=directoryReceipts;
                    [variants addObject:file];if(file.data)available=YES;
                }
            }
            if(!available)budget.missing++;
            [catalog.records addObject:@{@"bundleName":bundle,@"category":STBRText(STBRCategoryName(record->category)),
                @"vendorMD5":STBRText(record->md5),@"declaredBytes":@(record->declaredSize),@"cacheFallbackStatus":fallback,@"variants":variants}];
            if(!STBRTimeAvailable(&budget))break;
        }
    }

    NSURL *result=nil;int outputDirectory=-1,output=-1;
    NSString *temporary=[@"SDKtools-Billiards-tmp-" stringByAppendingString:NSUUID.UUID.UUIDString];
    NSString *finalName=[NSString stringWithFormat:@"SDKtools-BilliardsResources-%@.json",NSUUID.UUID.UUIDString];
    BOOL published=NO;NSDictionary *diag=nil;NSInteger failCode=4;
    do {
        if(STGSNow()>=finishDeadline)break;
        if(mkdirat(documentsFD,"SDKtools",0700)&&errno!=EEXIST)break;
        outputDirectory=openat(documentsFD,"SDKtools",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
        if(!STBRDirectorySafe(outputDirectory,documentsDevice))break;
        output=openat(outputDirectory,temporary.UTF8String,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
        if(output<0)break;
        NSURL *canonicalDocuments=documents.URLByResolvingSymlinksInPath.URLByStandardizingPath;
        NSURL *directoryURL=[canonicalDocuments URLByAppendingPathComponent:@"SDKtools" isDirectory:YES];
        NSURL *tempURL=[directoryURL URLByAppendingPathComponent:temporary];
        if(!STBROutputDirectoryAttached(documentsFD,outputDirectory,documentsDevice)||
            !STBROutputSame(outputDirectory,output,temporary.UTF8String,documentsDevice))break;
#if TARGET_OS_IOS || TARGET_OS_TV || TARGET_OS_WATCH
        if(![NSFileManager.defaultManager setAttributes:@{NSFileProtectionKey:NSFileProtectionComplete} ofItemAtPath:tempURL.path error:nil])break;
#endif
        if(![tempURL setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil])break;
        if(!STBROutputDirectoryAttached(documentsFD,outputDirectory,documentsDevice)||
            !STBROutputSame(outputDirectory,output,temporary.UTF8String,documentsDevice))break;
        BOOL ready=NO;
        for(NSUInteger attempt=0;attempt<3;attempt++) {
          @autoreleasepool {
            STBRValidate(documentsFD,catalogs,captures,rejected);
            NSDictionary *report=STBRReport(catalogs,captures,rejected,budget,NO,&diag);
            NSData *json=[NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingSortedKeys error:nil];
            if(!json||json.length>STBRJSONLimit){budget.truncated=YES;failCode=5;break;}
            if(!STBRWriteFD(output,json,finishDeadline)){failCode=6;break;}
            if(!STBRValidate(documentsFD,catalogs,captures,rejected)){ready=YES;break;}
            if(attempt==2) {
                report=STBRReport(catalogs,captures,rejected,budget,YES,&diag);
                json=[NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingSortedKeys error:nil];
                ready=json&&STBRWriteFD(output,json,finishDeadline);
            }
          }
        }
        if(!ready||STGSNow()>=finishDeadline||!STBROutputDirectoryAttached(documentsFD,outputDirectory,documentsDevice)||
            !STBROutputSame(outputDirectory,output,temporary.UTF8String,documentsDevice))break;
        // linkat creates the final name atomically and refuses replacement.
        // Remove the temporary link immediately, leaving one owned regular file.
        if(linkat(outputDirectory,temporary.UTF8String,outputDirectory,finalName.UTF8String,0))break;
        if(unlinkat(outputDirectory,temporary.UTF8String,0)) { unlinkat(outputDirectory,finalName.UTF8String,0); break; }
        if(!STBROutputDirectoryAttached(documentsFD,outputDirectory,documentsDevice)||
            !STBROutputSame(outputDirectory,output,finalName.UTF8String,documentsDevice)) { unlinkat(outputDirectory,finalName.UTF8String,0);break; }
        published=YES;result=[directoryURL URLByAppendingPathComponent:finalName];
    } while(NO);
    if(output>=0)close(output);
    if(outputDirectory>=0) { if(!published)unlinkat(outputDirectory,temporary.UTF8String,0);close(outputDirectory); }
    if(libraryFD>=0)close(libraryFD);close(documentsFD);
    if(!diag)STBRReport(catalogs,captures,rejected,budget,YES,&diag);
    if(!result) {
        NSMutableDictionary *failed=[diag mutableCopy];failed[@"status"]=@"export_failed";
        failed[@"filesExported"]=@0;failed[@"bytesExported"]=@0;
        failed[@"errorCode"]=@(STGSNow()>=finishDeadline?7:failCode);diag=failed;
        if(error)*error=STBRError(failCode,@"Não foi possível concluir o arquivo do bilhar dentro dos limites da coleta.");
    }
    if(diagnostic)*diagnostic=diag;
    return result;
}
@end

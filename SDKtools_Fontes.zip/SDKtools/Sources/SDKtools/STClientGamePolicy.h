#ifndef STClientGamePolicy_h
#define STClientGamePolicy_h
#include <stdbool.h>
typedef enum { STClientGameNone=0, STClientGameAlpaca=60, STClientGameCards=2007, STClientGameBilliards=1003 } STClientGame;
/* Only a fresh, positive identity unlocks a module. Stopping is always allowed. */
static inline bool STClientCanModify(STClientGame active, STClientGame requested) {
    return (requested==STClientGameAlpaca || requested==STClientGameCards || requested==STClientGameBilliards) && active==requested;
}
static inline bool STClientCanToggle(STClientGame active, STClientGame requested, bool alreadyEnabled) {
    return alreadyEnabled || STClientCanModify(active,requested);
}
#endif

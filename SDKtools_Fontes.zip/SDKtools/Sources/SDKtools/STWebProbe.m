#import "STWebProbe.h"
#import <WebKit/WebKit.h>
#import <UIKit/UIKit.h>
#import "STWebProbeSanitizer.inc"

// The action returns only a fixed protocol. Page errors, custom data, node names
// and arbitrary dictionary fields must never leak into exported diagnostics.
static NSDictionary *STWPReturnResult(NSString *status, NSString *reason, id dispatched,
                                     BOOL physicalPending, BOOL runtimeValidated) {
    return @{@"version": @1, @"status": status, @"reason": reason,
        @"dispatched": dispatched ?: NSNull.null, @"physicalPending": @(physicalPending),
        @"popupConfirmationRequired": @([status isEqualToString:@"original_event_dispatched"]),
        @"runtimeValidated": @(runtimeValidated), @"boardEffectConfirmed": @NO};
}

static NSDictionary *STWPSanitizeReturnResult(id value) {
    if (![value isKindOfClass:NSDictionary.class] || ![value[@"version"] isEqual:@1])
        return STWPReturnResult(@"dispatch_uncertain", @"invalid_action_result", NSNull.null, NO, NO);
    NSString *status = value[@"status"];
    if ([status isEqual:@"original_event_dispatched"] && value[@"dispatched"] == (__bridge id)kCFBooleanTrue)
        return STWPReturnResult(status, @"original_event_dispatched", @YES, NO, YES);
    if ([status isEqual:@"dispatch_uncertain"])
        return STWPReturnResult(status, @"original_callback_uncertain", NSNull.null, NO, NO);
    if ([status isEqual:@"no_action"] && value[@"dispatched"] == (__bridge id)kCFBooleanFalse) {
        NSString *reason = value[@"reason"];
        NSArray *allowed = @[@"engine_version", @"context_unavailable", @"modal_visible", @"ambiguous_control",
            @"disabled_control", @"fingerprint_mismatch", @"read_error", @"scan_limit", @"time_budget",
            @"page_not_visible", @"document_not_ready", @"control_not_found", @"context_changed",
            @"invalid_scene", @"handler_unavailable", @"handler_ambiguous", @"button_unavailable",
            @"event_mismatch", @"document_unavailable", @"event_unavailable"];
        return STWPReturnResult(status, [allowed containsObject:reason] ? reason : @"original_control_unavailable", @NO, NO, NO);
    }
    return STWPReturnResult(@"dispatch_uncertain", @"invalid_action_result", NSNull.null, NO, NO);
}

@interface STWPContext : NSObject
@property (nonatomic, weak) WKWebView *webView;
@property (nonatomic, copy) NSString *namespaceKey;
@property (nonatomic, copy) NSString *contextID;
@property (nonatomic, copy) NSString *webViewID;
@property (nonatomic, strong) NSMutableSet<NSString *> *issuedContextIDs;
@end
@implementation STWPContext
@end

@interface STWebProbe ()
@property (nonatomic, copy) NSString *script;
@property (nonatomic, copy) NSString *returnScript;
@property (nonatomic) BOOL active;
@property (nonatomic) BOOL inFlight;
@property (nonatomic) BOOL cleaning;
@property (nonatomic) BOOL acting;
@property (nonatomic) BOOL traceControlsEnabled;
@property (nonatomic) NSUInteger generation;
@property (nonatomic) NSUInteger requestSerial;
@property (nonatomic) NSUInteger requestCount;
@property (nonatomic) NSTimeInterval totalLatencyMs;
@property (nonatomic) NSTimeInterval maximumLatencyMs;
@property (nonatomic, strong) NSMapTable<WKWebView *, STWPContext *> *contexts;
@property (nonatomic, strong) NSMutableArray<STWPContext *> *cleanupQueue;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *counters;
- (void)count:(NSString *)key;
- (void)drainCleanup;
@end

@implementation STWebProbe

- (instancetype)init {
    if ((self = [super init])) {
        _contexts = [NSMapTable weakToStrongObjectsMapTable];
        _cleanupQueue = [NSMutableArray array];
        _counters = [NSMutableDictionary dictionary];
        NSBundle *bundle = [NSBundle bundleForClass:STWebProbe.class];
        NSURL *URL = [bundle URLForResource:@"scene_probe" withExtension:@"js"];
        if (!URL) URL = [bundle URLForResource:@"scene_probe" withExtension:@"js" subdirectory:@"Resources"];
        NSNumber *size = nil;
        [URL getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
        if (URL && size.unsignedLongLongValue > 0 && size.unsignedLongLongValue <= 65536)
            _script = [[NSString alloc] initWithContentsOfURL:URL encoding:NSUTF8StringEncoding error:nil];
        NSURL *returnURL = [bundle URLForResource:@"return_tool" withExtension:@"js"];
        if (!returnURL) returnURL = [bundle URLForResource:@"return_tool" withExtension:@"js" subdirectory:@"Resources"];
        NSNumber *returnSize = nil;
        [returnURL getResourceValue:&returnSize forKey:NSURLFileSizeKey error:nil];
        if (returnURL && returnSize.unsignedLongLongValue > 0 && returnSize.unsignedLongLongValue <= 65536)
            _returnScript = [[NSString alloc] initWithContentsOfURL:returnURL encoding:NSUTF8StringEncoding error:nil];
    }
    return self;
}

- (void)count:(NSString *)key { self.counters[key] = @(MIN([self.counters[key] unsignedIntegerValue] + 1, (NSUInteger)1000000)); }

- (void)setTraceControlsEnabled:(BOOL)enabled {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    _traceControlsEnabled = self.active && enabled;
}

- (NSDictionary<NSString *, id> *)diagnosticsSnapshot {
    if (!NSThread.isMainThread) return @{@"error": @"mainThreadRequired"};
    NSUInteger completed = [self.counters[@"completedEvaluations"] unsignedIntegerValue];
    return @{@"requestedEvaluations": @(self.requestCount), @"targetIntervalMs": @250,
        @"cadenceSource": @"recorder_periodic_timer", @"overlapPolicy": @"skip_while_physical_operation_pending",
        @"maximumEvaluations": @720, @"timeoutMs": @2000, @"physicalEvaluationPending": @(self.inFlight),
        @"cleanupPending": @(self.cleanupQueue.count), @"physicalOperation": self.inFlight ? (self.acting ? @"return_action" : (self.cleaning ? @"cleanup" : @"capture")) : @"idle",
        @"meanEvaluationMs": @(completed ? self.totalLatencyMs / completed : 0),
        @"maximumEvaluationMs": @(self.maximumLatencyMs), @"counters": [self.counters copy],
        @"identityRule": @"webViewID_and_contextID_scope_node_frame_texture_IDs",
        @"controlTraceActive": @(self.traceControlsEnabled), @"controlTraceMode": @"read_only_public_metadata",
        @"ownNamespaceOnly": @YES, @"mainFrameOnly": @YES};
}

- (void)reset {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    [self stop];
    self.active = YES;
    self.generation++;
    self.requestCount = 0;
    self.totalLatencyMs = 0;
    self.maximumLatencyMs = 0;
    [self.counters removeAllObjects];
    // Keep a physical capture/action/cleanup lock across resets until its actual callback.
}

- (BOOL)performOriginalReturnInWebView:(WKWebView *)webView
                       validateContext:(BOOL (^)(void))validateContext
                                update:(void (^)(NSDictionary<NSString *,id> *))update {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    NSString *rejection = nil;
    if (self.inFlight) rejection = @"physical_operation_pending";
    else if (self.cleanupQueue.count) { [self drainCleanup]; rejection = @"cleanup_pending"; }
    else if (!self.returnScript.length) rejection = @"action_script_missing";
    else if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive ||
             !webView.window || webView.hidden || webView.alpha < 0.01 || !validateContext()) rejection = @"native_context_unavailable";
    if (rejection) {
        update(STWPReturnResult(@"no_action", rejection, @NO, NO, NO));
        return NO;
    }
    // No capture namespace is required and no game object is cached for this call.
    NSString *wrapped = [NSString stringWithFormat:@"(%@)()", self.returnScript];
    self.inFlight = YES;
    self.cleaning = NO;
    self.acting = YES;
    NSUInteger serial = ++self.requestSerial;
    NSTimeInterval requestedAt = NSProcessInfo.processInfo.systemUptime;
    [self count:@"returnActionRequests"];
    __block BOOL timeoutReported = NO;
    __weak STWebProbe *weakSelf = self;
    @try {
        [webView evaluateJavaScript:wrapped completionHandler:^(id result, NSError *error) {
            STWebProbe *strongSelf = weakSelf;
            if (!strongSelf || strongSelf.requestSerial != serial) return;
            // Capture generations must not discard this callback or release early.
            strongSelf.inFlight = NO;
            strongSelf.acting = NO;
            NSDictionary *safe;
            if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive || !validateContext())
                safe = STWPReturnResult(@"dispatch_uncertain", @"native_context_changed", NSNull.null, NO, NO);
            else if (error)
                safe = STWPReturnResult(@"dispatch_uncertain", @"evaluation_failed_after_submission", NSNull.null, NO, NO);
            else safe = STWPSanitizeReturnResult(result);
            NSMutableDictionary *reported = [safe mutableCopy];
            double duration = (NSProcessInfo.processInfo.systemUptime - requestedAt) * 1000;
            reported[@"evaluationMilliseconds"] = @(isfinite(duration) ? MAX(0, MIN(duration, 3600000)) : 0);
            reported[@"afterTimeout"] = @(timeoutReported);
            [strongSelf count:@"returnActionCallbacks"];
            update(reported);
            [strongSelf drainCleanup];
        }];
    } @catch (__unused NSException *exception) {
        // A throwing bridge cannot prove the game callback did not start. Keep
        // the physical lock until an actual callback, if any, rather than retry.
        timeoutReported = YES;
        [self count:@"returnActionSubmissionException"];
        update(STWPReturnResult(@"dispatch_uncertain", @"submission_exception", NSNull.null, YES, NO));
        return YES;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        STWebProbe *strongSelf = weakSelf;
        if (!strongSelf || !strongSelf.inFlight || !strongSelf.acting || strongSelf.requestSerial != serial) return;
        timeoutReported = YES;
        [strongSelf count:@"returnActionTimeout"];
        update(STWPReturnResult(@"dispatch_uncertain", @"evaluation_timeout", NSNull.null, YES, NO));
        // WebKit has no cancellation acknowledgement. Do not release or retry.
    });
    return YES;
}

- (void)stop {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    self.active = NO;
    self.traceControlsEnabled = NO;
    self.generation++;
    for (STWPContext *context in self.contexts.objectEnumerator.allObjects)
        if (context.webView && ![self.cleanupQueue containsObject:context]) [self.cleanupQueue addObject:context];
    [self.contexts removeAllObjects];
    [self drainCleanup];
}

- (void)drainCleanup {
    if (self.inFlight) return;
    while (self.cleanupQueue.count && !self.cleanupQueue.firstObject.webView) [self.cleanupQueue removeObjectAtIndex:0];
    if (!self.cleanupQueue.count) return;
    STWPContext *context = self.cleanupQueue.firstObject;
    [self.cleanupQueue removeObjectAtIndex:0];
    WKWebView *webView = context.webView;
    // namespaceKey is generated here from UUID hex, never a page or user value.
    NSString *cleanup = [NSString stringWithFormat:@"(function(){var k='%@',d=Object.getOwnPropertyDescriptor(window,k);if(d&&d.value&&d.value.owner===k){delete window[k];}return true;}())", context.namespaceKey];
    self.inFlight = YES;
    self.cleaning = YES;
    NSUInteger serial = ++self.requestSerial;
    [self count:@"cleanupRequests"];
    __weak STWebProbe *weakSelf = self;
    @try {
        [webView evaluateJavaScript:cleanup completionHandler:^(__unused id result, __unused NSError *error) {
            STWebProbe *strongSelf = weakSelf;
            if (!strongSelf || strongSelf.requestSerial != serial) return;
            strongSelf.inFlight = NO;
            strongSelf.cleaning = NO;
            [strongSelf count:error ? @"cleanupFailed" : @"cleanupCompleted"];
            [strongSelf drainCleanup];
        }];
    } @catch (__unused NSException *exception) {
        self.inFlight = NO;
        self.cleaning = NO;
        [self count:@"cleanupException"];
        [self drainCleanup];
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        STWebProbe *strongSelf = weakSelf;
        if (strongSelf.inFlight && strongSelf.requestSerial == serial) [strongSelf count:@"cleanupTimeout"];
        // Timeout does not cancel WebKit execution, so it cannot release the lock.
    });
}

- (void)sampleWebView:(WKWebView *)webView elapsedMilliseconds:(NSTimeInterval)elapsedMilliseconds
          completion:(void (^)(NSDictionary<NSString *,id> *))completion {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    NSTimeInterval now = NSProcessInfo.processInfo.systemUptime;
    if (!self.active) return;
    if (self.inFlight) { [self count:@"skippedPhysicalOperationPending"]; return; }
    if (self.cleanupQueue.count) { [self drainCleanup]; [self count:@"skippedCleanupPending"]; return; }
    if (self.requestCount >= 720) { [self count:@"skippedRequestLimit"]; return; }
    if (!webView.window || webView.hidden || webView.alpha < 0.01) { [self count:@"skippedInvisibleWebView"]; return; }
    // STRecorder's 250 ms repeating timer is the sole scheduling authority.
    // Its tolerance may produce intervals shorter than 245 ms after a late
    // firing. Another time gate here would discard an otherwise eligible tick.
    // The physical operation lock above still prevents concurrent evaluations.
    STWPContext *context = [self.contexts objectForKey:webView];
    if (!context) {
        if (self.contexts.count >= 8 || self.cleanupQueue.count >= 16) { [self count:@"skippedContextLimit"]; return; }
        context = [STWPContext new];
        context.webView = webView;
        context.webViewID = NSUUID.UUID.UUIDString;
        context.issuedContextIDs = [NSMutableSet set];
        context.namespaceKey = [@"__SDKtools_capture_" stringByAppendingString:[NSUUID.UUID.UUIDString stringByReplacingOccurrencesOfString:@"-" withString:@""]];
        [self.contexts setObject:context forKey:webView];
        [self count:@"webViewContextsCreated"];
    }
    self.requestCount++;
    BOOL traceControls = self.traceControlsEnabled;
    if (traceControls) [self count:@"controlTraceRequestedEvaluations"];
    NSString *protocol = STWPChoice(webView.URL.scheme.lowercaseString, @[@"file", @"https", @"http", @"about", @"data"], @"other");
    NSDictionary *metadata = @{@"requestedElapsedMs": @(isfinite(elapsedMilliseconds) ? elapsedMilliseconds : 0),
        @"requestSequence": @(self.requestCount), @"webViewID": context.webViewID,
        @"urlProtocolOnly": protocol, @"isFileURL": @(webView.URL.isFileURL), @"loading": @(webView.loading),
        @"scope": @"observedCocosControllerMainFrame", @"requestedBy": @"explicitUserRecording", @"controlTraceRequested": @(traceControls)};
    if (!self.script.length) {
        [self count:@"missingScript"];
        NSMutableDictionary *failed = [metadata mutableCopy];
        failed[@"status"] = @"probe_script_missing";
        completion(failed);
        return;
    }
    NSString *candidateID = NSUUID.UUID.UUIDString;
    // Only native-issued IDs are trusted. Keep history for a late first callback
    // and for back/forward cache restoring an earlier document in this WebView.
    [context.issuedContextIDs addObject:candidateID]; // Bounded by 720 total requests.
    // The closure survives samples in one document. Navigation removes the namespace,
    // so a fresh native candidate UUID is assigned before node n1 can recur.
    NSString *wrapped = [NSString stringWithFormat:
        @"(function(){var k='%@',d=Object.getOwnPropertyDescriptor(window,k),s=d&&d.value;if(!s||s.owner!==k||typeof s.capture!=='function'){if(d)return {version:2,status:'probe_namespace_conflict'};s=Object.freeze({owner:k,contextID:'%@',capture:(%@)});Object.defineProperty(window,k,{value:s,configurable:true,enumerable:false,writable:false});}var out=s.capture({traceControls:%@});if(!out||typeof out!=='object')return {version:2,status:'invalid_probe_result'};out.contextID=s.contextID;return out;}())",
        context.namespaceKey, candidateID, self.script, traceControls ? @"true" : @"false"];
    self.inFlight = YES;
    self.cleaning = NO;
    NSUInteger generation = self.generation, serial = ++self.requestSerial;
    __block BOOL reportedTimeout = NO;
    __weak STWebProbe *weakSelf = self;
    @try {
        [webView evaluateJavaScript:wrapped completionHandler:^(id result, NSError *error) {
            STWebProbe *strongSelf = weakSelf;
            if (!strongSelf || strongSelf.requestSerial != serial) return;
            strongSelf.inFlight = NO;
            if (!strongSelf.active || strongSelf.generation != generation || reportedTimeout) { [strongSelf drainCleanup]; return; }
            NSMutableDictionary *sample = [metadata mutableCopy];
            double latency = (NSProcessInfo.processInfo.systemUptime - now) * 1000;
            sample[@"evaluationMilliseconds"] = @(isfinite(latency) ? MAX(0, latency) : 0);
            [strongSelf count:@"completedEvaluations"];
            strongSelf.totalLatencyMs += isfinite(latency) ? MAX(0, latency) : 0;
            strongSelf.maximumLatencyMs = MAX(strongSelf.maximumLatencyMs, isfinite(latency) ? latency : 0);
            if (error) { sample[@"status"] = @"evaluation_failed"; [strongSelf count:@"evaluationFailed"]; }
            else {
                id returnedContext = [result isKindOfClass:NSDictionary.class] ? result[@"contextID"] : nil;
                BOOL validContext = [returnedContext isKindOfClass:NSString.class] &&
                    [context.issuedContextIDs containsObject:returnedContext];
                if (validContext) {
                    if (![returnedContext isEqualToString:context.contextID]) [strongSelf count:@"documentContextsCreated"];
                    context.contextID = returnedContext;
                    sample[@"contextID"] = returnedContext;
                    [sample addEntriesFromDictionary:STWPSanitize(result, traceControls)];
                } else { sample[@"status"] = @"probe_context_unverified"; [strongSelf count:@"invalidContext"]; }
            }
            completion(sample);
            [strongSelf drainCleanup];
        }];
    } @catch (__unused NSException *exception) {
        self.inFlight = NO;
        [self count:@"evaluationException"];
        NSMutableDictionary *sample = [metadata mutableCopy];
        sample[@"status"] = @"evaluation_exception";
        completion(sample);
        [self drainCleanup];
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        STWebProbe *strongSelf = weakSelf;
        if (!strongSelf.active || strongSelf.generation != generation || strongSelf.requestSerial != serial || !strongSelf.inFlight) return;
        reportedTimeout = YES;
        [strongSelf count:@"evaluationTimeout"];
        NSMutableDictionary *sample = [metadata mutableCopy];
        sample[@"status"] = @"evaluation_timeout";
        sample[@"newEvaluationsBlockedUntilCallback"] = @YES;
        completion(sample);
        // Never start another capture or cleanup while the physical evaluation runs.
    });
}

@end

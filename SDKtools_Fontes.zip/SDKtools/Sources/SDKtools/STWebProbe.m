#import "STWebProbe.h"
#import <WebKit/WebKit.h>
#import <math.h>

static id STWPNumber(id value) {
    if (![value isKindOfClass:NSNumber.class]) return NSNull.null;
    double number = [value doubleValue];
    return isfinite(number) && fabs(number) <= 10000000 ? value : NSNull.null;
}
static NSDictionary *STWPNumbers(id value, NSArray<NSString *> *keys) {
    if (![value isKindOfClass:NSDictionary.class]) return @{};
    NSMutableDictionary *output = [NSMutableDictionary dictionary];
    for (NSString *key in keys) output[key] = STWPNumber(value[key]);
    return output;
}
static NSString *STWPChoice(id value, NSArray<NSString *> *choices, NSString *fallback) {
    return [value isKindOfClass:NSString.class] && [choices containsObject:value] ? value : fallback;
}
static BOOL STWPBool(id value) { return [value isKindOfClass:NSNumber.class] && [value boolValue]; }
static BOOL STWPMatch(id value, NSString *pattern, NSUInteger maximumLength) {
    if (![value isKindOfClass:NSString.class] || [value length] > maximumLength) return NO;
    return [value rangeOfString:pattern options:NSRegularExpressionSearch].location != NSNotFound;
}

// A web page may redefine public JavaScript APIs. Rebuild each allowed field;
// never export an arbitrary JS result, error description, URL, node name or text.
static NSDictionary *STWPSanitize(id value) {
    if (![value isKindOfClass:NSDictionary.class]) return @{@"version": @1, @"status": @"invalid_probe_result"};
    NSDictionary *input = value;
    NSMutableDictionary *output = [@{@"version": @1, @"status": STWPChoice(input[@"status"],
        @[@"cocos_not_exposed", @"cocos_version_unsupported", @"scene_api_unavailable", @"no_scene",
          @"cocos2_scene_captured", @"capture_error"], @"invalid_probe_result")} mutableCopy];
    id domInput = input[@"dom"];
    NSMutableDictionary *dom = [STWPNumbers(domInput, @[@"viewportWidth", @"viewportHeight", @"devicePixelRatio", @"canvasCount", @"iframeCount"]) mutableCopy];
    if ([domInput isKindOfClass:NSDictionary.class]) {
        dom[@"readyState"] = STWPChoice(domInput[@"readyState"], @[@"loading", @"interactive", @"complete"], @"unknown");
        id canvases = domInput[@"canvases"];
        NSMutableArray *safeCanvases = [NSMutableArray array];
        if ([canvases isKindOfClass:NSArray.class]) {
            for (id canvas in canvases) {
                if (safeCanvases.count >= 6) break;
                if (![canvas isKindOfClass:NSDictionary.class]) continue;
                NSMutableDictionary *row = [STWPNumbers(canvas, @[@"index", @"width", @"height"]) mutableCopy];
                row[@"cssRect"] = STWPNumbers(canvas[@"cssRect"], @[@"x", @"y", @"width", @"height"]);
                [safeCanvases addObject:row];
            }
        }
        dom[@"canvases"] = safeCanvases;
    }
    output[@"dom"] = dom;
    id cocosInput = input[@"cocos"];
    NSMutableDictionary *cocos = [NSMutableDictionary dictionary];
    if ([cocosInput isKindOfClass:NSDictionary.class]) {
        cocos[@"exposed"] = @(STWPBool(cocosInput[@"exposed"]));
        id version = cocosInput[@"version"];
        cocos[@"version"] = STWPMatch(version, @"^[0-9]{1,2}\\.[0-9]{1,3}\\.[0-9]{1,3}(?:[-+][a-zA-Z0-9.]{1,20})?$", 32) ? version : @"unknown";
        cocos[@"activeNodesOnly"] = @YES;
        cocos[@"coordinates"] = @"cocos_local_and_world_units";
        cocos[@"occlusionResolved"] = @NO;
        cocos[@"cardRulesKnown"] = @NO;
        cocos[@"spriteTagMeaning"] = @"fnv32_public_frame_name_not_visual_identity";
        cocos[@"truncated"] = @(STWPBool(cocosInput[@"truncated"]));
    }
    NSArray *categories = @[@"sheep", @"alpaca", @"card", @"tile", @"board", @"slot", @"layer", @"button", @"btn", @"canvas",
                            @"sprite", @"icon", @"cell", @"stage", @"result", @"match", @"other"];
    NSMutableArray *nodes = [NSMutableArray array];
    id rawNodes = input[@"sceneNodes"];
    if ([rawNodes isKindOfClass:NSArray.class]) {
        for (id node in rawNodes) {
            if (nodes.count >= 120) break;
            if (![node isKindOfClass:NSDictionary.class]) continue;
            NSMutableDictionary *row = [STWPNumbers(node, @[@"index", @"parent", @"depth"]) mutableCopy];
            row[@"category"] = STWPChoice(node[@"category"], categories, @"other");
            row[@"active"] = @(STWPBool(node[@"active"]));
            row[@"activeInHierarchy"] = @(STWPBool(node[@"activeInHierarchy"]));
            row[@"local"] = STWPNumbers(node[@"local"], @[@"x", @"y", @"z", @"width", @"height", @"anchorX", @"anchorY", @"scaleX", @"scaleY", @"angle", @"opacity"]);
            if ([node[@"worldOrigin"] isKindOfClass:NSDictionary.class])
                row[@"worldOrigin"] = STWPNumbers(node[@"worldOrigin"], @[@"x", @"y"]);
            id sprite = node[@"sprite"];
            if ([sprite isKindOfClass:NSDictionary.class]) {
                NSMutableDictionary *safeSprite = [@{@"present": @(STWPBool(sprite[@"present"]))} mutableCopy];
                id tag = sprite[@"frameNameTag"];
                if (STWPMatch(tag, @"^[0-9a-f]{8}$", 8)) safeSprite[@"frameNameTag"] = tag;
                if ([sprite[@"atlasRect"] isKindOfClass:NSDictionary.class])
                    safeSprite[@"atlasRect"] = STWPNumbers(sprite[@"atlasRect"], @[@"x", @"y", @"width", @"height"]);
                row[@"sprite"] = safeSprite;
            }
            [nodes addObject:row];
        }
    }
    cocos[@"nodeCount"] = @(nodes.count);
    output[@"cocos"] = cocos;
    output[@"sceneNodes"] = nodes;
    return output;
}

@interface STWebProbe ()
@property (nonatomic, copy) NSString *script;
@property (nonatomic) BOOL active;
@property (nonatomic) BOOL inFlight;
@property (nonatomic) NSUInteger generation;
@property (nonatomic) NSUInteger requestSerial;
@property (nonatomic) NSUInteger requestCount;
@property (nonatomic) NSTimeInterval lastRequestAt;
@end

@implementation STWebProbe

- (instancetype)init {
    if ((self = [super init])) {
        NSBundle *bundle = [NSBundle bundleForClass:STWebProbe.class];
        NSURL *URL = [bundle URLForResource:@"scene_probe" withExtension:@"js"];
        if (!URL) URL = [bundle URLForResource:@"scene_probe" withExtension:@"js" subdirectory:@"Resources"];
        NSNumber *size = nil;
        [URL getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
        if (URL && size.unsignedLongLongValue > 0 && size.unsignedLongLongValue <= 65536)
            _script = [[NSString alloc] initWithContentsOfURL:URL encoding:NSUTF8StringEncoding error:nil];
    }
    return self;
}

- (void)reset {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    self.generation++;
    self.active = YES;
    self.requestCount = 0;
    self.lastRequestAt = 0;
    // A previous evaluation cannot be cancelled by WKWebView. Keep its physical
    // in-flight lock until its callback, even across a recording restart.
}

- (void)stop {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    self.active = NO;
    self.generation++;
}

- (void)sampleWebView:(WKWebView *)webView elapsedMilliseconds:(NSTimeInterval)elapsedMilliseconds
          completion:(void (^)(NSDictionary<NSString *,id> *))completion {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    NSTimeInterval now = NSProcessInfo.processInfo.systemUptime;
    if (!self.active || self.inFlight || self.requestCount >= 180 || !webView.window || webView.hidden ||
        (self.lastRequestAt > 0 && now - self.lastRequestAt < 1.0)) return;
    self.lastRequestAt = now;
    self.requestCount++;
    NSString *protocol = STWPChoice(webView.URL.scheme.lowercaseString, @[@"file", @"https", @"http", @"about", @"data"], @"other");
    NSDictionary *metadata = @{@"requestedElapsedMs": @(isfinite(elapsedMilliseconds) ? elapsedMilliseconds : 0),
        @"urlProtocolOnly": protocol, @"isFileURL": @(webView.URL.isFileURL), @"loading": @(webView.loading),
        @"scope": @"observedCocosControllerMainFrame", @"requestedBy": @"explicitUserRecording"};
    if (!self.script.length) {
        NSMutableDictionary *failed = [metadata mutableCopy];
        failed[@"status"] = @"probe_script_missing";
        completion(failed);
        return;
    }
    self.inFlight = YES;
    NSUInteger generation = self.generation, serial = ++self.requestSerial;
    __block BOOL reportedTimeout = NO;
    __weak STWebProbe *weakSelf = self;
    @try {
        [webView evaluateJavaScript:self.script completionHandler:^(id result, NSError *error) {
            STWebProbe *strongSelf = weakSelf;
            if (!strongSelf || strongSelf.requestSerial != serial) return;
            strongSelf.inFlight = NO;
            if (!strongSelf.active || strongSelf.generation != generation || reportedTimeout) return;
            NSMutableDictionary *sample = [metadata mutableCopy];
            sample[@"evaluationMilliseconds"] = @((NSProcessInfo.processInfo.systemUptime - now) * 1000);
            if (error) sample[@"status"] = @"evaluation_failed";
            else [sample addEntriesFromDictionary:STWPSanitize(result)];
            completion(sample);
        }];
    } @catch (__unused NSException *exception) {
        self.inFlight = NO;
        NSMutableDictionary *sample = [metadata mutableCopy];
        sample[@"status"] = @"evaluation_exception";
        completion(sample);
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        STWebProbe *strongSelf = weakSelf;
        if (!strongSelf.active || strongSelf.generation != generation || strongSelf.requestSerial != serial || !strongSelf.inFlight) return;
        reportedTimeout = YES;
        NSMutableDictionary *sample = [metadata mutableCopy];
        sample[@"status"] = @"evaluation_timeout";
        sample[@"newEvaluationsBlockedUntilCallback"] = @YES;
        completion(sample);
        // Do not launch a second evaluation while the first is physically pending.
    });
}

@end

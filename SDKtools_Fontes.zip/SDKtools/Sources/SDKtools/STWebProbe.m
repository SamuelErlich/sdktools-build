#import "STWebProbe.h"
#import <WebKit/WebKit.h>
#import <math.h>

static id STWPNumber(id value) {
    if (![value isKindOfClass:NSNumber.class]) return NSNull.null;
    double number = [value doubleValue];
    return isfinite(number) && fabs(number) <= 10000000 ? value : NSNull.null;
}
static NSDictionary *STWPNumbers(id value, NSArray<NSString *> *keys) {
    if (![value isKindOfClass:NSDictionary.class]) return @{};
    NSMutableDictionary *output = [NSMutableDictionary dictionary];
    for (NSString *key in keys) output[key] = STWPNumber(value[key]);
    return output;
}
static NSString *STWPChoice(id value, NSArray<NSString *> *choices, NSString *fallback) {
    return [value isKindOfClass:NSString.class] && [choices containsObject:value] ? value : fallback;
}
static BOOL STWPBool(id value) { return [value isKindOfClass:NSNumber.class] && [value boolValue]; }
static BOOL STWPMatch(id value, NSString *pattern, NSUInteger maximumLength) {
    if (![value isKindOfClass:NSString.class] || [value length] > maximumLength) return NO;
    return [value rangeOfString:pattern options:NSRegularExpressionSearch].location != NSNotFound;
}

// A web page may redefine public JavaScript APIs. Rebuild each allowed field;
// never export an arbitrary JS result, error description, URL, node name or text.
static NSDictionary *STWPSanitize(id value) {
    if (![value isKindOfClass:NSDictionary.class] || ![value[@"version"] isEqual:@2]) return @{@"version": @2, @"status": @"invalid_probe_result"};
    NSDictionary *input = value;
    NSMutableDictionary *output = [@{@"version": @2, @"status": STWPChoice(input[@"status"],
        @[@"cocos_not_exposed", @"cocos_version_unsupported", @"scene_api_unavailable", @"no_scene",
          @"cocos2_scene_captured", @"capture_error"], @"invalid_probe_result")} mutableCopy];
    id domInput = input[@"dom"];
    NSMutableDictionary *dom = [STWPNumbers(domInput, @[@"viewportWidth", @"viewportHeight", @"devicePixelRatio", @"canvasCount", @"iframeCount"]) mutableCopy];
    if ([domInput isKindOfClass:NSDictionary.class]) {
        dom[@"readyState"] = STWPChoice(domInput[@"readyState"], @[@"loading", @"interactive", @"complete"], @"unknown");
        id canvases = domInput[@"canvases"];
        NSMutableArray *safeCanvases = [NSMutableArray array];
        if ([canvases isKindOfClass:NSArray.class]) {
            for (NSUInteger index = 0; index < MIN([canvases count], (NSUInteger)6); index++) {
                id canvas = canvases[index];
                if (![canvas isKindOfClass:NSDictionary.class]) continue;
                NSMutableDictionary *row = [STWPNumbers(canvas, @[@"index", @"width", @"height"]) mutableCopy];
                row[@"cssRect"] = STWPNumbers(canvas[@"cssRect"], @[@"x", @"y", @"width", @"height"]);
                [safeCanvases addObject:row];
            }
        }
        dom[@"canvases"] = safeCanvases;
    }
    output[@"dom"] = dom;
    id cocosInput = input[@"cocos"];
    NSMutableDictionary *cocos = [NSMutableDictionary dictionary];
    if ([cocosInput isKindOfClass:NSDictionary.class]) {
        cocos[@"exposed"] = @(STWPBool(cocosInput[@"exposed"]));
        id version = cocosInput[@"version"];
        cocos[@"version"] = STWPMatch(version, @"^[0-9]{1,2}\\.[0-9]{1,3}\\.[0-9]{1,3}(?:[-+][a-zA-Z0-9.]{1,20})?$", 32) ? version : @"unknown";
        cocos[@"activeNodesOnly"] = @YES;
        cocos[@"coordinates"] = @"cocos_local_and_world_units";
        cocos[@"occlusionResolved"] = @NO;
        cocos[@"cardRulesKnown"] = @NO;
        cocos[@"spriteTagMeaning"] = @"fnv32_public_frame_name_not_visual_identity";
        cocos[@"identityScope"] = @"context_local_object_identity_not_card_identity";
        cocos[@"traversal"] = @"prioritized_depth_first";
        cocos[@"truncated"] = @(STWPBool(cocosInput[@"truncated"]));
        cocos[@"limits"] = STWPNumbers(cocosInput[@"limits"], @[@"maxNodes", @"maxVisits", @"maxChildrenPerNode", @"maxQueue", @"maxDepth", @"budgetMs"]);
        cocos[@"stats"] = STWPNumbers(cocosInput[@"stats"], @[@"visitedNodes", @"inspectedChildren", @"skippedInactive", @"skippedInvalid", @"skippedRepeated", @"queuePeak", @"remainingQueued", @"elapsedMs", @"readErrors"]);
        NSMutableArray *reasons = [NSMutableArray array];
        id rawReasons = cocosInput[@"truncationReasons"];
        if ([rawReasons isKindOfClass:NSArray.class]) {
            for (NSUInteger index = 0; index < MIN([rawReasons count], (NSUInteger)16); index++) {
                NSString *reason = STWPChoice(rawReasons[index], @[@"node_limit", @"visit_limit", @"child_limit", @"queue_limit", @"depth_limit", @"time_budget", @"read_error"], @"");
                if (reason.length && ![reasons containsObject:reason]) [reasons addObject:reason];
            }
        }
        cocos[@"truncationReasons"] = reasons;
    }
    NSArray *categories = @[@"sheep", @"alpaca", @"card", @"tile", @"board", @"slot", @"layer", @"button", @"btn", @"canvas",
                            @"sprite", @"icon", @"cell", @"stage", @"result", @"match", @"other"];
    NSMutableArray *nodes = [NSMutableArray array];
    id rawNodes = input[@"sceneNodes"];
    if ([rawNodes isKindOfClass:NSArray.class]) {
        for (NSUInteger index = 0; index < MIN([rawNodes count], (NSUInteger)768); index++) {
            id node = rawNodes[index];
            if (![node isKindOfClass:NSDictionary.class]) continue;
            NSMutableDictionary *row = [STWPNumbers(node, @[@"index", @"parent", @"depth", @"siblingIndex", @"childCountReal", @"childrenQueued"]) mutableCopy];
            if (STWPMatch(node[@"nodeID"], @"^n[1-9][0-9]{0,11}$", 13)) row[@"nodeID"] = node[@"nodeID"];
            row[@"parentID"] = STWPMatch(node[@"parentID"], @"^n[1-9][0-9]{0,11}$", 13) ? node[@"parentID"] : NSNull.null;
            row[@"prioritizationHint"] = STWPChoice(node[@"prioritizationHint"], @[@"piece_geometry", @"board_geometry", @"name_hint", @"none"], @"none");
            row[@"category"] = STWPChoice(node[@"category"], categories, @"other");
            row[@"active"] = @(STWPBool(node[@"active"]));
            row[@"activeInHierarchy"] = @(STWPBool(node[@"activeInHierarchy"]));
            row[@"local"] = STWPNumbers(node[@"local"], @[@"x", @"y", @"z", @"width", @"height", @"anchorX", @"anchorY", @"scaleX", @"scaleY", @"angle", @"opacity"]);
            if ([node[@"worldOrigin"] isKindOfClass:NSDictionary.class])
                row[@"worldOrigin"] = STWPNumbers(node[@"worldOrigin"], @[@"x", @"y"]);
            id sprite = node[@"sprite"];
            if ([sprite isKindOfClass:NSDictionary.class]) {
                NSMutableDictionary *safeSprite = [@{@"present": @(STWPBool(sprite[@"present"]))} mutableCopy];
                id tag = sprite[@"frameNameTag"];
                if (STWPMatch(sprite[@"frameID"], @"^f[1-9][0-9]{0,11}$", 13)) safeSprite[@"frameID"] = sprite[@"frameID"];
                if (STWPMatch(sprite[@"textureID"], @"^t[1-9][0-9]{0,11}$", 13)) safeSprite[@"textureID"] = sprite[@"textureID"];
                if (STWPMatch(tag, @"^[0-9a-f]{8}$", 8)) safeSprite[@"frameNameTag"] = tag;
                if ([sprite[@"atlasRect"] isKindOfClass:NSDictionary.class])
                    safeSprite[@"atlasRect"] = STWPNumbers(sprite[@"atlasRect"], @[@"x", @"y", @"width", @"height"]);
                row[@"sprite"] = safeSprite;
            }
            [nodes addObject:row];
        }
    }
    cocos[@"nodeCount"] = @(nodes.count);
    if ([rawNodes isKindOfClass:NSArray.class] && [rawNodes count] > 768) {
        cocos[@"truncated"] = @YES;
        output[@"nativeNodeLimitApplied"] = @YES;
    }
    output[@"cocos"] = cocos;
    output[@"sceneNodes"] = nodes;
    return output;
}

@interface STWPContext : NSObject
@property (nonatomic, weak) WKWebView *webView;
@property (nonatomic, copy) NSString *namespaceKey;
@property (nonatomic, copy) NSString *contextID;
@property (nonatomic, copy) NSString *webViewID;
@property (nonatomic, strong) NSMutableSet<NSString *> *issuedContextIDs;
@end
@implementation STWPContext
@end

@interface STWebProbe ()
@property (nonatomic, copy) NSString *script;
@property (nonatomic) BOOL active;
@property (nonatomic) BOOL inFlight;
@property (nonatomic) BOOL cleaning;
@property (nonatomic) NSUInteger generation;
@property (nonatomic) NSUInteger requestSerial;
@property (nonatomic) NSUInteger requestCount;
@property (nonatomic) NSTimeInterval lastRequestAt;
@property (nonatomic) NSTimeInterval totalLatencyMs;
@property (nonatomic) NSTimeInterval maximumLatencyMs;
@property (nonatomic, strong) NSMapTable<WKWebView *, STWPContext *> *contexts;
@property (nonatomic, strong) NSMutableArray<STWPContext *> *cleanupQueue;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *counters;
- (void)count:(NSString *)key;
- (void)drainCleanup;
@end

@implementation STWebProbe

- (instancetype)init {
    if ((self = [super init])) {
        _contexts = [NSMapTable weakToStrongObjectsMapTable];
        _cleanupQueue = [NSMutableArray array];
        _counters = [NSMutableDictionary dictionary];
        NSBundle *bundle = [NSBundle bundleForClass:STWebProbe.class];
        NSURL *URL = [bundle URLForResource:@"scene_probe" withExtension:@"js"];
        if (!URL) URL = [bundle URLForResource:@"scene_probe" withExtension:@"js" subdirectory:@"Resources"];
        NSNumber *size = nil;
        [URL getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
        if (URL && size.unsignedLongLongValue > 0 && size.unsignedLongLongValue <= 65536)
            _script = [[NSString alloc] initWithContentsOfURL:URL encoding:NSUTF8StringEncoding error:nil];
    }
    return self;
}

- (void)count:(NSString *)key { self.counters[key] = @(MIN([self.counters[key] unsignedIntegerValue] + 1, (NSUInteger)1000000)); }

- (NSDictionary<NSString *, id> *)diagnosticsSnapshot {
    if (!NSThread.isMainThread) return @{@"error": @"mainThreadRequired"};
    NSUInteger completed = [self.counters[@"completedEvaluations"] unsignedIntegerValue];
    return @{@"requestedEvaluations": @(self.requestCount), @"targetIntervalMs": @250,
        @"maximumEvaluations": @720, @"timeoutMs": @2000, @"physicalEvaluationPending": @(self.inFlight),
        @"cleanupPending": @(self.cleanupQueue.count), @"physicalOperation": self.inFlight ? (self.cleaning ? @"cleanup" : @"capture") : @"idle",
        @"meanEvaluationMs": @(completed ? self.totalLatencyMs / completed : 0),
        @"maximumEvaluationMs": @(self.maximumLatencyMs), @"counters": [self.counters copy],
        @"identityRule": @"webViewID_and_contextID_scope_node_frame_texture_IDs",
        @"ownNamespaceOnly": @YES, @"mainFrameOnly": @YES};
}

- (void)reset {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    [self stop];
    self.active = YES;
    self.generation++;
    self.requestCount = 0;
    self.lastRequestAt = 0;
    self.totalLatencyMs = 0;
    self.maximumLatencyMs = 0;
    [self.counters removeAllObjects];
    // Keep a physical capture/cleanup lock across resets until its actual callback.
}

- (void)stop {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    self.active = NO;
    self.generation++;
    for (STWPContext *context in self.contexts.objectEnumerator.allObjects)
        if (context.webView && ![self.cleanupQueue containsObject:context]) [self.cleanupQueue addObject:context];
    [self.contexts removeAllObjects];
    [self drainCleanup];
}

- (void)drainCleanup {
    if (self.inFlight) return;
    while (self.cleanupQueue.count && !self.cleanupQueue.firstObject.webView) [self.cleanupQueue removeObjectAtIndex:0];
    if (!self.cleanupQueue.count) return;
    STWPContext *context = self.cleanupQueue.firstObject;
    [self.cleanupQueue removeObjectAtIndex:0];
    WKWebView *webView = context.webView;
    // namespaceKey is generated here from UUID hex, never a page or user value.
    NSString *cleanup = [NSString stringWithFormat:@"(function(){var k='%@',d=Object.getOwnPropertyDescriptor(window,k);if(d&&d.value&&d.value.owner===k){delete window[k];}return true;}())", context.namespaceKey];
    self.inFlight = YES;
    self.cleaning = YES;
    NSUInteger serial = ++self.requestSerial;
    [self count:@"cleanupRequests"];
    __weak STWebProbe *weakSelf = self;
    @try {
        [webView evaluateJavaScript:cleanup completionHandler:^(__unused id result, __unused NSError *error) {
            STWebProbe *strongSelf = weakSelf;
            if (!strongSelf || strongSelf.requestSerial != serial) return;
            strongSelf.inFlight = NO;
            strongSelf.cleaning = NO;
            [strongSelf count:error ? @"cleanupFailed" : @"cleanupCompleted"];
            [strongSelf drainCleanup];
        }];
    } @catch (__unused NSException *exception) {
        self.inFlight = NO;
        self.cleaning = NO;
        [self count:@"cleanupException"];
        [self drainCleanup];
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        STWebProbe *strongSelf = weakSelf;
        if (strongSelf.inFlight && strongSelf.requestSerial == serial) [strongSelf count:@"cleanupTimeout"];
        // Timeout does not cancel WebKit execution, so it cannot release the lock.
    });
}

- (void)sampleWebView:(WKWebView *)webView elapsedMilliseconds:(NSTimeInterval)elapsedMilliseconds
          completion:(void (^)(NSDictionary<NSString *,id> *))completion {
    NSAssert(NSThread.isMainThread, @"STWebProbe requires the main thread");
    NSTimeInterval now = NSProcessInfo.processInfo.systemUptime;
    if (!self.active) return;
    if (self.inFlight) { [self count:@"skippedPhysicalOperationPending"]; return; }
    if (self.cleanupQueue.count) { [self drainCleanup]; [self count:@"skippedCleanupPending"]; return; }
    if (self.requestCount >= 720) { [self count:@"skippedRequestLimit"]; return; }
    if (!webView.window || webView.hidden || webView.alpha < 0.01) { [self count:@"skippedInvisibleWebView"]; return; }
    if (self.lastRequestAt > 0 && now - self.lastRequestAt < 0.245) { [self count:@"skippedCadence"]; return; }
    STWPContext *context = [self.contexts objectForKey:webView];
    if (!context) {
        if (self.contexts.count >= 8 || self.cleanupQueue.count >= 16) { [self count:@"skippedContextLimit"]; return; }
        context = [STWPContext new];
        context.webView = webView;
        context.webViewID = NSUUID.UUID.UUIDString;
        context.issuedContextIDs = [NSMutableSet set];
        context.namespaceKey = [@"__SDKtools_capture_" stringByAppendingString:[NSUUID.UUID.UUIDString stringByReplacingOccurrencesOfString:@"-" withString:@""]];
        [self.contexts setObject:context forKey:webView];
        [self count:@"webViewContextsCreated"];
    }
    self.lastRequestAt = now;
    self.requestCount++;
    NSString *protocol = STWPChoice(webView.URL.scheme.lowercaseString, @[@"file", @"https", @"http", @"about", @"data"], @"other");
    NSDictionary *metadata = @{@"requestedElapsedMs": @(isfinite(elapsedMilliseconds) ? elapsedMilliseconds : 0),
        @"requestSequence": @(self.requestCount), @"webViewID": context.webViewID,
        @"urlProtocolOnly": protocol, @"isFileURL": @(webView.URL.isFileURL), @"loading": @(webView.loading),
        @"scope": @"observedCocosControllerMainFrame", @"requestedBy": @"explicitUserRecording"};
    if (!self.script.length) {
        [self count:@"missingScript"];
        NSMutableDictionary *failed = [metadata mutableCopy];
        failed[@"status"] = @"probe_script_missing";
        completion(failed);
        return;
    }
    NSString *candidateID = NSUUID.UUID.UUIDString;
    // Only native-issued IDs are trusted. Keep history for a late first callback
    // and for back/forward cache restoring an earlier document in this WebView.
    [context.issuedContextIDs addObject:candidateID]; // Bounded by 720 total requests.
    // The closure survives samples in one document. Navigation removes the namespace,
    // so a fresh native candidate UUID is assigned before node n1 can recur.
    NSString *wrapped = [NSString stringWithFormat:
        @"(function(){var k='%@',d=Object.getOwnPropertyDescriptor(window,k),s=d&&d.value;if(!s||s.owner!==k||typeof s.capture!=='function'){if(d)return {version:2,status:'probe_namespace_conflict'};s=Object.freeze({owner:k,contextID:'%@',capture:(%@)});Object.defineProperty(window,k,{value:s,configurable:true,enumerable:false,writable:false});}var out=s.capture();if(!out||typeof out!=='object')return {version:2,status:'invalid_probe_result'};out.contextID=s.contextID;return out;}())",
        context.namespaceKey, candidateID, self.script];
    self.inFlight = YES;
    self.cleaning = NO;
    NSUInteger generation = self.generation, serial = ++self.requestSerial;
    __block BOOL reportedTimeout = NO;
    __weak STWebProbe *weakSelf = self;
    @try {
        [webView evaluateJavaScript:wrapped completionHandler:^(id result, NSError *error) {
            STWebProbe *strongSelf = weakSelf;
            if (!strongSelf || strongSelf.requestSerial != serial) return;
            strongSelf.inFlight = NO;
            if (!strongSelf.active || strongSelf.generation != generation || reportedTimeout) { [strongSelf drainCleanup]; return; }
            NSMutableDictionary *sample = [metadata mutableCopy];
            double latency = (NSProcessInfo.processInfo.systemUptime - now) * 1000;
            sample[@"evaluationMilliseconds"] = @(isfinite(latency) ? MAX(0, latency) : 0);
            [strongSelf count:@"completedEvaluations"];
            strongSelf.totalLatencyMs += isfinite(latency) ? MAX(0, latency) : 0;
            strongSelf.maximumLatencyMs = MAX(strongSelf.maximumLatencyMs, isfinite(latency) ? latency : 0);
            if (error) { sample[@"status"] = @"evaluation_failed"; [strongSelf count:@"evaluationFailed"]; }
            else {
                id returnedContext = [result isKindOfClass:NSDictionary.class] ? result[@"contextID"] : nil;
                BOOL validContext = [returnedContext isKindOfClass:NSString.class] &&
                    [context.issuedContextIDs containsObject:returnedContext];
                if (validContext) {
                    if (![returnedContext isEqualToString:context.contextID]) [strongSelf count:@"documentContextsCreated"];
                    context.contextID = returnedContext;
                    sample[@"contextID"] = returnedContext;
                    [sample addEntriesFromDictionary:STWPSanitize(result)];
                } else { sample[@"status"] = @"probe_context_unverified"; [strongSelf count:@"invalidContext"]; }
            }
            completion(sample);
            [strongSelf drainCleanup];
        }];
    } @catch (__unused NSException *exception) {
        self.inFlight = NO;
        [self count:@"evaluationException"];
        NSMutableDictionary *sample = [metadata mutableCopy];
        sample[@"status"] = @"evaluation_exception";
        completion(sample);
        [self drainCleanup];
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        STWebProbe *strongSelf = weakSelf;
        if (!strongSelf.active || strongSelf.generation != generation || strongSelf.requestSerial != serial || !strongSelf.inFlight) return;
        reportedTimeout = YES;
        [strongSelf count:@"evaluationTimeout"];
        NSMutableDictionary *sample = [metadata mutableCopy];
        sample[@"status"] = @"evaluation_timeout";
        sample[@"newEvaluationsBlockedUntilCallback"] = @YES;
        completion(sample);
        // Never start another capture or cleanup while the physical evaluation runs.
    });
}

@end

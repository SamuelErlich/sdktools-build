#import "STClientContext.h"
#import <QuartzCore/QuartzCore.h>

// Main-thread, passive bookkeeping. Never reads chat text or touch positions.
static NSHashTable<UITouch *> *STClientTouches;
static BOOL STClientKeyboard;
static double STClientQuietUntil;
static void STClientInstallInteraction(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        STClientTouches=[NSHashTable weakObjectsHashTable];
        NSNotificationCenter *center=NSNotificationCenter.defaultCenter;
        [center addObserverForName:UIKeyboardWillShowNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *n){
            STClientKeyboard=YES;
        }];
        [center addObserverForName:UIKeyboardDidHideNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *n){
            STClientKeyboard=NO; STClientQuietUntil=CACurrentMediaTime()+0.35;
        }];
        [center addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *n){
            STClientKeyboard=NO; [STClientTouches removeAllObjects]; STClientQuietUntil=0;
        }];
    });
}
BOOL STClientObserveInputEvent(UIEvent *event) {
    if (!NSThread.isMainThread) return NO;
    STClientInstallInteraction();
    if (event.type!=UIEventTypeTouches) return NO;
    BOOL began=NO;
    Class overlay=NSClassFromString(@"STOverlayWindow");
    for (UITouch *touch in event.allTouches) {
        if (overlay && [touch.window isKindOfClass:overlay]) continue;
        if (touch.phase==UITouchPhaseEnded || touch.phase==UITouchPhaseCancelled) {
            [STClientTouches removeObject:touch]; STClientQuietUntil=CACurrentMediaTime()+0.35;
        } else {
            [STClientTouches addObject:touch];
            began|=touch.phase==UITouchPhaseBegan;
        }
    }
    return began;
}
BOOL STClientInteractionBlocked(void) {
    if (!NSThread.isMainThread) return YES;
    STClientInstallInteraction();
    return STClientKeyboard || STClientTouches.count || CACurrentMediaTime()<STClientQuietUntil;
}

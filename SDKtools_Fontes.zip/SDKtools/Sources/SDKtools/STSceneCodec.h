#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSUInteger const STSceneCodecKeyframeInterval;
FOUNDATION_EXPORT NSUInteger const STSceneCodecMaximumDependencyDepth;

// Immutable encoding proposal. Preparing it does not advance the reference target.
@interface STSceneEncodingCandidate : NSObject
@property (nonatomic, copy, readonly) NSDictionary<NSString *, id> *fields;
@property (nonatomic, readonly) NSUInteger fullPayloadBytes;
@property (nonatomic, readonly) NSUInteger encodedPayloadBytes;
@property (nonatomic, readonly) NSUInteger dependencyDepth;
@end

// Main-thread recorder component; Foundation-only to permit native macOS tests.
// Inputs must be immutable JSON values for the candidate/state lifetime. Only the
// last materialized scene is retained; full/delta history belongs to the recorder.
@interface STSceneCodec : NSObject
- (nullable STSceneEncodingCandidate *)prepareNodes:(NSArray *)nodes
                                         contextID:(nullable NSString *)contextID
                                         webViewID:(nullable NSString *)webViewID
                                          sequence:(NSUInteger)sequence;
// Call only after the complete encoded sample has passed the recorder's budget.
// Returns NO for stale proposals. Rejected proposals must never be committed.
- (BOOL)commitCandidate:(STSceneEncodingCandidate *)candidate;
- (void)reset;
@end

NS_ASSUME_NONNULL_END

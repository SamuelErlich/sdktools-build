#import "STClientContext.h"
#import "STRecorder.h"
#import "STBilliardsLuaBridge.h"
STClientGame STClientCurrentGame(UIWindow *overlay) {
    if (!NSThread.isMainThread || !overlay || overlay.hidden || UIApplication.sharedApplication.applicationState!=UIApplicationStateActive ||
        (overlay.windowScene && overlay.windowScene.activationState!=UISceneActivationStateForegroundActive) || overlay.rootViewController.presentedViewController) return STClientGameNone;
    NSNumber *type=[STRecorder.shared visibleHostedGameTypeInWindow:overlay];
    if (type) return type.integerValue==60?STClientGameAlpaca:(type.integerValue==2007?STClientGameCards:STClientGameNone);
    Class unityClass=NSClassFromString(@"UnityView");
    if (!unityClass) return STClientGameNone;
    UIView *unity=nil; NSUInteger visited=0;
    NSArray<UIWindow *> *windows=overlay.windowScene?overlay.windowScene.windows:UIApplication.sharedApplication.windows;
    if (windows.count>16) return STClientGameNone;
    for (UIWindow *window in windows) {
        if (window==overlay || window.hidden || window.alpha<0.01 || window.screen!=overlay.screen || window.windowLevel>UIWindowLevelNormal) continue;
        UIViewController *controller=window.rootViewController;
        if (controller.isBeingPresented || controller.isBeingDismissed || controller.transitionCoordinator || [controller.presentedViewController isKindOfClass:UIAlertController.class]) return STClientGameNone;
        NSMutableArray<UIView *> *pending=[NSMutableArray arrayWithObject:window];
        while (pending.count) {
            if (++visited>512) return STClientGameNone;
            UIView *view=pending.lastObject; [pending removeLastObject];
            if (view.hidden || view.alpha<0.01 || CGRectIsEmpty(view.bounds)) continue;
            if ([view isKindOfClass:unityClass]) { if (unity && unity!=view) return STClientGameNone; unity=view; continue; }
            if (pending.count+view.subviews.count>512) return STClientGameNone;
            [pending addObjectsFromArray:view.subviews];
        }
    }
    if (!unity || !unity.window || CGRectIsEmpty([unity convertRect:unity.bounds toView:unity.window])) return STClientGameNone;
    CGPoint center=CGPointMake(CGRectGetMidX(unity.bounds),CGRectGetMidY(unity.bounds));
    UIView *hit=[unity.window hitTest:[unity convertPoint:center toView:unity.window] withEvent:nil];
    if (hit!=unity && ![hit isDescendantOfView:unity]) return STClientGameNone;
    NSDictionary *identity=[STBilliardsLuaBridge executeCommand:@"identify" error:NULL];
    return [identity[@"format"] isEqual:@"SDK.ClientContext"] && [identity[@"active"] isEqual:@YES]?STClientGameBilliards:STClientGameNone;
}

#import "STClientContext.h"
#import "STRecorder.h"
#import "STBilliardsLuaBridge.h"
static STClientGame STClientFindGame(UIWindow *overlay, BOOL actions) {
    if (!NSThread.isMainThread || !overlay || overlay.hidden || UIApplication.sharedApplication.applicationState!=UIApplicationStateActive ||
        (overlay.windowScene && overlay.windowScene.activationState!=UISceneActivationStateForegroundActive) || (actions && overlay.rootViewController.presentedViewController)) return STClientGameNone;
    NSNumber *type=actions?[STRecorder.shared visibleHostedGameTypeInWindow:overlay]:[STRecorder.shared hostedGameIdentityInWindow:overlay];
    if (type) return type.integerValue==60?STClientGameAlpaca:(type.integerValue==2007?STClientGameCards:STClientGameNone);
    Class unityClass=NSClassFromString(@"UnityView");
    if (!unityClass) return STClientGameNone;
    UIView *unity=nil; NSUInteger visited=0;
    NSArray<UIWindow *> *windows=overlay.windowScene?overlay.windowScene.windows:UIApplication.sharedApplication.windows;
    if (windows.count>16) return STClientGameNone;
    for (UIWindow *window in windows) {
        if (window==overlay || window.hidden || window.alpha<0.01 || window.screen!=overlay.screen || window.windowLevel>UIWindowLevelNormal) continue;
        UIViewController *controller=window.rootViewController;
        if (controller.isBeingPresented || controller.isBeingDismissed ||
            (actions && (controller.transitionCoordinator || controller.presentedViewController))) return STClientGameNone;
        NSMutableArray<UIView *> *pending=[NSMutableArray arrayWithObject:window];
        while (pending.count) {
            if (++visited>512) return STClientGameNone;
            UIView *view=pending.lastObject; [pending removeLastObject];
            if (view.hidden || view.alpha<0.01 || CGRectIsEmpty(view.bounds)) continue;
            if ([view isKindOfClass:unityClass]) { if (unity && unity!=view) return STClientGameNone; unity=view; continue; }
            if (pending.count+view.subviews.count>512) return STClientGameNone;
            [pending addObjectsFromArray:view.subviews];
        }
    }
    if (!unity || !unity.window || CGRectIsEmpty([unity convertRect:unity.bounds toView:unity.window])) return STClientGameNone;
    CGPoint center=CGPointMake(CGRectGetMidX(unity.bounds),CGRectGetMidY(unity.bounds));
    UIView *hit=[unity.window hitTest:[unity convertPoint:center toView:unity.window] withEvent:nil];
    if (actions && hit!=unity && ![hit isDescendantOfView:unity]) return STClientGameNone;
    NSDictionary *identity=[STBilliardsLuaBridge executeCommand:@"identify" error:NULL];
    return [identity[@"format"] isEqual:@"SDK.ClientContext"] && [identity[@"active"] isEqual:@YES]?STClientGameBilliards:STClientGameNone;
}

STClientGame STClientCurrentGame(UIWindow *overlay) {
    (void)STClientInteractionBlocked(); // Register keyboard observers before opt-in.
    return STClientFindGame(overlay,NO);
}
STClientGame STClientActionGame(UIWindow *overlay) {
    return STClientInteractionBlocked()?STClientGameNone:STClientFindGame(overlay,YES);
}

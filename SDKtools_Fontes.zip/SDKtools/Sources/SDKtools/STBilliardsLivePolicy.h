#ifndef ST_BILLIARDS_LIVE_POLICY_H
#define ST_BILLIARDS_LIVE_POLICY_H
#include <stdbool.h>
#include <stdint.h>
#include <math.h>

#define STBL_STALE_SECONDS 0.35
// Poll cadence is independent of a snapshot's drawing lifetime. A slower
// producer may still prove advancing Unity frames; frozen frames expire above.
#define STBL_FEED_GAP_SECONDS 1.0
#define STBL_MOVING_SPEED 0.002
typedef struct { double x, y, depth; } STBLPoint;
typedef struct {
    int64_t sceneHandle, sessionId, cameraId;
    uint32_t width, height;
} STBLContext;
typedef struct {
    STBLContext context;
    uint64_t frame;
    double advancedAt;
    bool hasContext, confirmed;
} STBLFrameGate;
typedef enum { STBLFrameReject=0, STBLFrameWarmup=1, STBLFrameFresh=2, STBLFrameDuplicate=3 } STBLFrameResult;

static inline bool STBLValidPoint(STBLPoint point, double width, double height) {
    return isfinite(point.x) && isfinite(point.y) && isfinite(point.depth) &&
        isfinite(width) && isfinite(height) && width>0 && height>0 && point.depth>0 &&
        point.x>=0 && point.x<=width && point.y>=0 && point.y<=height;
}
static inline bool STBLValidViewport(double pixelWidth, double pixelHeight, double pointWidth, double pointHeight) {
    if (!isfinite(pixelWidth) || !isfinite(pixelHeight) || !isfinite(pointWidth) || !isfinite(pointHeight) ||
        pixelWidth<16 || pixelWidth>16384 || pixelHeight<16 || pixelHeight>16384 ||
        pointWidth<16 || pointWidth>16384 || pointHeight<16 || pointHeight>16384)
        return false;
    double pixelAspect=pixelWidth/pixelHeight, pointAspect=pointWidth/pointHeight;
    return fabs(pixelAspect-pointAspect)/pixelAspect<=0.02;
}
static inline bool STBLValidIdentityBall(int64_t tag, int64_t number, uint32_t *mask) {
    if (!mask || tag<1 || tag>16 || number!=tag-1) return false;
    uint32_t bit=UINT32_C(1) << (unsigned)(tag-1);
    if (*mask & bit) return false;
    *mask |= bit;
    return true;
}
static inline bool STBLContextEqual(STBLContext a, STBLContext b) {
    return a.sceneHandle==b.sceneHandle && a.sessionId==b.sessionId && a.cameraId==b.cameraId &&
        a.width==b.width && a.height==b.height;
}
static inline STBLFrameResult STBLAcceptFrame(STBLFrameGate *gate, STBLContext context, uint64_t frame, double now) {
    if (!gate || !isfinite(now) || now<=0 || context.sessionId<=0 || !context.cameraId ||
        context.width<16 || context.width>16384 || context.height<16 || context.height>16384)
        return STBLFrameReject;
    if (!gate->hasContext || !STBLContextEqual(gate->context,context) || now<gate->advancedAt || frame<gate->frame) {
        *gate=(STBLFrameGate){.context=context,.frame=frame,.advancedAt=now,.hasContext=true,.confirmed=false};
        return STBLFrameWarmup;
    }
    if (frame==gate->frame) {
        if (now-gate->advancedAt>=STBL_STALE_SECONDS) { gate->confirmed=false; gate->hasContext=false; return STBLFrameReject; }
        return gate->confirmed ? STBLFrameDuplicate : STBLFrameWarmup;
    }
    bool continuous=now-gate->advancedAt<STBL_FEED_GAP_SECONDS;
    gate->frame=frame; gate->advancedAt=now;
    gate->confirmed=continuous;
    return continuous ? STBLFrameFresh : STBLFrameWarmup;
}
#endif

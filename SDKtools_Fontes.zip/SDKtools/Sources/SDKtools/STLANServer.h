#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
/// Opt-in foreground-only HTTP on the Wi-Fi IPv4 address, not a public relay.
/// Pairing secret is distinct from all game/account credentials. HTTP is NOT TLS.
@interface STLANServer : NSObject
@property (atomic, readonly) BOOL active;
@property (atomic, readonly) BOOL paired;
@property (atomic, copy, readonly) NSString *URLString;
@property (atomic, copy, readonly) NSString *pairingCode;
- (BOOL)startWithState:(NSDictionary *(^)(void))state
              command:(NSDictionary *(^)(NSDictionary *))command
              stopped:(void (^)(void))stopped
                error:(NSError **)error;
- (void)stop;
@end
NS_ASSUME_NONNULL_END

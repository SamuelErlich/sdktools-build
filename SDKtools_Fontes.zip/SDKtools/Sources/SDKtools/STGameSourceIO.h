#ifndef ST_GAME_SOURCE_IO_H
#define ST_GAME_SOURCE_IO_H
/* Read-only, descriptor-relative source collection. Shared unchanged with the
 * portable test. Paths, symlinks, regular files and mutation are checked before
 * any bytes are exposed to the Objective-C exporter. */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <unistd.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#define STGS_MAX_PATH 1024
#define STGS_MAX_FILE (16u*1024u*1024u)
#define STGS_MAX_TOTAL (32u*1024u*1024u)
#define STGS_MAX_ENTRIES 4096u
#define STGS_MAX_FILES 128u
#define STGS_MAX_DEPTH 8u
#define STGS_MAX_CANDIDATES 256u
typedef struct { char path[STGS_MAX_PATH]; uint64_t size; } STGSCandidate;
typedef struct {
    STGSCandidate files[STGS_MAX_CANDIDATES];
    unsigned count, visited, symlinks, nonJS, other, excessiveDepth, excessiveCandidates, errors;
    bool entryLimit, timedOut;
    double deadline;
    dev_t device;
} STGSInventory;
static inline double STGSNow(void) { struct timespec t; if(clock_gettime(CLOCK_MONOTONIC,&t))return 0;return (double)t.tv_sec+(double)t.tv_nsec/1e9; }
static inline bool STGSRelative(const char *path) {
    if(!path||!*path||*path=='/'||strlen(path)>=STGS_MAX_PATH)return false;
    const char *start=path;
    for(const char *p=path;;p++) {
        if(*p=='/'||!*p) {
            size_t n=(size_t)(p-start);
            if(!n||n>255||(n==1&&start[0]=='.')||(n==2&&start[0]=='.'&&start[1]=='.')||start[0]=='.')return false;
            if(!*p)break;
            start=p+1;
        } else if((unsigned char)*p<32||*p=='\\')return false;
    }
    return true;
}
static inline bool STGSJS(const char *path) { size_t n=path?strlen(path):0;return n>3&&!strcmp(path+n-3,".js"); }
typedef enum {
    STGSRootOK, STGSRootUnsafePath, STGSRootLayoutMismatch,
    STGSRootDifferentGame, STGSRootNativePathMismatch
} STGSRootStatus;
/* Paths here are already relative to the OS-provided Caches directory. The
 * optional native resource path must come from the ABI-checked original
 * gameResDownloadPath:60 getter, after verifying the foreground game identity.
 * It is never obtained from the page, report contents or a directory search. */
static inline STGSRootStatus STGSResolveRoot(const char *entry,const char *nativeResource,char *root,size_t capacity) {
    if(root&&capacity)root[0]=0;
    if(!root||!capacity||!STGSRelative(entry)||(nativeResource&&!STGSRelative(nativeResource)))return STGSRootUnsafePath;
    static const char prefix[]="littleGame/",suffix[]="/game_res/web-mobile/index.html";
    size_t length=strlen(entry),prefixLength=sizeof(prefix)-1,suffixLength=sizeof(suffix)-1;
    if(length<=prefixLength+suffixLength||strncmp(entry,prefix,prefixLength)||strcmp(entry+length-suffixLength,suffix))return STGSRootLayoutMismatch;
    size_t folderLength=length-prefixLength-suffixLength;
    const char *folder=entry+prefixLength;
    if(folderLength>64||memchr(folder,'/',folderLength))return STGSRootLayoutMismatch;
    /* Only a single simple folder can vary; additional path layers and encoded
     * names are not treated as package roots. Descriptor opening rejects links. */
    for(size_t i=0;i<folderLength;i++) {
        char c=folder[i];if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'))return STGSRootUnsafePath;
    }
    size_t resourceLength=length-strlen("/web-mobile/index.html");
    if(nativeResource) {
        if(strlen(nativeResource)!=resourceLength||strncmp(entry,nativeResource,resourceLength))return STGSRootNativePathMismatch;
    } else if(!((folderLength==7&&!memcmp(folder,"60_game",7))||(folderLength==11&&!memcmp(folder,"dev_60_game",11))))return STGSRootDifferentGame;
    size_t rootLength=length-strlen("/index.html");
    if(rootLength+1>capacity)return STGSRootUnsafePath;
    memcpy(root,entry,rootLength);root[rootLength]=0;return STGSRootOK;
}
static inline int STGSOpenRelative(int root, const char *path, bool directory) {
    if(!STGSRelative(path)){errno=EINVAL;return -1;}
    char copy[STGS_MAX_PATH];memcpy(copy,path,strlen(path)+1);
    int fd=dup(root);if(fd<0)return -1;
    char *part=copy;
    for(;;) {
        char *slash=strchr(part,'/');if(slash)*slash=0;
        int flags=O_RDONLY|O_CLOEXEC|O_NOFOLLOW|((slash||directory)?O_DIRECTORY:O_NONBLOCK);
        int next=openat(fd,part,flags);int error=errno;close(fd);fd=next;errno=error;
        if(fd<0||!slash)return fd;
        part=slash+1;
    }
}
typedef struct { char name[256]; } STGSDirectory;
static inline int STGSDirectoryPriority(const char *name) {
    if(!strcmp(name,"src")||!strcmp(name,"js")||!strcmp(name,"main")||!strcmp(name,"game"))return 0;
    if(!strcmp(name,"assets"))return 1;
    if(!strcmp(name,"native")||!strcmp(name,"import"))return 3;
    return 2;
}
static inline int STGSDirectoryCompare(const void *left,const void *right) {
    const STGSDirectory *a=left,*b=right;int rank=STGSDirectoryPriority(a->name)-STGSDirectoryPriority(b->name);
    return rank?rank:strcmp(a->name,b->name);
}
static inline void STGSWalk(int root, int directory, const char *prefix, unsigned depth, STGSInventory *inventory) {
    (void)root;
    if(depth>STGS_MAX_DEPTH){inventory->excessiveDepth++;return;}
    int copied=dup(directory);if(copied<0){inventory->errors++;return;}
    DIR *dir=fdopendir(copied);if(!dir){close(copied);inventory->errors++;return;}
    STGSDirectory *directories=calloc(256,sizeof(STGSDirectory));unsigned directoryCount=0;
    if(!directories){closedir(dir);inventory->errors++;return;}
    // Collect this directory's JS before descending. Source-bearing folders are
    // visited before Cocos native/import asset trees, avoiding asset starvation.
    for(;;) {
        if(inventory->visited>=STGS_MAX_ENTRIES){inventory->entryLimit=true;break;}
        if(STGSNow()>inventory->deadline){inventory->timedOut=true;break;}
        errno=0;struct dirent *entry=readdir(dir);
        if(!entry){if(errno)inventory->errors++;break;}
        if(!strcmp(entry->d_name,".")||!strcmp(entry->d_name,".."))continue;
        inventory->visited++;
        size_t a=strlen(prefix),b=strlen(entry->d_name);
        if(a+b+2>=STGS_MAX_PATH||!STGSRelative(entry->d_name)){inventory->other++;continue;}
        char relative[STGS_MAX_PATH];memcpy(relative,prefix,a);if(a)relative[a++]='/';memcpy(relative+a,entry->d_name,b+1);
        struct stat st;
        if(fstatat(directory,entry->d_name,&st,AT_SYMLINK_NOFOLLOW)){inventory->errors++;continue;}
        if(S_ISLNK(st.st_mode)){inventory->symlinks++;continue;}
        if(st.st_dev!=inventory->device){inventory->other++;continue;}
        if(S_ISDIR(st.st_mode)) {
            if(directoryCount<256)memcpy(directories[directoryCount++].name,entry->d_name,b+1);
            else inventory->other++;
            continue;
        }
        if(!S_ISREG(st.st_mode)||st.st_nlink!=1){inventory->other++;continue;}
        if(!STGSJS(relative)){inventory->nonJS++;continue;}
        if(inventory->count>=STGS_MAX_CANDIDATES){inventory->excessiveCandidates++;continue;}
        STGSCandidate *candidate=&inventory->files[inventory->count++];
        memcpy(candidate->path,relative,strlen(relative)+1);candidate->size=st.st_size<0?0:(uint64_t)st.st_size;
    }
    closedir(dir);qsort(directories,directoryCount,sizeof(STGSDirectory),STGSDirectoryCompare);
    for(unsigned i=0;i<directoryCount&&!inventory->timedOut&&!inventory->entryLimit;i++) {
        char relative[STGS_MAX_PATH];size_t length=strlen(prefix);
        memcpy(relative,prefix,length);if(length)relative[length++]='/';
        memcpy(relative+length,directories[i].name,strlen(directories[i].name)+1);
        int child=openat(directory,directories[i].name,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_DIRECTORY);
        if(child<0){inventory->errors++;continue;}
        STGSWalk(root,child,relative,depth+1,inventory);close(child);
    }
    free(directories);
}
static inline bool STGSStatSame(struct stat a,struct stat b) {
#ifdef __APPLE__
    return a.st_dev==b.st_dev&&a.st_ino==b.st_ino&&a.st_size==b.st_size&&a.st_mtimespec.tv_sec==b.st_mtimespec.tv_sec&&a.st_mtimespec.tv_nsec==b.st_mtimespec.tv_nsec&&a.st_ctimespec.tv_sec==b.st_ctimespec.tv_sec&&a.st_ctimespec.tv_nsec==b.st_ctimespec.tv_nsec;
#else
    return a.st_dev==b.st_dev&&a.st_ino==b.st_ino&&a.st_size==b.st_size&&a.st_mtim.tv_sec==b.st_mtim.tv_sec&&a.st_mtim.tv_nsec==b.st_mtim.tv_nsec&&a.st_ctim.tv_sec==b.st_ctim.tv_sec&&a.st_ctim.tv_nsec==b.st_ctim.tv_nsec;
#endif
}
static inline bool STGSText(const unsigned char *data,size_t size) {
    for(size_t i=0;i<size;) {
        unsigned c=data[i++];
        if(c<128){if((c<32&&c!=9&&c!=10&&c!=13)||c==127)return false;continue;}
        unsigned remaining;uint32_t code,minimum;
        if(c>=0xC2&&c<=0xDF){remaining=1;code=c&31;minimum=0x80;}
        else if(c>=0xE0&&c<=0xEF){remaining=2;code=c&15;minimum=0x800;}
        else if(c>=0xF0&&c<=0xF4){remaining=3;code=c&7;minimum=0x10000;}else return false;
        if(size-i<remaining)return false;
        while(remaining--){unsigned v=data[i++];if((v&0xC0)!=0x80)return false;code=(code<<6)|(v&63);}
        if(code<minimum||code>0x10FFFF||(code>=0xD800&&code<=0xDFFF))return false;
    }
    return true;
}
typedef enum { STGSReadOK,STGSReadUnavailable,STGSReadSize,STGSReadChanged,STGSReadNotText,STGSReadTimeout } STGSReadStatus;
static inline STGSReadStatus STGSRead(int root,const char *relative,dev_t device,size_t maximum,double deadline,unsigned char **bytes,size_t *size) {
    *bytes=NULL;*size=0;
    if(!STGSJS(relative))return STGSReadUnavailable;
    int fd=STGSOpenRelative(root,relative,false);if(fd<0)return STGSReadUnavailable;
    struct stat before,after;
    if(fstat(fd,&before)||!S_ISREG(before.st_mode)||before.st_nlink!=1||before.st_dev!=device){close(fd);return STGSReadUnavailable;}
    if(before.st_size<=0||(uint64_t)before.st_size>maximum){close(fd);return STGSReadSize;}
    size_t expected=(size_t)before.st_size;unsigned char *data=malloc(expected);
    if(!data){close(fd);return STGSReadUnavailable;}
    size_t readBytes=0;STGSReadStatus status=STGSReadOK;
    while(readBytes<expected) {
        if(STGSNow()>deadline){status=STGSReadTimeout;break;}
        ssize_t got=read(fd,data+readBytes,expected-readBytes>65536?65536:expected-readBytes);
        if(got<0&&errno==EINTR)continue;
        if(got<=0){status=STGSReadChanged;break;}readBytes+=(size_t)got;
    }
    if(status==STGSReadOK&&(fstat(fd,&after)||!STGSStatSame(before,after)))status=STGSReadChanged;
    close(fd);
    if(status==STGSReadOK&&!STGSText(data,expected))status=STGSReadNotText;
    if(status!=STGSReadOK){free(data);return status;}
    *bytes=data;*size=expected;return STGSReadOK;
}
static inline unsigned STGSMatches(const unsigned char *bytes,size_t size,const char *needle,size_t *offsets,unsigned capacity) {
    size_t length=strlen(needle);unsigned count=0;
    for(size_t i=0;length&&i+length<=size;i++)if(!memcmp(bytes+i,needle,length)){if(count<capacity)offsets[count]=i;count++;if(count==capacity)return count;}
    return count;
}
#endif

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
/// Bounded observation history, NOT a map of current/hidden card identities.
@interface STCardColorFeed : NSObject
- (void)reset;
- (void)consumeEvents:(NSArray *)events;
- (NSDictionary *)snapshot;
- (NSString *)statusText;
@end
NS_ASSUME_NONNULL_END

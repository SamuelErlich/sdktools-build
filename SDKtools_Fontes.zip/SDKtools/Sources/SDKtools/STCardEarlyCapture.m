#import "STCardEarlyCapture.h"
#import "STCardFeaturePolicy.h"
#import "STLicenseManager.h"
#import <dispatch/dispatch.h>

#if !ST_CARD_GAME_FEATURE_ENABLED
// The paused build contains no lifecycle hook, WebKit message handler,
// notification observer or timer implementation. Calling the old API is inert.
@implementation STCardEarlyCapture
+ (instancetype)shared {
    static STCardEarlyCapture *value; static dispatch_once_t once;
    dispatch_once(&once, ^{ value = [STCardEarlyCapture new]; });
    return value;
}
- (BOOL)active { return NO; }
- (BOOL)requested { return NO; }
- (NSString *)statusText { return @"Cartas desativado nesta versão."; }
- (NSString *)colorStatusText { return @"Cartas desativado."; }
- (BOOL)arm { return NO; }
- (void)stopWithReason:(NSString *)reason { (void)reason; }
- (NSDictionary *)snapshotReport {
    return @{@"version":@1, @"gameType":@2007, @"requested":@NO, @"active":@NO,
        @"status":@"disabled", @"reason":@"feature_disabled", @"samples":@[], @"latest":@{},
        @"native":@{@"hooksInstalled":@NO, @"hooksPrepared":@NO, @"scriptInstalled":@NO,
            @"helloReceived":@NO, @"receivedMessages":@0, @"events":@0}};
}
@end
#else
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <string.h>
#import "STCardEarlySanitizer.inc"
#import "STCardLifecycle.h"
#import "STCardColorFeed.h"

static const NSUInteger STEEventLimit = 4096;
static const NSUInteger STEReportLimit = 4 * 1024 * 1024;
static NSTimeInterval STENow(void) { return NSProcessInfo.processInfo.systemUptime; }

@interface STEHook : NSObject
@property (nonatomic, assign) Class target;
@property (nonatomic) SEL selector;
@property (nonatomic) IMP original;
@property (nonatomic) IMP wrapper;
@property (nonatomic, copy) NSString *typeEncoding;
@property (nonatomic) BOOL installed;
@property (nonatomic) BOOL contested;
@end
@implementation STEHook @end

@class STEMessageReceiver;
@interface STCardEarlyCapture ()
@property (nonatomic, readwrite) BOOL active;
@property (nonatomic, readwrite) BOOL requested;
@property (nonatomic) NSUInteger generation;
@property (nonatomic, copy) NSString *state;
@property (nonatomic, copy) NSString *reason;
@property (nonatomic, copy) NSString *lastArmFailure;
@property (nonatomic, copy) NSString *token;
@property (nonatomic, copy) NSString *handlerName;
@property (nonatomic, copy) NSString *documentID;
@property (nonatomic, copy) NSURL *documentURL;
@property (nonatomic, weak) UIViewController *targetController;
@property (nonatomic, weak) WKWebView *targetWebView;
@property (nonatomic, weak) WKUserContentController *contentController;
@property (nonatomic, strong) WKUserScript *ownedScript;
@property (nonatomic, strong) STEMessageReceiver *receiver;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSMutableArray<STEHook *> *hooks;
@property (nonatomic, strong) NSMutableArray *samples;
@property (nonatomic, strong) NSDictionary *latest;
@property (nonatomic, strong) STCardColorFeed *colorFeed;
@property (nonatomic, strong) NSMutableSet<NSString *> *nativeGaps;
@property (nonatomic) NSTimeInterval armedAt;
@property (nonatomic) NSTimeInterval startedAt;
@property (nonatomic) NSTimeInterval stoppedAt;
@property (nonatomic) NSTimeInterval lastMessageAt;
@property (nonatomic) NSTimeInterval lastNotificationAt;
@property (nonatomic) NSUInteger receivedMessages;
@property (nonatomic) NSUInteger rejectedMessages;
@property (nonatomic) NSUInteger omittedEvents;
@property (nonatomic) NSUInteger sequenceGaps;
@property (nonatomic) NSUInteger lastSequence;
@property (nonatomic) NSUInteger eventCount;
@property (nonatomic) NSUInteger reportBytes;
@property (nonatomic) BOOL scriptInstalled;
@property (nonatomic) BOOL hooksPrepared;
@property (nonatomic) BOOL helloReceived;
@property (nonatomic) BOOL loadCheckpoint;
@property (nonatomic) BOOL setupCheckpoint;
@property (nonatomic) BOOL pollingPreparation;
@property (nonatomic) BOOL finalDrainReceived;
@property (nonatomic) BOOL targetSelected;
- (void)checkpoint:(id)controller beforeLoad:(BOOL)beforeLoad;
- (void)receive:(WKScriptMessage *)message generation:(NSUInteger)generation reply:(void (^)(id, NSString *))reply;
@end

// WKUserContentController retains its handler. The handler only weakly refers
// back to the session; generation additionally rejects callbacks from old arms.
@interface STEMessageReceiver : NSObject <WKScriptMessageHandlerWithReply>
@property (nonatomic, weak) STCardEarlyCapture *owner;
@property (nonatomic) NSUInteger generation;
@end
@implementation STEMessageReceiver
- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message replyHandler:(void (^)(id _Nullable, NSString * _Nullable))replyHandler {
    STCardEarlyCapture *owner = self.owner;
    if (!owner) { replyHandler(@{@"active":@NO}, nil); return; }
    [owner receive:message generation:self.generation reply:replyHandler];
}
@end

@implementation STCardEarlyCapture
+ (instancetype)shared {
    static STCardEarlyCapture *value; static dispatch_once_t once;
    dispatch_once(&once, ^{ value = [STCardEarlyCapture new]; }); return value;
}
- (instancetype)init {
    if ((self = [super init])) {
        _hooks = [NSMutableArray array]; _samples = [NSMutableArray array]; _colorFeed = [STCardColorFeed new];
        _nativeGaps = [NSMutableSet set]; _state = @"idle"; _reason = @"not_requested";
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(backgrounded:) name:UIApplicationDidEnterBackgroundNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(backgrounded:) name:UIApplicationWillResignActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(licenseChanged:) name:STLicenseDidChangeNotification object:nil];
    }
    return self;
}
- (void)backgrounded:(NSNotification *)notification { if (self.active) [self stopWithReason:@"application_inactive"]; }
- (void)licenseChanged:(NSNotification *)notification { if (!STLicenseAllowsFeatures()) [self stopWithReason:@"explicit_stop"]; }
- (NSString *)colorStatusText { return [self.colorFeed statusText]; }
- (BOOL)supportedHost {
    NSDictionary *config = [NSBundle bundleForClass:self.class].infoDictionary;
    NSDictionary *map = @{@"CFBundleIdentifier":@"SDKToolsTargetBundleIdentifier", @"CFBundleShortVersionString":@"SDKToolsTargetVersion", @"CFBundleVersion":@"SDKToolsTargetBuild", @"CFBundleExecutable":@"SDKToolsTargetExecutable"};
    for (NSString *key in map) {
        id expected = config[map[key]], actual = [NSBundle.mainBundle objectForInfoDictionaryKey:key];
        if (![expected isKindOfClass:NSString.class] || ![expected length] || ![actual isKindOfClass:NSString.class] || ![actual isEqual:expected]) return NO;
    }
    return YES;
}
- (void)notifyChanged {
    if (!NSThread.isMainThread) return;
    // The observer can be busy while cards animate. Coalesce UI refreshes.
    NSTimeInterval now = STENow();
    if (self.active && now - self.lastNotificationAt < 0.5) return;
    self.lastNotificationAt = now;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"STRecorderDidChangeNotification" object:nil];
}
- (NSString *)statusText {
    if ([self.lastArmFailure isEqual:@"already_open_document"]) return @"Saia das cartas, arme no lobby e entre novamente.";
    if ([self.lastArmFailure isEqual:@"preflight_scan_limit"]) return @"Não foi possível conferir a tela. Feche outras janelas e tente novamente.";
    if (!self.requested) return @"Arme antes de abrir as cartas. A coleta dura 90 s.";
    if ([self.state isEqual:@"blocked"]) return @"Captura inicial bloqueada. Exporte para conferir o motivo.";
    if (self.active && !self.helloReceived) return self.scriptInstalled ? @"Preparado para a próxima abertura das cartas…" : @"Armado. Abra as cartas em até 120 s.";
    if (self.active) return [NSString stringWithFormat:@"Início das cartas · %.0f/90 s · %lu eventos", MIN(90.0, STENow() - self.startedAt), (unsigned long)self.eventCount];
    return [NSString stringWithFormat:@"Captura inicial encerrada · %lu eventos · exporte o diagnóstico", (unsigned long)self.eventCount];
}
- (BOOL)arm {
    if (!NSThread.isMainThread) return NO;
    if (!STLicenseAllowsFeatures()) return NO;
    if (self.active) return YES;
    self.lastArmFailure = nil;
    if ([self supportedHost] && UIApplication.sharedApplication.applicationState == UIApplicationStateActive && [self hasOpenCardsDocument]) {
        if (!self.lastArmFailure) self.lastArmFailure = @"already_open_document";
        if (!self.requested) { self.requested = YES; self.state = @"blocked"; self.reason = self.lastArmFailure; }
        [self notifyChanged]; return NO;
    }
    self.lastArmFailure = nil;
    self.generation++; self.requested = YES; self.active = YES;
    self.state = @"armed"; self.reason = @"awaiting_controller";
    self.armedAt = STENow(); self.startedAt = 0; self.stoppedAt = 0; self.lastMessageAt = 0;
    self.lastNotificationAt = 0; self.samples = [NSMutableArray array]; self.latest = @{};
    self.nativeGaps = [NSMutableSet set]; self.targetController = nil; self.targetWebView = nil;
    self.targetSelected = NO; self.documentID = nil; self.documentURL = nil;
    self.receivedMessages = self.rejectedMessages = self.omittedEvents = self.sequenceGaps = 0;
    self.lastSequence = self.eventCount = self.reportBytes = 0;
    [self.colorFeed reset];
    self.hooksPrepared = self.scriptInstalled = self.helloReceived = self.loadCheckpoint = self.setupCheckpoint = self.pollingPreparation = self.finalDrainReceived = NO;
    self.token = [NSUUID.UUID.UUIDString stringByReplacingOccurrencesOfString:@"-" withString:@""].lowercaseString;
    self.handlerName = [@"ste_" stringByAppendingString:[NSUUID.UUID.UUIDString stringByReplacingOccurrencesOfString:@"-" withString:@""].lowercaseString];
    if (![self supportedHost]) { [self stopWithReason:@"unsupported_host"]; self.state = @"blocked"; [self notifyChanged]; return NO; }
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) { [self stopWithReason:@"application_inactive"]; return NO; }
    if (@available(iOS 14.0, *)) { /* The host has minOS 15; retain a runtime gate. */ }
    else { [self stopWithReason:@"unsupported_webkit_api"]; self.state = @"blocked"; return NO; }
    [self installHooks];
    __weak typeof(self) weakSelf = self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.25 repeats:YES block:^(__unused NSTimer *timer) { [weakSelf tick]; }];
    [self tick]; [self notifyChanged]; return self.active;
}
- (BOOL)controllerIsCards:(id)controller {
    // An unreviewed subclass can override lifecycle or gameType contracts.
    // Restrict the audited ABI to the exact runtime class, including when a
    // lifecycle method itself was inherited from a superclass.
    Class cls = NSClassFromString(@"WPCocosGameViewController");
    if (!controller || object_getClass(controller) != cls || ![controller isKindOfClass:UIViewController.class]) return NO;
    SEL sel = NSSelectorFromString(@"gameType"); Method method = class_getInstanceMethod(cls, sel);
    const char *type = method ? method_getTypeEncoding(method) : NULL;
    if (!type || strcmp(type, "q16@0:8") != 0 || method_getNumberOfArguments(method) != 2) { self.reason = @"game_type_abi_mismatch"; return NO; }
    @try { return ((long long (*)(id, SEL))objc_msgSend)(controller, sel) == 2007; }
    @catch (__unused NSException *exception) { self.reason = @"game_type_read_failed"; return NO; }
}
- (WKWebView *)webViewInController:(UIViewController *)controller {
    UIView *root = controller.viewIfLoaded; if (!root) { self.reason = @"view_not_loaded"; return nil; }
    NSMutableArray *pending = [NSMutableArray arrayWithObject:root]; NSUInteger visited = 0; WKWebView *found = nil;
    while (pending.count && visited++ < 256) {
        UIView *view = pending.lastObject; [pending removeLastObject];
        if ([view isKindOfClass:WKWebView.class]) {
            if (found && found != view) { self.reason = @"ambiguous_webview"; return nil; }
            found = (WKWebView *)view; continue;
        }
        if (pending.count + view.subviews.count > 256) { self.reason = @"view_scan_limit"; return nil; }
        [pending addObjectsFromArray:view.subviews];
    }
    if (pending.count) { self.reason = @"view_scan_limit"; return nil; }
    if (!found) self.reason = @"webview_unavailable";
    return found;
}
- (BOOL)installHooks {
    if (!self.active || !NSThread.isMainThread) return NO;
    if (!STLicenseAllowsFeatures()) return NO;
    Class cls = NSClassFromString(@"WPCocosGameViewController");
    if (!cls) { self.reason = @"controller_class_unavailable"; return NO; }
    for (NSString *name in @[@"setupWKWebView", @"loadCurrentGame"]) {
        SEL sel = NSSelectorFromString(name); STEHook *record = nil;
        for (STEHook *h in self.hooks) if (h.target == cls && h.selector == sel) { record = h; break; }
        Method method = class_getInstanceMethod(cls, sel); const char *types = method ? method_getTypeEncoding(method) : NULL;
        if (!STCardLifecycleMatches(sel, method)) { self.reason = @"lifecycle_abi_mismatch"; [self.nativeGaps addObject:@"lifecycle_abi_mismatch"]; continue; }
        IMP current = method_getImplementation(method);
        if (record) {
            if (current == record.wrapper) { record.installed = YES; continue; }
            if (record.contested || current != record.original) { record.contested = YES; self.reason = @"lifecycle_method_replaced"; [self.nativeGaps addObject:self.reason]; continue; }
            class_replaceMethod(cls, sel, record.wrapper, types); record.installed = YES; continue;
        }
        record = [STEHook new]; record.target = cls; record.selector = sel; record.original = current;
        record.typeEncoding = [NSString stringWithUTF8String:types];
        // Keep a single block/record per selector for the process lifetime. An
        // external hook may retain our IMP; freeing it would be unsafe.
        __weak typeof(self) weakSelf = self;
        IMP wrapper = STCardLifecycleWrapper(sel, current, ^(id object, BOOL before) {
            if (!NSThread.isMainThread) return;
            @try { [weakSelf checkpoint:object beforeLoad:before]; }
            @catch (__unused NSException *exception) { [weakSelf stopWithReason:@"native_checkpoint_error"]; }
        });
        record.wrapper = wrapper; [self.hooks addObject:record];
        // class_addMethod makes an inherited implementation local; never
        // method_setImplementation on a Method owned by the superclass.
        if (!class_addMethod(cls, sel, wrapper, types)) class_replaceMethod(cls, sel, wrapper, types);
        record.installed = YES;
    }
    NSUInteger installed = 0; for (STEHook *h in self.hooks) if (h.installed) installed++;
    if (installed == 2) self.hooksPrepared = YES;
    return installed == 2;
}
- (void)restoreHooks {
    for (STEHook *hook in self.hooks) {
        if (!hook.installed) continue;
        Method method = class_getInstanceMethod(hook.target, hook.selector);
        if (method && method_getImplementation(method) == hook.wrapper) class_replaceMethod(hook.target, hook.selector, hook.original, hook.typeEncoding.UTF8String);
        else { hook.contested = YES; [self.nativeGaps addObject:@"lifecycle_restore_contested"]; }
        hook.installed = NO;
    }
}
- (void)checkpoint:(id)controller beforeLoad:(BOOL)beforeLoad {
    if (!self.active || !NSThread.isMainThread) return;
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) { [self stopWithReason:@"application_inactive"]; return; }
    if (![self controllerIsCards:controller]) {
        if (self.targetSelected && controller == self.targetController) [self stopWithReason:@"game_context_changed"];
        return;
    }
    if (self.targetSelected && controller != self.targetController) return;
    if (beforeLoad) self.loadCheckpoint = YES; else self.setupCheckpoint = YES;
    // A second load is navigation away from the bound document. Never follow.
    if (beforeLoad && self.helloReceived) { [self stopWithReason:@"document_changed"]; return; }
    WKWebView *webView = [self webViewInController:controller];
    if (webView) [self prepareWebView:webView controller:controller polling:NO];
}
- (void)prepareWebView:(WKWebView *)webView controller:(UIViewController *)controller polling:(BOOL)polling {
    if (!self.active || self.helloReceived) return;
    if (!STLicenseAllowsFeatures()) { [self stopWithReason:@"explicit_stop"]; return; }
    if (self.targetSelected && (controller != self.targetController || webView != self.targetWebView)) { [self stopWithReason:@"webview_changed"]; return; }
    if (self.scriptInstalled) return;
    self.targetSelected = YES; self.targetController = controller; self.targetWebView = webView;
    self.pollingPreparation = polling;
    NSBundle *bundle = [NSBundle bundleForClass:self.class];
    NSURL *url = [bundle URLForResource:@"card_early" withExtension:@"js"];
    if (!url) url = [bundle URLForResource:@"card_early" withExtension:@"js" subdirectory:@"Resources"];
    NSNumber *size = nil; [url getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
    if (!url || !size.unsignedLongLongValue || size.unsignedLongLongValue > 131072) { [self stopWithReason:@"early_script_missing"]; return; }
    NSString *source = [[NSString alloc] initWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    NSData *configData = [NSJSONSerialization dataWithJSONObject:@{@"handlerName":self.handlerName, @"token":self.token} options:0 error:nil];
    NSString *config = [[NSString alloc] initWithData:configData encoding:NSUTF8StringEncoding];
    if (!source.length || !config.length) { [self stopWithReason:@"early_script_invalid"]; return; }
    NSString *script = [NSString stringWithFormat:@";(function(){'use strict';var f=(%@);f(%@);})();", source, config];
    WKUserContentController *content = webView.configuration.userContentController;
    if (!content) { [self stopWithReason:@"content_controller_unavailable"]; return; }
    @try {
        if (@available(iOS 14.0, *)) {
            STEMessageReceiver *receiver = [STEMessageReceiver new]; receiver.owner = self; receiver.generation = self.generation;
            self.receiver = receiver; self.contentController = content;
            [content addScriptMessageHandlerWithReply:receiver contentWorld:WKContentWorld.pageWorld name:self.handlerName];
            self.ownedScript = [[WKUserScript alloc] initWithSource:script injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:YES inContentWorld:WKContentWorld.pageWorld];
            [content addUserScript:self.ownedScript]; self.scriptInstalled = YES;
            self.state = @"waiting_document"; self.reason = polling ? @"prepared_next_navigation" : @"prepared_lifecycle_checkpoint";
        }
    } @catch (__unused NSException *exception) { [self stopWithReason:@"script_install_failed"]; }
    [self notifyChanged];
}
- (BOOL)hasOpenCardsDocument {
    // Refuse a late arm before clearing a previous report. A normal exit can
    // destroy the old controller; never imply that this can follow a new one.
    NSMutableArray *pending = [NSMutableArray array]; NSUInteger windows = 0;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if (++windows > 16) { self.lastArmFailure = @"preflight_scan_limit"; return YES; }
            if (!window.hidden && window.alpha > 0.01 && window.rootViewController) [pending addObject:window.rootViewController];
        }
    }
    NSHashTable *seen = [NSHashTable hashTableWithOptions:NSPointerFunctionsObjectPointerPersonality]; NSUInteger visited = 0;
    while (pending.count && visited++ < 128) {
        UIViewController *controller = pending.lastObject; [pending removeLastObject];
        if ([seen containsObject:controller]) continue; [seen addObject:controller];
        if ([self controllerIsCards:controller] && controller.viewIfLoaded.window) {
            WKWebView *webView = [self webViewInController:controller];
            if (webView.URL || webView.loading) return YES;
        }
        if (pending.count + controller.childViewControllers.count > 128) { self.lastArmFailure = @"preflight_scan_limit"; return YES; }
        [pending addObjectsFromArray:controller.childViewControllers];
        if (controller.presentedViewController) [pending addObject:controller.presentedViewController];
    }
    if (pending.count) self.lastArmFailure = @"preflight_scan_limit";
    return pending.count > 0;
}
- (void)pollForController {
    // Read-only fallback. Adding a user script never executes it in the current
    // document; this path prepares the NEXT navigation and claims no coverage.
    NSMutableArray<UIViewController *> *pending = [NSMutableArray array]; NSUInteger windows = 0;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if (++windows > 16) { self.reason = @"window_scan_limit"; return; }
            if (!window.hidden && window.alpha > 0.01 && window.rootViewController) [pending addObject:window.rootViewController];
        }
    }
    NSHashTable *seen = [NSHashTable hashTableWithOptions:NSPointerFunctionsObjectPointerPersonality];
    UIViewController *found = nil; NSUInteger visited = 0;
    while (pending.count && visited++ < 128) {
        UIViewController *controller = pending.lastObject; [pending removeLastObject];
        if ([seen containsObject:controller]) continue; [seen addObject:controller];
        if ([self controllerIsCards:controller] && controller.viewIfLoaded.window && !controller.isBeingDismissed) {
            if (found && found != controller) { self.reason = @"ambiguous_controller"; return; }
            found = controller;
        }
        if (pending.count + controller.childViewControllers.count > 128) { self.reason = @"controller_scan_limit"; return; }
        [pending addObjectsFromArray:controller.childViewControllers];
        if (controller.presentedViewController) [pending addObject:controller.presentedViewController];
    }
    if (pending.count) { self.reason = @"controller_scan_limit"; return; }
    if (found) { WKWebView *webView = [self webViewInController:found]; if (webView) [self prepareWebView:webView controller:found polling:YES]; }
}
- (void)tick {
    if (!self.active) return;
    if (!STLicenseAllowsFeatures()) { [self stopWithReason:@"explicit_stop"]; return; }
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) { [self stopWithReason:@"application_inactive"]; return; }
    NSTimeInterval now = STENow();
    if (!self.helloReceived && now - self.armedAt >= 120) { [self stopWithReason:@"document_start_timeout"]; return; }
    // The final 1.5 seconds only receive events timestamped inside JS's 90 s.
    // They give the last 250 ms batch/end a chance to cross WebKit's IPC queue.
    if (self.helloReceived && now - self.startedAt >= 91.5) { [self stopWithReason:@"duration_limit"]; return; }
    if (self.helloReceived && now - self.lastMessageAt > 4.5) { [self.nativeGaps addObject:@"transport_heartbeat_missing"]; [self stopWithReason:@"transport_timeout"]; return; }
    if (!self.scriptInstalled) { [self installHooks]; [self pollForController]; }
    if (self.targetSelected) {
        if (!self.targetController || !self.targetWebView || ![self controllerIsCards:self.targetController]) { [self stopWithReason:@"game_context_changed"]; return; }
        WKWebView *current = [self webViewInController:self.targetController];
        if (current != self.targetWebView) { [self stopWithReason:@"webview_changed"]; return; }
        if (self.targetController.isBeingDismissed || self.targetController.isMovingFromParentViewController) { [self stopWithReason:@"controller_dismissed"]; return; }
        if (self.helloReceived && !self.targetWebView.loading && self.targetWebView.URL && ![self.targetWebView.URL isEqual:self.documentURL]) { [self stopWithReason:@"document_changed"]; return; }
    }
    [self notifyChanged];
}
- (void)receive:(WKScriptMessage *)message generation:(NSUInteger)generation reply:(void (^)(id, NSString *))reply {
    if (!NSThread.isMainThread || !self.active || generation != self.generation) { reply(@{@"active":@NO}, nil); return; }
    self.receivedMessages++;
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive || ![self controllerIsCards:self.targetController]) {
        [self stopWithReason:@"game_context_changed"]; reply(@{@"active":@NO}, nil); return;
    }
    if (message.webView != self.targetWebView || !message.frameInfo.isMainFrame || ![message.name isEqual:self.handlerName]) {
        self.rejectedMessages++; [self.nativeGaps addObject:@"foreign_message_rejected"]; reply(@{@"active":@NO}, nil); return;
    }
    id body = message.body;
    if (![body isKindOfClass:NSDictionary.class] || ![STENumber(body[@"version"], 1, 1) isEqual:@1] || ![body[@"token"] isKindOfClass:NSString.class] || ![body[@"token"] isEqual:self.token] || !STEDocumentID(body[@"documentID"]) || !STEBoundedJSON(body, 65536)) {
        self.rejectedMessages++; [self.nativeGaps addObject:@"invalid_envelope"]; reply(@{@"active":@NO}, nil); return;
    }
    NSString *kind = STEChoice(body[@"kind"], @[@"hello", @"batch", @"end"]);
    NSDictionary *safe = STESanitizeObservation(body[@"observation"]);
    NSURL *url = message.frameInfo.request.URL;
    if (!kind || !safe || !url || !url.scheme.length) {
        self.rejectedMessages++; [self.nativeGaps addObject:@"invalid_observation"]; reply(@{@"active":@NO}, nil); return;
    }
    if (!self.helloReceived) {
        if (![kind isEqual:@"hello"]) { self.rejectedMessages++; [self.nativeGaps addObject:@"missing_hello"]; reply(@{@"active":@NO}, nil); return; }
        self.documentID = body[@"documentID"]; self.documentURL = url; self.helloReceived = YES;
        self.startedAt = STENow(); self.state = @"capturing"; self.reason = @"observing";
    } else if (![body[@"documentID"] isEqual:self.documentID] || ![url isEqual:self.documentURL]) {
        self.rejectedMessages++; [self stopWithReason:@"document_changed"]; reply(@{@"active":@NO}, nil); return;
    } else if ([kind isEqual:@"hello"]) {
        self.rejectedMessages++; [self.nativeGaps addObject:@"duplicate_hello"]; reply(@{@"active":@YES}, nil); return;
    }
    self.lastMessageAt = STENow();
    NSMutableDictionary *observation = [safe mutableCopy]; NSMutableArray *events = [NSMutableArray array];
    self.omittedEvents += [safe[@"nativeOmittedEvents"] unsignedIntegerValue];
    for (NSDictionary *event in safe[@"events"]) {
        NSUInteger seq = [event[@"sequence"] unsignedIntegerValue];
        if (seq <= self.lastSequence) { self.omittedEvents++; [self.nativeGaps addObject:@"duplicate_or_reordered_event"]; continue; }
        if (seq > self.lastSequence + 1) self.sequenceGaps += seq - self.lastSequence - 1;
        self.lastSequence = seq;
        if ([event[@"elapsedMs"] doubleValue] > 90000 || self.eventCount >= STEEventLimit) { self.omittedEvents++; [self.nativeGaps addObject:@"native_event_limit"]; continue; }
        [events addObject:event]; self.eventCount++;
    }
    observation[@"events"] = events;
    NSMutableDictionary *metadata = [observation mutableCopy]; [metadata removeObjectForKey:@"events"];
    self.latest = metadata;
    NSDictionary *sample = @{@"nativeElapsedMs":@((NSUInteger)MIN(91500.0, MAX(0.0, (STENow() - self.startedAt) * 1000))), @"kind":kind, @"observation":observation};
    NSData *bytes = STEBoundedJSON(sample, 65536);
    if (!bytes || self.reportBytes + bytes.length > STEReportLimit - 32768 || self.samples.count >= 512) {
        self.omittedEvents += events.count; self.eventCount -= events.count;
        [self.nativeGaps addObject:@"native_report_limit"]; [self stopWithReason:@"native_report_limit"]; reply(@{@"active":@NO}, nil); return;
    }
    self.reportBytes += bytes.length; [self.samples addObject:sample];
    [self.colorFeed consumeEvents:events];
    if ([kind isEqual:@"end"]) { self.finalDrainReceived = YES; [self stopWithReason:safe[@"reason"]]; }
    [self notifyChanged]; reply(@{@"active":@(self.active)}, nil);
}
- (void)removeOwnedScript {
    WKUserContentController *content = self.contentController;
    if (content && self.handlerName.length) {
        @try { if (@available(iOS 14.0, *)) [content removeScriptMessageHandlerForName:self.handlerName contentWorld:WKContentWorld.pageWorld]; }
        @catch (__unused NSException *exception) { [self.nativeGaps addObject:@"handler_removal_failed"]; }
    }
    if (content && self.ownedScript) {
        @try {
            NSArray *scripts = content.userScripts; BOOL found = NO; NSMutableArray *keep = [NSMutableArray array];
            for (WKUserScript *script in scripts) { if (script == self.ownedScript) found = YES; else [keep addObject:script]; }
            // WebKit has no remove-one-user-script API. Snapshot and restore
            // all other objects synchronously on the main thread, in order.
            if (found) { [content removeAllUserScripts]; for (WKUserScript *script in keep) [content addUserScript:script]; }
        } @catch (__unused NSException *exception) { [self.nativeGaps addObject:@"script_removal_failed"]; }
    }
    self.receiver.owner = nil; self.receiver = nil; self.ownedScript = nil; self.contentController = nil;
}
- (void)stopWithReason:(NSString *)reason {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self stopWithReason:reason]; }); return; }
    if (!self.active) return;
    if ([reason isEqual:@"background"]) reason = @"application_inactive";
    NSArray *nativeReasons = @[@"unsupported_host", @"application_inactive", @"unsupported_webkit_api", @"document_start_timeout", @"native_checkpoint_error", @"game_context_changed", @"webview_changed", @"early_script_missing", @"early_script_invalid", @"content_controller_unavailable", @"script_install_failed", @"controller_dismissed", @"transport_timeout", @"native_report_limit", @"export", @"explicit_stop", @"context_changed"];
    self.reason = STEChoice(reason, nativeReasons) ?: STEChoice(reason, STEReasons()) ?: @"explicit_stop";
    self.active = NO; self.state = @"stopped"; self.stoppedAt = STENow();
    [self.timer invalidate]; self.timer = nil; [self restoreHooks]; [self removeOwnedScript];
    // The injected code has its own 3 s lease. Without evaluateJavaScript the
    // native stop cannot synchronously drain/restore page wrappers; report it.
    if (self.helloReceived && !self.finalDrainReceived) [self.nativeGaps addObject:@"undrained_tail_possible"];
    [self notifyChanged];
}
- (NSDictionary *)snapshotReport {
    if (!NSThread.isMainThread) return @{@"version":@1, @"error":@"main_thread_required"};
    NSTimeInterval end = self.active ? STENow() : (self.stoppedAt ?: STENow());
    BOOL hooksInstalled = self.hooks.count == 2; for (STEHook *h in self.hooks) hooksInstalled &= h.installed;
    BOOL finalDrainConfirmed = self.finalDrainReceived && [self.latest[@"counters"][@"bytesQueued"] isEqual:@0] && [self.latest[@"counters"][@"dropped"] isEqual:@0] && !self.omittedEvents && !self.sequenceGaps;
    NSDictionary *native = @{@"hooksInstalled":@(hooksInstalled), @"hooksPrepared":@(self.hooksPrepared), @"scriptInstalled":@(self.scriptInstalled), @"helloReceived":@(self.helloReceived), @"loadCheckpoint":@(self.loadCheckpoint), @"setupCheckpoint":@(self.setupCheckpoint), @"pollingPreparation":@(self.pollingPreparation), @"receivedMessages":@(self.receivedMessages), @"rejectedMessages":@(self.rejectedMessages), @"nativeOmittedEvents":@(self.omittedEvents), @"sequenceGaps":@(self.sequenceGaps), @"events":@(self.eventCount), @"reportBytes":@(self.reportBytes), @"finalDrainReceived":@(self.finalDrainReceived), @"finalDrainConfirmed":@(finalDrainConfirmed), @"undrainedTailMayBeLost":(self.helloReceived && !finalDrainConfirmed ? @YES : @NO), @"gaps":[self.nativeGaps.allObjects sortedArrayUsingSelector:@selector(compare:)]};
    NSDictionary *report = @{@"version":@1, @"gameType":@2007, @"requested":@(self.requested), @"active":@(self.active), @"status":self.state ?: @"idle", @"reason":self.reason ?: @"not_requested", @"lastArmFailure":self.lastArmFailure ?: @"none", @"generation":@(self.generation), @"documentGeneration":@(self.helloReceived ? 1 : 0), @"durationLimitMs":@90000, @"armedWaitLimitMs":@120000, @"finalDrainGraceMs":@1500, @"armElapsedMs":@(self.armedAt ? (NSUInteger)MAX(0.0, (end - self.armedAt) * 1000) : 0), @"captureElapsedMs":@(self.startedAt ? (NSUInteger)MIN(90000.0, MAX(0.0, (end - self.startedAt) * 1000)) : 0), @"native":native, @"liveColors":[self.colorFeed snapshot], @"latest":self.latest ?: @{}, @"samples":[self.samples copy] ?: @[]};
    // Build a detached JSON object so callers cannot mutate retained evidence.
    NSData *data = STEBoundedJSON(report, STEReportLimit);
    if (!data) return @{@"version":@1, @"gameType":@2007, @"requested":@(self.requested), @"status":@"error", @"reason":@"native_export_limit", @"generation":@(self.generation), @"documentGeneration":@(self.helloReceived ? 1 : 0), @"latest":@{}, @"native":native, @"samples":@[]};
    return [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
}
@end

#endif // ST_CARD_GAME_FEATURE_ENABLED

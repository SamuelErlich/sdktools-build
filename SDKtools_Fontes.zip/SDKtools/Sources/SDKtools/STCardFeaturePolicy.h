#ifndef SDKTOOLS_ST_CARD_FEATURE_POLICY_H
#define SDKTOOLS_ST_CARD_FEATURE_POLICY_H

// V3.19.7: explicit owner-requested reactivation for native gameType 2007.
// This is a build policy, never a preference, exported flag or runtime toggle.
// Archived card sources remain for a later explicit reactivation/review.
// Alpaca/gameType 60 and generic game identification are independent of it.
#ifndef ST_CARD_GAME_FEATURE_ENABLED
#define ST_CARD_GAME_FEATURE_ENABLED 1
#endif

#endif

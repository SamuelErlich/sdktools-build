#ifndef SDKTOOLS_ST_CARD_FEATURE_POLICY_H
#define SDKTOOLS_ST_CARD_FEATURE_POLICY_H

// V3.13: Ah, minha carta (native gameType 2007) is paused by the owner.
// This is a build policy, never a preference, exported flag or runtime toggle.
// Archived card sources remain for a later explicit reactivation/review.
// Alpaca/gameType 60 and generic game identification are independent of it.
#define ST_CARD_GAME_FEATURE_ENABLED 0

#endif

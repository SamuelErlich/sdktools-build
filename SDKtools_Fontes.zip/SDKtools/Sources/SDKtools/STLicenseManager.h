#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSNotificationName const STLicenseDidChangeNotification;
FOUNDATION_EXPORT BOOL STLicenseAllowsFeatures(void);

/// Main-thread licensing. Only an online verified session grants capabilities.
@interface STLicenseManager : NSObject
+ (instancetype)shared;
@property(nonatomic,readonly) BOOL authorized;
@property(nonatomic,readonly) BOOL busy;
@property(nonatomic,readonly) BOOL savedKeyAvailable;
@property(nonatomic,copy,readonly) NSString *statusKey;
@property(nonatomic,copy,readonly,nullable) NSDate *expiry;
- (void)start;
- (void)resume;
- (void)activateKey:(NSString *)key;
- (void)forgetKey;
@end
NS_ASSUME_NONNULL_END

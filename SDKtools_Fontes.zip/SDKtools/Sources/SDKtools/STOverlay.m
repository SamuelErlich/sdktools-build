#import "STOverlay.h"
#import "STRecorder.h"
#import "STCardEarlyCapture.h"
#import "STBilliardsRuntime.h"
#import "STBrandTheme.h"
#import "STClientContext.h"
#import <ReplayKit/ReplayKit.h>
#import <QuartzCore/QuartzCore.h>

static UIColor *STOrange(void) { return STBrandColor(0xFF6A1F); }
static UIColor *STMuted(void) { return STBrandColor(0xA08F80); }
static void STSetLabelText(UILabel *label, NSString *text) {
    NSString *value = text ?: @"";
    if (![label.text isEqualToString:value]) label.text = value;
}
static void STSetButtonTitle(UIButton *button, NSString *title) {
    if (![button titleForState:UIControlStateNormal] || ![[button titleForState:UIControlStateNormal] isEqualToString:title])
        [button setTitle:title forState:UIControlStateNormal];
}

// VoiceOver adjusts whole layers, matching the five steps used by touch.
@interface STLayerDepthSlider : UISlider
@end

@implementation STLayerDepthSlider
- (void)accessibilityIncrement {
    float next = MIN(self.maximumValue, (float)((NSInteger)(self.value + 0.5f) + 1));
    if (next == self.value) return;
    [self setValue:next animated:NO];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}
- (void)accessibilityDecrement {
    float next = MAX(self.minimumValue, (float)((NSInteger)(self.value + 0.5f) - 1));
    if (next == self.value) return;
    [self setValue:next animated:NO];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}
@end

// Brand-sized track with a full 44 pt touch target and native accessibility.
@interface STClientSwitch : UISwitch @end
@implementation STClientSwitch
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    (void)event; return CGRectContainsPoint(CGRectInset(self.bounds,-4,-11),point);
}
@end

typedef NS_ENUM(NSUInteger, STVideoState) {
    STVideoIdle, STVideoStarting, STVideoRecording, STVideoStopping
};

@class STOverlayController;
@class STReplaySessionDelegate;

@interface STOverlay () <RPPreviewViewControllerDelegate>
@property (nonatomic, strong) STOverlayWindow *window;
@property (nonatomic, strong) STOverlayController *controller;
@property (nonatomic, strong) NSTimer *statusTimer;
@property (nonatomic, copy) NSString *notice;
@property (nonatomic) NSTimeInterval noticeExpires;
@property (nonatomic) STVideoState videoState;
@property (nonatomic) NSUInteger videoGeneration;
@property (nonatomic) NSTimeInterval videoStarted;
@property (nonatomic) BOOL stopWhenStarted;
@property (nonatomic) BOOL ownsReplayKit;
@property (nonatomic) BOOL previousMicrophoneEnabled;
@property (nonatomic) BOOL previousCameraEnabled;
@property (nonatomic, weak) id<RPScreenRecorderDelegate> previousReplayDelegate;
@property (nonatomic, strong, nullable) STReplaySessionDelegate *replayDelegate;
@property (nonatomic, copy, nullable) NSString *videoCaptureSessionIdentifier;
@property (nonatomic, copy, nullable) NSString *pendingStopReason;
@property (nonatomic, strong, nullable) RPPreviewViewController *pendingPreview;
@property (nonatomic, strong, nullable) NSURL *pendingSourceExportURL;
@property (nonatomic) BOOL pendingSourceExportIsBilliards;
- (void)refresh;
- (void)startCapture;
- (void)detectNewGame;
- (void)confirmNewGame;
- (void)openLeftPower;
- (void)openCenterPower;
- (void)openRightPower;
- (void)confirmPower;
- (void)performPowerSlot:(NSString *)slot command:(NSString *)command;
- (void)toggleAutoplay;
- (void)toggleTurbo;
- (void)toggleExtendedPlanning;
- (void)toggleAutoPowers;
- (void)traceCardEntry;
- (void)toggleCardHints;
- (void)sampleCardMenuNow;
- (void)toggleBilliards;
- (void)toggleBilliardsAim;
- (void)toggleBilliardsAuto;
- (void)exportBilliardsLive;
- (void)toggleXray;
- (void)toggleDiagnostic;
- (void)changeXrayDepth;
- (void)openWarehouse;
- (void)traceReturn;
- (void)stopCapture;
- (void)markAlpaca;
- (void)markMatch;
- (void)exportReport;
- (void)exportGameSources;
- (void)exportBilliardsResources;
- (void)presentPendingSourceExport;
- (void)toggleVideo;
- (void)showNotice:(NSString *)notice;
- (void)stopAllWithReason:(NSString *)reason;
- (void)stopVideo;
- (void)markVideoEndWithError:(nullable NSError *)error;
- (void)finishVideoWithPreview:(nullable RPPreviewViewController *)preview;
- (void)presentPendingPreview;
- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)recorder preview:(nullable RPPreviewViewController *)preview error:(nullable NSError *)error;
- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation;
@end

/// A new delegate object binds callbacks to each recording generation. Reading
/// the current generation when an old callback arrives would not be sufficient.
@interface STReplaySessionDelegate : NSObject <RPScreenRecorderDelegate>
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic) NSUInteger generation;
@end

@implementation STReplaySessionDelegate
- (void)screenRecorder:(RPScreenRecorder *)recorder didStopRecordingWithPreviewViewController:(RPPreviewViewController *)preview error:(NSError *)error {
    [self.owner replayDidStopWithGeneration:self.generation recorder:recorder preview:preview error:error];
}
- (void)screenRecorderDidChangeAvailability:(RPScreenRecorder *)recorder {
    [self.owner replayAvailabilityChangedWithGeneration:self.generation];
}
@end

@interface STOverlayController : UIViewController
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic, strong) UIButton *bubble;
@property (nonatomic, strong) UIView *recordingDot;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UIScrollView *panelScroll;
@property (nonatomic, strong) UIView *alpacaModule;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UILabel *noticeLabel;
@property (nonatomic, strong) UILabel *collapsedNoticeLabel;
@property (nonatomic, strong) UIButton *returnActionButton;
@property (nonatomic, strong) UIButton *leftPowerButton;
@property (nonatomic, strong) UIButton *rightPowerButton;
@property (nonatomic, strong) UIButton *confirmPowerButton;
@property (nonatomic, strong) UIStackView *powerControls;
@property (nonatomic, strong) UIButton *autoplayButton;
@property (nonatomic, strong) UILabel *autoplayLabel;
@property (nonatomic, strong) UISwitch *xraySwitch;
@property (nonatomic, strong) UISwitch *turboSwitch;
@property (nonatomic, strong) UISwitch *planningSwitch;
@property (nonatomic, strong) UISwitch *powersSwitch;
@property (nonatomic, strong) UIButton *diagnosticButton;
@property (nonatomic, strong) UILabel *diagnosticLabel;
@property (nonatomic, strong) UIButton *identifyGameButton;
@property (nonatomic, strong) UIView *confirmGameContainer;
@property (nonatomic, strong) UIButton *confirmGameButton;
@property (nonatomic, strong) UILabel *gameDetectionLabel;
@property (nonatomic, strong) UILabel *xrayLabel;
@property (nonatomic, strong) UIView *xrayDepthContainer;
@property (nonatomic, strong) STLayerDepthSlider *xrayDepthSlider;
@property (nonatomic, strong) UILabel *xrayDepthLabel;
@property (nonatomic) NSInteger lastRequestedXrayDepth;
@property (nonatomic, strong) UIButton *warehouseButton;
@property (nonatomic, strong) UIButton *warehouseTestButton;
@property (nonatomic, strong) UIButton *warehouseTestCancelButton;
@property (nonatomic, strong) UILabel *warehouseTestLabel;
@property (nonatomic, strong) UIButton *dataButton;
@property (nonatomic, strong) UIStackView *dataStack;
@property (nonatomic, strong) UIView *dataContainer;
@property (nonatomic, strong) UIButton *exportButton;
@property (nonatomic, strong) UIButton *billiardsResourceExportButton;
@property (nonatomic, strong) UIButton *billiardsTrainerButton;
@property (nonatomic, strong) UIButton *billiardsLiveExportButton;
@property (nonatomic, strong) UIButton *cardEarlyButton;
@property (nonatomic, strong) UIButton *cardHintsButton;
@property (nonatomic, strong) UIButton *cardSampleButton;
@property (nonatomic, strong) UIButton *cardExportButton;
@property (nonatomic, strong) UILabel *cardStatusLabel;
@property (nonatomic, strong) UILabel *cardColorsLabel;
@property (nonatomic, strong) UILabel *billiardsStatusLabel;
@property (nonatomic, strong) NSMutableArray<UIView *> *moduleCards;
@property (nonatomic, strong) NSMutableArray<UIView *> *moduleBodies;
@property (nonatomic, strong) NSMutableArray<UILabel *> *moduleBadges;
@property (nonatomic, strong) NSMutableArray<UIImageView *> *moduleIcons;
@property (nonatomic, strong) NSMutableArray<UILabel *> *moduleHints;
@property (nonatomic, strong) NSMutableArray<NSNumber *> *moduleGames;
@property (nonatomic, strong) UIButton *billiardsAimButton;
@property (nonatomic, strong) UIButton *billiardsAutoButton;
@property (nonatomic, strong) UIStackView *clientContentStack;
@property (nonatomic, strong) NSLayoutConstraint *clientHeaderHeight;
@property (nonatomic) STClientGame activeGame;
@property (nonatomic) CFTimeInterval lastContextCheck;
@property (nonatomic) BOOL refreshingContext;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *,NSURL *> *clientLinkURLs;
@property (nonatomic) BOOL expanded;
@property (nonatomic) BOOL dataExpanded;
@property (nonatomic) BOOL dragging;
@property (nonatomic) BOOL bubbleOnRight;
@property (nonatomic) CGFloat bubbleVerticalFraction;
- (BOOL)acceptsPoint:(CGPoint)point;
- (void)refresh;

- (UIStackView *)stackInCollapsibleContainer:(UIView *)container;
@end

@implementation STOverlayWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    STOverlayController *controller = (STOverlayController *)self.rootViewController;
    if (![controller isKindOfClass:STOverlayController.class]) return nil;
    // Presented share sheets and ReplayKit previews need their complete bounds.
    if (!controller.presentedViewController && ![controller acceptsPoint:point]) return nil;
    return [super hitTest:point withEvent:event];
}
// This window deliberately does not override canBecomeKeyWindow or call
// makeKeyAndVisible. The host game retains keyboard, scene and input ownership.
@end

@implementation STOverlayController

- (UILabel *)label:(NSString *)text size:(CGFloat)size weight:(UIFontWeight)weight color:(UIColor *)color {
    UILabel *label=[UILabel new]; label.text=text; label.textColor=color; label.numberOfLines=0;
    label.font=STBrandFont(weight>=UIFontWeightSemibold?@"Geist-SemiBold":(weight>=UIFontWeightMedium?@"Geist-Medium":@"Geist-Regular"),size,UIFontTextStyleBody);
    label.adjustsFontForContentSizeCategory=YES;
    return label;
}
- (UIStackView *)verticalStack {
    UIStackView *stack=[UIStackView new]; stack.axis=UILayoutConstraintAxisVertical; stack.spacing=12; return stack;
}
- (UIView *)separator {
    UIView *line=[UIView new]; line.backgroundColor=STBrandColor(0x2E241C);
    [line.heightAnchor constraintEqualToConstant:1].active=YES; return line;
}
- (UIButton *)button:(NSString *)title symbol:(NSString *)symbol action:(SEL)action primary:(BOOL)primary {
    UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setImage:STBrandImage(symbol,YES) forState:UIControlStateNormal];
    [button setTitleColor:STBrandColor(primary?0x0F0B08:0xFFF1E0) forState:UIControlStateNormal];
    button.tintColor=STBrandColor(primary?0x0F0B08:0xA08F80);
    button.backgroundColor=STBrandColor(primary?0xFF6A1F:0x211913);
    button.layer.cornerRadius=10; button.layer.borderWidth=primary?0:1; button.layer.borderColor=STBrandColor(0x2E241C).CGColor;
    button.titleLabel.font=STBrandFont(@"Geist-Medium",14,UIFontTextStyleBody);
    button.titleLabel.adjustsFontForContentSizeCategory=YES; button.titleLabel.numberOfLines=0;
    button.titleLabel.textAlignment=NSTextAlignmentCenter;
    button.contentEdgeInsets=UIEdgeInsetsMake(12,12,12,12); button.imageEdgeInsets=UIEdgeInsetsMake(0,-6,0,6);
    [button.heightAnchor constraintGreaterThanOrEqualToConstant:44].active=YES;
    if (action) [button addTarget:self.owner action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}
- (UISwitch *)addSwitch:(NSString *)title action:(SEL)action toStack:(UIStackView *)stack {
    UILabel *label=[self label:title size:14 weight:UIFontWeightMedium color:STBrandColor(0xFFF1E0)];
    UISwitch *control=[STClientSwitch new]; control.transform=CGAffineTransformMakeScale(0.86,0.86);
    control.onTintColor=STOrange(); control.thumbTintColor=STBrandColor(0xFFF1E0); control.accessibilityLabel=title;
    [control addTarget:self.owner action:action forControlEvents:UIControlEventValueChanged];
    UIStackView *row=[[UIStackView alloc] initWithArrangedSubviews:@[label,control]];
    row.alignment=UIStackViewAlignmentCenter; row.spacing=12; [row.heightAnchor constraintGreaterThanOrEqualToConstant:44].active=YES;
    [stack addArrangedSubview:row]; return control;
}
- (UIView *)module:(NSString *)title icon:(NSString *)icon game:(STClientGame)game body:(UIStackView *)body {
    UIView *card=[UIView new]; card.layer.cornerRadius=20; card.layer.borderWidth=1; card.clipsToBounds=YES;
    UIStackView *stack=[self verticalStack]; stack.translatesAutoresizingMaskIntoConstraints=NO;
    [card addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:card.topAnchor constant:16],
        [stack.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16],
        [stack.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-16],
        [stack.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-16]]];
    UIImageView *image=[[UIImageView alloc] initWithImage:STBrandImage(icon,YES)]; image.contentMode=UIViewContentModeScaleAspectFit;
    [image.widthAnchor constraintEqualToConstant:24].active=YES; [image.heightAnchor constraintEqualToConstant:24].active=YES;
    UILabel *name=[self label:title size:16 weight:UIFontWeightSemibold color:STBrandColor(0xFFF1E0)];
    UILabel *badge=[self label:@"Closed" size:12 weight:UIFontWeightMedium color:STMuted()];
    badge.font=STBrandFont(@"Martian-Mono-SemiCondensed-Medium",11,UIFontTextStyleCaption1);
    [badge setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    UIStackView *header=[[UIStackView alloc] initWithArrangedSubviews:@[image,name,badge]];
    header.axis=UILayoutConstraintAxisHorizontal; header.alignment=UIStackViewAlignmentCenter; header.spacing=10;
    [header.heightAnchor constraintGreaterThanOrEqualToConstant:28].active=YES;
    [stack addArrangedSubview:header];
    UILabel *hint=[self label:@"Open this minigame to unlock its controls." size:12 weight:UIFontWeightRegular color:STMuted()];
    [stack addArrangedSubview:hint];
    UIView *wrapper=[UIView new]; wrapper.clipsToBounds=YES; body.translatesAutoresizingMaskIntoConstraints=NO;
    [wrapper addSubview:body];
    NSLayoutConstraint *bottom=[body.bottomAnchor constraintEqualToAnchor:wrapper.bottomAnchor]; bottom.priority=999;
    [NSLayoutConstraint activateConstraints:@[[body.topAnchor constraintEqualToAnchor:wrapper.topAnchor],
        [body.leadingAnchor constraintEqualToAnchor:wrapper.leadingAnchor], [body.trailingAnchor constraintEqualToAnchor:wrapper.trailingAnchor],bottom]];
    [stack addArrangedSubview:wrapper];
    [self.moduleCards addObject:card]; [self.moduleBodies addObject:wrapper]; [self.moduleBadges addObject:badge];
    [self.moduleIcons addObject:image]; [self.moduleHints addObject:hint]; [self.moduleGames addObject:@(game)];
    return card;
}
- (void)loadView {
    STRegisterBrandFonts();
    self.view=[[UIView alloc] initWithFrame:UIScreen.mainScreen.bounds]; self.view.backgroundColor=UIColor.clearColor;
    self.bubbleOnRight=YES; self.bubbleVerticalFraction=0.18;
    self.moduleCards=[NSMutableArray array]; self.moduleBodies=[NSMutableArray array]; self.moduleBadges=[NSMutableArray array];
    self.moduleIcons=[NSMutableArray array]; self.moduleHints=[NSMutableArray array]; self.moduleGames=[NSMutableArray array];
    self.bubble=[UIButton buttonWithType:UIButtonTypeCustom]; self.bubble.backgroundColor=STBrandColor(0x17110D);
    self.bubble.layer.cornerRadius=16; self.bubble.layer.borderWidth=1; self.bubble.layer.borderColor=STBrandColor(0x2E241C).CGColor;
    UIImageView *symbol=[[UIImageView alloc] initWithImage:STBrandImage(@"symbol",NO)]; symbol.contentMode=UIViewContentModeScaleAspectFit;
    symbol.frame=CGRectMake(16.33,14,23.33,28); symbol.userInteractionEnabled=NO; [self.bubble addSubview:symbol];
    self.bubble.accessibilityLabel=@"Open SDK Client"; self.bubble.accessibilityHint=@"Drag to move the menu.";
    [self.bubble addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [self.bubble addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveBubble:)]];
    [self.view addSubview:self.bubble];
    self.recordingDot=[[UIView alloc] initWithFrame:CGRectMake(44,4,6,6)]; self.recordingDot.layer.cornerRadius=3;
    self.recordingDot.backgroundColor=STOrange(); self.recordingDot.hidden=YES; self.recordingDot.userInteractionEnabled=NO;
    [self.bubble addSubview:self.recordingDot];
    self.collapsedNoticeLabel=[self label:@"" size:12 weight:UIFontWeightMedium color:STBrandColor(0xFFF1E0)];
    self.collapsedNoticeLabel.backgroundColor=STBrandColor(0x17110D); self.collapsedNoticeLabel.textAlignment=NSTextAlignmentCenter;
    self.collapsedNoticeLabel.numberOfLines=3; self.collapsedNoticeLabel.layer.cornerRadius=10;
    self.collapsedNoticeLabel.clipsToBounds=YES; self.collapsedNoticeLabel.userInteractionEnabled=NO; self.collapsedNoticeLabel.hidden=YES;
    [self.view addSubview:self.collapsedNoticeLabel];
    self.panel=[UIView new]; self.panel.backgroundColor=STBrandColor(0x17110D); self.panel.layer.cornerRadius=24;
    self.panel.layer.borderWidth=1; self.panel.layer.borderColor=STBrandColor(0x2E241C).CGColor; self.panel.clipsToBounds=YES; self.panel.hidden=YES;
    [self.view addSubview:self.panel];
    UIView *header=[UIView new]; header.translatesAutoresizingMaskIntoConstraints=NO; [self.panel addSubview:header];
    UIImageView *logo=[[UIImageView alloc] initWithImage:STBrandImage(@"logo",NO)]; logo.contentMode=UIViewContentModeScaleAspectFit;
    logo.isAccessibilityElement=YES; logo.accessibilityLabel=@"SDK Client"; logo.translatesAutoresizingMaskIntoConstraints=NO; [header addSubview:logo];
    UIButton *close=[UIButton buttonWithType:UIButtonTypeSystem]; [close setImage:STBrandImage(@"close",YES) forState:UIControlStateNormal];
    close.tintColor=STMuted(); close.accessibilityLabel=@"Close SDK Client"; close.translatesAutoresizingMaskIntoConstraints=NO;
    [close addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside]; [header addSubview:close];
    [NSLayoutConstraint activateConstraints:@[[header.topAnchor constraintEqualToAnchor:self.panel.topAnchor],
        [header.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor], [header.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor],
        (self.clientHeaderHeight=[header.heightAnchor constraintEqualToConstant:80]), [logo.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:24],
        [logo.centerYAnchor constraintEqualToAnchor:header.centerYAnchor], [logo.widthAnchor constraintEqualToConstant:96],
        [logo.heightAnchor constraintEqualToConstant:33.1], [close.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-12],
        [close.centerYAnchor constraintEqualToAnchor:header.centerYAnchor], [close.widthAnchor constraintEqualToConstant:44], [close.heightAnchor constraintEqualToConstant:44]]];
    UIView *line=[self separator]; line.translatesAutoresizingMaskIntoConstraints=NO; [self.panel addSubview:line];
    self.panelScroll=[UIScrollView new]; self.panelScroll.translatesAutoresizingMaskIntoConstraints=NO;
    self.panelScroll.indicatorStyle=UIScrollViewIndicatorStyleWhite; self.panelScroll.contentInsetAdjustmentBehavior=UIScrollViewContentInsetAdjustmentNever;
    [self.panel addSubview:self.panelScroll];
    [NSLayoutConstraint activateConstraints:@[[line.topAnchor constraintEqualToAnchor:header.bottomAnchor], [line.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor],
        [line.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor], [self.panelScroll.topAnchor constraintEqualToAnchor:line.bottomAnchor],
        [self.panelScroll.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor], [self.panelScroll.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor],
        [self.panelScroll.bottomAnchor constraintEqualToAnchor:self.panel.bottomAnchor]]];
    UIStackView *content=[self verticalStack]; self.clientContentStack=content; content.spacing=12; content.translatesAutoresizingMaskIntoConstraints=NO; [self.panelScroll addSubview:content];
    [NSLayoutConstraint activateConstraints:@[[content.topAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.topAnchor constant:20],
        [content.leadingAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.leadingAnchor constant:16],
        [content.trailingAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.trailingAnchor constant:-16],
        [content.bottomAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.bottomAnchor constant:-20],
        [content.widthAnchor constraintEqualToAnchor:self.panelScroll.frameLayoutGuide.widthAnchor constant:-32]]];
    UILabel *title=[self label:@"Your game. Your edge." size:26 weight:UIFontWeightSemibold color:STBrandColor(0xFFF1E0)];
    title.font=STBrandFont(@"Syne-Bold",26,UIFontTextStyleTitle2); [content addArrangedSubview:title];
    self.statusLabel=[self label:@"Open a minigame to get started." size:13 weight:UIFontWeightRegular color:STMuted()];
    self.statusLabel.accessibilityTraits|=UIAccessibilityTraitUpdatesFrequently; [content addArrangedSubview:self.statusLabel];
    [content setCustomSpacing:20 afterView:self.statusLabel];
    UIStackView *alpaca=[self verticalStack];
    self.autoplayButton=[self button:@"Start autoplay" symbol:@"movement" action:@selector(toggleAutoplay) primary:YES]; [alpaca addArrangedSubview:self.autoplayButton];
    self.autoplayLabel=[self label:@"Plays available moves and follows the current mission." size:12 weight:UIFontWeightRegular color:STMuted()]; [alpaca addArrangedSubview:self.autoplayLabel];
    self.turboSwitch=[self addSwitch:@"Turbo" action:@selector(toggleTurbo) toStack:alpaca];
    self.planningSwitch=[self addSwitch:@"Extended planning" action:@selector(toggleExtendedPlanning) toStack:alpaca];
    self.powersSwitch=[self addSwitch:@"Use owned powers" action:@selector(toggleAutoPowers) toStack:alpaca];
    self.powersSwitch.accessibilityHint=@"Allows autoplay to consume your existing powers when needed. Never purchases powers.";
    [alpaca addArrangedSubview:[self label:@"Owned powers can be consumed by autoplay when enabled." size:12 weight:UIFontWeightRegular color:STMuted()]];
    [alpaca addArrangedSubview:[self separator]];
    UILabel *xrayTitle=[self label:@"X-ray" size:14 weight:UIFontWeightMedium color:STBrandColor(0xFFF1E0)];
    self.xraySwitch=[STClientSwitch new]; self.xraySwitch.transform=CGAffineTransformMakeScale(0.86,0.86); self.xraySwitch.onTintColor=STOrange(); self.xraySwitch.thumbTintColor=STBrandColor(0xFFF1E0);
    self.xraySwitch.accessibilityLabel=@"X-ray"; [self.xraySwitch addTarget:self.owner action:@selector(toggleXray) forControlEvents:UIControlEventValueChanged];
    UIStackView *xrayRow=[[UIStackView alloc] initWithArrangedSubviews:@[xrayTitle,self.xraySwitch]];
    xrayRow.alignment=UIStackViewAlignmentCenter; xrayRow.spacing=12; [xrayRow.heightAnchor constraintGreaterThanOrEqualToConstant:44].active=YES; [alpaca addArrangedSubview:xrayRow];
    self.xrayLabel=[self label:@"See the layers below the board." size:12 weight:UIFontWeightRegular color:STMuted()]; [alpaca addArrangedSubview:self.xrayLabel];
    self.xrayDepthContainer=[UIView new]; UIStackView *depth=[self stackInCollapsibleContainer:self.xrayDepthContainer];
    self.xrayDepthLabel=[self label:@"Depth · 1 layer" size:12 weight:UIFontWeightMedium color:STBrandColor(0xFFB547)];
    self.xrayDepthLabel.font=STBrandFont(@"Martian-Mono-SemiCondensed-Medium",12,UIFontTextStyleCaption1); [depth addArrangedSubview:self.xrayDepthLabel];
    self.xrayDepthSlider=[STLayerDepthSlider new]; self.xrayDepthSlider.minimumValue=1; self.xrayDepthSlider.maximumValue=5;
    self.xrayDepthSlider.minimumTrackTintColor=STOrange(); self.xrayDepthSlider.maximumTrackTintColor=STBrandColor(0x2E241C);
    self.xrayDepthSlider.thumbTintColor=STBrandColor(0xFFF1E0); self.xrayDepthSlider.accessibilityLabel=@"Layers below";
    [self.xrayDepthSlider.heightAnchor constraintGreaterThanOrEqualToConstant:44].active=YES;
    [self.xrayDepthSlider addTarget:self.owner action:@selector(changeXrayDepth) forControlEvents:UIControlEventValueChanged]; [depth addArrangedSubview:self.xrayDepthSlider];
    [alpaca addArrangedSubview:self.xrayDepthContainer];
    [alpaca addArrangedSubview:[self separator]];
    [alpaca addArrangedSubview:[self label:@"Original powers" size:12 weight:UIFontWeightSemibold color:STMuted()]];
    self.leftPowerButton=[self button:@"Left" symbol:@"keybind" action:@selector(openLeftPower) primary:NO];
    self.returnActionButton=[self button:@"Center" symbol:@"reset" action:@selector(openCenterPower) primary:NO];
    self.rightPowerButton=[self button:@"Right" symbol:@"duplicate" action:@selector(openRightPower) primary:NO];
    self.powerControls=[[UIStackView alloc] initWithArrangedSubviews:@[self.leftPowerButton,self.returnActionButton,self.rightPowerButton]];
    self.powerControls.spacing=8; self.powerControls.distribution=UIStackViewDistributionFillEqually; [alpaca addArrangedSubview:self.powerControls];
    self.confirmPowerButton=[self button:@"Confirm open power" symbol:@"check" action:@selector(confirmPower) primary:NO]; [alpaca addArrangedSubview:self.confirmPowerButton];
    self.warehouseButton=[self button:@"Open warehouse" symbol:@"configs" action:@selector(openWarehouse) primary:NO]; [alpaca addArrangedSubview:self.warehouseButton];
    self.alpacaModule=[self module:@"Crazy Alpaca" icon:@"movement" game:STClientGameAlpaca body:alpaca]; [content addArrangedSubview:self.alpacaModule];
    UIStackView *cards=[self verticalStack];
    self.cardHintsButton=[self button:@"Enable card markers" symbol:@"player" action:@selector(toggleCardHints) primary:YES]; [cards addArrangedSubview:self.cardHintsButton];
    self.cardStatusLabel=[self label:@"Read the card information available in this match." size:12 weight:UIFontWeightRegular color:STMuted()]; [cards addArrangedSubview:self.cardStatusLabel];
    [cards addArrangedSubview:[self label:@"Unknown cards stay marked as ?. Unreceived colors stay marked as X." size:12 weight:UIFontWeightRegular color:STMuted()]];
    [content addArrangedSubview:[self module:@"Cards" icon:@"duplicate" game:STClientGameCards body:cards]];
    UIStackView *billiards=[self verticalStack];
    self.billiardsTrainerButton=[self button:@"Enable aim guide" symbol:@"render" action:@selector(toggleBilliards) primary:YES]; [billiards addArrangedSubview:self.billiardsTrainerButton];
    self.billiardsStatusLabel=[self label:@"A visual guide for the current table." size:12 weight:UIFontWeightRegular color:STMuted()]; [billiards addArrangedSubview:self.billiardsStatusLabel];
    [billiards addArrangedSubview:[self label:@"Prediction is approximate. Shots remain under your control." size:12 weight:UIFontWeightRegular color:STMuted()]];
    [billiards addArrangedSubview:[self separator]];
    self.billiardsAimButton=[self button:@"Aim assist · no shot" symbol:@"combat" action:@selector(toggleBilliardsAim) primary:NO];
    self.billiardsAutoButton=[self button:@"Autoplay · current match" symbol:@"movement" action:@selector(toggleBilliardsAuto) primary:NO];
    [billiards addArrangedSubview:self.billiardsAimButton]; [billiards addArrangedSubview:self.billiardsAutoButton];
    [billiards addArrangedSubview:[self label:@"Aim adjusts the direction. Autoplay takes shots only in this match. Manual input or reopening the menu pauses automation." size:12 weight:UIFontWeightRegular color:STMuted()]];
    [content addArrangedSubview:[self module:@"Billiards" icon:@"combat" game:STClientGameBilliards body:billiards]];
    self.noticeLabel=[self label:@"" size:13 weight:UIFontWeightMedium color:STBrandColor(0xFFB547)]; self.noticeLabel.hidden=YES; [content addArrangedSubview:self.noticeLabel];
    [content addArrangedSubview:[self separator]];
    [content addArrangedSubview:[self label:@"Stay connected" size:12 weight:UIFontWeightSemibold color:STMuted()]];
    NSURL *linksURL=[[NSBundle bundleForClass:STOverlay.class] URLForResource:@"client-links" withExtension:@"json" subdirectory:@"Brand"];
    NSData *linksData=linksURL?[NSData dataWithContentsOfURL:linksURL]:nil;
    id config=linksData?[NSJSONSerialization JSONObjectWithData:linksData options:0 error:NULL]:nil;
    NSArray *links=[config isKindOfClass:NSDictionary.class] && [config[@"links"] isKindOfClass:NSArray.class]?config[@"links"]:@[];
    self.clientLinkURLs=[NSMutableDictionary dictionary];
    for (id item in [links subarrayWithRange:NSMakeRange(0,MIN((NSUInteger)4,links.count))]) {
        if (![item isKindOfClass:NSDictionary.class] || ![item[@"title"] isKindOfClass:NSString.class]) continue;
        NSString *title=item[@"title"], *urlText=[item[@"url"] isKindOfClass:NSString.class]?item[@"url"]:nil;
        NSURL *url=urlText?[NSURL URLWithString:urlText]:nil;
        BOOL live=[url.scheme.lowercaseString isEqual:@"https"] && url.host.length>0;
        NSString *display=live?title:[title stringByAppendingString:@" · Coming soon"];
        UIButton *link=[self button:display symbol:[title isEqual:@"YouTube"]?@"youtube":@"world" action:NULL primary:NO];
        link.enabled=live; link.alpha=live?1:0.6; link.accessibilityLabel=display;
        if(live) { self.clientLinkURLs[@(link.hash)]=url; [link addTarget:self action:@selector(openClientLink:) forControlEvents:UIControlEventTouchUpInside]; }
        [content addArrangedSubview:link];
    }
    UILabel *signature=[self label:@"Forged hot. Played cold." size:14 weight:UIFontWeightSemibold color:STBrandColor(0xD9C9B6)];
    signature.font=STBrandFont(@"Syne-SemiBold",14,UIFontTextStyleFootnote); [content addArrangedSubview:signature];
    UILabel *version=[self label:@"SDK Client · 3.22.0" size:11 weight:UIFontWeightRegular color:STMuted()];
    version.font=STBrandFont(@"Martian-Mono-SemiCondensed-Regular",11,UIFontTextStyleCaption2); [content addArrangedSubview:version];
}
- (void)openClientLink:(UIButton *)button {
    NSURL *url=self.clientLinkURLs[@(button.hash)];
    if (url) [UIApplication.sharedApplication openURL:url options:@{} completionHandler:nil];
}
- (UIStackView *)stackInCollapsibleContainer:(UIView *)container {
    container.clipsToBounds=YES; UIStackView *stack=[self verticalStack]; stack.translatesAutoresizingMaskIntoConstraints=NO; [container addSubview:stack];
    NSLayoutConstraint *bottom=[stack.bottomAnchor constraintEqualToAnchor:container.bottomAnchor]; bottom.priority=999;
    [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:container.topAnchor], [stack.leadingAnchor constraintEqualToAnchor:container.leadingAnchor],
        [stack.trailingAnchor constraintEqualToAnchor:container.trailingAnchor],bottom]]; return stack;
}
- (void)viewDidLoad { [super viewDidLoad]; [self.owner refresh]; }
- (void)traitCollectionDidChange:(UITraitCollection *)previous {
    [super traitCollectionDidChange:previous]; [self.view setNeedsLayout];
}
- (CGRect)usableBounds { return CGRectInset(UIEdgeInsetsInsetRect(self.view.bounds,self.view.safeAreaInsets),8,8); }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews]; CGRect safe=[self usableBounds];
    self.clientHeaderHeight.constant=safe.size.height<440?68:80;
    if (!self.dragging) self.bubble.frame=CGRectMake(self.bubbleOnRight?CGRectGetMaxX(safe)-56:CGRectGetMinX(safe),CGRectGetMinY(safe)+self.bubbleVerticalFraction*MAX(0,safe.size.height-56),56,56);
    CGFloat width=MIN(440,MAX(0,safe.size.width)), height=MIN(760,MAX(0,safe.size.height-64));
    self.panel.frame=CGRectMake(self.bubbleOnRight?CGRectGetMaxX(safe)-width:CGRectGetMinX(safe),CGRectGetMinY(safe)+64,width,height);
    self.powerControls.axis=(width<360 || UIContentSizeCategoryIsAccessibilityCategory(self.traitCollection.preferredContentSizeCategory))?UILayoutConstraintAxisVertical:UILayoutConstraintAxisHorizontal;
    CGFloat w=MIN(280,safe.size.width); CGSize size=[self.collapsedNoticeLabel sizeThatFits:CGSizeMake(MAX(1,w-24),CGFLOAT_MAX)];
    CGFloat h=MIN(MAX(44,size.height+16),safe.size.height), y=CGRectGetMaxY(self.bubble.frame)+8;
    if (y+h>CGRectGetMaxY(safe)) y=CGRectGetMinY(self.bubble.frame)-h-8;
    y=MAX(CGRectGetMinY(safe),MIN(y,CGRectGetMaxY(safe)-h));
    self.collapsedNoticeLabel.frame=CGRectMake(self.bubbleOnRight?CGRectGetMaxX(safe)-w:CGRectGetMinX(safe),y,w,h);
}
- (BOOL)acceptsPoint:(CGPoint)point {
    CGPoint local=[self.view convertPoint:point fromView:self.view.window];
    return CGRectContainsPoint(self.bubble.frame,local) || (self.expanded && CGRectContainsPoint(self.panel.frame,local));
}
- (void)togglePanel {
    if (!self.expanded) [STBilliardsRuntime.shared pauseAutomationWithReason:@"menu_opened"];
    self.expanded=!self.expanded; self.panel.hidden=!self.expanded; self.view.accessibilityViewIsModal=self.expanded;
    self.bubble.accessibilityLabel=self.expanded?@"Close SDK Client":@"Open SDK Client";
    self.lastContextCheck=0; [self.owner refresh];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,self.expanded?self.statusLabel:self.bubble);
}
- (BOOL)accessibilityPerformEscape { if (!self.expanded) return NO; [self togglePanel]; return YES; }
- (void)moveBubble:(UIPanGestureRecognizer *)gesture {
    CGRect safe=[self usableBounds]; if (gesture.state==UIGestureRecognizerStateBegan) self.dragging=YES;
    CGPoint delta=[gesture translationInView:self.view], center=self.bubble.center;
    center.x=MIN(MAX(center.x+delta.x,CGRectGetMinX(safe)+28),CGRectGetMaxX(safe)-28);
    center.y=MIN(MAX(center.y+delta.y,CGRectGetMinY(safe)+28),CGRectGetMaxY(safe)-28);
    self.bubble.center=center; [gesture setTranslation:CGPointZero inView:self.view];
    if (gesture.state==UIGestureRecognizerStateEnded || gesture.state==UIGestureRecognizerStateCancelled || gesture.state==UIGestureRecognizerStateFailed) {
        self.dragging=NO; self.bubbleOnRight=center.x>=CGRectGetMidX(safe);
        CGFloat travel=safe.size.height-56; self.bubbleVerticalFraction=travel>0?MIN(1,MAX(0,(center.y-28-CGRectGetMinY(safe))/travel)):0; [self.view setNeedsLayout];
    }
}
- (void)refresh {
    if (!self.isViewLoaded || self.refreshingContext) return;
    self.refreshingContext=YES;
    STRecorder *r=STRecorder.shared; STBilliardsRuntime *b=STBilliardsRuntime.shared;
    CFTimeInterval now=CACurrentMediaTime();
    if (UIApplication.sharedApplication.applicationState!=UIApplicationStateActive) self.activeGame=STClientGameNone;
    else if (!self.lastContextCheck || now-self.lastContextCheck>=0.75) { self.activeGame=STClientCurrentGame(self.view.window); self.lastContextCheck=now; }
    // Stop existing tools when their game leaves the foreground. Never clear an
    // uncertain physical action; STRecorder retains its existing completion guard.
    if (self.activeGame!=STClientGameAlpaca) { if(r.autoplayEnabled)[r pauseAutoplayWithReason:@"game_context_changed"]; if(r.xrayEnabled)[r setXrayEnabled:NO]; }
    if (self.activeGame!=STClientGameCards && r.cardHintsEnabled) [r setCardHintsEnabled:NO];
    if (self.activeGame!=STClientGameBilliards && b.enabled) [b stopWithReason:@"game_context_changed"];
    BOOL busy=r.recording || r.cardEarlyActive || r.detectedGameDetectionActive || r.sourceExportBusy || r.returnActionBusy || r.autoplayBusy ||
        self.presentedViewController || self.owner.pendingPreview || self.owner.videoState!=STVideoIdle;
    BOOL alpaca=STClientCanModify(self.activeGame,STClientGameAlpaca), cards=STClientCanModify(self.activeGame,STClientGameCards), billiards=STClientCanModify(self.activeGame,STClientGameBilliards);
    [self.turboSwitch setOn:r.turboEnabled animated:NO]; [self.planningSwitch setOn:r.extendedPlanning animated:NO]; [self.powersSwitch setOn:r.powersEnabled animated:NO];
    for (UISwitch *control in @[self.turboSwitch,self.planningSwitch,self.powersSwitch]) control.enabled=alpaca && !r.recording && !r.sourceExportBusy && !self.presentedViewController;
    self.billiardsAimButton.enabled=self.billiardsAutoButton.enabled=billiards && !busy && !r.cardHintsEnabled && !r.cardHintsBusy;
    STSetButtonTitle(self.billiardsAimButton,b.automationMode==1?@"Pause aim assist":@"Aim assist · no shot");
    STSetButtonTitle(self.billiardsAutoButton,b.automationMode==2?@"Pause billiards autoplay":@"Autoplay · current match");
    self.autoplayButton.enabled=alpaca && !r.warehouseTestActive && (r.autoplayEnabled || (!busy && !b.enabled && !r.cardHintsBusy));
    STSetButtonTitle(self.autoplayButton,r.autoplayEnabled?@"Pause autoplay":(r.autoplayBusy?@"Waiting for move…":@"Start autoplay"));
    STSetLabelText(self.autoplayLabel,r.autoplayEnabled || r.autoplayBusy?r.autoplayStatusText:@"Plays available moves and follows the current mission.");
    self.xraySwitch.on=r.xrayEnabled; self.xraySwitch.enabled=alpaca && (r.xrayEnabled || (!busy && !b.enabled));
    STSetLabelText(self.xrayLabel,r.xrayEnabled?r.xrayStatusText:@"See the layers below the board.");
    self.xrayDepthContainer.hidden=!r.xrayEnabled; self.xrayDepthSlider.enabled=alpaca && r.xrayEnabled && !busy;
    if (!self.xrayDepthSlider.isTracking) {
        NSInteger depth=MAX(1,MIN(5,r.xrayDepth)); self.xrayDepthSlider.value=(float)depth; self.lastRequestedXrayDepth=depth;
        STSetLabelText(self.xrayDepthLabel,[NSString stringWithFormat:@"Depth · %ld %@",(long)depth,depth==1?@"layer":@"layers"]);
        self.xrayDepthSlider.accessibilityValue=[NSString stringWithFormat:@"%ld %@",(long)depth,depth==1?@"layer":@"layers"];
    }
    for (UIButton *button in @[self.leftPowerButton,self.returnActionButton,self.rightPowerButton,self.confirmPowerButton,self.warehouseButton]) button.enabled=alpaca && !busy && !b.enabled && !r.warehouseTestActive;
    self.cardHintsButton.enabled=cards && (r.cardHintsEnabled || (!busy && !b.enabled && !r.cardHintsBusy));
    STSetButtonTitle(self.cardHintsButton,r.cardHintsEnabled?@"Disable card markers":@"Enable card markers");
    STSetLabelText(self.cardStatusLabel,r.cardHintsEnabled?r.cardHintsStatusText:@"Read the card information available in this match.");
    self.billiardsTrainerButton.enabled=billiards && (b.enabled || (!busy && !r.cardHintsEnabled && !r.cardHintsBusy));
    STSetButtonTitle(self.billiardsTrainerButton,b.enabled?@"Disable aim guide":@"Enable aim guide");
    STSetLabelText(self.billiardsStatusLabel,b.enabled?b.statusText:@"A visual guide for the current table.");
    for (UIButton *button in @[self.autoplayButton,self.leftPowerButton,self.returnActionButton,self.rightPowerButton,self.confirmPowerButton,self.warehouseButton,self.cardHintsButton,self.billiardsTrainerButton,self.billiardsAimButton,self.billiardsAutoButton]) button.alpha=button.enabled?1:0.4;
    NSString *activeName=@"";
    for (NSUInteger i=0;i<self.moduleCards.count;i++) {
        BOOL active=self.activeGame==(STClientGame)self.moduleGames[i].integerValue;
        UIView *card=self.moduleCards[i]; card.backgroundColor=STBrandColor(active?0x1C1511:0x0F0B08);
        card.layer.borderColor=STBrandColor(active?0xFF6A1F:0x2E241C).CGColor;
        self.moduleBodies[i].hidden=!active; self.moduleHints[i].hidden=active;
        self.moduleBadges[i].text=active?@"Active":@"Closed"; self.moduleBadges[i].textColor=STBrandColor(active?0xFFB547:0xA08F80);
        self.moduleIcons[i].tintColor=STBrandColor(active?0xFF6A1F:0x5A4A3E); card.alpha=active?1:0.6;
        if(active) {
            activeName=self.activeGame==STClientGameAlpaca?@"Crazy Alpaca":(cards?@"Cards":@"Billiards");
            if ([self.clientContentStack.arrangedSubviews indexOfObject:card]!=2) {
                [self.clientContentStack removeArrangedSubview:card]; [self.clientContentStack insertArrangedSubview:card atIndex:2];
                self.panelScroll.contentOffset=CGPointZero;
            }
        }
    }
    STSetLabelText(self.statusLabel,activeName.length?[NSString stringWithFormat:@"%@ is open. Your controls are ready.",activeName]:@"Open a minigame to unlock its controls.");
    NSString *notice=self.owner.noticeExpires>now?self.owner.notice:@"";
    STSetLabelText(self.noticeLabel,notice); self.noticeLabel.hidden=!notice.length;
    self.recordingDot.hidden=!r.autoplayEnabled && !r.xrayEnabled && !r.cardHintsEnabled && !b.enabled;
    NSString *compact=notice.length?notice:(r.autoplayEnabled?@"SDK · Autoplay on":(b.enabled?@"SDK · Aim guide on":(r.cardHintsEnabled?@"SDK · Card markers on":(r.xrayEnabled?@"SDK · X-ray on":@""))));
    STSetLabelText(self.collapsedNoticeLabel,compact); self.collapsedNoticeLabel.hidden=self.expanded || !compact.length;
    self.refreshingContext=NO; [self.view setNeedsLayout];
}
@end


@implementation STOverlay
// Fresh identity at every modifying action prevents a tap racing a game switch.
- (BOOL)clientAllowsGame:(STClientGame)game {
    if (STClientCanModify(STClientCurrentGame(self.window),game)) return YES;
    [self showNotice:@"Open the matching minigame before using this control."];
    self.controller.lastContextCheck=0; [self refresh]; return NO;
}


+ (instancetype)shared {
    static STOverlay *instance;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ instance = [STOverlay new]; });
    return instance;
}

- (instancetype)init {
    if ((self = [super init])) {
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        [center addObserver:self selector:@selector(becameActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        [center addObserver:self selector:@selector(becameActive:) name:UISceneDidActivateNotification object:nil];
        [center addObserver:self selector:@selector(enteredBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(sceneEnteredBackground:) name:UISceneDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(recorderChanged:) name:STRecorderDidChangeNotification object:nil];
        [center addObserver:self selector:@selector(recorderChanged:) name:STBilliardsRuntimeDidChangeNotification object:nil];
    }
    return self;
}

- (UIWindowScene *)foregroundScene {
    UIWindowScene *fallback = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        UIWindowScene *windowScene = (UIWindowScene *)scene;
        for (UIWindow *window in windowScene.windows) {
            if (![window isKindOfClass:STOverlayWindow.class] && window.isKeyWindow) return windowScene;
        }
        if (!fallback) fallback = windowScene;
    }
    return fallback;
}

- (void)installIfNeeded {
    NSAssert(NSThread.isMainThread, @"SDKtools UI requires the main thread");
    UIWindowScene *scene = [self foregroundScene];
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    // Unity hosts may still use the UIApplication lifecycle without a scene
    // manifest. In that case connectedScenes is empty and a scene-only overlay
    // would never appear. Require a real host window in either lifecycle.
    UIWindow *hostWindow = nil;
    NSArray<UIWindow *> *windows = scene ? scene.windows : UIApplication.sharedApplication.windows;
    for (UIWindow *candidate in windows) {
        if ([candidate isKindOfClass:STOverlayWindow.class] || candidate.hidden || !candidate.rootViewController) continue;
        if (candidate.isKeyWindow) { hostWindow = candidate; break; }
        if (!hostWindow && candidate.windowLevel == UIWindowLevelNormal) hostWindow = candidate;
    }
    if (!hostWindow) return;
    if (!self.window) {
        self.controller = [STOverlayController new];
        self.controller.owner = self;
        self.window = scene ? [[STOverlayWindow alloc] initWithWindowScene:scene] : [[STOverlayWindow alloc] initWithFrame:hostWindow.bounds];
        self.window.rootViewController = self.controller;
        self.window.windowLevel = UIWindowLevelNormal + 5;
        self.window.backgroundColor = UIColor.clearColor;
        self.window.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
        self.window.accessibilityIdentifier = @"SDKtools.overlay";
    } else if (scene && self.window.windowScene != scene && !self.controller.presentedViewController) {
        self.window.hidden = YES;
        self.window.windowScene = scene;
    }
    self.window.frame = scene ? scene.coordinateSpace.bounds : hostWindow.screen.bounds;
    self.window.hidden = NO;
    [self refresh];
}

- (void)becameActive:(NSNotification *)notification {
    [self installIfNeeded];
    [self presentPendingPreview];
    [self presentPendingSourceExport];
}

- (void)sceneEnteredBackground:(NSNotification *)notification {
    if (notification.object == self.window.windowScene) [self enteredBackground:notification];
}

- (void)enteredBackground:(NSNotification *)notification {
    self.window.hidden = YES;
    [self.statusTimer invalidate];
    self.statusTimer = nil;
    [self stopAllWithReason:@"background"];
}

- (void)recorderChanged:(NSNotification *)notification {
    // Limits and background handling can stop JSON independently. Do not leave
    // a screen recording running after its paired capture has ended.
    if (!STRecorder.shared.recording && self.ownsReplayKit) {
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    }
    [self refresh];
}

- (void)refresh {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self refresh]; }); return; }
    [self.controller refresh];
    BOOL active = UIApplication.sharedApplication.applicationState == UIApplicationStateActive;
    BOOL needed = active && (self.controller.expanded || STRecorder.shared.autoplayEnabled || STRecorder.shared.autoplayBusy || STRecorder.shared.xrayEnabled || STBilliardsRuntime.shared.enabled || STRecorder.shared.cardEarlyActive || STRecorder.shared.cardHintsEnabled || STRecorder.shared.detectedGameDetectionActive || STRecorder.shared.sourceExportBusy || (self.controller.expanded && (STRecorder.shared.recording || self.videoState != STVideoIdle || STRecorder.shared.autoplayEnabled || STRecorder.shared.autoplayBusy || STRecorder.shared.xrayEnabled)) || self.noticeExpires > CACurrentMediaTime());
    if (needed && !self.statusTimer) {
        __weak typeof(self) weakSelf = self;
        self.statusTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer *timer) { [weakSelf refresh]; }];
    } else if (!needed && self.statusTimer) {
        [self.statusTimer invalidate];
        self.statusTimer = nil;
    }
}

- (void)showNotice:(NSString *)notice {
    self.notice = notice;
    self.noticeExpires = CACurrentMediaTime() + 8;
    [self refresh];
}

- (void)startCapture {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar antes de iniciar outra captura."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (STRecorder.shared.recording) return;
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize ou salve o vídeo anterior antes de iniciar outra captura."];
        return;
    }
    [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura não iniciou. Tente novamente com o app aberto."];
        return;
    }
    [self showNotice:@"Diagnóstico iniciado. Jogue um pouco; depois pare e exporte em Suporte."];
}

- (void)detectNewGame {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar antes de identificar outro jogo."]; return; }
    STRecorder *recorder = STRecorder.shared;
    if (recorder.detectedGameDetectionActive) {
        [recorder cancelNewGameDetection]; [self showNotice:@"Detecção cancelada."]; return;
    }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController || ![recorder beginNewGameDetection]) {
        [self showNotice:@"Finalize a captura ou ação em andamento antes de detectar outro jogo."]; return;
    }
    [self showNotice:@"Abra outro minigame. Depois volte a Suporte e toque Capturar jogo identificado."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)confirmNewGame {
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize o vídeo ou a janela aberta antes de confirmar a captura."]; return;
    }
    if (![STRecorder.shared confirmNewGameCapture]) {
        [self showNotice:@"O jogo mudou ou ainda está carregando. Aguarde a nova detecção."]; return;
    }
    [self showNotice:@"JSON iniciado. Jogue por 30–60 s; depois toque Parar e Exportar relatório."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)traceReturn {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (STRecorder.shared.returnTraceActive) {
        [self showNotice:@"Rastreamento já ativo. Use os poderes e o armazém originais, depois pare e exporte."];
        return;
    }
    if (!STRecorder.shared.recording) [self startCapture];
    if (!STRecorder.shared.recording) return;
    if (![STRecorder.shared beginReturnTrace]) {
        [self showNotice:@"Não foi possível iniciar o rastreamento nesta captura. Pare e exporte o relatório atual."];
        return;
    }
    [self showNotice:@"Rastreamento ativo. Use os poderes e o armazém no jogo. Depois pare a captura e exporte o JSON."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)traceCardEntry {
    STRecorder *recorder=STRecorder.shared;
    if (recorder.cardEarlyActive) { [recorder stopCardEarlyCapture]; [self showNotice:@"Captura encerrada. Exporte o JSON de Cartas."]; return; }
    if (STBilliardsRuntime.shared.enabled || self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Finalize o bilhar, vídeo ou janela aberta antes de capturar Cartas."]; return; }
    if (![recorder beginCardEarlyCapture]) { [self showNotice:recorder.cardEarlyStatusText]; return; }
    [self showNotice:@"Captura armada. Entre em Ah, minha carta e jogue por 90 s."];
    if (self.controller.expanded) [self.controller togglePanel];
}
- (void)toggleCardHints {
    STRecorder *recorder=STRecorder.shared;
    if (!recorder.cardHintsEnabled && ![self clientAllowsGame:STClientGameCards]) return;
    if (recorder.cardEarlyActive || STBilliardsRuntime.shared.enabled) { [self showNotice:@"Pare a captura ou o bilhar antes de ativar os marcadores."]; return; }
    if (self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Finalize o vídeo ou a janela aberta antes de usar Cartas."]; return; }
    if (![recorder setCardHintsEnabled:!recorder.cardHintsEnabled]) [self showNotice:recorder.cardHintsStatusText];
    else [self showNotice:recorder.cardHintsEnabled?@"Etiquetas: total de cartas e ? desconhecidas. X = cor não recebida; círculos não são a quantidade da mão.":@"Marcadores desativados."];
    [self refresh];
}

- (void)sampleCardMenuNow {
    STRecorder *recorder=STRecorder.shared;
    if (recorder.cardEarlyActive || STBilliardsRuntime.shared.enabled || self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Pare a captura, bilhar, vídeo ou janela aberta antes de injetar o amostrador."]; return;
    }
    if (![recorder injectCardColorsAndReadRoot]) [self showNotice:recorder.cardHintsStatusText];
    else [self showNotice:@"Amostragem local solicitada. Confira hooks e cores por mão no menu. Não envia comandos ao jogo."];
    [self refresh];
}

- (void)toggleBilliards {
    STBilliardsRuntime *runtime=STBilliardsRuntime.shared;
    if (runtime.enabled) { [runtime stopWithReason:@"user"]; [self refresh]; return; }
    if (![self clientAllowsGame:STClientGameBilliards]) return;
    if (STRecorder.shared.cardEarlyActive || STRecorder.shared.cardHintsEnabled || STRecorder.shared.cardHintsBusy) { [self showNotice:@"Pare a captura ou os marcadores de Cartas antes de ativar o bilhar."]; return; }
    if (self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Feche a janela ou a captura aberta antes de ativar o bilhar."]; return;
    }
    NSError *error=nil;
    if (![runtime startInWindow:self.window error:&error]) {
        [self showNotice:error.localizedDescription ?: @"Não foi possível iniciar a leitura do bilhar."]; return;
    }
    self.noticeExpires=0;
    if (self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)toggleBilliardsAim {
    STBilliardsRuntime *r=STBilliardsRuntime.shared;
    if (r.automationMode==1) { [r pauseAutomationWithReason:@"user"]; [self refresh]; return; }
    if (![self clientAllowsGame:STClientGameBilliards]) return;
    if (!r.enabled) [self toggleBilliards];
    if (!r.enabled) return;
    r.automationMode=1;
    if (self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}
- (void)toggleBilliardsAuto {
    STBilliardsRuntime *r=STBilliardsRuntime.shared;
    if (r.automationMode==2) { [r pauseAutomationWithReason:@"user"]; [self refresh]; return; }
    if (![self clientAllowsGame:STClientGameBilliards]) return;
    if (!r.enabled) [self toggleBilliards];
    if (!r.enabled) return;
    r.automationMode=2;
    if (self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}
- (void)exportBilliardsLive {
    if (STRecorder.shared.sourceExportBusy || self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize a exportação ou janela aberta antes de compartilhar."]; return;
    }
    NSError *error=nil;
    NSURL *url=[STBilliardsRuntime.shared exportReportWithError:&error];
    if (!url) { [self showNotice:error.localizedDescription ?: @"Não foi possível gerar o diagnóstico do bilhar."]; return; }
    self.pendingSourceExportURL=url;
    self.pendingSourceExportIsBilliards=YES;
    [self presentPendingSourceExport];
    [self refresh];
}

- (void)toggleTurbo {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
 [STRecorder.shared setTurboEnabled:self.controller.turboSwitch.isOn]; [self refresh]; }
- (void)toggleExtendedPlanning {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
 [STRecorder.shared setExtendedPlanning:self.controller.planningSwitch.isOn]; [self refresh]; }
- (void)toggleAutoPowers {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
 [STRecorder.shared setPowersEnabled:self.controller.powersSwitch.isOn]; [self refresh]; }

- (void)toggleAutoplay {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (STRecorder.shared.autoplayEnabled) {
        [STRecorder.shared pauseAutoplayWithReason:@"user"];
        [self showNotice:STRecorder.shared.autoplayStatusText];
        return;
    }
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
    if ([STRecorder.shared startAutoplay]) {
        self.noticeExpires = 0;
        if (self.controller.expanded) [self.controller togglePanel];
    } else {
        [self showNotice:STRecorder.shared.autoplayBusy ? @"Aguarde a ação já enviada terminar antes de retomar." :
            (STRecorder.shared.recording ? @"Pare a captura antes de iniciar o autoplay." : @"Entre na partida e feche as janelas do jogo antes de iniciar.")];
    }
    [self refresh];
}

- (void)toggleXray {
    if (self.controller.xraySwitch.isOn && ![self clientAllowsGame:STClientGameAlpaca]) { self.controller.xraySwitch.on=STRecorder.shared.xrayEnabled; return; }
    if (STBilliardsRuntime.shared.enabled) { self.controller.xraySwitch.on=NO; [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    [STRecorder.shared setXrayEnabled:self.controller.xraySwitch.isOn];
    [self refresh];
}

- (void)toggleDiagnostic {
    STRecorder *recorder = STRecorder.shared;
    if (recorder.recording || recorder.detectedGameDetectionActive || self.videoState != STVideoIdle) {
        [self stopCapture];
        [self refresh];
        return;
    }
    [self startCapture];
    if (recorder.recording && self.controller.expanded) [self.controller togglePanel];
}

- (void)changeXrayDepth {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;

    STLayerDepthSlider *slider = self.controller.xrayDepthSlider;
    NSInteger depth = MAX(1, MIN(5, (NSInteger)(slider.value + 0.5f)));
    [slider setValue:(float)depth animated:NO];
    STSetLabelText(self.controller.xrayDepthLabel, [NSString stringWithFormat:@"Camadas abaixo: %ld", (long)depth]);
    slider.accessibilityValue = [NSString stringWithFormat:depth == 1 ? @"%ld camada abaixo" : @"%ld camadas abaixo", (long)depth];
    // Continuous touch events within the same step do not trigger new reads.
    if (depth == self.controller.lastRequestedXrayDepth) return;
    self.controller.lastRequestedXrayDepth = depth;
    [STRecorder.shared setXrayDepth:depth];
}

- (void)runWarehouseTest:(NSString *)command {
    if (STBilliardsRuntime.shared.enabled || STRecorder.shared.sourceExportBusy || self.controller.presentedViewController || self.pendingPreview ||
        self.videoState==STVideoStarting || self.videoState==STVideoStopping) { [self showNotice:@"Feche janelas e desative o Bilhar antes do teste."]; return; }
    __weak STOverlay *weakSelf=self;
    BOOL submitted=[STRecorder.shared performWarehouseTestCommand:command update:^(NSDictionary *result) {
        STOverlay *s=weakSelf;if (!s) return;if ([result[@"status"] isEqual:@"blocked"] && !STRecorder.shared.warehouseTestStarted)
            [s showNotice:@"Teste não armado. Pause o autoplay, aguarde a jogada e confira seu slot vazio bloqueado."];
        else [s showNotice:STRecorder.shared.warehouseTestStatusText];[s refresh];
    }];
    if (submitted && [command isEqual:@"arm"] && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}
- (void)testWarehouseLock { [self runWarehouseTest:STRecorder.shared.warehouseTestStarted ? @"poll" : @"arm"]; }
- (void)cancelWarehouseTest { [self runWarehouseTest:@"cancel"]; }

- (void)openWarehouse {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;

    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.controller.presentedViewController || self.pendingPreview ||
        self.videoState == STVideoStarting || self.videoState == STVideoStopping) {
        [self showNotice:@"Feche a janela aberta e aguarde o vídeo terminar de iniciar ou salvar."];
        return;
    }
    [self showNotice:@"Conferindo seu armazém…"];
    __weak STOverlay *weakSelf = self;
    BOOL accepted = [STRecorder.shared openOwnWarehouseWithUpdate:^(NSDictionary *result) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        NSString *status = result[@"status"], *reason = result[@"reason"];
        if ([status isEqualToString:@"original_event_dispatched"]) {
            [strongSelf showNotice:@"Pedido enviado. Confira a seleção do armazém no jogo."];
        } else if ([status isEqualToString:@"dispatch_uncertain"]) {
            [strongSelf showNotice:@"A resposta ainda não foi confirmada. Aguarde e confira o armazém no jogo."];
        } else if ([reason isEqualToString:@"selection_already_open"]) {
            [strongSelf showNotice:@"A seleção do armazém já está aberta."];
        } else if ([reason isEqualToString:@"own_slot_locked"]) {
            [strongSelf showNotice:@"Seu espaço está bloqueado nesta partida. O jogo precisa liberá-lo."];
        } else if ([reason isEqualToString:@"own_slot_occupied"]) {
            [strongSelf showNotice:@"Seu espaço já está ocupado. Confira as cartas no armazém."];
        } else if ([reason isEqualToString:@"owner_unknown"]) {
            [strongSelf showNotice:@"Não foi possível identificar seu armazém nesta tela."];
        } else if ([@[@"return_action_pending", @"physical_operation_pending", @"cleanup_pending"] containsObject:reason]) {
            [strongSelf showNotice:@"Uma ação ainda está em andamento. Aguarde antes de tentar novamente."];
        } else if ([@[@"native_modal_visible", @"modal_visible", @"native_view_obscured", @"ambiguous_window_overlap"] containsObject:reason]) {
            [strongSelf showNotice:@"Feche a janela aberta no jogo antes de abrir o armazém."];
        } else {
            [strongSelf showNotice:@"Seu armazém não está disponível nesta tela. Entre na partida e tente novamente."];
        }
        [strongSelf refresh];
    }];
    if (accepted && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)openLeftPower { [self performPowerSlot:@"left" command:@"open"]; }
- (void)openCenterPower { [self performPowerSlot:@"center" command:@"open"]; }
- (void)openRightPower { [self performPowerSlot:@"right" command:@"open"]; }
- (void)confirmPower { [self performPowerSlot:@"current" command:@"confirm"]; }

- (void)performPowerSlot:(NSString *)slot command:(NSString *)command {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;

    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.controller.presentedViewController || self.pendingPreview ||
        self.videoState == STVideoStarting || self.videoState == STVideoStopping) {
        [self showNotice:@"Feche a janela aberta e aguarde o vídeo terminar de iniciar ou salvar."];
        return;
    }
    [self showNotice:[command isEqual:@"confirm"] ? @"Conferindo o poder aberto e o estoque…" : @"Abrindo o poder original…"];
    __weak STOverlay *weakSelf = self;
    BOOL accepted = [STRecorder.shared performOriginalPowerAtSlot:slot command:command update:^(NSDictionary *result) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        NSString *status = result[@"status"], *reason = result[@"reason"];
        if ([status isEqualToString:@"original_event_dispatched"]) {
            [strongSelf showNotice:[command isEqual:@"confirm"] ? @"Uso solicitado ao jogo. Aguarde o efeito antes de usar novamente." : @"Confira o efeito e confirme Usar item no jogo."];
        } else if ([status isEqualToString:@"dispatch_uncertain"]) {
            [strongSelf showNotice:[result[@"physicalPending"] boolValue] ?
                @"Resposta incerta. Aguarde o jogo; o poder permanece bloqueado enquanto essa chamada não terminar." :
                @"A resposta não pôde ser confirmada. Confira a tela do jogo antes de tocar novamente."];
        } else if ([@[@"return_action_pending", @"physical_operation_pending", @"cleanup_pending"] containsObject:reason]) {
            [strongSelf showNotice:@"Há uma leitura ou ação em andamento. Aguarde antes de tocar novamente."];
        } else if ([@[@"native_modal_visible", @"modal_visible", @"native_view_obscured", @"ambiguous_window_overlap"] containsObject:reason]) {
            [strongSelf showNotice:@"Já existe uma janela aberta. Resolva ou feche essa janela no jogo."];
        } else if ([@[@"disabled_control", @"button_unavailable", @"stock_unavailable", @"stock_empty"] containsObject:reason]) {
            [strongSelf showNotice:@"O poder não está disponível ou está sem estoque. Confira a partida."];
        } else if ([@[@"confirmation_unavailable", @"confirmation_ambiguous", @"prop_mismatch"] containsObject:reason]) {
            [strongSelf showNotice:@"Abra o poder desejado e confira sua confirmação no jogo. A janela pode fechar após alguns segundos."];
        } else if ([@[@"unsupported_application", @"engine_version", @"game_type_abi_mismatch"] containsObject:reason]) {
            [strongSelf showNotice:@"Esta versão do jogo não corresponde ao controle verificado para US 6.6.2."];
        } else {
            [strongSelf showNotice:@"Não foi possível identificar esse poder nesta tela. Entre na partida e exporte um relatório se continuar."];
        }
        [strongSelf refresh];
    }];
    // Only an accepted request can collapse the panel. Rejections keep the
    // explanation and controls visible. No synthetic tap or automatic retry.
    if (accepted && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)stopCapture { [self stopAllWithReason:@"user"]; }

- (void)stopAllWithReason:(NSString *)reason {
    [STRecorder.shared stopCardEarlyCaptureWithReason:reason];
    [STRecorder.shared setCardHintsEnabled:NO];
    [STBilliardsRuntime.shared stopWithReason:reason];
    if (STRecorder.shared.detectedGameDetectionActive) {
        [STRecorder.shared cancelNewGameDetection];
        [self showNotice:@"Detecção cancelada."]; return;
    }
    if (self.videoState != STVideoIdle) {
        self.pendingStopReason = reason;
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    } else {
        [STRecorder.shared stopRecordingWithReason:reason];
        [self showNotice:@"Captura encerrada. O relatório está pronto para exportar."];
    }
}

- (void)markAlpaca {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"crazyAlpacaEntered" details:@{@"source": @"user"}];
    [self showNotice:@"Entrada no Crazy Alpaca marcada no relatório."];
}

- (void)markMatch {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"matchStarted" details:@{@"source": @"user"}];
    [self showNotice:@"Início da partida marcado no relatório."];
}

- (void)exportReport {
    [STBilliardsRuntime.shared stopWithReason:@"export"];
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.pendingPreview) { [self showNotice:@"Salve ou feche a prévia do vídeo antes de exportar."]; [self presentPendingPreview]; return; }
    if (STRecorder.shared.recording || STRecorder.shared.cardEarlyActive || self.videoState != STVideoIdle) { [self showNotice:@"Pare a captura antes de exportar o relatório."]; return; }
    if (self.controller.presentedViewController) { [self showNotice:@"Feche a janela aberta antes de exportar."]; return; }
    NSError *error = nil;
    NSURL *url = [STRecorder.shared writeReportWithError:&error];
    if (!url) {
        if ([error.domain isEqualToString:@"SDKtools.Recorder"] && error.code == 1)
            [self showNotice:@"Ainda não há dados. Use uma ferramenta ou toque Suporte → Iniciar diagnóstico antes de exportar."];
        else
            [self showNotice:@"Não foi possível gerar o JSON. Confira o espaço livre e tente novamente."];
        return;
    }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    share.popoverPresentationController.sourceView = self.controller.exportButton;
    share.popoverPresentationController.sourceRect = self.controller.exportButton.bounds;
    __weak typeof(self) weakSelf = self;
    share.completionWithItemsHandler = ^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:completed ? @"Relatório compartilhado." : @"Relatório disponível para exportar novamente."];
            [weakSelf presentPendingPreview];
        });
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)exportGameSources {
    [STBilliardsRuntime.shared stopWithReason:@"export"];
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"A exportação do código já está em andamento."]; return; }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Pare o vídeo e feche a prévia ou janela aberta antes de exportar o código."];
        return;
    }
    if (self.pendingSourceExportURL) { [self presentPendingSourceExport]; return; }
    [self showNotice:@"Preparando o código do jogo. Aguarde sem sair da partida."];
    __weak STOverlay *weakSelf = self;
    [STRecorder.shared exportCurrentGameSourcesWithCompletion:^(NSURL *url, NSError *error) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        if (!url.isFileURL || error) {
            [strongSelf showNotice:error.localizedDescription ?: @"Não foi possível gerar o arquivo. Abra uma partida e tente novamente."];
            [strongSelf refresh];
            return;
        }
        strongSelf.pendingSourceExportURL = url;
        strongSelf.pendingSourceExportIsBilliards = NO;
        [strongSelf showNotice:@"Código pronto. Escolha Salvar em Arquivos ou compartilhar o JSON."];
        [strongSelf presentPendingSourceExport];
        [strongSelf refresh];
    }];
    [self refresh];
}

- (void)exportBilliardsResources {
    [STBilliardsRuntime.shared stopWithReason:@"export"];
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Uma exportação já está em andamento."]; return; }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Pare o vídeo e feche a prévia ou janela aberta antes de exportar os recursos."]; return;
    }
    if (self.pendingSourceExportURL) { [self presentPendingSourceExport]; return; }
    [self showNotice:@"Preparando os recursos. Mantenha o bilhar aberto até terminar."];
    __weak STOverlay *weakSelf = self;
    [STRecorder.shared exportBilliardsResourcesWithCompletion:^(NSURL *url, NSError *error) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        if (!url.isFileURL || error) {
            [strongSelf showNotice:error.localizedDescription ?: @"Não foi possível gerar o arquivo de recursos. Tente novamente."];
            [strongSelf refresh]; return;
        }
        strongSelf.pendingSourceExportURL = url;
        strongSelf.pendingSourceExportIsBilliards = YES;
        NSUInteger exported = [STRecorder.shared.billiardsResourceExportDiagnostic[@"counts"][@"filesExported"] unsignedIntegerValue];
        [strongSelf showNotice:exported ? @"Recursos prontos. Salve em Arquivos ou compartilhe o JSON." :
            @"Diagnóstico pronto; recursos ainda não encontrados. Abra o bilhar, aguarde o carregamento e exporte novamente."];
        [strongSelf presentPendingSourceExport];
        [strongSelf refresh];
    }];
    [self refresh];
}

- (void)presentPendingSourceExport {
    if (!self.pendingSourceExportURL || STRecorder.shared.sourceExportBusy ||
        self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController ||
        UIApplication.sharedApplication.applicationState != UIApplicationStateActive || self.window.hidden) return;
    NSURL *url = self.pendingSourceExportURL;
    BOOL billiards = self.pendingSourceExportIsBilliards;
    self.pendingSourceExportURL = nil;
    self.pendingSourceExportIsBilliards = NO;
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    UIView *anchor = self.controller.bubble;
    share.popoverPresentationController.sourceView = anchor;
    share.popoverPresentationController.sourceRect = anchor.bounds;
    __weak STOverlay *weakSelf = self;
    share.completionWithItemsHandler = ^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:completed ? (billiards ? @"Arquivo do bilhar compartilhado." : @"Código do jogo compartilhado.") : @"Arquivo gerado. Você pode exportar novamente pelo menu."];
            [weakSelf presentPendingPreview];
        });
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)toggleVideo {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar antes de iniciar outra captura."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.videoState == STVideoRecording) { [self stopVideo]; return; }
    if (self.videoState != STVideoIdle) return;
    if (self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Feche ou salve a prévia anterior antes de gravar novamente."]; return; }
    RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
    if (!recorder.isAvailable || recorder.isRecording) { [self showNotice:@"A gravação de tela não está disponível agora. O JSON pode ser gravado normalmente."]; return; }
    if (recorder.delegate && recorder.delegate != self.replayDelegate) { [self showNotice:@"O app já utiliza o gravador de tela. O JSON está ativo; para vídeo, use a Central de Controle."]; return; }
    if (!STRecorder.shared.recording) [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura JSON não iniciou. O vídeo não foi aberto."];
        return;
    }
    self.videoCaptureSessionIdentifier = STRecorder.shared.captureSessionIdentifier;
    NSUInteger generation = ++self.videoGeneration;
    self.previousReplayDelegate = recorder.delegate;
    self.previousMicrophoneEnabled = recorder.isMicrophoneEnabled;
    self.previousCameraEnabled = recorder.isCameraEnabled;
    self.replayDelegate = [STReplaySessionDelegate new];
    self.replayDelegate.owner = self;
    self.replayDelegate.generation = generation;
    recorder.delegate = self.replayDelegate;
    recorder.microphoneEnabled = NO;
    recorder.cameraEnabled = NO;
    self.ownsReplayKit = YES;
    self.videoState = STVideoStarting;
    self.stopWhenStarted = NO;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [recorder startRecordingWithHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            if (error) {
                [strongSelf markVideoEndWithError:error];
                [strongSelf finishVideoWithPreview:nil];
                [strongSelf showNotice:STRecorder.shared.recording ? @"O vídeo não iniciou. O JSON continua; você também pode gravar pela Central de Controle." : @"O vídeo não iniciou. A captura foi encerrada; o JSON está disponível para exportar."];
                return;
            }
            strongSelf.videoState = STVideoRecording;
            strongSelf.videoStarted = CACurrentMediaTime();
            [STRecorder.shared markEvent:@"visualRecordingStarted" details:@{@"source": @"replaykit", @"enabled": @YES}];
            if (strongSelf.stopWhenStarted || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) [strongSelf stopVideo];
            else [strongSelf showNotice:@"Vídeo iniciado sem microfone. Feche o menu para continuar."];
        });
    }];
}

- (void)stopVideo {
    if (self.videoState != STVideoRecording || !self.ownsReplayKit) return;
    self.videoState = STVideoStopping;
    NSUInteger generation = self.videoGeneration;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [RPScreenRecorder.sharedRecorder stopRecordingWithHandler:^(RPPreviewViewController *preview, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            [strongSelf markVideoEndWithError:error];
            [strongSelf finishVideoWithPreview:preview];
            if (error) [strongSelf showNotice:@"O vídeo terminou com erro. Exporte o JSON; a prévia será exibida se estiver disponível."];
        });
    }];
}

- (void)markVideoEndWithError:(NSError *)error {
    NSTimeInterval elapsed = self.videoStarted > 0 ? MAX(0, CACurrentMediaTime() - self.videoStarted) : 0;
    if (self.videoCaptureSessionIdentifier) {
        [STRecorder.shared markVisualRecordingEndForSessionIdentifier:self.videoCaptureSessionIdentifier failed:(error != nil) durationSeconds:elapsed];
    }
}

- (void)finishVideoWithPreview:(RPPreviewViewController *)preview {
    if (self.ownsReplayKit) {
        RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
        if (recorder.delegate == self.replayDelegate) {
            recorder.delegate = self.previousReplayDelegate;
            recorder.microphoneEnabled = self.previousMicrophoneEnabled;
            recorder.cameraEnabled = self.previousCameraEnabled;
        }
    }
    self.ownsReplayKit = NO;
    self.videoState = STVideoIdle;
    self.videoStarted = 0;
    self.stopWhenStarted = NO;
    self.previousReplayDelegate = nil;
    self.replayDelegate = nil;
    self.videoCaptureSessionIdentifier = nil;
    if (self.pendingStopReason) {
        NSString *reason = self.pendingStopReason;
        self.pendingStopReason = nil;
        [STRecorder.shared stopRecordingWithReason:reason];
    }
    if (preview) {
        preview.previewControllerDelegate = self;
        if (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) {
            preview.modalPresentationStyle = UIModalPresentationPopover;
            preview.popoverPresentationController.sourceView = self.controller.bubble;
            preview.popoverPresentationController.sourceRect = self.controller.bubble.bounds;
            preview.preferredContentSize = CGSizeMake(540, 620);
        } else preview.modalPresentationStyle = UIModalPresentationFullScreen;
        self.pendingPreview = preview;
    }
    [self refresh];
    [self presentPendingPreview];
}

- (void)presentPendingPreview {
    if (!self.pendingPreview || self.controller.presentedViewController || UIApplication.sharedApplication.applicationState != UIApplicationStateActive || self.window.hidden) return;
    RPPreviewViewController *preview = self.pendingPreview;
    self.pendingPreview = nil;
    [self.controller presentViewController:preview animated:YES completion:nil];
}

- (void)previewControllerDidFinish:(RPPreviewViewController *)previewController {
    [previewController dismissViewControllerAnimated:YES completion:^{ [self showNotice:@"Vídeo encerrado. Exporte também o JSON para analisar os dois juntos."]; [self presentPendingSourceExport]; }];
}

- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)screenRecorder preview:(RPPreviewViewController *)previewViewController error:(NSError *)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.ownsReplayKit || self.videoGeneration != generation || screenRecorder.isRecording) return;
        [self markVideoEndWithError:error];
        [self finishVideoWithPreview:previewViewController];
        [self showNotice:@"A gravação de vídeo foi encerrada pelo iOS. O relatório JSON continua disponível."];
    });
}

- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation {
    dispatch_async(dispatch_get_main_queue(), ^{ if (self.videoGeneration == generation) [self refresh]; });
}
@end

#import "STOverlay.h"
#import "STRecorder.h"
#import <ReplayKit/ReplayKit.h>
#import <QuartzCore/QuartzCore.h>

static UIColor *STOrange(void) { return [UIColor colorWithRed:1 green:0.36 blue:0.12 alpha:1]; }
static UIColor *STMuted(void) { return [UIColor colorWithWhite:0.67 alpha:1]; }
static void STSetLabelText(UILabel *label, NSString *text) {
    NSString *value = text ?: @"";
    if (![label.text isEqualToString:value]) label.text = value;
}
static void STSetButtonTitle(UIButton *button, NSString *title) {
    if (![button titleForState:UIControlStateNormal] || ![[button titleForState:UIControlStateNormal] isEqualToString:title])
        [button setTitle:title forState:UIControlStateNormal];
}

// VoiceOver adjusts whole layers, matching the five steps used by touch.
@interface STLayerDepthSlider : UISlider
@end

@implementation STLayerDepthSlider
- (void)accessibilityIncrement {
    float next = MIN(self.maximumValue, (float)((NSInteger)(self.value + 0.5f) + 1));
    if (next == self.value) return;
    [self setValue:next animated:NO];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}
- (void)accessibilityDecrement {
    float next = MAX(self.minimumValue, (float)((NSInteger)(self.value + 0.5f) - 1));
    if (next == self.value) return;
    [self setValue:next animated:NO];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}
@end

typedef NS_ENUM(NSUInteger, STVideoState) {
    STVideoIdle, STVideoStarting, STVideoRecording, STVideoStopping
};

@class STOverlayController;
@class STReplaySessionDelegate;

@interface STOverlay () <RPPreviewViewControllerDelegate>
@property (nonatomic, strong) STOverlayWindow *window;
@property (nonatomic, strong) STOverlayController *controller;
@property (nonatomic, strong) NSTimer *statusTimer;
@property (nonatomic, copy) NSString *notice;
@property (nonatomic) NSTimeInterval noticeExpires;
@property (nonatomic) STVideoState videoState;
@property (nonatomic) NSUInteger videoGeneration;
@property (nonatomic) NSTimeInterval videoStarted;
@property (nonatomic) BOOL stopWhenStarted;
@property (nonatomic) BOOL ownsReplayKit;
@property (nonatomic) BOOL previousMicrophoneEnabled;
@property (nonatomic) BOOL previousCameraEnabled;
@property (nonatomic, weak) id<RPScreenRecorderDelegate> previousReplayDelegate;
@property (nonatomic, strong, nullable) STReplaySessionDelegate *replayDelegate;
@property (nonatomic, copy, nullable) NSString *videoCaptureSessionIdentifier;
@property (nonatomic, copy, nullable) NSString *pendingStopReason;
@property (nonatomic, strong, nullable) RPPreviewViewController *pendingPreview;
@property (nonatomic, strong, nullable) NSURL *pendingSourceExportURL;
- (void)refresh;
- (void)startCapture;
- (void)detectNewGame;
- (void)confirmNewGame;
- (void)openLeftPower;
- (void)openCenterPower;
- (void)openRightPower;
- (void)confirmPower;
- (void)performPowerSlot:(NSString *)slot command:(NSString *)command;
- (void)toggleAutoplay;
- (void)toggleXray;
- (void)toggleCardHints;
- (void)investigateCards;
- (void)toggleDiagnostic;
- (void)changeXrayDepth;
- (void)openWarehouse;
- (void)traceReturn;
- (void)stopCapture;
- (void)markAlpaca;
- (void)markMatch;
- (void)exportReport;
- (void)exportGameSources;
- (void)presentPendingSourceExport;
- (void)toggleVideo;
- (void)showNotice:(NSString *)notice;
- (void)stopAllWithReason:(NSString *)reason;
- (void)stopVideo;
- (void)markVideoEndWithError:(nullable NSError *)error;
- (void)finishVideoWithPreview:(nullable RPPreviewViewController *)preview;
- (void)presentPendingPreview;
- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)recorder preview:(nullable RPPreviewViewController *)preview error:(nullable NSError *)error;
- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation;
@end

/// A new delegate object binds callbacks to each recording generation. Reading
/// the current generation when an old callback arrives would not be sufficient.
@interface STReplaySessionDelegate : NSObject <RPScreenRecorderDelegate>
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic) NSUInteger generation;
@end

@implementation STReplaySessionDelegate
- (void)screenRecorder:(RPScreenRecorder *)recorder didStopRecordingWithPreviewViewController:(RPPreviewViewController *)preview error:(NSError *)error {
    [self.owner replayDidStopWithGeneration:self.generation recorder:recorder preview:preview error:error];
}
- (void)screenRecorderDidChangeAvailability:(RPScreenRecorder *)recorder {
    [self.owner replayAvailabilityChangedWithGeneration:self.generation];
}
@end

@interface STOverlayController : UIViewController
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic, strong) UIButton *bubble;
@property (nonatomic, strong) UIView *recordingDot;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UIScrollView *panelScroll;
@property (nonatomic, strong) UISegmentedControl *moduleSelector;
@property (nonatomic, strong) UIView *alpacaModule;
@property (nonatomic, strong) UIView *cardsModule;
@property (nonatomic) NSInteger selectedModule;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UILabel *noticeLabel;
@property (nonatomic, strong) UILabel *collapsedNoticeLabel;
@property (nonatomic, strong) UIButton *returnActionButton;
@property (nonatomic, strong) UIButton *leftPowerButton;
@property (nonatomic, strong) UIButton *rightPowerButton;
@property (nonatomic, strong) UIButton *confirmPowerButton;
@property (nonatomic, strong) UIStackView *powerControls;
@property (nonatomic, strong) UIButton *autoplayButton;
@property (nonatomic, strong) UILabel *autoplayLabel;
@property (nonatomic, strong) UISwitch *xraySwitch;
@property (nonatomic, strong) UIButton *cardHintsButton;
@property (nonatomic, strong) UILabel *cardHintsLabel;
@property (nonatomic, strong) UIButton *cardInvestigationButton;
@property (nonatomic, strong) UILabel *cardInvestigationLabel;
@property (nonatomic, strong) UILabel *xrayLabel;
@property (nonatomic, strong) UIView *xrayDepthContainer;
@property (nonatomic, strong) STLayerDepthSlider *xrayDepthSlider;
@property (nonatomic, strong) UILabel *xrayDepthLabel;
@property (nonatomic) NSInteger lastRequestedXrayDepth;
@property (nonatomic, strong) UIButton *warehouseButton;
@property (nonatomic, strong) UIButton *dataButton;
@property (nonatomic, strong) UIStackView *dataStack;
@property (nonatomic, strong) UIView *dataContainer;
@property (nonatomic, strong) UIButton *exportButton;
@property (nonatomic) BOOL expanded;
@property (nonatomic) BOOL dataExpanded;
@property (nonatomic) BOOL dragging;
@property (nonatomic) BOOL bubbleOnRight;
@property (nonatomic) CGFloat bubbleVerticalFraction;
- (BOOL)acceptsPoint:(CGPoint)point;
- (void)refresh;
- (void)toggleData;
- (void)selectModule;
- (UIStackView *)stackInCollapsibleContainer:(UIView *)container;
@end

@implementation STOverlayWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    STOverlayController *controller = (STOverlayController *)self.rootViewController;
    if (![controller isKindOfClass:STOverlayController.class]) return nil;
    // Presented share sheets and ReplayKit previews need their complete bounds.
    if (!controller.presentedViewController && ![controller acceptsPoint:point]) return nil;
    return [super hitTest:point withEvent:event];
}
// This window deliberately does not override canBecomeKeyWindow or call
// makeKeyAndVisible. The host game retains keyboard, scene and input ownership.
@end

@implementation STOverlayController

- (void)loadView {
    self.view = [[UIView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.view.backgroundColor = UIColor.clearColor;
    self.view.accessibilityViewIsModal = NO;
    self.bubbleOnRight = YES;
    self.bubbleVerticalFraction = 0;

    self.bubble = [UIButton buttonWithType:UIButtonTypeCustom];
    self.bubble.backgroundColor = [UIColor colorWithRed:0.17 green:0.075 blue:0.04 alpha:0.96];
    self.bubble.layer.cornerRadius = 23;
    self.bubble.layer.borderColor = STOrange().CGColor;
    self.bubble.layer.borderWidth = 1.5;
    self.bubble.tintColor = STOrange();
    [self.bubble setImage:[UIImage systemImageNamed:@"square.stack.3d.up.fill"] forState:UIControlStateNormal];
    self.bubble.accessibilityLabel = @"SDKtools";
    self.bubble.accessibilityHint = @"Toque para abrir. Arraste para mudar de posição.";
    [self.bubble addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [self.bubble addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveBubble:)]];
    [self.view addSubview:self.bubble];

    self.collapsedNoticeLabel = [self label:@"" size:12 weight:UIFontWeightMedium color:UIColor.whiteColor];
    self.collapsedNoticeLabel.numberOfLines = 3;
    self.collapsedNoticeLabel.backgroundColor = [UIColor colorWithWhite:0.07 alpha:0.96];
    self.collapsedNoticeLabel.layer.cornerRadius = 10;
    self.collapsedNoticeLabel.layer.masksToBounds = YES;
    self.collapsedNoticeLabel.textAlignment = NSTextAlignmentCenter;
    self.collapsedNoticeLabel.userInteractionEnabled = NO;
    self.collapsedNoticeLabel.hidden = YES;
    [self.view addSubview:self.collapsedNoticeLabel];

    self.recordingDot = [[UIView alloc] initWithFrame:CGRectMake(34, 2, 9, 9)];
    self.recordingDot.backgroundColor = [UIColor colorWithRed:1 green:0.22 blue:0.22 alpha:1];
    self.recordingDot.layer.cornerRadius = 4.5;
    self.recordingDot.layer.borderColor = UIColor.blackColor.CGColor;
    self.recordingDot.layer.borderWidth = 1;
    self.recordingDot.userInteractionEnabled = NO;
    self.recordingDot.hidden = YES;
    [self.bubble addSubview:self.recordingDot];

    self.panel = [UIView new];
    self.panel.hidden = YES;
    self.panel.backgroundColor = [UIColor colorWithRed:0.055 green:0.055 blue:0.065 alpha:0.98];
    self.panel.layer.cornerRadius = 22;
    self.panel.layer.borderColor = [UIColor colorWithRed:0.6 green:0.22 blue:0.09 alpha:0.7].CGColor;
    self.panel.layer.borderWidth = 1;
    self.panel.layer.shadowColor = UIColor.blackColor.CGColor;
    self.panel.layer.shadowOpacity = 0.3;
    self.panel.layer.shadowRadius = 16;
    self.panel.layer.shadowOffset = CGSizeMake(0, 5);
    [self.view addSubview:self.panel];

    UIScrollView *scroll = [UIScrollView new];
    self.panelScroll = scroll;
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    scroll.alwaysBounceVertical = NO;
    scroll.showsVerticalScrollIndicator = YES;
    scroll.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    [self.panel addSubview:scroll];
    UIStackView *stack = [[UIStackView alloc] init];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 8;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:self.panel.topAnchor constant:16],
        [scroll.bottomAnchor constraintEqualToAnchor:self.panel.bottomAnchor constant:-16],
        [scroll.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor constant:16],
        [scroll.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor constant:-16],
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor],
        [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor],
        [stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor],
        [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor]
    ]];

    UIStackView *header = [[UIStackView alloc] init];
    header.axis = UILayoutConstraintAxisHorizontal;
    header.alignment = UIStackViewAlignmentCenter;
    UIStackView *heading = [UIStackView new];
    heading.axis = UILayoutConstraintAxisVertical;
    heading.spacing = 2;
    [heading addArrangedSubview:[self label:@"SDKtools" size:23 weight:UIFontWeightBold color:UIColor.whiteColor]];
    [heading addArrangedSubview:[self label:@"V3.6 · Seus jogos" size:11 weight:UIFontWeightMedium color:STOrange()]];
    [header addArrangedSubview:heading];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    [close setImage:[UIImage systemImageNamed:@"xmark.circle.fill"] forState:UIControlStateNormal];
    close.tintColor = STMuted();
    close.accessibilityLabel = @"Fechar menu";
    [close addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [close.widthAnchor constraintEqualToConstant:44].active = YES;
    [close.heightAnchor constraintEqualToConstant:44].active = YES;
    [header addArrangedSubview:close];
    [stack addArrangedSubview:header];

    self.moduleSelector = [[UISegmentedControl alloc] initWithItems:@[@"Alpaca", @"Cartas"]];
    self.moduleSelector.selectedSegmentTintColor = [UIColor colorWithRed:0.75 green:0.20 blue:0.08 alpha:1];
    [self.moduleSelector setTitleTextAttributes:@{NSForegroundColorAttributeName: UIColor.whiteColor,
        NSFontAttributeName: [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold]} forState:UIControlStateNormal];
    [self.moduleSelector setTitleTextAttributes:@{NSForegroundColorAttributeName: UIColor.whiteColor} forState:UIControlStateSelected];
    self.selectedModule = [NSUserDefaults.standardUserDefaults integerForKey:@"SDKtools.selectedModule"] == 1 ? 1 : 0;
    self.moduleSelector.selectedSegmentIndex = self.selectedModule;
    self.moduleSelector.accessibilityLabel = @"Módulo do jogo";
    self.moduleSelector.accessibilityHint = @"Escolha Crazy Alpaca ou Ah, minha carta. Trocar de módulo não inicia nem pausa ferramentas.";
    [self.moduleSelector.heightAnchor constraintGreaterThanOrEqualToConstant:44].active = YES;
    [self.moduleSelector addTarget:self action:@selector(selectModule) forControlEvents:UIControlEventValueChanged];
    [stack addArrangedSubview:self.moduleSelector];

    self.alpacaModule = [UIView new];
    self.alpacaModule.accessibilityIdentifier = @"SDKtools.module.alpaca";
    UIStackView *alpaca = [self stackInCollapsibleContainer:self.alpacaModule];
    [stack addArrangedSubview:self.alpacaModule];
    UILabel *alpacaHeading = [self label:@"Crazy Alpaca" size:17 weight:UIFontWeightBold color:UIColor.whiteColor];
    alpacaHeading.accessibilityTraits |= UIAccessibilityTraitHeader;
    [alpaca addArrangedSubview:alpacaHeading];
    self.autoplayButton = [self button:@"Iniciar autoplay" symbol:@"play.fill" action:@selector(toggleAutoplay) primary:YES];
    [self.autoplayButton setImage:[UIImage systemImageNamed:@"pause.fill"] forState:UIControlStateSelected];
    self.autoplayButton.accessibilityHint = @"Planeja as combinações antes de mover. Toque na partida para pausar e retome aqui.";
    [alpaca addArrangedSubview:self.autoplayButton];
    self.autoplayLabel = [self label:@"Auto pausado" size:12 weight:UIFontWeightMedium color:STMuted()];
    [alpaca addArrangedSubview:self.autoplayLabel];

    UIStackView *xrayRow = [UIStackView new];
    xrayRow.axis = UILayoutConstraintAxisHorizontal;
    xrayRow.alignment = UIStackViewAlignmentCenter;
    [xrayRow addArrangedSubview:[self label:@"Raio X" size:15 weight:UIFontWeightSemibold color:UIColor.whiteColor]];
    self.xraySwitch = [UISwitch new];
    self.xraySwitch.onTintColor = STOrange();
    self.xraySwitch.accessibilityLabel = @"Raio X do Crazy Alpaca";
    self.xraySwitch.accessibilityHint = @"Mostra as camadas cobertas escolhidas e destaca combinações que cabem na barra.";
    [self.xraySwitch addTarget:self.owner action:@selector(toggleXray) forControlEvents:UIControlEventValueChanged];
    [xrayRow addArrangedSubview:self.xraySwitch];
    [xrayRow.heightAnchor constraintGreaterThanOrEqualToConstant:44].active = YES;
    [alpaca addArrangedSubview:xrayRow];
    self.xrayLabel = [self label:@"Desativado" size:11 weight:UIFontWeightRegular color:STMuted()];
    [alpaca addArrangedSubview:self.xrayLabel];
    self.xrayDepthContainer = [UIView new];
    self.xrayDepthContainer.hidden = YES;
    UIStackView *depthStack = [self stackInCollapsibleContainer:self.xrayDepthContainer];
    depthStack.spacing = 1;
    NSInteger initialDepth = MAX(1, MIN(5, STRecorder.shared.xrayDepth));
    self.lastRequestedXrayDepth = initialDepth;
    self.xrayDepthLabel = [self label:[NSString stringWithFormat:@"Camadas abaixo: %ld", (long)initialDepth]
        size:12 weight:UIFontWeightMedium color:UIColor.whiteColor];
    [depthStack addArrangedSubview:self.xrayDepthLabel];
    self.xrayDepthSlider = [STLayerDepthSlider new];
    self.xrayDepthSlider.minimumValue = 1;
    self.xrayDepthSlider.maximumValue = 5;
    self.xrayDepthSlider.value = (float)initialDepth;
    self.xrayDepthSlider.continuous = YES;
    self.xrayDepthSlider.minimumTrackTintColor = STOrange();
    self.xrayDepthSlider.maximumTrackTintColor = [UIColor colorWithWhite:0.25 alpha:1];
    self.xrayDepthSlider.accessibilityLabel = @"Camadas abaixo";
    self.xrayDepthSlider.accessibilityHint = @"Escolha de uma a cinco camadas cobertas. Um mostra a primeira camada coberta.";
    [self.xrayDepthSlider.heightAnchor constraintGreaterThanOrEqualToConstant:44].active = YES;
    [self.xrayDepthSlider addTarget:self.owner action:@selector(changeXrayDepth) forControlEvents:UIControlEventValueChanged];
    [depthStack addArrangedSubview:self.xrayDepthSlider];
    [depthStack addArrangedSubview:[self label:@"1 = primeira camada coberta" size:11 weight:UIFontWeightRegular color:STMuted()]];
    [alpaca addArrangedSubview:self.xrayDepthContainer];

    self.warehouseButton = [self button:@"Meu armazém" symbol:@"tray.2" action:@selector(openWarehouse) primary:NO];
    self.warehouseButton.accessibilityHint = @"Abre o controle original de um espaço disponível no seu armazém.";
    [alpaca addArrangedSubview:self.warehouseButton];
    [alpaca addArrangedSubview:[self label:@"Poderes da partida" size:12 weight:UIFontWeightSemibold color:STMuted()]];
    self.leftPowerButton = [self button:@"Esquerdo" symbol:@"tray" action:@selector(openLeftPower) primary:NO];
    self.returnActionButton = [self button:@"Central" symbol:@"arrow.uturn.backward" action:@selector(openCenterPower) primary:NO];
    self.rightPowerButton = [self button:@"Direito" symbol:@"shuffle" action:@selector(openRightPower) primary:NO];
    UIStackView *powerRow = [[UIStackView alloc] initWithArrangedSubviews:@[self.leftPowerButton, self.returnActionButton, self.rightPowerButton]];
    self.powerControls = powerRow;
    powerRow.axis = UIContentSizeCategoryIsAccessibilityCategory(self.traitCollection.preferredContentSizeCategory) ? UILayoutConstraintAxisVertical : UILayoutConstraintAxisHorizontal;
    powerRow.distribution = UIStackViewDistributionFillEqually;
    powerRow.spacing = 6;
    for (UIButton *button in @[self.leftPowerButton, self.returnActionButton, self.rightPowerButton]) {
        button.titleLabel.font = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleCaption1] scaledFontForFont:[UIFont systemFontOfSize:11 weight:UIFontWeightSemibold]];
        button.accessibilityLabel = [NSString stringWithFormat:@"Abrir poder %@", button.currentTitle.lowercaseString];
        button.accessibilityHint = @"Confira o nome, o efeito e o estoque na confirmação do jogo.";
    }
    [alpaca addArrangedSubview:powerRow];
    self.confirmPowerButton = [self button:@"Confirmar poder aberto" symbol:@"checkmark.circle" action:@selector(confirmPower) primary:NO];
    self.confirmPowerButton.accessibilityHint = @"Confirma uma vez o poder cuja janela original está aberta. O jogo controla o estoque.";
    [alpaca addArrangedSubview:self.confirmPowerButton];

    self.cardsModule = [UIView new];
    self.cardsModule.accessibilityIdentifier = @"SDKtools.module.cards";
    UIStackView *cards = [self stackInCollapsibleContainer:self.cardsModule];
    [stack addArrangedSubview:self.cardsModule];
    UILabel *cardsHeading = [self label:@"Ah, minha carta" size:17 weight:UIFontWeightBold color:UIColor.whiteColor];
    cardsHeading.accessibilityTraits |= UIAccessibilityTraitHeader;
    [cards addArrangedSubview:cardsHeading];
    self.cardHintsButton = [self button:@"Ver cartas" symbol:@"rectangle.on.rectangle" action:@selector(toggleCardHints) primary:YES];
    self.cardHintsButton.accessibilityHint = @"Ícones das cartas identificadas pelo jogo. Cartas desconhecidas continuam sem identificação.";
    [cards addArrangedSubview:self.cardHintsButton];
    self.cardHintsLabel = [self label:@"Desativado" size:12 weight:UIFontWeightRegular color:STMuted()];
    [cards addArrangedSubview:self.cardHintsLabel];
    self.alpacaModule.hidden = self.selectedModule != 0;
    self.cardsModule.hidden = self.selectedModule != 1;

    self.dataButton = [self button:@"Suporte" symbol:@"chevron.down" action:@selector(toggleData) primary:NO];
    [self.dataButton removeTarget:self.owner action:@selector(toggleData) forControlEvents:UIControlEventTouchUpInside];
    [self.dataButton addTarget:self action:@selector(toggleData) forControlEvents:UIControlEventTouchUpInside];
    [self.dataButton setImage:[UIImage systemImageNamed:@"chevron.up"] forState:UIControlStateSelected];
    self.dataButton.accessibilityValue = @"Fechado";
    self.dataButton.accessibilityHint = @"Abre diagnóstico manual e exportação de relatório. Nada é gravado ao abrir esta seção.";
    [stack addArrangedSubview:self.dataButton];
    self.dataContainer = [UIView new];
    self.dataContainer.hidden = YES;
    self.dataStack = [self stackInCollapsibleContainer:self.dataContainer];
    [stack addArrangedSubview:self.dataContainer];
    self.cardInvestigationButton = [self button:@"Iniciar diagnóstico" symbol:@"waveform.path" action:@selector(toggleDiagnostic) primary:NO];
    self.cardInvestigationButton.accessibilityHint = @"Inicia uma coleta local somente ao tocar. As ferramentas são pausadas durante o diagnóstico.";
    [self.dataStack addArrangedSubview:self.cardInvestigationButton];
    self.cardInvestigationLabel = [self label:@"Escolha o jogo acima e entre na partida." size:11 weight:UIFontWeightRegular color:STMuted()];
    [self.dataStack addArrangedSubview:self.cardInvestigationLabel];
    self.statusLabel = [self label:@"Diagnóstico parado" size:12 weight:UIFontWeightMedium color:STMuted()];
    [self.dataStack addArrangedSubview:self.statusLabel];
    self.exportButton = [self button:@"Exportar relatório" symbol:@"square.and.arrow.up" action:@selector(exportReport) primary:NO];
    self.exportButton.accessibilityHint = @"Abre o compartilhamento do relatório JSON salvo no dispositivo.";
    [self.dataStack addArrangedSubview:self.exportButton];
    self.noticeLabel = [self label:@"" size:12 weight:UIFontWeightMedium color:STOrange()];
    self.noticeLabel.hidden = YES;
    self.noticeLabel.accessibilityTraits = UIAccessibilityTraitStaticText;
    [stack addArrangedSubview:self.noticeLabel];
    [self.view bringSubviewToFront:self.bubble];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.owner refresh];
}

- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection {
    [super traitCollectionDidChange:previousTraitCollection];
    self.powerControls.axis = UIContentSizeCategoryIsAccessibilityCategory(self.traitCollection.preferredContentSizeCategory) ? UILayoutConstraintAxisVertical : UILayoutConstraintAxisHorizontal;
    [self.view setNeedsLayout];
}

- (UIStackView *)stackInCollapsibleContainer:(UIView *)container {
    container.clipsToBounds = YES;
    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 8;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [container addSubview:stack];
    // A hidden arranged wrapper has zero height. Its children retain usable
    // tap targets without fighting the UIStackView hiding constraint.
    NSLayoutConstraint *bottom = [stack.bottomAnchor constraintEqualToAnchor:container.bottomAnchor];
    bottom.priority = 999;
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:container.topAnchor],
        [stack.leadingAnchor constraintEqualToAnchor:container.leadingAnchor],
        [stack.trailingAnchor constraintEqualToAnchor:container.trailingAnchor], bottom
    ]];
    return stack;
}

- (UILabel *)label:(NSString *)text size:(CGFloat)size weight:(UIFontWeight)weight color:(UIColor *)color {
    UILabel *label = [UILabel new];
    label.text = text;
    label.numberOfLines = 0;
    label.textColor = color;
    label.font = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleBody] scaledFontForFont:[UIFont systemFontOfSize:size weight:weight]];
    label.adjustsFontForContentSizeCategory = YES;
    return label;
}

- (UIButton *)button:(NSString *)title symbol:(NSString *)symbol action:(SEL)action primary:(BOOL)primary {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setImage:[UIImage systemImageNamed:symbol] forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.tintColor = primary ? UIColor.whiteColor : STOrange();
    button.backgroundColor = primary ? [UIColor colorWithRed:0.8 green:0.22 blue:0.07 alpha:1] : [UIColor colorWithWhite:0.115 alpha:1];
    button.titleLabel.font = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleBody] scaledFontForFont:[UIFont systemFontOfSize:12 weight:UIFontWeightSemibold]];
    button.titleLabel.adjustsFontForContentSizeCategory = YES;
    button.titleLabel.numberOfLines = 2;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.layer.cornerRadius = 12;
    button.contentEdgeInsets = UIEdgeInsetsMake(11, 8, 11, 8);
    button.imageEdgeInsets = UIEdgeInsetsMake(0, -4, 0, 4);
    [button.heightAnchor constraintGreaterThanOrEqualToConstant:46].active = YES;
    [button addTarget:self.owner action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (CGRect)usableBounds {
    CGRect bounds = UIEdgeInsetsInsetRect(self.view.bounds, self.view.safeAreaInsets);
    return CGRectInset(bounds, 10, 8);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect safe = [self usableBounds];
    if (!self.dragging) {
        CGFloat x = self.bubbleOnRight ? CGRectGetMaxX(safe) - 46 : CGRectGetMinX(safe);
        CGFloat y = CGRectGetMinY(safe) + self.bubbleVerticalFraction * MAX(0, CGRectGetHeight(safe) - 46);
        self.bubble.frame = CGRectMake(x, y, 46, 46);
    }
    CGFloat width = MIN(350, CGRectGetWidth(safe));
    CGFloat preferredHeight = self.selectedModule == 1 ? 330 : (self.xrayDepthContainer.hidden ? 620 : 720);
    if (self.dataExpanded) preferredHeight += 220;
    if (UIContentSizeCategoryIsAccessibilityCategory(self.traitCollection.preferredContentSizeCategory)) preferredHeight += 160;
    CGFloat height = MIN(preferredHeight, MAX(120, CGRectGetHeight(safe) - 56));
    CGFloat x = self.bubbleOnRight ? CGRectGetMaxX(safe) - width : CGRectGetMinX(safe);
    CGFloat y = CGRectGetMinY(safe) + 56;
    self.panel.frame = CGRectMake(x, y, width, height);
    self.panel.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.panel.bounds cornerRadius:22].CGPath;
    BOOL compactStatus = !self.noticeLabel.text.length;
    CGFloat noticeWidth = MIN(compactStatus ? 200 : 300, CGRectGetWidth(safe));
    CGSize noticeSize = [self.collapsedNoticeLabel sizeThatFits:CGSizeMake(MAX(1, noticeWidth - 16), CGFLOAT_MAX)];
    CGFloat noticeHeight = MIN(MAX(compactStatus ? 26 : 50, noticeSize.height + (compactStatus ? 8 : 16)), CGRectGetHeight(safe));
    CGFloat noticeX = self.bubbleOnRight ? CGRectGetMaxX(safe) - noticeWidth : CGRectGetMinX(safe);
    CGFloat below = CGRectGetMaxY(self.bubble.frame) + 8;
    CGFloat noticeY = below + noticeHeight <= CGRectGetMaxY(safe) ? below : CGRectGetMinY(self.bubble.frame) - noticeHeight - 8;
    noticeY = MAX(CGRectGetMinY(safe), MIN(noticeY, CGRectGetMaxY(safe) - noticeHeight));
    self.collapsedNoticeLabel.frame = CGRectMake(noticeX, noticeY, noticeWidth, noticeHeight);
}

- (BOOL)acceptsPoint:(CGPoint)point {
    CGPoint local = [self.view convertPoint:point fromView:self.view.window];
    return CGRectContainsPoint(self.bubble.frame, local) || (self.expanded && CGRectContainsPoint(self.panel.frame, local));
}

- (void)togglePanel {
    self.expanded = !self.expanded;
    self.panel.hidden = !self.expanded;
    self.view.accessibilityViewIsModal = self.expanded;
    [self.bubble setImage:[UIImage systemImageNamed:self.expanded ? @"xmark" : @"square.stack.3d.up.fill"] forState:UIControlStateNormal];
    self.bubble.accessibilityLabel = self.expanded ? @"Fechar SDKtools" : @"Abrir SDKtools";
    [self.owner refresh];
}

- (void)moveBubble:(UIPanGestureRecognizer *)gesture {
    CGRect safe = [self usableBounds];
    if (gesture.state == UIGestureRecognizerStateBegan) self.dragging = YES;
    CGPoint delta = [gesture translationInView:self.view];
    CGPoint center = self.bubble.center;
    center.x = MIN(MAX(center.x + delta.x, CGRectGetMinX(safe) + 23), CGRectGetMaxX(safe) - 23);
    center.y = MIN(MAX(center.y + delta.y, CGRectGetMinY(safe) + 23), CGRectGetMaxY(safe) - 23);
    self.bubble.center = center;
    [gesture setTranslation:CGPointZero inView:self.view];
    if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled || gesture.state == UIGestureRecognizerStateFailed) {
        self.dragging = NO;
        self.bubbleOnRight = center.x >= CGRectGetMidX(safe);
        CGFloat travel = CGRectGetHeight(safe) - 46;
        self.bubbleVerticalFraction = travel > 0 ? MIN(1, MAX(0, (center.y - 23 - CGRectGetMinY(safe)) / travel)) : 0;
        [self.view setNeedsLayout];
    }
}

- (void)selectModule {
    self.selectedModule = self.moduleSelector.selectedSegmentIndex == 1 ? 1 : 0;
    [NSUserDefaults.standardUserDefaults setInteger:self.selectedModule forKey:@"SDKtools.selectedModule"];
    self.alpacaModule.hidden = self.selectedModule != 0;
    self.cardsModule.hidden = self.selectedModule != 1;
    // Module selection only changes navigation. It never changes active tools.
    [self.panelScroll setContentOffset:CGPointZero animated:NO];
    [self.owner refresh];
    [self.view setNeedsLayout];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification,
        self.selectedModule == 1 ? self.cardHintsButton : self.autoplayButton);
}

- (void)toggleData {
    self.dataExpanded = !self.dataExpanded;
    self.dataContainer.hidden = !self.dataExpanded;
    self.dataButton.selected = self.dataExpanded;
    self.dataButton.accessibilityValue = self.dataExpanded ? @"Aberto" : @"Fechado";
    [self.view setNeedsLayout];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.dataExpanded ? self.cardInvestigationButton : self.dataButton);
}

- (void)refresh {
    if (!self.isViewLoaded) return;
    STRecorder *recorder = STRecorder.shared;
    BOOL recording = recorder.recording;
    BOOL detecting = recorder.detectedGameDetectionActive;
    BOOL sourceBusy = recorder.sourceExportBusy;
    BOOL transition = self.owner.videoState == STVideoStarting || self.owner.videoState == STVideoStopping;
    BOOL presented = self.owner.pendingPreview || self.presentedViewController;
    BOOL autoEnabled = recorder.autoplayEnabled, autoBusy = recorder.autoplayBusy;
    BOOL cardsEnabled = recorder.cardHintsEnabled, cardsBusy = recorder.cardHintsBusy;
    BOOL idlePresentation = self.owner.videoState == STVideoIdle && !presented;
    STSetLabelText(self.statusLabel, recorder.statusText ?: @"Diagnóstico parado");
    self.exportButton.enabled = !detecting && !sourceBusy && !recording && idlePresentation;
    BOOL actionAvailable = !cardsEnabled && !cardsBusy && !detecting && !recording && !sourceBusy && !recorder.returnActionBusy && !autoBusy && !presented && !transition;
    self.returnActionButton.enabled = actionAvailable;
    self.leftPowerButton.enabled = actionAvailable;
    self.rightPowerButton.enabled = actionAvailable;
    self.confirmPowerButton.enabled = actionAvailable;
    self.warehouseButton.enabled = actionAvailable;
    STSetButtonTitle(self.confirmPowerButton, recorder.returnActionBusy ? @"Aguardando a ação…" : @"Confirmar poder aberto");
    self.autoplayButton.enabled = !cardsEnabled && !cardsBusy && !detecting && !sourceBusy && (autoEnabled || (!autoBusy && !recording && !recorder.returnActionBusy && idlePresentation));
    STSetButtonTitle(self.autoplayButton, autoEnabled ? @"Pausar autoplay" : (autoBusy ? @"Aguardando a jogada…" : @"Iniciar autoplay"));
    self.autoplayButton.selected = autoEnabled;
    STSetLabelText(self.autoplayLabel, recorder.autoplayStatusText);
    self.xraySwitch.on = recorder.xrayEnabled;
    self.xraySwitch.enabled = !cardsEnabled && !cardsBusy && !detecting && (recorder.xrayEnabled || (!sourceBusy && !recording && !presented && !transition));
    STSetLabelText(self.xrayLabel, recorder.xrayStatusText ?: @"Desativado");
    if (self.xrayDepthContainer.hidden == recorder.xrayEnabled) {
        self.xrayDepthContainer.hidden = !recorder.xrayEnabled;
        [self.view setNeedsLayout];
    }
    self.xrayDepthSlider.enabled = recorder.xrayEnabled && !sourceBusy && !recording && !presented && !transition;
    if (!self.xrayDepthSlider.isTracking) {
        NSInteger depth = MAX(1, MIN(5, recorder.xrayDepth));
        if (self.xrayDepthSlider.value != (float)depth) [self.xrayDepthSlider setValue:(float)depth animated:NO];
        self.lastRequestedXrayDepth = depth;
        STSetLabelText(self.xrayDepthLabel, [NSString stringWithFormat:@"Camadas abaixo: %ld", (long)depth]);
        self.xrayDepthSlider.accessibilityValue = [NSString stringWithFormat:depth == 1 ? @"%ld camada abaixo" : @"%ld camadas abaixo", (long)depth];
    }
    self.cardHintsButton.enabled = cardsEnabled || (!cardsBusy && !detecting && !sourceBusy && !recording && !autoBusy && !recorder.returnActionBusy && idlePresentation);
    STSetButtonTitle(self.cardHintsButton, cardsEnabled ? @"Ocultar cartas" : (cardsBusy ? @"Encerrando leitura…" : @"Ver cartas"));
    self.cardHintsButton.selected = cardsEnabled;
    STSetLabelText(self.cardHintsLabel, recorder.cardHintsStatusText);
    BOOL diagnosticRunning = recording || detecting || self.owner.videoState != STVideoIdle;
    self.cardInvestigationButton.enabled = diagnosticRunning || (!cardsBusy && !sourceBusy && !autoBusy && !recorder.returnActionBusy && idlePresentation);
    STSetButtonTitle(self.cardInvestigationButton, diagnosticRunning ? @"Parar diagnóstico" : @"Iniciar diagnóstico");
    NSString *diagnosticText = recorder.cardInvestigationActive ? recorder.cardInvestigationStatusText :
        (recording ? @"Coleta em andamento. Pare para exportar." :
            (self.selectedModule == 1 ? @"Ah, minha carta · coleta local por até 90 s" : @"Crazy Alpaca · coleta manual da partida"));
    STSetLabelText(self.cardInvestigationLabel, diagnosticText);
    self.recordingDot.hidden = !cardsEnabled && !detecting && !recording && self.owner.videoState == STVideoIdle && !autoEnabled && !sourceBusy && !recorder.xrayEnabled;
    // Only actual, initialized controls belong here. Removed development
    // buttons must never become nil entries inside an NSArray literal.
    for (UIButton *button in @[self.exportButton, self.returnActionButton, self.leftPowerButton, self.rightPowerButton,
        self.confirmPowerButton, self.autoplayButton, self.warehouseButton, self.cardHintsButton, self.cardInvestigationButton]) {
        button.alpha = button.enabled ? 1 : 0.38;
    }
    NSString *notice = self.owner.noticeExpires > CACurrentMediaTime() ? self.owner.notice : @"";
    STSetLabelText(self.noticeLabel, notice);
    self.noticeLabel.hidden = !notice.length;
    NSString *compactAuto = autoEnabled ? recorder.autoplayStatusText : (autoBusy ? @"Auto pausando…" : @"");
    NSString *compactText = notice.length ? notice : (recording ? @"Diagnóstico ativo" :
        (cardsEnabled ? @"Ver cartas ativo" : (sourceBusy ? @"Preparando arquivo…" : compactAuto)));
    BOOL layoutChanged = ![self.collapsedNoticeLabel.text isEqualToString:compactText];
    STSetLabelText(self.collapsedNoticeLabel, compactText);
    CGFloat fontSize = notice.length ? 12 : 10;
    if (self.collapsedNoticeLabel.font.pointSize != fontSize)
        self.collapsedNoticeLabel.font = [UIFont systemFontOfSize:fontSize weight:UIFontWeightMedium];
    self.collapsedNoticeLabel.hidden = self.expanded || !compactText.length;
    if (layoutChanged) [self.view setNeedsLayout];
}

@end

@implementation STOverlay

+ (instancetype)shared {
    static STOverlay *instance;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ instance = [STOverlay new]; });
    return instance;
}

- (instancetype)init {
    if ((self = [super init])) {
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        [center addObserver:self selector:@selector(becameActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        [center addObserver:self selector:@selector(becameActive:) name:UISceneDidActivateNotification object:nil];
        [center addObserver:self selector:@selector(enteredBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(sceneEnteredBackground:) name:UISceneDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(recorderChanged:) name:STRecorderDidChangeNotification object:nil];
    }
    return self;
}

- (UIWindowScene *)foregroundScene {
    UIWindowScene *fallback = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        UIWindowScene *windowScene = (UIWindowScene *)scene;
        for (UIWindow *window in windowScene.windows) {
            if (![window isKindOfClass:STOverlayWindow.class] && window.isKeyWindow) return windowScene;
        }
        if (!fallback) fallback = windowScene;
    }
    return fallback;
}

- (void)installIfNeeded {
    NSAssert(NSThread.isMainThread, @"SDKtools UI requires the main thread");
    UIWindowScene *scene = [self foregroundScene];
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    // Unity hosts may still use the UIApplication lifecycle without a scene
    // manifest. In that case connectedScenes is empty and a scene-only overlay
    // would never appear. Require a real host window in either lifecycle.
    UIWindow *hostWindow = nil;
    NSArray<UIWindow *> *windows = scene ? scene.windows : UIApplication.sharedApplication.windows;
    for (UIWindow *candidate in windows) {
        if ([candidate isKindOfClass:STOverlayWindow.class] || candidate.hidden || !candidate.rootViewController) continue;
        if (candidate.isKeyWindow) { hostWindow = candidate; break; }
        if (!hostWindow && candidate.windowLevel == UIWindowLevelNormal) hostWindow = candidate;
    }
    if (!hostWindow) return;
    if (!self.window) {
        self.controller = [STOverlayController new];
        self.controller.owner = self;
        self.window = scene ? [[STOverlayWindow alloc] initWithWindowScene:scene] : [[STOverlayWindow alloc] initWithFrame:hostWindow.bounds];
        self.window.rootViewController = self.controller;
        self.window.windowLevel = UIWindowLevelNormal + 5;
        self.window.backgroundColor = UIColor.clearColor;
        self.window.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
        self.window.accessibilityIdentifier = @"SDKtools.overlay";
    } else if (scene && self.window.windowScene != scene && !self.controller.presentedViewController) {
        self.window.hidden = YES;
        self.window.windowScene = scene;
    }
    self.window.frame = scene ? scene.coordinateSpace.bounds : hostWindow.screen.bounds;
    self.window.hidden = NO;
    [self refresh];
}

- (void)becameActive:(NSNotification *)notification {
    [self installIfNeeded];
    [self presentPendingPreview];
    [self presentPendingSourceExport];
}

- (void)sceneEnteredBackground:(NSNotification *)notification {
    if (notification.object == self.window.windowScene) [self enteredBackground:notification];
}

- (void)enteredBackground:(NSNotification *)notification {
    self.window.hidden = YES;
    [self.statusTimer invalidate];
    self.statusTimer = nil;
    [self stopAllWithReason:@"background"];
}

- (void)recorderChanged:(NSNotification *)notification {
    // Limits and background handling can stop JSON independently. Do not leave
    // a screen recording running after its paired capture has ended.
    if (!STRecorder.shared.recording && self.ownsReplayKit) {
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    }
    [self refresh];
}

- (void)refresh {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self refresh]; }); return; }
    [self.controller refresh];
    BOOL active = UIApplication.sharedApplication.applicationState == UIApplicationStateActive;
    BOOL needed = active && (STRecorder.shared.detectedGameDetectionActive || STRecorder.shared.sourceExportBusy || (self.controller.expanded && (STRecorder.shared.cardHintsEnabled || STRecorder.shared.cardHintsBusy || STRecorder.shared.recording || self.videoState != STVideoIdle || STRecorder.shared.autoplayEnabled || STRecorder.shared.autoplayBusy || STRecorder.shared.xrayEnabled)) || self.noticeExpires > CACurrentMediaTime());
    if (needed && !self.statusTimer) {
        __weak typeof(self) weakSelf = self;
        self.statusTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer *timer) { [weakSelf refresh]; }];
    } else if (!needed && self.statusTimer) {
        [self.statusTimer invalidate];
        self.statusTimer = nil;
    }
}

- (void)showNotice:(NSString *)notice {
    self.notice = notice;
    self.noticeExpires = CACurrentMediaTime() + 8;
    [self refresh];
}

- (void)startCapture {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação do código terminar."]; return; }
    if (STRecorder.shared.recording) return;
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize ou salve o vídeo anterior antes de iniciar outra captura."];
        return;
    }
    [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura não iniciou. Tente novamente com o app aberto."];
        return;
    }
    [self showNotice:@"Diagnóstico iniciado. Jogue um pouco; depois pare e exporte em Suporte."];
}

- (void)detectNewGame {
    STRecorder *recorder = STRecorder.shared;
    if (recorder.detectedGameDetectionActive) {
        [recorder cancelNewGameDetection]; [self showNotice:@"Detecção cancelada."]; return;
    }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController || ![recorder beginNewGameDetection]) {
        [self showNotice:@"Finalize a captura ou ação em andamento antes de detectar outro jogo."]; return;
    }
    [self showNotice:@"Abra Ah, minha carta. Depois confirme o jogo em Dados e captura."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)confirmNewGame {
    if (![STRecorder.shared confirmNewGameCapture]) {
        [self showNotice:@"O jogo mudou ou ainda está carregando. Aguarde a nova detecção."]; return;
    }
    [self showNotice:@"JSON iniciado. Jogue por 30–60 s; depois toque Parar e Exportar relatório."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)traceReturn {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação do código terminar."]; return; }
    if (STRecorder.shared.returnTraceActive) {
        [self showNotice:@"Rastreamento já ativo. Use os poderes e o armazém originais, depois pare e exporte."];
        return;
    }
    if (!STRecorder.shared.recording) [self startCapture];
    if (!STRecorder.shared.recording) return;
    if (![STRecorder.shared beginReturnTrace]) {
        [self showNotice:@"Não foi possível iniciar o rastreamento nesta captura. Pare e exporte o relatório atual."];
        return;
    }
    [self showNotice:@"Rastreamento ativo. Use os poderes e o armazém no jogo. Depois pare a captura e exporte o JSON."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)toggleAutoplay {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação do código terminar."]; return; }
    if (STRecorder.shared.autoplayEnabled) {
        [STRecorder.shared pauseAutoplayWithReason:@"user"];
        [self showNotice:STRecorder.shared.autoplayStatusText];
        return;
    }
    if ([STRecorder.shared startAutoplay]) {
        self.noticeExpires = 0;
        if (self.controller.expanded) [self.controller togglePanel];
    } else {
        [self showNotice:STRecorder.shared.autoplayBusy ? @"Aguarde a ação já enviada terminar antes de retomar." :
            (STRecorder.shared.recording ? @"Pare a captura antes de iniciar o autoplay." : @"Entre na partida e feche as janelas do jogo antes de iniciar.")];
    }
    [self refresh];
}

- (void)toggleXray {
    [STRecorder.shared setXrayEnabled:self.controller.xraySwitch.isOn];
    [self refresh];
}

- (void)toggleCardHints {
    STRecorder *recorder = STRecorder.shared;
    BOOL enabling = !recorder.cardHintsEnabled;
    BOOL accepted = [recorder setCardHintsEnabled:enabling];
    if (!accepted) [self showNotice:recorder.cardHintsStatusText];
    else if (enabling) {
        [self showNotice:@"Ver cartas ativo. Ícones das cartas identificadas pelo jogo."];
        if (self.controller.expanded) [self.controller togglePanel];
    }
    [self refresh];
}

- (void)toggleDiagnostic {
    STRecorder *recorder = STRecorder.shared;
    if (recorder.recording || recorder.detectedGameDetectionActive || self.videoState != STVideoIdle) {
        [self stopCapture];
        [self refresh];
        return;
    }
    if (self.controller.selectedModule == 1) {
        [self investigateCards];
    } else {
        [self startCapture];
        if (recorder.recording && self.controller.expanded) [self.controller togglePanel];
    }
}

- (void)investigateCards {
    if (STRecorder.shared.cardInvestigationActive) {
        [STRecorder.shared stopRecordingWithReason:@"user"];
        [self showNotice:@"Diagnóstico encerrado. Em Suporte, toque Exportar relatório."];
        [self refresh]; return;
    }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize o vídeo ou a janela aberta antes de investigar."]; return;
    }
    if (![STRecorder.shared beginCardInvestigation]) {
        [self showNotice:STRecorder.shared.cardInvestigationStatusText]; return;
    }
    [self showNotice:@"Diagnóstico iniciado. Jogue por 30–60 s; depois pare e exporte em Suporte."];
    if (self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)changeXrayDepth {
    STLayerDepthSlider *slider = self.controller.xrayDepthSlider;
    NSInteger depth = MAX(1, MIN(5, (NSInteger)(slider.value + 0.5f)));
    [slider setValue:(float)depth animated:NO];
    STSetLabelText(self.controller.xrayDepthLabel, [NSString stringWithFormat:@"Camadas abaixo: %ld", (long)depth]);
    slider.accessibilityValue = [NSString stringWithFormat:depth == 1 ? @"%ld camada abaixo" : @"%ld camadas abaixo", (long)depth];
    // Continuous touch events within the same step do not trigger new reads.
    if (depth == self.controller.lastRequestedXrayDepth) return;
    self.controller.lastRequestedXrayDepth = depth;
    [STRecorder.shared setXrayDepth:depth];
}

- (void)openWarehouse {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação do código terminar."]; return; }
    if (self.controller.presentedViewController || self.pendingPreview ||
        self.videoState == STVideoStarting || self.videoState == STVideoStopping) {
        [self showNotice:@"Feche a janela aberta e aguarde o vídeo terminar de iniciar ou salvar."];
        return;
    }
    [self showNotice:@"Conferindo seu armazém…"];
    __weak STOverlay *weakSelf = self;
    BOOL accepted = [STRecorder.shared openOwnWarehouseWithUpdate:^(NSDictionary *result) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        NSString *status = result[@"status"], *reason = result[@"reason"];
        if ([status isEqualToString:@"original_event_dispatched"]) {
            [strongSelf showNotice:@"Pedido enviado. Confira a seleção do armazém no jogo."];
        } else if ([status isEqualToString:@"dispatch_uncertain"]) {
            [strongSelf showNotice:@"A resposta ainda não foi confirmada. Aguarde e confira o armazém no jogo."];
        } else if ([reason isEqualToString:@"selection_already_open"]) {
            [strongSelf showNotice:@"A seleção do armazém já está aberta."];
        } else if ([reason isEqualToString:@"own_slot_locked"]) {
            [strongSelf showNotice:@"Seu espaço está bloqueado nesta partida. O jogo precisa liberá-lo."];
        } else if ([reason isEqualToString:@"own_slot_occupied"]) {
            [strongSelf showNotice:@"Seu espaço já está ocupado. Confira as cartas no armazém."];
        } else if ([reason isEqualToString:@"owner_unknown"]) {
            [strongSelf showNotice:@"Não foi possível identificar seu armazém nesta tela."];
        } else if ([@[@"return_action_pending", @"physical_operation_pending", @"cleanup_pending"] containsObject:reason]) {
            [strongSelf showNotice:@"Uma ação ainda está em andamento. Aguarde antes de tentar novamente."];
        } else if ([@[@"native_modal_visible", @"modal_visible", @"native_view_obscured", @"ambiguous_window_overlap"] containsObject:reason]) {
            [strongSelf showNotice:@"Feche a janela aberta no jogo antes de abrir o armazém."];
        } else {
            [strongSelf showNotice:@"Seu armazém não está disponível nesta tela. Entre na partida e tente novamente."];
        }
        [strongSelf refresh];
    }];
    if (accepted && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)openLeftPower { [self performPowerSlot:@"left" command:@"open"]; }
- (void)openCenterPower { [self performPowerSlot:@"center" command:@"open"]; }
- (void)openRightPower { [self performPowerSlot:@"right" command:@"open"]; }
- (void)confirmPower { [self performPowerSlot:@"current" command:@"confirm"]; }

- (void)performPowerSlot:(NSString *)slot command:(NSString *)command {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação do código terminar."]; return; }
    if (self.controller.presentedViewController || self.pendingPreview ||
        self.videoState == STVideoStarting || self.videoState == STVideoStopping) {
        [self showNotice:@"Feche a janela aberta e aguarde o vídeo terminar de iniciar ou salvar."];
        return;
    }
    [self showNotice:[command isEqual:@"confirm"] ? @"Conferindo o poder aberto e o estoque…" : @"Abrindo o poder original…"];
    __weak STOverlay *weakSelf = self;
    BOOL accepted = [STRecorder.shared performOriginalPowerAtSlot:slot command:command update:^(NSDictionary *result) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        NSString *status = result[@"status"], *reason = result[@"reason"];
        if ([status isEqualToString:@"original_event_dispatched"]) {
            [strongSelf showNotice:[command isEqual:@"confirm"] ? @"Uso solicitado ao jogo. Aguarde o efeito antes de usar novamente." : @"Confira o efeito e confirme Usar item no jogo."];
        } else if ([status isEqualToString:@"dispatch_uncertain"]) {
            [strongSelf showNotice:[result[@"physicalPending"] boolValue] ?
                @"Resposta incerta. Aguarde o jogo; o poder permanece bloqueado enquanto essa chamada não terminar." :
                @"A resposta não pôde ser confirmada. Confira a tela do jogo antes de tocar novamente."];
        } else if ([@[@"return_action_pending", @"physical_operation_pending", @"cleanup_pending"] containsObject:reason]) {
            [strongSelf showNotice:@"Há uma leitura ou ação em andamento. Aguarde antes de tocar novamente."];
        } else if ([@[@"native_modal_visible", @"modal_visible", @"native_view_obscured", @"ambiguous_window_overlap"] containsObject:reason]) {
            [strongSelf showNotice:@"Já existe uma janela aberta. Resolva ou feche essa janela no jogo."];
        } else if ([@[@"disabled_control", @"button_unavailable", @"stock_unavailable", @"stock_empty"] containsObject:reason]) {
            [strongSelf showNotice:@"O poder não está disponível ou está sem estoque. Confira a partida."];
        } else if ([@[@"confirmation_unavailable", @"confirmation_ambiguous", @"prop_mismatch"] containsObject:reason]) {
            [strongSelf showNotice:@"Abra o poder desejado e confira sua confirmação no jogo. A janela pode fechar após alguns segundos."];
        } else if ([@[@"unsupported_application", @"engine_version", @"game_type_abi_mismatch"] containsObject:reason]) {
            [strongSelf showNotice:@"Esta versão do jogo não corresponde ao controle verificado para US 6.6.2."];
        } else {
            [strongSelf showNotice:@"Não foi possível identificar esse poder nesta tela. Entre na partida e exporte um relatório se continuar."];
        }
        [strongSelf refresh];
    }];
    // Only an accepted request can collapse the panel. Rejections keep the
    // explanation and controls visible. No synthetic tap or automatic retry.
    if (accepted && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)stopCapture { [self stopAllWithReason:@"user"]; }

- (void)stopAllWithReason:(NSString *)reason {
    if (STRecorder.shared.detectedGameDetectionActive) {
        [STRecorder.shared cancelNewGameDetection];
        [self showNotice:@"Detecção cancelada."]; return;
    }
    if (self.videoState != STVideoIdle) {
        self.pendingStopReason = reason;
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    } else {
        [STRecorder.shared stopRecordingWithReason:reason];
        [self showNotice:@"Captura encerrada. O relatório está pronto para exportar."];
    }
}

- (void)markAlpaca {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"crazyAlpacaEntered" details:@{@"source": @"user"}];
    [self showNotice:@"Entrada no Crazy Alpaca marcada no relatório."];
}

- (void)markMatch {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"matchStarted" details:@{@"source": @"user"}];
    [self showNotice:@"Início da partida marcado no relatório."];
}

- (void)exportReport {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação do código terminar."]; return; }
    if (self.pendingPreview) { [self showNotice:@"Salve ou feche a prévia do vídeo antes de exportar."]; [self presentPendingPreview]; return; }
    if (STRecorder.shared.recording || self.videoState != STVideoIdle) { [self showNotice:@"Pare a captura antes de exportar o relatório."]; return; }
    if (self.controller.presentedViewController) { [self showNotice:@"Feche a janela aberta antes de exportar."]; return; }
    NSError *error = nil;
    NSURL *url = [STRecorder.shared writeReportWithError:&error];
    if (!url) {
        if ([error.domain isEqualToString:@"SDKtools.Recorder"] && error.code == 1)
            [self showNotice:@"Ainda não há dados. Use uma ferramenta ou toque Suporte → Iniciar diagnóstico antes de exportar."];
        else
            [self showNotice:@"Não foi possível gerar o JSON. Confira o espaço livre e tente novamente."];
        return;
    }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    share.popoverPresentationController.sourceView = self.controller.exportButton;
    share.popoverPresentationController.sourceRect = self.controller.exportButton.bounds;
    __weak typeof(self) weakSelf = self;
    share.completionWithItemsHandler = ^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:completed ? @"Relatório compartilhado." : @"Relatório disponível para exportar novamente."];
            [weakSelf presentPendingPreview];
        });
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)exportGameSources {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"A exportação do código já está em andamento."]; return; }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Pare o vídeo e feche a prévia ou janela aberta antes de exportar o código."];
        return;
    }
    if (self.pendingSourceExportURL) { [self presentPendingSourceExport]; return; }
    [self showNotice:@"Preparando o código do jogo. Aguarde sem sair da partida."];
    __weak STOverlay *weakSelf = self;
    [STRecorder.shared exportCurrentGameSourcesWithCompletion:^(NSURL *url, NSError *error) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        if (!url.isFileURL || error) {
            [strongSelf showNotice:error.localizedDescription ?: @"Não foi possível gerar o arquivo. Abra uma partida e tente novamente."];
            [strongSelf refresh];
            return;
        }
        strongSelf.pendingSourceExportURL = url;
        [strongSelf showNotice:@"Código pronto. Escolha Salvar em Arquivos ou compartilhar o JSON."];
        [strongSelf presentPendingSourceExport];
        [strongSelf refresh];
    }];
    [self refresh];
}

- (void)presentPendingSourceExport {
    if (!self.pendingSourceExportURL || STRecorder.shared.sourceExportBusy ||
        self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController ||
        UIApplication.sharedApplication.applicationState != UIApplicationStateActive || self.window.hidden) return;
    NSURL *url = self.pendingSourceExportURL;
    self.pendingSourceExportURL = nil;
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    UIView *anchor = self.controller.bubble;
    share.popoverPresentationController.sourceView = anchor;
    share.popoverPresentationController.sourceRect = anchor.bounds;
    __weak STOverlay *weakSelf = self;
    share.completionWithItemsHandler = ^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:completed ? @"Código do jogo compartilhado." : @"Arquivo gerado. Você pode exportar novamente pelo menu."];
            [weakSelf presentPendingPreview];
        });
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)toggleVideo {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação do código terminar."]; return; }
    if (self.videoState == STVideoRecording) { [self stopVideo]; return; }
    if (self.videoState != STVideoIdle) return;
    if (self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Feche ou salve a prévia anterior antes de gravar novamente."]; return; }
    RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
    if (!recorder.isAvailable || recorder.isRecording) { [self showNotice:@"A gravação de tela não está disponível agora. O JSON pode ser gravado normalmente."]; return; }
    if (recorder.delegate && recorder.delegate != self.replayDelegate) { [self showNotice:@"O app já utiliza o gravador de tela. O JSON está ativo; para vídeo, use a Central de Controle."]; return; }
    if (!STRecorder.shared.recording) [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura JSON não iniciou. O vídeo não foi aberto."];
        return;
    }
    self.videoCaptureSessionIdentifier = STRecorder.shared.captureSessionIdentifier;
    NSUInteger generation = ++self.videoGeneration;
    self.previousReplayDelegate = recorder.delegate;
    self.previousMicrophoneEnabled = recorder.isMicrophoneEnabled;
    self.previousCameraEnabled = recorder.isCameraEnabled;
    self.replayDelegate = [STReplaySessionDelegate new];
    self.replayDelegate.owner = self;
    self.replayDelegate.generation = generation;
    recorder.delegate = self.replayDelegate;
    recorder.microphoneEnabled = NO;
    recorder.cameraEnabled = NO;
    self.ownsReplayKit = YES;
    self.videoState = STVideoStarting;
    self.stopWhenStarted = NO;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [recorder startRecordingWithHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            if (error) {
                [strongSelf markVideoEndWithError:error];
                [strongSelf finishVideoWithPreview:nil];
                [strongSelf showNotice:STRecorder.shared.recording ? @"O vídeo não iniciou. O JSON continua; você também pode gravar pela Central de Controle." : @"O vídeo não iniciou. A captura foi encerrada; o JSON está disponível para exportar."];
                return;
            }
            strongSelf.videoState = STVideoRecording;
            strongSelf.videoStarted = CACurrentMediaTime();
            [STRecorder.shared markEvent:@"visualRecordingStarted" details:@{@"source": @"replaykit", @"enabled": @YES}];
            if (strongSelf.stopWhenStarted || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) [strongSelf stopVideo];
            else [strongSelf showNotice:@"Vídeo iniciado sem microfone. Feche o menu para continuar."];
        });
    }];
}

- (void)stopVideo {
    if (self.videoState != STVideoRecording || !self.ownsReplayKit) return;
    self.videoState = STVideoStopping;
    NSUInteger generation = self.videoGeneration;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [RPScreenRecorder.sharedRecorder stopRecordingWithHandler:^(RPPreviewViewController *preview, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            [strongSelf markVideoEndWithError:error];
            [strongSelf finishVideoWithPreview:preview];
            if (error) [strongSelf showNotice:@"O vídeo terminou com erro. Exporte o JSON; a prévia será exibida se estiver disponível."];
        });
    }];
}

- (void)markVideoEndWithError:(NSError *)error {
    NSTimeInterval elapsed = self.videoStarted > 0 ? MAX(0, CACurrentMediaTime() - self.videoStarted) : 0;
    if (self.videoCaptureSessionIdentifier) {
        [STRecorder.shared markVisualRecordingEndForSessionIdentifier:self.videoCaptureSessionIdentifier failed:(error != nil) durationSeconds:elapsed];
    }
}

- (void)finishVideoWithPreview:(RPPreviewViewController *)preview {
    if (self.ownsReplayKit) {
        RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
        if (recorder.delegate == self.replayDelegate) {
            recorder.delegate = self.previousReplayDelegate;
            recorder.microphoneEnabled = self.previousMicrophoneEnabled;
            recorder.cameraEnabled = self.previousCameraEnabled;
        }
    }
    self.ownsReplayKit = NO;
    self.videoState = STVideoIdle;
    self.videoStarted = 0;
    self.stopWhenStarted = NO;
    self.previousReplayDelegate = nil;
    self.replayDelegate = nil;
    self.videoCaptureSessionIdentifier = nil;
    if (self.pendingStopReason) {
        NSString *reason = self.pendingStopReason;
        self.pendingStopReason = nil;
        [STRecorder.shared stopRecordingWithReason:reason];
    }
    if (preview) {
        preview.previewControllerDelegate = self;
        if (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) {
            preview.modalPresentationStyle = UIModalPresentationPopover;
            preview.popoverPresentationController.sourceView = self.controller.bubble;
            preview.popoverPresentationController.sourceRect = self.controller.bubble.bounds;
            preview.preferredContentSize = CGSizeMake(540, 620);
        } else preview.modalPresentationStyle = UIModalPresentationFullScreen;
        self.pendingPreview = preview;
    }
    [self refresh];
    [self presentPendingPreview];
}

- (void)presentPendingPreview {
    if (!self.pendingPreview || self.controller.presentedViewController || UIApplication.sharedApplication.applicationState != UIApplicationStateActive || self.window.hidden) return;
    RPPreviewViewController *preview = self.pendingPreview;
    self.pendingPreview = nil;
    [self.controller presentViewController:preview animated:YES completion:nil];
}

- (void)previewControllerDidFinish:(RPPreviewViewController *)previewController {
    [previewController dismissViewControllerAnimated:YES completion:^{ [self showNotice:@"Vídeo encerrado. Exporte também o JSON para analisar os dois juntos."]; [self presentPendingSourceExport]; }];
}

- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)screenRecorder preview:(RPPreviewViewController *)previewViewController error:(NSError *)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.ownsReplayKit || self.videoGeneration != generation || screenRecorder.isRecording) return;
        [self markVideoEndWithError:error];
        [self finishVideoWithPreview:previewViewController];
        [self showNotice:@"A gravação de vídeo foi encerrada pelo iOS. O relatório JSON continua disponível."];
    });
}

- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation {
    dispatch_async(dispatch_get_main_queue(), ^{ if (self.videoGeneration == generation) [self refresh]; });
}
@end

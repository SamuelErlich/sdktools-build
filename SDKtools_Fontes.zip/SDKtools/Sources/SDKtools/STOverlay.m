#import "STOverlay.h"
#import "STRecorder.h"
#import "STCardEarlyCapture.h"
#import "STBilliardsRuntime.h"
#import "STBrandTheme.h"
#import "STClientContext.h"
#import "STLocalizedUI.h"
#import "STCompactMenuLayout.h"
#import <ReplayKit/ReplayKit.h>
#import <QuartzCore/QuartzCore.h>
#import <math.h>

static UIColor *STOrange(void) { return STBrandColor(0xFF6A1F); }
static UIColor *STMuted(void) { return STBrandColor(0xA08F80); }
static void STSetLabelText(UILabel *label, NSString *text) { STLocalizeLabel(label,text); }
static void STSetButtonTitle(UIButton *button, NSString *title) { STLocalizeButton(button,title); }

// VoiceOver adjusts whole layers, matching the five steps used by touch.
@interface STLayerDepthSlider : UISlider
@end

@implementation STLayerDepthSlider
- (void)accessibilityIncrement {
    float next = MIN(self.maximumValue, (float)((NSInteger)(self.value + 0.5f) + 1));
    if (next == self.value) return;
    [self setValue:next animated:NO];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}
- (void)accessibilityDecrement {
    float next = MAX(self.minimumValue, (float)((NSInteger)(self.value + 0.5f) - 1));
    if (next == self.value) return;
    [self setValue:next animated:NO];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}
@end

// Brand-sized track with a full 44 pt touch target and native accessibility.
@interface STClientSwitch : UISwitch @end
@implementation STClientSwitch
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    (void)event; return CGRectContainsPoint(CGRectInset(self.bounds,-4,-13),point);
}
@end

typedef NS_ENUM(NSUInteger, STVideoState) {
    STVideoIdle, STVideoStarting, STVideoRecording, STVideoStopping
};

@class STOverlayController;
@class STReplaySessionDelegate;

@interface STOverlay () <RPPreviewViewControllerDelegate>
@property (nonatomic, strong) STOverlayWindow *window;
@property (nonatomic, strong) STOverlayController *controller;
@property (nonatomic, strong) NSTimer *statusTimer;
@property (nonatomic, copy) NSString *notice;
@property (nonatomic) NSTimeInterval noticeExpires;
@property (nonatomic) STVideoState videoState;
@property (nonatomic) NSUInteger videoGeneration;
@property (nonatomic) NSTimeInterval videoStarted;
@property (nonatomic) BOOL stopWhenStarted;
@property (nonatomic) BOOL ownsReplayKit;
@property (nonatomic) BOOL previousMicrophoneEnabled;
@property (nonatomic) BOOL previousCameraEnabled;
@property (nonatomic, weak) id<RPScreenRecorderDelegate> previousReplayDelegate;
@property (nonatomic, strong, nullable) STReplaySessionDelegate *replayDelegate;
@property (nonatomic, copy, nullable) NSString *videoCaptureSessionIdentifier;
@property (nonatomic, copy, nullable) NSString *pendingStopReason;
@property (nonatomic, strong, nullable) RPPreviewViewController *pendingPreview;
@property (nonatomic, strong, nullable) NSURL *pendingSourceExportURL;
@property (nonatomic) BOOL pendingSourceExportIsBilliards;
- (void)refresh;
- (void)startCapture;
- (void)detectNewGame;
- (void)confirmNewGame;
- (void)openLeftPower;
- (void)openCenterPower;
- (void)openRightPower;
- (void)confirmPower;
- (void)performPowerSlot:(NSString *)slot command:(NSString *)command;
- (void)toggleAutoplay;
- (void)toggleTurbo;
- (void)toggleSuperFast;
- (void)shareLAN;
- (void)stopLAN;
- (void)toggleExtendedPlanning;
- (void)toggleAutoPowers;
- (void)testCoveredCard;
- (void)testPenetrateZero;
- (void)exportCoveredReport;
- (void)traceCardEntry;
- (void)toggleCardHints;
- (void)sampleCardMenuNow;
- (void)toggleBilliards;
- (void)toggleBilliardsAim;
- (void)toggleBilliardsAuto;
- (void)exportBilliardsLive;
- (void)toggleXray;
- (void)toggleDiagnostic;
- (void)changeXrayDepth;
- (void)openWarehouse;
- (void)traceReturn;
- (void)stopCapture;
- (void)markAlpaca;
- (void)markMatch;
- (void)exportReport;
- (void)exportGameSources;
- (void)exportBilliardsResources;
- (void)presentPendingSourceExport;
- (void)toggleVideo;
- (void)showNotice:(NSString *)notice;
- (void)stopAllWithReason:(NSString *)reason;
- (void)stopVideo;
- (void)markVideoEndWithError:(nullable NSError *)error;
- (void)finishVideoWithPreview:(nullable RPPreviewViewController *)preview;
- (void)presentPendingPreview;
- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)recorder preview:(nullable RPPreviewViewController *)preview error:(nullable NSError *)error;
- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation;
@end

/// A new delegate object binds callbacks to each recording generation. Reading
/// the current generation when an old callback arrives would not be sufficient.
@interface STReplaySessionDelegate : NSObject <RPScreenRecorderDelegate>
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic) NSUInteger generation;
@end

@implementation STReplaySessionDelegate
- (void)screenRecorder:(RPScreenRecorder *)recorder didStopRecordingWithPreviewViewController:(RPPreviewViewController *)preview error:(NSError *)error {
    [self.owner replayDidStopWithGeneration:self.generation recorder:recorder preview:preview error:error];
}
- (void)screenRecorderDidChangeAvailability:(RPScreenRecorder *)recorder {
    [self.owner replayAvailabilityChangedWithGeneration:self.generation];
}
@end

@interface STOverlayController : UIViewController
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic, strong) UIButton *bubble;
@property (nonatomic, strong) UIView *recordingDot;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UIScrollView *panelScroll;
@property (nonatomic, strong) UIView *alpacaModule;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UILabel *noticeLabel;
@property (nonatomic, strong) UILabel *collapsedNoticeLabel;
@property (nonatomic, strong) UIButton *returnActionButton;
@property (nonatomic, strong) UIButton *leftPowerButton;
@property (nonatomic, strong) UIButton *rightPowerButton;
@property (nonatomic, strong) UIButton *confirmPowerButton;
@property (nonatomic, strong) UIStackView *powerControls;
@property (nonatomic, strong) UIButton *autoplayButton;
@property (nonatomic, strong) UIButton *lanButton;
@property (nonatomic, strong) UIButton *lanStopButton;
@property (nonatomic, strong) UILabel *lanLabel;
@property (nonatomic, strong) UILabel *autoplayLabel;
@property (nonatomic, strong) UISwitch *xraySwitch;
@property (nonatomic, strong) UISwitch *turboSwitch;
@property (nonatomic, strong) UISwitch *superFastSwitch;
@property (nonatomic, strong) UISwitch *planningSwitch;
@property (nonatomic, strong) UISwitch *powersSwitch;
@property (nonatomic, strong) UIButton *coveredAttemptButton;
@property (nonatomic, strong) UIButton *penetrateZeroButton;
@property (nonatomic, strong) UILabel *coveredAttemptLabel;
@property (nonatomic, strong) UIButton *coveredReportButton;
@property (nonatomic, strong) UIButton *diagnosticButton;
@property (nonatomic, strong) UILabel *diagnosticLabel;
@property (nonatomic, strong) UIButton *identifyGameButton;
@property (nonatomic, strong) UIView *confirmGameContainer;
@property (nonatomic, strong) UIButton *confirmGameButton;
@property (nonatomic, strong) UILabel *gameDetectionLabel;
@property (nonatomic, strong) UILabel *xrayLabel;
@property (nonatomic, strong) UIView *xrayDepthContainer;
@property (nonatomic, strong) STLayerDepthSlider *xrayDepthSlider;
@property (nonatomic, strong) UILabel *xrayDepthLabel;
@property (nonatomic) NSInteger lastRequestedXrayDepth;
@property (nonatomic, strong) UIButton *warehouseButton;
@property (nonatomic, strong) UIButton *warehouseTestButton;
@property (nonatomic, strong) UIButton *warehouseTestCancelButton;
@property (nonatomic, strong) UILabel *warehouseTestLabel;
@property (nonatomic, strong) UIButton *dataButton;
@property (nonatomic, strong) UIStackView *dataStack;
@property (nonatomic, strong) UIView *dataContainer;
@property (nonatomic, strong) UIButton *exportButton;
@property (nonatomic, strong) UIButton *billiardsResourceExportButton;
@property (nonatomic, strong) UIButton *billiardsTrainerButton;
@property (nonatomic, strong) UIButton *billiardsLiveExportButton;
@property (nonatomic, strong) UIButton *cardEarlyButton;
@property (nonatomic, strong) UIButton *cardHintsButton;
@property (nonatomic, strong) UIButton *cardSampleButton;
@property (nonatomic, strong) UIButton *cardExportButton;
@property (nonatomic, strong) UILabel *cardStatusLabel;
@property (nonatomic, strong) UILabel *cardColorsLabel;
@property (nonatomic, strong) UILabel *billiardsStatusLabel;
@property (nonatomic, strong) NSMutableArray<UIView *> *moduleCards;
@property (nonatomic, strong) NSMutableArray<UIView *> *moduleBodies;
@property (nonatomic, strong) NSMutableArray<UILabel *> *moduleBadges;
@property (nonatomic, strong) NSMutableArray<UIImageView *> *moduleIcons;
@property (nonatomic, strong) NSMutableArray<UILabel *> *moduleHints;
@property (nonatomic, strong) NSMutableArray<NSNumber *> *moduleGames;
@property (nonatomic, strong) UIButton *billiardsAimButton;
@property (nonatomic, strong) UIButton *billiardsAutoButton;
@property (nonatomic, strong) UIStackView *clientContentStack;
@property (nonatomic, strong) NSLayoutConstraint *clientHeaderHeight;
@property (nonatomic, strong) UIButton *languageButton;
@property (nonatomic, strong) UIView *languagePopover;
@property (nonatomic, strong) NSMutableArray<UIButton *> *languageChoices;
@property (nonatomic, strong) UIButton *settingsButton;
@property (nonatomic, strong) UIView *advancedContainer;
@property (nonatomic, strong) NSMutableArray<UIButton *> *tabButtons;
@property (nonatomic) STClientGame selectedGame;
@property (nonatomic, strong) UIStackView *languageSettingsRow;
@property (nonatomic) STClientGame activeGame;
@property (nonatomic) CFTimeInterval lastContextCheck;
@property (nonatomic) BOOL refreshingContext;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *,NSURL *> *clientLinkURLs;
@property (nonatomic) BOOL expanded;
@property (nonatomic) BOOL dataExpanded;
@property (nonatomic) BOOL dragging;
@property (nonatomic) BOOL bubbleOnRight;
@property (nonatomic) CGFloat bubbleVerticalFraction;
- (BOOL)acceptsPoint:(CGPoint)point;
- (void)refresh;

- (UIStackView *)stackInCollapsibleContainer:(UIView *)container;
@end

@implementation STOverlayWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    STOverlayController *controller = (STOverlayController *)self.rootViewController;
    if (![controller isKindOfClass:STOverlayController.class]) return nil;
    // Presented share sheets and ReplayKit previews need their complete bounds.
    if (!controller.presentedViewController && ![controller acceptsPoint:point]) return nil;
    return [super hitTest:point withEvent:event];
}
// This window deliberately does not override canBecomeKeyWindow or call
// makeKeyAndVisible. The host game retains keyboard, scene and input ownership.
@end

@implementation STOverlayController

// Cap menu typography, including accessibility categories. The content scrolls;
// controls keep their 44 pt targets instead of expanding over the game.
- (UIFont *)font:(NSString *)name size:(CGFloat)size {
    UIFont *base=[UIFont fontWithName:name size:size] ?: [UIFont systemFontOfSize:size];
    return [[UIFontMetrics metricsForTextStyle:UIFontTextStyleCaption1] scaledFontForFont:base maximumPointSize:size+3 compatibleWithTraitCollection:self.traitCollection];
}
- (UILabel *)label:(NSString *)text size:(CGFloat)size weight:(UIFontWeight)weight color:(UIColor *)color {
    UILabel *label=[UILabel new]; STLocalizeLabel(label,text); label.textColor=color; label.numberOfLines=0;
    label.font=[self font:weight>=UIFontWeightSemibold?@"Geist-SemiBold":@"Geist-Regular" size:size];
    label.adjustsFontForContentSizeCategory=NO; return label;
}
- (UIImage *)icon:(NSString *)name {
    // The brand PNGs have a 24 pt intrinsic size. Resize the image itself so
    // UIButton's intrinsic layout reserves precisely the visible 16 pt icon.
    static NSCache<NSString *,UIImage *> *cache; static dispatch_once_t once;
    dispatch_once(&once,^{cache=[NSCache new];cache.countLimit=32;});
    UIImage *icon=[cache objectForKey:name]; if(icon)return icon;
    UIImage *source=STBrandImage(name,YES); if(!source)return nil;
    UIGraphicsImageRenderer *renderer=[[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(16,16)];
    icon=[[renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx){(void)ctx;[source drawInRect:CGRectMake(0,0,16,16)];}] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    [cache setObject:icon forKey:name]; return icon;
}
- (UIStackView *)verticalStack {
    UIStackView *stack=[UIStackView new]; stack.axis=UILayoutConstraintAxisVertical; stack.spacing=6; return stack;
}
- (UIButton *)button:(NSString *)title symbol:(NSString *)symbol action:(SEL)action primary:(BOOL)primary {
    UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem]; STLocalizeButton(button,title);
    [button setImage:[self icon:symbol] forState:UIControlStateNormal];
    [button setTitleColor:STBrandColor(primary?0x0F0B08:0xFFF1E0) forState:UIControlStateNormal];
    button.tintColor=STBrandColor(primary?0x0F0B08:0xA08F80);
    button.backgroundColor=STBrandColor(primary?0xFF6A1F:0x211913); button.layer.cornerRadius=9;
    button.titleLabel.font=[self font:@"Geist-Medium" size:12]; button.titleLabel.numberOfLines=1;
    button.contentEdgeInsets=UIEdgeInsetsMake(8,8,8,8); button.imageEdgeInsets=UIEdgeInsetsMake(0,-3,0,3);
    [button.heightAnchor constraintEqualToConstant:44].active=YES;
    if(action)[button addTarget:self.owner action:action forControlEvents:UIControlEventTouchUpInside]; return button;
}
- (UIButton *)iconButton:(NSString *)label symbol:(NSString *)symbol target:(id)target action:(SEL)action {
    UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem];
    [button setImage:[self icon:symbol] forState:UIControlStateNormal]; button.tintColor=STMuted();
    STLocalizeAccessibilityLabel(button,label);
    // UIStackView gives a hidden header action zero width. Let that constraint
    // win without an Auto Layout conflict, preserving 44 pt when visible.
    NSLayoutConstraint *width=[button.widthAnchor constraintEqualToConstant:44]; width.priority=999; width.active=YES;
    [button.heightAnchor constraintEqualToConstant:44].active=YES;
    if(action)[button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside]; return button;
}
- (UISwitch *)addSwitch:(NSString *)title action:(SEL)action toStack:(UIStackView *)stack {
    UILabel *label=[self label:title size:12 weight:UIFontWeightMedium color:STBrandColor(0xFFF1E0)]; label.numberOfLines=2;
    UISwitch *control=[STClientSwitch new]; control.transform=CGAffineTransformMakeScale(0.80,0.80);
    control.onTintColor=STOrange(); control.thumbTintColor=STBrandColor(0xFFF1E0); STLocalizeAccessibilityLabel(control,title);
    [control setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [control addTarget:self.owner action:action forControlEvents:UIControlEventValueChanged];
    UIStackView *row=[[UIStackView alloc] initWithArrangedSubviews:@[label,control]];
    row.alignment=UIStackViewAlignmentCenter; row.spacing=8; [row.heightAnchor constraintGreaterThanOrEqualToConstant:44].active=YES;
    [stack addArrangedSubview:row]; return control;
}
- (void)loadView {
    STRegisterBrandFonts(); self.view=[[UIView alloc] initWithFrame:UIScreen.mainScreen.bounds]; self.view.backgroundColor=UIColor.clearColor;
    self.bubbleOnRight=YES; self.bubbleVerticalFraction=0.18; self.selectedGame=STClientGameAlpaca;
    self.moduleBodies=[NSMutableArray array]; self.moduleGames=[NSMutableArray arrayWithArray:@[@(STClientGameAlpaca),@(STClientGameCards),@(STClientGameBilliards)]];
    self.tabButtons=[NSMutableArray array];
    self.bubble=[UIButton buttonWithType:UIButtonTypeCustom]; self.bubble.backgroundColor=STBrandColor(0x17110D);
    self.bubble.layer.cornerRadius=12; self.bubble.layer.borderWidth=1; self.bubble.layer.borderColor=STBrandColor(0x2E241C).CGColor;
    UIImageView *symbol=[[UIImageView alloc] initWithImage:STBrandImage(@"symbol",NO)]; symbol.contentMode=UIViewContentModeScaleAspectFit;
    symbol.frame=CGRectMake(12.83,11,18.33,22); symbol.userInteractionEnabled=NO; [self.bubble addSubview:symbol];
    STLocalizeAccessibilityLabel(self.bubble,@"Open SDK Client"); STLocalizeAccessibilityHint(self.bubble,@"Drag to move the menu.");
    [self.bubble addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [self.bubble addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveBubble:)]]; [self.view addSubview:self.bubble];
    self.recordingDot=[[UIView alloc] initWithFrame:CGRectMake(35,5,4,4)]; self.recordingDot.layer.cornerRadius=2;
    self.recordingDot.backgroundColor=STBrandColor(0x62D48F); self.recordingDot.hidden=YES; self.recordingDot.userInteractionEnabled=NO; [self.bubble addSubview:self.recordingDot];
    self.collapsedNoticeLabel=[self label:@"" size:10 weight:UIFontWeightSemibold color:STBrandColor(0x62D48F)];
    self.collapsedNoticeLabel.backgroundColor=UIColor.clearColor; self.collapsedNoticeLabel.numberOfLines=1;
    self.collapsedNoticeLabel.userInteractionEnabled=NO; self.collapsedNoticeLabel.hidden=YES;
    self.collapsedNoticeLabel.layer.shadowColor=UIColor.blackColor.CGColor; self.collapsedNoticeLabel.layer.shadowOpacity=0.7;
    self.collapsedNoticeLabel.layer.shadowRadius=1; self.collapsedNoticeLabel.layer.shadowOffset=CGSizeMake(0,1); [self.view addSubview:self.collapsedNoticeLabel];
    self.panel=[UIView new]; self.panel.backgroundColor=STBrandColor(0x17110D); self.panel.layer.cornerRadius=16;
    self.panel.layer.borderWidth=1; self.panel.layer.borderColor=STBrandColor(0x2E241C).CGColor; self.panel.clipsToBounds=YES; self.panel.hidden=YES;
    [self.view addSubview:self.panel];
    UITapGestureRecognizer *dismissLanguage=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissLanguageOutside:)];
    dismissLanguage.cancelsTouchesInView=NO; dismissLanguage.delaysTouchesEnded=NO; [self.panel addGestureRecognizer:dismissLanguage];

    UIView *header=[UIView new]; header.translatesAutoresizingMaskIntoConstraints=NO; [self.panel addSubview:header];
    UIImageView *logo=[[UIImageView alloc] initWithImage:STBrandImage(@"logo",NO)]; logo.contentMode=UIViewContentModeScaleAspectFit;
    logo.isAccessibilityElement=YES; STLocalizeAccessibilityLabel(logo,@"SDK Client"); logo.translatesAutoresizingMaskIntoConstraints=NO; [header addSubview:logo];
    self.languageButton=[self iconButton:@"Language" symbol:@"world" target:self action:@selector(toggleLanguageMenu)];
    [self.languageButton setImage:[UIImage systemImageNamed:@"globe" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:16 weight:UIImageSymbolWeightRegular]] forState:UIControlStateNormal];
    self.settingsButton=[self iconButton:@"More settings" symbol:@"settings" target:self action:@selector(toggleSettings)];
    UIButton *close=[self iconButton:@"Close SDK Client" symbol:@"collapse" target:self action:@selector(togglePanel)];
    UIStackView *headerActions=[[UIStackView alloc] initWithArrangedSubviews:@[self.languageButton,self.settingsButton,close]];
    headerActions.translatesAutoresizingMaskIntoConstraints=NO; [header addSubview:headerActions];
    [NSLayoutConstraint activateConstraints:@[[header.topAnchor constraintEqualToAnchor:self.panel.topAnchor], [header.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor],
        [header.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor], [header.heightAnchor constraintEqualToConstant:48],
        [logo.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:12], [logo.centerYAnchor constraintEqualToAnchor:header.centerYAnchor],
        [logo.widthAnchor constraintEqualToConstant:64], [logo.heightAnchor constraintEqualToConstant:22],
        [headerActions.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-4], [headerActions.centerYAnchor constraintEqualToAnchor:header.centerYAnchor]]];
    UIStackView *tabs=[UIStackView new]; tabs.spacing=4; tabs.distribution=UIStackViewDistributionFillEqually; tabs.translatesAutoresizingMaskIntoConstraints=NO; [self.panel addSubview:tabs];
    NSArray *titles=@[@"Alpaca",@"Cards",@"Billiards"], *icons=@[@"movement",@"duplicate",@"combat"];
    for(NSUInteger i=0;i<titles.count;i++) {
        UIButton *tab=[UIButton buttonWithType:UIButtonTypeCustom]; tab.tag=self.moduleGames[i].integerValue; tab.layer.cornerRadius=9;
        STLocalizeAccessibilityLabel(tab,titles[i]);
        UIImageView *image=[[UIImageView alloc] initWithImage:[self icon:icons[i]]]; image.contentMode=UIViewContentModeScaleAspectFit;
        [image.widthAnchor constraintEqualToConstant:16].active=YES; [image.heightAnchor constraintEqualToConstant:16].active=YES;
        UILabel *title=[self label:titles[i] size:10 weight:UIFontWeightSemibold color:STBrandColor(0xFFF1E0)]; title.font=[self font:@"Syne-SemiBold" size:10]; title.numberOfLines=1;
        UIStackView *tabContent=[[UIStackView alloc] initWithArrangedSubviews:@[image,title]]; tabContent.axis=UILayoutConstraintAxisVertical; tabContent.alignment=UIStackViewAlignmentCenter; tabContent.spacing=1;
        tabContent.userInteractionEnabled=NO; tabContent.translatesAutoresizingMaskIntoConstraints=NO; [tab addSubview:tabContent];
        [NSLayoutConstraint activateConstraints:@[[tabContent.centerXAnchor constraintEqualToAnchor:tab.centerXAnchor], [tabContent.centerYAnchor constraintEqualToAnchor:tab.centerYAnchor],
            [tabContent.leadingAnchor constraintGreaterThanOrEqualToAnchor:tab.leadingAnchor constant:4], [tabContent.trailingAnchor constraintLessThanOrEqualToAnchor:tab.trailingAnchor constant:-4]]];
        [tab addTarget:self action:@selector(selectTab:) forControlEvents:UIControlEventTouchUpInside];
        [self.tabButtons addObject:tab]; [tabs addArrangedSubview:tab];
    }
    [NSLayoutConstraint activateConstraints:@[[tabs.topAnchor constraintEqualToAnchor:header.bottomAnchor], [tabs.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor constant:12],
        [tabs.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor constant:-12], [tabs.heightAnchor constraintEqualToConstant:44]]];

    UIView *footer=[UIView new]; footer.translatesAutoresizingMaskIntoConstraints=NO; [self.panel addSubview:footer];
    UILabel *version=[self label:@"3.23.13" size:9 weight:UIFontWeightRegular color:STMuted()]; version.font=[self font:@"Martian-Mono-SemiCondensed-Regular" size:9];
    version.translatesAutoresizingMaskIntoConstraints=NO; [footer addSubview:version];
    NSURL *linksURL=[[NSBundle bundleForClass:STOverlay.class] URLForResource:@"client-links" withExtension:@"json" subdirectory:@"Brand"];
    NSData *linksData=linksURL?[NSData dataWithContentsOfURL:linksURL]:nil; id config=linksData?[NSJSONSerialization JSONObjectWithData:linksData options:0 error:NULL]:nil;
    NSArray *links=[config isKindOfClass:NSDictionary.class] && [config[@"links"] isKindOfClass:NSArray.class]?config[@"links"]:@[];
    self.clientLinkURLs=[NSMutableDictionary dictionary]; UIStackView *social=[UIStackView new]; social.translatesAutoresizingMaskIntoConstraints=NO; [footer addSubview:social];
    for(id item in [links subarrayWithRange:NSMakeRange(0,MIN((NSUInteger)4,links.count))]) {
        if(![item isKindOfClass:NSDictionary.class] || ![item[@"title"] isKindOfClass:NSString.class])continue;
        NSString *title=item[@"title"], *urlText=[item[@"url"] isKindOfClass:NSString.class]?item[@"url"]:nil; NSURL *url=urlText?[NSURL URLWithString:urlText]:nil;
        BOOL live=[url.scheme.lowercaseString isEqual:@"https"] && url.host.length>0;
        UIButton *link=[self iconButton:title symbol:[title isEqual:@"YouTube"]?@"youtube":@"world" target:self action:@selector(openClientLink:)];
        link.enabled=live; link.alpha=live?1:0.45; STLocalizeAccessibilityHint(link,live?@"Open link":@"Coming soon");
        if(live)self.clientLinkURLs[@(link.hash)]=url; [social addArrangedSubview:link];
    }
    [NSLayoutConstraint activateConstraints:@[[footer.bottomAnchor constraintEqualToAnchor:self.panel.bottomAnchor], [footer.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor constant:12],
        [footer.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor constant:-4], [footer.heightAnchor constraintEqualToConstant:44],
        [version.leadingAnchor constraintEqualToAnchor:footer.leadingAnchor], [version.centerYAnchor constraintEqualToAnchor:footer.centerYAnchor],
        [social.trailingAnchor constraintEqualToAnchor:footer.trailingAnchor], [social.centerYAnchor constraintEqualToAnchor:footer.centerYAnchor]]];
    self.panelScroll=[UIScrollView new]; self.panelScroll.translatesAutoresizingMaskIntoConstraints=NO; self.panelScroll.alwaysBounceVertical=NO;
    self.panelScroll.indicatorStyle=UIScrollViewIndicatorStyleWhite; self.panelScroll.contentInsetAdjustmentBehavior=UIScrollViewContentInsetAdjustmentNever; [self.panel addSubview:self.panelScroll];
    [NSLayoutConstraint activateConstraints:@[[self.panelScroll.topAnchor constraintEqualToAnchor:tabs.bottomAnchor constant:8], [self.panelScroll.bottomAnchor constraintEqualToAnchor:footer.topAnchor],
        [self.panelScroll.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor], [self.panelScroll.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor]]];
    UIStackView *content=[self verticalStack]; self.clientContentStack=content; content.translatesAutoresizingMaskIntoConstraints=NO; [self.panelScroll addSubview:content];
    [NSLayoutConstraint activateConstraints:@[[content.topAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.topAnchor], [content.bottomAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.bottomAnchor constant:-8],
        [content.leadingAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.leadingAnchor constant:12], [content.trailingAnchor constraintEqualToAnchor:self.panelScroll.contentLayoutGuide.trailingAnchor constant:-12],
        [content.widthAnchor constraintEqualToAnchor:self.panelScroll.frameLayoutGuide.widthAnchor constant:-24]]];
    self.statusLabel=[self label:@"Open a game" size:11 weight:UIFontWeightRegular color:STMuted()]; self.statusLabel.numberOfLines=2; [content addArrangedSubview:self.statusLabel];

    UIStackView *alpaca=[self verticalStack];
    self.autoplayButton=[self button:@"Auto" symbol:@"movement" action:@selector(toggleAutoplay) primary:YES]; [alpaca addArrangedSubview:self.autoplayButton];
    self.autoplayLabel=[self label:@"Ready" size:10 weight:UIFontWeightRegular color:STMuted()]; self.autoplayLabel.numberOfLines=2; self.autoplayLabel.hidden=YES; [alpaca addArrangedSubview:self.autoplayLabel];
    self.lanButton=[self button:@"Browser control" symbol:@"world" action:@selector(shareLAN) primary:NO]; [alpaca addArrangedSubview:self.lanButton];
    self.lanStopButton=[self button:@"Stop LAN sharing" symbol:@"close" action:@selector(stopLAN) primary:NO]; [alpaca addArrangedSubview:self.lanStopButton];
    self.lanLabel=[self label:@"Same private Wi-Fi. HTTP is not encrypted. Keep the game open." size:10 weight:UIFontWeightRegular color:STMuted()]; self.lanLabel.numberOfLines=0; [alpaca addArrangedSubview:self.lanLabel];
    self.xraySwitch=[self addSwitch:@"X-ray" action:@selector(toggleXray) toStack:alpaca];
    self.xrayLabel=[self label:@"" size:10 weight:UIFontWeightRegular color:STMuted()]; self.xrayLabel.numberOfLines=2; self.xrayLabel.hidden=YES; [alpaca addArrangedSubview:self.xrayLabel];
    self.xrayDepthContainer=[UIView new]; UIStackView *depth=[self stackInCollapsibleContainer:self.xrayDepthContainer];
    self.xrayDepthLabel=[self label:@"Depth · 1 layer" size:10 weight:UIFontWeightMedium color:STMuted()]; [depth addArrangedSubview:self.xrayDepthLabel];
    self.xrayDepthSlider=[STLayerDepthSlider new]; self.xrayDepthSlider.minimumValue=1; self.xrayDepthSlider.maximumValue=4;
    self.xrayDepthSlider.minimumTrackTintColor=STOrange(); self.xrayDepthSlider.maximumTrackTintColor=STBrandColor(0x2E241C);
    STLocalizeAccessibilityLabel(self.xrayDepthSlider,@"Layers below"); [self.xrayDepthSlider.heightAnchor constraintEqualToConstant:44].active=YES;
    [self.xrayDepthSlider addTarget:self.owner action:@selector(changeXrayDepth) forControlEvents:UIControlEventValueChanged]; [depth addArrangedSubview:self.xrayDepthSlider]; [alpaca addArrangedSubview:self.xrayDepthContainer];
    [alpaca addArrangedSubview:[self label:@"Powers" size:10 weight:UIFontWeightSemibold color:STMuted()]];
    self.leftPowerButton=[self iconButton:@"Left power" symbol:@"keybind" target:self.owner action:@selector(openLeftPower)];
    self.returnActionButton=[self iconButton:@"Center power" symbol:@"reset" target:self.owner action:@selector(openCenterPower)];
    self.rightPowerButton=[self iconButton:@"Right power" symbol:@"duplicate" target:self.owner action:@selector(openRightPower)];
    self.confirmPowerButton=[self iconButton:@"Confirm open power" symbol:@"check" target:self.owner action:@selector(confirmPower)];
    self.warehouseButton=[self iconButton:@"Open warehouse" symbol:@"configs" target:self.owner action:@selector(openWarehouse)];
    self.powerControls=[[UIStackView alloc] initWithArrangedSubviews:@[self.leftPowerButton,self.returnActionButton,self.rightPowerButton,self.confirmPowerButton,self.warehouseButton]];
    self.powerControls.distribution=UIStackViewDistributionEqualSpacing; [alpaca addArrangedSubview:self.powerControls];
    self.advancedContainer=[UIView new]; UIStackView *advanced=[self stackInCollapsibleContainer:self.advancedContainer];
    self.turboSwitch=[self addSwitch:@"Turbo" action:@selector(toggleTurbo) toStack:advanced];
    self.superFastSwitch=[self addSwitch:@"Super Fast" action:@selector(toggleSuperFast) toStack:advanced];
    STLocalizeAccessibilityHint(self.superFastSwitch,@"Up to 3 exposed cards per burst. Waits for server replies.");
    [advanced addArrangedSubview:[self label:@"Up to 3 exposed cards per burst. Waits for server replies." size:10 weight:UIFontWeightRegular color:STMuted()]];
    self.planningSwitch=[self addSwitch:@"Extended planning" action:@selector(toggleExtendedPlanning) toStack:advanced];
    self.powersSwitch=[self addSwitch:@"Owned powers" action:@selector(toggleAutoPowers) toStack:advanced];
    STLocalizeAccessibilityHint(self.powersSwitch,@"May use powers from your inventory.");
    [advanced addArrangedSubview:[self label:@"Uses your existing inventory." size:10 weight:UIFontWeightRegular color:STMuted()]];
    self.coveredAttemptButton=[self button:@"Test 1 covered card" symbol:@"duplicate" action:@selector(testCoveredCard) primary:NO];
    STLocalizeAccessibilityHint(self.coveredAttemptButton,@"Experimental. Sends one original card event; never retries automatically.");
    [advanced addArrangedSubview:self.coveredAttemptButton];
    self.penetrateZeroButton=[self button:@"Test Penetrate (0 stock)" symbol:@"duplicate" action:@selector(testPenetrateZero) primary:NO];
    STLocalizeAccessibilityHint(self.penetrateZeroButton,@"Experimental. Stock 0 does not guarantee free power or activation; SDK does not edit stock.");
    [advanced addArrangedSubview:self.penetrateZeroButton];
    UILabel *penetrateCaption=[self label:@"Experimental. Stock 0 does not guarantee free power or activation; SDK does not edit stock." size:10 weight:UIFontWeightRegular color:STMuted()];
    penetrateCaption.numberOfLines=0; [advanced addArrangedSubview:penetrateCaption];
    self.coveredAttemptLabel=[self label:@"Experimental: Auto off, X-ray on." size:10 weight:UIFontWeightRegular color:STMuted()];
    self.coveredAttemptLabel.numberOfLines=0; [advanced addArrangedSubview:self.coveredAttemptLabel];
    self.coveredReportButton=[self button:@"Export test report" symbol:@"duplicate" action:@selector(exportCoveredReport) primary:NO];
    STLocalizeAccessibilityHint(self.coveredReportButton,@"Exports only the observed state; sends no new attempt.");
    [advanced addArrangedSubview:self.coveredReportButton];
    UILabel *coveredReportCaption=[self label:@"Exports only the observed state; sends no new attempt." size:10 weight:UIFontWeightRegular color:STMuted()];
    coveredReportCaption.numberOfLines=0; [advanced addArrangedSubview:coveredReportCaption];
    self.advancedContainer.hidden=YES; [alpaca addArrangedSubview:self.advancedContainer];
    for(UIStackView *body in @[alpaca]) { UIView *wrapper=[UIView new]; [self putStack:body inWrapper:wrapper]; [self.moduleBodies addObject:wrapper]; [content addArrangedSubview:wrapper]; }
    UIStackView *cards=[self verticalStack]; self.cardHintsButton=[self button:@"Markers" symbol:@"player" action:@selector(toggleCardHints) primary:YES]; [cards addArrangedSubview:self.cardHintsButton];
    self.cardStatusLabel=[self label:@"? unknown · X no color" size:11 weight:UIFontWeightRegular color:STMuted()]; self.cardStatusLabel.numberOfLines=2; [cards addArrangedSubview:self.cardStatusLabel];
    UIView *cardsWrapper=[UIView new]; [self putStack:cards inWrapper:cardsWrapper]; [self.moduleBodies addObject:cardsWrapper]; [content addArrangedSubview:cardsWrapper];
    UIStackView *billiards=[self verticalStack];
    self.billiardsTrainerButton=[self button:@"Guide" symbol:@"render" action:@selector(toggleBilliards) primary:YES]; [billiards addArrangedSubview:self.billiardsTrainerButton];
    self.billiardsAimButton=[self button:@"Aim" symbol:@"combat" action:@selector(toggleBilliardsAim) primary:NO]; [billiards addArrangedSubview:self.billiardsAimButton];
    STLocalizeAccessibilityHint(self.billiardsAimButton,@"Adjusts aim without shooting.");
    self.billiardsAutoButton=[self button:@"Auto" symbol:@"movement" action:@selector(toggleBilliardsAuto) primary:NO]; [billiards addArrangedSubview:self.billiardsAutoButton];
    STLocalizeAccessibilityHint(self.billiardsAutoButton,@"Takes shots in this match. Manual input or reopening the menu pauses automation.");
    self.billiardsStatusLabel=[self label:@"Ready" size:11 weight:UIFontWeightRegular color:STMuted()]; self.billiardsStatusLabel.numberOfLines=2; [billiards addArrangedSubview:self.billiardsStatusLabel];
    UIView *billiardsWrapper=[UIView new]; [self putStack:billiards inWrapper:billiardsWrapper]; [self.moduleBodies addObject:billiardsWrapper]; [content addArrangedSubview:billiardsWrapper];
    self.noticeLabel=[self label:@"" size:11 weight:UIFontWeightMedium color:STBrandColor(0xFFB547)]; self.noticeLabel.hidden=YES; [content addArrangedSubview:self.noticeLabel];

    // Inline dropdown stays inside this non-key window. Choosing a language
    // never presents a controller, alters game identity or sends a game action.
    self.languagePopover=[UIView new]; self.languagePopover.translatesAutoresizingMaskIntoConstraints=NO; self.languagePopover.hidden=YES;
    self.languagePopover.backgroundColor=STBrandColor(0x211913); self.languagePopover.layer.cornerRadius=10; self.languagePopover.layer.borderWidth=1; self.languagePopover.layer.borderColor=STBrandColor(0x5A4A3E).CGColor;
    [self.panel addSubview:self.languagePopover]; UIStackView *languages=[self verticalStack]; languages.spacing=0; languages.translatesAutoresizingMaskIntoConstraints=NO; [self.languagePopover addSubview:languages];
    self.languageChoices=[NSMutableArray array];
    for(NSString *code in @[@"en",@"pt"]) {
        UIButton *choice=[self button:[code isEqual:@"en"]?@"English":@"Português" symbol:@"check" action:NULL primary:NO]; choice.accessibilityIdentifier=code;
        [choice addTarget:self action:@selector(selectLanguage:) forControlEvents:UIControlEventTouchUpInside]; [self.languageChoices addObject:choice]; [languages addArrangedSubview:choice];
    }
    [NSLayoutConstraint activateConstraints:@[[self.languagePopover.topAnchor constraintEqualToAnchor:header.bottomAnchor], [self.languagePopover.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor constant:-8],
        [self.languagePopover.widthAnchor constraintEqualToConstant:148], [languages.topAnchor constraintEqualToAnchor:self.languagePopover.topAnchor constant:4],
        [languages.bottomAnchor constraintEqualToAnchor:self.languagePopover.bottomAnchor constant:-4], [languages.leadingAnchor constraintEqualToAnchor:self.languagePopover.leadingAnchor constant:4], [languages.trailingAnchor constraintEqualToAnchor:self.languagePopover.trailingAnchor constant:-4]]];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(languageDidChange:) name:STLanguageDidChangeNotification object:nil]; [self languageDidChange:nil];
}
- (void)putStack:(UIStackView *)stack inWrapper:(UIView *)wrapper {
    stack.translatesAutoresizingMaskIntoConstraints=NO; [wrapper addSubview:stack];
    NSLayoutConstraint *bottom=[stack.bottomAnchor constraintEqualToAnchor:wrapper.bottomAnchor]; bottom.priority=999;
    [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:wrapper.topAnchor], [stack.leadingAnchor constraintEqualToAnchor:wrapper.leadingAnchor], [stack.trailingAnchor constraintEqualToAnchor:wrapper.trailingAnchor],bottom]];
}
- (UIStackView *)stackInCollapsibleContainer:(UIView *)container {
    UIStackView *stack=[self verticalStack]; [self putStack:stack inWrapper:container]; return stack;
}
- (void)toggleLanguageMenu {
    self.languagePopover.hidden=!self.languagePopover.hidden; self.languageButton.accessibilityValue=self.languagePopover.hidden?nil:STLocalizedText(@"Language");
    if(!self.languagePopover.hidden)UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification,self.languageChoices.firstObject);
}
- (void)dismissLanguageOutside:(UITapGestureRecognizer *)gesture {
    if(self.languagePopover.hidden)return;
    CGPoint point=[gesture locationInView:self.panel];
    if(CGRectContainsPoint(self.languagePopover.frame,point) || CGRectContainsPoint([self.languageButton convertRect:self.languageButton.bounds toView:self.panel],point))return;
    self.languagePopover.hidden=YES;
}
- (void)selectLanguage:(UIButton *)sender {
    self.languagePopover.hidden=YES; STSetLanguage(sender.accessibilityIdentifier); [self languageDidChange:nil];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification,self.languageButton);
}
- (void)languageDidChange:(NSNotification *)note {
    (void)note;
    for(UIButton *choice in self.languageChoices) {
        BOOL selected=[choice.accessibilityIdentifier isEqual:STCurrentLanguage()];
        choice.tintColor=selected?STOrange():UIColor.clearColor; choice.accessibilityTraits=UIAccessibilityTraitButton|(selected?UIAccessibilityTraitSelected:0);
    }
    STLocalizeAccessibilityValue(self.languageButton,[STCurrentLanguage() isEqual:@"pt"]?@"Português":@"English"); [self.view setNeedsLayout];
}
- (void)toggleSettings {
    self.languagePopover.hidden=YES; self.advancedContainer.hidden=!self.advancedContainer.hidden; self.settingsButton.tintColor=self.advancedContainer.hidden?STMuted():STOrange();
    self.panelScroll.contentOffset=CGPointZero; [self.view setNeedsLayout];
}
- (void)selectTab:(UIButton *)sender {
    self.languagePopover.hidden=YES; self.selectedGame=(STClientGame)sender.tag; self.advancedContainer.hidden=YES; self.panelScroll.contentOffset=CGPointZero; [self refresh];
}
- (void)dealloc { [NSNotificationCenter.defaultCenter removeObserver:self name:STLanguageDidChangeNotification object:nil]; }
- (void)openClientLink:(UIButton *)button {
    NSURL *url=self.clientLinkURLs[@(button.hash)]; if(url)[UIApplication.sharedApplication openURL:url options:@{} completionHandler:nil];
}
- (void)viewDidLoad { [super viewDidLoad]; [self.owner refresh]; }
- (void)traitCollectionDidChange:(UITraitCollection *)previous {
    [super traitCollectionDidChange:previous]; [self.view setNeedsLayout];
}
- (CGRect)usableBounds { return CGRectInset(UIEdgeInsetsInsetRect(self.view.bounds,self.view.safeAreaInsets),8,8); }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews]; CGRect safe=[self usableBounds];
    if(!self.dragging)self.bubble.frame=CGRectMake(self.bubbleOnRight?CGRectGetMaxX(safe)-44:CGRectGetMinX(safe),CGRectGetMinY(safe)+self.bubbleVerticalFraction*MAX(0,safe.size.height-44),44,44);
    CGFloat width=MIN(288,MAX(0,safe.size.width));
    self.powerControls.axis=width<244?UILayoutConstraintAxisVertical:UILayoutConstraintAxisHorizontal;
    self.powerControls.alignment=width<244?UIStackViewAlignmentCenter:UIStackViewAlignmentFill;
    CGSize content=[self.clientContentStack systemLayoutSizeFittingSize:CGSizeMake(MAX(1,width-24),0) withHorizontalFittingPriority:UILayoutPriorityRequired verticalFittingPriority:UILayoutPriorityFittingSizeLevel];
    STCompactMenuSize panelSize=STCompactMenuFit(safe.size.width,safe.size.height,content.height);
    CGFloat height=panelSize.height, y=MIN(MAX(CGRectGetMinY(self.bubble.frame),CGRectGetMinY(safe)),CGRectGetMaxY(safe)-height);
    self.panel.frame=CGRectMake(self.bubbleOnRight?CGRectGetMaxX(safe)-panelSize.width:CGRectGetMinX(safe),y,panelSize.width,height);
    CGFloat tagWidth=MIN(92,MAX(0,safe.size.width-50));
    // Geist reaches a 16.9 pt line at the capped accessibility size. Measure
    // the registered font so even this small, background-free tag never clips.
    CGFloat tagHeight=MAX(16,ceil(self.collapsedNoticeLabel.font.lineHeight));
    self.collapsedNoticeLabel.textAlignment=self.bubbleOnRight?NSTextAlignmentRight:NSTextAlignmentLeft;
    self.collapsedNoticeLabel.frame=CGRectMake(self.bubbleOnRight?CGRectGetMinX(self.bubble.frame)-tagWidth-6:CGRectGetMaxX(self.bubble.frame)+6,CGRectGetMidY(self.bubble.frame)-tagHeight/2,tagWidth,tagHeight);
}
- (BOOL)acceptsPoint:(CGPoint)point {
    CGPoint local=[self.view convertPoint:point fromView:self.view.window];
    return (self.expanded && CGRectContainsPoint(self.panel.frame,local)) || (!self.expanded && CGRectContainsPoint(self.bubble.frame,local));
}
- (void)togglePanel {
    if(!self.expanded)[STBilliardsRuntime.shared pauseAutomationWithReason:@"menu_opened"];
    self.expanded=!self.expanded; self.panel.hidden=!self.expanded; self.bubble.hidden=self.expanded; self.languagePopover.hidden=YES;
    self.view.accessibilityViewIsModal=self.expanded;
    self.lastContextCheck=0; [self.owner refresh]; UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,self.expanded?self.tabButtons.firstObject:self.bubble);
}
- (BOOL)accessibilityPerformEscape {
    if(!self.languagePopover.hidden){self.languagePopover.hidden=YES;return YES;}
    if(!self.expanded)return NO; [self togglePanel]; return YES;
}
- (void)moveBubble:(UIPanGestureRecognizer *)gesture {
    CGRect safe=[self usableBounds]; if(gesture.state==UIGestureRecognizerStateBegan)self.dragging=YES;
    CGPoint delta=[gesture translationInView:self.view], center=self.bubble.center;
    center.x=MIN(MAX(center.x+delta.x,CGRectGetMinX(safe)+22),CGRectGetMaxX(safe)-22); center.y=MIN(MAX(center.y+delta.y,CGRectGetMinY(safe)+22),CGRectGetMaxY(safe)-22);
    self.bubble.center=center; [gesture setTranslation:CGPointZero inView:self.view];
    if(gesture.state==UIGestureRecognizerStateEnded || gesture.state==UIGestureRecognizerStateCancelled || gesture.state==UIGestureRecognizerStateFailed) {
        self.dragging=NO; self.bubbleOnRight=center.x>=CGRectGetMidX(safe); CGFloat travel=safe.size.height-44;
        self.bubbleVerticalFraction=travel>0?MIN(1,MAX(0,(center.y-22-CGRectGetMinY(safe))/travel)):0;
    }
    [self.view setNeedsLayout];
}
- (void)refresh {
    if(!self.isViewLoaded || self.refreshingContext)return; self.refreshingContext=YES;
    STRecorder *r=STRecorder.shared; STBilliardsRuntime *b=STBilliardsRuntime.shared; CFTimeInterval now=CACurrentMediaTime(); STClientGame previousGame=self.activeGame;
    if(UIApplication.sharedApplication.applicationState!=UIApplicationStateActive)self.activeGame=STClientGameNone;
    else if(!self.lastContextCheck || now-self.lastContextCheck>=0.75){self.activeGame=STClientCurrentGame(self.view.window);self.lastContextCheck=now;}
    // Preserve the original context and uncertain-action guards.
    if(self.activeGame!=STClientGameAlpaca){if(r.autoplayEnabled)[r pauseAutoplayWithReason:@"game_context_changed"];if(r.xrayEnabled)[r setXrayEnabled:NO];}
    if(self.activeGame!=STClientGameCards && r.cardHintsEnabled)[r setCardHintsEnabled:NO];
    if(self.activeGame!=STClientGameBilliards && b.enabled)[b stopWithReason:@"game_context_changed"];
    if(previousGame!=self.activeGame){
        if(self.activeGame!=STClientGameNone)self.selectedGame=self.activeGame;
        self.advancedContainer.hidden=YES; self.languagePopover.hidden=YES; self.panelScroll.contentOffset=CGPointZero;
    }
    BOOL otherBusy=r.coveredAttemptPending || r.recording || r.cardEarlyActive || r.detectedGameDetectionActive || r.sourceExportBusy || r.returnActionBusy || self.presentedViewController || self.owner.pendingPreview || self.owner.videoState!=STVideoIdle;
    BOOL busy=otherBusy || r.autoplayBusy, autoBusy=otherBusy || r.autoplayStartBlockedByEvaluation;
    BOOL alpaca=STClientCanModify(self.activeGame,STClientGameAlpaca), cards=STClientCanModify(self.activeGame,STClientGameCards), billiards=STClientCanModify(self.activeGame,STClientGameBilliards);
    [self.turboSwitch setOn:r.turboEnabled animated:NO]; [self.superFastSwitch setOn:r.superFastEnabled animated:NO]; [self.planningSwitch setOn:r.extendedPlanning animated:NO]; [self.powersSwitch setOn:r.powersEnabled animated:NO];
    for(UISwitch *control in @[self.turboSwitch,self.superFastSwitch,self.planningSwitch,self.powersSwitch]){control.enabled=alpaca && !r.recording && !r.sourceExportBusy && !self.presentedViewController;control.alpha=control.enabled?1:0.4;}
    self.autoplayButton.enabled=alpaca && !r.warehouseTestActive && (r.autoplayEnabled || (!autoBusy && !b.enabled && !r.cardHintsBusy));
    STSetButtonTitle(self.autoplayButton,r.autoplayEnabled?@"Pause":(r.autoplayStartBlockedByEvaluation?@"Wait…":@"Auto"));
    self.autoplayLabel.hidden=!r.autoplayEnabled && !r.autoplayStartBlockedByEvaluation && !r.xrayEnabled; STSetLabelText(self.autoplayLabel,r.autoplayStatusText);
    STSetButtonTitle(self.lanButton,r.lanSharingEnabled?@"Copy LAN link":@"Browser control");
    self.lanButton.enabled=r.lanSharingEnabled || (alpaca && !otherBusy); self.lanStopButton.hidden=!r.lanSharingEnabled;
    STSetLabelText(self.lanLabel,r.lanSharingEnabled?[NSString stringWithFormat:@"LAN: %@ · Code: %@",r.lanSharingURL,r.lanPairingCode.length?r.lanPairingCode:@"—"]:@"Same private Wi-Fi. HTTP is not encrypted. Keep the game open.");
    self.xraySwitch.on=r.xrayEnabled; self.xraySwitch.enabled=alpaca && (r.xrayEnabled || ((!busy || r.coveredAttemptPending) && !b.enabled && !r.recording && !r.sourceExportBusy)); self.xraySwitch.alpha=self.xraySwitch.enabled?1:0.4;
    self.xrayDepthContainer.hidden=!r.xrayEnabled; self.xrayDepthSlider.enabled=alpaca && r.xrayEnabled && !busy;
    if(!self.xrayDepthSlider.isTracking){NSInteger depth=MAX(1,MIN(4,r.xrayDepth));self.xrayDepthSlider.value=(float)depth;self.lastRequestedXrayDepth=depth;
        STSetLabelText(self.xrayDepthLabel,[NSString stringWithFormat:@"Depth · %ld %@",(long)depth,depth==1?@"layer":@"layers"]);
        STLocalizeAccessibilityValue(self.xrayDepthSlider,[NSString stringWithFormat:@"%ld %@",(long)depth,depth==1?@"layer":@"layers"]);}
    for(UIButton *button in @[self.leftPowerButton,self.returnActionButton,self.rightPowerButton,self.confirmPowerButton,self.warehouseButton])button.enabled=alpaca && !busy && !b.enabled && !r.warehouseTestActive;
    self.coveredAttemptButton.hidden=self.coveredAttemptLabel.hidden=!alpaca;
    self.coveredAttemptButton.enabled=alpaca && r.xrayEnabled && !r.autoplayEnabled && !busy && !b.enabled && !r.warehouseTestActive && !r.cardHintsBusy;
    STSetButtonTitle(self.coveredAttemptButton,r.coveredAttemptPending?@"Awaiting result…":@"Test 1 covered card");
    STSetLabelText(self.coveredAttemptLabel,r.coveredAttemptStatusText);
    self.coveredAttemptButton.alpha=self.coveredAttemptButton.enabled?1:0.35;
    self.penetrateZeroButton.hidden=!alpaca;
    self.penetrateZeroButton.enabled=self.coveredAttemptButton.enabled;
    STSetButtonTitle(self.penetrateZeroButton,r.coveredAttemptPending?@"Awaiting result…":@"Test Penetrate (0 stock)");
    self.penetrateZeroButton.alpha=self.penetrateZeroButton.enabled?1:0.35;
    // Read-only export stays accessible in the Alpaca tab without a live match,
    // including pending/uncertain tests. Only presentation lifecycle gates apply.
    self.coveredReportButton.enabled=UIApplication.sharedApplication.applicationState==UIApplicationStateActive &&
        !self.presentedViewController && !self.owner.pendingPreview && self.view.window!=nil;
    self.coveredReportButton.alpha=self.coveredReportButton.enabled?1:0.35;
    self.cardHintsButton.enabled=cards && (r.cardHintsEnabled || (!busy && !b.enabled && !r.cardHintsBusy)); STSetButtonTitle(self.cardHintsButton,r.cardHintsEnabled?@"Markers · On":@"Markers");
    STSetLabelText(self.cardStatusLabel,r.cardHintsEnabled?r.cardHintsStatusText:@"? unknown · X no color");
    self.billiardsTrainerButton.enabled=billiards && (b.enabled || (!busy && !r.cardHintsEnabled && !r.cardHintsBusy)); STSetButtonTitle(self.billiardsTrainerButton,b.enabled?@"Guide · On":@"Guide");
    self.billiardsAimButton.enabled=self.billiardsAutoButton.enabled=billiards && !busy && !r.cardHintsEnabled && !r.cardHintsBusy;
    STSetButtonTitle(self.billiardsAimButton,b.automationMode==1?@"Aim · On":@"Aim"); STSetButtonTitle(self.billiardsAutoButton,b.automationMode==2?@"Pause":@"Auto");
    STSetLabelText(self.billiardsStatusLabel,b.enabled?b.statusText:@"Manual input pauses Auto.");
    for(UIButton *button in @[self.autoplayButton,self.leftPowerButton,self.returnActionButton,self.rightPowerButton,self.confirmPowerButton,self.warehouseButton,self.cardHintsButton,self.billiardsTrainerButton,self.billiardsAimButton,self.billiardsAutoButton])button.alpha=button.enabled?1:0.35;
    for(NSUInteger i=0;i<self.tabButtons.count;i++){
        UIButton *tab=self.tabButtons[i]; BOOL selected=self.selectedGame==(STClientGame)tab.tag, active=self.activeGame==(STClientGame)tab.tag;
        self.moduleBodies[i].hidden=!selected; tab.backgroundColor=STBrandColor(selected?0x2E241C:0x17110D);
        tab.layer.borderWidth=active?1:0;tab.layer.borderColor=STOrange().CGColor;tab.tintColor=active?STOrange():STMuted(); tab.alpha=active?1:(selected?0.7:0.45);
        tab.accessibilityTraits=UIAccessibilityTraitButton|(selected?UIAccessibilityTraitSelected:0); STLocalizeAccessibilityValue(tab,active?@"Active":@"Closed");
    }
    self.settingsButton.hidden=self.selectedGame!=STClientGameAlpaca; self.settingsButton.tintColor=self.advancedContainer.hidden?STMuted():STOrange();
    STLocalizeAccessibilityValue(self.settingsButton,self.advancedContainer.hidden?@"Closed":@"Open");
    STSetLabelText(self.statusLabel,self.activeGame==self.selectedGame?@"Active":@"Open this game to use controls."); self.statusLabel.textColor=self.activeGame==self.selectedGame?STOrange():STMuted();
    NSString *notice=self.owner.noticeExpires>now?self.owner.notice:@""; STSetLabelText(self.noticeLabel,notice); self.noticeLabel.hidden=!notice.length;
    self.recordingDot.hidden=!r.autoplayEnabled && !r.xrayEnabled && !r.cardHintsEnabled && !b.enabled;
    // Never forward full notices/diagnostics into gameplay. At most two short
    // state tags, green text, transparent background, next to the 44 pt bubble.
    NSString *compact=[NSString stringWithUTF8String:STCompactMenuTag(r.autoplayEnabled,r.xrayEnabled,r.cardHintsEnabled,b.enabled,(int)b.automationMode)];
    STSetLabelText(self.collapsedNoticeLabel,compact); self.collapsedNoticeLabel.hidden=self.expanded || !compact.length;
    self.refreshingContext=NO; [self.view setNeedsLayout];
}
@end


@implementation STOverlay
// Fresh identity at every modifying action prevents a tap racing a game switch.
- (BOOL)clientAllowsGame:(STClientGame)game {
    if (STClientCanModify(STClientActionGame(self.window),game)) { self.noticeExpires=0; return YES; }
    [self showNotice:STClientCanModify(STClientCurrentGame(self.window),game)?
        @"Close chat or popups, then try again.":@"Open the matching minigame before using this control."];
    self.controller.lastContextCheck=0; [self refresh]; return NO;
}


+ (instancetype)shared {
    static STOverlay *instance;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ instance = [STOverlay new]; });
    return instance;
}

- (instancetype)init {
    if ((self = [super init])) {
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        [center addObserver:self selector:@selector(becameActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        [center addObserver:self selector:@selector(becameActive:) name:UISceneDidActivateNotification object:nil];
        [center addObserver:self selector:@selector(enteredBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(sceneEnteredBackground:) name:UISceneDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(recorderChanged:) name:STRecorderDidChangeNotification object:nil];
        [center addObserver:self selector:@selector(recorderChanged:) name:STBilliardsRuntimeDidChangeNotification object:nil];
    }
    return self;
}

- (UIWindowScene *)foregroundScene {
    UIWindowScene *fallback = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        UIWindowScene *windowScene = (UIWindowScene *)scene;
        for (UIWindow *window in windowScene.windows) {
            if (![window isKindOfClass:STOverlayWindow.class] && window.isKeyWindow) return windowScene;
        }
        if (!fallback) fallback = windowScene;
    }
    return fallback;
}

- (void)installIfNeeded {
    NSAssert(NSThread.isMainThread, @"SDKtools UI requires the main thread");
    UIWindowScene *scene = [self foregroundScene];
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    // Unity hosts may still use the UIApplication lifecycle without a scene
    // manifest. In that case connectedScenes is empty and a scene-only overlay
    // would never appear. Require a real host window in either lifecycle.
    UIWindow *hostWindow = nil;
    NSArray<UIWindow *> *windows = scene ? scene.windows : UIApplication.sharedApplication.windows;
    for (UIWindow *candidate in windows) {
        if ([candidate isKindOfClass:STOverlayWindow.class] || candidate.hidden || !candidate.rootViewController) continue;
        if (candidate.isKeyWindow) { hostWindow = candidate; break; }
        if (!hostWindow && candidate.windowLevel == UIWindowLevelNormal) hostWindow = candidate;
    }
    if (!hostWindow) return;
    if (!self.window) {
        self.controller = [STOverlayController new];
        self.controller.owner = self;
        self.window = scene ? [[STOverlayWindow alloc] initWithWindowScene:scene] : [[STOverlayWindow alloc] initWithFrame:hostWindow.bounds];
        self.window.rootViewController = self.controller;
        self.window.windowLevel = UIWindowLevelNormal + 5;
        self.window.backgroundColor = UIColor.clearColor;
        self.window.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
        self.window.accessibilityIdentifier = @"SDKtools.overlay";
    } else if (scene && self.window.windowScene != scene && !self.controller.presentedViewController) {
        self.window.hidden = YES;
        self.window.windowScene = scene;
    }
    self.window.frame = scene ? scene.coordinateSpace.bounds : hostWindow.screen.bounds;
    self.window.hidden = NO;
    [self refresh];
}

- (void)becameActive:(NSNotification *)notification {
    [self installIfNeeded];
    [self presentPendingPreview];
    [self presentPendingSourceExport];
}

- (void)sceneEnteredBackground:(NSNotification *)notification {
    if (notification.object == self.window.windowScene) [self enteredBackground:notification];
}

- (void)enteredBackground:(NSNotification *)notification {
    self.window.hidden = YES;
    [self.statusTimer invalidate];
    self.statusTimer = nil;
    [self stopAllWithReason:@"background"];
}

- (void)recorderChanged:(NSNotification *)notification {
    // Limits and background handling can stop JSON independently. Do not leave
    // a screen recording running after its paired capture has ended.
    if (!STRecorder.shared.recording && self.ownsReplayKit) {
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    }
    [self refresh];
}

- (void)refresh {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self refresh]; }); return; }
    [self.controller refresh];
    BOOL active = UIApplication.sharedApplication.applicationState == UIApplicationStateActive;
    BOOL needed = active && (self.controller.expanded || STRecorder.shared.coveredAttemptPending || STRecorder.shared.autoplayEnabled || STRecorder.shared.autoplayBusy || STRecorder.shared.xrayEnabled || STBilliardsRuntime.shared.enabled || STRecorder.shared.cardEarlyActive || STRecorder.shared.cardHintsEnabled || STRecorder.shared.detectedGameDetectionActive || STRecorder.shared.sourceExportBusy || (self.controller.expanded && (STRecorder.shared.recording || self.videoState != STVideoIdle || STRecorder.shared.autoplayEnabled || STRecorder.shared.autoplayBusy || STRecorder.shared.xrayEnabled)) || self.noticeExpires > CACurrentMediaTime());
    if (needed && !self.statusTimer) {
        __weak typeof(self) weakSelf = self;
        self.statusTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer *timer) { [weakSelf refresh]; }];
    } else if (!needed && self.statusTimer) {
        [self.statusTimer invalidate];
        self.statusTimer = nil;
    }
}

- (void)showNotice:(NSString *)notice {
    self.notice = notice;
    self.noticeExpires = CACurrentMediaTime() + 8;
    [self refresh];
}

- (void)startCapture {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar antes de iniciar outra captura."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (STRecorder.shared.recording) return;
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize ou salve o vídeo anterior antes de iniciar outra captura."];
        return;
    }
    [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura não iniciou. Tente novamente com o app aberto."];
        return;
    }
    [self showNotice:@"Diagnóstico iniciado. Jogue um pouco; depois pare e exporte em Suporte."];
}

- (void)detectNewGame {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar antes de identificar outro jogo."]; return; }
    STRecorder *recorder = STRecorder.shared;
    if (recorder.detectedGameDetectionActive) {
        [recorder cancelNewGameDetection]; [self showNotice:@"Detecção cancelada."]; return;
    }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController || ![recorder beginNewGameDetection]) {
        [self showNotice:@"Finalize a captura ou ação em andamento antes de detectar outro jogo."]; return;
    }
    [self showNotice:@"Abra outro minigame. Depois volte a Suporte e toque Capturar jogo identificado."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)confirmNewGame {
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize o vídeo ou a janela aberta antes de confirmar a captura."]; return;
    }
    if (![STRecorder.shared confirmNewGameCapture]) {
        [self showNotice:@"O jogo mudou ou ainda está carregando. Aguarde a nova detecção."]; return;
    }
    [self showNotice:@"JSON iniciado. Jogue por 30–60 s; depois toque Parar e Exportar relatório."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)traceReturn {
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (STRecorder.shared.returnTraceActive) {
        [self showNotice:@"Rastreamento já ativo. Use os poderes e o armazém originais, depois pare e exporte."];
        return;
    }
    if (!STRecorder.shared.recording) [self startCapture];
    if (!STRecorder.shared.recording) return;
    if (![STRecorder.shared beginReturnTrace]) {
        [self showNotice:@"Não foi possível iniciar o rastreamento nesta captura. Pare e exporte o relatório atual."];
        return;
    }
    [self showNotice:@"Rastreamento ativo. Use os poderes e o armazém no jogo. Depois pare a captura e exporte o JSON."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)traceCardEntry {
    STRecorder *recorder=STRecorder.shared;
    if (recorder.cardEarlyActive) { [recorder stopCardEarlyCapture]; [self showNotice:@"Captura encerrada. Exporte o JSON de Cartas."]; return; }
    if (STBilliardsRuntime.shared.enabled || self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Finalize o bilhar, vídeo ou janela aberta antes de capturar Cartas."]; return; }
    if (![recorder beginCardEarlyCapture]) { [self showNotice:recorder.cardEarlyStatusText]; return; }
    [self showNotice:@"Captura armada. Entre em Ah, minha carta e jogue por 90 s."];
    if (self.controller.expanded) [self.controller togglePanel];
}
- (void)toggleCardHints {
    STRecorder *recorder=STRecorder.shared;
    if (!recorder.cardHintsEnabled && ![self clientAllowsGame:STClientGameCards]) return;
    if (recorder.cardEarlyActive || STBilliardsRuntime.shared.enabled) { [self showNotice:@"Pare a captura ou o bilhar antes de ativar os marcadores."]; return; }
    if (self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Finalize o vídeo ou a janela aberta antes de usar Cartas."]; return; }
    if (![recorder setCardHintsEnabled:!recorder.cardHintsEnabled]) [self showNotice:recorder.cardHintsStatusText];
    else [self showNotice:recorder.cardHintsEnabled?@"Etiquetas: total de cartas e ? desconhecidas. X = cor não recebida; círculos não são a quantidade da mão.":@"Marcadores desativados."];
    [self refresh];
}

- (void)sampleCardMenuNow {
    STRecorder *recorder=STRecorder.shared;
    if (recorder.cardEarlyActive || STBilliardsRuntime.shared.enabled || self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Pare a captura, bilhar, vídeo ou janela aberta antes de injetar o amostrador."]; return;
    }
    if (![recorder injectCardColorsAndReadRoot]) [self showNotice:recorder.cardHintsStatusText];
    else [self showNotice:@"Amostragem local solicitada. Confira hooks e cores por mão no menu. Não envia comandos ao jogo."];
    [self refresh];
}

- (void)toggleBilliards {
    STBilliardsRuntime *runtime=STBilliardsRuntime.shared;
    if (runtime.enabled) { [runtime stopWithReason:@"user"]; [self refresh]; return; }
    if (![self clientAllowsGame:STClientGameBilliards]) return;
    if (STRecorder.shared.cardEarlyActive || STRecorder.shared.cardHintsEnabled || STRecorder.shared.cardHintsBusy) { [self showNotice:@"Pare a captura ou os marcadores de Cartas antes de ativar o bilhar."]; return; }
    if (self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Feche a janela ou a captura aberta antes de ativar o bilhar."]; return;
    }
    NSError *error=nil;
    if (![runtime startInWindow:self.window error:&error]) {
        [self showNotice:error.localizedDescription ?: @"Não foi possível iniciar a leitura do bilhar."]; return;
    }
    self.noticeExpires=0;
    if (self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)toggleBilliardsAim {
    STBilliardsRuntime *r=STBilliardsRuntime.shared;
    if (r.automationMode==1) { [r pauseAutomationWithReason:@"user"]; [self refresh]; return; }
    if (![self clientAllowsGame:STClientGameBilliards]) return;
    if (!r.enabled) [self toggleBilliards];
    if (!r.enabled) return;
    r.automationMode=1;
    if (self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}
- (void)toggleBilliardsAuto {
    STBilliardsRuntime *r=STBilliardsRuntime.shared;
    if (r.automationMode==2) { [r pauseAutomationWithReason:@"user"]; [self refresh]; return; }
    if (![self clientAllowsGame:STClientGameBilliards]) return;
    if (!r.enabled) [self toggleBilliards];
    if (!r.enabled) return;
    r.automationMode=2;
    if (self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}
- (void)exportBilliardsLive {
    if (STRecorder.shared.sourceExportBusy || self.videoState!=STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize a exportação ou janela aberta antes de compartilhar."]; return;
    }
    NSError *error=nil;
    NSURL *url=[STBilliardsRuntime.shared exportReportWithError:&error];
    if (!url) { [self showNotice:error.localizedDescription ?: @"Não foi possível gerar o diagnóstico do bilhar."]; return; }
    self.pendingSourceExportURL=url;
    self.pendingSourceExportIsBilliards=YES;
    [self presentPendingSourceExport];
    [self refresh];
}

- (void)toggleTurbo {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
 [STRecorder.shared setTurboEnabled:self.controller.turboSwitch.isOn]; [self refresh]; }
- (void)toggleSuperFast {
 if (STRecorder.shared.recording || STRecorder.shared.sourceExportBusy) { [self refresh]; return; }
 [STRecorder.shared setSuperFastEnabled:self.controller.superFastSwitch.isOn]; [self refresh]; }
- (void)toggleExtendedPlanning {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
 [STRecorder.shared setExtendedPlanning:self.controller.planningSwitch.isOn]; [self refresh]; }
- (void)toggleAutoPowers {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
 [STRecorder.shared setPowersEnabled:self.controller.powersSwitch.isOn]; [self refresh]; }

- (void)testCoveredCard {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
    if (self.controller.presentedViewController || self.pendingPreview || self.videoState!=STVideoIdle) return;
    BOOL submitted=[STRecorder.shared performCoveredAttempt];
    [self showNotice:submitted ? @"One-card test requested. Checking the game state." :
        ((STRecorder.shared.autoplayBusy || STRecorder.shared.returnActionBusy) ? @"Wait for the current read or action to finish." : STRecorder.shared.coveredAttemptStatusText)];
    // Keep the compact panel visible so acceptance/refusal/unknown is explicit.
    [self refresh];
}

- (void)testPenetrateZero {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
    if (self.controller.presentedViewController || self.pendingPreview || self.videoState!=STVideoIdle) return;
    BOOL submitted=[STRecorder.shared performPenetrateZeroAttempt];
    [self showNotice:submitted ? @"Penetrate test requested. Checking the game state." :
        ((STRecorder.shared.autoplayBusy || STRecorder.shared.returnActionBusy) ? @"Wait for the current read or action to finish." : STRecorder.shared.coveredAttemptStatusText)];
    [self refresh];
}

- (void)exportCoveredReport {
    if (!NSThread.isMainThread) return;
    if (UIApplication.sharedApplication.applicationState!=UIApplicationStateActive || self.window.hidden || !self.controller.view.window) {
        [self showNotice:@"Keep WePlay in the foreground to export the test report."]; return;
    }
    if (self.controller.presentedViewController || self.pendingPreview) {
        [self showNotice:@"Close the open window before sharing the test report."]; return;
    }
    NSError *error=nil;
    NSURL *url=[STRecorder.shared writeCoveredAttemptReportWithError:&error];
    if (!url.isFileURL) {
        [self showNotice:@"Could not save the test report. Check free space and try again."]; return;
    }
    UIActivityViewController *share=[[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    UIButton *anchor=self.controller.coveredReportButton;
    share.popoverPresentationController.sourceView=anchor;
    share.popoverPresentationController.sourceRect=anchor.bounds;
    __weak STOverlay *weakSelf=self;
    share.completionWithItemsHandler=^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        (void)type; (void)items;
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:shareError ? @"The test report was saved, but sharing failed. Export it again." :
                (completed ? @"Test report shared." : @"Test report saved. You can export it again.")];
        });
        // The saved report remains on disk even when sharing is cancelled.
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)toggleAutoplay {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (STRecorder.shared.autoplayEnabled) {
        [STRecorder.shared pauseAutoplayWithReason:@"user"];
        [self showNotice:STRecorder.shared.autoplayStatusText];
        return;
    }
    if (![self clientAllowsGame:STClientGameAlpaca]) return;
    if ([STRecorder.shared startAutoplay]) {
        self.noticeExpires = 0;
        if (self.controller.expanded) [self.controller togglePanel];
    } else {
        [self showNotice:STRecorder.shared.autoplayBusy ? @"Aguarde a ação já enviada terminar antes de retomar." :
            (STRecorder.shared.recording ? @"Pare a captura antes de iniciar o autoplay." : @"Entre na partida e feche as janelas do jogo antes de iniciar.")];
    }
    [self refresh];
}

- (void)shareLAN {
    STRecorder *r=STRecorder.shared;
    if(!r.lanSharingEnabled && ![self clientAllowsGame:STClientGameAlpaca])return;
    NSError *error=nil;if(!r.lanSharingEnabled && ![r startLANSharingWithError:&error]){[self showNotice:error.localizedDescription ?: @"LAN unavailable. Connect to private Wi-Fi."];return;}
    UIPasteboard.generalPasteboard.string=r.lanSharingURL;
    [self showNotice:@"LAN link copied. Open it on the PC and enter the code shown here. HTTP is not encrypted."];[self refresh];
}
- (void)stopLAN { [STRecorder.shared stopLANSharing];[self showNotice:@"LAN sharing stopped. Remote Auto paused."];[self refresh]; }

- (void)toggleXray {
    if (self.controller.xraySwitch.isOn && ![self clientAllowsGame:STClientGameAlpaca]) { self.controller.xraySwitch.on=STRecorder.shared.xrayEnabled; return; }
    if (STBilliardsRuntime.shared.enabled) { self.controller.xraySwitch.on=NO; [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    [STRecorder.shared setXrayEnabled:self.controller.xraySwitch.isOn];
    [self refresh];
}

- (void)toggleDiagnostic {
    STRecorder *recorder = STRecorder.shared;
    if (recorder.recording || recorder.detectedGameDetectionActive || self.videoState != STVideoIdle) {
        [self stopCapture];
        [self refresh];
        return;
    }
    [self startCapture];
    if (recorder.recording && self.controller.expanded) [self.controller togglePanel];
}

- (void)changeXrayDepth {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;

    STLayerDepthSlider *slider = self.controller.xrayDepthSlider;
    NSInteger depth = MAX(1, MIN(4, (NSInteger)(slider.value + 0.5f)));
    [slider setValue:(float)depth animated:NO];
    STSetLabelText(self.controller.xrayDepthLabel, [NSString stringWithFormat:@"Camadas abaixo: %ld", (long)depth]);
    STLocalizeAccessibilityValue(slider,[NSString stringWithFormat:depth == 1 ? @"%ld camada abaixo" : @"%ld camadas abaixo", (long)depth]);
    // Continuous touch events within the same step do not trigger new reads.
    if (depth == self.controller.lastRequestedXrayDepth) return;
    self.controller.lastRequestedXrayDepth = depth;
    [STRecorder.shared setXrayDepth:depth];
}

- (void)runWarehouseTest:(NSString *)command {
    if (STBilliardsRuntime.shared.enabled || STRecorder.shared.sourceExportBusy || self.controller.presentedViewController || self.pendingPreview ||
        self.videoState==STVideoStarting || self.videoState==STVideoStopping) { [self showNotice:@"Feche janelas e desative o Bilhar antes do teste."]; return; }
    __weak STOverlay *weakSelf=self;
    BOOL submitted=[STRecorder.shared performWarehouseTestCommand:command update:^(NSDictionary *result) {
        STOverlay *s=weakSelf;if (!s) return;if ([result[@"status"] isEqual:@"blocked"] && !STRecorder.shared.warehouseTestStarted)
            [s showNotice:@"Teste não armado. Pause o autoplay, aguarde a jogada e confira seu slot vazio bloqueado."];
        else [s showNotice:STRecorder.shared.warehouseTestStatusText];[s refresh];
    }];
    if (submitted && [command isEqual:@"arm"] && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}
- (void)testWarehouseLock { [self runWarehouseTest:STRecorder.shared.warehouseTestStarted ? @"poll" : @"arm"]; }
- (void)cancelWarehouseTest { [self runWarehouseTest:@"cancel"]; }

- (void)openWarehouse {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;

    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.controller.presentedViewController || self.pendingPreview ||
        self.videoState == STVideoStarting || self.videoState == STVideoStopping) {
        [self showNotice:@"Feche a janela aberta e aguarde o vídeo terminar de iniciar ou salvar."];
        return;
    }
    [self showNotice:@"Conferindo seu armazém…"];
    __weak STOverlay *weakSelf = self;
    BOOL accepted = [STRecorder.shared openOwnWarehouseWithUpdate:^(NSDictionary *result) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        NSString *status = result[@"status"], *reason = result[@"reason"];
        if ([status isEqualToString:@"original_event_dispatched"]) {
            [strongSelf showNotice:@"Pedido enviado. Confira a seleção do armazém no jogo."];
        } else if ([status isEqualToString:@"dispatch_uncertain"]) {
            [strongSelf showNotice:@"A resposta ainda não foi confirmada. Aguarde e confira o armazém no jogo."];
        } else if ([reason isEqualToString:@"selection_already_open"]) {
            [strongSelf showNotice:@"A seleção do armazém já está aberta."];
        } else if ([reason isEqualToString:@"own_slot_locked"]) {
            [strongSelf showNotice:@"Seu espaço está bloqueado nesta partida. O jogo precisa liberá-lo."];
        } else if ([reason isEqualToString:@"own_slot_occupied"]) {
            [strongSelf showNotice:@"Seu espaço já está ocupado. Confira as cartas no armazém."];
        } else if ([reason isEqualToString:@"owner_unknown"]) {
            [strongSelf showNotice:@"Não foi possível identificar seu armazém nesta tela."];
        } else if ([@[@"return_action_pending", @"physical_operation_pending", @"cleanup_pending"] containsObject:reason]) {
            [strongSelf showNotice:@"Uma ação ainda está em andamento. Aguarde antes de tentar novamente."];
        } else if ([@[@"native_modal_visible", @"modal_visible", @"native_view_obscured", @"ambiguous_window_overlap"] containsObject:reason]) {
            [strongSelf showNotice:@"Feche a janela aberta no jogo antes de abrir o armazém."];
        } else {
            [strongSelf showNotice:@"Seu armazém não está disponível nesta tela. Entre na partida e tente novamente."];
        }
        [strongSelf refresh];
    }];
    if (accepted && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)openLeftPower { [self performPowerSlot:@"left" command:@"open"]; }
- (void)openCenterPower { [self performPowerSlot:@"center" command:@"open"]; }
- (void)openRightPower { [self performPowerSlot:@"right" command:@"open"]; }
- (void)confirmPower { [self performPowerSlot:@"current" command:@"confirm"]; }

- (void)performPowerSlot:(NSString *)slot command:(NSString *)command {
    if (![self clientAllowsGame:STClientGameAlpaca]) return;

    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar para usar o Alpaca."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.controller.presentedViewController || self.pendingPreview ||
        self.videoState == STVideoStarting || self.videoState == STVideoStopping) {
        [self showNotice:@"Feche a janela aberta e aguarde o vídeo terminar de iniciar ou salvar."];
        return;
    }
    [self showNotice:[command isEqual:@"confirm"] ? @"Conferindo o poder aberto e o estoque…" : @"Abrindo o poder original…"];
    __weak STOverlay *weakSelf = self;
    BOOL accepted = [STRecorder.shared performOriginalPowerAtSlot:slot command:command update:^(NSDictionary *result) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        NSString *status = result[@"status"], *reason = result[@"reason"];
        if ([status isEqualToString:@"original_event_dispatched"]) {
            [strongSelf showNotice:[command isEqual:@"confirm"] ? @"Uso solicitado ao jogo. Aguarde o efeito antes de usar novamente." : @"Confira o efeito e confirme Usar item no jogo."];
        } else if ([status isEqualToString:@"dispatch_uncertain"]) {
            [strongSelf showNotice:[result[@"physicalPending"] boolValue] ?
                @"Resposta incerta. Aguarde o jogo; o poder permanece bloqueado enquanto essa chamada não terminar." :
                @"A resposta não pôde ser confirmada. Confira a tela do jogo antes de tocar novamente."];
        } else if ([@[@"return_action_pending", @"physical_operation_pending", @"cleanup_pending"] containsObject:reason]) {
            [strongSelf showNotice:@"Há uma leitura ou ação em andamento. Aguarde antes de tocar novamente."];
        } else if ([@[@"native_modal_visible", @"modal_visible", @"native_view_obscured", @"ambiguous_window_overlap"] containsObject:reason]) {
            [strongSelf showNotice:@"Já existe uma janela aberta. Resolva ou feche essa janela no jogo."];
        } else if ([@[@"disabled_control", @"button_unavailable", @"stock_unavailable", @"stock_empty"] containsObject:reason]) {
            [strongSelf showNotice:@"O poder não está disponível ou está sem estoque. Confira a partida."];
        } else if ([@[@"confirmation_unavailable", @"confirmation_ambiguous", @"prop_mismatch"] containsObject:reason]) {
            [strongSelf showNotice:@"Abra o poder desejado e confira sua confirmação no jogo. A janela pode fechar após alguns segundos."];
        } else if ([@[@"unsupported_application", @"engine_version", @"game_type_abi_mismatch"] containsObject:reason]) {
            [strongSelf showNotice:@"Esta versão do jogo não corresponde ao controle verificado para US 6.6.2."];
        } else {
            [strongSelf showNotice:@"Não foi possível identificar esse poder nesta tela. Entre na partida e exporte um relatório se continuar."];
        }
        [strongSelf refresh];
    }];
    // Only an accepted request can collapse the panel. Rejections keep the
    // explanation and controls visible. No synthetic tap or automatic retry.
    if (accepted && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)stopCapture { [self stopAllWithReason:@"user"]; }

- (void)stopAllWithReason:(NSString *)reason {
    [STRecorder.shared stopCardEarlyCaptureWithReason:reason];
    [STRecorder.shared setCardHintsEnabled:NO];
    [STBilliardsRuntime.shared stopWithReason:reason];
    if (STRecorder.shared.detectedGameDetectionActive) {
        [STRecorder.shared cancelNewGameDetection];
        [self showNotice:@"Detecção cancelada."]; return;
    }
    if (self.videoState != STVideoIdle) {
        self.pendingStopReason = reason;
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    } else {
        [STRecorder.shared stopRecordingWithReason:reason];
        [self showNotice:@"Captura encerrada. O relatório está pronto para exportar."];
    }
}

- (void)markAlpaca {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"crazyAlpacaEntered" details:@{@"source": @"user"}];
    [self showNotice:@"Entrada no Crazy Alpaca marcada no relatório."];
}

- (void)markMatch {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"matchStarted" details:@{@"source": @"user"}];
    [self showNotice:@"Início da partida marcado no relatório."];
}

- (void)exportReport {
    [STBilliardsRuntime.shared stopWithReason:@"export"];
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.pendingPreview) { [self showNotice:@"Salve ou feche a prévia do vídeo antes de exportar."]; [self presentPendingPreview]; return; }
    if (STRecorder.shared.recording || STRecorder.shared.cardEarlyActive || self.videoState != STVideoIdle) { [self showNotice:@"Pare a captura antes de exportar o relatório."]; return; }
    if (self.controller.presentedViewController) { [self showNotice:@"Feche a janela aberta antes de exportar."]; return; }
    NSError *error = nil;
    NSURL *url = [STRecorder.shared writeReportWithError:&error];
    if (!url) {
        if ([error.domain isEqualToString:@"SDKtools.Recorder"] && error.code == 1)
            [self showNotice:@"Ainda não há dados. Use uma ferramenta ou toque Suporte → Iniciar diagnóstico antes de exportar."];
        else
            [self showNotice:@"Não foi possível gerar o JSON. Confira o espaço livre e tente novamente."];
        return;
    }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    share.popoverPresentationController.sourceView = self.controller.exportButton;
    share.popoverPresentationController.sourceRect = self.controller.exportButton.bounds;
    __weak typeof(self) weakSelf = self;
    share.completionWithItemsHandler = ^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:completed ? @"Relatório compartilhado." : @"Relatório disponível para exportar novamente."];
            [weakSelf presentPendingPreview];
        });
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)exportGameSources {
    [STBilliardsRuntime.shared stopWithReason:@"export"];
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"A exportação do código já está em andamento."]; return; }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Pare o vídeo e feche a prévia ou janela aberta antes de exportar o código."];
        return;
    }
    if (self.pendingSourceExportURL) { [self presentPendingSourceExport]; return; }
    [self showNotice:@"Preparando o código do jogo. Aguarde sem sair da partida."];
    __weak STOverlay *weakSelf = self;
    [STRecorder.shared exportCurrentGameSourcesWithCompletion:^(NSURL *url, NSError *error) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        if (!url.isFileURL || error) {
            [strongSelf showNotice:error.localizedDescription ?: @"Não foi possível gerar o arquivo. Abra uma partida e tente novamente."];
            [strongSelf refresh];
            return;
        }
        strongSelf.pendingSourceExportURL = url;
        strongSelf.pendingSourceExportIsBilliards = NO;
        [strongSelf showNotice:@"Código pronto. Escolha Salvar em Arquivos ou compartilhar o JSON."];
        [strongSelf presentPendingSourceExport];
        [strongSelf refresh];
    }];
    [self refresh];
}

- (void)exportBilliardsResources {
    [STBilliardsRuntime.shared stopWithReason:@"export"];
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Uma exportação já está em andamento."]; return; }
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Pare o vídeo e feche a prévia ou janela aberta antes de exportar os recursos."]; return;
    }
    if (self.pendingSourceExportURL) { [self presentPendingSourceExport]; return; }
    [self showNotice:@"Preparando os recursos. Mantenha o bilhar aberto até terminar."];
    __weak STOverlay *weakSelf = self;
    [STRecorder.shared exportBilliardsResourcesWithCompletion:^(NSURL *url, NSError *error) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        if (!url.isFileURL || error) {
            [strongSelf showNotice:error.localizedDescription ?: @"Não foi possível gerar o arquivo de recursos. Tente novamente."];
            [strongSelf refresh]; return;
        }
        strongSelf.pendingSourceExportURL = url;
        strongSelf.pendingSourceExportIsBilliards = YES;
        NSUInteger exported = [STRecorder.shared.billiardsResourceExportDiagnostic[@"counts"][@"filesExported"] unsignedIntegerValue];
        [strongSelf showNotice:exported ? @"Recursos prontos. Salve em Arquivos ou compartilhe o JSON." :
            @"Diagnóstico pronto; recursos ainda não encontrados. Abra o bilhar, aguarde o carregamento e exporte novamente."];
        [strongSelf presentPendingSourceExport];
        [strongSelf refresh];
    }];
    [self refresh];
}

- (void)presentPendingSourceExport {
    if (!self.pendingSourceExportURL || STRecorder.shared.sourceExportBusy ||
        self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController ||
        UIApplication.sharedApplication.applicationState != UIApplicationStateActive || self.window.hidden) return;
    NSURL *url = self.pendingSourceExportURL;
    BOOL billiards = self.pendingSourceExportIsBilliards;
    self.pendingSourceExportURL = nil;
    self.pendingSourceExportIsBilliards = NO;
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    UIView *anchor = self.controller.bubble;
    share.popoverPresentationController.sourceView = anchor;
    share.popoverPresentationController.sourceRect = anchor.bounds;
    __weak STOverlay *weakSelf = self;
    share.completionWithItemsHandler = ^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:completed ? (billiards ? @"Arquivo do bilhar compartilhado." : @"Código do jogo compartilhado.") : @"Arquivo gerado. Você pode exportar novamente pelo menu."];
            [weakSelf presentPendingPreview];
        });
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)toggleVideo {
    if (STBilliardsRuntime.shared.enabled) { [self showNotice:@"Desative a leitura do bilhar antes de iniciar outra captura."]; return; }
    if (STRecorder.shared.sourceExportBusy) { [self showNotice:@"Aguarde a exportação terminar."]; return; }
    if (self.videoState == STVideoRecording) { [self stopVideo]; return; }
    if (self.videoState != STVideoIdle) return;
    if (self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Feche ou salve a prévia anterior antes de gravar novamente."]; return; }
    RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
    if (!recorder.isAvailable || recorder.isRecording) { [self showNotice:@"A gravação de tela não está disponível agora. O JSON pode ser gravado normalmente."]; return; }
    if (recorder.delegate && recorder.delegate != self.replayDelegate) { [self showNotice:@"O app já utiliza o gravador de tela. O JSON está ativo; para vídeo, use a Central de Controle."]; return; }
    if (!STRecorder.shared.recording) [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura JSON não iniciou. O vídeo não foi aberto."];
        return;
    }
    self.videoCaptureSessionIdentifier = STRecorder.shared.captureSessionIdentifier;
    NSUInteger generation = ++self.videoGeneration;
    self.previousReplayDelegate = recorder.delegate;
    self.previousMicrophoneEnabled = recorder.isMicrophoneEnabled;
    self.previousCameraEnabled = recorder.isCameraEnabled;
    self.replayDelegate = [STReplaySessionDelegate new];
    self.replayDelegate.owner = self;
    self.replayDelegate.generation = generation;
    recorder.delegate = self.replayDelegate;
    recorder.microphoneEnabled = NO;
    recorder.cameraEnabled = NO;
    self.ownsReplayKit = YES;
    self.videoState = STVideoStarting;
    self.stopWhenStarted = NO;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [recorder startRecordingWithHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            if (error) {
                [strongSelf markVideoEndWithError:error];
                [strongSelf finishVideoWithPreview:nil];
                [strongSelf showNotice:STRecorder.shared.recording ? @"O vídeo não iniciou. O JSON continua; você também pode gravar pela Central de Controle." : @"O vídeo não iniciou. A captura foi encerrada; o JSON está disponível para exportar."];
                return;
            }
            strongSelf.videoState = STVideoRecording;
            strongSelf.videoStarted = CACurrentMediaTime();
            [STRecorder.shared markEvent:@"visualRecordingStarted" details:@{@"source": @"replaykit", @"enabled": @YES}];
            if (strongSelf.stopWhenStarted || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) [strongSelf stopVideo];
            else [strongSelf showNotice:@"Vídeo iniciado sem microfone. Feche o menu para continuar."];
        });
    }];
}

- (void)stopVideo {
    if (self.videoState != STVideoRecording || !self.ownsReplayKit) return;
    self.videoState = STVideoStopping;
    NSUInteger generation = self.videoGeneration;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [RPScreenRecorder.sharedRecorder stopRecordingWithHandler:^(RPPreviewViewController *preview, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            [strongSelf markVideoEndWithError:error];
            [strongSelf finishVideoWithPreview:preview];
            if (error) [strongSelf showNotice:@"O vídeo terminou com erro. Exporte o JSON; a prévia será exibida se estiver disponível."];
        });
    }];
}

- (void)markVideoEndWithError:(NSError *)error {
    NSTimeInterval elapsed = self.videoStarted > 0 ? MAX(0, CACurrentMediaTime() - self.videoStarted) : 0;
    if (self.videoCaptureSessionIdentifier) {
        [STRecorder.shared markVisualRecordingEndForSessionIdentifier:self.videoCaptureSessionIdentifier failed:(error != nil) durationSeconds:elapsed];
    }
}

- (void)finishVideoWithPreview:(RPPreviewViewController *)preview {
    if (self.ownsReplayKit) {
        RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
        if (recorder.delegate == self.replayDelegate) {
            recorder.delegate = self.previousReplayDelegate;
            recorder.microphoneEnabled = self.previousMicrophoneEnabled;
            recorder.cameraEnabled = self.previousCameraEnabled;
        }
    }
    self.ownsReplayKit = NO;
    self.videoState = STVideoIdle;
    self.videoStarted = 0;
    self.stopWhenStarted = NO;
    self.previousReplayDelegate = nil;
    self.replayDelegate = nil;
    self.videoCaptureSessionIdentifier = nil;
    if (self.pendingStopReason) {
        NSString *reason = self.pendingStopReason;
        self.pendingStopReason = nil;
        [STRecorder.shared stopRecordingWithReason:reason];
    }
    if (preview) {
        preview.previewControllerDelegate = self;
        if (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) {
            preview.modalPresentationStyle = UIModalPresentationPopover;
            preview.popoverPresentationController.sourceView = self.controller.bubble;
            preview.popoverPresentationController.sourceRect = self.controller.bubble.bounds;
            preview.preferredContentSize = CGSizeMake(540, 620);
        } else preview.modalPresentationStyle = UIModalPresentationFullScreen;
        self.pendingPreview = preview;
    }
    [self refresh];
    [self presentPendingPreview];
}

- (void)presentPendingPreview {
    if (!self.pendingPreview || self.controller.presentedViewController || UIApplication.sharedApplication.applicationState != UIApplicationStateActive || self.window.hidden) return;
    RPPreviewViewController *preview = self.pendingPreview;
    self.pendingPreview = nil;
    [self.controller presentViewController:preview animated:YES completion:nil];
}

- (void)previewControllerDidFinish:(RPPreviewViewController *)previewController {
    [previewController dismissViewControllerAnimated:YES completion:^{ [self showNotice:@"Vídeo encerrado. Exporte também o JSON para analisar os dois juntos."]; [self presentPendingSourceExport]; }];
}

- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)screenRecorder preview:(RPPreviewViewController *)previewViewController error:(NSError *)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.ownsReplayKit || self.videoGeneration != generation || screenRecorder.isRecording) return;
        [self markVideoEndWithError:error];
        [self finishVideoWithPreview:previewViewController];
        [self showNotice:@"A gravação de vídeo foi encerrada pelo iOS. O relatório JSON continua disponível."];
    });
}

- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation {
    dispatch_async(dispatch_get_main_queue(), ^{ if (self.videoGeneration == generation) [self refresh]; });
}
@end

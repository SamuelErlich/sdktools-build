#import "STOverlay.h"
#import "STRecorder.h"
#import <ReplayKit/ReplayKit.h>
#import <QuartzCore/QuartzCore.h>

static UIColor *STOrange(void) { return [UIColor colorWithRed:1 green:0.36 blue:0.12 alpha:1]; }
static UIColor *STMuted(void) { return [UIColor colorWithWhite:0.67 alpha:1]; }

typedef NS_ENUM(NSUInteger, STVideoState) {
    STVideoIdle, STVideoStarting, STVideoRecording, STVideoStopping
};

@class STOverlayController;
@class STReplaySessionDelegate;

@interface STOverlay () <RPPreviewViewControllerDelegate>
@property (nonatomic, strong) STOverlayWindow *window;
@property (nonatomic, strong) STOverlayController *controller;
@property (nonatomic, strong) NSTimer *statusTimer;
@property (nonatomic, copy) NSString *notice;
@property (nonatomic) NSTimeInterval noticeExpires;
@property (nonatomic) STVideoState videoState;
@property (nonatomic) NSUInteger videoGeneration;
@property (nonatomic) NSTimeInterval videoStarted;
@property (nonatomic) BOOL stopWhenStarted;
@property (nonatomic) BOOL ownsReplayKit;
@property (nonatomic) BOOL previousMicrophoneEnabled;
@property (nonatomic) BOOL previousCameraEnabled;
@property (nonatomic, weak) id<RPScreenRecorderDelegate> previousReplayDelegate;
@property (nonatomic, strong, nullable) STReplaySessionDelegate *replayDelegate;
@property (nonatomic, copy, nullable) NSString *videoCaptureSessionIdentifier;
@property (nonatomic, copy, nullable) NSString *pendingStopReason;
@property (nonatomic, strong, nullable) RPPreviewViewController *pendingPreview;
- (void)refresh;
- (void)startCapture;
- (void)openReturn;
- (void)toggleAutoplay;
- (void)traceReturn;
- (void)stopCapture;
- (void)markAlpaca;
- (void)markMatch;
- (void)exportReport;
- (void)toggleVideo;
- (void)showNotice:(NSString *)notice;
- (void)stopAllWithReason:(NSString *)reason;
- (void)stopVideo;
- (void)markVideoEndWithError:(nullable NSError *)error;
- (void)finishVideoWithPreview:(nullable RPPreviewViewController *)preview;
- (void)presentPendingPreview;
- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)recorder preview:(nullable RPPreviewViewController *)preview error:(nullable NSError *)error;
- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation;
@end

/// A new delegate object binds callbacks to each recording generation. Reading
/// the current generation when an old callback arrives would not be sufficient.
@interface STReplaySessionDelegate : NSObject <RPScreenRecorderDelegate>
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic) NSUInteger generation;
@end

@implementation STReplaySessionDelegate
- (void)screenRecorder:(RPScreenRecorder *)recorder didStopRecordingWithPreviewViewController:(RPPreviewViewController *)preview error:(NSError *)error {
    [self.owner replayDidStopWithGeneration:self.generation recorder:recorder preview:preview error:error];
}
- (void)screenRecorderDidChangeAvailability:(RPScreenRecorder *)recorder {
    [self.owner replayAvailabilityChangedWithGeneration:self.generation];
}
@end

@interface STOverlayController : UIViewController
@property (nonatomic, weak) STOverlay *owner;
@property (nonatomic, strong) UIButton *bubble;
@property (nonatomic, strong) UIView *recordingDot;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UILabel *videoLabel;
@property (nonatomic, strong) UILabel *noticeLabel;
@property (nonatomic, strong) UILabel *collapsedNoticeLabel;
@property (nonatomic, strong) UIButton *returnTraceButton;
@property (nonatomic, strong) UIButton *returnActionButton;
@property (nonatomic, strong) UIButton *autoplayButton;
@property (nonatomic, strong) UILabel *autoplayLabel;
@property (nonatomic, strong) UIButton *startButton;
@property (nonatomic, strong) UIButton *stopButton;
@property (nonatomic, strong) UIButton *alpacaButton;
@property (nonatomic, strong) UIButton *matchButton;
@property (nonatomic, strong) UISwitch *includeVideoSwitch;
@property (nonatomic, strong) UIButton *exportButton;
@property (nonatomic) BOOL expanded;
@property (nonatomic) BOOL dragging;
@property (nonatomic) BOOL bubbleOnRight;
@property (nonatomic) CGFloat bubbleVerticalFraction;
- (BOOL)acceptsPoint:(CGPoint)point;
- (void)refresh;
@end

@implementation STOverlayWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    STOverlayController *controller = (STOverlayController *)self.rootViewController;
    if (![controller isKindOfClass:STOverlayController.class]) return nil;
    // Presented share sheets and ReplayKit previews need their complete bounds.
    if (!controller.presentedViewController && ![controller acceptsPoint:point]) return nil;
    return [super hitTest:point withEvent:event];
}
// This window deliberately does not override canBecomeKeyWindow or call
// makeKeyAndVisible. The host game retains keyboard, scene and input ownership.
@end

@implementation STOverlayController

- (void)loadView {
    self.view = [[UIView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.view.backgroundColor = UIColor.clearColor;
    self.view.accessibilityViewIsModal = NO;
    self.bubbleOnRight = YES;
    self.bubbleVerticalFraction = 0;

    self.bubble = [UIButton buttonWithType:UIButtonTypeCustom];
    self.bubble.backgroundColor = [UIColor colorWithRed:0.17 green:0.075 blue:0.04 alpha:0.96];
    self.bubble.layer.cornerRadius = 23;
    self.bubble.layer.borderColor = STOrange().CGColor;
    self.bubble.layer.borderWidth = 1.5;
    self.bubble.tintColor = STOrange();
    [self.bubble setImage:[UIImage systemImageNamed:@"square.stack.3d.up.fill"] forState:UIControlStateNormal];
    self.bubble.accessibilityLabel = @"SDKtools";
    self.bubble.accessibilityHint = @"Toque para abrir. Arraste para mudar de posição.";
    [self.bubble addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [self.bubble addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveBubble:)]];
    [self.view addSubview:self.bubble];

    self.collapsedNoticeLabel = [self label:@"" size:12 weight:UIFontWeightMedium color:UIColor.whiteColor];
    self.collapsedNoticeLabel.backgroundColor = [UIColor colorWithWhite:0.07 alpha:0.96];
    self.collapsedNoticeLabel.layer.cornerRadius = 10;
    self.collapsedNoticeLabel.layer.masksToBounds = YES;
    self.collapsedNoticeLabel.textAlignment = NSTextAlignmentCenter;
    self.collapsedNoticeLabel.userInteractionEnabled = NO;
    self.collapsedNoticeLabel.hidden = YES;
    [self.view addSubview:self.collapsedNoticeLabel];

    self.recordingDot = [[UIView alloc] initWithFrame:CGRectMake(34, 2, 9, 9)];
    self.recordingDot.backgroundColor = [UIColor colorWithRed:1 green:0.22 blue:0.22 alpha:1];
    self.recordingDot.layer.cornerRadius = 4.5;
    self.recordingDot.layer.borderColor = UIColor.blackColor.CGColor;
    self.recordingDot.layer.borderWidth = 1;
    self.recordingDot.userInteractionEnabled = NO;
    self.recordingDot.hidden = YES;
    [self.bubble addSubview:self.recordingDot];

    self.panel = [UIView new];
    self.panel.hidden = YES;
    self.panel.backgroundColor = [UIColor colorWithRed:0.055 green:0.055 blue:0.065 alpha:0.98];
    self.panel.layer.cornerRadius = 22;
    self.panel.layer.borderColor = [UIColor colorWithRed:0.6 green:0.22 blue:0.09 alpha:0.7].CGColor;
    self.panel.layer.borderWidth = 1;
    self.panel.layer.shadowColor = UIColor.blackColor.CGColor;
    self.panel.layer.shadowOpacity = 0.3;
    self.panel.layer.shadowRadius = 16;
    self.panel.layer.shadowOffset = CGSizeMake(0, 5);
    [self.view addSubview:self.panel];

    UIScrollView *scroll = [UIScrollView new];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    scroll.alwaysBounceVertical = NO;
    scroll.showsVerticalScrollIndicator = YES;
    scroll.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    [self.panel addSubview:scroll];
    UIStackView *stack = [[UIStackView alloc] init];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 10;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:self.panel.topAnchor constant:16],
        [scroll.bottomAnchor constraintEqualToAnchor:self.panel.bottomAnchor constant:-16],
        [scroll.leadingAnchor constraintEqualToAnchor:self.panel.leadingAnchor constant:16],
        [scroll.trailingAnchor constraintEqualToAnchor:self.panel.trailingAnchor constant:-16],
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor],
        [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor],
        [stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor],
        [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor]
    ]];

    UIStackView *header = [[UIStackView alloc] init];
    header.axis = UILayoutConstraintAxisHorizontal;
    header.alignment = UIStackViewAlignmentCenter;
    UILabel *title = [self label:@"SDKtools" size:25 weight:UIFontWeightBold color:UIColor.whiteColor];
    [header addArrangedSubview:title];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    [close setImage:[UIImage systemImageNamed:@"xmark.circle.fill"] forState:UIControlStateNormal];
    close.tintColor = STMuted();
    close.accessibilityLabel = @"Fechar menu";
    [close addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [close.widthAnchor constraintEqualToConstant:44].active = YES;
    [close.heightAnchor constraintEqualToConstant:44].active = YES;
    [header addArrangedSubview:close];
    [stack addArrangedSubview:header];
    [stack addArrangedSubview:[self label:@"US 6.6.2 · SDKtools V2.6" size:12 weight:UIFontWeightMedium color:STOrange()]];
    [stack addArrangedSubview:[self label:@"Ferramentas" size:16 weight:UIFontWeightSemibold color:UIColor.whiteColor]];
    self.autoplayButton = [self button:@"Iniciar autoplay" symbol:@"play.fill" action:@selector(toggleAutoplay) primary:YES];
    self.autoplayButton.accessibilityHint = @"Lê as cartas carregadas e joga uma por vez. Toque na partida para pausar. Retome pelo menu.";
    [stack addArrangedSubview:self.autoplayButton];
    self.autoplayLabel = [self label:@"Auto pausado" size:12 weight:UIFontWeightMedium color:STMuted()];
    [stack addArrangedSubview:self.autoplayLabel];
    [stack addArrangedSubview:[self label:@"Analisa a mesa antes de cada jogada e aguarda o resultado. Seu toque pausa o auto. Funciona sem iniciar gravação." size:12 weight:UIFontWeightRegular color:STMuted()]];
    self.returnActionButton = [self button:@"Poder central: abrir" symbol:@"arrow.uturn.backward" action:@selector(openReturn) primary:YES];
    self.returnActionButton.accessibilityHint = @"Abre o poder que ocupa o botão central no jogo. Confirme no jogo; usa o estoque original.";
    [stack addArrangedSubview:self.returnActionButton];
    [stack addArrangedSubview:[self label:@"Abre a confirmação do poder central atual. Confira o nome e o efeito no jogo antes de usar. O estoque original continua valendo." size:12 weight:UIFontWeightRegular color:STMuted()]];
    self.returnTraceButton = [self button:@"Rastrear poderes" symbol:@"waveform.path" action:@selector(traceReturn) primary:NO];
    self.returnTraceButton.accessibilityHint = @"Registra os controles, contadores e métodos locais dos poderes. Use o poder original, depois pare e exporte o JSON.";
    [stack addArrangedSubview:self.returnTraceButton];
    [stack addArrangedSubview:[self label:@"Para investigar o limite, ative antes de usar um poder. Deixe a confirmação aberta por 1 segundo, confirme no jogo e depois exporte o JSON. A captura inclui o contador e métodos locais dos controles identificados." size:12 weight:UIFontWeightRegular color:STMuted()]];
    [stack addArrangedSubview:[self label:@"Captura e relatório" size:16 weight:UIFontWeightSemibold color:UIColor.whiteColor]];
    [stack addArrangedSubview:[self label:@"Grave de 30 a 45 segundos do caminho ou da partida. O JSON registra os toques e a estrutura da cena; envie também o vídeo para conferir as peças." size:13 weight:UIFontWeightRegular color:STMuted()]];
    self.statusLabel = [self label:@"Captura parada" size:13 weight:UIFontWeightSemibold color:UIColor.whiteColor];
    self.statusLabel.font = [UIFont monospacedDigitSystemFontOfSize:13 weight:UIFontWeightSemibold];
    [stack addArrangedSubview:self.statusLabel];
    UIStackView *videoChoice = [UIStackView new];
    videoChoice.axis = UILayoutConstraintAxisHorizontal;
    videoChoice.alignment = UIStackViewAlignmentCenter;
    [videoChoice addArrangedSubview:[self label:@"Incluir vídeo da tela" size:13 weight:UIFontWeightMedium color:UIColor.whiteColor]];
    self.includeVideoSwitch = [UISwitch new];
    self.includeVideoSwitch.on = YES;
    self.includeVideoSwitch.onTintColor = STOrange();
    self.includeVideoSwitch.accessibilityLabel = @"Incluir vídeo da tela. Desative para gravar somente o JSON.";
    [videoChoice addArrangedSubview:self.includeVideoSwitch];
    [stack addArrangedSubview:videoChoice];
    self.startButton = [self button:@"Gravar caminho e partida" symbol:@"record.circle" action:@selector(startCapture) primary:YES];
    self.stopButton = [self button:@"Parar captura" symbol:@"stop.circle" action:@selector(stopCapture) primary:NO];
    UIStackView *captureRow = [[UIStackView alloc] initWithArrangedSubviews:@[self.startButton, self.stopButton]];
    captureRow.axis = UILayoutConstraintAxisVertical;
    captureRow.distribution = UIStackViewDistributionFillEqually;
    captureRow.spacing = 8;
    [stack addArrangedSubview:captureRow];

    self.videoLabel = [self label:@"Vídeo sem microfone; pode incluir áudio do app. Ao parar, salve ou compartilhe a prévia do iOS e depois exporte o JSON. Desative a opção acima para gravar só o JSON." size:11 weight:UIFontWeightRegular color:STMuted()];
    [stack addArrangedSubview:self.videoLabel];

    self.alpacaButton = [self button:@"Cheguei ao Crazy Alpaca" symbol:@"flag" action:@selector(markAlpaca) primary:NO];
    self.matchButton = [self button:@"Marcar início da partida" symbol:@"play.rectangle" action:@selector(markMatch) primary:NO];
    [stack addArrangedSubview:self.alpacaButton];
    [stack addArrangedSubview:self.matchButton];
    [stack addArrangedSubview:[self label:@"Os marcadores são manuais. O nome Crazy Alpaca / Sheep e os elementos do jogo serão confirmados cruzando JSON e vídeo." size:11 weight:UIFontWeightRegular color:STMuted()]];

    self.exportButton = [self button:@"Exportar relatório JSON" symbol:@"square.and.arrow.up" action:@selector(exportReport) primary:NO];
    [stack addArrangedSubview:self.exportButton];
    self.noticeLabel = [self label:@"" size:12 weight:UIFontWeightMedium color:STOrange()];
    [stack addArrangedSubview:self.noticeLabel];
    [stack addArrangedSubview:[self label:@"As telas de login e campos de texto não são transcritos para o JSON. O vídeo mostra o que estiver na tela: evite capturar senhas, mensagens e dados pessoais." size:11 weight:UIFontWeightRegular color:STMuted()]];
    [self.view bringSubviewToFront:self.bubble];
}

- (UILabel *)label:(NSString *)text size:(CGFloat)size weight:(UIFontWeight)weight color:(UIColor *)color {
    UILabel *label = [UILabel new];
    label.text = text;
    label.numberOfLines = 0;
    label.textColor = color;
    label.font = [UIFont systemFontOfSize:size weight:weight];
    label.adjustsFontForContentSizeCategory = YES;
    return label;
}

- (UIButton *)button:(NSString *)title symbol:(NSString *)symbol action:(SEL)action primary:(BOOL)primary {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setImage:[UIImage systemImageNamed:symbol] forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.tintColor = primary ? UIColor.whiteColor : STOrange();
    button.backgroundColor = primary ? [UIColor colorWithRed:0.8 green:0.22 blue:0.07 alpha:1] : [UIColor colorWithWhite:0.115 alpha:1];
    button.titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    button.titleLabel.numberOfLines = 2;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.layer.cornerRadius = 12;
    button.contentEdgeInsets = UIEdgeInsetsMake(11, 8, 11, 8);
    button.imageEdgeInsets = UIEdgeInsetsMake(0, -4, 0, 4);
    [button.heightAnchor constraintGreaterThanOrEqualToConstant:46].active = YES;
    [button addTarget:self.owner action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (CGRect)usableBounds {
    CGRect bounds = UIEdgeInsetsInsetRect(self.view.bounds, self.view.safeAreaInsets);
    return CGRectInset(bounds, 10, 8);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect safe = [self usableBounds];
    if (!self.dragging) {
        CGFloat x = self.bubbleOnRight ? CGRectGetMaxX(safe) - 46 : CGRectGetMinX(safe);
        CGFloat y = CGRectGetMinY(safe) + self.bubbleVerticalFraction * MAX(0, CGRectGetHeight(safe) - 46);
        self.bubble.frame = CGRectMake(x, y, 46, 46);
    }
    CGFloat width = MIN(360, CGRectGetWidth(safe));
    CGFloat height = MIN(660, MAX(120, CGRectGetHeight(safe) - 56));
    CGFloat x = self.bubbleOnRight ? CGRectGetMaxX(safe) - width : CGRectGetMinX(safe);
    CGFloat y = CGRectGetMinY(safe) + 56;
    self.panel.frame = CGRectMake(x, y, width, height);
    self.panel.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.panel.bounds cornerRadius:22].CGPath;
    BOOL compactStatus = !self.noticeLabel.text.length;
    CGFloat noticeWidth = MIN(compactStatus ? 200 : 300, CGRectGetWidth(safe));
    CGSize noticeSize = [self.collapsedNoticeLabel sizeThatFits:CGSizeMake(MAX(1, noticeWidth - 16), CGFLOAT_MAX)];
    CGFloat noticeHeight = MIN(MAX(compactStatus ? 26 : 50, noticeSize.height + (compactStatus ? 8 : 16)), CGRectGetHeight(safe));
    CGFloat noticeX = self.bubbleOnRight ? CGRectGetMaxX(safe) - noticeWidth : CGRectGetMinX(safe);
    CGFloat below = CGRectGetMaxY(self.bubble.frame) + 8;
    CGFloat noticeY = below + noticeHeight <= CGRectGetMaxY(safe) ? below : CGRectGetMinY(self.bubble.frame) - noticeHeight - 8;
    noticeY = MAX(CGRectGetMinY(safe), MIN(noticeY, CGRectGetMaxY(safe) - noticeHeight));
    self.collapsedNoticeLabel.frame = CGRectMake(noticeX, noticeY, noticeWidth, noticeHeight);
}

- (BOOL)acceptsPoint:(CGPoint)point {
    CGPoint local = [self.view convertPoint:point fromView:self.view.window];
    return CGRectContainsPoint(self.bubble.frame, local) || (self.expanded && CGRectContainsPoint(self.panel.frame, local));
}

- (void)togglePanel {
    self.expanded = !self.expanded;
    self.panel.hidden = !self.expanded;
    [self.bubble setImage:[UIImage systemImageNamed:self.expanded ? @"xmark" : @"square.stack.3d.up.fill"] forState:UIControlStateNormal];
    self.bubble.accessibilityLabel = self.expanded ? @"Fechar SDKtools" : @"Abrir SDKtools";
    [self.owner refresh];
}

- (void)moveBubble:(UIPanGestureRecognizer *)gesture {
    CGRect safe = [self usableBounds];
    if (gesture.state == UIGestureRecognizerStateBegan) self.dragging = YES;
    CGPoint delta = [gesture translationInView:self.view];
    CGPoint center = self.bubble.center;
    center.x = MIN(MAX(center.x + delta.x, CGRectGetMinX(safe) + 23), CGRectGetMaxX(safe) - 23);
    center.y = MIN(MAX(center.y + delta.y, CGRectGetMinY(safe) + 23), CGRectGetMaxY(safe) - 23);
    self.bubble.center = center;
    [gesture setTranslation:CGPointZero inView:self.view];
    if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled || gesture.state == UIGestureRecognizerStateFailed) {
        self.dragging = NO;
        self.bubbleOnRight = center.x >= CGRectGetMidX(safe);
        CGFloat travel = CGRectGetHeight(safe) - 46;
        self.bubbleVerticalFraction = travel > 0 ? MIN(1, MAX(0, (center.y - 23 - CGRectGetMinY(safe)) / travel)) : 0;
        [self.view setNeedsLayout];
    }
}

- (void)refresh {
    if (!self.isViewLoaded) return;
    BOOL recording = STRecorder.shared.recording;
    self.statusLabel.text = STRecorder.shared.statusText ?: @"Captura parada";
    self.startButton.enabled = !recording && self.owner.videoState == STVideoIdle && !self.owner.pendingPreview && !self.presentedViewController;
    self.stopButton.enabled = recording || self.owner.videoState != STVideoIdle;
    self.alpacaButton.enabled = recording;
    self.matchButton.enabled = recording;
    self.includeVideoSwitch.enabled = !recording && self.owner.videoState == STVideoIdle;
    self.exportButton.enabled = !recording && self.owner.videoState == STVideoIdle;
    self.returnActionButton.enabled = !STRecorder.shared.returnActionBusy && !STRecorder.shared.autoplayBusy && !self.owner.pendingPreview &&
        !self.presentedViewController && self.owner.videoState != STVideoStarting && self.owner.videoState != STVideoStopping;
    [self.returnActionButton setTitle:STRecorder.shared.returnActionBusy ? @"Poder: aguardando resposta" : @"Poder central: abrir" forState:UIControlStateNormal];
    self.returnTraceButton.enabled = recording || (self.owner.videoState == STVideoIdle && !self.owner.pendingPreview && !self.presentedViewController);
    [self.returnTraceButton setTitle:STRecorder.shared.returnTraceActive ? @"Poderes: rastreamento ativo" : @"Rastrear poderes" forState:UIControlStateNormal];
    BOOL autoEnabled = STRecorder.shared.autoplayEnabled, autoBusy = STRecorder.shared.autoplayBusy;
    self.autoplayButton.enabled = autoEnabled || (!autoBusy && !recording && !STRecorder.shared.returnActionBusy &&
        self.owner.videoState == STVideoIdle && !self.owner.pendingPreview && !self.presentedViewController);
    [self.autoplayButton setTitle:autoEnabled ? @"Pausar autoplay" : (autoBusy ? @"Aguardando a ação enviada" : @"Iniciar autoplay") forState:UIControlStateNormal];
    [self.autoplayButton setImage:[UIImage systemImageNamed:autoEnabled ? @"pause.fill" : @"play.fill"] forState:UIControlStateNormal];
    self.autoplayLabel.text = STRecorder.shared.autoplayStatusText;
    self.recordingDot.hidden = !recording && self.owner.videoState == STVideoIdle && !autoEnabled;
    for (UIButton *button in @[self.startButton, self.stopButton, self.alpacaButton, self.matchButton, self.exportButton, self.returnTraceButton, self.returnActionButton, self.autoplayButton]) button.alpha = button.enabled ? 1 : 0.38;
    if (self.owner.videoState == STVideoRecording) {
        NSUInteger elapsed = (NSUInteger)MAX(0, CACurrentMediaTime() - self.owner.videoStarted);
        self.videoLabel.text = [NSString stringWithFormat:@"Vídeo %02lu:%02lu · sem microfone. Ao terminar, salve ou compartilhe na prévia do iOS.", (unsigned long)(elapsed / 60), (unsigned long)(elapsed % 60)];
    } else if (self.owner.videoState == STVideoStarting) self.videoLabel.text = @"Aguardando o iOS iniciar a gravação de vídeo…";
    else if (self.owner.videoState == STVideoStopping) self.videoLabel.text = @"Finalizando vídeo. Aguarde a prévia do iOS…";
    else self.videoLabel.text = @"Vídeo sem microfone; pode incluir áudio do app. Ao parar, salve ou compartilhe a prévia do iOS e depois exporte o JSON. Desative a opção acima para gravar só o JSON.";
    self.noticeLabel.text = self.owner.noticeExpires > CACurrentMediaTime() ? self.owner.notice : @"";
    NSString *compactAuto = autoEnabled ? [NSString stringWithFormat:@"Auto · %lu cartas · %lu jogadas", (unsigned long)STRecorder.shared.autoplayCardsRead, (unsigned long)STRecorder.shared.autoplayConfirmedMoves] : (autoBusy ? @"Auto pausando…" : @"");
    self.collapsedNoticeLabel.text = self.noticeLabel.text.length ? self.noticeLabel.text : compactAuto;
    self.collapsedNoticeLabel.font = [UIFont systemFontOfSize:self.noticeLabel.text.length ? 12 : 10 weight:UIFontWeightMedium];
    self.collapsedNoticeLabel.hidden = self.expanded || !self.collapsedNoticeLabel.text.length;
    [self.view setNeedsLayout];
}
@end

@implementation STOverlay

+ (instancetype)shared {
    static STOverlay *instance;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ instance = [STOverlay new]; });
    return instance;
}

- (instancetype)init {
    if ((self = [super init])) {
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        [center addObserver:self selector:@selector(becameActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        [center addObserver:self selector:@selector(becameActive:) name:UISceneDidActivateNotification object:nil];
        [center addObserver:self selector:@selector(enteredBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(sceneEnteredBackground:) name:UISceneDidEnterBackgroundNotification object:nil];
        [center addObserver:self selector:@selector(recorderChanged:) name:STRecorderDidChangeNotification object:nil];
    }
    return self;
}

- (UIWindowScene *)foregroundScene {
    UIWindowScene *fallback = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        UIWindowScene *windowScene = (UIWindowScene *)scene;
        for (UIWindow *window in windowScene.windows) {
            if (![window isKindOfClass:STOverlayWindow.class] && window.isKeyWindow) return windowScene;
        }
        if (!fallback) fallback = windowScene;
    }
    return fallback;
}

- (void)installIfNeeded {
    NSAssert(NSThread.isMainThread, @"SDKtools UI requires the main thread");
    UIWindowScene *scene = [self foregroundScene];
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    // Unity hosts may still use the UIApplication lifecycle without a scene
    // manifest. In that case connectedScenes is empty and a scene-only overlay
    // would never appear. Require a real host window in either lifecycle.
    UIWindow *hostWindow = nil;
    NSArray<UIWindow *> *windows = scene ? scene.windows : UIApplication.sharedApplication.windows;
    for (UIWindow *candidate in windows) {
        if ([candidate isKindOfClass:STOverlayWindow.class] || candidate.hidden || !candidate.rootViewController) continue;
        if (candidate.isKeyWindow) { hostWindow = candidate; break; }
        if (!hostWindow && candidate.windowLevel == UIWindowLevelNormal) hostWindow = candidate;
    }
    if (!hostWindow) return;
    if (!self.window) {
        self.controller = [STOverlayController new];
        self.controller.owner = self;
        self.window = scene ? [[STOverlayWindow alloc] initWithWindowScene:scene] : [[STOverlayWindow alloc] initWithFrame:hostWindow.bounds];
        self.window.rootViewController = self.controller;
        self.window.windowLevel = UIWindowLevelNormal + 5;
        self.window.backgroundColor = UIColor.clearColor;
        self.window.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
        self.window.accessibilityIdentifier = @"SDKtools.overlay";
    } else if (scene && self.window.windowScene != scene && !self.controller.presentedViewController) {
        self.window.hidden = YES;
        self.window.windowScene = scene;
    }
    self.window.frame = scene ? scene.coordinateSpace.bounds : hostWindow.screen.bounds;
    self.window.hidden = NO;
    [self refresh];
}

- (void)becameActive:(NSNotification *)notification {
    [self installIfNeeded];
    [self presentPendingPreview];
}

- (void)sceneEnteredBackground:(NSNotification *)notification {
    if (notification.object == self.window.windowScene) [self enteredBackground:notification];
}

- (void)enteredBackground:(NSNotification *)notification {
    self.window.hidden = YES;
    [self.statusTimer invalidate];
    self.statusTimer = nil;
    [self stopAllWithReason:@"background"];
}

- (void)recorderChanged:(NSNotification *)notification {
    // Limits and background handling can stop JSON independently. Do not leave
    // a screen recording running after its paired capture has ended.
    if (!STRecorder.shared.recording && self.ownsReplayKit) {
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    }
    [self refresh];
}

- (void)refresh {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self refresh]; }); return; }
    [self.controller refresh];
    BOOL active = UIApplication.sharedApplication.applicationState == UIApplicationStateActive;
    BOOL needed = active && ((self.controller.expanded && (STRecorder.shared.recording || self.videoState != STVideoIdle || STRecorder.shared.autoplayEnabled || STRecorder.shared.autoplayBusy)) || self.noticeExpires > CACurrentMediaTime());
    if (needed && !self.statusTimer) {
        __weak typeof(self) weakSelf = self;
        self.statusTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer *timer) { [weakSelf refresh]; }];
    } else if (!needed && self.statusTimer) {
        [self.statusTimer invalidate];
        self.statusTimer = nil;
    }
}

- (void)showNotice:(NSString *)notice {
    self.notice = notice;
    self.noticeExpires = CACurrentMediaTime() + 8;
    [self refresh];
}

- (void)startCapture {
    if (STRecorder.shared.recording) return;
    if (self.videoState != STVideoIdle || self.pendingPreview || self.controller.presentedViewController) {
        [self showNotice:@"Finalize ou salve o vídeo anterior antes de iniciar outra captura."];
        return;
    }
    [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura não iniciou. Tente novamente com o app aberto."];
        return;
    }
    [self showNotice:@"Captura iniciada. Feche o menu e siga até o Crazy Alpaca."];
    if (self.controller.includeVideoSwitch.isOn) [self toggleVideo];
}

- (void)traceReturn {
    if (STRecorder.shared.returnTraceActive) {
        [self showNotice:@"Rastreamento já ativo. Use o poder original, depois pare e exporte."];
        return;
    }
    if (!STRecorder.shared.recording) [self startCapture];
    if (!STRecorder.shared.recording) return;
    if (![STRecorder.shared beginReturnTrace]) {
        [self showNotice:@"Não foi possível iniciar o rastreamento nesta captura. Pare e exporte o relatório atual."];
        return;
    }
    [self showNotice:@"Rastreamento ativo. Use o poder original. Depois abra o menu, pare e exporte o JSON."];
    if (self.controller.expanded) [self.controller togglePanel];
}

- (void)toggleAutoplay {
    if (STRecorder.shared.autoplayEnabled) {
        [STRecorder.shared pauseAutoplayWithReason:@"user"];
        [self showNotice:STRecorder.shared.autoplayStatusText];
        return;
    }
    if ([STRecorder.shared startAutoplay]) {
        self.noticeExpires = 0;
        if (self.controller.expanded) [self.controller togglePanel];
    } else {
        [self showNotice:STRecorder.shared.autoplayBusy ? @"Aguarde a ação já enviada terminar antes de retomar." :
            (STRecorder.shared.recording ? @"Pare a captura antes de iniciar o autoplay." : @"Entre na partida e feche as janelas do jogo antes de iniciar.")];
    }
    [self refresh];
}

- (void)openReturn {
    if (self.controller.presentedViewController || self.pendingPreview ||
        self.videoState == STVideoStarting || self.videoState == STVideoStopping) {
        [self showNotice:@"Feche a janela aberta e aguarde o vídeo terminar de iniciar ou salvar."];
        return;
    }
    [self showNotice:@"Conferindo o poder central do jogo…"];
    __weak STOverlay *weakSelf = self;
    BOOL accepted = [STRecorder.shared performOriginalReturnWithUpdate:^(NSDictionary *result) {
        STOverlay *strongSelf = weakSelf;
        if (!strongSelf) return;
        NSString *status = result[@"status"], *reason = result[@"reason"];
        if ([status isEqualToString:@"original_event_dispatched"]) {
            [strongSelf showNotice:@"Confirme Usar item no jogo. O estoque e as regras são os originais."];
        } else if ([status isEqualToString:@"dispatch_uncertain"]) {
            [strongSelf showNotice:[result[@"physicalPending"] boolValue] ?
                @"Resposta incerta. Aguarde o jogo; o poder permanece bloqueado enquanto essa chamada não terminar." :
                @"A resposta não pôde ser confirmada. Confira a tela do jogo antes de tocar novamente."];
        } else if ([@[@"return_action_pending", @"physical_operation_pending", @"cleanup_pending"] containsObject:reason]) {
            [strongSelf showNotice:@"Há uma leitura ou ação em andamento. Aguarde antes de tocar novamente."];
        } else if ([@[@"native_modal_visible", @"modal_visible", @"native_view_obscured"] containsObject:reason]) {
            [strongSelf showNotice:@"Já existe uma janela aberta. Resolva ou feche essa janela no jogo."];
        } else if ([@[@"disabled_control", @"button_unavailable"] containsObject:reason]) {
            [strongSelf showNotice:@"O poder central não está disponível agora. Confira o estado da partida e o estoque."];
        } else if ([@[@"unsupported_application", @"engine_version", @"game_type_abi_mismatch"] containsObject:reason]) {
            [strongSelf showNotice:@"Esta versão do jogo não corresponde ao controle verificado para US 6.6.2."];
        } else {
            [strongSelf showNotice:@"Não foi possível identificar o poder central nesta tela. Entre na partida e exporte um relatório se continuar."];
        }
        [strongSelf refresh];
    }];
    // Only an accepted request can collapse the panel. Rejections keep the
    // explanation and controls visible. No synthetic tap or automatic retry.
    if (accepted && self.controller.expanded) [self.controller togglePanel];
    [self refresh];
}

- (void)stopCapture { [self stopAllWithReason:@"user"]; }

- (void)stopAllWithReason:(NSString *)reason {
    if (self.videoState != STVideoIdle) {
        self.pendingStopReason = reason;
        if (self.videoState == STVideoStarting) self.stopWhenStarted = YES;
        else if (self.videoState == STVideoRecording) [self stopVideo];
    } else {
        [STRecorder.shared stopRecordingWithReason:reason];
        [self showNotice:@"Captura encerrada. O relatório está pronto para exportar."];
    }
}

- (void)markAlpaca {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"crazyAlpacaEntered" details:@{@"source": @"user"}];
    [self showNotice:@"Entrada no Crazy Alpaca marcada no relatório."];
}

- (void)markMatch {
    if (!STRecorder.shared.recording) return;
    [STRecorder.shared markEvent:@"matchStarted" details:@{@"source": @"user"}];
    [self showNotice:@"Início da partida marcado no relatório."];
}

- (void)exportReport {
    if (STRecorder.shared.recording || self.videoState != STVideoIdle) { [self showNotice:@"Pare a captura antes de exportar o relatório."]; return; }
    if (self.controller.presentedViewController) { [self showNotice:@"Feche a janela aberta antes de exportar."]; return; }
    NSError *error = nil;
    NSURL *url = [STRecorder.shared writeReportWithError:&error];
    if (!url) { [self showNotice:@"Não foi possível gerar o JSON. Confira o espaço livre e tente novamente."]; return; }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    share.popoverPresentationController.sourceView = self.controller.exportButton;
    share.popoverPresentationController.sourceRect = self.controller.exportButton.bounds;
    __weak typeof(self) weakSelf = self;
    share.completionWithItemsHandler = ^(UIActivityType type, BOOL completed, NSArray *items, NSError *shareError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showNotice:completed ? @"Relatório compartilhado." : @"Relatório disponível para exportar novamente."];
            [weakSelf presentPendingPreview];
        });
    };
    [self.controller presentViewController:share animated:YES completion:nil];
}

- (void)toggleVideo {
    if (self.videoState == STVideoRecording) { [self stopVideo]; return; }
    if (self.videoState != STVideoIdle) return;
    if (self.pendingPreview || self.controller.presentedViewController) { [self showNotice:@"Feche ou salve a prévia anterior antes de gravar novamente."]; return; }
    RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
    if (!recorder.isAvailable || recorder.isRecording) { [self showNotice:@"A gravação de tela não está disponível agora. O JSON pode ser gravado normalmente."]; return; }
    if (recorder.delegate && recorder.delegate != self.replayDelegate) { [self showNotice:@"O app já utiliza o gravador de tela. O JSON está ativo; para vídeo, use a Central de Controle."]; return; }
    if (!STRecorder.shared.recording) [STRecorder.shared startRecording];
    if (!STRecorder.shared.recording) {
        [self showNotice:STRecorder.shared.statusText ?: @"A captura JSON não iniciou. O vídeo não foi aberto."];
        return;
    }
    self.videoCaptureSessionIdentifier = STRecorder.shared.captureSessionIdentifier;
    NSUInteger generation = ++self.videoGeneration;
    self.previousReplayDelegate = recorder.delegate;
    self.previousMicrophoneEnabled = recorder.isMicrophoneEnabled;
    self.previousCameraEnabled = recorder.isCameraEnabled;
    self.replayDelegate = [STReplaySessionDelegate new];
    self.replayDelegate.owner = self;
    self.replayDelegate.generation = generation;
    recorder.delegate = self.replayDelegate;
    recorder.microphoneEnabled = NO;
    recorder.cameraEnabled = NO;
    self.ownsReplayKit = YES;
    self.videoState = STVideoStarting;
    self.stopWhenStarted = NO;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [recorder startRecordingWithHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            if (error) {
                [strongSelf markVideoEndWithError:error];
                [strongSelf finishVideoWithPreview:nil];
                [strongSelf showNotice:STRecorder.shared.recording ? @"O vídeo não iniciou. O JSON continua; você também pode gravar pela Central de Controle." : @"O vídeo não iniciou. A captura foi encerrada; o JSON está disponível para exportar."];
                return;
            }
            strongSelf.videoState = STVideoRecording;
            strongSelf.videoStarted = CACurrentMediaTime();
            [STRecorder.shared markEvent:@"visualRecordingStarted" details:@{@"source": @"replaykit", @"enabled": @YES}];
            if (strongSelf.stopWhenStarted || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) [strongSelf stopVideo];
            else [strongSelf showNotice:@"Vídeo iniciado sem microfone. Feche o menu para continuar."];
        });
    }];
}

- (void)stopVideo {
    if (self.videoState != STVideoRecording || !self.ownsReplayKit) return;
    self.videoState = STVideoStopping;
    NSUInteger generation = self.videoGeneration;
    [self refresh];
    __weak typeof(self) weakSelf = self;
    [RPScreenRecorder.sharedRecorder stopRecordingWithHandler:^(RPPreviewViewController *preview, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            STOverlay *strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.ownsReplayKit || strongSelf.videoGeneration != generation) return;
            [strongSelf markVideoEndWithError:error];
            [strongSelf finishVideoWithPreview:preview];
            if (error) [strongSelf showNotice:@"O vídeo terminou com erro. Exporte o JSON; a prévia será exibida se estiver disponível."];
        });
    }];
}

- (void)markVideoEndWithError:(NSError *)error {
    NSTimeInterval elapsed = self.videoStarted > 0 ? MAX(0, CACurrentMediaTime() - self.videoStarted) : 0;
    if (self.videoCaptureSessionIdentifier) {
        [STRecorder.shared markVisualRecordingEndForSessionIdentifier:self.videoCaptureSessionIdentifier failed:(error != nil) durationSeconds:elapsed];
    }
}

- (void)finishVideoWithPreview:(RPPreviewViewController *)preview {
    if (self.ownsReplayKit) {
        RPScreenRecorder *recorder = RPScreenRecorder.sharedRecorder;
        if (recorder.delegate == self.replayDelegate) {
            recorder.delegate = self.previousReplayDelegate;
            recorder.microphoneEnabled = self.previousMicrophoneEnabled;
            recorder.cameraEnabled = self.previousCameraEnabled;
        }
    }
    self.ownsReplayKit = NO;
    self.videoState = STVideoIdle;
    self.videoStarted = 0;
    self.stopWhenStarted = NO;
    self.previousReplayDelegate = nil;
    self.replayDelegate = nil;
    self.videoCaptureSessionIdentifier = nil;
    if (self.pendingStopReason) {
        NSString *reason = self.pendingStopReason;
        self.pendingStopReason = nil;
        [STRecorder.shared stopRecordingWithReason:reason];
    }
    if (preview) {
        preview.previewControllerDelegate = self;
        if (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) {
            preview.modalPresentationStyle = UIModalPresentationPopover;
            preview.popoverPresentationController.sourceView = self.controller.bubble;
            preview.popoverPresentationController.sourceRect = self.controller.bubble.bounds;
            preview.preferredContentSize = CGSizeMake(540, 620);
        } else preview.modalPresentationStyle = UIModalPresentationFullScreen;
        self.pendingPreview = preview;
    }
    [self refresh];
    [self presentPendingPreview];
}

- (void)presentPendingPreview {
    if (!self.pendingPreview || self.controller.presentedViewController || UIApplication.sharedApplication.applicationState != UIApplicationStateActive || self.window.hidden) return;
    RPPreviewViewController *preview = self.pendingPreview;
    self.pendingPreview = nil;
    [self.controller presentViewController:preview animated:YES completion:nil];
}

- (void)previewControllerDidFinish:(RPPreviewViewController *)previewController {
    [previewController dismissViewControllerAnimated:YES completion:^{ [self showNotice:@"Vídeo encerrado. Exporte também o JSON para analisar os dois juntos."]; }];
}

- (void)replayDidStopWithGeneration:(NSUInteger)generation recorder:(RPScreenRecorder *)screenRecorder preview:(RPPreviewViewController *)previewViewController error:(NSError *)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.ownsReplayKit || self.videoGeneration != generation || screenRecorder.isRecording) return;
        [self markVideoEndWithError:error];
        [self finishVideoWithPreview:previewViewController];
        [self showNotice:@"A gravação de vídeo foi encerrada pelo iOS. O relatório JSON continua disponível."];
    });
}

- (void)replayAvailabilityChangedWithGeneration:(NSUInteger)generation {
    dispatch_async(dispatch_get_main_queue(), ^{ if (self.videoGeneration == generation) [self refresh]; });
}
@end

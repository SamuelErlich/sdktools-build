#import <Foundation/Foundation.h>
@class WKWebView;

NS_ASSUME_NONNULL_BEGIN

/// Bounded inspection and explicit guarded original power actions.
/// Main-thread use only. Capture remains passive; each open/confirm is a separate tap.
@interface STWebProbe : NSObject
- (void)reset;
- (void)stop;
/// Opt-in bounded control metadata plus targeted Retornar method/numeric
/// inspection; no callbacks invoked. Cleared by stop/reset.
- (void)setTraceControlsEnabled:(BOOL)enabled;
/// Enabled only by the recorder's explicitly bound game-2007 investigation.
/// Shares capture's namespace, document identity, request budget and lock.
/// Paused in V3.13: YES is rejected by the compiled card feature policy.
- (void)setCardInvestigationEnabled:(BOOL)enabled;
/// Explicit temporary observers, armed only with a game-2007 investigation.
/// Paused in V3.13: this cannot enable observers.
- (void)setCardFlowEnabled:(BOOL)enabled;
- (NSDictionary<NSString *, id> *)diagnosticsSnapshot;
/// One live autoplay step. Shares the physical evaluation lock with capture,
/// popup actions and cleanup. A timeout never releases that lock.
- (BOOL)performAutoplayStepInWebView:(WKWebView *)webView
                  resumeGeneration:(NSUInteger)resumeGeneration
                       allowAction:(BOOL)allowAction
                    coveredAttempt:(BOOL)coveredAttempt
                  penetrateAttempt:(BOOL)penetrateAttempt
                      turboEnabled:(BOOL)turboEnabled
                  superFastEnabled:(BOOL)superFastEnabled
                     cardsPerBatch:(NSUInteger)cardsPerBatch
                  extendedPlanning:(BOOL)extendedPlanning
                     powersEnabled:(BOOL)powersEnabled
                       xrayEnabled:(BOOL)xrayEnabled
                         xrayDepth:(NSInteger)xrayDepth
                   validateContext:(BOOL (^)(void))validateContext
               validateObservation:(BOOL (^)(void))validateObservation
                            update:(void (^)(NSDictionary<NSString *, id> *result))update;
/// Removes only SDK-owned visual nodes, preserving every uncertain action latch.
/// Queued behind any physical evaluation already submitted.
- (void)hideAutoplayVisuals;
/// Shares the physical evaluation lock with every action and capture. No game
/// callbacks are invoked. A timeout retains the lock until WebKit's callback.
/// Paused in V3.13: returns NO and reports feature_disabled synchronously,
/// without validating the page, allocating a runtime or evaluating JavaScript.
- (BOOL)performCardHintsInWebView:(WKWebView *)webView
               sessionGeneration:(NSUInteger)sessionGeneration
                 validateContext:(BOOL (^)(void))validateContext
                          update:(void (^)(NSDictionary<NSString *, id> *result))update;
/// Stops the SDK-owned renderer and its lease; preserves document identity.
- (void)hideCardHints;
/// Explicit one-attempt local lock test. poll/cancel never submit a game request.
- (BOOL)performWarehouseTestInWebView:(WKWebView *)webView
                               command:(NSString *)command
                       validateContext:(BOOL (^)(void))validateContext
                                update:(void (^)(NSDictionary<NSString *, id> *result))update;
- (BOOL)performOriginalWarehouseInWebView:(WKWebView *)webView
                        validateContext:(BOOL (^)(void))validateContext
                                 update:(void (^)(NSDictionary<NSString *, id> *result))update;
/// Returns YES once one physical evaluation is submitted. Rejections are reported
/// synchronously. A timeout update has physicalPending=YES and does not unlock;
/// the eventual WebKit callback sends the final update with physicalPending=NO.
/// This operation is independent of capture start/stop. No automatic retries.
- (BOOL)performOriginalPowerInWebView:(WKWebView *)webView
                                  slot:(NSString *)slot
                               command:(NSString *)command
                       validateContext:(BOOL (^)(void))validateContext
                                update:(void (^)(NSDictionary<NSString *, id> *result))update;
- (void)sampleWebView:(WKWebView *)webView
 elapsedMilliseconds:(NSTimeInterval)elapsedMilliseconds
          completion:(void (^)(NSDictionary<NSString *, id> *sample))completion;
@end

NS_ASSUME_NONNULL_END

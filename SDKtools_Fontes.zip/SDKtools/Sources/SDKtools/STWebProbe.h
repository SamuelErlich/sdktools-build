#import <Foundation/Foundation.h>
@class WKWebView;

NS_ASSUME_NONNULL_BEGIN

/// Bounded, passive inspection of the explicitly recorded Cocos game WebView.
/// Main-thread use only. No DOM writes, input, networking, cookies or storage access.
@interface STWebProbe : NSObject
- (void)reset;
- (void)stop;
- (void)sampleWebView:(WKWebView *)webView
 elapsedMilliseconds:(NSTimeInterval)elapsedMilliseconds
          completion:(void (^)(NSDictionary<NSString *, id> *sample))completion;
@end

NS_ASSUME_NONNULL_END

#ifndef STBILLIARDS_NUMERIC_POLICY_H
#define STBILLIARDS_NUMERIC_POLICY_H

#include <stdbool.h>
#include <stdint.h>
#include <math.h>

/* Validate in the original numeric domain before converting. These helpers
 * are shared by the Foundation snapshot reader and the portable regression
 * tests. Rejection never changes the caller's output. */
static inline bool STBLReadSignedInteger(int64_t value, int64_t minimum,
                                        int64_t maximum, int64_t *out) {
    if (minimum > maximum || value < minimum || value > maximum) return false;
    if (out) *out = value;
    return true;
}

static inline bool STBLReadUnsignedInteger(uint64_t value, int64_t minimum,
                                          int64_t maximum, int64_t *out) {
    if (minimum > maximum || maximum < 0 || value > (uint64_t)maximum ||
        (minimum > 0 && value < (uint64_t)minimum)) return false;
    /* maximum is nonnegative and <= INT64_MAX, so this cast cannot wrap. */
    if (out) *out = (int64_t)value;
    return true;
}

static inline bool STBLReadFloatingInteger(double value, int64_t minimum,
                                          int64_t maximum, int64_t *out) {
    /* (double)INT64_MAX rounds UP to 2^63. Use an exclusive upper bound
     * before casting, then compare the exact integer with the field bounds. */
    if (!isfinite(value) || floor(value) != value ||
        value < -0x1p63 || value >= 0x1p63) return false;
    return STBLReadSignedInteger((int64_t)value, minimum, maximum, out);
}

#endif

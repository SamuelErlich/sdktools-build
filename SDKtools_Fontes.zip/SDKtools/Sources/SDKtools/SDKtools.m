#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "STOverlay.h"

// No UIKit work, scans, hooks or file I/O runs while dyld is loading this image.
// The supported identity can be changed explicitly in the framework's Info.plist
// after inspecting another host build. An absent key keeps this known build.
static BOOL STSupportedHost(void) {
    NSBundle *host = NSBundle.mainBundle;
    NSBundle *framework = [NSBundle bundleForClass:STOverlay.class];
    NSDictionary *config = framework.infoDictionary;
    NSString *(^setting)(NSString *, NSString *) = ^NSString *(NSString *key, NSString *fallback) {
        id value = config[key];
        return [value isKindOfClass:NSString.class] && [value length] > 0 ? value : fallback;
    };
    id version = [host objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
    id build = [host objectForInfoDictionaryKey:@"CFBundleVersion"];
    return [host.bundleIdentifier isEqualToString:setting(@"SDKToolsTargetBundleIdentifier", @"com.wejoy.weplay")]
        && [version isKindOfClass:NSString.class] && [version isEqualToString:setting(@"SDKToolsTargetVersion", @"6.12.0")]
        && [build isKindOfClass:NSString.class] && [build isEqualToString:setting(@"SDKToolsTargetBuild", @"275")];
}

__attribute__((constructor)) static void SDKtoolsInitialize(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!STSupportedHost()) return;
        [[STOverlay shared] installIfNeeded];
    });
}

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "STOverlay.h"

// No UIKit work, scans, hooks or file I/O runs while dyld is loading this image.
// The framework metadata is validated against the audited base during build
// and packaging. Missing identity keys disable the overlay instead of falling
// back to a different host edition or version.
static BOOL STSupportedHost(void) {
    NSBundle *host = NSBundle.mainBundle;
    NSBundle *framework = [NSBundle bundleForClass:STOverlay.class];
    NSDictionary *config = framework.infoDictionary;
    NSDictionary<NSString *, NSString *> *mapping = @{
        @"CFBundleIdentifier": @"SDKToolsTargetBundleIdentifier",
        @"CFBundleShortVersionString": @"SDKToolsTargetVersion",
        @"CFBundleVersion": @"SDKToolsTargetBuild",
        @"CFBundleExecutable": @"SDKToolsTargetExecutable"
    };
    for (NSString *hostKey in mapping) {
        id expected = config[mapping[hostKey]];
        id actual = [host objectForInfoDictionaryKey:hostKey];
        if (![expected isKindOfClass:NSString.class] || [expected length] == 0
            || ![actual isKindOfClass:NSString.class] || ![actual isEqualToString:expected]) {
            return NO;
        }
    }
    return YES;
}

__attribute__((constructor)) static void SDKtoolsInitialize(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!STSupportedHost()) return;
        [[STOverlay shared] installIfNeeded];
    });
}

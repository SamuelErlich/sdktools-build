#import "STLocalizedUI.h"
#import "STBilliardsRuntime.h"
#import "STBilliardsLuaBridge.h"
#import "STBilliardsLivePolicy.h"
#import "STBilliardsLiveSnapshot.h"
#import "STBilliardsGuideDrawing.h"
#import "STBilliardsCaptureReport.h"
#import "STRecorder.h"
#import "STClientContext.h"
#import <QuartzCore/QuartzCore.h>
#import <CoreFoundation/CoreFoundation.h>
#include <math.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

NSNotificationName const STBilliardsRuntimeDidChangeNotification = @"STBilliardsRuntimeDidChange";
static const NSUInteger STBLHistoryLimit=120;
static const double STBLShotObservationLimitMs=20000.0;
static BOOL STBLShotFiniteNumber(id value, double *out) {
    if (![value isKindOfClass:NSNumber.class] ||
        CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID()) return NO;
    double number=[value doubleValue];
    if (!isfinite(number)) return NO;
    if (out) *out=number;
    return YES;
}
static BOOL STBLShotSameContext(NSDictionary *reference, NSDictionary *record) {
    return [reference[@"sessionId"] isKindOfClass:NSNumber.class] &&
        [reference[@"cameraInstanceId"] isKindOfClass:NSNumber.class] &&
        [reference[@"scene"] isKindOfClass:NSDictionary.class] &&
        [reference[@"sessionId"] isEqual:record[@"sessionId"]] &&
        [reference[@"cameraInstanceId"] isEqual:record[@"cameraInstanceId"]] &&
        [reference[@"scene"] isEqual:record[@"scene"]];
}
static BOOL STBLShotIdentityMatches(NSArray *referenceRows, NSArray *candidateRows) {
    if (![referenceRows isKindOfClass:NSArray.class] || ![candidateRows isKindOfClass:NSArray.class] ||
        referenceRows.count<1 || referenceRows.count>16 || referenceRows.count!=candidateRows.count) return NO;
    NSMutableDictionary *numbers=[NSMutableDictionary dictionaryWithCapacity:referenceRows.count];
    for (id row in referenceRows) {
        if (![row isKindOfClass:NSDictionary.class]) return NO;
        double tag=0,number=0;
        if (!STBLShotFiniteNumber(row[@"tag"],&tag) || tag<1 || tag>16 || floor(tag)!=tag ||
            !STBLShotFiniteNumber(row[@"number"],&number) || number<0 || number>15 || floor(number)!=number ||
            numbers[row[@"tag"]]) return NO;
        numbers[row[@"tag"]]=row[@"number"];
    }
    NSMutableSet *seen=[NSMutableSet setWithCapacity:candidateRows.count];
    for (id row in candidateRows) {
        if (![row isKindOfClass:NSDictionary.class]) return NO;
        double tag=0,number=0;
        if (!STBLShotFiniteNumber(row[@"tag"],&tag) || tag<1 || tag>16 || floor(tag)!=tag ||
            !STBLShotFiniteNumber(row[@"number"],&number) || number<0 || number>15 || floor(number)!=number ||
            [seen containsObject:row[@"tag"]] || ![numbers[row[@"tag"]] isEqual:row[@"number"]]) return NO;
        [seen addObject:row[@"tag"]];
    }
    return seen.count==numbers.count;
}
static BOOL STBLShotObservedRest(NSDictionary *record) {
    NSArray *identityRows=record[@"balls"];
    NSDictionary *dynamics=record[@"observedDynamics"];
    NSArray *rows=[dynamics isKindOfClass:NSDictionary.class] &&
        [dynamics[@"schemaVersion"] isEqual:@1]?dynamics[@"balls"]:identityRows;
    if (![identityRows isKindOfClass:NSArray.class] || ![rows isKindOfClass:NSArray.class] ||
        rows.count<1 || rows.count>16 || rows.count!=identityRows.count) return NO;
    NSMutableDictionary *identities=[NSMutableDictionary dictionaryWithCapacity:identityRows.count];
    for (id candidate in identityRows) {
        if (![candidate isKindOfClass:NSDictionary.class]) return NO;
        NSNumber *tag=candidate[@"tag"];
        double tagValue=0;
        if (!STBLShotFiniteNumber(tag,&tagValue) || tagValue<1 || tagValue>16 || floor(tagValue)!=tagValue ||
            identities[tag]) return NO;
        identities[tag]=candidate;
    }
    NSMutableSet *seen=[NSMutableSet setWithCapacity:rows.count];
    NSUInteger activeCount=0;
    for (id candidate in rows) {
        if (![candidate isKindOfClass:NSDictionary.class]) return NO;
        NSDictionary *row=candidate;
        NSNumber *tag=row[@"tag"];
        double tagValue=0;
        if (!STBLShotFiniteNumber(tag,&tagValue) || tagValue<1 || tagValue>16 || floor(tagValue)!=tagValue ||
            [seen containsObject:tag]) return NO;
        NSDictionary *identity=identities[tag];
        if (!identity || ![row[@"active"] isKindOfClass:NSNumber.class] ||
            ![row[@"potted"] isKindOfClass:NSNumber.class] ||
            ![row[@"number"] isEqual:identity[@"number"]] ||
            ![row[@"active"] isEqual:identity[@"active"]] || ![row[@"potted"] isEqual:identity[@"potted"]]) return NO;
        [seen addObject:tag];
        if ([row[@"potted"] boolValue]) continue;
        if (![row[@"active"] boolValue]) return NO;
        activeCount++;
        double speed=0,x=0,y=0,z=0;
        NSDictionary *angular=row[@"angularVelocity"],*world=row[@"world"];
        if (!STBLShotFiniteNumber(row[@"speed"],&speed) || speed<0 || speed>0.002 ||
            ![angular isKindOfClass:NSDictionary.class] ||
            !STBLShotFiniteNumber(angular[@"x"],&x) || !STBLShotFiniteNumber(angular[@"y"],&y) ||
            !STBLShotFiniteNumber(angular[@"z"],&z) || hypot(hypot(x,y),z)>0.2 ||
            ![world isKindOfClass:NSDictionary.class] ||
            !STBLShotFiniteNumber(world[@"x"],NULL) || !STBLShotFiniteNumber(world[@"y"],NULL) ||
            !STBLShotFiniteNumber(world[@"z"],NULL)) return NO;
    }
    return activeCount>0 && seen.count==identities.count;
}
static BOOL STBLShotKnownLocal(NSDictionary *record) {
    NSDictionary *physics=record[@"physics"];
    id localTurn=[physics isKindOfClass:NSDictionary.class]?physics[@"localTurn"]:nil;
    return [localTurn isKindOfClass:NSNumber.class] &&
        CFGetTypeID((__bridge CFTypeRef)localTurn)==CFBooleanGetTypeID() && [localTurn boolValue];
}
static BOOL STBLShotKnownNonlocal(NSDictionary *record) {
    NSDictionary *physics=record[@"physics"];
    id localTurn=[physics isKindOfClass:NSDictionary.class]?physics[@"localTurn"]:nil;
    return [localTurn isKindOfClass:NSNumber.class] &&
        CFGetTypeID((__bridge CFTypeRef)localTurn)==CFBooleanGetTypeID() && ![localTurn boolValue];
}
static BOOL STBLShotPowerInstruction(NSString *reason) {
    return [reason isKindOfClass:NSString.class] &&
        [@[@"power_unavailable",@"power_below_deadzone"] containsObject:reason];
}
static BOOL STBLShotPhysicsUnavailableReason(NSString *reason) {
    return [reason isKindOfClass:NSString.class] &&
        [@[@"power_unavailable",@"physics_unavailable",@"physics_body_unavailable",@"physics_profile_mismatch",
           @"inertia_tensor_unsupported",@"spin_unavailable",@"spin_unsupported",@"tutorial_physics_unsupported"] containsObject:reason];
}
static BOOL STBLShotDirectionNeedsPower(NSDictionary *snapshot) {
    NSDictionary *physics=snapshot[@"physics"];
    if (![physics isKindOfClass:NSDictionary.class]) physics=@{};
    if ([physics[@"reason"] isEqual:@"power_below_deadzone"] ||
        [snapshot[@"reason"] isEqual:@"power_below_deadzone"]) return YES;
    double power=0,maximum=0,deadzone=0;
    if (!STBLShotFiniteNumber(physics[@"power"],&power) || power<0) return NO;
    if (power==0) return YES;
    return STBLShotFiniteNumber(physics[@"sliderMax"],&maximum) && maximum>0 &&
        STBLShotFiniteNumber(physics[@"deadzone"],&deadzone) && deadzone>=0 && deadzone<1 &&
        power<deadzone*maximum;
}
static NSString *STBLShotPredictionStatusText(NSDictionary *snapshot) {
    NSDictionary *prediction=snapshot[@"prediction"];
    if (![prediction isKindOfClass:NSDictionary.class]) return @"Previsão de parada parcial";
    if ([prediction[@"model"] isEqual:@"geometric"]) {
        return STBLShotDirectionNeedsPower(snapshot)?@"Guia de direção · ajuste a força":
            @"Guia de direção · parada indisponível";
    }
    BOOL finite=[prediction[@"model"] isEqual:@"finite"] && [prediction[@"chainVersion"] isEqual:@2];
    BOOL complete=finite && [prediction[@"complete"] boolValue] && ![prediction[@"truncated"] boolValue];
    NSUInteger affected=[prediction[@"affectedBallCount"] unsignedIntegerValue];
    return complete?[NSString stringWithFormat:@"Parada estimada · %lu bolas",(unsigned long)affected]:
        @"Previsão de parada parcial";
}
static NSError *STBLError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"SDKtools.BilliardsLive" code:code userInfo:@{NSLocalizedDescriptionKey:message}];
}
static BOOL STBLHostViewVisible(UIView *view) {
    return STClientHostViewAllowsActions(view);
}
@interface STBilliardsOverlayView : UIView
@property(nonatomic,copy) NSDictionary *snapshot;
@property(nonatomic) CGRect gameRect;
@property(nonatomic) CGRect acceptedBounds;
@property(nonatomic) double expiresAt;
- (void)clear;
@end
@implementation STBilliardsOverlayView
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self=[super initWithFrame:frame])) {
        self.userInteractionEnabled=NO; self.backgroundColor=UIColor.clearColor;
        self.opaque=NO; self.accessibilityElementsHidden=YES; self.clipsToBounds=YES;
        self.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    }
    return self;
}
- (void)clear { self.snapshot=nil; self.expiresAt=0; [self setNeedsDisplay]; }
- (void)layoutSubviews {
    [super layoutSubviews];
    if (!CGRectEqualToRect(self.bounds,self.acceptedBounds)) [self clear];
}
- (CGPoint)point:(NSDictionary *)point width:(double)width height:(double)height {
    return CGPointMake(self.gameRect.origin.x+[point[@"x"] doubleValue]/width*self.gameRect.size.width,
        self.gameRect.origin.y+(1-[point[@"y"] doubleValue]/height)*self.gameRect.size.height);
}
- (void)drawRect:(CGRect)rect {
    (void)rect;
    if (!self.snapshot || CACurrentMediaTime()>=self.expiresAt || !CGRectEqualToRect(self.bounds,self.acceptedBounds)) return;
    double width=[self.snapshot[@"screen"][@"width"] doubleValue],height=[self.snapshot[@"screen"][@"height"] doubleValue];
    if (!STBLValidViewport(width,height,self.gameRect.size.width,self.gameRect.size.height)) return;
    STBilliardsDrawGuideSnapshot(self.snapshot,self.gameRect);
}
@end

@interface STBilliardsRuntime () {
    STBLFrameGate _frameGate;
}
@property(nonatomic,readwrite,getter=isEnabled) BOOL enabled;
@property(nonatomic,copy,readwrite) NSString *statusText;
@property(nonatomic,copy,readwrite) NSDictionary *lastSnapshot;
@property(nonatomic,copy) NSDictionary *latestAimReference;
@property(nonatomic,copy) NSDictionary *lastAimBeforeMotion;
@property(nonatomic,copy) NSDictionary *lastShotObservation;
@property(nonatomic,weak) UIWindow *overlayWindow;
@property(nonatomic,weak) UIWindow *hostWindow;
@property(nonatomic,weak) UIView *hostView;
@property(nonatomic,strong) STBilliardsOverlayView *drawing;
@property(nonatomic,strong) NSTimer *sampleTimer;
@property(nonatomic,strong) CADisplayLink *expiryDisplayLink;
@property(nonatomic,strong) NSMutableArray<NSDictionary *> *history;
@property(nonatomic) UIInterfaceOrientation acceptedOrientation;
@property(nonatomic) CGRect acceptedGameRect;
@property(nonatomic) NSUInteger attempts;
@property(nonatomic) NSUInteger accepted;
@property(nonatomic) NSUInteger rejected;
@property(nonatomic) NSUInteger slowSamples;
@property(nonatomic) NSUInteger omitted;
@property(nonatomic) double lastDurationMs;
@property(nonatomic) double startedAt;
@property(nonatomic) double lastTick;
@property(nonatomic) BOOL slowed;
@property(nonatomic) uint64_t automationFrame;
@property(nonatomic) BOOL automationNeedsFreshInput;
@property(nonatomic,copy) NSDictionary *automationContext;
@property(nonatomic) BOOL automationEverEnabled;
@property(nonatomic) BOOL automationEverAutoplay;
@property(nonatomic,strong) NSMutableArray<NSDictionary *> *automationHistory;
@property(nonatomic,copy) NSDictionary *lastAutomation;
- (void)runAutomationForSnapshot:(NSDictionary *)snapshot;
@property(nonatomic,copy) NSString *stopReason;
- (void)closeShotObservationWithReason:(NSString *)reason;
- (void)updateShotObservationWithRecord:(NSDictionary *)record;
@end

@implementation STBilliardsRuntime
+ (instancetype)shared { static STBilliardsRuntime *instance; static dispatch_once_t once; dispatch_once(&once,^{instance=[self new];}); return instance; }
- (instancetype)init {
    if ((self=[super init])) {
        _automationHistory=[NSMutableArray array]; _lastAutomation=@{};
        _statusText=@"Desativado"; _lastSnapshot=@{}; _history=[NSMutableArray array]; _stopReason=@"not_started";
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(background:) name:UIApplicationWillResignActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(background:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    }
    return self;
}
- (void)publishStatus:(NSString *)text {
    if ([self.statusText isEqual:text]) return;
    self.statusText=text;
    [[NSNotificationCenter defaultCenter] postNotificationName:STBilliardsRuntimeDidChangeNotification object:self];
}
- (void)setAutomationMode:(NSUInteger)mode {
    if (!NSThread.isMainThread || mode>2 || (mode && !self.enabled)) return;
    if (_automationMode==mode) return;
    if (mode && ![STRecorder.shared ensureEventObservation]) {
        [self publishStatus:@"Automação indisponível: observação de toque ausente"]; return;
    }
    _automationMode=mode; self.automationFrame=0; self.automationNeedsFreshInput=NO; self.lastAutomation=@{};
    self.automationEverEnabled|=mode!=0;
    self.automationEverAutoplay|=mode==2;
    [STBilliardsLuaBridge executeCommand:@"stop" error:nil];
    self.automationContext=nil;
    if (mode) {
        NSDictionary *arm=[STBilliardsLuaBridge executeCommand:mode==2?@"arm_auto":@"arm_aim" error:nil];
        NSDictionary *a=[arm[@"automation"] isKindOfClass:NSDictionary.class]?arm[@"automation"]:nil;
        if (![a[@"reason"] isEqual:@"automation_armed"] || ![arm[@"scene"][@"name"] isEqual:@"BilliardInGame"]) {
            _automationMode=0;
            [STBilliardsLuaBridge executeCommand:@"stop" error:nil];
            [self publishStatus:@"Abra a partida atual antes de armar Aim/Auto"]; return;
        }
        self.automationContext=@{@"scene":arm[@"scene"] ?: @{},@"sessionId":arm[@"sessionId"] ?: @(-1),
            @"cameraInstanceId":arm[@"cameraInstanceId"] ?: @0,@"screen":arm[@"screen"] ?: @{}};
        self.automationFrame=[arm[@"frameNumber"] unsignedLongLongValue];
    }
    [self publishStatus:mode==2?@"Auto · somente a partida atual":(mode==1?@"Aim · ajusta sem disparar":@"Automação pausada")];
}
- (void)pauseAutomationWithReason:(NSString *)reason {
    if (!self.automationMode) return;
    self.automationMode=0;
    [self publishStatus:[reason isEqual:@"manual_touch"]?@"Pausado por toque manual · rearme no menu":@"Automação pausada · rearme no menu"];
}
- (void)suspendForInteraction {
    if (!NSThread.isMainThread || !self.automationMode) return;
    self.automationNeedsFreshInput=YES;
}
- (void)runAutomationForSnapshot:(NSDictionary *)snapshot {
    if (!self.automationMode) return;
    if (STClientInteractionBlocked()) { [self suspendForInteraction]; return; }
    if (!self.automationContext || !STBLShotSameContext(self.automationContext,snapshot)) {
        [self pauseAutomationWithReason:@"armed_context_changed"]; return;
    }
    if (self.automationNeedsFreshInput) {
        NSDictionary *suspended=[STBilliardsLuaBridge executeCommand:@"suspend" error:nil];
        if (![suspended[@"reason"] isEqual:@"interaction_suspended"]) return;
        self.automationNeedsFreshInput=NO;
    }
    double frame=0,width=0,height=0;
    if (!STBLShotFiniteNumber(snapshot[@"frameNumber"],&frame) || frame<0 || floor(frame)!=frame ||
        !STBLShotFiniteNumber(snapshot[@"screen"][@"width"],&width) ||
        !STBLShotFiniteNumber(snapshot[@"screen"][@"height"],&height) ||
        !STBLValidViewport(width,height,self.acceptedGameRect.size.width,self.acceptedGameRect.size.height)) {
        [self suspendForInteraction]; return;
    }
    if (self.automationFrame && frame<self.automationFrame) { [self pauseAutomationWithReason:@"frame_rewound"]; return; }
    if (self.automationFrame==(uint64_t)frame) return;
    self.automationFrame=(uint64_t)frame;
    NSError *error=nil;
    double controlStarted=CACurrentMediaTime();
    NSDictionary *raw=[STBilliardsLuaBridge executeCommand:self.automationMode==2?@"autoplay":@"aim" error:&error];
    double durationMs=MAX(0,(CACurrentMediaTime()-controlStarted)*1000);
    NSDictionary *a=[raw[@"automation"] isKindOfClass:NSDictionary.class]?raw[@"automation"]:nil;
    if (error || !a || ![a[@"schemaVersion"] isEqual:@1]) { [self pauseAutomationWithReason:@"control_unavailable"]; return; }
    NSString *phase=a[@"phase"], *reason=a[@"reason"];
    NSArray *phases=@[@"observing",@"waiting",@"planning",@"aimed",@"submitted",@"moving",@"ended",@"uncertain"];
    NSCharacterSet *invalid=[[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyz_0123456789"] invertedSet];
    if (![phase isKindOfClass:NSString.class] || ![phases containsObject:phase] ||
        ![reason isKindOfClass:NSString.class] || reason.length<1 || reason.length>80 ||
        [reason rangeOfCharacterFromSet:invalid].location!=NSNotFound) { [self pauseAutomationWithReason:@"invalid_control"]; return; }
    NSMutableDictionary *safe=[@{@"schemaVersion":@1,@"phase":phase,@"reason":reason,@"mode":@(self.automationMode),
        @"elapsedSeconds":@(MAX(0,CACurrentMediaTime()-self.startedAt)),@"durationMs":@(durationMs)} mutableCopy];
    for (NSString *key in @[@"shots",@"calibrationSamples",@"gain",@"target",@"number",@"pocket",@"angle",@"power",@"score",@"evaluated"]) {
        id value=a[key]; if (!value) continue;
        double n=0;
        if (!STBLShotFiniteNumber(value,&n) || fabs(n)>1000000) { [self pauseAutomationWithReason:@"invalid_control_number"]; return; }
        safe[key]=value;
    }
    for (NSString *key in @[@"kind",@"model"]) {
        NSString *v=a[key]; if (!v) continue;
        if (![v isKindOfClass:NSString.class] || v.length>64 || [v rangeOfCharacterFromSet:invalid].location!=NSNotFound) { [self pauseAutomationWithReason:@"invalid_control_token"]; return; }
        safe[key]=v;
    }
    self.lastAutomation=safe;
    if (self.automationHistory.count>=64) [self.automationHistory removeObjectAtIndex:0];
    [self.automationHistory addObject:safe];
    NSDictionary *labels=@{@"observing":@"Observando",@"planning":@"Calculando",@"waiting":@"Aguardando",@"aimed":@"Mira pronta",
        @"submitted":@"Tacada enviada",@"moving":@"Bolas em movimento",@"ended":@"Partida encerrada",@"uncertain":@"Pausado · verificar"};
    NSString *title=labels[phase] ?: @"Aguardando";
    // Gameplay state is displayed once by the compact SDK bubble.
    [self publishStatus:[NSString stringWithFormat:@"%@ · %@",title,reason]];
    if ([phase isEqual:@"ended"] || [phase isEqual:@"uncertain"]) {
        _automationMode=0; // Keep the Lua terminal latch intact.
        [[NSNotificationCenter defaultCenter] postNotificationName:STBilliardsRuntimeDidChangeNotification object:self];
    }
}
- (void)background:(NSNotification *)notification {
    (void)notification;
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(),^{[self stopWithReason:@"background"];}); return; }
    [self stopWithReason:@"background"];
}
- (BOOL)startInWindow:(UIWindow *)window error:(NSError **)error {
    if (!NSThread.isMainThread || UIApplication.sharedApplication.applicationState!=UIApplicationStateActive ||
        !window || window.hidden || !window.rootViewController.isViewLoaded) {
        if(error)*error=STBLError(1,@"Abra o jogo e tente novamente."); return NO;
    }
    if (self.enabled) return YES;
    STRecorder *recorder=STRecorder.shared;
    if (recorder.coveredAttemptPending || recorder.recording || recorder.detectedGameDetectionActive || recorder.sourceExportBusy || recorder.autoplayBusy || recorder.returnActionBusy) {
        if(error)*error=STBLError(2,@"Finalize a captura, exportação ou jogada em andamento."); return NO;
    }
    [recorder pauseAutoplayWithReason:@"billiards_started"]; [recorder setXrayEnabled:NO];
    self.overlayWindow=window; self.hostWindow=nil; self.hostView=nil;
    self.drawing=[[STBilliardsOverlayView alloc] initWithFrame:window.rootViewController.view.bounds];
    [window.rootViewController.view insertSubview:self.drawing atIndex:0];
    _automationMode=0;self.automationEverEnabled=NO;self.automationEverAutoplay=NO;self.automationFrame=0;
    self.lastAutomation=@{};[self.automationHistory removeAllObjects];
    self.enabled=YES; self.slowed=NO; self.startedAt=CACurrentMediaTime(); self.lastTick=0;
    self.attempts=0; self.accepted=0; self.rejected=0; self.slowSamples=0; self.omitted=0;
    self.lastSnapshot=@{}; self.latestAimReference=nil; self.lastAimBeforeMotion=nil; self.lastShotObservation=nil;
    [self.history removeAllObjects]; _frameGate=(STBLFrameGate){0};
    self.stopReason=@"running";
    self.expiryDisplayLink=[CADisplayLink displayLinkWithTarget:self selector:@selector(expiryTick:)];
    self.expiryDisplayLink.preferredFramesPerSecond=30;
    [self.expiryDisplayLink addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];
    [self scheduleTimer:0.1];
    [self publishStatus:@"Aguardando a mesa do bilhar…"];
    [self sample];
    return YES;
}
- (void)scheduleTimer:(double)interval {
    [self.sampleTimer invalidate];
    __weak typeof(self) weakSelf=self;
    self.sampleTimer=[NSTimer timerWithTimeInterval:interval repeats:YES block:^(__unused NSTimer *timer){[weakSelf sample];}];
    self.sampleTimer.tolerance=0.01;
    [NSRunLoop.mainRunLoop addTimer:self.sampleTimer forMode:NSRunLoopCommonModes];
}
- (void)expiryTick:(CADisplayLink *)link {
    (void)link;
    if (!self.drawing.snapshot) return;
    if (CACurrentMediaTime()>=self.drawing.expiresAt || UIApplication.sharedApplication.applicationState!=UIApplicationStateActive ||
        self.overlayWindow.hidden || self.hostWindow.hidden || !STBLHostViewVisible(self.hostView) ||
        self.overlayWindow.windowScene.interfaceOrientation!=self.acceptedOrientation ||
        !CGRectEqualToRect([self.hostView convertRect:self.hostView.bounds toView:self.drawing],self.acceptedGameRect)) [self.drawing clear];
}
- (void)stopWithReason:(NSString *)reason {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(),^{[self stopWithReason:reason];}); return; }
    BOOL wasEnabled=self.enabled;
    _automationMode=0;
    self.enabled=NO; [self.sampleTimer invalidate]; self.sampleTimer=nil;
    [self.expiryDisplayLink invalidate]; self.expiryDisplayLink=nil;
    [self.drawing clear]; [self.drawing removeFromSuperview]; self.drawing=nil;
    self.overlayWindow=nil; self.hostView=nil; self.hostWindow=nil; _frameGate=(STBLFrameGate){0};
    if (!wasEnabled) return;
    self.stopReason=STBilliardsDiagnosticToken(reason);
    [self closeShotObservationWithReason:[@"capture_stopped_" stringByAppendingString:self.stopReason]];
    [STBilliardsLuaBridge executeCommand:@"stop" error:nil];
    [self publishStatus:[reason isEqual:@"background"]?@"Pausado ao sair do jogo":@"Desativado"];
}
- (UIView *)visibleUnityView {
    UIWindow *overlay=self.overlayWindow;
    if (!overlay || overlay.hidden) return nil;
    UIWindowScene *scene=overlay.windowScene;
    if (scene && scene.activationState!=UISceneActivationStateForegroundActive) return nil;
    NSArray<UIWindow *> *windows=scene?scene.windows:UIApplication.sharedApplication.windows;
    Class unityClass=NSClassFromString(@"UnityView");
    if (!unityClass) return nil;
    UIView *found=nil; NSUInteger visited=0;
    for (UIWindow *window in windows) {
        if (window==overlay || window.hidden || window.alpha<0.01 || window.screen!=overlay.screen) continue;
        if (window.windowLevel>UIWindowLevelNormal) continue;
        NSMutableArray<UIView *> *pending=[NSMutableArray arrayWithObject:window];
        while (pending.count) {
            if (++visited>512) return nil;
            UIView *view=pending.lastObject; [pending removeLastObject];
            if (view.hidden || view.alpha<0.01) continue;
            if ([view isKindOfClass:unityClass]) { if (found && found!=view) return nil; found=view; continue; }
            if (pending.count+view.subviews.count>512) return nil;
            [pending addObjectsFromArray:view.subviews];
        }
    }
    return STBLHostViewVisible(found)?found:nil;
}
- (void)closeShotObservationWithReason:(NSString *)reason {
    if (![self.lastShotObservation[@"status"] isEqual:@"pending"]) return;
    NSMutableDictionary *observation=[self.lastShotObservation mutableCopy];
    observation[@"status"]=@"incomplete";
    observation[@"reason"]=STBilliardsDiagnosticToken(reason);
    self.lastShotObservation=observation;
}
- (void)updateShotObservationWithRecord:(NSDictionary *)record {
    if (![self.lastShotObservation[@"status"] isEqual:@"pending"]) return;
    NSDictionary *firstMotion=self.lastShotObservation[@"firstMotion"];
    double currentMs=0,firstMs=0;
    if (!STBLShotFiniteNumber(record[@"elapsedMs"],&currentMs) ||
        !STBLShotFiniteNumber(firstMotion[@"elapsedMs"],&firstMs) || currentMs<firstMs) return;
    if (currentMs-firstMs>STBLShotObservationLimitMs) {
        [self closeShotObservationWithReason:@"observation_timeout"]; return;
    }
    if (!STBLShotSameContext(firstMotion,record)) {
        [self closeShotObservationWithReason:@"context_changed_or_unavailable"]; return;
    }
    if ([record[@"reason"] isEqual:@"not_local_turn"] || STBLShotKnownNonlocal(record)) {
        [self closeShotObservationWithReason:@"turn_changed_before_observed_rest"]; return;
    }
    if ([record[@"reason"] isEqual:@"not_aiming"] && !STBLShotKnownLocal(record)) {
        [self closeShotObservationWithReason:@"turn_unconfirmed_before_observed_rest"]; return;
    }
    NSDictionary *lastMotion=self.lastShotObservation[@"lastMotion"];
    NSNumber *frame=record[@"frameNumber"],*previousFrame=lastMotion[@"frameNumber"];
    BOOL advanced=[frame isKindOfClass:NSNumber.class] && [previousFrame isKindOfClass:NSNumber.class] &&
        [frame compare:previousFrame]==NSOrderedDescending;
    if (advanced && STBLShotKnownLocal(record) &&
        STBLShotIdentityMatches(firstMotion[@"balls"],record[@"balls"]) && STBLShotObservedRest(record)) {
        NSMutableDictionary *observation=[self.lastShotObservation mutableCopy];
        observation[@"firstRest"]=[record copy];
        observation[@"status"]=@"complete";
        observation[@"reason"]=@"observed_rest";
        self.lastShotObservation=observation;
        return;
    }
    if ([@[@"wrong_scene",@"unsupported",@"error",@"stopped"] containsObject:record[@"status"]]) {
        [self closeShotObservationWithReason:@"observation_unavailable"]; return;
    }
    if (advanced && [record[@"status"] isEqual:@"moving"]) {
        NSMutableDictionary *observation=[self.lastShotObservation mutableCopy];
        observation[@"lastMotion"]=[record copy];
        self.lastShotObservation=observation;
    }
}
- (void)rememberSnapshot:(NSDictionary *)snapshot {
    NSMutableDictionary *record=[snapshot mutableCopy];
    record[@"elapsedMs"]=@(MAX(0,(CACurrentMediaTime()-self.startedAt)*1000));
    record[@"readDurationMs"]=@(self.lastDurationMs);
    BOOL knownNonlocal=STBLShotKnownNonlocal(snapshot);
    if (knownNonlocal) self.latestAimReference=nil;
    if ([snapshot[@"status"] isEqual:@"aiming"] &&
        [snapshot[@"rendering"][@"available"] boolValue] && !knownNonlocal) {
        self.latestAimReference=record;
    } else if ([snapshot[@"status"] isEqual:@"moving"] && self.latestAimReference) {
        NSDictionary *aim=self.latestAimReference;
        double elapsed=[record[@"elapsedMs"] doubleValue]-[aim[@"elapsedMs"] doubleValue];
        BOOL sameContext=STBLShotSameContext(aim,snapshot);
        if (sameContext && elapsed>=0 && elapsed<=1000) {
            self.lastAimBeforeMotion=@{@"association":@"same_context_next_motion",
                @"aim":aim,@"firstMotion":[record copy]};
            self.lastShotObservation=@{@"schemaVersion":@1,@"association":@"same_context_next_motion",
                @"status":@"pending",@"reason":@"awaiting_observed_rest",@"aim":aim,
                @"firstMotion":[record copy],@"lastMotion":[record copy],@"firstRest":NSNull.null};
        }
        self.latestAimReference=nil;
    } else if ([snapshot[@"status"] isEqual:@"wrong_scene"] ||
               [snapshot[@"status"] isEqual:@"unsupported"] ||
               [snapshot[@"status"] isEqual:@"error"] ||
               [snapshot[@"reason"] isEqual:@"not_local_turn"]) {
        self.latestAimReference=nil;
    }
    [self updateShotObservationWithRecord:record];
    if (self.history.count>=STBLHistoryLimit) { [self.history removeObjectAtIndex:0]; self.omitted++; }
    [self.history addObject:record];
}
- (void)invalidate:(NSString *)status reason:(NSString *)reason {
    [self invalidate:status reason:reason bridgeError:nil];
}
- (void)invalidate:(NSString *)status reason:(NSString *)reason bridgeError:(NSError *)error {
    [self.drawing clear]; _frameGate=(STBLFrameGate){0}; self.rejected++;
    NSMutableDictionary *snapshot=[@{@"format":@"SDKtools.BilliardsLive",@"schemaVersion":@1,@"status":status,
        @"reason":STBilliardsDiagnosticToken(reason),@"balls":@[],@"segments":@[]} mutableCopy];
    if (error) {
        BOOL known=[error.domain isEqual:@"SDKtools.BilliardsLua"];
        NSInteger code=MAX((NSInteger)-1000000,MIN((NSInteger)1000000,error.code));
        NSString *message=known && error.localizedDescription.length<=200?error.localizedDescription:@"Ponte de leitura indisponível.";
        snapshot[@"nativeBridgeError"]=@{@"domain":known?error.domain:@"other",@"code":@(code),@"description":message};
    }
    self.lastSnapshot=snapshot;
    [self rememberSnapshot:snapshot];
}
- (void)sample {
    if (!self.enabled || !NSThread.isMainThread) return;
    double now=CACurrentMediaTime();
    if (self.lastTick && now-self.lastTick<(self.slowed?0.24:0.095)) return;
    self.lastTick=now;
    STRecorder *recorder=STRecorder.shared;
    if (UIApplication.sharedApplication.applicationState!=UIApplicationStateActive || !self.overlayWindow || self.overlayWindow.hidden) { [self stopWithReason:@"background"]; return; }
    if (recorder.coveredAttemptPending || recorder.recording || recorder.sourceExportBusy || recorder.detectedGameDetectionActive || recorder.autoplayEnabled || recorder.xrayEnabled || recorder.autoplayBusy || recorder.returnActionBusy) {
        [self stopWithReason:@"other_tool_active"]; return;
    }
    UIView *unity=[self visibleUnityView];
    if (!unity) { [self invalidate:@"not_ready" reason:@"unity_view_unavailable"]; [self publishStatus:@"Abra a mesa do bilhar para localizar as bolas."]; return; }
    CGRect rect=[unity convertRect:unity.bounds toView:self.drawing];
    if (!isfinite(rect.origin.x) || !isfinite(rect.origin.y) || !isfinite(rect.size.width) || !isfinite(rect.size.height) ||
        rect.size.width<16 || rect.size.height<16 || !CGRectContainsRect(self.drawing.bounds,rect)) {
        [self invalidate:@"not_ready" reason:@"unity_viewport_unavailable"]; [self publishStatus:@"Aguardando a tela do jogo estabilizar…"]; return;
    }
    UIInterfaceOrientation orientation=self.overlayWindow.windowScene.interfaceOrientation;
    if (self.hostView!=unity || self.hostWindow!=unity.window || !CGRectEqualToRect(rect,self.acceptedGameRect) || orientation!=self.acceptedOrientation) {
        [self.drawing clear]; _frameGate=(STBLFrameGate){0};
        [self suspendForInteraction];
        self.hostView=unity; self.hostWindow=unity.window; self.acceptedGameRect=rect; self.acceptedOrientation=orientation;
    }
    if (self.overlayWindow.rootViewController.presentedViewController) {
        [self invalidate:@"not_ready" reason:@"overlay_presentation"]; return;
    }
    NSError *error=nil; self.attempts++;
    NSDictionary *raw=[STBilliardsLuaBridge executeCommand:@"sample" error:&error];
    double completed=CACurrentMediaTime(); self.lastDurationMs=(completed-now)*1000;
    if (self.lastDurationMs>50) {
        self.slowSamples++;
        if (!self.slowed) { self.slowed=YES; [self scheduleTimer:0.25]; }
    }
    if (completed-now>=STBL_STALE_SECONDS || error || !raw) {
        [self invalidate:@"error" reason:error?@"bridge_unavailable":@"sample_time_limit" bridgeError:error];
        [self publishStatus:error?@"Leitura nativa indisponível. Exporte o diagnóstico.":@"Leitura demorada; guia ocultada."]; return;
    }
    NSString *failure=nil;
    NSDictionary *snapshot=STBilliardsSanitizeSnapshot(raw,&failure);
    if (!snapshot) { [self invalidate:@"error" reason:failure]; [self publishStatus:@"Dados incompletos; guia ocultada. Exporte o diagnóstico."]; return; }
    self.lastSnapshot=snapshot;
    [self runAutomationForSnapshot:snapshot];
    NSString *status=snapshot[@"status"];
    if (![@[@"aiming",@"moving"] containsObject:status]) {
        [self.drawing clear]; _frameGate=(STBLFrameGate){0};
        [self rememberSnapshot:snapshot];
        NSDictionary *texts=@{@"wrong_scene":@"Abra uma partida de bilhar.",@"not_ready":@"Aguardando a mesa e a câmera…",
            @"unsupported":@"Essa leitura ainda não está disponível. Exporte o diagnóstico.",@"error":@"A leitura falhou. Exporte o diagnóstico.",@"stopped":@"Leitura interrompida."};
        if ([snapshot[@"gates"][@"hasFrame"] boolValue] &&
            [snapshot[@"gates"][@"hasCamera"] boolValue] &&
            STBLShotPhysicsUnavailableReason(snapshot[@"reason"])) {
            [self publishStatus:@"Mesa lida · previsão de parada indisponível"];
        } else if (STBLShotPowerInstruction(snapshot[@"reason"])) {
            [self publishStatus:@"Ajuste a força para prever a parada"];
        } else if ([snapshot[@"resolution"][@"contractStatus"] isEqual:@"selected"] &&
            ![snapshot[@"gates"][@"hasFrame"] boolValue]) {
            [self publishStatus:@"Módulos do bilhar encontrados. Exporte a leitura para verificar a mesa."];
        } else if ([snapshot[@"reason"] isEqual:@"billiards_contract_mismatch"] &&
            [snapshot[@"environment"] isKindOfClass:NSDictionary.class]) {
            [self publishStatus:@"Diagnóstico do ambiente coletado. Exporte a leitura do bilhar."];
        } else if (!self.automationMode || !self.lastAutomation.count) {
            [self publishStatus:texts[status] ?: @"Aguardando o jogo…"];
        }
        return;
    }
    double width=[snapshot[@"screen"][@"width"] doubleValue],height=[snapshot[@"screen"][@"height"] doubleValue];
    if (!STBLValidViewport(width,height,rect.size.width,rect.size.height)) {
        [self invalidate:@"not_ready" reason:@"viewport_aspect_mismatch"]; [self publishStatus:@"Aguardando o enquadramento da mesa…"]; return;
    }
    STBLContext context={[snapshot[@"scene"][@"handle"] longLongValue],[snapshot[@"sessionId"] longLongValue],
        [snapshot[@"cameraInstanceId"] longLongValue],(uint32_t)width,(uint32_t)height};
    STBLFrameResult gate=STBLAcceptFrame(&_frameGate,context,[snapshot[@"frameNumber"] unsignedLongLongValue],now);
    BOOL draw=(gate==STBLFrameFresh || gate==STBLFrameDuplicate) && [status isEqual:@"aiming"] && [snapshot[@"prediction"][@"available"] boolValue];
    NSMutableDictionary *observed=[snapshot mutableCopy];
    observed[@"rendering"]=@{@"available":@(draw),@"frameGate":gate==STBLFrameReject?@"stale_frame":
        (gate==STBLFrameWarmup?@"warmup":(gate==STBLFrameDuplicate?@"duplicate_within_ttl":@"fresh")),
        @"frameAgeMs":@(MAX(0,(completed-_frameGate.advancedAt)*1000))};
    self.lastSnapshot=observed;
    if (gate==STBLFrameReject || gate==STBLFrameWarmup) {
        [self rememberSnapshot:observed];
        [self.drawing clear];
        if (!self.automationMode || !self.lastAutomation.count)
            [self publishStatus:gate==STBLFrameReject?@"Aguardando uma leitura nova da mesa…":@"Conferindo a mesa e a câmera…"];
        return;
    }
    if (gate==STBLFrameFresh) {
        self.accepted++;
        [self rememberSnapshot:observed];
    }
    if (!draw) {
        [self.drawing clear];
        if (!self.automationMode || !self.lastAutomation.count)
            [self publishStatus:STBLShotPowerInstruction(snapshot[@"reason"])?@"Ajuste a força para prever a parada":
                ([status isEqual:@"moving"]?@"Bolas em movimento; aguardando parar.":@"Mesa lida; aguardando uma mira válida.")];
        return;
    }
    self.drawing.snapshot=snapshot; self.drawing.gameRect=rect; self.drawing.acceptedBounds=self.drawing.bounds;
    self.drawing.expiresAt=_frameGate.advancedAt+STBL_STALE_SECONDS;
    [self.drawing setNeedsDisplay];
    if (!self.automationMode && !self.lastAutomation.count) [self publishStatus:STBLShotPredictionStatusText(snapshot)];
}
- (NSURL *)exportReportWithError:(NSError **)error {
    if (!NSThread.isMainThread) { if(error)*error=STBLError(3,@"Exporte pelo menu do jogo."); return nil; }
    [self stopWithReason:@"export"];
    if (!self.lastSnapshot.count) { if(error)*error=STBLError(4,@"Ative o bilhar antes de exportar o diagnóstico."); return nil; }
    NSDictionary *report=@{@"format":@"SDKtools.BilliardsLiveCapture",@"schemaVersion":@1,@"toolVersion":@"4.0.1",
        @"createdUTC":[NSISO8601DateFormatter.new stringFromDate:NSDate.date],@"lastSnapshot":self.lastSnapshot,
        @"lastAimBeforeMotion":self.lastAimBeforeMotion ?: (id)NSNull.null,
        @"lastShotObservation":self.lastShotObservation ?: (id)NSNull.null,
        @"automation":@{@"last":self.lastAutomation ?: @{},@"history":[self.automationHistory copy],@"newMatchesStarted":@0,@"deviceValidation":@"required"},
        @"samples":[self.history copy],@"counts":@{@"attempts":@(self.attempts),@"accepted":@(self.accepted),@"rejected":@(self.rejected),
            @"slowSamples":@(self.slowSamples),@"omittedOlderSamples":@(self.omitted)},@"stopReason":self.stopReason,
        @"limits":@{@"historySamples":@(STBLHistoryLimit),@"staleSeconds":@(STBL_STALE_SECONDS),@"maximumHz":@10,@"slowModeHz":@4,
            @"shotObservationSeconds":@(STBLShotObservationLimitMs/1000.0)},
        @"environmentDiagnostics":@{@"schemaVersion":@1,@"mode":@"structural_only",
            @"automaticEnvironmentSwitch":@NO,@"initializationCalls":@NO,
            @"resourceGameIdSource":@"static_catalog_contract",@"gameTypeSource":@"static_module_contract",
            @"environmentGameTypes":@"observed_only_when_present"},
        @"contractResolution":@{@"schemaVersion":@1,@"fallback":@"canonical_loaded_modules",
            @"moduleLoadingCalls":@NO,@"globalNamespaceWrites":@NO,
            @"loadedBilliardsSceneRequired":@YES,@"existingManagerGetter":@YES,
            @"managerGetterImplementation":@"not_recovered"},
        @"policy":@{@"gameplayWrites":@(self.automationEverEnabled),@"automaticShots":@(self.automationEverAutoplay),@"automaticShotsMeaning":@"explicit_permission_not_verified_outcome",@"changesOriginalGuide":@(self.automationEverEnabled),@"automaticRematch":@NO,@"predictionModel":@"finite_with_direction_fallback",
            @"chainEventBudget":@64,@"chainSegmentBudget":@48,@"environmentQueryBudget":@96,
            @"maximumBouncesPerBall":@6,@"maximumSimulationSeconds":@15,@"maximumPhysicsSteps":@750,
            @"physicsStepSeconds":@0.02,@"environmentLayerMask":@524289,
            @"directionFallback":@{@"model":@"geometric",@"chainVersion":@1,@"predictsStops":@NO,
                @"maximumBouncesPerBall":@2,@"segmentBudget":@24,@"queryBudget":@32,
                @"eventBudget":@16,@"normalizedHorizon":@12},
            @"fullSpinFrictionModel":@NO,@"matchResultGuaranteed":@NO}};
    NSData *data=STBilliardsEncodeCapture(report,4u*1024u*1024u,error);
    if (!data) return nil;
    NSURL *documents=[NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject;
    if (!documents.isFileURL) { if(error)*error=STBLError(6,@"A pasta de exportação não está disponível."); return nil; }
    NSURL *directory=[documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES];
    int root=open(documents.URLByResolvingSymlinksInPath.path.fileSystemRepresentation,O_RDONLY|O_DIRECTORY|O_CLOEXEC);
    if (root<0 || (mkdirat(root,"SDKtools",0700) && errno!=EEXIST)) { if(root>=0)close(root); if(error)*error=STBLError(6,@"Não foi possível abrir a pasta de exportação."); return nil; }
    int dir=openat(root,"SDKtools",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC); close(root);
    if (dir<0) { if(error)*error=STBLError(6,@"A pasta de exportação não é válida."); return nil; }
    NSString *name=[NSString stringWithFormat:@"SDKtools-BilliardsLive-%@.json",NSUUID.UUID.UUIDString];
    NSString *temporary=[@"." stringByAppendingString:name];
    int fd=openat(dir,temporary.fileSystemRepresentation,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    BOOL ok=fd>=0; size_t offset=0;
    while (ok && offset<data.length) {
        ssize_t written=write(fd,(const unsigned char *)data.bytes+offset,data.length-offset);
        if (written<0 && errno==EINTR) continue;
        if (written<=0) { ok=NO; break; } offset+=(size_t)written;
    }
    if (ok) ok=fsync(fd)==0;
    if (fd>=0 && close(fd)) ok=NO;
    NSURL *temporaryURL=[directory URLByAppendingPathComponent:temporary];
    if (ok) ok=[NSFileManager.defaultManager setAttributes:@{NSFileProtectionKey:NSFileProtectionComplete} ofItemAtPath:temporaryURL.path error:nil];
    if (ok) ok=renameat(dir,temporary.fileSystemRepresentation,dir,name.fileSystemRepresentation)==0;
    if (!ok) unlinkat(dir,temporary.fileSystemRepresentation,0);
    close(dir);
    if (!ok) { if(error)*error=STBLError(7,@"Não foi possível salvar o diagnóstico."); return nil; }
    NSURL *output=[directory URLByAppendingPathComponent:name]; [output setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
    return output;
}
@end

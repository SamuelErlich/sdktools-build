#import "STBilliardsRuntime.h"
#import "STBilliardsLuaBridge.h"
#import "STBilliardsLivePolicy.h"
#import "STBilliardsLiveSnapshot.h"
#import "STRecorder.h"
#import <QuartzCore/QuartzCore.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

NSNotificationName const STBilliardsRuntimeDidChangeNotification = @"STBilliardsRuntimeDidChange";
static const NSUInteger STBLHistoryLimit=120;
static NSError *STBLError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"SDKtools.BilliardsLive" code:code userInfo:@{NSLocalizedDescriptionKey:message}];
}
static BOOL STBLHostViewVisible(UIView *view) {
    if (!view.window || view.hidden || view.alpha<0.01 || view.window.hidden) return NO;
    UIViewController *top=view.window.rootViewController;
    NSUInteger count=0;
    while (top.presentedViewController) {
        if (++count>16 || top.isBeingDismissed || top.isBeingPresented) return NO;
        top=top.presentedViewController;
    }
    if (!top || top.isBeingDismissed || top.isBeingPresented || !top.isViewLoaded ||
        (top.view!=view && ![view isDescendantOfView:top.view])) return NO;
    UIResponder *responder=view;
    for (NSUInteger depth=0;responder && depth<64;depth++,responder=responder.nextResponder) {
        if ([responder isKindOfClass:UIViewController.class]) {
            UIViewController *controller=(UIViewController *)responder;
            if (controller.isBeingDismissed || controller.isBeingPresented) return NO;
        }
        if (responder==view.window) break;
    }
    CGPoint middle=[view convertPoint:CGPointMake(CGRectGetMidX(view.bounds),CGRectGetMidY(view.bounds)) toView:view.window];
    UIView *hit=[view.window hitTest:middle withEvent:nil];
    return hit==view || [hit isDescendantOfView:view];
}
@interface STBilliardsOverlayView : UIView
@property(nonatomic,copy) NSDictionary *snapshot;
@property(nonatomic) CGRect gameRect;
@property(nonatomic) CGRect acceptedBounds;
@property(nonatomic) double expiresAt;
- (void)clear;
@end
@implementation STBilliardsOverlayView
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self=[super initWithFrame:frame])) {
        self.userInteractionEnabled=NO; self.backgroundColor=UIColor.clearColor;
        self.opaque=NO; self.accessibilityElementsHidden=YES; self.clipsToBounds=YES;
        self.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    }
    return self;
}
- (void)clear { self.snapshot=nil; self.expiresAt=0; [self setNeedsDisplay]; }
- (void)layoutSubviews {
    [super layoutSubviews];
    if (!CGRectEqualToRect(self.bounds,self.acceptedBounds)) [self clear];
}
- (CGPoint)point:(NSDictionary *)point width:(double)width height:(double)height {
    return CGPointMake(self.gameRect.origin.x+[point[@"x"] doubleValue]/width*self.gameRect.size.width,
        self.gameRect.origin.y+(1-[point[@"y"] doubleValue]/height)*self.gameRect.size.height);
}
- (void)drawRect:(CGRect)rect {
    (void)rect;
    if (!self.snapshot || CACurrentMediaTime()>=self.expiresAt || !CGRectEqualToRect(self.bounds,self.acceptedBounds)) return;
    double width=[self.snapshot[@"screen"][@"width"] doubleValue],height=[self.snapshot[@"screen"][@"height"] doubleValue];
    if (!STBLValidViewport(width,height,self.gameRect.size.width,self.gameRect.size.height)) return;
    CGContextRef context=UIGraphicsGetCurrentContext(); if (!context) return;
    CGContextSaveGState(context); CGContextClipToRect(context,self.gameRect);
    for (NSDictionary *segment in self.snapshot[@"segments"]) {
        CGPoint from=[self point:segment[@"from"] width:width height:height], to=[self point:segment[@"to"] width:width height:height];
        UIColor *color=[segment[@"kind"] isEqual:@"object"]?[UIColor colorWithRed:1 green:0.65 blue:0.12 alpha:0.95]:
            ([segment[@"kind"] isEqual:@"rebound"]?[UIColor colorWithRed:0.3 green:1 blue:0.65 alpha:0.95]:[UIColor colorWithRed:0.2 green:0.85 blue:1 alpha:0.95]);
        UIBezierPath *line=[UIBezierPath bezierPath]; [line moveToPoint:from]; [line addLineToPoint:to];
        line.lineWidth=2.0; line.lineCapStyle=kCGLineCapRound; [color setStroke]; [line stroke];
    }
    for (NSDictionary *ball in self.snapshot[@"balls"]) {
        if (![ball[@"active"] boolValue] || [ball[@"potted"] boolValue]) continue;
        CGPoint center=[self point:ball[@"screen"] width:width height:height];
        double radius=[ball[@"radiusPixels"] doubleValue]/width*self.gameRect.size.width;
        if (!isfinite(radius) || radius<=0) continue;
        UIBezierPath *circle=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(center.x-radius,center.y-radius,radius*2,radius*2)];
        circle.lineWidth=1; [[UIColor colorWithWhite:1 alpha:0.6] setStroke]; [circle stroke];
    }
    CGContextRestoreGState(context);
}
@end

@interface STBilliardsRuntime () {
    STBLFrameGate _frameGate;
}
@property(nonatomic,readwrite,getter=isEnabled) BOOL enabled;
@property(nonatomic,copy,readwrite) NSString *statusText;
@property(nonatomic,copy,readwrite) NSDictionary *lastSnapshot;
@property(nonatomic,weak) UIWindow *overlayWindow;
@property(nonatomic,weak) UIWindow *hostWindow;
@property(nonatomic,weak) UIView *hostView;
@property(nonatomic,strong) STBilliardsOverlayView *drawing;
@property(nonatomic,strong) NSTimer *sampleTimer;
@property(nonatomic,strong) CADisplayLink *expiryDisplayLink;
@property(nonatomic,strong) NSMutableArray<NSDictionary *> *history;
@property(nonatomic) UIInterfaceOrientation acceptedOrientation;
@property(nonatomic) CGRect acceptedGameRect;
@property(nonatomic) NSUInteger attempts;
@property(nonatomic) NSUInteger accepted;
@property(nonatomic) NSUInteger rejected;
@property(nonatomic) NSUInteger slowSamples;
@property(nonatomic) NSUInteger omitted;
@property(nonatomic) double lastDurationMs;
@property(nonatomic) double startedAt;
@property(nonatomic) double lastTick;
@property(nonatomic) BOOL slowed;
@property(nonatomic,copy) NSString *stopReason;
@end

@implementation STBilliardsRuntime
+ (instancetype)shared { static STBilliardsRuntime *instance; static dispatch_once_t once; dispatch_once(&once,^{instance=[self new];}); return instance; }
- (instancetype)init {
    if ((self=[super init])) {
        _statusText=@"Desativado"; _lastSnapshot=@{}; _history=[NSMutableArray array]; _stopReason=@"not_started";
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(background:) name:UIApplicationWillResignActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(background:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    }
    return self;
}
- (void)publishStatus:(NSString *)text {
    if ([self.statusText isEqual:text]) return;
    self.statusText=text;
    [[NSNotificationCenter defaultCenter] postNotificationName:STBilliardsRuntimeDidChangeNotification object:self];
}
- (void)background:(NSNotification *)notification {
    (void)notification;
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(),^{[self stopWithReason:@"background"];}); return; }
    [self stopWithReason:@"background"];
}
- (BOOL)startInWindow:(UIWindow *)window error:(NSError **)error {
    if (!NSThread.isMainThread || UIApplication.sharedApplication.applicationState!=UIApplicationStateActive ||
        !window || window.hidden || !window.rootViewController.isViewLoaded) {
        if(error)*error=STBLError(1,@"Abra o jogo e tente novamente."); return NO;
    }
    if (self.enabled) return YES;
    STRecorder *recorder=STRecorder.shared;
    if (recorder.recording || recorder.detectedGameDetectionActive || recorder.sourceExportBusy || recorder.autoplayBusy || recorder.returnActionBusy) {
        if(error)*error=STBLError(2,@"Finalize a captura, exportação ou jogada em andamento."); return NO;
    }
    [recorder pauseAutoplayWithReason:@"billiards_started"]; [recorder setXrayEnabled:NO];
    self.overlayWindow=window; self.hostWindow=nil; self.hostView=nil;
    self.drawing=[[STBilliardsOverlayView alloc] initWithFrame:window.rootViewController.view.bounds];
    [window.rootViewController.view insertSubview:self.drawing atIndex:0];
    self.enabled=YES; self.slowed=NO; self.startedAt=CACurrentMediaTime(); self.lastTick=0;
    self.attempts=0; self.accepted=0; self.rejected=0; self.slowSamples=0; self.omitted=0;
    self.lastSnapshot=@{}; [self.history removeAllObjects]; _frameGate=(STBLFrameGate){0};
    self.stopReason=@"running";
    self.expiryDisplayLink=[CADisplayLink displayLinkWithTarget:self selector:@selector(expiryTick:)];
    self.expiryDisplayLink.preferredFramesPerSecond=30;
    [self.expiryDisplayLink addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];
    [self scheduleTimer:0.1];
    [self publishStatus:@"Aguardando a mesa do bilhar…"];
    [self sample];
    return YES;
}
- (void)scheduleTimer:(double)interval {
    [self.sampleTimer invalidate];
    __weak typeof(self) weakSelf=self;
    self.sampleTimer=[NSTimer timerWithTimeInterval:interval repeats:YES block:^(__unused NSTimer *timer){[weakSelf sample];}];
    self.sampleTimer.tolerance=0.01;
    [NSRunLoop.mainRunLoop addTimer:self.sampleTimer forMode:NSRunLoopCommonModes];
}
- (void)expiryTick:(CADisplayLink *)link {
    (void)link;
    if (!self.drawing.snapshot) return;
    if (CACurrentMediaTime()>=self.drawing.expiresAt || UIApplication.sharedApplication.applicationState!=UIApplicationStateActive ||
        self.overlayWindow.hidden || self.hostWindow.hidden || !STBLHostViewVisible(self.hostView) ||
        self.overlayWindow.windowScene.interfaceOrientation!=self.acceptedOrientation ||
        !CGRectEqualToRect([self.hostView convertRect:self.hostView.bounds toView:self.drawing],self.acceptedGameRect)) [self.drawing clear];
}
- (void)stopWithReason:(NSString *)reason {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(),^{[self stopWithReason:reason];}); return; }
    BOOL wasEnabled=self.enabled;
    self.enabled=NO; [self.sampleTimer invalidate]; self.sampleTimer=nil;
    [self.expiryDisplayLink invalidate]; self.expiryDisplayLink=nil;
    [self.drawing clear]; [self.drawing removeFromSuperview]; self.drawing=nil;
    self.overlayWindow=nil; self.hostView=nil; self.hostWindow=nil; _frameGate=(STBLFrameGate){0};
    if (!wasEnabled) return;
    self.stopReason=STBilliardsDiagnosticToken(reason);
    [STBilliardsLuaBridge executeCommand:@"stop" error:nil];
    [self publishStatus:[reason isEqual:@"background"]?@"Pausado ao sair do jogo":@"Desativado"];
}
- (UIView *)visibleUnityView {
    UIWindow *overlay=self.overlayWindow;
    if (!overlay || overlay.hidden) return nil;
    UIWindowScene *scene=overlay.windowScene;
    if (scene && scene.activationState!=UISceneActivationStateForegroundActive) return nil;
    NSArray<UIWindow *> *windows=scene?scene.windows:UIApplication.sharedApplication.windows;
    Class unityClass=NSClassFromString(@"UnityView");
    if (!unityClass) return nil;
    UIView *found=nil; NSUInteger visited=0;
    for (UIWindow *window in windows) {
        if (window==overlay || window.hidden || window.alpha<0.01 || window.screen!=overlay.screen) continue;
        if (window.windowLevel>UIWindowLevelNormal) continue;
        NSMutableArray<UIView *> *pending=[NSMutableArray arrayWithObject:window];
        while (pending.count) {
            if (++visited>512) return nil;
            UIView *view=pending.lastObject; [pending removeLastObject];
            if (view.hidden || view.alpha<0.01) continue;
            if ([view isKindOfClass:unityClass]) { if (found && found!=view) return nil; found=view; continue; }
            if (pending.count+view.subviews.count>512) return nil;
            [pending addObjectsFromArray:view.subviews];
        }
    }
    return STBLHostViewVisible(found)?found:nil;
}
- (void)rememberSnapshot:(NSDictionary *)snapshot {
    NSMutableDictionary *record=[snapshot mutableCopy];
    record[@"elapsedMs"]=@(MAX(0,(CACurrentMediaTime()-self.startedAt)*1000));
    record[@"readDurationMs"]=@(self.lastDurationMs);
    if (self.history.count>=STBLHistoryLimit) { [self.history removeObjectAtIndex:0]; self.omitted++; }
    [self.history addObject:record];
}
- (void)invalidate:(NSString *)status reason:(NSString *)reason {
    [self invalidate:status reason:reason bridgeError:nil];
}
- (void)invalidate:(NSString *)status reason:(NSString *)reason bridgeError:(NSError *)error {
    [self.drawing clear]; _frameGate=(STBLFrameGate){0}; self.rejected++;
    NSMutableDictionary *snapshot=[@{@"format":@"SDKtools.BilliardsLive",@"schemaVersion":@1,@"status":status,
        @"reason":STBilliardsDiagnosticToken(reason),@"balls":@[],@"segments":@[]} mutableCopy];
    if (error) {
        BOOL known=[error.domain isEqual:@"SDKtools.BilliardsLua"];
        NSInteger code=MAX((NSInteger)-1000000,MIN((NSInteger)1000000,error.code));
        NSString *message=known && error.localizedDescription.length<=200?error.localizedDescription:@"Ponte de leitura indisponível.";
        snapshot[@"nativeBridgeError"]=@{@"domain":known?error.domain:@"other",@"code":@(code),@"description":message};
    }
    self.lastSnapshot=snapshot;
    [self rememberSnapshot:snapshot];
}
- (void)sample {
    if (!self.enabled || !NSThread.isMainThread) return;
    double now=CACurrentMediaTime();
    if (self.lastTick && now-self.lastTick<(self.slowed?0.24:0.095)) return;
    self.lastTick=now;
    STRecorder *recorder=STRecorder.shared;
    if (UIApplication.sharedApplication.applicationState!=UIApplicationStateActive || !self.overlayWindow || self.overlayWindow.hidden) { [self stopWithReason:@"background"]; return; }
    if (recorder.recording || recorder.sourceExportBusy || recorder.detectedGameDetectionActive || recorder.autoplayEnabled || recorder.xrayEnabled || recorder.autoplayBusy || recorder.returnActionBusy) {
        [self stopWithReason:@"other_tool_active"]; return;
    }
    UIView *unity=[self visibleUnityView];
    if (!unity) { [self invalidate:@"not_ready" reason:@"unity_view_unavailable"]; [self publishStatus:@"Abra a mesa do bilhar para localizar as bolas."]; return; }
    CGRect rect=[unity convertRect:unity.bounds toView:self.drawing];
    if (!isfinite(rect.origin.x) || !isfinite(rect.origin.y) || !isfinite(rect.size.width) || !isfinite(rect.size.height) ||
        rect.size.width<16 || rect.size.height<16 || !CGRectContainsRect(self.drawing.bounds,rect)) {
        [self invalidate:@"not_ready" reason:@"unity_viewport_unavailable"]; [self publishStatus:@"Aguardando a tela do jogo estabilizar…"]; return;
    }
    UIInterfaceOrientation orientation=self.overlayWindow.windowScene.interfaceOrientation;
    if (self.hostView!=unity || self.hostWindow!=unity.window || !CGRectEqualToRect(rect,self.acceptedGameRect) || orientation!=self.acceptedOrientation) {
        [self.drawing clear]; _frameGate=(STBLFrameGate){0};
        self.hostView=unity; self.hostWindow=unity.window; self.acceptedGameRect=rect; self.acceptedOrientation=orientation;
    }
    if (self.overlayWindow.rootViewController.presentedViewController) {
        [self invalidate:@"not_ready" reason:@"overlay_presentation"]; return;
    }
    NSError *error=nil; self.attempts++;
    NSDictionary *raw=[STBilliardsLuaBridge executeCommand:@"sample" error:&error];
    double completed=CACurrentMediaTime(); self.lastDurationMs=(completed-now)*1000;
    if (self.lastDurationMs>50) {
        self.slowSamples++;
        if (!self.slowed) { self.slowed=YES; [self scheduleTimer:0.25]; }
    }
    if (completed-now>=STBL_STALE_SECONDS || error || !raw) {
        [self invalidate:@"error" reason:error?@"bridge_unavailable":@"sample_time_limit" bridgeError:error];
        [self publishStatus:error?@"Leitura nativa indisponível. Exporte o diagnóstico.":@"Leitura demorada; guia ocultada."]; return;
    }
    NSString *failure=nil;
    NSDictionary *snapshot=STBilliardsSanitizeSnapshot(raw,&failure);
    if (!snapshot) { [self invalidate:@"error" reason:failure]; [self publishStatus:@"Dados incompletos; guia ocultada. Exporte o diagnóstico."]; return; }
    self.lastSnapshot=snapshot;
    NSString *status=snapshot[@"status"];
    if (![@[@"aiming",@"moving"] containsObject:status]) {
        [self.drawing clear]; _frameGate=(STBLFrameGate){0};
        [self rememberSnapshot:snapshot];
        NSDictionary *texts=@{@"wrong_scene":@"Abra uma partida de bilhar.",@"not_ready":@"Aguardando a mesa e a câmera…",
            @"unsupported":@"Essa leitura ainda não está disponível. Exporte o diagnóstico.",@"error":@"A leitura falhou. Exporte o diagnóstico.",@"stopped":@"Leitura interrompida."};
        if ([snapshot[@"reason"] isEqual:@"billiards_contract_mismatch"] &&
            [snapshot[@"environment"] isKindOfClass:NSDictionary.class]) {
            [self publishStatus:@"Diagnóstico do ambiente coletado. Exporte a leitura do bilhar."];
        } else {
            [self publishStatus:texts[status] ?: @"Aguardando o jogo…"];
        }
        return;
    }
    double width=[snapshot[@"screen"][@"width"] doubleValue],height=[snapshot[@"screen"][@"height"] doubleValue];
    if (!STBLValidViewport(width,height,rect.size.width,rect.size.height)) {
        [self invalidate:@"not_ready" reason:@"viewport_aspect_mismatch"]; [self publishStatus:@"Aguardando o enquadramento da mesa…"]; return;
    }
    STBLContext context={[snapshot[@"scene"][@"handle"] longLongValue],[snapshot[@"sessionId"] longLongValue],
        [snapshot[@"cameraInstanceId"] longLongValue],(uint32_t)width,(uint32_t)height};
    STBLFrameResult gate=STBLAcceptFrame(&_frameGate,context,[snapshot[@"frameNumber"] unsignedLongLongValue],now);
    BOOL draw=(gate==STBLFrameFresh || gate==STBLFrameDuplicate) && [status isEqual:@"aiming"] && [snapshot[@"prediction"][@"available"] boolValue];
    NSMutableDictionary *observed=[snapshot mutableCopy];
    observed[@"rendering"]=@{@"available":@(draw),@"frameGate":gate==STBLFrameReject?@"stale_frame":
        (gate==STBLFrameWarmup?@"warmup":(gate==STBLFrameDuplicate?@"duplicate_within_ttl":@"fresh")),
        @"frameAgeMs":@(MAX(0,(completed-_frameGate.advancedAt)*1000))};
    self.lastSnapshot=observed;
    if (gate==STBLFrameReject || gate==STBLFrameWarmup) {
        [self rememberSnapshot:observed];
        [self.drawing clear]; [self publishStatus:gate==STBLFrameReject?@"Aguardando uma leitura nova da mesa…":@"Conferindo a mesa e a câmera…"]; return;
    }
    if (gate==STBLFrameFresh) {
        self.accepted++;
        [self rememberSnapshot:observed];
    }
    if (!draw) {
        [self.drawing clear];
        [self publishStatus:[status isEqual:@"moving"]?@"Bolas em movimento; aguardando parar.":@"Mesa lida; aguardando uma mira válida."]; return;
    }
    self.drawing.snapshot=snapshot; self.drawing.gameRect=rect; self.drawing.acceptedBounds=self.drawing.bounds;
    self.drawing.expiresAt=_frameGate.advancedAt+STBL_STALE_SECONDS;
    [self.drawing setNeedsDisplay];
    [self publishStatus:[NSString stringWithFormat:@"Guia geométrica ativa · %lu bolas",(unsigned long)[snapshot[@"balls"] count]]];
}
- (NSURL *)exportReportWithError:(NSError **)error {
    if (!NSThread.isMainThread) { if(error)*error=STBLError(3,@"Exporte pelo menu do jogo."); return nil; }
    [self stopWithReason:@"export"];
    if (!self.lastSnapshot.count) { if(error)*error=STBLError(4,@"Ative o bilhar antes de exportar o diagnóstico."); return nil; }
    NSDictionary *report=@{@"format":@"SDKtools.BilliardsLiveCapture",@"schemaVersion":@1,@"toolVersion":@"3.16",
        @"createdUTC":[NSISO8601DateFormatter.new stringFromDate:NSDate.date],@"lastSnapshot":self.lastSnapshot,
        @"samples":[self.history copy],@"counts":@{@"attempts":@(self.attempts),@"accepted":@(self.accepted),@"rejected":@(self.rejected),
            @"slowSamples":@(self.slowSamples),@"omittedOlderSamples":@(self.omitted)},@"stopReason":self.stopReason,
        @"limits":@{@"historySamples":@(STBLHistoryLimit),@"staleSeconds":@(STBL_STALE_SECONDS),@"maximumHz":@10,@"slowModeHz":@4},
        @"environmentDiagnostics":@{@"schemaVersion":@1,@"mode":@"structural_only",
            @"automaticEnvironmentSwitch":@NO,@"initializationCalls":@NO,
            @"resourceGameIdSource":@"static_catalog_contract",@"gameTypeSource":@"static_module_contract",
            @"environmentGameTypes":@"observed_only_when_present"},
        @"policy":@{@"gameplayWrites":@NO,@"automaticShots":@NO,@"changesOriginalGuide":@NO,@"predictionModel":@"geometric",
            @"fullSpinFrictionModel":@NO,@"matchResultGuaranteed":@NO}};
    NSData *data=[NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingPrettyPrinted error:error];
    if (!data) return nil;
    if (data.length>4u*1024u*1024u) { if(error)*error=STBLError(5,@"O relatório excedeu o limite de exportação."); return nil; }
    NSURL *documents=[NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject;
    if (!documents.isFileURL) { if(error)*error=STBLError(6,@"A pasta de exportação não está disponível."); return nil; }
    NSURL *directory=[documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES];
    int root=open(documents.URLByResolvingSymlinksInPath.path.fileSystemRepresentation,O_RDONLY|O_DIRECTORY|O_CLOEXEC);
    if (root<0 || (mkdirat(root,"SDKtools",0700) && errno!=EEXIST)) { if(root>=0)close(root); if(error)*error=STBLError(6,@"Não foi possível abrir a pasta de exportação."); return nil; }
    int dir=openat(root,"SDKtools",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC); close(root);
    if (dir<0) { if(error)*error=STBLError(6,@"A pasta de exportação não é válida."); return nil; }
    NSString *name=[NSString stringWithFormat:@"SDKtools-BilliardsLive-%@.json",NSUUID.UUID.UUIDString];
    NSString *temporary=[@"." stringByAppendingString:name];
    int fd=openat(dir,temporary.fileSystemRepresentation,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    BOOL ok=fd>=0; size_t offset=0;
    while (ok && offset<data.length) {
        ssize_t written=write(fd,(const unsigned char *)data.bytes+offset,data.length-offset);
        if (written<0 && errno==EINTR) continue;
        if (written<=0) { ok=NO; break; } offset+=(size_t)written;
    }
    if (ok) ok=fsync(fd)==0;
    if (fd>=0 && close(fd)) ok=NO;
    NSURL *temporaryURL=[directory URLByAppendingPathComponent:temporary];
    if (ok) ok=[NSFileManager.defaultManager setAttributes:@{NSFileProtectionKey:NSFileProtectionComplete} ofItemAtPath:temporaryURL.path error:nil];
    if (ok) ok=renameat(dir,temporary.fileSystemRepresentation,dir,name.fileSystemRepresentation)==0;
    if (!ok) unlinkat(dir,temporary.fileSystemRepresentation,0);
    close(dir);
    if (!ok) { if(error)*error=STBLError(7,@"Não foi possível salvar o diagnóstico."); return nil; }
    NSURL *output=[directory URLByAppendingPathComponent:name]; [output setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
    return output;
}
@end

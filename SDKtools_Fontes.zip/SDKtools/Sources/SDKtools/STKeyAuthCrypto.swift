import Foundation
import CryptoKit

@_cdecl("STKeyAuthVerifyEd25519")
public func STKeyAuthVerifyEd25519(
    _ signature: UnsafePointer<UInt8>?, _ signatureLength: UInt,
    _ message: UnsafePointer<UInt8>?, _ messageLength: UInt,
    _ publicKey: UnsafePointer<UInt8>?, _ publicKeyLength: UInt
) -> Int32 {
    guard let signature = signature, signatureLength == 64,
          let publicKey = publicKey, publicKeyLength == 32,
          messageLength <= 1024 * 1024,
          messageLength == 0 || message != nil else { return 0 }

    let messageData: Data
    if let message = message {
        messageData = Data(bytes: message, count: Int(messageLength))
    } else {
        messageData = Data()
    }
    guard let key = try? Curve25519.Signing.PublicKey(
        rawRepresentation: Data(bytes: publicKey, count: 32)
    ) else { return 0 }
    return key.isValidSignature(Data(bytes: signature, count: 64), for: messageData) ? 1 : 0
}

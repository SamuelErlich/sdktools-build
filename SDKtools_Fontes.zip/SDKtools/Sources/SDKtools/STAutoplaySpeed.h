#ifndef ST_AUTOPLAY_SPEED_H
#define ST_AUTOPLAY_SPEED_H
// Requested polling cadence only. Action confirmation and physical locks remain independent.
static inline unsigned STAutoplayIntervalMilliseconds(unsigned level) {
    static const unsigned intervals[]={500,250,100,40,20,10,5,2};
    return level>=1 && level<=8 ? intervals[level-1] : 100;
}
static inline const char *STAutoplaySpeedName(unsigned level) {
    static const char *const names[]={"Slow · 500 ms","Moderate · 250 ms","Normal · 100 ms","Turbo · 40 ms",
        "Maximum · 20 ms","Test · 10 ms","Test · 5 ms","Test · 2 ms"};
    return names[level>=1 && level<=8 ? level-1 : 2];
}
#endif

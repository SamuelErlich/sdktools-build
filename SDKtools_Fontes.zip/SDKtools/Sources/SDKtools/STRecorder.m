#import "STRecorder.h"
#import "STWebProbe.h"
#import "STSceneCodec.h"
#import "STGameSourceExporter.h"
#import "STBilliardsResourceExporter.h"
#import "STCardEarlyCapture.h"
#import "STCardFeaturePolicy.h"
#include "STGameSourceNativePath.inc"
#include "STNativeActionPolicy.h"
#include "STNewGameCapturePolicy.h"
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <math.h>
#import <string.h>

NSNotificationName const STRecorderDidChangeNotification = @"STRecorderDidChangeNotification";

static const NSTimeInterval STMaximumDuration = 180.0;
static const NSUInteger STMaximumTouchSamples = 300;
static const NSUInteger STMaximumSnapshots = 320;
static const NSUInteger STMaximumEventSnapshots = 100;
static const NSUInteger STMaximumViews = 64;
static const NSUInteger STMaximumViewDepth = 8;
static const NSUInteger STMaximumMarkers = 40;
static const NSTimeInterval STMoveInterval = 0.1;
static const NSTimeInterval STWebInterval = 0.25;
static const NSUInteger STMaximumWebSamples = 720;
static const NSUInteger STMaximumPayloadBytes = 32 * 1024 * 1024;
static const NSUInteger STMetadataReserveBytes = 256 * 1024;
static const NSUInteger STMaximumWebSampleBytes = 1024 * 1024;
static IMP STPreviousSendEvent;
static Class STHookedApplicationClass;

static double STFinite(double value) { return isfinite(value) ? value : 0.0; }
static NSTimeInterval STNow(void) { return NSProcessInfo.processInfo.systemUptime; }
static NSString *STClassName(id value) {
    NSString *name = value ? NSStringFromClass(object_getClass(value)) : @"none";
    return [name substringToIndex:MIN(name.length, (NSUInteger)96)];
}
static NSDictionary *STPoint(CGPoint point) { return @{@"x": @(STFinite(point.x)), @"y": @(STFinite(point.y))}; }
static NSDictionary *STRect(CGRect rect) {
    return @{@"x": @(STFinite(rect.origin.x)), @"y": @(STFinite(rect.origin.y)),
             @"width": @(STFinite(rect.size.width)), @"height": @(STFinite(rect.size.height))};
}
static BOOL STIsOwnWindow(UIWindow *window) {
    Class overlay = NSClassFromString(@"STOverlayWindow");
    if (overlay && [window isKindOfClass:overlay]) return YES;
    // Walk actual runtime classes, including subclasses. No description or view text is read.
    for (Class cls = object_getClass(window); cls; cls = class_getSuperclass(cls))
        if ([NSStringFromClass(cls) isEqualToString:@"STOverlayWindow"]) return YES;
    return NO;
}
static BOOL STIsKeyboard(id object) {
    for (Class cls = object_getClass(object); cls; cls = class_getSuperclass(cls)) {
        NSString *name = NSStringFromClass(cls);
        if ([name containsString:@"Keyboard"] || [name containsString:@"InputSet"] ||
            [name containsString:@"TextEffects"] || [name isEqualToString:@"UIInputWindow"]) return YES;
    }
    return NO;
}
static BOOL STIsTextEntry(UIView *view) {
    if ([view isKindOfClass:UITextField.class] || [view isKindOfClass:UITextView.class]) return YES;
    if ([view conformsToProtocol:@protocol(UITextInputTraits)] &&
        [view respondsToSelector:@selector(isSecureTextEntry)] && [(id<UITextInputTraits>)view isSecureTextEntry]) return YES;
    // WKContentView implements UITextInput even for a noneditable game canvas.
    // Inspect a BOOL editing flag, never the input value or an arbitrary KVC property.
    if (![view conformsToProtocol:@protocol(UITextInput)]) return NO;
    SEL selector = NSSelectorFromString(@"isEditable");
    Method method = class_getInstanceMethod(object_getClass(view), selector);
    char type[8] = {0};
    if (!method || method_getNumberOfArguments(method) != 2) return NO;
    method_getReturnType(method, type, sizeof(type));
    if (strcmp(type, "B") && strcmp(type, "c")) return NO;
    return ((BOOL (*)(id, SEL))objc_msgSend)(view, selector);
}
static BOOL STWindowUsable(UIWindow *window) {
    if (!window || window.hidden || window.alpha < 0.01 || STIsOwnWindow(window) || STIsKeyboard(window)) return NO;
    UIWindowScene *scene = window.windowScene;
    return !scene || scene.activationState == UISceneActivationStateForegroundActive;
}
static NSString *STTouchExclusion(UITouch *touch) {
    UIWindow *window = touch.window;
    if (STIsOwnWindow(window)) return @"sdktoolsOverlay";
    if (!STWindowUsable(window)) return @"inactiveHiddenOrKeyboardWindow";
    UIView *view = touch.view;
    for (NSUInteger depth = 0; view && depth < 32; depth++, view = view.superview)
        if (STIsTextEntry(view) || STIsKeyboard(view)) return @"textInput";
    return nil;
}
static NSString *STTouchPhase(UITouchPhase phase) {
    switch (phase) {
        case UITouchPhaseBegan: return @"began";
        case UITouchPhaseMoved: return @"moved";
        case UITouchPhaseEnded: return @"ended";
        case UITouchPhaseCancelled: return @"cancelled";
        default: return @"stationary";
    }
}

static NSArray<UIViewController *> *STVisibleControllersChecked(UIWindow *window, BOOL *complete) {
    NSMutableArray *found = [NSMutableArray array];
    NSMutableArray *pending = [NSMutableArray array];
    if (window.rootViewController) [pending addObject:window.rootViewController];
    NSHashTable *seen = [NSHashTable weakObjectsHashTable];
    BOOL untruncated = YES;
    for (NSUInteger visit = 0; pending.count && visit < 32; visit++) {
        UIViewController *controller = pending.firstObject;
        [pending removeObjectAtIndex:0];
        if ([seen containsObject:controller]) continue;
        [seen addObject:controller];
        if (controller.isViewLoaded && controller.view.window == window && !controller.view.hidden)
            [found addObject:controller];
        if (controller.presentedViewController) [pending addObject:controller.presentedViewController];
        for (UIViewController *child in controller.childViewControllers) {
            if (pending.count >= 32) { untruncated = NO; break; }
            [pending addObject:child];
        }
    }
    if (complete) *complete = untruncated && !pending.count;
    return found;
}

static NSArray<UIViewController *> *STVisibleControllers(UIWindow *window) {
    return STVisibleControllersChecked(window, NULL);
}

// Only native object identity is compared in memory. This cannot identify a
// Unity scene, a game type or a match, and is never written into the report.
static NSSet *STBilliardsExportNativeContext(void) {
    if (!NSThread.isMainThread || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return nil;
    NSMutableOrderedSet<UIWindow *> *windows = [NSMutableOrderedSet orderedSet];
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if ([scene isKindOfClass:UIWindowScene.class] && scene.activationState == UISceneActivationStateForegroundActive)
            [windows addObjectsFromArray:((UIWindowScene *)scene).windows];
    }
    if (!windows.count) [windows addObjectsFromArray:UIApplication.sharedApplication.windows];
    if (windows.count > 16) return nil;
    NSMutableSet *context = [NSMutableSet set];
    NSUInteger hostWindows = 0;
    for (UIWindow *window in windows) {
        if (STIsOwnWindow(window) && !window.hidden && window.rootViewController.presentedViewController) return nil;
        if (!STWindowUsable(window)) continue;
        if (++hostWindows > 8) return nil;
        BOOL complete = NO;
        NSArray *controllers = STVisibleControllersChecked(window, &complete);
        if (!complete || !controllers.count) return nil;
        [context addObject:window];
        [context addObjectsFromArray:controllers];
        for (UIViewController *controller in controllers) {
            if (controller.isBeingPresented || controller.isBeingDismissed || controller.transitionCoordinator) return nil;
            [context addObject:controller.view];
        }
    }
    return hostWindows ? [context copy] : nil;
}

static NSDictionary *STBilliardsExportBoundedCounts(NSDictionary *diagnostic) {
    if (![diagnostic isKindOfClass:NSDictionary.class]) return @{};
    NSMutableDictionary *counts = [NSMutableDictionary dictionary];
    for (NSString *key in @[@"manifestsFound", @"manifestsAccepted", @"manifestsChanged", @"filesExported",
        @"filesMissing", @"filesChanged", @"bytesExported", @"entriesVisited"]) {
        id value = diagnostic[key];
        if (![value isKindOfClass:NSNumber.class] || !isfinite([value doubleValue]) || [value doubleValue] < 0) continue;
        double maximum = [key isEqualToString:@"bytesExported"] ? 64.0 * 1024 * 1024 : 1000000000.0;
        counts[key] = @((unsigned long long)MIN([value doubleValue], maximum));
    }
    if ([diagnostic[@"truncated"] isKindOfClass:NSNumber.class]) counts[@"truncated"] = @([diagnostic[@"truncated"] boolValue]);
    return [counts copy];
}

static BOOL STIsCocosController(UIViewController *controller) {
    for (Class cls = object_getClass(controller); cls; cls = class_getSuperclass(cls))
        if ([NSStringFromClass(cls) isEqualToString:@"WPCocosGameViewController"]) return YES;
    return NO;
}

static WKWebView *STFindGameWebView(UIView *root) {
    NSMutableArray<NSDictionary *> *pending = [NSMutableArray arrayWithObject:@{@"view": root, @"depth": @0}];
    for (NSUInteger visited = 0; pending.count && visited < 128; visited++) {
        NSDictionary *item = pending.firstObject;
        [pending removeObjectAtIndex:0];
        UIView *view = item[@"view"];
        NSUInteger depth = [item[@"depth"] unsignedIntegerValue];
        if (!view.window || view.hidden || view.alpha < 0.01 || STIsTextEntry(view) || STIsKeyboard(view)) continue;
        if ([view isKindOfClass:WKWebView.class]) return (WKWebView *)view;
        if (depth >= 12) continue;
        for (UIView *child in view.subviews) {
            if (pending.count >= 128) break;
            [pending addObject:@{@"view": child, @"depth": @(depth + 1)}];
        }
    }
    return nil;
}

static BOOL STControllerContains(UIViewController *ancestor, UIViewController *descendant) {
    for (NSUInteger depth = 0; descendant && depth < 32; depth++, descendant = descendant.parentViewController)
        if (descendant == ancestor) return YES;
    return NO;
}

static BOOL STActionViewVisible(UIView *view, UIView *root, UIWindow *window) {
    if (!view || view.window != window || !STWindowUsable(window)) return NO;
    BOOL reachedRoot = NO;
    for (NSUInteger depth = 0; view && depth < 32; depth++, view = view.superview) {
        if (view.hidden || view.alpha < 0.01 || CGRectIsEmpty(view.bounds)) return NO;
        if (view == root) { reachedRoot = YES; break; }
    }
    return reachedRoot;
}

// Fixed, bounded diagnostics: no URLs, text, object descriptions or identifiers.
static NSDictionary *STLastActionGateDiagnostics;
static STNativeActionGate STLastActionPolicyGate = STNativeActionUnavailable;
static NSString *STNativeGateReason(STNativeActionGate gate) {
    switch (gate) {
        case STNativeActionReady: return @"ready";
        case STNativeActionInactive: return @"application_inactive";
        case STNativeActionUnsupported: return @"unsupported_application";
        case STNativeActionScanLimit: return @"native_scan_limit";
        case STNativeActionAmbiguous: return @"ambiguous_native_webview";
        case STNativeActionModal: return @"native_modal_visible";
        case STNativeActionPresenting: return @"native_controller_presenting";
        case STNativeActionDismissing: return @"native_controller_dismissing";
        case STNativeActionLoading: return @"native_webview_loading";
        case STNativeActionObscured: return @"native_view_obscured";
        case STNativeActionWindowOverlap: return @"ambiguous_window_overlap";
        default: return @"native_context_unavailable";
    }
}
static WKWebView *STNativeGateResult(WKWebView *selected, NSString **reason, NSString *decision,
                                     STNativeActionFacts facts, NSUInteger windows) {
    if (reason) *reason = decision;
    NSMutableDictionary *diagnostics = [@{@"decision": decision, @"windowCount": @(windows),
        @"candidateObserved": @(facts.candidateVisible), @"scanComplete": @(facts.scanComplete),
        @"applicationActive": @(facts.applicationActive), @"supportedApplication": @(facts.supportedApplication),
        @"nativeModalVisible": @(facts.nativeModalVisible), @"nativeObscured": @(facts.nativeObscured),
        @"ambiguousWindowOverlap": @(facts.ambiguousWindowOverlap)} mutableCopy];
    if (facts.candidateVisible) {
        diagnostics[@"hostIsKeyWindow"] = @(facts.hostIsKeyWindow);
        diagnostics[@"hostWindowLevel"] = @(STFinite(facts.hostWindowLevel));
        diagnostics[@"controllerPresenting"] = @(facts.controllerPresenting);
        diagnostics[@"controllerDismissing"] = @(facts.controllerDismissing);
        diagnostics[@"webViewLoading"] = @(facts.webViewLoading);
    }
    STLastActionGateDiagnostics = [diagnostics copy];
    STLastActionPolicyGate = STNativeActionEvaluate(facts);
    return selected;
}

/// Discover one visible US 6.6.2/132 hosted game, optionally requiring its type.
/// A non-key host is valid: key status
/// controls keyboard routing, not visibility. Real transitions and obstructions
/// remain blocking and are diagnosed separately.
static WKWebView *STFindHostedGameWebView(NSNumber *requiredGameType, NSNumber **observedGameType,
                                         UIViewController **observedController, NSString **reason) {
    if (observedGameType) *observedGameType = nil;
    if (observedController) *observedController = nil;
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    STNativeActionFacts facts = {.applicationActive = UIApplication.sharedApplication.applicationState == UIApplicationStateActive,
        .supportedApplication = [info[@"CFBundleIdentifier"] isEqual:@"com.wejoy.weplay.us"] &&
            [info[@"CFBundleShortVersionString"] isEqual:@"6.6.2"] && [info[@"CFBundleVersion"] isEqual:@"132"],
        .scanComplete = true};
    if (!facts.applicationActive || !facts.supportedApplication)
        return STNativeGateResult(nil, reason, STNativeGateReason(STNativeActionEvaluate(facts)), facts, 0);
    NSMutableOrderedSet<UIWindow *> *windows = [NSMutableOrderedSet orderedSet];
    NSMutableOrderedSet<UIWindow *> *allWindows = [NSMutableOrderedSet orderedSet];
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        [allWindows addObjectsFromArray:((UIWindowScene *)scene).windows];
    }
    if (!allWindows.count) [allWindows addObjectsFromArray:UIApplication.sharedApplication.windows];
    for (UIWindow *window in allWindows) {
        // The menu itself is excluded, but its share sheet/video preview is modal.
        if (STIsOwnWindow(window) && !window.hidden && window.rootViewController.presentedViewController) {
            facts.nativeModalVisible = true;
            return STNativeGateResult(nil, reason, @"native_modal_visible", facts, windows.count);
        }
        if (STWindowUsable(window)) [windows addObject:window];
    }
    if (windows.count > 8) {
        facts.scanComplete = false;
        return STNativeGateResult(nil, reason, @"native_scan_limit", facts, windows.count);
    }
    WKWebView *selected = nil;
    UIViewController *selectedController = nil;
    NSNumber *selectedGameType = nil;
    for (UIWindow *window in windows) {
        BOOL complete = NO;
        NSArray<UIViewController *> *controllers = STVisibleControllersChecked(window, &complete);
        if (!complete) { facts.scanComplete = false; return STNativeGateResult(nil, reason, @"native_scan_limit", facts, windows.count); }
        for (UIViewController *controller in controllers) {
            if ([controller isKindOfClass:UIAlertController.class]) {
                facts.nativeModalVisible = true;
                return STNativeGateResult(nil, reason, @"native_modal_visible", facts, windows.count);
            }
            if (![NSStringFromClass(object_getClass(controller)) isEqualToString:@"WPCocosGameViewController"] ||
                !STActionViewVisible(controller.view, window, window)) continue;
            facts.candidateVisible = true; facts.windowUsable = true;
            facts.hostIsKeyWindow = window.isKeyWindow; facts.hostWindowLevel = window.windowLevel;
            facts.controllerPresenting = controller.isBeingPresented;
            facts.controllerDismissing = controller.isBeingDismissed;
            STNativeActionGate candidateGate = STNativeActionEvaluate(facts);
            if (candidateGate != STNativeActionReady)
                return STNativeGateResult(nil, reason, STNativeGateReason(candidateGate), facts, windows.count);
            for (UIViewController *visible in controllers) {
                UIViewController *presented = visible.presentedViewController;
                if (presented && !STControllerContains(presented, controller)) {
                    facts.nativeModalVisible = true;
                    return STNativeGateResult(nil, reason, @"native_modal_visible", facts, windows.count);
                }
            }
            SEL selector = NSSelectorFromString(@"gameType");
            Method getter = class_getInstanceMethod(object_getClass(controller), selector);
            const char *encoding = getter ? method_getTypeEncoding(getter) : NULL;
            if (!encoding || strcmp(encoding, "q16@0:8") != 0 || method_getNumberOfArguments(getter) != 2)
                return STNativeGateResult(nil, reason, @"game_type_abi_mismatch", facts, windows.count);
            long long gameType;
            @try { gameType = ((long long (*)(id, SEL))objc_msgSend)(controller, selector); }
            @catch (__unused NSException *exception) { return STNativeGateResult(nil, reason, @"game_type_unavailable", facts, windows.count); }
            if (gameType < 0 || gameType > 1000000)
                return STNativeGateResult(nil, reason, @"game_type_unavailable", facts, windows.count);
            if (requiredGameType && gameType != requiredGameType.longLongValue)
                return STNativeGateResult(nil, reason, @"different_game", facts, windows.count);
            NSMutableArray<UIView *> *pending = [NSMutableArray arrayWithObject:controller.view];
            NSUInteger visited = 0;
            while (pending.count && visited++ < 256) {
                UIView *view = pending.lastObject; [pending removeLastObject];
                if (!STActionViewVisible(view, controller.view, window) || STIsTextEntry(view) || STIsKeyboard(view)) continue;
                if ([view isKindOfClass:WKWebView.class]) {
                    if (selected && (selected != view || selectedController != controller)) {
                        facts.ambiguousWebView = true;
                        return STNativeGateResult(nil, reason, @"ambiguous_native_webview", facts, windows.count);
                    }
                    selected = (WKWebView *)view;
                    selectedController = controller;
                    selectedGameType = @(gameType);
                    continue;
                }
                if (pending.count + view.subviews.count > 256) { facts.scanComplete = false; return STNativeGateResult(nil, reason, @"native_scan_limit", facts, windows.count); }
                [pending addObjectsFromArray:view.subviews];
            }
            if (pending.count) { facts.scanComplete = false; return STNativeGateResult(nil, reason, @"native_scan_limit", facts, windows.count); }
        }
    }
    if (!selected || CGRectIsEmpty([selected convertRect:selected.bounds toView:selected.window]))
        return STNativeGateResult(nil, reason, @"native_context_unavailable", facts, windows.count);
    facts.webViewLoading = selected.loading;
    CGPoint center = CGPointMake(CGRectGetMidX(selected.bounds), CGRectGetMidY(selected.bounds));
    CGPoint windowPoint = [selected convertPoint:center toView:selected.window];
    UIView *hit = [selected.window hitTest:windowPoint withEvent:nil];
    facts.nativeObscured = hit != selected && ![hit isDescendantOfView:selected];
    // Window level establishes ordering across levels. Key-window state does
    // not establish touch order within a level. A hit in another same-level
    // window is ambiguous, so wait instead of guessing which window is above.
    for (UIWindow *other in windows) {
        if (other == selected.window || other.windowScene != selected.window.windowScene) continue;
        UIViewController *presented = other.rootViewController.presentedViewController;
        if (presented && presented.isViewLoaded && presented.view.window == other && !presented.view.hidden && presented.view.alpha >= 0.01) {
            facts.nativeModalVisible = true; break;
        }
        if (other.windowLevel < selected.window.windowLevel) continue;
        for (NSUInteger sample = 0; sample < 5; sample++) {
            CGFloat x = sample == 0 ? 0.5 : ((sample & 1) ? 0.25 : 0.75);
            CGFloat y = sample == 0 ? 0.5 : (sample < 3 ? 0.25 : 0.75);
            CGPoint point = CGPointMake(CGRectGetMinX(selected.bounds) + x * CGRectGetWidth(selected.bounds),
                                       CGRectGetMinY(selected.bounds) + y * CGRectGetHeight(selected.bounds));
            CGPoint otherPoint = [selected convertPoint:point toView:other];
            if ([other hitTest:otherPoint withEvent:nil]) {
                facts.nativeObscured = true;
                facts.ambiguousWindowOverlap = other.windowLevel == selected.window.windowLevel;
                break;
            }
        }
        if (facts.nativeObscured) break;
    }
    STNativeActionGate gate = STNativeActionEvaluate(facts);
    if (gate == STNativeActionReady) {
        if (observedGameType) *observedGameType = selectedGameType;
        if (observedController) *observedController = selectedController;
    }
    return STNativeGateResult(gate == STNativeActionReady ? selected : nil, reason, STNativeGateReason(gate), facts, windows.count);
}

// The action boundary remains fixed to the verified Crazy Alpaca identity.
static WKWebView *STFindReturnActionWebView(NSString **reason) {
    return STFindHostedGameWebView(@60, NULL, NULL, reason);
}

// Read-only discovery must not overwrite the independent autoplay diagnostics.
static WKWebView *STFindCaptureGame(NSNumber **type, UIViewController **controller, NSString **reason) {
    NSDictionary *previous = STLastActionGateDiagnostics;
    STNativeActionGate previousGate = STLastActionPolicyGate;
    WKWebView *result = nil;
    @try { result = STFindHostedGameWebView(nil, type, controller, reason); }
    @catch (__unused NSException *exception) { if (reason) *reason = @"native_context_unavailable"; }
    STLastActionGateDiagnostics = previous;
    STLastActionPolicyGate = previousGate;
    return result;
}

@interface STRecorder ()
@property (nonatomic, readwrite, getter=isRecording) BOOL recording;
@property (nonatomic) NSUInteger generation;
@property (nonatomic) NSUInteger nextTouchID;
@property (nonatomic) NSUInteger eventSnapshotCount;
@property (nonatomic) NSTimeInterval startedAt;
@property (nonatomic) NSTimeInterval stoppedAt;
@property (nonatomic) NSTimeInterval lastEventSnapshotAt;
@property (nonatomic, copy) NSString *startedDate;
@property (nonatomic, copy) NSString *sessionID;
@property (nonatomic, copy) NSString *stopReason;
@property (nonatomic, copy) NSString *startFailure;
@property (nonatomic, strong) NSMutableArray<NSMutableDictionary *> *touches;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *snapshots;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *markers;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *webSamples;
@property (nonatomic, strong) STWebProbe *webProbe;
@property (nonatomic, strong) STSceneCodec *sceneCodec;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *omitted;
@property (nonatomic, strong) NSMapTable<UITouch *, NSNumber *> *touchIDs;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, NSNumber *> *lastMove;
@property (nonatomic, copy) NSArray<NSNumber *> *unfinishedTouchIDs;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSTimer *webTimer;
@property (nonatomic, strong) NSTimer *detectedGameDetectionTimer;
@property (nonatomic, copy) NSString *detectedGameState;
@property (nonatomic, copy) NSString *detectedGameLastGate;
@property (nonatomic) NSTimeInterval detectedGameDetectionStartedAt;
@property (nonatomic, strong) NSNumber *detectedGameType;
@property (nonatomic, weak) WKWebView *detectedGameWebView;
@property (nonatomic, weak) UIViewController *detectedGameController;
@property (nonatomic, copy) NSURL *detectedGameDocumentURL; // Compared only in memory.
@property (nonatomic, copy) NSDictionary *detectedGameIdentity;
@property (nonatomic, copy) NSString *detectedGameProbeContextID;
@property (nonatomic) BOOL detectedGameCaptureScoped;
@property (nonatomic) BOOL startingNewGameCapture;
@property (nonatomic) BOOL startingCardInvestigation;
@property (nonatomic) BOOL startingCardFlow;
@property (nonatomic) BOOL cardFlowRequested;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *cardFlowSamples;
@property (nonatomic) BOOL cardInvestigationRequested;
@property (nonatomic, copy) NSString *cardInvestigationGate;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *cardInvestigationSamples;
@property (nonatomic, weak) WKWebView *cachedGameWebView;
@property (nonatomic, weak) UIViewController *cachedGameController;
@property (nonatomic) NSTimeInterval webCacheValidatedAt;
@property (nonatomic, strong) NSNumber *cachedNativeSnapshotID;
@property (nonatomic) NSUInteger payloadBytes;
@property (nonatomic) NSUInteger fullWebSamples;
@property (nonatomic) NSUInteger deltaWebSamples;
@property (nonatomic) NSUInteger deduplicatedWebSamples;
@property (nonatomic) NSUInteger sceneFullPayloadBytes;
@property (nonatomic) NSUInteger sceneEncodedPayloadBytes;
@property (nonatomic) NSUInteger sceneMaximumDependencyDepth;
@property (nonatomic) NSUInteger truncatedWebSamples;
@property (nonatomic) NSUInteger exportDroppedWebSamples;
@property (nonatomic) NSTimeInterval firstWebElapsedMs;
@property (nonatomic) NSTimeInterval lastWebElapsedMs;
@property (nonatomic) BOOL afterSnapshotPending;
@property (nonatomic, readwrite) BOOL returnTraceActive;
@property (nonatomic) BOOL returnTraceRequested;
@property (nonatomic) NSTimeInterval returnTraceStartedElapsedMs;
@property (nonatomic) NSUInteger returnTraceRequestedSamples;
@property (nonatomic) NSUInteger returnTraceMetadataSamples;
@property (nonatomic) NSUInteger returnTracePartialSamples;
@property (nonatomic, readwrite) BOOL returnActionBusy;
@property (nonatomic, copy, readwrite) NSString *returnActionStatus;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *returnActionEvents;
@property (nonatomic) NSUInteger returnActionSerial;
@property (nonatomic) NSUInteger actionContextGeneration;
@property (nonatomic, readwrite) BOOL sourceExportBusy;
@property (nonatomic, copy, readwrite) NSString *sourceExportStatus;
@property (nonatomic, copy) NSString *sourceExportNativePathStatus;
@property (nonatomic, copy) NSDictionary *sourceExportPathDiagnostic;
@property (nonatomic) NSInteger sourceExportErrorCode;
@property (nonatomic) BOOL sourceExportAttempted;
@property (nonatomic, copy, readwrite) NSDictionary *billiardsResourceExportDiagnostic;
@property (nonatomic, readwrite) BOOL autoplayEnabled;
@property (nonatomic, readwrite) BOOL xrayEnabled;
@property (nonatomic) BOOL cardHintsRequested;
@property (nonatomic, readwrite) BOOL cardHintsBusy;
@property (nonatomic, strong) NSTimer *cardHintsTimer;
@property (nonatomic) NSUInteger cardHintsSessionGeneration;
@property (nonatomic) BOOL cardHintsHasRuntime;
@property (nonatomic, weak) WKWebView *cardHintsWebView;
@property (nonatomic, weak) UIViewController *cardHintsController;
@property (nonatomic, copy) NSURL *cardHintsDocumentURL;
@property (nonatomic, copy) NSDictionary *cardHintsDiagnostic;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *cardHintsEvents;
@property (nonatomic, readwrite) NSInteger xrayDepth;
@property (nonatomic, copy) NSDictionary *xrayDiagnostic;
@property (nonatomic, copy) NSDictionary *autoplayPlanningDiagnostic;
@property (nonatomic, copy) NSDictionary *autoplayReadingDiagnostic;
@property (nonatomic) BOOL xrayHasRuntime;
@property (nonatomic, readwrite) BOOL autoplayBusy;
@property (nonatomic, readwrite) NSUInteger autoplayCardsRead;
@property (nonatomic, readwrite) NSUInteger autoplayCardTypesRead;
@property (nonatomic) NSUInteger autoplayEventSequence;
@property (nonatomic) NSTimeInterval autoplayDiagnosticOrigin;
@property (nonatomic) NSTimeInterval autoplayLastDiagnosticAt;
@property (nonatomic, readwrite) NSUInteger autoplayConfirmedMoves;
@property (nonatomic, copy) NSString *autoplayStatus;
@property (nonatomic, copy) NSString *autoplayReason;
@property (nonatomic, strong) NSTimer *autoplayTimer;
@property (nonatomic) NSUInteger autoplayResumeGeneration;
@property (nonatomic) NSUInteger autoplaySerial;
@property (nonatomic) NSTimeInterval autoplayStartedAt;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *autoplayEvents;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *autoplayRuntimeCounts;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSString *> *autoplayRuntimeDocuments;
- (BOOL)ensureEventObservation;
- (void)autoplayTick;
- (void)ensureAutoplayTimer;
- (void)appendAutoplayEvent:(NSDictionary *)event;
- (void)cardHintsTick;
- (void)acceptCardHintsDiagnostic:(NSDictionary *)diagnostic;
- (BOOL)cardHintsContextMatches;
- (NSArray<NSMutableDictionary *> *)beforeEvent:(UIEvent *)event;
- (void)afterEvent:(NSArray<NSMutableDictionary *> *)entries generation:(NSUInteger)generation;
- (NSNumber *)captureSnapshot:(NSString *)reason;
- (NSNumber *)buildSnapshot:(NSString *)reason;
- (void)countOmitted:(NSString *)reason;
- (void)notifyChange;
- (BOOL)reservePayloadObject:(id)object;
- (BOOL)reservePayloadByteCount:(NSUInteger)compactBytes;
- (void)sampleCachedGameWebView;
- (void)acceptWebSample:(NSDictionary *)sample nativeSnapshotID:(NSNumber *)snapshotID cacheAgeMs:(double)cacheAge;
- (NSDictionary *)reportObject;
- (NSData *)compactReportDataWithError:(NSError **)error;
- (void)newGameDetectionTick;
- (BOOL)newGameContextIsCurrent;
- (NSNumber *)buildNewGameSnapshot:(NSString *)reason;
@end

// Observe dispatch without replacing, duplicating, cancelling, or manufacturing app input.
// UIKit runs sendEvent on main. Unexpected off-main calls are forwarded untouched.
static void STObservedSendEvent(UIApplication *application, SEL selector, UIEvent *event) {
    STRecorder *recorder = STRecorder.shared;
    NSArray<NSMutableDictionary *> *entries = nil;
    NSUInteger generation = 0;
    if (NSThread.isMainThread && recorder.autoplayEnabled) {
        @try {
            for (UITouch *touch in event.allTouches) {
                if (touch.phase == UITouchPhaseBegan && !STIsOwnWindow(touch.window)) {
                    [recorder pauseAutoplayWithReason:@"manual_touch"];
                    break;
                }
            }
        } @catch (__unused NSException *exception) { [recorder countOmitted:@"observationException"]; }
    }
    if (NSThread.isMainThread && recorder.isRecording) {
        generation = recorder.generation;
        @try { entries = [recorder beforeEvent:event]; }
        @catch (__unused NSException *exception) { [recorder countOmitted:@"observationException"]; }
    }
    // Do not catch exceptions thrown by the original application or retry the original call.
    ((void (*)(id, SEL, UIEvent *))STPreviousSendEvent)(application, selector, event);
    if (NSThread.isMainThread && entries.count) {
        @try { [recorder afterEvent:entries generation:generation]; }
        @catch (__unused NSException *exception) { [recorder countOmitted:@"observationException"]; }
    }
}

@implementation STRecorder

+ (instancetype)shared {
    static STRecorder *value;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ value = [STRecorder new]; });
    return value;
}

- (instancetype)init {
    if ((self = [super init])) {
        _touches = [NSMutableArray array];
        _snapshots = [NSMutableArray array];
        _markers = [NSMutableArray array];
        _webSamples = [NSMutableArray array];
        _cardInvestigationSamples = [NSMutableArray array];
        _cardFlowSamples = [NSMutableArray array];
        _cardInvestigationGate = @"not_requested";
        _webProbe = [STWebProbe new];
        _sceneCodec = [STSceneCodec new];
        _omitted = [NSMutableDictionary dictionary];
        _touchIDs = [NSMapTable weakToStrongObjectsMapTable];
        _lastMove = [NSMutableDictionary dictionary];
        _unfinishedTouchIDs = @[];
        _stopReason = @"notStarted";
        _startFailure = @"";
        _sessionID = @"";
        _startedDate = @"";
        _detectedGameState = @"idle";
        _detectedGameLastGate = @"not_requested";
        _detectedGameIdentity = @{};
        _sourceExportStatus = @"idle";
        _sourceExportNativePathStatus = @"not_requested";
        _sourceExportPathDiagnostic = @{};
        _billiardsResourceExportDiagnostic = @{@"attempted": @NO, @"status": @"not_requested", @"errorCode": @0, @"counts": @{}};
        _returnActionStatus = @"idle";
        _returnActionEvents = [NSMutableArray array];
        _autoplayDiagnosticOrigin = STNow();
        _autoplayStatus = @"paused";
        NSInteger storedDepth = [NSUserDefaults.standardUserDefaults integerForKey:@"SDKtools.xrayDepth"];
        _xrayDepth = storedDepth >= 1 && storedDepth <= 5 ? storedDepth : 1;
        _xrayDiagnostic = @{@"status": @"off", @"coveredIcons": @0, @"matchedBorders": @0};
        _autoplayPlanningDiagnostic = @{};
        _autoplayReadingDiagnostic = @{};
        _autoplayReason = @"not_started";
        _cardHintsDiagnostic = @{@"status": @"off", @"reason": @"not_started", @"shown": @0, @"unknown": @0, @"unavailable": @0};
        _cardHintsEvents = [NSMutableArray array];
        _autoplayEvents = [NSMutableArray array];
        _autoplayRuntimeCounts = [NSMutableDictionary dictionary];
        _autoplayRuntimeDocuments = [NSMutableDictionary dictionary];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationBackgrounded:)
            name:UIApplicationDidEnterBackgroundNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionContextChanged:)
            name:UIApplicationWillResignActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionContextChanged:)
            name:UISceneWillDeactivateNotification object:nil];
    }
    return self;
}

- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; [_timer invalidate]; [_webTimer invalidate]; [_autoplayTimer invalidate]; [_detectedGameDetectionTimer invalidate]; [_cardHintsTimer invalidate]; }

- (void)actionContextChanged:(NSNotification *)notification {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ self.actionContextGeneration++; [self pauseAutoplayWithReason:@"application_inactive"]; [self setXrayEnabled:NO]; [self setCardHintsEnabled:NO]; });
    } else { self.actionContextGeneration++; [self pauseAutoplayWithReason:@"application_inactive"]; [self setXrayEnabled:NO]; [self setCardHintsEnabled:NO]; }
    // Invalidate the context, never release a pending WebKit action early.
}

- (void)applicationBackgrounded:(NSNotification *)notification {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self cancelNewGameDetection]; [self stopRecordingWithReason:@"background"]; });
    } else { [self cancelNewGameDetection]; [self stopRecordingWithReason:@"background"]; }
}

#include "STAutoplayRecorder.inc"
#include "STCardHintsRecorder.inc"
#include "STNewGameCapture.inc"
#include "STCardInvestigationRecorder.inc"
#include "STCardFlowRecorder.inc"
#include "STCardEarlyRecorder.inc"

- (void)notifyChange {
    NSAssert(NSThread.isMainThread, @"STRecorder requires the main thread");
    [[NSNotificationCenter defaultCenter] postNotificationName:STRecorderDidChangeNotification object:self];
}

- (void)countOmitted:(NSString *)reason {
    self.omitted[reason] = @(MIN([self.omitted[reason] unsignedIntegerValue] + 1, (NSUInteger)1000000));
}

- (BOOL)reservePayloadObject:(id)object {
    NSData *data = [NSJSONSerialization dataWithJSONObject:object options:NSJSONWritingSortedKeys error:nil];
    if (!data) { [self countOmitted:@"payloadSerializationFailed"]; return NO; }
    return [self reservePayloadByteCount:data.length];
}

- (BOOL)reservePayloadByteCount:(NSUInteger)compactBytes {
    NSUInteger size = compactBytes < NSUIntegerMax ? compactBytes + 1 : NSUIntegerMax; // Array separator.
    if (size > STMaximumPayloadBytes - STMetadataReserveBytes ||
        self.payloadBytes > STMaximumPayloadBytes - STMetadataReserveBytes - size) {
        [self countOmitted:@"payloadLimit"];
        [self stopRecordingWithReason:@"payloadLimit"];
        return NO;
    }
    self.payloadBytes += size;
    return YES;
}

- (NSString *)statusText {
    if (!NSThread.isMainThread) return @"Consulte na thread principal";
    if ([self.startFailure isEqualToString:@"inactiveApplication"]) return @"Abra o app para iniciar a captura";
    if ([self.startFailure isEqualToString:@"eventObservationUnavailable"]) return @"Não foi possível observar os toques";
    NSTimeInterval duration = self.startedAt > 0 ? (self.isRecording ? STNow() : self.stoppedAt) - self.startedAt : 0;
    if (!self.startedAt) return @"Nenhuma captura iniciada";
    NSString *label = self.isRecording ? @"Gravando" : @"Captura pronta";
    if (!self.isRecording && [self.stopReason isEqual:@"payloadLimit"]) label = @"Limite de 32 MiB atingido";
    else if (!self.isRecording && [self.stopReason isEqual:@"durationLimit"]) label = @"Limite de 180 s atingido";
    else if (!self.isRecording && [self.stopReason isEqual:@"touchLimit"]) label = @"Limite de toques atingido";
    NSDictionary *last = self.webSamples.lastObject;
    id cocos = last[@"cocos"];
    id descendants = [cocos isKindOfClass:NSDictionary.class] ? cocos[@"descendantNodeCount"] : nil;
    id sprites = [cocos isKindOfClass:NSDictionary.class] ? cocos[@"spriteNodeCount"] : nil;
    NSString *sceneDetail = @"Aguardando leitura da cena";
    NSString *status = [last[@"status"] isKindOfClass:NSString.class] ? last[@"status"] : @"";
    BOOL sceneObserved = [status isEqualToString:@"cocos2_scene_captured"] ||
        [status isEqualToString:@"cocos2_scene_observed_empty"];
    if (sceneObserved && [descendants isKindOfClass:NSNumber.class] && [sprites isKindOfClass:NSNumber.class]) {
        sceneDetail = [descendants unsignedIntegerValue] > 0 ?
            [NSString stringWithFormat:@"Última leitura: %lu elementos · %lu sprites",
                (unsigned long)[descendants unsignedIntegerValue], (unsigned long)[sprites unsignedIntegerValue]] :
            @"Última leitura: sem elementos observados";
    } else if ([status isEqualToString:@"cocos2_scene_observed_incomplete"])
        sceneDetail = @"Última leitura: observação incompleta";
    else if (last) sceneDetail = @"Última leitura: cena indisponível";
    if (self.returnTraceActive) sceneDetail = [sceneDetail stringByAppendingString:@"\nPoderes: rastreamento ativo"];
    return [NSString stringWithFormat:@"%@ · %.0f s · %lu eventos de toque · %lu leituras\n%@", label,
        MAX(0, duration), (unsigned long)self.touches.count, (unsigned long)self.webSamples.count, sceneDetail];
}

- (NSString *)captureSessionIdentifier { return NSThread.isMainThread ? [self.sessionID copy] : @""; }

- (BOOL)performOriginalPowerAtSlot:(NSString *)slot command:(NSString *)command update:(void (^)(NSDictionary<NSString *,id> *))update {
    NSAssert(NSThread.isMainThread, @"STRecorder requires the main thread");
    if (self.cardHintsEnabled || self.cardHintsBusy || self.detectedGameDetectionActive || self.detectedGameCaptureActive) {
        update(@{@"status": @"no_action", @"reason": @"native_context_unavailable", @"dispatched": @NO, @"physicalPending": @NO}); return NO;
    }
    if (!([@[@"left", @"center", @"right"] containsObject:slot] || ([slot isEqual:@"current"] && [command isEqual:@"confirm"])) ||
        ![@[@"open", @"confirm"] containsObject:command]) {
        update(@{@"status": @"no_action", @"reason": @"invalid_options", @"dispatched": @NO, @"physicalPending": @NO}); return NO;
    }
    if (self.sourceExportBusy) { update(@{@"status": @"no_action", @"reason": @"source_export_pending", @"dispatched": @NO, @"physicalPending": @NO}); return NO; }
    [self pauseAutoplayWithReason:@"power_requested"];
    if (self.returnActionBusy) {
        // Reject the new tap without unlocking or overwriting the older request.
        update(@{@"status": @"no_action", @"reason": @"return_action_pending", @"dispatched": @NO,
                 @"physicalPending": @YES, @"popupConfirmationRequired": @NO, @"boardEffectConfirmed": @NO});
        return NO;
    }
    NSString *reason = nil;
    WKWebView *webView = nil;
    @try { webView = STFindReturnActionWebView(&reason); }
    @catch (__unused NSException *exception) { reason = @"native_context_unavailable"; }
    if (!webView) {
        self.returnActionStatus = reason ?: @"native_context_unavailable";
        NSDictionary *event = @{@"status": @"no_action", @"reason": self.returnActionStatus, @"dispatched": @NO,
            @"physicalPending": @NO, @"popupConfirmationRequired": @NO, @"boardEffectConfirmed": @NO,
            @"runtimeValidated": @NO, @"actionSequence": @(++self.returnActionSerial),
            @"captureSessionID": self.isRecording ? self.sessionID : (id)NSNull.null,
            @"requestedElapsedMs": self.isRecording ? @(STFinite(MAX(0, (STNow() - self.startedAt) * 1000))) : (id)NSNull.null,
            @"requestAgeMs": @0, @"scope": @"explicit_original_power_action", @"slot": slot, @"command": command,
            @"nativeGate": STLastActionGateDiagnostics ?: @{}};
        if (self.returnActionEvents.count >= 24) [self.returnActionEvents removeObjectAtIndex:0];
        [self.returnActionEvents addObject:event];
        update(event);
        [self notifyChange];
        return NO;
    }
    // Set before entering the bridge; even a synchronous callback cannot leave a
    // second tap eligible. Capture start/stop never resets this action state.
    self.returnActionBusy = YES;
    self.returnActionStatus = [command isEqual:@"open"] ? @"opening_original_confirmation" : @"confirming_original_power";
    NSUInteger serial = ++self.returnActionSerial;
    NSTimeInterval requestedAt = STNow();
    NSString *captureID = self.isRecording ? [self.sessionID copy] : nil;
    NSNumber *captureElapsed = self.isRecording ? @(STFinite(MAX(0, (requestedAt - self.startedAt) * 1000))) : nil;
    if (self.isRecording) [self markEvent:@"returnActionRequested" details:@{@"source": @"overlay"}];
    [self notifyChange];
    NSURL *initialURL = [webView.URL copy]; // Compared in memory only; never exported.
    __weak WKWebView *weakWebView = webView;
    __weak UIWindow *weakWindow = webView.window;
    NSUInteger actionContextGeneration = self.actionContextGeneration;
    __weak STRecorder *weakSelf = self;
    return [self.webProbe performOriginalPowerInWebView:webView slot:slot command:command validateContext:^BOOL {
        WKWebView *expected = weakWebView;
        STRecorder *strongSelf = weakSelf;
        if (!expected || !strongSelf || strongSelf.actionContextGeneration != actionContextGeneration ||
            !weakWindow || expected.window != weakWindow || expected.loading || ![expected.URL isEqual:initialURL]) return NO;
        NSString *currentReason = nil;
        @try { return STFindReturnActionWebView(&currentReason) == expected; }
        @catch (__unused NSException *exception) { return NO; }
    } update:^(NSDictionary *result) {
        STRecorder *strongSelf = weakSelf;
        if (!strongSelf || strongSelf.returnActionSerial != serial) return;
        strongSelf.returnActionBusy = [result[@"physicalPending"] boolValue];
        strongSelf.returnActionStatus = result[@"status"] ?: @"dispatch_uncertain";
        NSMutableDictionary *event = [result mutableCopy];
        event[@"actionSequence"] = @(serial);
        event[@"captureSessionID"] = captureID ?: (id)NSNull.null;
        event[@"requestedElapsedMs"] = captureElapsed ?: (id)NSNull.null;
        event[@"requestAgeMs"] = @(STFinite(MAX(0, (STNow() - requestedAt) * 1000)));
        event[@"scope"] = @"explicit_original_power_action";
        event[@"slot"] = slot; event[@"command"] = command;
        event[@"nativeGate"] = STLastActionGateDiagnostics ?: @{};
        // Bounded in-memory diagnostics are exported only on an explicit report
        // request. They also work when no scene recording was started.
        if (strongSelf.returnActionEvents.count >= 24) [strongSelf.returnActionEvents removeObjectAtIndex:0];
        [strongSelf.returnActionEvents addObject:[event copy]];
        update(event);
        [strongSelf notifyChange];
    }];
}

- (BOOL)openOwnWarehouseWithUpdate:(void (^)(NSDictionary<NSString *,id> *))update {
    NSAssert(NSThread.isMainThread, @"STRecorder requires the main thread");
    if (self.cardHintsEnabled || self.cardHintsBusy || self.detectedGameDetectionActive || self.detectedGameCaptureActive) {
        update(@{@"status": @"no_action", @"reason": @"native_context_unavailable", @"dispatched": @NO, @"physicalPending": @NO}); return NO;
    }
    if (self.sourceExportBusy) { update(@{@"status": @"no_action", @"reason": @"source_export_pending", @"dispatched": @NO, @"physicalPending": @NO}); return NO; }
    [self pauseAutoplayWithReason:@"power_requested"];
    if (self.returnActionBusy) {
        // Reject the new tap without unlocking or overwriting the older request.
        update(@{@"status": @"no_action", @"reason": @"return_action_pending", @"dispatched": @NO,
                 @"physicalPending": @YES, @"popupConfirmationRequired": @NO, @"boardEffectConfirmed": @NO});
        return NO;
    }
    NSString *reason = nil;
    WKWebView *webView = nil;
    @try { webView = STFindReturnActionWebView(&reason); }
    @catch (__unused NSException *exception) { reason = @"native_context_unavailable"; }
    if (!webView) {
        self.returnActionStatus = reason ?: @"native_context_unavailable";
        NSDictionary *event = @{@"status": @"no_action", @"reason": self.returnActionStatus, @"dispatched": @NO,
            @"physicalPending": @NO, @"popupConfirmationRequired": @NO, @"boardEffectConfirmed": @NO,
            @"runtimeValidated": @NO, @"actionSequence": @(++self.returnActionSerial),
            @"captureSessionID": self.isRecording ? self.sessionID : (id)NSNull.null,
            @"requestedElapsedMs": self.isRecording ? @(STFinite(MAX(0, (STNow() - self.startedAt) * 1000))) : (id)NSNull.null,
            @"requestAgeMs": @0, @"scope": @"explicit_own_warehouse_action", @"command": @"open",
            @"nativeGate": STLastActionGateDiagnostics ?: @{}};
        if (self.returnActionEvents.count >= 24) [self.returnActionEvents removeObjectAtIndex:0];
        [self.returnActionEvents addObject:event];
        update(event);
        [self notifyChange];
        return NO;
    }
    // Set before entering the bridge; even a synchronous callback cannot leave a
    // second tap eligible. Capture start/stop never resets this action state.
    self.returnActionBusy = YES;
    self.returnActionStatus = @"opening_own_warehouse";
    NSUInteger serial = ++self.returnActionSerial;
    NSTimeInterval requestedAt = STNow();
    NSString *captureID = self.isRecording ? [self.sessionID copy] : nil;
    NSNumber *captureElapsed = self.isRecording ? @(STFinite(MAX(0, (requestedAt - self.startedAt) * 1000))) : nil;
    [self notifyChange];
    NSURL *initialURL = [webView.URL copy]; // Compared in memory only; never exported.
    __weak WKWebView *weakWebView = webView;
    __weak UIWindow *weakWindow = webView.window;
    NSUInteger actionContextGeneration = self.actionContextGeneration;
    __weak STRecorder *weakSelf = self;
    return [self.webProbe performOriginalWarehouseInWebView:webView validateContext:^BOOL {
        WKWebView *expected = weakWebView;
        STRecorder *strongSelf = weakSelf;
        if (!expected || !strongSelf || strongSelf.actionContextGeneration != actionContextGeneration ||
            !weakWindow || expected.window != weakWindow || expected.loading || ![expected.URL isEqual:initialURL]) return NO;
        NSString *currentReason = nil;
        @try { return STFindReturnActionWebView(&currentReason) == expected; }
        @catch (__unused NSException *exception) { return NO; }
    } update:^(NSDictionary *result) {
        STRecorder *strongSelf = weakSelf;
        if (!strongSelf || strongSelf.returnActionSerial != serial) return;
        strongSelf.returnActionBusy = [result[@"physicalPending"] boolValue];
        strongSelf.returnActionStatus = result[@"status"] ?: @"dispatch_uncertain";
        NSMutableDictionary *event = [result mutableCopy];
        event[@"actionSequence"] = @(serial);
        event[@"captureSessionID"] = captureID ?: (id)NSNull.null;
        event[@"requestedElapsedMs"] = captureElapsed ?: (id)NSNull.null;
        event[@"requestAgeMs"] = @(STFinite(MAX(0, (STNow() - requestedAt) * 1000)));
        event[@"scope"] = @"explicit_own_warehouse_action";
        event[@"command"] = @"open"; event[@"ownerOnly"] = @YES;
        event[@"nativeGate"] = STLastActionGateDiagnostics ?: @{};
        // Bounded in-memory diagnostics are exported only on an explicit report
        // request. They also work when no scene recording was started.
        if (strongSelf.returnActionEvents.count >= 24) [strongSelf.returnActionEvents removeObjectAtIndex:0];
        [strongSelf.returnActionEvents addObject:[event copy]];
        update(event);
        [strongSelf notifyChange];
    }];
}

- (BOOL)beginReturnTrace {
    NSAssert(NSThread.isMainThread, @"STRecorder requires the main thread");
    if (self.detectedGameCaptureScoped || self.detectedGameDetectionActive || !self.isRecording || self.returnTraceActive || self.markers.count >= STMaximumMarkers) return NO;
    self.returnTraceRequested = YES;
    self.returnTraceActive = YES;
    self.returnTraceStartedElapsedMs = STFinite(MAX(0, (STNow() - self.startedAt) * 1000));
    [self.webProbe setTraceControlsEnabled:YES];
    [self markEvent:@"returnTraceStarted" details:@{@"source": @"overlay"}];
    [self notifyChange];
    return self.isRecording && self.returnTraceActive;
}

- (void)startRecording {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self startRecording]; }); return; }
    if (self.isRecording || self.sourceExportBusy || self.cardEarlyActive) return;
    self.cardInvestigationRequested = ST_CARD_GAME_FEATURE_ENABLED && self.startingCardInvestigation;
    self.cardFlowRequested = ST_CARD_GAME_FEATURE_ENABLED && self.startingCardInvestigation && self.startingCardFlow;
    [self.cardFlowSamples removeAllObjects];
    [self.cardInvestigationSamples removeAllObjects];
    if (!ST_CARD_GAME_FEATURE_ENABLED) self.cardInvestigationGate = @"feature_disabled";
    else if (!self.startingCardInvestigation) self.cardInvestigationGate = @"not_requested";
    [self setCardHintsEnabled:NO];
    if (!self.startingNewGameCapture) {
        [self cancelNewGameDetection];
        self.detectedGameCaptureScoped = NO;
        self.detectedGameIdentity = @{};
        self.detectedGameState = @"idle";
    }
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
        self.startFailure = @"inactiveApplication";
        [self notifyChange];
        return;
    }
    [self pauseAutoplayWithReason:@"recording_started"];
    [self setXrayEnabled:NO];
    if (![self ensureEventObservation]) {
        self.startFailure = @"eventObservationUnavailable";
        [self notifyChange];
        return;
    }
    self.generation++;
    self.startFailure = @"";
    self.nextTouchID = 0;
    self.eventSnapshotCount = 0;
    self.payloadBytes = 0;
    self.fullWebSamples = 0;
    self.deltaWebSamples = 0;
    self.deduplicatedWebSamples = 0;
    self.sceneFullPayloadBytes = 0;
    self.sceneEncodedPayloadBytes = 0;
    self.sceneMaximumDependencyDepth = 0;
    self.truncatedWebSamples = 0;
    self.exportDroppedWebSamples = 0;
    self.firstWebElapsedMs = -1;
    self.lastWebElapsedMs = -1;
    self.returnTraceActive = NO;
    self.returnTraceRequested = NO;
    self.returnTraceStartedElapsedMs = 0;
    self.returnTraceRequestedSamples = 0;
    self.returnTraceMetadataSamples = 0;
    self.returnTracePartialSamples = 0;
    [self.sceneCodec reset];
    self.cachedGameWebView = nil;
    self.cachedGameController = nil;
    self.cachedNativeSnapshotID = nil;
    self.webCacheValidatedAt = 0;
    self.startedAt = STNow();
    self.stoppedAt = 0;
    self.lastEventSnapshotAt = 0;
    self.afterSnapshotPending = NO;
    self.stopReason = @"recording";
    self.sessionID = NSUUID.UUID.UUIDString;
    self.startedDate = [[NSISO8601DateFormatter new] stringFromDate:NSDate.date];
    [self.touches removeAllObjects]; [self.snapshots removeAllObjects]; [self.markers removeAllObjects];
    [self.webSamples removeAllObjects]; [self.webProbe reset];
    [self.webProbe setCardInvestigationEnabled:self.cardInvestigationRequested];
    [self.webProbe setCardFlowEnabled:self.cardFlowRequested];
    [self.omitted removeAllObjects]; [self.touchIDs removeAllObjects]; [self.lastMove removeAllObjects];
    self.unfinishedTouchIDs = @[];
    self.recording = YES;
    [self captureSnapshot:@"recordingStarted"];
    __weak STRecorder *weakSelf = self;
    NSUInteger generation = self.generation;
    self.timer = [NSTimer timerWithTimeInterval:1.0 repeats:YES block:^(__unused NSTimer *timer) {
        STRecorder *strongSelf = weakSelf;
        if (!strongSelf.isRecording || strongSelf.generation != generation) return;
        if (STNow() - strongSelf.startedAt >= (strongSelf.cardInvestigationRequested ? 90.0 : STMaximumDuration)) {
            [strongSelf stopRecordingWithReason:@"durationLimit"];
        } else if (strongSelf.touches.count >= STMaximumTouchSamples) {
            [strongSelf stopRecordingWithReason:@"touchLimit"];
        } else {
            [strongSelf captureSnapshot:@"periodic"];
            [strongSelf notifyChange];
        }
    }];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    self.webTimer = [NSTimer timerWithTimeInterval:(self.cardInvestigationRequested ? 0.5 : STWebInterval) repeats:YES block:^(__unused NSTimer *timer) {
        STRecorder *strongSelf = weakSelf;
        if (!strongSelf.isRecording || strongSelf.generation != generation) return;
        if (STNow() - strongSelf.startedAt >= (strongSelf.cardInvestigationRequested ? 90.0 : STMaximumDuration)) [strongSelf stopRecordingWithReason:@"durationLimit"];
        else [strongSelf sampleCachedGameWebView];
    }];
    self.webTimer.tolerance = 0.025;
    [[NSRunLoop mainRunLoop] addTimer:self.webTimer forMode:NSRunLoopCommonModes];
    [self notifyChange];
}

- (void)stopRecordingWithReason:(NSString *)reason {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self stopRecordingWithReason:reason]; }); return;
    }
    if (!self.isRecording) return;
    self.recording = NO;
    self.returnTraceActive = NO;
    self.stoppedAt = STNow();
    NSSet *knownReasons = [NSSet setWithArray:@[@"user", @"background", @"durationLimit", @"touchLimit", @"payloadLimit", @"export", @"overlayClosed", @"gameContextChanged", @"investigationSampleLimit"]];
    self.stopReason = [knownReasons containsObject:reason] ? reason : @"user";
    if (self.detectedGameCaptureScoped) self.detectedGameState = @"complete";
    self.generation++;
    [self.timer invalidate]; self.timer = nil;
    [self.webTimer invalidate]; self.webTimer = nil;
    self.cachedGameWebView = nil; self.cachedGameController = nil;
    self.afterSnapshotPending = NO;
    [self.webProbe stop];
    self.unfinishedTouchIDs = [[self.touchIDs objectEnumerator].allObjects sortedArrayUsingSelector:@selector(compare:)];
    [self.touchIDs removeAllObjects]; [self.lastMove removeAllObjects];
    [self notifyChange];
}

- (NSNumber *)captureSnapshot:(NSString *)reason {
    @try { return [self buildSnapshot:reason]; }
    @catch (__unused NSException *exception) { [self countOmitted:@"snapshotException"]; return nil; }
}

- (NSNumber *)buildSnapshot:(NSString *)reason {
    NSAssert(NSThread.isMainThread, @"STRecorder requires the main thread");
    if (!self.isRecording) return nil;
    if (self.detectedGameCaptureScoped) return [self buildNewGameSnapshot:reason];
    if (self.snapshots.count >= STMaximumSnapshots) { [self countOmitted:@"snapshotLimit"]; return nil; }
    NSMutableArray<UIWindow *> *windows = [NSMutableArray array];
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows)
            if (STWindowUsable(window)) [windows addObject:window];
    }
    if (!windows.count) {
        for (UIWindow *window in UIApplication.sharedApplication.windows)
            if (STWindowUsable(window)) [windows addObject:window];
    }
    [windows sortUsingComparator:^NSComparisonResult(UIWindow *a, UIWindow *b) {
        if (a.isKeyWindow != b.isKeyWindow) return a.isKeyWindow ? NSOrderedAscending : NSOrderedDescending;
        if (a.windowLevel > b.windowLevel) return NSOrderedAscending;
        if (a.windowLevel < b.windowLevel) return NSOrderedDescending;
        return NSOrderedSame;
    }];
    NSMutableArray *windowReports = [NSMutableArray array];
    NSMutableArray *nodes = [NSMutableArray array];
    NSMutableSet *renderers = [NSMutableSet set];
    WKWebView *gameWebView = nil;
    UIViewController *gameController = nil;
    BOOL truncated = windows.count > 3;
    for (NSUInteger windowIndex = 0; windowIndex < MIN(windows.count, (NSUInteger)3); windowIndex++) {
        UIWindow *window = windows[windowIndex];
        NSArray<UIViewController *> *controllers = STVisibleControllers(window);
        NSMutableArray *controllerReports = [NSMutableArray array];
        for (UIViewController *controller in controllers) {
            NSMutableDictionary *controllerReport = [@{@"class": STClassName(controller)} mutableCopy];
            if (STIsCocosController(controller)) {
                if (!gameWebView) {
                    WKWebView *candidate = STFindGameWebView(controller.view);
                    if (candidate) { gameWebView = candidate; gameController = controller; }
                }
                controllerReport[@"cocosContainerObserved"] = @YES;
                controllerReport[@"gameTypeGetterRead"] = @NO;
            }
            [controllerReports addObject:controllerReport];
        }
        [windowReports addObject:@{@"index": @(windowIndex), @"class": STClassName(window),
            @"boundsPoints": STRect(window.bounds), @"screenScale": @(STFinite(window.screen.scale)),
            @"orientation": @(window.windowScene.interfaceOrientation), @"isKeyWindow": @(window.isKeyWindow),
            @"safeAreaInsets": @{@"top": @(STFinite(window.safeAreaInsets.top)), @"left": @(STFinite(window.safeAreaInsets.left)),
                @"bottom": @(STFinite(window.safeAreaInsets.bottom)), @"right": @(STFinite(window.safeAreaInsets.right))},
            @"rootControllerClass": STClassName(window.rootViewController), @"visibleControllers": controllerReports}];
        NSMutableArray<NSDictionary *> *pending = [NSMutableArray arrayWithObject:@{@"view": window, @"parent": @(-1), @"depth": @0}];
        NSUInteger visited = 0;
        while (pending.count && nodes.count < STMaximumViews && visited < 256) {
            NSDictionary *item = pending.firstObject;
            [pending removeObjectAtIndex:0];
            visited++;
            UIView *view = item[@"view"];
            NSUInteger depth = [item[@"depth"] unsignedIntegerValue];
            if (view.hidden || view.alpha < 0.01 || STIsKeyboard(view)) continue;
            NSUInteger nodeID = nodes.count;
            BOOL textEntry = STIsTextEntry(view);
            CGRect windowRect = [view convertRect:view.bounds toView:window];
            NSMutableDictionary *node = [@{@"id": @(nodeID), @"parent": item[@"parent"], @"depth": @(depth),
                @"window": @(windowIndex), @"class": STClassName(view), @"rectInWindowPoints": STRect(windowRect),
                @"interactive": @(view.userInteractionEnabled), @"alpha": @(STFinite(view.alpha)),
                @"clipsToBounds": @(view.clipsToBounds), @"textEntryRedacted": @(textEntry)} mutableCopy];
            if ([view isKindOfClass:UIControl.class]) {
                UIControl *control = (UIControl *)view;
                node[@"enabled"] = @(control.enabled); node[@"selected"] = @(control.selected);
            }
            NSString *viewClass = STClassName(view);
            NSString *layerClass = STClassName(view.layer);
            if ([viewClass containsString:@"Unity"] || [viewClass containsString:@"Metal"] ||
                [layerClass isEqualToString:@"CAMetalLayer"] || [layerClass isEqualToString:@"CAEAGLLayer"]) {
                node[@"renderSurface"] = layerClass;
                [renderers addObject:@"nativeRenderedSurface"];
            }
            if ([view isKindOfClass:WKWebView.class]) {
                [renderers addObject:@"webView"];
            }
            [nodes addObject:node];
            if (textEntry) continue; // No editor contents, descendants, accessibility values, or text.
            if (depth >= STMaximumViewDepth) { if (view.subviews.count) truncated = YES; continue; }
            for (UIView *child in view.subviews) {
                if (pending.count >= 256) { truncated = YES; break; }
                [pending addObject:@{@"view": child, @"parent": @(nodeID), @"depth": @(depth + 1)}];
            }
        }
        if (pending.count) truncated = YES;
    }
    NSNumber *snapshotID = @(self.snapshots.count + 1);
    NSDictionary *snapshot = @{@"id": snapshotID, @"elapsedMs": @(STFinite((STNow() - self.startedAt) * 1000)),
        @"reason": reason, @"windows": windowReports, @"views": nodes, @"truncated": @(truncated),
        @"renderersObserved": [renderers.allObjects sortedArrayUsingSelector:@selector(compare:)],
        @"gameWebViewEligible": @(gameWebView != nil), @"internalGameStateCaptured": @NO};
    if (![self reservePayloadObject:snapshot]) return nil;
    [self.snapshots addObject:snapshot];
    // Independent 4 Hz sampling uses these weak references. Full controller/view
    // discovery stays at native snapshot cadence instead of running every 250 ms.
    self.cachedGameWebView = gameWebView;
    self.cachedGameController = gameController;
    self.cachedNativeSnapshotID = snapshotID;
    self.webCacheValidatedAt = STNow();
    return snapshotID;
}

- (void)sampleCachedGameWebView {
    if (!self.isRecording) return;
    if (self.cardInvestigationRequested && self.webSamples.count >= 200) {
        [self stopRecordingWithReason:@"investigationSampleLimit"]; return;
    }
    if (self.detectedGameCaptureScoped && ![self newGameContextIsCurrent]) return;
    if (self.webSamples.count >= STMaximumWebSamples) { [self countOmitted:@"webSampleLimit"]; return; }
    WKWebView *webView = self.cachedGameWebView;
    UIViewController *controller = self.cachedGameController;
    double cacheAge = STNow() - self.webCacheValidatedAt;
    if (!webView || !controller || cacheAge < 0 || cacheAge > 1.5 || !self.cachedNativeSnapshotID) {
        [self countOmitted:@"webCacheUnavailableOrExpired"]; return;
    }
    if (!controller.isViewLoaded || !STIsCocosController(controller) || !STWindowUsable(webView.window) ||
        controller.view.window != webView.window || ![webView isDescendantOfView:controller.view]) {
        [self countOmitted:@"webCacheNoLongerInCocosController"]; return;
    }
    UIView *ancestor = webView;
    BOOL reachedController = NO;
    for (NSUInteger depth = 0; ancestor && depth < 16; depth++, ancestor = ancestor.superview) {
        if (ancestor.hidden || ancestor.alpha < 0.01) { [self countOmitted:@"webCacheHiddenAncestor"]; return; }
        if (ancestor == controller.view) { reachedController = YES; break; }
    }
    if (!reachedController) { [self countOmitted:@"webCacheAncestorLimit"]; return; }
    NSUInteger generation = self.generation;
    NSNumber *snapshotID = self.cachedNativeSnapshotID;
    __weak STRecorder *weakSelf = self;
    [self.webProbe sampleWebView:webView elapsedMilliseconds:(STNow() - self.startedAt) * 1000
        completion:^(NSDictionary *sample) {
            STRecorder *strongSelf = weakSelf;
            if (!strongSelf.isRecording || strongSelf.generation != generation) return;
            if (strongSelf.detectedGameCaptureScoped && ![strongSelf newGameContextIsCurrent]) return;
            [strongSelf acceptWebSample:sample nativeSnapshotID:snapshotID cacheAgeMs:cacheAge * 1000];
        }];
}

- (void)acceptWebSample:(NSDictionary *)sample nativeSnapshotID:(NSNumber *)snapshotID cacheAgeMs:(double)cacheAge {
    if (!self.isRecording || self.webSamples.count >= STMaximumWebSamples) return;
    if (self.cardInvestigationRequested && [sample[@"status"] isEqual:@"probe_document_changed"]) {
        [self stopRecordingWithReason:@"gameContextChanged"]; return;
    }
    if (self.detectedGameCaptureScoped) {
        NSString *context = [sample[@"contextID"] isKindOfClass:NSString.class] ? sample[@"contextID"] : nil;
        if (context.length && self.detectedGameProbeContextID.length && ![context isEqual:self.detectedGameProbeContextID]) {
            [self stopRecordingWithReason:@"gameContextChanged"]; return;
        }
        if (context.length) self.detectedGameProbeContextID = context;
        NSMutableDictionary *identity = [self.detectedGameIdentity mutableCopy];
        NSDictionary *cocos = [sample[@"cocos"] isKindOfClass:NSDictionary.class] ? sample[@"cocos"] : @{};
        // A bridge timeout has no engine evidence. Preserve the most recent
        // actual observation while reporting the current attempt separately.
        if ([cocos[@"exposed"] isEqual:@YES]) {
            identity[@"engine"] = @"cocos";
            identity[@"engineVersion"] = cocos[@"version"] ?: @"unknown";
        } else if ([sample[@"status"] isEqual:@"cocos_not_exposed"]) {
            identity[@"engine"] = @"not_exposed";
            identity[@"engineVersion"] = @"unknown";
        }
        identity[@"sceneStatus"] = sample[@"status"] ?: @"unavailable";
        identity[@"sceneReadSupported"] = @([sample[@"status"] hasPrefix:@"cocos2_scene_"]);
        self.detectedGameIdentity = identity;
    }
    NSMutableDictionary *linked = [sample mutableCopy];
    // Keep investigation evidence independent of scene delta/identity codecs.
    [linked removeObjectForKey:@"cardInvestigation"];
    [linked removeObjectForKey:@"cardFlow"];
    NSNumber *sequence = @(self.webSamples.count + 1);
    linked[@"sequence"] = sequence;
    linked[@"nativeSnapshotID"] = snapshotID;
    linked[@"nativeSnapshotAgeMsAtRequest"] = @(STFinite(cacheAge));
    id nodes = sample[@"sceneNodes"];
    NSString *contextID = [sample[@"contextID"] isKindOfClass:NSString.class] ? sample[@"contextID"] : nil;
    NSString *webViewID = [sample[@"webViewID"] isKindOfClass:NSString.class] ? sample[@"webViewID"] : nil;
    STSceneEncodingCandidate *candidate = [nodes isKindOfClass:NSArray.class] ?
        [self.sceneCodec prepareNodes:nodes contextID:contextID webViewID:webViewID sequence:sequence.unsignedIntegerValue] : nil;
    if (candidate) {
        [linked removeObjectForKey:@"sceneNodes"];
        [linked removeObjectForKey:@"sceneNodesRefSequence"];
        [linked removeObjectForKey:@"sceneNodesDelta"];
        [linked addEntriesFromDictionary:candidate.fields];
    }
    NSData *encoded = [NSJSONSerialization dataWithJSONObject:linked options:NSJSONWritingSortedKeys error:nil];
    if (!encoded) { [self countOmitted:@"webSampleSerializationFailed"]; return; }
    if (encoded.length > STMaximumWebSampleBytes) {
        [self countOmitted:@"webSamplePayloadLimit"];
        linked = [@{@"sequence": sequence, @"nativeSnapshotID": snapshotID, @"status": @"native_sample_payload_limit",
            @"requestedElapsedMs": sample[@"requestedElapsedMs"] ?: @0, @"rejectedCompactBytes": @(encoded.length)} mutableCopy];
        candidate = nil;
        encoded = [NSJSONSerialization dataWithJSONObject:linked options:NSJSONWritingSortedKeys error:nil];
        if (!encoded) { [self countOmitted:@"webSampleSerializationFailed"]; return; }
    }
    if (![self reservePayloadByteCount:encoded.length]) return;
    [self.webSamples addObject:linked];
    if (self.cardInvestigationRequested) {
        NSDictionary *observation = [sample[@"cardInvestigation"] isKindOfClass:NSDictionary.class] ? sample[@"cardInvestigation"] : nil;
        NSMutableDictionary *evidence = [@{@"sequence": sequence, @"nativeSnapshotID": snapshotID,
            @"requestedElapsedMs": sample[@"requestedElapsedMs"] ?: @0,
            @"observation": observation ?: @{@"version": @1, @"status": @"unavailable", @"reason": @"probe_result_unavailable"}} mutableCopy];
        if (contextID) evidence[@"contextID"] = contextID;
        if (webViewID) evidence[@"webViewID"] = webViewID;
        if ([self reservePayloadObject:evidence]) [self.cardInvestigationSamples addObject:evidence];
    }
    if (self.cardFlowRequested) {
        NSDictionary *observation = [sample[@"cardFlow"] isKindOfClass:NSDictionary.class] ? sample[@"cardFlow"] : nil;
        NSMutableDictionary *evidence = [@{@"sequence": sequence, @"nativeSnapshotID": snapshotID,
            @"requestedElapsedMs": sample[@"requestedElapsedMs"] ?: @0,
            @"observation": observation ?: @{@"version": @1, @"status": @"unavailable", @"reason": @"probe_result_unavailable", @"events": @[]}} mutableCopy];
        if (contextID) evidence[@"contextID"] = contextID;
        if (webViewID) evidence[@"webViewID"] = webViewID;
        if ([self reservePayloadObject:evidence]) [self.cardFlowSamples addObject:evidence];
    }
    if ([sample[@"controlTraceRequested"] isEqual:@YES]) {
        self.returnTraceRequestedSamples++;
        NSDictionary *trace = [linked[@"controlTrace"] isKindOfClass:NSDictionary.class] ? linked[@"controlTrace"] : nil;
        if ([trace[@"enabled"] isEqual:@YES]) {
            self.returnTraceMetadataSamples++;
            if ([trace[@"truncated"] isEqual:@YES]) self.returnTracePartialSamples++;
        }
    }
    // Only accepted samples can become a target. A payload rejection or a
    // stop during reservation leaves the previous materialized scene untouched.
    if (candidate && [self.sceneCodec commitCandidate:candidate]) {
        NSString *encoding = candidate.fields[@"sceneNodesEncoding"];
        if ([encoding isEqualToString:@"full"]) self.fullWebSamples++;
        else if ([encoding isEqualToString:@"delta"]) self.deltaWebSamples++;
        else if ([encoding isEqualToString:@"reference"]) self.deduplicatedWebSamples++;
        self.sceneFullPayloadBytes += candidate.fullPayloadBytes;
        self.sceneEncodedPayloadBytes += candidate.encodedPayloadBytes;
        self.sceneMaximumDependencyDepth = MAX(self.sceneMaximumDependencyDepth, candidate.dependencyDepth);
    }
    if ([sample[@"cocos"] isKindOfClass:NSDictionary.class] && [sample[@"cocos"][@"truncated"] boolValue]) self.truncatedWebSamples++;
    double elapsed = [sample[@"requestedElapsedMs"] doubleValue];
    if (isfinite(elapsed)) { if (self.firstWebElapsedMs < 0) self.firstWebElapsedMs = elapsed; self.lastWebElapsedMs = elapsed; }
}

- (NSArray<NSMutableDictionary *> *)beforeEvent:(UIEvent *)event {
    if (!self.isRecording || event.type != UIEventTypeTouches) return @[];
    NSTimeInterval now = STNow();
    if (now - self.startedAt >= STMaximumDuration) { [self stopRecordingWithReason:@"durationLimit"]; return @[]; }
    NSMutableArray *accepted = [NSMutableArray array];
    NSNumber *beforeID = self.snapshots.lastObject[@"id"];
    BOOL sampledBefore = NO;
    BOOL scopeValidated = NO;
    for (UITouch *touch in event.allTouches) {
        UITouchPhase phase = touch.phase;
        if (phase != UITouchPhaseBegan && phase != UITouchPhaseMoved && phase != UITouchPhaseEnded && phase != UITouchPhaseCancelled) continue;
        NSString *exclusion = STTouchExclusion(touch);
        if (exclusion) { [self countOmitted:exclusion]; continue; }
        if (self.detectedGameCaptureScoped && touch.view != self.detectedGameWebView &&
            ![touch.view isDescendantOfView:self.detectedGameWebView]) {
            [self countOmitted:@"outsideConfirmedGame"]; continue;
        }
        if (self.touches.count >= STMaximumTouchSamples) break;
        NSNumber *touchID = [self.touchIDs objectForKey:touch];
        BOOL missingBegin = !touchID && phase != UITouchPhaseBegan;
        if (!touchID) { touchID = @(++self.nextTouchID); [self.touchIDs setObject:touchID forKey:touch]; }
        if (phase == UITouchPhaseMoved) {
            NSTimeInterval last = [self.lastMove[touchID] doubleValue];
            if (last && now - last < STMoveInterval) { [self countOmitted:@"moveThrottled"]; continue; }
            self.lastMove[touchID] = @(now);
        }
        // Excluded overlay/input events and throttled 60 Hz move samples do
        // not rescan native windows. Revalidate before accepting any data.
        if (self.detectedGameCaptureScoped && !scopeValidated) {
            if (![self newGameContextIsCurrent]) return accepted;
            scopeValidated = YES;
        }
        if (phase == UITouchPhaseBegan && !sampledBefore && now - self.lastEventSnapshotAt >= 0.3 &&
            self.eventSnapshotCount < STMaximumEventSnapshots) {
            NSNumber *captured = [self captureSnapshot:@"beforeTouch"];
            if (captured) { beforeID = captured; self.eventSnapshotCount++; self.lastEventSnapshotAt = now; }
            sampledBefore = YES;
        }
        if (!self.isRecording) break;
        UIWindow *window = touch.window;
        CGPoint point = [touch locationInView:window];
        CGRect bounds = window.bounds;
        NSMutableDictionary *entry = [@{@"sequence": @(self.touches.count + 1), @"touchID": touchID,
            @"phase": STTouchPhase(phase), @"missingBegin": @(missingBegin),
            @"elapsedMs": @(STFinite((now - self.startedAt) * 1000)),
            @"touchTimestampElapsedMs": @(STFinite((touch.timestamp - self.startedAt) * 1000)),
            @"pointInWindow": STPoint(point), @"windowBoundsPoints": STRect(bounds),
            @"normalized": STPoint(CGPointMake(bounds.size.width > 0 ? (point.x - bounds.origin.x) / bounds.size.width : 0,
                                               bounds.size.height > 0 ? (point.y - bounds.origin.y) / bounds.size.height : 0)),
            @"orientation": @(window.windowScene.interfaceOrientation),
            @"viewClass": STClassName(touch.view), @"windowClass": STClassName(window),
            @"beforeSnapshotID": beforeID ?: NSNull.null} mutableCopy];
        if (![self reservePayloadObject:entry]) break;
        [self.touches addObject:entry]; [accepted addObject:entry];
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            [self.touchIDs removeObjectForKey:touch]; [self.lastMove removeObjectForKey:touchID];
        }
    }
    return accepted;
}

- (void)afterEvent:(NSArray<NSMutableDictionary *> *)entries generation:(NSUInteger)generation {
    if (!self.isRecording || self.generation != generation) return;
    if (self.touches.count >= STMaximumTouchSamples) { [self stopRecordingWithReason:@"touchLimit"]; return; }
    BOOL ended = NO;
    for (NSDictionary *entry in entries)
        if ([entry[@"phase"] isEqualToString:@"ended"] || [entry[@"phase"] isEqualToString:@"cancelled"]) { ended = YES; break; }
    if (!ended || self.afterSnapshotPending || self.eventSnapshotCount >= STMaximumEventSnapshots) return;
    self.afterSnapshotPending = YES;
    // UIKit objects are not captured by the block. The copy contains only JSON primitives.
    NSArray *eventEntries = [entries copy];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!self.isRecording || self.generation != generation) return;
        self.afterSnapshotPending = NO;
        if (self.eventSnapshotCount >= STMaximumEventSnapshots) return;
        NSNumber *afterID = [self captureSnapshot:@"afterTouch"];
        if (!afterID) return;
        self.eventSnapshotCount++;
        self.lastEventSnapshotAt = STNow();
        for (NSMutableDictionary *entry in eventEntries) entry[@"afterSnapshotID"] = afterID;
    });
}

- (void)markEvent:(NSString *)name details:(NSDictionary<NSString *,id> *)details {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self markEvent:name details:details]; }); return;
    }
    if (!self.isRecording) return;
    NSSet *names = [NSSet setWithArray:@[@"crazyAlpacaEntered", @"matchStarted", @"matchEnded", @"elementsObserved",
        @"visualRecordingStarted", @"visualRecordingStopped", @"visualRecordingFailed", @"returnTraceStarted", @"returnActionRequested"]];
    if (![names containsObject:name]) { [self countOmitted:@"unknownMarker"]; return; }
    if (self.markers.count >= STMaximumMarkers) { [self countOmitted:@"markerLimit"]; return; }
    NSMutableDictionary *safeDetails = [NSMutableDictionary dictionary];
    id source = details[@"source"];
    if ([source isKindOfClass:NSString.class] && [@[@"user", @"overlay", @"replaykit"] containsObject:source]) safeDetails[@"source"] = source;
    id enabled = details[@"enabled"];
    if ([enabled isKindOfClass:NSNumber.class]) safeDetails[@"enabled"] = @([enabled boolValue]);
    id duration = details[@"durationSeconds"];
    if ([duration isKindOfClass:NSNumber.class] && isfinite([duration doubleValue])) safeDetails[@"durationSeconds"] = @(MAX(0, MIN([duration doubleValue], 3600)));
    NSTimeInterval elapsed = STNow() - self.startedAt;
    NSNumber *snapshotID = [self captureSnapshot:@"userMarker"];
    if (!self.isRecording) return;
    NSDictionary *marker = @{@"name": name, @"elapsedMs": @(STFinite(elapsed * 1000)), @"details": safeDetails,
                             @"snapshotID": snapshotID ?: NSNull.null,
                             @"semanticConfirmation": @"userMarkerNotAutomaticDetection"};
    if (![self reservePayloadObject:marker]) return;
    [self.markers addObject:marker];
    [self notifyChange];
}

- (void)markVisualRecordingEndForSessionIdentifier:(NSString *)identifier failed:(BOOL)failed durationSeconds:(NSTimeInterval)durationSeconds {
    if (!NSThread.isMainThread) {
        NSString *copiedID = [identifier copy];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self markVisualRecordingEndForSessionIdentifier:copiedID failed:failed durationSeconds:durationSeconds];
        });
        return;
    }
    if (!self.startedAt || !identifier.length || ![identifier isEqualToString:self.sessionID]) return;
    NSTimeInterval elapsed = STNow() - self.startedAt;
    if (!isfinite(elapsed) || elapsed < 0 || elapsed > 3600) return;
    for (NSDictionary *marker in self.markers)
        if ([marker[@"name"] isEqualToString:@"visualRecordingStopped"] || [marker[@"name"] isEqualToString:@"visualRecordingFailed"]) return;
    // One reserved terminal video marker remains possible when ordinary markers hit their cap.
    if (self.markers.count > STMaximumMarkers) return;
    NSTimeInterval boundedDuration = isfinite(durationSeconds) ? MAX(0, MIN(durationSeconds, 3600)) : 0;
    NSDictionary *marker = @{@"name": failed ? @"visualRecordingFailed" : @"visualRecordingStopped",
        @"elapsedMs": @(elapsed * 1000), @"afterJSONCaptureStop": @(!self.isRecording),
        @"details": @{@"source": @"replaykit", @"durationSeconds": @(boundedDuration)},
        @"snapshotID": NSNull.null, @"semanticConfirmation": @"replaykitLifecycleCallback"};
    // The metadata reserve also covers one terminal ReplayKit callback after a
    // payload-limit stop; it must remain exportable without restarting collection.
    if (self.isRecording) (void)[self reservePayloadObject:marker];
    [self.markers addObject:marker];
    [self notifyChange];
}

- (NSDictionary *)reportObject {
    if (!NSThread.isMainThread) return @{@"error": @"mainThreadRequired"};
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    NSMutableDictionary *app = [NSMutableDictionary dictionary];
    for (NSString *key in @[@"CFBundleIdentifier", @"CFBundleShortVersionString", @"CFBundleVersion"]) {
        id value = info[key];
        if ([value isKindOfClass:NSString.class]) app[key] = [value substringToIndex:MIN([value length], (NSUInteger)160)];
    }
    NSTimeInterval duration = self.startedAt > 0 ? (self.isRecording ? STNow() : self.stoppedAt) - self.startedAt : 0;
    NSDictionary *report = @{
        @"format": @"SDKtools.Capture", @"schemaVersion": @3, @"toolVersion": @"3.19.6",
        @"moduleAvailability": @{@"alpaca": @YES, @"cards": (ST_CARD_GAME_FEATURE_ENABLED ? @YES : @NO),
            @"cardsStatus": ST_CARD_GAME_FEATURE_ENABLED ? @"available" : @"paused_by_owner", @"billiardsIdentified": @NO,
            @"billiardsResourceExportAvailable": @YES, @"billiardsPredictionAvailable": @NO},
        @"billiardsResourceExport": @{@"diagnostic": self.billiardsResourceExportDiagnostic,
            @"explicitRequestOnly": @YES, @"cachedResourcesOnly": @YES, @"currentMatchIdentified": @NO,
            @"nativeGameType": NSNull.null, @"sceneType": NSNull.null,
            @"nativeContextCheckScope": @"window_and_controller_identity_not_unity_scene",
            @"runtimeInvocation": @NO, @"ballPositionsRead": @NO},
        @"cardEarly": [STCardEarlyCapture.shared snapshotReport],
        @"cardFlow": @{@"available": (ST_CARD_GAME_FEATURE_ENABLED ? @YES : @NO), @"requested": @(self.cardFlowRequested), @"active": @(self.cardFlowRequested && self.isRecording),
            @"expectedGameType": @2007, @"temporaryMethodObservers": @YES, @"automaticInput": @NO,
            @"rawNetworkPayloads": @NO, @"playerIdentifiers": @NO, @"promiseReactionAdded": @YES,
            @"observerSchemaVersion": @3, @"decodedBoundary": @"original_gameplay_response_resolver",
            @"resultPaths": @[@"rank_infos[].cards", @"game_over_info.rank_infos[].cards"],
            @"maximumPendingResolvers": @32, @"maximumResultFieldRecords": @19, @"maximumPayloadFieldRecords": @16,
            @"additionalCardPaths": @[@"punish.cards", @"punish_list[].cards"],
            @"observedCommands": @[@"CMD_SYNC", @"CMD_ENTER_GAME", @"CMD_PLAY_CARD", @"CMD_SELECT_COLOR", @"CMD_DOUBT", @"CMD_CHOOSE_GAMER", @"CMD_END_LOOK_OVER", @"CMD_GIVE_CARD", @"CMD_UNO", @"CMD_CATCH", @"CMD_CANCEL_AUTO"],
            @"colorStates": @[@"known", @"special", @"unknown", @"candidate", @"unavailable"],
            @"colorCountsAreRepeatedObservations": @YES, @"colorCaptureChangesVisualHints": @NO,
            @"decoderFallback": @"socket_sync_result_and_push_input",
            @"maximumSeconds": @90, @"maximumEvents": @4096, @"targetDrainIntervalMs": @500,
            @"leaseMilliseconds": @1800, @"maximumSampleJSONBytes": @65536,
            @"undrainedTailMayBeLostAtStop": @YES, @"slotsAreStoreArrayIndices": @YES,
            @"identityScope": @"document_local_fo_and_fn_ids_not_visual_probe_ids",
            @"roundMeaning": @"observed_start_time_changes_not_verified_server_rounds",
            @"hiddenIdentitiesProven": @NO, @"samples": self.cardFlowSamples},
        @"cardInvestigation": @{@"available": (ST_CARD_GAME_FEATURE_ENABLED ? @YES : @NO), @"requested": @(self.cardInvestigationRequested), @"active": @(self.cardInvestigationActive),
            @"expectedGameType": @2007, @"observedGameType": self.cardInvestigationRequested ? @2007 : NSNull.null,
            @"readOnly": @YES, @"automaticInput": @NO, @"networkCapture": @NO,
            @"maximumSeconds": @90, @"maximumSamples": @200, @"targetIntervalMs": @500,
            @"gate": self.cardInvestigationGate ?: @"not_requested", @"samples": self.cardInvestigationSamples,
            @"identityScope": @"probe_local_ids_independent_of_scene_codec", @"hiddenIdentitiesProven": @NO},
        @"cardHints": @{@"available": (ST_CARD_GAME_FEATURE_ENABLED ? @YES : @NO), @"enabled": @(self.cardHintsEnabled), @"physicalPending": @(self.cardHintsBusy),
            @"gameType": @2007, @"targetIntervalMs": @150, @"leaseMilliseconds": @600,
            @"readOnly": @YES, @"automaticInput": @NO, @"nativeRootCommand": @"injectCardColorsAndReadRoot",
            @"rootBinding": @"current_store_object_or_scoped_selected_protocol",
            @"handCounting": @"current_store_membership_not_scene_or_history", @"handCountScope": @"all_current_hands_excludes_discard_and_selected_outside_hand", @"originalGameObjectsWritten": @NO,
            @"selectedKnowledge": @{@"source":@"select_give_card",@"maximumAgeMilliseconds":@120000,
                @"scope":@"document_scene_store_socket_round_owner",@"maximumRetained":@256,
                @"allHiddenCardsRevealed":@NO,@"originalCardFieldsChanged":@NO},
            @"diagnostic": self.cardHintsDiagnostic,
            @"eventsScope": @"last_48_changes_in_this_process", @"events": self.cardHintsEvents},
        @"newGameCapture": @{@"state": self.detectedGameState ?: @"idle", @"identity": self.detectedGameIdentity ?: @{},
            @"scopedToConfirmedGame": @(self.detectedGameCaptureScoped), @"detectionDeadlineSeconds": @120,
            @"detectionGate": self.detectedGameLastGate ?: @"not_requested",
            @"lobbyAndChatCaptured": @NO, @"automaticTitleRecognition": @NO},
        @"sessionID": self.sessionID, @"startedAtUTC": self.startedDate,
        @"clock": @"monotonicSystemUptimeRelativeMilliseconds", @"coordinateUnit": @"UIKitWindowPoints",
        @"recording": @(self.isRecording), @"durationSeconds": @(STFinite(MAX(0, duration))), @"stopReason": self.stopReason,
        @"application": app, @"osVersion": UIDevice.currentDevice.systemVersion,
        @"returnTrace": @{@"mode": @"non_board_ui_control_identification",
            @"requested": @(self.returnTraceRequested), @"active": @(self.returnTraceActive),
            @"startedElapsedMs": self.returnTraceRequested ? @(self.returnTraceStartedElapsedMs) : NSNull.null,
            @"acceptedRequestedSamplesDuringCapture": @(self.returnTraceRequestedSamples),
            @"acceptedMetadataSamplesDuringCapture": @(self.returnTraceMetadataSamples),
            @"acceptedPartialMetadataSamplesDuringCapture": @(self.returnTracePartialSamples),
            @"countingScope": @"accepted_samples_before_export_tail_pruning",
            @"legacyFieldName": @YES, @"originalFullReturnHandlerVerified": @NO,
            @"observedOriginalEvent": @"onUseProp", @"popupOpenActionImplemented": @YES,
            @"targetedReturnInspectionImplemented": @YES,
            @"targetedReturnInspectionScope": @"central_power_and_UsePropAlert_local_methods_numeric_badges_and_relevant_scalar_fields",
            @"returnLimitLocationEstablished": @NO,
            @"automaticReturnConfirmationImplemented": @NO,
            @"unlimitedUseImplemented": @NO, @"stockChangedBySDKtools": @NO},
        @"sourceExport": @{@"status": self.sourceExportStatus, @"busy": @(self.sourceExportBusy),
            @"attempted": @(self.sourceExportAttempted), @"lastErrorCode": @(self.sourceExportErrorCode),
            @"nativePathStatus": self.sourceExportNativePathStatus, @"lastPathDiagnostic": self.sourceExportPathDiagnostic,
            @"explicitRequestOnly": @YES, @"staticOnDiskJSOnly": @YES},
        @"returnAction": @{@"scope": @"explicit_original_controls", @"explicitTapRequired": @YES,
            @"worksWithoutRecording": @YES, @"physicalPending": @(self.returnActionBusy),
            @"status": self.returnActionStatus, @"popupOpenActionImplemented": @YES,
            @"manualMenuConfirmationImplemented": @YES, @"supportedSlots": @[@"left", @"center", @"right"],
            @"ownWarehouseOpenImplemented": @YES, @"warehouseRequiresEmptyUnlockedOwnSlot": @YES,
            @"automaticReturnConfirmationImplemented": @NO, @"unlimitedUseImplemented": @NO,
            @"stockChangedBySDKtools": @NO, @"boardEffectConfirmed": @NO, @"automaticRetries": @NO,
            @"eventsScope": @"last_24_action_updates_in_this_process", @"events": self.returnActionEvents},
        @"autoplay": @{@"implemented": @YES, @"enabled": @(self.autoplayEnabled),
            @"physicalPending": @(self.autoplayBusy), @"status": self.autoplayStatus, @"reason": self.autoplayReason,
            @"cardsRead": @(self.autoplayCardsRead), @"cardTypesRead": @(self.autoplayCardTypesRead), @"confirmedMoves": @(self.autoplayConfirmedMoves),
            @"nativeGate": STLastActionGateDiagnostics ?: @{}, @"temporaryNativeBlocksRetry": @YES,
            @"eventsClock": @"processElapsedMs_since_recorder_initialization",
            @"countingScope": @"confirmed_moves_observed_by_runtime_in_this_process",
            @"worksWithoutRecording": @YES, @"targetIntervalMs": @100, @"manualTouchPauses": @YES,
            @"plannedTripleRequired": @YES, @"completeObservedPlanRequired": @NO,
            @"planningGoal": @"next_verified_trio_with_bounded_lookahead",
            @"planning": self.autoplayPlanningDiagnostic,
            @"reading": self.autoplayReadingDiagnostic,
            @"xrayEnabled": @(self.xrayEnabled), @"xrayDepth": @(self.xrayDepth), @"xray": self.xrayDiagnostic,
            @"uncertainBoardResultsRemainObserved": @YES,
            @"backgroundPauses": @YES, @"explicitResumeRequired": @YES, @"maximumActionsPerEvaluation": @1,
            @"uncertainActionsNeverRetried": @YES, @"perfectPlayGuaranteed": @NO, @"deviceValidated": @NO,
            @"eventsScope": @"last_96_status_action_and_xray_updates_in_this_process", @"events": self.autoplayEvents},
        @"limits": @{@"durationSeconds": self.cardInvestigationRequested ? @90 : @(STMaximumDuration), @"touchSamples": @(STMaximumTouchSamples),
            @"moveIntervalMilliseconds": @100, @"snapshots": @(STMaximumSnapshots), @"eventSnapshots": @(STMaximumEventSnapshots),
            @"viewsPerSnapshot": @(STMaximumViews), @"viewDepth": @(STMaximumViewDepth), @"markers": @(STMaximumMarkers),
            @"terminalVideoMarkerReserve": @1, @"webSamples": self.cardInvestigationRequested ? @200 : @(STMaximumWebSamples),
            @"webTargetIntervalMs": self.cardInvestigationRequested ? @500 : @250,
            @"maximumCompactJSONBytes": @(STMaximumPayloadBytes), @"metadataReserveBytes": @(STMetadataReserveBytes),
            @"maximumSingleWebSampleBytes": @(STMaximumWebSampleBytes)},
        @"captureStatistics": @{@"acceptedItemCompactBytes": @(self.payloadBytes), @"compactMetadataNotIncludedInItemBytes": @YES,
            @"acceptedWebSamples": @(self.webSamples.count), @"fullWebSamplesAcceptedDuringCapture": @(self.fullWebSamples),
            @"deltaWebSamplesAcceptedDuringCapture": @(self.deltaWebSamples),
            @"referenceWebSamplesAcceptedDuringCapture": @(self.deduplicatedWebSamples),
            @"deduplicatedWebSamplesAcceptedDuringCapture": @(self.deduplicatedWebSamples), @"truncatedWebSamplesAcceptedDuringCapture": @(self.truncatedWebSamples),
            @"sceneCompression": @{@"fullEncodingBytesBaseline": @(self.sceneFullPayloadBytes),
                @"acceptedEncodingBytes": @(self.sceneEncodedPayloadBytes),
                @"serializedSceneBytesSaved": @((long long)self.sceneFullPayloadBytes - (long long)self.sceneEncodedPayloadBytes),
                @"byteAccounting": @"sceneEncodingFieldsOnlyDuringCaptureBeforeTailPruning",
                @"keyframeSequenceInterval": @(STSceneCodecKeyframeInterval),
                @"maximumAllowedDependencyDepth": @(STSceneCodecMaximumDependencyDepth),
                @"maximumObservedDependencyDepth": @(self.sceneMaximumDependencyDepth)},
            @"exportDroppedTailWebSamples": @(self.exportDroppedWebSamples),
            @"observedWebResponseHz": @(self.lastWebElapsedMs > self.firstWebElapsedMs && self.webSamples.count > 1 ?
                (self.webSamples.count - 1) * 1000.0 / (self.lastWebElapsedMs - self.firstWebElapsedMs) : 0),
            @"webProbe": [self.webProbe diagnosticsSnapshot]},
        @"observability": @{@"crazyAlpacaIdentity": @"notAutomaticallyVerified", @"sheepCorrespondence": @"requiresVisualEvidence",
            @"completeInternalGameStateCaptured": @NO, @"cardsCaptured": @NO,
            @"targetedLocalInspection": @"present_only_in_control_returnInspection_when_requested_and_identified",
            @"hiddenCardContentDetermined": @NO, @"occlusionUnknown": @YES,
            @"visualEvidence": @"notContainedInJSON", @"renderedBoardNote": @"Canvas cards are not UIKit views. Optional Cocos scene structure does not confirm card identities. Pair this JSON with a user-approved screen video.",
            @"periodicSnapshotSeconds": @1, @"afterTouchSnapshotDelaySeconds": @0.25,
            @"webProbeTargetSeconds": self.cardInvestigationRequested ? @0.5 : @0.25,
            @"webProbeCadenceGuaranteed": @NO, @"nativeWebViewCacheMaximumAgeSeconds": @1.5,
            @"sceneNodeIdentity": @"contextLocalObjectIdentityNotCardFaceIdentity"},
        @"privacy": @{@"inputValues": @NO, @"viewText": @NO, @"accessibilityValues": @NO, @"clipboard": @NO,
            @"credentials": @NO, @"urls": @NO, @"networkPayloads": @NO, @"decodedCardFields": @(self.cardFlowRequested || self.cardEarlyRequested), @"temporaryGameMethodObservers": @(self.cardFlowRequested || self.cardEarlyRequested), @"memoryReads": @NO, @"screenshots": @NO,
            @"numericReturnBadgeOptIn": @YES, @"boundedLocalMethodSourceOptIn": @YES,
            @"relevantReturnScalarsOptIn": @YES, @"methodSourceMayContainCodeLiterals": @YES,
            @"sdktoolsTouchesExcluded": @YES, @"textInputTouchesExcluded": @YES, @"automaticInput": @YES, @"automaticInputRequiresExplicitPlay": @YES},
        @"touches": self.touches, @"snapshots": self.snapshots, @"markers": self.markers, @"webSamples": self.webSamples, @"omitted": self.omitted,
        @"unfinishedTouchIDsAtStop": self.unfinishedTouchIDs,
        @"notes": @[@"A marker identifies what the user reported, not an automatically recognized game screen.",
                    @"A touch followed by a UI change does not prove that touch caused the change.",
                    @"sceneNodesEncoding=reference or delta points to an earlier accepted full/delta sample in the same webViewID and contextID. Resolve only sceneNodes; timing, DOM and diagnostics remain current. References never target references.",
                    @"Delta version 1 preserves exact node order through order, adds complete rows through added, and applies top-level set/unset patches through changed. Missing IDs describe sample membership only, never confirmed card removal; truncated samples remain partial.",
                    @"Node/frame/texture IDs are local to webViewID plus contextID. A reload creates a new context; IDs do not prove identical card faces or rules.",
                    @"The 250 ms web interval is a target. One physical evaluation is allowed at a time; UI load, timeouts and payload limits can reduce the observed rate.",
                    @"The legacy returnTrace field describes opt-in non-board control metadata. It does not invoke game callbacks. The central-power menu action validates the live original onUseProp event and only opens its popup. Its legacy Retornar field names do not establish which power occupies that position. The user still confirms Usar item in the original game; stock and game rules remain unchanged by SDKtools.",
                    @"V2.7 control.returnInspection may include numeric badges, relevant primitive fields and bounded local function source from the central power and observed UsePropAlert component. The central button is not assumed to be Retornar; captured video showed Shuffle in that position. These are partial observations, not proof of server authority, item eligibility or an unlimited-use patch. Function code may contain literals; no credential store, page URL or network payload is read.",
                    @"Return action timeout is not cancellation. Its physical lock remains held until the actual WebKit callback. No command is automatically retried and popup dispatch never proves a board effect.",
                    @"Autoplay uses a separate live scene adapter and bounded planner after explicit Play. It reads loaded cards only, invokes at most one original registered card event per evaluation and waits for a board effect. Background, manual input and capture start pause it; one already-submitted action may still finish. Complete hidden state and perfect play are not established."]
    };
    return report;
}

- (NSDictionary<NSString *,id> *)snapshotReport {
    if (!NSThread.isMainThread) return @{@"error": @"mainThreadRequired"};
    // Detach mutable internal collections so callers cannot corrupt the recording state.
    NSData *data = [NSJSONSerialization dataWithJSONObject:[self reportObject] options:NSJSONWritingSortedKeys error:nil];
    return data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : @{@"error": @"reportSerializationFailed"};
}

- (NSData *)compactReportDataWithError:(NSError **)error {
    NSData *data = [NSJSONSerialization dataWithJSONObject:[self reportObject] options:NSJSONWritingSortedKeys error:error];
    // The incremental budget reserves 256 KiB for metadata and small late fields.
    // This exact final check is a second boundary. Removing only the tail keeps
    // every retained sceneNodesRefSequence pointing to an earlier retained item.
    while (data && data.length > STMaximumPayloadBytes && self.webSamples.count) {
        NSDictionary *last = self.webSamples.lastObject;
        NSData *lastData = [NSJSONSerialization dataWithJSONObject:last options:NSJSONWritingSortedKeys error:nil];
        NSUInteger size = lastData.length + 1;
        NSNumber *removedSequence = last[@"sequence"];
        if (removedSequence) {
            for (NSUInteger index = self.cardFlowSamples.count; index > 0; index--) {
                NSDictionary *observation = self.cardFlowSamples[index - 1];
                if (![observation[@"sequence"] isEqual:removedSequence]) continue;
                size += [NSJSONSerialization dataWithJSONObject:observation options:NSJSONWritingSortedKeys error:nil].length + 1;
                [self.cardFlowSamples removeObjectAtIndex:index - 1];
            }
            for (NSUInteger index = self.cardInvestigationSamples.count; index > 0; index--) {
                NSDictionary *observation = self.cardInvestigationSamples[index - 1];
                if (![observation[@"sequence"] isEqual:removedSequence]) continue;
                size += [NSJSONSerialization dataWithJSONObject:observation options:NSJSONWritingSortedKeys error:nil].length + 1;
                [self.cardInvestigationSamples removeObjectAtIndex:index - 1];
            }
        }
        self.payloadBytes = self.payloadBytes > size ? self.payloadBytes - size : 0;
        [self.webSamples removeLastObject];
        self.exportDroppedWebSamples++;
        self.stopReason = @"payloadLimit";
        data = [NSJSONSerialization dataWithJSONObject:[self reportObject] options:NSJSONWritingSortedKeys error:error];
    }
    if (data.length > STMaximumPayloadBytes) {
        if (error) *error = [NSError errorWithDomain:@"SDKtools.Recorder" code:3 userInfo:@{NSLocalizedDescriptionKey: @"O relatório ultrapassou o limite de 32 MiB."}];
        return nil;
    }
    return data;
}

- (void)exportCurrentGameSourcesWithCompletion:(void (^)(NSURL *, NSError *))completion {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self exportCurrentGameSourcesWithCompletion:completion]; }); return;
    }
    if (self.cardEarlyActive || self.detectedGameDetectionActive || self.detectedGameCaptureActive || self.sourceExportBusy || self.returnActionBusy || self.autoplayBusy) {
        completion(nil, [NSError errorWithDomain:@"SDKtools.GameSources" code:20 userInfo:@{NSLocalizedDescriptionKey:@"Aguarde a ação ou exportação em andamento terminar."}]); return;
    }
    [self setCardHintsEnabled:NO];
    self.sourceExportAttempted = YES;
    self.sourceExportErrorCode = 0;
    self.sourceExportPathDiagnostic = @{};
    self.sourceExportNativePathStatus = @"not_requested";
    [self pauseAutoplayWithReason:@"source_export"];
    [self setXrayEnabled:NO];
    if (self.isRecording) [self stopRecordingWithReason:@"export"];
    NSString *reason = nil; WKWebView *webView = nil;
    NSNumber *observedGameType = nil; UIViewController *observedController = nil;
    @try { webView = STFindCaptureGame(&observedGameType, &observedController, &reason); }
    @catch (__unused NSException *exception) { webView = nil; }
    if (!webView || !webView.URL.isFileURL || ![@[@60, @2007] containsObject:observedGameType]) {
        self.sourceExportErrorCode = 21;
        self.sourceExportStatus = @"error"; [self notifyChange];
        completion(nil, [NSError errorWithDomain:@"SDKtools.GameSources" code:21 userInfo:@{NSLocalizedDescriptionKey:@"Abra Crazy Alpaca ou Ah, minha carta com o pacote local carregado e feche as janelas do jogo."}]); return;
    }
    NSURL *entryURL = [webView.URL copy];
    NSURL *caches = [NSFileManager.defaultManager URLForDirectory:NSCachesDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
    NSURL *documents = [NSFileManager.defaultManager URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:nil];
    if (!caches || !documents) {
        self.sourceExportErrorCode = 22;
        self.sourceExportStatus = @"error"; [self notifyChange];
        completion(nil, [NSError errorWithDomain:@"SDKtools.GameSources" code:22 userInfo:@{NSLocalizedDescriptionKey:@"As pastas locais necessárias não estão disponíveis."}]); return;
    }
    // App/controller/type are observed. Only game60 has an evidenced native
    // resource getter; game2007 uses the exact file URL and package policy only.
    NSString *nativePathStatus = nil;
    NSURL *nativeResourceURL = STGameSourceNativeResourceURLForGame(observedGameType.longLongValue, &nativePathStatus);
    self.sourceExportNativePathStatus = nativePathStatus;
    self.sourceExportBusy = YES; self.sourceExportStatus = @"collecting"; [self notifyChange];
    __weak WKWebView *weakWebView = webView; __weak UIWindow *weakWindow = webView.window;
    __weak UIViewController *weakController = observedController;
    NSUInteger contextGeneration = self.actionContextGeneration;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSError *error = nil;
        NSURL *URL = [STGameSourceExporter writeSourcesFromCachesURL:caches documentsURL:documents entryURL:entryURL
            observedGameType:observedGameType.integerValue
            verifiedNativeResourceURL:nativeResourceURL
            destinationDirectory:[documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES] error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            BOOL valid = NO; NSString *currentReason = nil;
            @try {
                NSNumber *currentType = nil; UIViewController *currentController = nil;
                WKWebView *currentView = STFindCaptureGame(&currentType, &currentController, &currentReason);
                valid = self.actionContextGeneration == contextGeneration && weakWebView && weakWindow &&
                    weakWebView.window == weakWindow && [weakWebView.URL isEqual:entryURL] &&
                    currentView == weakWebView && weakController && currentController == weakController &&
                    [currentType isEqual:observedGameType];
            } @catch (__unused NSException *exception) { valid = NO; }
            NSURL *delivered = URL; NSError *deliveredError = error;
            if (URL && !valid) {
                [NSFileManager.defaultManager removeItemAtURL:URL error:nil]; delivered = nil;
                deliveredError = [NSError errorWithDomain:@"SDKtools.GameSources" code:23 userInfo:@{NSLocalizedDescriptionKey:@"A tela do jogo mudou durante a coleta. O arquivo foi descartado; repita com a partida aberta."}];
            }
            self.sourceExportBusy = NO; self.sourceExportStatus = delivered ? @"exported" : @"error";
            self.sourceExportErrorCode = [deliveredError.domain isEqual:@"SDKtools.GameSources"] ? deliveredError.code : 0;
            // Only the exporter's own bounded structural dictionary is retained.
            // Never copy a URL, file-system path or arbitrary NSError text here.
            id pathDiagnostic = deliveredError.userInfo[STGameSourcePathDiagnosticKey];
            self.sourceExportPathDiagnostic = [pathDiagnostic isKindOfClass:NSDictionary.class] ? pathDiagnostic : @{};
            [self notifyChange]; completion(delivered, deliveredError);
        });
    });
}

- (void)exportBilliardsResourcesWithCompletion:(void (^)(NSURL *, NSError *))completion {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self exportBilliardsResourcesWithCompletion:completion]; }); return;
    }
    if (self.sourceExportBusy || self.returnActionBusy || self.autoplayBusy || self.cardHintsBusy ||
        self.cardEarlyActive || self.detectedGameDetectionActive) {
        completion(nil, [NSError errorWithDomain:@"SDKtools.BilliardsResources" code:20
            userInfo:@{NSLocalizedDescriptionKey: @"Aguarde a ação ou exportação em andamento terminar."}]); return;
    }
    self.billiardsResourceExportDiagnostic = @{@"attempted": @YES, @"status": @"validating", @"errorCode": @0, @"counts": @{}};
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    BOOL supported = [info[@"CFBundleIdentifier"] isEqual:@"com.wejoy.weplay.us"] &&
        [info[@"CFBundleShortVersionString"] isEqual:@"6.6.2"] && [info[@"CFBundleVersion"] isEqual:@"132"];
    if (!supported || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
        NSInteger code = supported ? 21 : 22;
        self.billiardsResourceExportDiagnostic = @{@"attempted": @YES, @"status": supported ? @"inactive_application" : @"unsupported_application",
            @"errorCode": @(code), @"counts": @{}};
        [self notifyChange];
        completion(nil, [NSError errorWithDomain:@"SDKtools.BilliardsResources" code:code userInfo:@{NSLocalizedDescriptionKey:
            supported ? @"Mantenha o WePlay aberto para exportar os recursos." : @"Esta exportação requer WePlay US 6.6.2, build 132."}]); return;
    }
    [self pauseAutoplayWithReason:@"source_export"];
    [self setXrayEnabled:NO];
    [self setCardHintsEnabled:NO];
    if (self.isRecording) [self stopRecordingWithReason:@"export"];
    NSSet *initialContext = STBilliardsExportNativeContext();
    if (!initialContext) {
        self.billiardsResourceExportDiagnostic = @{@"attempted": @YES, @"status": @"native_context_unavailable", @"errorCode": @23, @"counts": @{}};
        [self notifyChange];
        completion(nil, [NSError errorWithDomain:@"SDKtools.BilliardsResources" code:23
            userInfo:@{NSLocalizedDescriptionKey: @"Aguarde a tela terminar de abrir e feche as janelas antes de exportar."}]); return;
    }
    NSURL *documents = [NSFileManager.defaultManager URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:nil];
    NSURL *library = [NSFileManager.defaultManager URLForDirectory:NSLibraryDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
    if (!documents.isFileURL || !library.isFileURL) {
        self.billiardsResourceExportDiagnostic = @{@"attempted": @YES, @"status": @"directories_unavailable", @"errorCode": @24, @"counts": @{}};
        [self notifyChange];
        completion(nil, [NSError errorWithDomain:@"SDKtools.BilliardsResources" code:24
            userInfo:@{NSLocalizedDescriptionKey: @"As pastas locais necessárias não estão disponíveis."}]); return;
    }
    self.sourceExportBusy = YES;
    self.billiardsResourceExportDiagnostic = @{@"attempted": @YES, @"status": @"collecting", @"errorCode": @0, @"counts": @{}};
    [self notifyChange];
    NSUInteger contextGeneration = self.actionContextGeneration;
    // Sample native transitions while work is in flight and check once more at
    // completion. Unity scene changes within one controller are not observable here.
    __block BOOL contextInvalidated = NO;
    __weak STRecorder *weakSelf = self;
    NSTimer *contextTimer = [NSTimer timerWithTimeInterval:0.25 repeats:YES block:^(NSTimer *timer) {
        STRecorder *recorder = weakSelf;
        NSSet *current = STBilliardsExportNativeContext();
        if (!recorder || recorder.actionContextGeneration != contextGeneration || !current || ![current isEqualToSet:initialContext]) {
            contextInvalidated = YES;
            [timer invalidate];
        }
    }];
    [NSRunLoop.mainRunLoop addTimer:contextTimer forMode:NSRunLoopCommonModes];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSError *error = nil;
        NSDictionary *diagnostic = nil;
        NSURL *URL = [STBilliardsResourceExporter writePackageFromDocumentsURL:documents libraryURL:library
            destinationDirectory:[documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES]
            diagnostic:&diagnostic error:&error];
        NSDictionary *counts = STBilliardsExportBoundedCounts(diagnostic);
        id reportedStatus = [diagnostic isKindOfClass:NSDictionary.class] ? diagnostic[@"status"] : nil;
        NSString *exportStatus = [reportedStatus isKindOfClass:NSString.class] && [@[@"exported", @"partial", @"resources_missing"] containsObject:reportedStatus] ? reportedStatus : @"exported";
        dispatch_async(dispatch_get_main_queue(), ^{
            [contextTimer invalidate];
            NSSet *current = STBilliardsExportNativeContext();
            BOOL valid = !contextInvalidated && self.actionContextGeneration == contextGeneration &&
                current && [current isEqualToSet:initialContext];
            NSURL *delivered = URL;
            NSError *deliveredError = error;
            NSString *status = URL && !error ? exportStatus : @"error";
            if (!valid) {
                if (URL.isFileURL) [NSFileManager.defaultManager removeItemAtURL:URL error:nil];
                delivered = nil;
                status = @"cancelled_context_changed";
                deliveredError = [NSError errorWithDomain:@"SDKtools.BilliardsResources" code:25
                    userInfo:@{NSLocalizedDescriptionKey: @"A tela mudou ou o app saiu do primeiro plano. O arquivo foi descartado; exporte novamente com o bilhar aberto."}];
            } else if (error || !URL.isFileURL) {
                if (URL.isFileURL) [NSFileManager.defaultManager removeItemAtURL:URL error:nil];
                delivered = nil;
                status = @"error";
                if (!error) deliveredError = [NSError errorWithDomain:@"SDKtools.BilliardsResources" code:26
                    userInfo:@{NSLocalizedDescriptionKey: @"Não foi possível gerar o arquivo de recursos."}];
            }
            self.sourceExportBusy = NO;
            NSInteger errorCode = deliveredError ? MAX((NSInteger)-1000000000, MIN(deliveredError.code, (NSInteger)1000000000)) : 0;
            self.billiardsResourceExportDiagnostic = @{@"attempted": @YES, @"status": status, @"errorCode": @(errorCode), @"counts": counts};
            [self notifyChange];
            completion(delivered, deliveredError);
        });
    });
}

- (NSURL *)writeReportWithError:(NSError **)error {
    if (!NSThread.isMainThread || (!self.startedAt && !self.returnActionEvents.count && !self.autoplayEvents.count && !self.cardHintsEvents.count && !self.sourceExportAttempted && !self.cardEarlyRequested && ![self.billiardsResourceExportDiagnostic[@"attempted"] boolValue])) {
        if (error) *error = [NSError errorWithDomain:@"SDKtools.Recorder" code:1 userInfo:@{NSLocalizedDescriptionKey: @"Inicie uma captura ou use uma ferramenta antes de exportar, na thread principal."}];
        return nil;
    }
    [self pauseAutoplayWithReason:@"export"];
    [STCardEarlyCapture.shared stopWithReason:@"export"];
    if (self.isRecording) [self stopRecordingWithReason:@"export"];
    NSData *data = [self compactReportDataWithError:error];
    if (!data) return nil;
    NSURL *documents = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:error];
    if (!documents) return nil;
    NSURL *folder = [documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES];
    if (![[NSFileManager defaultManager] createDirectoryAtURL:folder withIntermediateDirectories:YES
        attributes:@{NSFileProtectionKey: NSFileProtectionComplete} error:error]) return nil;
    NSString *filename = [NSString stringWithFormat:@"SDKtools-Capture-%@.json", NSUUID.UUID.UUIDString];
    NSURL *destination = [folder URLByAppendingPathComponent:filename];
    if (![data writeToURL:destination options:NSDataWritingAtomic | NSDataWritingFileProtectionComplete error:error]) return nil;
    [destination setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
    return destination;
}

@end

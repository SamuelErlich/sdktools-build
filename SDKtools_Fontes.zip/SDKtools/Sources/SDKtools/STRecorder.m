#import "STRecorder.h"
#import "STWebProbe.h"
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <math.h>
#import <string.h>

NSNotificationName const STRecorderDidChangeNotification = @"STRecorderDidChangeNotification";

static const NSTimeInterval STMaximumDuration = 180.0;
static const NSUInteger STMaximumTouchSamples = 300;
static const NSUInteger STMaximumSnapshots = 320;
static const NSUInteger STMaximumEventSnapshots = 100;
static const NSUInteger STMaximumViews = 64;
static const NSUInteger STMaximumViewDepth = 8;
static const NSUInteger STMaximumMarkers = 40;
static const NSTimeInterval STMoveInterval = 0.1;
static IMP STPreviousSendEvent;
static Class STHookedApplicationClass;

static double STFinite(double value) { return isfinite(value) ? value : 0.0; }
static NSTimeInterval STNow(void) { return NSProcessInfo.processInfo.systemUptime; }
static NSString *STClassName(id value) {
    NSString *name = value ? NSStringFromClass(object_getClass(value)) : @"none";
    return [name substringToIndex:MIN(name.length, (NSUInteger)96)];
}
static NSDictionary *STPoint(CGPoint point) { return @{@"x": @(STFinite(point.x)), @"y": @(STFinite(point.y))}; }
static NSDictionary *STRect(CGRect rect) {
    return @{@"x": @(STFinite(rect.origin.x)), @"y": @(STFinite(rect.origin.y)),
             @"width": @(STFinite(rect.size.width)), @"height": @(STFinite(rect.size.height))};
}
static BOOL STIsOwnWindow(UIWindow *window) {
    Class overlay = NSClassFromString(@"STOverlayWindow");
    if (overlay && [window isKindOfClass:overlay]) return YES;
    // Walk actual runtime classes, including subclasses. No description or view text is read.
    for (Class cls = object_getClass(window); cls; cls = class_getSuperclass(cls))
        if ([NSStringFromClass(cls) isEqualToString:@"STOverlayWindow"]) return YES;
    return NO;
}
static BOOL STIsKeyboard(id object) {
    for (Class cls = object_getClass(object); cls; cls = class_getSuperclass(cls)) {
        NSString *name = NSStringFromClass(cls);
        if ([name containsString:@"Keyboard"] || [name containsString:@"InputSet"] ||
            [name containsString:@"TextEffects"] || [name isEqualToString:@"UIInputWindow"]) return YES;
    }
    return NO;
}
static BOOL STIsTextEntry(UIView *view) {
    if ([view isKindOfClass:UITextField.class] || [view isKindOfClass:UITextView.class]) return YES;
    if ([view conformsToProtocol:@protocol(UITextInputTraits)] &&
        [view respondsToSelector:@selector(isSecureTextEntry)] && [(id<UITextInputTraits>)view isSecureTextEntry]) return YES;
    // WKContentView implements UITextInput even for a noneditable game canvas.
    // Inspect a BOOL editing flag, never the input value or an arbitrary KVC property.
    if (![view conformsToProtocol:@protocol(UITextInput)]) return NO;
    SEL selector = NSSelectorFromString(@"isEditable");
    Method method = class_getInstanceMethod(object_getClass(view), selector);
    char type[8] = {0};
    if (!method || method_getNumberOfArguments(method) != 2) return NO;
    method_getReturnType(method, type, sizeof(type));
    if (strcmp(type, "B") && strcmp(type, "c")) return NO;
    return ((BOOL (*)(id, SEL))objc_msgSend)(view, selector);
}
static BOOL STWindowUsable(UIWindow *window) {
    if (!window || window.hidden || window.alpha < 0.01 || STIsOwnWindow(window) || STIsKeyboard(window)) return NO;
    UIWindowScene *scene = window.windowScene;
    return !scene || scene.activationState == UISceneActivationStateForegroundActive;
}
static NSString *STTouchExclusion(UITouch *touch) {
    UIWindow *window = touch.window;
    if (STIsOwnWindow(window)) return @"sdktoolsOverlay";
    if (!STWindowUsable(window)) return @"inactiveHiddenOrKeyboardWindow";
    UIView *view = touch.view;
    for (NSUInteger depth = 0; view && depth < 32; depth++, view = view.superview)
        if (STIsTextEntry(view) || STIsKeyboard(view)) return @"textInput";
    return nil;
}
static NSString *STTouchPhase(UITouchPhase phase) {
    switch (phase) {
        case UITouchPhaseBegan: return @"began";
        case UITouchPhaseMoved: return @"moved";
        case UITouchPhaseEnded: return @"ended";
        case UITouchPhaseCancelled: return @"cancelled";
        default: return @"stationary";
    }
}

static NSArray<UIViewController *> *STVisibleControllers(UIWindow *window) {
    NSMutableArray *found = [NSMutableArray array];
    NSMutableArray *pending = [NSMutableArray array];
    if (window.rootViewController) [pending addObject:window.rootViewController];
    NSHashTable *seen = [NSHashTable weakObjectsHashTable];
    for (NSUInteger visit = 0; pending.count && visit < 32; visit++) {
        UIViewController *controller = pending.firstObject;
        [pending removeObjectAtIndex:0];
        if ([seen containsObject:controller]) continue;
        [seen addObject:controller];
        if (controller.isViewLoaded && controller.view.window == window && !controller.view.hidden)
            [found addObject:controller];
        if (controller.presentedViewController) [pending addObject:controller.presentedViewController];
        for (UIViewController *child in controller.childViewControllers) {
            if (pending.count >= 32) break;
            [pending addObject:child];
        }
    }
    return found;
}

static BOOL STIsCocosController(UIViewController *controller) {
    for (Class cls = object_getClass(controller); cls; cls = class_getSuperclass(cls))
        if ([NSStringFromClass(cls) isEqualToString:@"WPCocosGameViewController"]) return YES;
    return NO;
}

static WKWebView *STFindGameWebView(UIView *root) {
    NSMutableArray<NSDictionary *> *pending = [NSMutableArray arrayWithObject:@{@"view": root, @"depth": @0}];
    for (NSUInteger visited = 0; pending.count && visited < 128; visited++) {
        NSDictionary *item = pending.firstObject;
        [pending removeObjectAtIndex:0];
        UIView *view = item[@"view"];
        NSUInteger depth = [item[@"depth"] unsignedIntegerValue];
        if (!view.window || view.hidden || view.alpha < 0.01 || STIsTextEntry(view) || STIsKeyboard(view)) continue;
        if ([view isKindOfClass:WKWebView.class]) return (WKWebView *)view;
        if (depth >= 12) continue;
        for (UIView *child in view.subviews) {
            if (pending.count >= 128) break;
            [pending addObject:@{@"view": child, @"depth": @(depth + 1)}];
        }
    }
    return nil;
}

@interface STRecorder ()
@property (nonatomic, readwrite, getter=isRecording) BOOL recording;
@property (nonatomic) NSUInteger generation;
@property (nonatomic) NSUInteger nextTouchID;
@property (nonatomic) NSUInteger eventSnapshotCount;
@property (nonatomic) NSTimeInterval startedAt;
@property (nonatomic) NSTimeInterval stoppedAt;
@property (nonatomic) NSTimeInterval lastEventSnapshotAt;
@property (nonatomic, copy) NSString *startedDate;
@property (nonatomic, copy) NSString *sessionID;
@property (nonatomic, copy) NSString *stopReason;
@property (nonatomic, copy) NSString *startFailure;
@property (nonatomic, strong) NSMutableArray<NSMutableDictionary *> *touches;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *snapshots;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *markers;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *webSamples;
@property (nonatomic, strong) STWebProbe *webProbe;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *omitted;
@property (nonatomic, strong) NSMapTable<UITouch *, NSNumber *> *touchIDs;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, NSNumber *> *lastMove;
@property (nonatomic, copy) NSArray<NSNumber *> *unfinishedTouchIDs;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic) BOOL afterSnapshotPending;
- (NSArray<NSMutableDictionary *> *)beforeEvent:(UIEvent *)event;
- (void)afterEvent:(NSArray<NSMutableDictionary *> *)entries generation:(NSUInteger)generation;
- (NSNumber *)captureSnapshot:(NSString *)reason;
- (NSNumber *)buildSnapshot:(NSString *)reason;
- (void)countOmitted:(NSString *)reason;
- (void)notifyChange;
@end

// Observe dispatch without replacing, duplicating, cancelling, or manufacturing app input.
// UIKit runs sendEvent on main. Unexpected off-main calls are forwarded untouched.
static void STObservedSendEvent(UIApplication *application, SEL selector, UIEvent *event) {
    STRecorder *recorder = STRecorder.shared;
    NSArray<NSMutableDictionary *> *entries = nil;
    NSUInteger generation = 0;
    if (NSThread.isMainThread && recorder.isRecording) {
        generation = recorder.generation;
        @try { entries = [recorder beforeEvent:event]; }
        @catch (__unused NSException *exception) { [recorder countOmitted:@"observationException"]; }
    }
    // Do not catch exceptions thrown by the original application or retry the original call.
    ((void (*)(id, SEL, UIEvent *))STPreviousSendEvent)(application, selector, event);
    if (NSThread.isMainThread && entries.count) {
        @try { [recorder afterEvent:entries generation:generation]; }
        @catch (__unused NSException *exception) { [recorder countOmitted:@"observationException"]; }
    }
}

@implementation STRecorder

+ (instancetype)shared {
    static STRecorder *value;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ value = [STRecorder new]; });
    return value;
}

- (instancetype)init {
    if ((self = [super init])) {
        _touches = [NSMutableArray array];
        _snapshots = [NSMutableArray array];
        _markers = [NSMutableArray array];
        _webSamples = [NSMutableArray array];
        _webProbe = [STWebProbe new];
        _omitted = [NSMutableDictionary dictionary];
        _touchIDs = [NSMapTable weakToStrongObjectsMapTable];
        _lastMove = [NSMutableDictionary dictionary];
        _unfinishedTouchIDs = @[];
        _stopReason = @"notStarted";
        _startFailure = @"";
        _sessionID = @"";
        _startedDate = @"";
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationBackgrounded:)
            name:UIApplicationDidEnterBackgroundNotification object:nil];
    }
    return self;
}

- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; [_timer invalidate]; }

- (void)applicationBackgrounded:(NSNotification *)notification {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self stopRecordingWithReason:@"background"]; });
    } else [self stopRecordingWithReason:@"background"];
}

- (void)notifyChange {
    NSAssert(NSThread.isMainThread, @"STRecorder requires the main thread");
    [[NSNotificationCenter defaultCenter] postNotificationName:STRecorderDidChangeNotification object:self];
}

- (void)countOmitted:(NSString *)reason {
    self.omitted[reason] = @(MIN([self.omitted[reason] unsignedIntegerValue] + 1, (NSUInteger)1000000));
}

- (NSString *)statusText {
    if (!NSThread.isMainThread) return @"Consulte na thread principal";
    if ([self.startFailure isEqualToString:@"inactiveApplication"]) return @"Abra o app para iniciar a captura";
    if ([self.startFailure isEqualToString:@"eventObservationUnavailable"]) return @"Não foi possível observar os toques";
    NSTimeInterval duration = self.startedAt > 0 ? (self.isRecording ? STNow() : self.stoppedAt) - self.startedAt : 0;
    if (!self.startedAt) return @"Nenhuma captura iniciada";
    return [NSString stringWithFormat:@"%@ · %.0f s · %lu amostras",
        self.isRecording ? @"Gravando" : @"Captura pronta", MAX(0, duration), (unsigned long)self.touches.count];
}

- (NSString *)captureSessionIdentifier { return NSThread.isMainThread ? [self.sessionID copy] : @""; }

- (void)startRecording {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self startRecording]; }); return; }
    if (self.isRecording) return;
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
        self.startFailure = @"inactiveApplication";
        [self notifyChange];
        return;
    }
    if (!STHookedApplicationClass) {
        Class applicationClass = object_getClass(UIApplication.sharedApplication);
        SEL selector = @selector(sendEvent:);
        Method method = class_getInstanceMethod(applicationClass, selector);
        IMP previous = method ? method_getImplementation(method) : NULL;
        if (!previous || previous == (IMP)STObservedSendEvent) {
            self.startFailure = @"eventObservationUnavailable";
            [self notifyChange];
            return;
        }
        STPreviousSendEvent = previous;
        // Add an override when sendEvent is inherited. Never modify a superclass by accident.
        if (!class_addMethod(applicationClass, selector, (IMP)STObservedSendEvent, method_getTypeEncoding(method)))
            class_replaceMethod(applicationClass, selector, (IMP)STObservedSendEvent, method_getTypeEncoding(method));
        STHookedApplicationClass = applicationClass;
    }
    self.generation++;
    self.startFailure = @"";
    self.nextTouchID = 0;
    self.eventSnapshotCount = 0;
    self.startedAt = STNow();
    self.stoppedAt = 0;
    self.lastEventSnapshotAt = 0;
    self.afterSnapshotPending = NO;
    self.stopReason = @"recording";
    self.sessionID = NSUUID.UUID.UUIDString;
    self.startedDate = [[NSISO8601DateFormatter new] stringFromDate:NSDate.date];
    [self.touches removeAllObjects]; [self.snapshots removeAllObjects]; [self.markers removeAllObjects];
    [self.webSamples removeAllObjects]; [self.webProbe reset];
    [self.omitted removeAllObjects]; [self.touchIDs removeAllObjects]; [self.lastMove removeAllObjects];
    self.unfinishedTouchIDs = @[];
    self.recording = YES;
    [self captureSnapshot:@"recordingStarted"];
    __weak STRecorder *weakSelf = self;
    NSUInteger generation = self.generation;
    self.timer = [NSTimer timerWithTimeInterval:1.0 repeats:YES block:^(__unused NSTimer *timer) {
        STRecorder *strongSelf = weakSelf;
        if (!strongSelf.isRecording || strongSelf.generation != generation) return;
        if (STNow() - strongSelf.startedAt >= STMaximumDuration) {
            [strongSelf stopRecordingWithReason:@"durationLimit"];
        } else if (strongSelf.touches.count >= STMaximumTouchSamples) {
            [strongSelf stopRecordingWithReason:@"touchLimit"];
        } else {
            [strongSelf captureSnapshot:@"periodic"];
            [strongSelf notifyChange];
        }
    }];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    [self notifyChange];
}

- (void)stopRecordingWithReason:(NSString *)reason {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self stopRecordingWithReason:reason]; }); return;
    }
    if (!self.isRecording) return;
    self.recording = NO;
    self.stoppedAt = STNow();
    NSSet *knownReasons = [NSSet setWithArray:@[@"user", @"background", @"durationLimit", @"touchLimit", @"export", @"overlayClosed"]];
    self.stopReason = [knownReasons containsObject:reason] ? reason : @"user";
    self.generation++;
    [self.timer invalidate]; self.timer = nil;
    self.afterSnapshotPending = NO;
    [self.webProbe stop];
    self.unfinishedTouchIDs = [[self.touchIDs objectEnumerator].allObjects sortedArrayUsingSelector:@selector(compare:)];
    [self.touchIDs removeAllObjects]; [self.lastMove removeAllObjects];
    [self notifyChange];
}

- (NSNumber *)captureSnapshot:(NSString *)reason {
    @try { return [self buildSnapshot:reason]; }
    @catch (__unused NSException *exception) { [self countOmitted:@"snapshotException"]; return nil; }
}

- (NSNumber *)buildSnapshot:(NSString *)reason {
    NSAssert(NSThread.isMainThread, @"STRecorder requires the main thread");
    if (!self.isRecording) return nil;
    if (self.snapshots.count >= STMaximumSnapshots) { [self countOmitted:@"snapshotLimit"]; return nil; }
    NSMutableArray<UIWindow *> *windows = [NSMutableArray array];
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows)
            if (STWindowUsable(window)) [windows addObject:window];
    }
    if (!windows.count) {
        for (UIWindow *window in UIApplication.sharedApplication.windows)
            if (STWindowUsable(window)) [windows addObject:window];
    }
    [windows sortUsingComparator:^NSComparisonResult(UIWindow *a, UIWindow *b) {
        if (a.isKeyWindow != b.isKeyWindow) return a.isKeyWindow ? NSOrderedAscending : NSOrderedDescending;
        if (a.windowLevel > b.windowLevel) return NSOrderedAscending;
        if (a.windowLevel < b.windowLevel) return NSOrderedDescending;
        return NSOrderedSame;
    }];
    NSMutableArray *windowReports = [NSMutableArray array];
    NSMutableArray *nodes = [NSMutableArray array];
    NSMutableSet *renderers = [NSMutableSet set];
    WKWebView *gameWebView = nil;
    BOOL truncated = windows.count > 3;
    for (NSUInteger windowIndex = 0; windowIndex < MIN(windows.count, (NSUInteger)3); windowIndex++) {
        UIWindow *window = windows[windowIndex];
        NSArray<UIViewController *> *controllers = STVisibleControllers(window);
        NSMutableArray *controllerReports = [NSMutableArray array];
        NSMutableArray<UIView *> *cocosRoots = [NSMutableArray array];
        for (UIViewController *controller in controllers) {
            NSMutableDictionary *controllerReport = [@{@"class": STClassName(controller)} mutableCopy];
            if (STIsCocosController(controller)) {
                [cocosRoots addObject:controller.view];
                controllerReport[@"cocosContainerObserved"] = @YES;
                controllerReport[@"gameTypeGetterRead"] = @NO;
            }
            [controllerReports addObject:controllerReport];
        }
        // The native hierarchy export has a lower cap. Search the confirmed
        // Cocos controller subtree separately so unrelated siblings do not starve it.
        for (UIView *root in cocosRoots) {
            if (!gameWebView) gameWebView = STFindGameWebView(root);
        }
        [windowReports addObject:@{@"index": @(windowIndex), @"class": STClassName(window),
            @"boundsPoints": STRect(window.bounds), @"screenScale": @(STFinite(window.screen.scale)),
            @"orientation": @(window.windowScene.interfaceOrientation), @"isKeyWindow": @(window.isKeyWindow),
            @"safeAreaInsets": @{@"top": @(STFinite(window.safeAreaInsets.top)), @"left": @(STFinite(window.safeAreaInsets.left)),
                @"bottom": @(STFinite(window.safeAreaInsets.bottom)), @"right": @(STFinite(window.safeAreaInsets.right))},
            @"rootControllerClass": STClassName(window.rootViewController), @"visibleControllers": controllerReports}];
        NSMutableArray<NSDictionary *> *pending = [NSMutableArray arrayWithObject:@{@"view": window, @"parent": @(-1), @"depth": @0}];
        NSUInteger visited = 0;
        while (pending.count && nodes.count < STMaximumViews && visited < 256) {
            NSDictionary *item = pending.firstObject;
            [pending removeObjectAtIndex:0];
            visited++;
            UIView *view = item[@"view"];
            NSUInteger depth = [item[@"depth"] unsignedIntegerValue];
            if (view.hidden || view.alpha < 0.01 || STIsKeyboard(view)) continue;
            NSUInteger nodeID = nodes.count;
            BOOL textEntry = STIsTextEntry(view);
            CGRect windowRect = [view convertRect:view.bounds toView:window];
            NSMutableDictionary *node = [@{@"id": @(nodeID), @"parent": item[@"parent"], @"depth": @(depth),
                @"window": @(windowIndex), @"class": STClassName(view), @"rectInWindowPoints": STRect(windowRect),
                @"interactive": @(view.userInteractionEnabled), @"alpha": @(STFinite(view.alpha)),
                @"clipsToBounds": @(view.clipsToBounds), @"textEntryRedacted": @(textEntry)} mutableCopy];
            if ([view isKindOfClass:UIControl.class]) {
                UIControl *control = (UIControl *)view;
                node[@"enabled"] = @(control.enabled); node[@"selected"] = @(control.selected);
            }
            NSString *viewClass = STClassName(view);
            NSString *layerClass = STClassName(view.layer);
            if ([viewClass containsString:@"Unity"] || [viewClass containsString:@"Metal"] ||
                [layerClass isEqualToString:@"CAMetalLayer"] || [layerClass isEqualToString:@"CAEAGLLayer"]) {
                node[@"renderSurface"] = layerClass;
                [renderers addObject:@"nativeRenderedSurface"];
            }
            if ([view isKindOfClass:WKWebView.class]) {
                [renderers addObject:@"webView"];
            }
            [nodes addObject:node];
            if (textEntry) continue; // No editor contents, descendants, accessibility values, or text.
            if (depth >= STMaximumViewDepth) { if (view.subviews.count) truncated = YES; continue; }
            for (UIView *child in view.subviews) {
                if (pending.count >= 256) { truncated = YES; break; }
                [pending addObject:@{@"view": child, @"parent": @(nodeID), @"depth": @(depth + 1)}];
            }
        }
        if (pending.count) truncated = YES;
    }
    NSNumber *snapshotID = @(self.snapshots.count + 1);
    [self.snapshots addObject:@{@"id": snapshotID, @"elapsedMs": @(STFinite((STNow() - self.startedAt) * 1000)),
        @"reason": reason, @"windows": windowReports, @"views": nodes, @"truncated": @(truncated),
        @"renderersObserved": [renderers.allObjects sortedArrayUsingSelector:@selector(compare:)],
        @"gameWebViewEligible": @(gameWebView != nil), @"internalGameStateCaptured": @NO}];
    // Append the native snapshot first: even an immediate missing-script callback
    // can only refer to an ID which is already in the report.
    if (gameWebView) {
        NSUInteger generation = self.generation;
        __weak STRecorder *weakSelf = self;
        [self.webProbe sampleWebView:gameWebView elapsedMilliseconds:(STNow() - self.startedAt) * 1000
            completion:^(NSDictionary *sample) {
                STRecorder *strongSelf = weakSelf;
                if (!strongSelf.isRecording || strongSelf.generation != generation || strongSelf.webSamples.count >= 180) return;
                NSMutableDictionary *linked = [sample mutableCopy];
                linked[@"nativeSnapshotID"] = snapshotID;
                [strongSelf.webSamples addObject:linked];
            }];
    }
    return snapshotID;
}

- (NSArray<NSMutableDictionary *> *)beforeEvent:(UIEvent *)event {
    if (!self.isRecording || event.type != UIEventTypeTouches) return @[];
    NSTimeInterval now = STNow();
    if (now - self.startedAt >= STMaximumDuration) { [self stopRecordingWithReason:@"durationLimit"]; return @[]; }
    NSMutableArray *accepted = [NSMutableArray array];
    NSNumber *beforeID = self.snapshots.lastObject[@"id"];
    BOOL sampledBefore = NO;
    for (UITouch *touch in event.allTouches) {
        UITouchPhase phase = touch.phase;
        if (phase != UITouchPhaseBegan && phase != UITouchPhaseMoved && phase != UITouchPhaseEnded && phase != UITouchPhaseCancelled) continue;
        NSString *exclusion = STTouchExclusion(touch);
        if (exclusion) { [self countOmitted:exclusion]; continue; }
        if (self.touches.count >= STMaximumTouchSamples) break;
        NSNumber *touchID = [self.touchIDs objectForKey:touch];
        BOOL missingBegin = !touchID && phase != UITouchPhaseBegan;
        if (!touchID) { touchID = @(++self.nextTouchID); [self.touchIDs setObject:touchID forKey:touch]; }
        if (phase == UITouchPhaseMoved) {
            NSTimeInterval last = [self.lastMove[touchID] doubleValue];
            if (last && now - last < STMoveInterval) { [self countOmitted:@"moveThrottled"]; continue; }
            self.lastMove[touchID] = @(now);
        }
        if (phase == UITouchPhaseBegan && !sampledBefore && now - self.lastEventSnapshotAt >= 0.3 &&
            self.eventSnapshotCount < STMaximumEventSnapshots) {
            NSNumber *captured = [self captureSnapshot:@"beforeTouch"];
            if (captured) { beforeID = captured; self.eventSnapshotCount++; self.lastEventSnapshotAt = now; }
            sampledBefore = YES;
        }
        UIWindow *window = touch.window;
        CGPoint point = [touch locationInView:window];
        CGRect bounds = window.bounds;
        NSMutableDictionary *entry = [@{@"sequence": @(self.touches.count + 1), @"touchID": touchID,
            @"phase": STTouchPhase(phase), @"missingBegin": @(missingBegin),
            @"elapsedMs": @(STFinite((now - self.startedAt) * 1000)),
            @"touchTimestampElapsedMs": @(STFinite((touch.timestamp - self.startedAt) * 1000)),
            @"pointInWindow": STPoint(point), @"windowBoundsPoints": STRect(bounds),
            @"normalized": STPoint(CGPointMake(bounds.size.width > 0 ? (point.x - bounds.origin.x) / bounds.size.width : 0,
                                               bounds.size.height > 0 ? (point.y - bounds.origin.y) / bounds.size.height : 0)),
            @"orientation": @(window.windowScene.interfaceOrientation),
            @"viewClass": STClassName(touch.view), @"windowClass": STClassName(window),
            @"beforeSnapshotID": beforeID ?: NSNull.null} mutableCopy];
        [self.touches addObject:entry]; [accepted addObject:entry];
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            [self.touchIDs removeObjectForKey:touch]; [self.lastMove removeObjectForKey:touchID];
        }
    }
    return accepted;
}

- (void)afterEvent:(NSArray<NSMutableDictionary *> *)entries generation:(NSUInteger)generation {
    if (!self.isRecording || self.generation != generation) return;
    if (self.touches.count >= STMaximumTouchSamples) { [self stopRecordingWithReason:@"touchLimit"]; return; }
    BOOL ended = NO;
    for (NSDictionary *entry in entries)
        if ([entry[@"phase"] isEqualToString:@"ended"] || [entry[@"phase"] isEqualToString:@"cancelled"]) { ended = YES; break; }
    if (!ended || self.afterSnapshotPending || self.eventSnapshotCount >= STMaximumEventSnapshots) return;
    self.afterSnapshotPending = YES;
    // UIKit objects are not captured by the block. The copy contains only JSON primitives.
    NSArray *eventEntries = [entries copy];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!self.isRecording || self.generation != generation) return;
        self.afterSnapshotPending = NO;
        if (self.eventSnapshotCount >= STMaximumEventSnapshots) return;
        NSNumber *afterID = [self captureSnapshot:@"afterTouch"];
        if (!afterID) return;
        self.eventSnapshotCount++;
        self.lastEventSnapshotAt = STNow();
        for (NSMutableDictionary *entry in eventEntries) entry[@"afterSnapshotID"] = afterID;
    });
}

- (void)markEvent:(NSString *)name details:(NSDictionary<NSString *,id> *)details {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self markEvent:name details:details]; }); return;
    }
    if (!self.isRecording) return;
    NSSet *names = [NSSet setWithArray:@[@"crazyAlpacaEntered", @"matchStarted", @"matchEnded", @"elementsObserved",
        @"visualRecordingStarted", @"visualRecordingStopped", @"visualRecordingFailed"]];
    if (![names containsObject:name]) { [self countOmitted:@"unknownMarker"]; return; }
    if (self.markers.count >= STMaximumMarkers) { [self countOmitted:@"markerLimit"]; return; }
    NSMutableDictionary *safeDetails = [NSMutableDictionary dictionary];
    id source = details[@"source"];
    if ([source isKindOfClass:NSString.class] && [@[@"user", @"overlay", @"replaykit"] containsObject:source]) safeDetails[@"source"] = source;
    id enabled = details[@"enabled"];
    if ([enabled isKindOfClass:NSNumber.class]) safeDetails[@"enabled"] = @([enabled boolValue]);
    id duration = details[@"durationSeconds"];
    if ([duration isKindOfClass:NSNumber.class] && isfinite([duration doubleValue])) safeDetails[@"durationSeconds"] = @(MAX(0, MIN([duration doubleValue], 3600)));
    NSTimeInterval elapsed = STNow() - self.startedAt;
    NSNumber *snapshotID = [self captureSnapshot:@"userMarker"];
    [self.markers addObject:@{@"name": name, @"elapsedMs": @(STFinite(elapsed * 1000)), @"details": safeDetails,
                             @"snapshotID": snapshotID ?: NSNull.null,
                             @"semanticConfirmation": @"userMarkerNotAutomaticDetection"}];
    [self notifyChange];
}

- (void)markVisualRecordingEndForSessionIdentifier:(NSString *)identifier failed:(BOOL)failed durationSeconds:(NSTimeInterval)durationSeconds {
    if (!NSThread.isMainThread) {
        NSString *copiedID = [identifier copy];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self markVisualRecordingEndForSessionIdentifier:copiedID failed:failed durationSeconds:durationSeconds];
        });
        return;
    }
    if (!self.startedAt || !identifier.length || ![identifier isEqualToString:self.sessionID]) return;
    NSTimeInterval elapsed = STNow() - self.startedAt;
    if (!isfinite(elapsed) || elapsed < 0 || elapsed > 3600) return;
    for (NSDictionary *marker in self.markers)
        if ([marker[@"name"] isEqualToString:@"visualRecordingStopped"] || [marker[@"name"] isEqualToString:@"visualRecordingFailed"]) return;
    // One reserved terminal video marker remains possible when ordinary markers hit their cap.
    if (self.markers.count > STMaximumMarkers) return;
    NSTimeInterval boundedDuration = isfinite(durationSeconds) ? MAX(0, MIN(durationSeconds, 3600)) : 0;
    [self.markers addObject:@{@"name": failed ? @"visualRecordingFailed" : @"visualRecordingStopped",
        @"elapsedMs": @(elapsed * 1000), @"afterJSONCaptureStop": @(!self.isRecording),
        @"details": @{@"source": @"replaykit", @"durationSeconds": @(boundedDuration)},
        @"snapshotID": NSNull.null, @"semanticConfirmation": @"replaykitLifecycleCallback"}];
    [self notifyChange];
}

- (NSDictionary<NSString *,id> *)snapshotReport {
    if (!NSThread.isMainThread) return @{@"error": @"mainThreadRequired"};
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    NSMutableDictionary *app = [NSMutableDictionary dictionary];
    for (NSString *key in @[@"CFBundleIdentifier", @"CFBundleShortVersionString", @"CFBundleVersion"]) {
        id value = info[key];
        if ([value isKindOfClass:NSString.class]) app[key] = [value substringToIndex:MIN([value length], (NSUInteger)160)];
    }
    NSTimeInterval duration = self.startedAt > 0 ? (self.isRecording ? STNow() : self.stoppedAt) - self.startedAt : 0;
    NSDictionary *report = @{
        @"format": @"SDKtools.Capture", @"schemaVersion": @1, @"toolVersion": @"1.0.0",
        @"sessionID": self.sessionID, @"startedAtUTC": self.startedDate,
        @"clock": @"monotonicSystemUptimeRelativeMilliseconds", @"coordinateUnit": @"UIKitWindowPoints",
        @"recording": @(self.isRecording), @"durationSeconds": @(STFinite(MAX(0, duration))), @"stopReason": self.stopReason,
        @"application": app, @"osVersion": UIDevice.currentDevice.systemVersion,
        @"limits": @{@"durationSeconds": @(STMaximumDuration), @"touchSamples": @(STMaximumTouchSamples),
            @"moveIntervalMilliseconds": @100, @"snapshots": @(STMaximumSnapshots), @"eventSnapshots": @(STMaximumEventSnapshots),
            @"viewsPerSnapshot": @(STMaximumViews), @"viewDepth": @(STMaximumViewDepth), @"markers": @(STMaximumMarkers),
            @"terminalVideoMarkerReserve": @1, @"webSamples": @180},
        @"observability": @{@"crazyAlpacaIdentity": @"notAutomaticallyVerified", @"sheepCorrespondence": @"requiresVisualEvidence",
            @"internalGameStateCaptured": @NO, @"cardsCaptured": @NO,
            @"hiddenCardContentDetermined": @NO, @"occlusionUnknown": @YES,
            @"visualEvidence": @"notContainedInJSON", @"renderedBoardNote": @"Canvas cards are not UIKit views. Optional Cocos scene structure does not confirm card identities. Pair this JSON with a user-approved screen video.",
            @"periodicSnapshotSeconds": @1, @"afterTouchSnapshotDelaySeconds": @0.25},
        @"privacy": @{@"inputValues": @NO, @"viewText": @NO, @"accessibilityValues": @NO, @"clipboard": @NO,
            @"credentials": @NO, @"urls": @NO, @"networkPayloads": @NO, @"memoryReads": @NO, @"screenshots": @NO,
            @"sdktoolsTouchesExcluded": @YES, @"textInputTouchesExcluded": @YES, @"automaticInput": @NO},
        @"touches": self.touches, @"snapshots": self.snapshots, @"markers": self.markers, @"webSamples": self.webSamples, @"omitted": self.omitted,
        @"unfinishedTouchIDsAtStop": self.unfinishedTouchIDs,
        @"notes": @[@"A marker identifies what the user reported, not an automatically recognized game screen.",
                    @"A touch followed by a UI change does not prove that touch caused the change.",
                    @"No card solver, X-ray or autoplay is implemented by this recorder."]
    };
    // Detach mutable internal collections so callers cannot corrupt the recording state.
    NSData *data = [NSJSONSerialization dataWithJSONObject:report options:0 error:nil];
    return data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : @{@"error": @"reportSerializationFailed"};
}

- (NSURL *)writeReportWithError:(NSError **)error {
    if (!NSThread.isMainThread || !self.startedAt) {
        if (error) *error = [NSError errorWithDomain:@"SDKtools.Recorder" code:1 userInfo:@{NSLocalizedDescriptionKey: @"Inicie uma captura antes de exportar, na thread principal."}];
        return nil;
    }
    if (self.isRecording) [self stopRecordingWithReason:@"export"];
    NSDictionary *report = [self snapshotReport];
    if (report[@"error"]) {
        if (error) *error = [NSError errorWithDomain:@"SDKtools.Recorder" code:2 userInfo:@{NSLocalizedDescriptionKey: @"Não foi possível montar o relatório da captura."}];
        return nil;
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingPrettyPrinted error:error];
    if (!data) return nil;
    NSURL *documents = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:error];
    if (!documents) return nil;
    NSURL *folder = [documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES];
    if (![[NSFileManager defaultManager] createDirectoryAtURL:folder withIntermediateDirectories:YES
        attributes:@{NSFileProtectionKey: NSFileProtectionComplete} error:error]) return nil;
    NSString *filename = [NSString stringWithFormat:@"SDKtools-Capture-%@.json", NSUUID.UUID.UUIDString];
    NSURL *destination = [folder URLByAppendingPathComponent:filename];
    if (![data writeToURL:destination options:NSDataWritingAtomic | NSDataWritingFileProtectionComplete error:error]) return nil;
    [destination setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
    return destination;
}

@end

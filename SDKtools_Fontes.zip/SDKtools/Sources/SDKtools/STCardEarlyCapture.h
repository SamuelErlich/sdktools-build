#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// Card-only diagnostic, armed BEFORE entering game 2007. No evaluateJavaScript.
/// All API calls are main-thread only. A stopped report remains exportable.
/// V3.13 keeps the API for source compatibility but compiles an inert
/// implementation: arm returns NO; no observer, timer or hook is installed.
@interface STCardEarlyCapture : NSObject
+ (instancetype)shared;
@property (nonatomic, readonly) BOOL active;
@property (nonatomic, readonly) BOOL requested;
@property (nonatomic, copy, readonly) NSString *statusText;
- (BOOL)arm;
- (void)stopWithReason:(NSString *)reason;
- (NSDictionary *)snapshotReport;
@end
NS_ASSUME_NONNULL_END

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSNotificationName const STRecorderDidChangeNotification;

/// An explicitly started bounded recorder with a separately requested original
/// Retornar popup action. Main-thread use only. Public scene structure does not
/// establish card identity, rules, or occlusion. No arbitrary memory reads.
@interface STRecorder : NSObject
+ (instancetype)shared;
@property (nonatomic, readonly, getter=isRecording) BOOL recording;
@property (nonatomic, copy, readonly) NSString *statusText;
@property (nonatomic, copy, readonly) NSString *captureSessionIdentifier;
/// Explicit, read-only control tracing for the current capture, including
/// bounded local methods and numeric state of identified Retornar controls.
@property (nonatomic, readonly) BOOL returnTraceActive;
@property (nonatomic, readonly) BOOL returnActionBusy;
@property (nonatomic, copy, readonly) NSString *returnActionStatus;
@property (nonatomic, readonly) BOOL autoplayEnabled;
@property (nonatomic, readonly) BOOL autoplayBusy;
@property (nonatomic, readonly) NSUInteger autoplayCardsRead;
@property (nonatomic, readonly) NSUInteger autoplayCardTypesRead;
@property (nonatomic, readonly) NSUInteger autoplayConfirmedMoves;
@property (nonatomic, copy, readonly) NSString *autoplayStatusText;
@property (nonatomic, readonly) BOOL xrayEnabled;
@property (nonatomic, readonly) NSInteger xrayDepth;
@property (nonatomic, copy, readonly) NSString *xrayStatusText;
- (void)setXrayEnabled:(BOOL)enabled;
- (void)setXrayDepth:(NSInteger)depth;
/// Read-only, explicitly enabled labels for the verified Ah, minha carta game.
@property (nonatomic, readonly) BOOL cardHintsEnabled;
@property (nonatomic, readonly) BOOL cardHintsBusy;
@property (nonatomic, copy, readonly) NSString *cardHintsStatusText;
- (BOOL)setCardHintsEnabled:(BOOL)enabled;
/// Native menu command: install if inactive, otherwise request a fresh read now.
- (BOOL)injectCardColorsAndReadRoot;
/// Explicit, read-only game-2007 capture. Stops at 90 seconds or 200 samples.
@property (nonatomic, readonly) BOOL cardInvestigationActive;
@property (nonatomic, copy, readonly) NSString *cardInvestigationStatusText;
- (BOOL)beginCardInvestigation;
/// Opt-in temporary method observers; numeric card fields only.
@property (nonatomic, readonly) BOOL cardFlowRequested;
@property (nonatomic, copy, readonly) NSString *cardFlowStatusText;
- (BOOL)beginCardFlowInvestigation;
/// Arms the next native game-2007 document before scene/socket startup.
/// Waiting is separate from the 90-second document capture. No game reload.
@property (nonatomic, readonly) BOOL cardEarlyActive;
@property (nonatomic, readonly) BOOL cardEarlyRequested;
@property (nonatomic, copy, readonly) NSString *cardEarlyStatusText;
- (BOOL)beginCardEarlyCapture;
- (void)stopCardEarlyCapture;
- (void)stopCardEarlyCaptureWithReason:(NSString *)reason;
- (BOOL)openOwnWarehouseWithUpdate:(void (^)(NSDictionary<NSString *, id> *result))update;
/// Explicit play/resume. Independent of recording; manual input and background
/// pause scheduling. A previously submitted physical operation may still finish.
- (BOOL)startAutoplay;
- (void)pauseAutoplayWithReason:(NSString *)reason;
/// Opens one original power or confirms the currently visible original popup.
/// Each command requires a separate explicit tap; stock stays authoritative.
/// Updates may first report an uncertain timeout while the physical call remains
/// pending, then its final callback. Returning NO means no new call was submitted.
- (BOOL)performOriginalPowerAtSlot:(NSString *)slot
                         command:(NSString *)command
                          update:(void (^)(NSDictionary<NSString *, id> *result))update;
/// Explicit static-source export for the currently verified local game only.
/// Main-thread call/completion; scanning and serialization run off the UI thread.
@property (nonatomic, readonly) BOOL sourceExportBusy;
@property (nonatomic, copy, readonly) NSString *sourceExportStatus;
- (void)exportCurrentGameSourcesWithCompletion:(void (^)(NSURL * _Nullable URL, NSError * _Nullable error))completion;
- (void)startRecording;
/// Observe only the active hosted game, then require a separate visual label
/// confirmation. This never enables autoplay or reads lobby/chat contents.
@property (nonatomic, readonly) BOOL detectedGameDetectionActive;
@property (nonatomic, readonly) BOOL detectedGameReadyToConfirm;
@property (nonatomic, readonly) BOOL detectedGameCaptureActive;
@property (nonatomic, copy, readonly) NSString *detectedGameStatusText;
- (BOOL)beginNewGameDetection;
- (void)cancelNewGameDetection;
// Confirms the observed controller/WebView/document, not the game title.
- (BOOL)confirmNewGameCapture;
- (void)stopRecordingWithReason:(NSString *)reason;
/// Arms an existing capture. Never invokes a game action or changes item stock.
/// Returns NO when recording is stopped or the trace is already armed.
- (BOOL)beginReturnTrace;
/// Only the documented marker names and safe scalar details are accepted.
- (void)markEvent:(NSString *)name details:(nullable NSDictionary<NSString *, id> *)details;
/// ReplayKit may finish after an automatic JSON stop. A matching session ID is mandatory.
- (void)markVisualRecordingEndForSessionIdentifier:(NSString *)identifier
                                          failed:(BOOL)failed
                                 durationSeconds:(NSTimeInterval)durationSeconds;
/// Returns a detached JSON-compatible report. No UIKit objects are retained in it.
- (NSDictionary<NSString *, id> *)snapshotReport;
/// Creates a uniquely named JSON in Documents/SDKtools. Stops an active capture first.
- (nullable NSURL *)writeReportWithError:(NSError * _Nullable * _Nullable)error;
@end

NS_ASSUME_NONNULL_END

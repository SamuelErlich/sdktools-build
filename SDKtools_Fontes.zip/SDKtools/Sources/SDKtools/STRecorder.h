#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSNotificationName const STRecorderDidChangeNotification;

/// A passive, explicitly started, bounded recorder. All methods run on the main thread.
/// It never generates input and does not inspect native game memory or hidden cards.
@interface STRecorder : NSObject
+ (instancetype)shared;
@property (nonatomic, readonly, getter=isRecording) BOOL recording;
@property (nonatomic, copy, readonly) NSString *statusText;
@property (nonatomic, copy, readonly) NSString *captureSessionIdentifier;
- (void)startRecording;
- (void)stopRecordingWithReason:(NSString *)reason;
/// Only the documented marker names and safe scalar details are accepted.
- (void)markEvent:(NSString *)name details:(nullable NSDictionary<NSString *, id> *)details;
/// ReplayKit may finish after an automatic JSON stop. A matching session ID is mandatory.
- (void)markVisualRecordingEndForSessionIdentifier:(NSString *)identifier
                                          failed:(BOOL)failed
                                 durationSeconds:(NSTimeInterval)durationSeconds;
/// Returns a detached JSON-compatible report. No UIKit objects are retained in it.
- (NSDictionary<NSString *, id> *)snapshotReport;
/// Creates a uniquely named JSON in Documents/SDKtools. Stops an active capture first.
- (nullable NSURL *)writeReportWithError:(NSError * _Nullable * _Nullable)error;
@end

NS_ASSUME_NONNULL_END

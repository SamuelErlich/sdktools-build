#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSNotificationName const STRecorderDidChangeNotification;

/// An explicitly started bounded recorder with a separately requested original
/// Retornar popup action. Main-thread use only. Public scene structure does not
/// establish card identity, rules, or occlusion. No arbitrary memory reads.
@interface STRecorder : NSObject
+ (instancetype)shared;
@property (nonatomic, readonly, getter=isRecording) BOOL recording;
@property (nonatomic, copy, readonly) NSString *statusText;
@property (nonatomic, copy, readonly) NSString *captureSessionIdentifier;
/// Explicit, read-only control tracing for the current capture, including
/// bounded local methods and numeric state of identified Retornar controls.
@property (nonatomic, readonly) BOOL returnTraceActive;
@property (nonatomic, readonly) BOOL returnActionBusy;
@property (nonatomic, copy, readonly) NSString *returnActionStatus;
/// Opens the original confirmation only, without starting a recording. Original
/// item stock and the manual Usar item confirmation remain the game's authority.
/// Updates may first report an uncertain timeout while the physical call remains
/// pending, then its final callback. Returning NO means no new call was submitted.
- (BOOL)performOriginalReturnWithUpdate:(void (^)(NSDictionary<NSString *, id> *result))update;
- (void)startRecording;
- (void)stopRecordingWithReason:(NSString *)reason;
/// Arms an existing capture. Never invokes a game action or changes item stock.
/// Returns NO when recording is stopped or the trace is already armed.
- (BOOL)beginReturnTrace;
/// Only the documented marker names and safe scalar details are accepted.
- (void)markEvent:(NSString *)name details:(nullable NSDictionary<NSString *, id> *)details;
/// ReplayKit may finish after an automatic JSON stop. A matching session ID is mandatory.
- (void)markVisualRecordingEndForSessionIdentifier:(NSString *)identifier
                                          failed:(BOOL)failed
                                 durationSeconds:(NSTimeInterval)durationSeconds;
/// Returns a detached JSON-compatible report. No UIKit objects are retained in it.
- (NSDictionary<NSString *, id> *)snapshotReport;
/// Creates a uniquely named JSON in Documents/SDKtools. Stops an active capture first.
- (nullable NSURL *)writeReportWithError:(NSError * _Nullable * _Nullable)error;
@end

NS_ASSUME_NONNULL_END

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSNotificationName const STRecorderDidChangeNotification;

/// A passive, explicitly started, bounded recorder. All methods run on the main thread.
/// It never generates input or reads arbitrary process memory. Public scene structure
/// does not establish card identity, rules, or occlusion.
@interface STRecorder : NSObject
+ (instancetype)shared;
@property (nonatomic, readonly, getter=isRecording) BOOL recording;
@property (nonatomic, copy, readonly) NSString *statusText;
@property (nonatomic, copy, readonly) NSString *captureSessionIdentifier;
/// Explicit, read-only control metadata tracing for the current capture.
@property (nonatomic, readonly) BOOL returnTraceActive;
- (void)startRecording;
- (void)stopRecordingWithReason:(NSString *)reason;
/// Arms an existing capture. Never invokes a game action or changes item stock.
/// Returns NO when recording is stopped or the trace is already armed.
- (BOOL)beginReturnTrace;
/// Only the documented marker names and safe scalar details are accepted.
- (void)markEvent:(NSString *)name details:(nullable NSDictionary<NSString *, id> *)details;
/// ReplayKit may finish after an automatic JSON stop. A matching session ID is mandatory.
- (void)markVisualRecordingEndForSessionIdentifier:(NSString *)identifier
                                          failed:(BOOL)failed
                                 durationSeconds:(NSTimeInterval)durationSeconds;
/// Returns a detached JSON-compatible report. No UIKit objects are retained in it.
- (NSDictionary<NSString *, id> *)snapshotReport;
/// Creates a uniquely named JSON in Documents/SDKtools. Stops an active capture first.
- (nullable NSURL *)writeReportWithError:(NSError * _Nullable * _Nullable)error;
@end

NS_ASSUME_NONNULL_END

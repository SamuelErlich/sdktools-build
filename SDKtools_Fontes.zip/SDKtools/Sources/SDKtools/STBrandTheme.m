#import "STBrandTheme.h"
#import <CoreText/CoreText.h>
@interface STBrandBundle : NSObject @end
@implementation STBrandBundle @end
UIColor *STBrandColor(uint32_t rgb) {
    return [UIColor colorWithRed:((rgb>>16)&255)/255.0 green:((rgb>>8)&255)/255.0 blue:(rgb&255)/255.0 alpha:1];
}
void STRegisterBrandFonts(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSBundle *bundle=[NSBundle bundleForClass:STBrandBundle.class];
        for (NSString *name in @[@"Syne-SemiBold",@"Syne-Bold",@"Syne-ExtraBold",@"Geist-Regular",@"Geist-Medium",@"Geist-SemiBold",@"MartianMonoSemiCondensed-Regular",@"MartianMonoSemiCondensed-Medium"]) {
            NSURL *url=[bundle URLForResource:name withExtension:@"ttf" subdirectory:@"Brand/Fonts"];
            if (url) CTFontManagerRegisterFontsForURL((__bridge CFURLRef)url, kCTFontManagerScopeProcess, NULL);
        }
    });
}
UIFont *STBrandFont(NSString *name, CGFloat size, UIFontTextStyle style) {
    STRegisterBrandFonts();
    UIFont *font=[UIFont fontWithName:name size:size] ?: [UIFont systemFontOfSize:size];
    return [[UIFontMetrics metricsForTextStyle:style] scaledFontForFont:font];
}
UIImage *STBrandImage(NSString *name, BOOL templateImage) {
    static NSCache<NSString *,UIImage *> *cache; static dispatch_once_t once;
    dispatch_once(&once,^{ cache=[NSCache new]; cache.countLimit=64; });
    NSString *key=[name stringByAppendingString:templateImage?@".template":@".original"];
    UIImage *image=[cache objectForKey:key];
    if (!image) {
        NSURL *url=[[NSBundle bundleForClass:STBrandBundle.class] URLForResource:[name stringByAppendingString:@"@3x"] withExtension:@"png" subdirectory:@"Brand"];
        NSData *data=url?[NSData dataWithContentsOfURL:url]:nil;
        image=data?[UIImage imageWithData:data scale:3]:nil;
        image=[image imageWithRenderingMode:templateImage?UIImageRenderingModeAlwaysTemplate:UIImageRenderingModeAlwaysOriginal];
        if (image) [cache setObject:image forKey:key];
    }
    return image;
}

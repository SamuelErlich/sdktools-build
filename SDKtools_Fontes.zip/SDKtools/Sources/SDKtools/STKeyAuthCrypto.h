#ifndef ST_KEYAUTH_CRYPTO_H
#define ST_KEYAUTH_CRYPTO_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Returns 1 only for a valid Ed25519 signature. Messages are limited to 1 MiB;
 * an empty message may use NULL. All other buffers must be non-NULL. */
int32_t STKeyAuthVerifyEd25519(const uint8_t *signature, size_t signatureLength,
                             const uint8_t *message, size_t messageLength,
                             const uint8_t *publicKey, size_t publicKeyLength);

#ifdef __cplusplus
}
#endif

#endif

#import "STLocalization.h"
#import <CoreFoundation/CoreFoundation.h>
#import <dispatch/dispatch.h>

NSNotificationName const STLanguageDidChangeNotification=@"SDKClient.LanguageDidChange";
static NSString *const STLanguagePreference=@"SDKClient.language";
static NSString *STLanguageValue;
static NSLock *STLanguageLock;

NSString *STLanguageFromPreferences(NSArray<NSString *> *preferred, NSString *saved) {
    if ([saved isEqual:@"en"] || [saved isEqual:@"pt"]) return saved;
    for (id value in preferred) {
        if (![value isKindOfClass:NSString.class]) continue;
        NSString *code=[[[value lowercaseString] stringByReplacingOccurrencesOfString:@"_" withString:@"-"] componentsSeparatedByString:@"-"].firstObject;
        if ([code isEqual:@"pt"] || [code isEqual:@"en"]) return code;
    }
    return @"en";
}
static void STInitializeLanguage(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        STLanguageLock=[NSLock new];
        id saved=[NSUserDefaults.standardUserDefaults objectForKey:STLanguagePreference];
        STLanguageValue=STLanguageFromPreferences(NSLocale.preferredLanguages,[saved isKindOfClass:NSString.class]?saved:nil);
        [NSUserDefaults.standardUserDefaults setObject:STLanguageValue forKey:STLanguagePreference];
    });
}
NSString *STCurrentLanguage(void) {
    STInitializeLanguage(); [STLanguageLock lock]; NSString *value=STLanguageValue; [STLanguageLock unlock]; return value;
}
BOOL STSetLanguage(NSString *language) {
    if (!NSThread.isMainThread || (! [language isEqual:@"en"] && ![language isEqual:@"pt"])) return NO;
    STInitializeLanguage(); [STLanguageLock lock];
    BOOL changed=![STLanguageValue isEqual:language]; STLanguageValue=[language copy]; [STLanguageLock unlock];
    [NSUserDefaults.standardUserDefaults setObject:language forKey:STLanguagePreference];
    if (changed) [[NSNotificationCenter defaultCenter] postNotificationName:STLanguageDidChangeNotification object:nil];
    return YES;
}

@interface STLocalizationCatalog ()
@property(nonatomic,copy) NSDictionary<NSString *,NSDictionary *> *aliases;
@property(nonatomic,copy) NSArray<NSDictionary *> *patterns;
@property(nonatomic,readwrite) NSUInteger entryCount;
@end

// This is a deliberately small, validated printf subset. The catalog never
// becomes a format string: captured values are copied as text, preserving their
// original precision/sign, and only object arguments are translated recursively.
static NSArray<NSTextCheckingResult *> *STFormatSlots(NSString *text) {
    static NSRegularExpression *token; static dispatch_once_t once;
    dispatch_once(&once, ^{
        token=[NSRegularExpression regularExpressionWithPattern:@"%(?:[0-9]+)?(?:\\.[0-9]+)?(?:@|(?:ll|l)?[udi]|f)" options:0 error:NULL];
    });
    NSMutableArray *slots=[NSMutableArray array]; NSUInteger offset=0;
    while (offset<text.length) {
        NSRange percent=[text rangeOfString:@"%" options:0 range:NSMakeRange(offset,text.length-offset)];
        if (percent.location==NSNotFound) break;
        offset=percent.location;
        if (offset+1<text.length && [text characterAtIndex:offset+1]=='%') { offset+=2; continue; }
        NSTextCheckingResult *match=[token firstMatchInString:text options:NSMatchingAnchored range:NSMakeRange(offset,text.length-offset)];
        if (!match) return nil;
        [slots addObject:match]; offset=NSMaxRange(match.range);
    }
    return slots;
}
static NSArray<NSString *> *STFormatSignature(NSString *text,NSArray<NSTextCheckingResult *> *slots) {
    NSMutableArray *signature=[NSMutableArray arrayWithCapacity:slots.count];
    for (NSTextCheckingResult *slot in slots) [signature addObject:[text substringWithRange:slot.range]];
    return signature;
}
static NSString *STFormatLiteral(NSString *text) {
    return [text stringByReplacingOccurrencesOfString:@"%%" withString:@"%"];
}
@implementation STLocalizationCatalog
- (instancetype)initWithData:(NSData *)data {
    if (!(self=[super init])) return nil;
    if (![data isKindOfClass:NSData.class] || !data.length || data.length>1024*1024) return nil;
    id root=[NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if (![root isKindOfClass:NSDictionary.class] || ![root[@"schemaVersion"] isKindOfClass:NSNumber.class] ||
        CFGetTypeID((__bridge CFTypeRef)root[@"schemaVersion"])==CFBooleanGetTypeID() || ![root[@"schemaVersion"] isEqual:@1] ||
        ![root[@"languages"] isEqual:@[@"en",@"pt"]] || ![root[@"entries"] isKindOfClass:NSArray.class]) return nil;
    NSArray *rows=root[@"entries"]; if (!rows.count || rows.count>1024) return nil;
    NSMutableDictionary *aliases=[NSMutableDictionary dictionary]; NSMutableArray *patterns=[NSMutableArray array];
    for (id row in rows) {
        if (![row isKindOfClass:NSDictionary.class]) return nil;
        NSMutableDictionary *formats=[NSMutableDictionary dictionary]; NSArray *signature=nil;
        NSArray *keys=row[@"source"]?@[@"en",@"pt",@"source"]:@[@"en",@"pt"];
        for (NSString *key in keys) {
            NSString *source=row[key];
            if (![source isKindOfClass:NSString.class] || !source.length || source.length>2048) return nil;
            if (aliases[source] && ![aliases[source] isEqual:row]) return nil;
            aliases[source]=row;
            NSArray *slots=STFormatSlots(source); if (!slots) return nil;
            NSArray *current=STFormatSignature(source,slots);
            if (signature && ![signature isEqual:current]) return nil;
            signature=current; formats[key]=slots;
        }
        NSMutableSet *seen=[NSMutableSet set];
        for (NSString *key in keys) {
            NSString *source=row[key];
            NSArray<NSTextCheckingResult *> *matches=formats[key];
            if (!matches.count) continue;
            NSUInteger slotLength=0;
            for (NSTextCheckingResult *match in matches) slotLength+=match.range.length;
            if (slotLength==source.length) return nil;
            NSMutableString *expression=[NSMutableString stringWithString:@"\\A"]; NSUInteger offset=0;
            for (NSTextCheckingResult *match in matches) {
                [expression appendString:[NSRegularExpression escapedPatternForString:STFormatLiteral([source substringWithRange:NSMakeRange(offset,match.range.location-offset)])]];
                NSString *specifier=[source substringWithRange:match.range];
                NSString *capture;
                // One object slot must not swallow sibling status components.
                // Otherwise generic "%ld %@" hides "cards" before the next
                // separator, and "Shots %@" consumes the calibration suffix.
                if ([specifier hasSuffix:@"@"]) capture=@"((?:(?! · ).)*?)";
                else if ([specifier hasSuffix:@"f"]) capture=@"([ ]*[-+]?(?:[0-9]+(?:[.,][0-9]*)?|[.,][0-9]+)(?:[eE][-+]?[0-9]+)?)";
                else if ([specifier hasSuffix:@"u"]) capture=@"([ ]*[+]?[0-9]+)";
                else capture=@"([ ]*[-+]?[0-9]+)";
                [expression appendString:capture];
                offset=NSMaxRange(match.range);
            }
            [expression appendString:[NSRegularExpression escapedPatternForString:STFormatLiteral([source substringFromIndex:offset])]];
            [expression appendString:@"\\z"];
            NSRegularExpression *regex=[NSRegularExpression regularExpressionWithPattern:expression options:0 error:NULL];
            if (!regex || source.length<4) return nil;
            if (![seen containsObject:expression]) [patterns addObject:@{@"regex":regex,@"row":row,@"formats":formats,@"length":@(source.length)}];
            [seen addObject:expression];
        }
    }
    [patterns sortUsingComparator:^NSComparisonResult(NSDictionary *a,NSDictionary *b){return [b[@"length"] compare:a[@"length"]];}];
    self.aliases=aliases; self.patterns=patterns; self.entryCount=rows.count; return self;
}
- (NSString *)text:(NSString *)source language:(NSString *)language { return [self translate:source language:[language isEqual:@"pt"]?@"pt":@"en" depth:0]; }
- (NSString *)translate:(NSString *)source language:(NSString *)language depth:(NSUInteger)depth {
    if (!source.length || source.length>8192 || depth>8) return source;
    NSDictionary *row=self.aliases[source]; if (row) return row[language];
    for (NSDictionary *item in self.patterns) {
        NSRegularExpression *regex=item[@"regex"];
        NSTextCheckingResult *match=[regex firstMatchInString:source options:0 range:NSMakeRange(0,source.length)];
        if (!match) continue;
        NSString *target=item[@"row"][language];
        NSArray<NSTextCheckingResult *> *slots=item[@"formats"][language];
        NSMutableString *result=[NSMutableString string]; NSUInteger offset=0, group=1;
        for (NSTextCheckingResult *slot in slots) {
            [result appendString:STFormatLiteral([target substringWithRange:NSMakeRange(offset,slot.range.location-offset)])];
            NSString *part=[source substringWithRange:[match rangeAtIndex:group++]];
            NSString *specifier=[target substringWithRange:slot.range];
            [result appendString:[specifier hasSuffix:@"@"]?[self translate:part language:language depth:depth+1]:part];
            offset=NSMaxRange(slot.range);
        }
        [result appendString:STFormatLiteral([target substringFromIndex:offset])]; return result;
    }
    // Status producers keep their original diagnostics. Translate their displayed
    // components only, preserving numbers, delimiters and unknown runtime data.
    for (NSString *separator in @[@"\n",@" · "]) {
        if (![source containsString:separator]) continue;
        NSMutableArray *parts=[NSMutableArray array];
        for (NSString *part in [source componentsSeparatedByString:separator]) [parts addObject:[self translate:part language:language depth:depth+1]];
        return [parts componentsJoinedByString:separator];
    }
    // Future internal reason identifiers get a localized neutral fallback in
    // customer UI; original diagnostic tokens and commands remain unchanged.
    if ([source containsString:@"_"] && [source rangeOfCharacterFromSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyz_0123456789"] invertedSet]].location==NSNotFound)
        return self.aliases[@"Status information unavailable."][language] ?: source;
    return source;
}
@end
NSString *STLocalizedText(NSString *source) {
    static STLocalizationCatalog *catalog; static dispatch_once_t once;
    dispatch_once(&once,^{
        NSURL *url=[[NSBundle bundleForClass:STLocalizationCatalog.class] URLForResource:@"menu-localizations" withExtension:@"json" subdirectory:@"Brand"];
        NSData *data=url?[NSData dataWithContentsOfURL:url]:nil;
        if(data) catalog=[[STLocalizationCatalog alloc] initWithData:data];
    });
    return catalog?[catalog text:source ?: @"" language:STCurrentLanguage()]:(source ?: @"");
}

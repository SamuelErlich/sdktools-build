#import "STCardColorFeed.h"
#import <CoreFoundation/CoreFoundation.h>
#include <math.h>

static BOOL STCFInt(id value, NSUInteger low, NSUInteger high) {
    if (![value isKindOfClass:NSNumber.class] || CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID()) return NO;
    double d=[value doubleValue];
    return isfinite(d) && d>=low && d<=high && floor(d)==d;
}
@interface STCardColorFeed ()
@property (nonatomic) NSUInteger lastSequence;
@property (nonatomic) NSUInteger accepted;
@property (nonatomic) NSUInteger rejected;
@property (nonatomic, strong) NSMutableArray<NSNumber *> *counts;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *recent;
@end
@implementation STCardColorFeed
- (instancetype)init { if ((self=[super init])) [self reset]; return self; }
- (void)reset {
    self.lastSequence=self.accepted=self.rejected=0;
    self.counts=[@[@0,@0,@0,@0,@0] mutableCopy]; self.recent=[NSMutableArray array];
}
- (void)consumeEvents:(NSArray *)events {
    if (![events isKindOfClass:NSArray.class] || events.count>96) return;
    for (id event in events) {
        if (![event isKindOfClass:NSDictionary.class] || !STCFInt(event[@"sequence"],1,4096)) continue;
        NSUInteger sequence=[event[@"sequence"] unsignedIntegerValue];
        if (sequence<=self.lastSequence) continue;
        self.lastSequence=sequence;
        if (![event[@"stage"] isEqual:@"skin_bg_complete"]) continue;
        id valid=event[@"bindingValid"];
        if (![valid isKindOfClass:NSNumber.class] || CFGetTypeID((__bridge CFTypeRef)valid)!=CFBooleanGetTypeID() || ![valid boolValue]) { self.rejected++; continue; }
        NSArray *cards=event[@"cards"];
        if (![cards isKindOfClass:NSArray.class] || cards.count!=1) { self.rejected++; continue; }
        NSDictionary *card=cards.firstObject;
        if (![card isKindOfClass:NSDictionary.class] || !STCFInt(card[@"id"],1,65535) ||
            !STCFInt(card[@"type"],1,10) || !STCFInt(card[@"color"],0,4)) { self.rejected++; continue; }
        NSUInteger type=[card[@"type"] unsignedIntegerValue], color=[card[@"color"] unsignedIntegerValue];
        BOOL special=type==4 || type==6 || type==10;
        if (!(special?[card[@"colorState"] isEqual:@"special"]:([card[@"colorState"] isEqual:@"known"] && color>0))) { self.rejected++; continue; }
        NSUInteger bucket=special?0:color;
        self.counts[bucket]=@([self.counts[bucket] unsignedIntegerValue]+1); self.accepted++;
        NSMutableDictionary *row=[@{@"sequence":@(sequence),@"id":card[@"id"],@"type":@(type),@"color":@(color),@"special":special?@YES:@NO} mutableCopy];
        // Only fixed numeric fields cross this independent view-model boundary.
        for (NSString *key in @[@"elapsedMs",@"connectionGeneration",@"round",@"bindingGeneration"])
            if (STCFInt(event[key],0,1000000000)) row[key]=event[key];
        [self.recent addObject:[row copy]];
        if (self.recent.count>8) [self.recent removeObjectAtIndex:0];
    }
}
- (NSDictionary *)snapshot {
    return @{@"version":@1,@"meaning":@"render_observation_history_not_current_hidden_state",
        @"observations":@(self.accepted),@"rejected":@(self.rejected),
        @"byColor":[self.counts copy],@"recent":[self.recent copy]};
}
- (NSString *)statusText {
    if (!self.accepted) return @"Aguardando argumentos de cor nos eventos de renderização.";
    NSDictionary *last=self.recent.lastObject;
    NSArray *names=@[@"especial",@"vermelho",@"azul",@"amarelo",@"verde"];
    NSUInteger bucket=[last[@"special"] boolValue]?0:[last[@"color"] unsignedIntegerValue];
    return [NSString stringWithFormat:@"%lu observações de argumentos · última carta %@: %@\nHistórico recebido; não revela cartas desconhecidas.",
        (unsigned long)self.accepted,last[@"id"],names[bucket]];
}
@end

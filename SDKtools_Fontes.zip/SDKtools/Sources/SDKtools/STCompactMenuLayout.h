#ifndef ST_COMPACT_MENU_LAYOUT_H
#define ST_COMPACT_MENU_LAYOUT_H
#include <stdbool.h>

typedef struct { double width, height; } STCompactMenuSize;
// 48 header + 44 tabs + 44 footer + 16 content insets. Scroll the body
// instead of increasing the popup beyond a small portion of the game.
static inline STCompactMenuSize STCompactMenuFit(double safeWidth, double safeHeight, double contentHeight) {
    STCompactMenuSize result;
    result.width=safeWidth>288?288:(safeWidth>0?safeWidth:0);
    double desired=contentHeight+152;
    if(desired<220)desired=220;
    if(desired>380)desired=380;
    result.height=safeHeight>desired?desired:(safeHeight>0?safeHeight:0);
    return result;
}
// Gameplay indicators intentionally exclude notices and verbose runtime text.
static inline const char *STCompactMenuTag(bool autoplay, bool xray, bool cards, bool guide, int billiardsMode) {
    if(autoplay)return xray?"Auto · Xray":"Auto";
    if(guide)return billiardsMode==2?"Auto":(billiardsMode==1?"Aim":"Guide");
    if(cards)return "Cards";
    return xray?"Xray":"";
}
#endif

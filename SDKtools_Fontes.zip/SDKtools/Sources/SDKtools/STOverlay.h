#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// The recorder excludes this exact class and its subclasses from game touches.
@interface STOverlayWindow : UIWindow
@end

@interface STOverlay : NSObject
+ (instancetype)shared;
/// Main-thread only. Reuses a single window and never makes it the key window.
- (void)installIfNeeded;
@end

NS_ASSUME_NONNULL_END

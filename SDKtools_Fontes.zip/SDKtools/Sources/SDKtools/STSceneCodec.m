#import "STSceneCodec.h"
#import <CoreFoundation/CoreFoundation.h>

NSUInteger const STSceneCodecKeyframeInterval = 20;
NSUInteger const STSceneCodecMaximumDependencyDepth = 19;

// Foundation's isEqual: treats JSON true and 1 as equal. They are distinct values
// in a scene field, including inside arrays/dictionaries, so compare recursively.
static BOOL STSceneJSONEqual(id left, id right) {
    if (left == right) return YES;
    if (!left || !right) return NO;
    if ([left isKindOfClass:NSNumber.class] && [right isKindOfClass:NSNumber.class]) {
        BOOL leftBoolean = CFGetTypeID((__bridge CFTypeRef)left) == CFBooleanGetTypeID();
        BOOL rightBoolean = CFGetTypeID((__bridge CFTypeRef)right) == CFBooleanGetTypeID();
        return leftBoolean == rightBoolean && [left isEqualToNumber:right];
    }
    if ([left isKindOfClass:NSArray.class] && [right isKindOfClass:NSArray.class]) {
        if ([left count] != [right count]) return NO;
        for (NSUInteger index = 0; index < [left count]; index++)
            if (!STSceneJSONEqual(left[index], right[index])) return NO;
        return YES;
    }
    if ([left isKindOfClass:NSDictionary.class] && [right isKindOfClass:NSDictionary.class]) {
        if ([left count] != [right count]) return NO;
        for (NSString *key in left)
            if (!STSceneJSONEqual(left[key], right[key])) return NO;
        return YES;
    }
    return [left isKindOfClass:NSString.class] && [right isKindOfClass:NSString.class] && [left isEqualToString:right];
}

static NSData *STSceneJSONData(id object) {
    if (![NSJSONSerialization isValidJSONObject:object]) return nil;
    return [NSJSONSerialization dataWithJSONObject:object options:NSJSONWritingSortedKeys error:NULL];
}

static NSDictionary<NSString *, NSDictionary *> *STSceneIndex(NSArray *nodes) {
    NSMutableDictionary *byID = [NSMutableDictionary dictionaryWithCapacity:nodes.count];
    for (id row in nodes) {
        if (![row isKindOfClass:NSDictionary.class]) return nil;
        id nodeID = row[@"nodeID"];
        if (![nodeID isKindOfClass:NSString.class] || ![nodeID length] || byID[nodeID]) return nil;
        byID[nodeID] = row;
    }
    return [byID copy];
}

@interface STSceneEncodingCandidate ()
@property (nonatomic, copy, readwrite) NSDictionary<NSString *, id> *fields;
@property (nonatomic, readwrite) NSUInteger fullPayloadBytes;
@property (nonatomic, readwrite) NSUInteger encodedPayloadBytes;
@property (nonatomic, readwrite) NSUInteger dependencyDepth;
@property (nonatomic, copy) NSArray *nodes;
@property (nonatomic, copy) NSDictionary<NSString *, NSDictionary *> *nodesByID;
@property (nonatomic, copy) NSString *contextID;
@property (nonatomic, copy) NSString *webViewID;
@property (nonatomic) NSUInteger sequence;
@property (nonatomic) NSUInteger revision;
@property (nonatomic, weak) STSceneCodec *owner;
@end

@implementation STSceneEncodingCandidate
@end

@interface STSceneCodec ()
@property (nonatomic, copy) NSArray *lastNodes;
@property (nonatomic, copy) NSDictionary<NSString *, NSDictionary *> *lastNodesByID;
@property (nonatomic, copy) NSString *contextID;
@property (nonatomic, copy) NSString *webViewID;
@property (nonatomic) NSUInteger lastMaterializedSequence;
@property (nonatomic) NSUInteger lastFullSequence;
@property (nonatomic) NSUInteger lastAcceptedSequence;
@property (nonatomic) NSUInteger materializedDepth;
@property (nonatomic) NSUInteger revision;
@end

@implementation STSceneCodec

- (void)reset {
    self.lastNodes = nil;
    self.lastNodesByID = nil;
    self.contextID = nil;
    self.webViewID = nil;
    self.lastMaterializedSequence = 0;
    self.lastFullSequence = 0;
    self.lastAcceptedSequence = 0;
    self.materializedDepth = 0;
    self.revision++;
}

- (STSceneEncodingCandidate *)prepareNodes:(NSArray *)nodes contextID:(NSString *)contextID
                               webViewID:(NSString *)webViewID sequence:(NSUInteger)sequence {
    if (![nodes isKindOfClass:NSArray.class] || !sequence || sequence <= self.lastAcceptedSequence) return nil;
    NSDictionary *full = @{@"sceneNodesEncoding": @"full", @"sceneNodes": nodes};
    NSData *fullData = STSceneJSONData(full);
    if (!fullData) return nil; // Invalid JSON cannot be represented by a full fallback either.
    NSDictionary *byID = STSceneIndex(nodes);
    BOOL scoped = [contextID isKindOfClass:NSString.class] && contextID.length &&
        [webViewID isKindOfClass:NSString.class] && webViewID.length;
    BOOL reusable = scoped && byID && self.lastNodesByID && self.lastMaterializedSequence &&
        [contextID isEqualToString:self.contextID] && [webViewID isEqualToString:self.webViewID];
    BOOL keyframeDue = !reusable || sequence - self.lastFullSequence >= STSceneCodecKeyframeInterval ||
        self.materializedDepth >= STSceneCodecMaximumDependencyDepth;
    NSDictionary *chosen = full;
    NSUInteger chosenBytes = fullData.length;
    NSUInteger depth = 0;
    if (!keyframeDue) {
        NSDictionary *compressed = nil;
        if (STSceneJSONEqual(nodes, self.lastNodes)) {
            compressed = @{@"sceneNodesEncoding": @"reference", @"sceneNodesRefSequence": @(self.lastMaterializedSequence)};
        } else {
            NSMutableArray *order = [NSMutableArray arrayWithCapacity:nodes.count];
            NSMutableArray *added = [NSMutableArray array];
            NSMutableArray *changed = [NSMutableArray array];
            for (NSDictionary *row in nodes) {
                NSString *nodeID = row[@"nodeID"];
                [order addObject:nodeID];
                NSDictionary *previous = self.lastNodesByID[nodeID];
                if (!previous) { [added addObject:row]; continue; }
                NSMutableDictionary *set = [NSMutableDictionary dictionary];
                NSMutableArray *unset = [NSMutableArray array];
                for (NSString *key in row) {
                    if ([key isEqualToString:@"nodeID"]) continue;
                    if (!STSceneJSONEqual(row[key], previous[key])) set[key] = row[key];
                }
                for (NSString *key in previous)
                    if (![key isEqualToString:@"nodeID"] && !row[key]) [unset addObject:key];
                if (set.count || unset.count) {
                    [unset sortUsingSelector:@selector(compare:)];
                    [changed addObject:@{@"nodeID": nodeID, @"set": [set copy], @"unset": [unset copy]}];
                }
            }
            compressed = @{@"sceneNodesEncoding": @"delta", @"sceneNodesRefSequence": @(self.lastMaterializedSequence),
                @"sceneNodesDelta": @{@"version": @1, @"order": [order copy], @"added": [added copy], @"changed": [changed copy]}};
        }
        NSData *compressedData = STSceneJSONData(compressed);
        // Unchanged scenes always use references (including an empty scene).
        // Deltas are selected only when their complete node encoding is smaller.
        if (compressedData && ([compressed[@"sceneNodesEncoding"] isEqualToString:@"reference"] || compressedData.length < fullData.length)) {
            chosen = compressed;
            chosenBytes = compressedData.length;
            depth = self.materializedDepth + 1;
        }
    }
    STSceneEncodingCandidate *candidate = [STSceneEncodingCandidate new];
    candidate.fields = chosen;
    candidate.fullPayloadBytes = fullData.length;
    candidate.encodedPayloadBytes = chosenBytes;
    candidate.dependencyDepth = depth;
    candidate.nodes = nodes;
    candidate.nodesByID = byID;
    candidate.contextID = scoped ? contextID : nil;
    candidate.webViewID = scoped ? webViewID : nil;
    candidate.sequence = sequence;
    candidate.revision = self.revision;
    candidate.owner = self;
    return candidate;
}

- (BOOL)commitCandidate:(STSceneEncodingCandidate *)candidate {
    if (!candidate || candidate.owner != self || candidate.revision != self.revision ||
        candidate.sequence <= self.lastAcceptedSequence) return NO;
    self.revision++;
    self.lastAcceptedSequence = candidate.sequence;
    NSString *encoding = candidate.fields[@"sceneNodesEncoding"];
    if ([encoding isEqualToString:@"reference"]) return YES;
    // A serializable but malformed/unscoped full scene is preserved in the JSON,
    // but is never used as a future reference target.
    self.lastNodes = candidate.contextID && candidate.nodesByID ? candidate.nodes : nil;
    self.lastNodesByID = candidate.contextID ? candidate.nodesByID : nil;
    self.contextID = candidate.contextID;
    self.webViewID = candidate.webViewID;
    self.lastMaterializedSequence = self.lastNodesByID ? candidate.sequence : 0;
    self.materializedDepth = candidate.dependencyDepth;
    if ([encoding isEqualToString:@"full"]) self.lastFullSequence = candidate.sequence;
    return YES;
}

@end

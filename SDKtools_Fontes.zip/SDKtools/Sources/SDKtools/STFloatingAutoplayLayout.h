#ifndef ST_FLOATING_AUTOPLAY_LAYOUT_H
#define ST_FLOATING_AUTOPLAY_LAYOUT_H
#include <stdbool.h>
#include <math.h>

typedef struct {
    double x, y, width, height;
    bool visible;
} STFloatingAutoplayLayout;

// Safe-area coordinates. Two 44-point controls have 6-point padding and gap.
// Try the inward side first, then the other side, below, and above the bubble.
// Never shrink touch targets or overlap the bubble when space is unavailable.
static inline STFloatingAutoplayLayout STFloatingAutoplayFit(
    double safeWidth, double safeHeight, double bubbleX, double bubbleY,
    double bubbleWidth, double bubbleHeight, bool preferLeft) {
    STFloatingAutoplayLayout hidden = {0, 0, 0, 0, false};
    const double width = 106, height = 56, gap = 6;
    if (!isfinite(safeWidth) || !isfinite(safeHeight) ||
        !isfinite(bubbleX) || !isfinite(bubbleY) ||
        !isfinite(bubbleWidth) || !isfinite(bubbleHeight) ||
        safeWidth < width || safeHeight < height ||
        bubbleWidth <= 0 || bubbleHeight <= 0 ||
        bubbleWidth > safeWidth || bubbleHeight > safeHeight ||
        bubbleX < 0 || bubbleY < 0 ||
        bubbleX > safeWidth - bubbleWidth || bubbleY > safeHeight - bubbleHeight)
        return hidden;

    double centerX = bubbleX + (bubbleWidth - width) / 2;
    double centerY = bubbleY + (bubbleHeight - height) / 2;
    if (centerX < 0) centerX = 0;
    if (centerX > safeWidth - width) centerX = safeWidth - width;
    if (centerY < 0) centerY = 0;
    if (centerY > safeHeight - height) centerY = safeHeight - height;
    const double left = bubbleX - gap - width, right = bubbleX + bubbleWidth + gap;
    const double xs[] = {preferLeft ? left : right, preferLeft ? right : left, centerX, centerX};
    const double ys[] = {centerY, centerY, bubbleY + bubbleHeight + gap, bubbleY - gap - height};
    for (unsigned i = 0; i < 4; i++) {
        double x = xs[i], y = ys[i];
        if (!isfinite(x) || !isfinite(y) || x < 0 || y < 0 ||
            x > safeWidth - width || y > safeHeight - height)
            continue;
        if (x < bubbleX + bubbleWidth && x + width > bubbleX &&
            y < bubbleY + bubbleHeight && y + height > bubbleY)
            continue;
        STFloatingAutoplayLayout result = {x, y, width, height, true};
        return result;
    }
    return hidden;
}
#endif

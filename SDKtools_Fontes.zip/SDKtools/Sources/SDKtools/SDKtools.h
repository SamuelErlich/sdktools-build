#import <Foundation/Foundation.h>

//! SDKtools is an in-process diagnostic overlay. It exposes no gameplay API.
//! The framework's bootstrap starts after the host application becomes active.

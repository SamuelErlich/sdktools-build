#import <Foundation/Foundation.h>

//! SDKtools provides bounded diagnostics and an explicit shortcut to the game's
//! original Retornar confirmation. The user confirms the action in the game.
//! The framework's bootstrap starts after the host application becomes active.

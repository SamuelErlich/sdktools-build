#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSNotificationName const STLanguageDidChangeNotification;
FOUNDATION_EXPORT NSString *STLanguageFromPreferences(NSArray<NSString *> *preferred, NSString * _Nullable saved);
FOUNDATION_EXPORT NSString *STCurrentLanguage(void);
/// Main-thread preference update. Never starts, stops or reloads a game module.
FOUNDATION_EXPORT BOOL STSetLanguage(NSString *language);
FOUNDATION_EXPORT NSString *STLocalizedText(NSString * _Nullable source);

/// Foundation-only catalog, independently testable with production resources.
/// Templates use matching ordered %@, signed/unsigned integer or %f arguments;
/// %% escapes a literal percent. Unsupported/mismatched formats reject the file.
@interface STLocalizationCatalog : NSObject
- (nullable instancetype)initWithData:(NSData *)data;
- (NSString *)text:(NSString *)source language:(NSString *)language;
@property(nonatomic,readonly) NSUInteger entryCount;
@end
NS_ASSUME_NONNULL_END

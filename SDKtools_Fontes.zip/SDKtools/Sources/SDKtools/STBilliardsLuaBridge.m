#import "STBilliardsLuaBridge.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <stdbool.h>
#import <stdint.h>
#import <string.h>

/* Contracts checked against the supplied 6.6.2/132 ARM64 UnityFramework.
 * APIs are resolved by exported name, with each address checked against the
 * owning image. No offsets from the static analysis are used at runtime.
 */
typedef struct STILDomain STILDomain;
typedef struct STILAssembly STILAssembly;
typedef struct STILImage STILImage;
typedef struct STILClass STILClass;
typedef struct STILType STILType;
typedef struct STILField STILField;
typedef struct STILObject STILObject;
typedef struct STILThread STILThread;
typedef struct STLuaState STLuaState;
typedef int (*STLuaCFunction)(STLuaState *);

typedef struct {
    STILDomain *(*domain_get)(void);
    const STILAssembly **(*domain_get_assemblies)(const STILDomain *, size_t *);
    const STILImage *(*assembly_get_image)(const STILAssembly *);
    const char *(*image_get_name)(const STILImage *);
    STILClass *(*class_from_name)(const STILImage *, const char *, const char *);
    STILClass *(*class_get_parent)(STILClass *);
    const char *(*class_get_name)(STILClass *);
    const char *(*class_get_namespace)(STILClass *);
    bool (*class_is_inited)(const STILClass *);
    STILField *(*class_get_field_from_name)(STILClass *, const char *);
    int (*field_get_flags)(STILField *);
    STILClass *(*field_get_parent)(STILField *);
    const STILType *(*field_get_type)(STILField *);
    STILClass *(*class_from_type)(const STILType *);
    void (*field_static_get_value)(STILField *, void *);
    void (*field_get_value)(STILObject *, STILField *, void *);
    STILClass *(*object_get_class)(STILObject *);
    STILThread *(*thread_current)(void);
    uint32_t (*gchandle_new)(STILObject *, bool);
    STILObject *(*gchandle_get_target)(uint32_t);
    void (*gchandle_free)(uint32_t);
    bool (*monitor_try_enter)(STILObject *, uint32_t);
    void (*monitor_exit)(STILObject *);
    const double *(*lua_version)(STLuaState *);
    int (*xlua_get_lib_version)(void);
    int (*lua_gettop)(STLuaState *);
    void (*lua_settop)(STLuaState *, int);
    int (*lua_checkstack)(STLuaState *, int);
    int (*lua_status)(STLuaState *);
    void (*lua_pushcclosure)(STLuaState *, STLuaCFunction, int);
    const char *(*lua_pushlstring)(STLuaState *, const char *, size_t);
    int (*luaL_loadbufferx)(STLuaState *, const char *, size_t, const char *, const char *);
    int (*lua_pcall)(STLuaState *, int, int, int);
    int (*lua_type)(STLuaState *, int);
    const char *(*lua_tolstring)(STLuaState *, int, size_t *);
} STBilliardsLuaAPI;

typedef NS_ENUM(NSInteger, STBilliardsLuaFailure) {
    STLuaOK = 0,
    STLuaUnsupportedCommand = 1,
    STLuaWrongThread,
    STLuaBusy,
    STLuaUnsupportedHost,
    STLuaUnityUnavailable,
    STLuaUnsupportedBinary,
    STLuaAPIUnavailable,
    STLuaUnsupportedABI,
    STLuaRuntimeNotReady,
    STLuaMetadataMismatch,
    STLuaManagerUnavailable,
    STLuaEnvironmentUnavailable,
    STLuaEnvironmentBusy,
    STLuaEnvironmentDisposed,
    STLuaScriptUnavailable,
    STLuaStackUnavailable,
    STLuaCompileFailed,
    STLuaExecutionFailed,
    STLuaUnexpectedResult,
    STLuaResultTooLarge,
    STLuaInvalidJSON
};

static const NSUInteger STLuaScriptLimit = 128u * 1024u;
static const NSUInteger STLuaResultLimit = 256u * 1024u;
static const uint8_t STUnityUUID[16] = {
    0x26,0xe4,0x9e,0x81,0x50,0xe8,0x39,0x6b,
    0xa9,0xf2,0xb3,0xbf,0x24,0x3a,0x46,0x4b
};

/* Main-thread-only, synchronous execution; the guard prevents a nested UI or
 * gameplay callback from replacing the context while a protected call is live.
 */
static BOOL STLuaBridgeBusy = NO;
typedef struct {
    const STBilliardsLuaAPI *api;
    const char *script;
    size_t scriptLength;
    const char *command;
    size_t commandLength;
    STBilliardsLuaFailure failure;
} STBilliardsLuaExecution;
static STBilliardsLuaExecution *STLuaCurrentExecution = NULL;

static int STLuaProtectedExecute(STLuaState *state) {
    STBilliardsLuaExecution *execution = STLuaCurrentExecution;
    if (!execution) return 0;
    const STBilliardsLuaAPI *api = execution->api;
    /* Both compilation and argument allocation occur inside the outer pcall.
     * Lua errors therefore cannot jump past the native monitor/handle cleanup.
     * The nested pcall contains errors produced by the observer itself.
     */
    if (api->luaL_loadbufferx(state, execution->script, execution->scriptLength,
                             "@SDKtools/billiards_probe.lua", "t") != 0) {
        execution->failure = STLuaCompileFailed;
        return 0;
    }
    api->lua_pushlstring(state, execution->command, execution->commandLength);
    if (api->lua_pcall(state, 1, 1, 0) != 0) {
        execution->failure = STLuaExecutionFailed;
        return 0;
    }
    return 1;
}

static NSError *STLuaError(STBilliardsLuaFailure code) {
    NSString *message;
    switch (code) {
        case STLuaUnsupportedCommand: message = @"Comando do bilhar inválido."; break;
        case STLuaWrongThread: message = @"A leitura do bilhar precisa ocorrer na thread principal."; break;
        case STLuaBusy: message = @"Uma leitura do bilhar já está em andamento."; break;
        case STLuaUnsupportedHost: message = @"Esta leitura exige WePlay US 6.6.2, build 132."; break;
        case STLuaUnityUnavailable: message = @"Abra o bilhar para carregar a Unity."; break;
        case STLuaUnsupportedBinary: message = @"A versão da Unity não corresponde à base verificada."; break;
        case STLuaAPIUnavailable: message = @"A ponte Unity/Lua necessária não está disponível."; break;
        case STLuaUnsupportedABI: message = @"A versão Lua/XLua não corresponde à base verificada."; break;
        case STLuaRuntimeNotReady: message = @"A Unity ainda não está pronta para leitura."; break;
        case STLuaMetadataMismatch: message = @"O contrato do estado Lua não corresponde à base verificada."; break;
        case STLuaManagerUnavailable: message = @"O gerenciador Lua ainda não foi criado pelo jogo."; break;
        case STLuaEnvironmentUnavailable: message = @"O ambiente Lua do jogo ainda não está disponível."; break;
        case STLuaEnvironmentBusy: message = @"O ambiente Lua está ocupado. Tente novamente."; break;
        case STLuaEnvironmentDisposed: message = @"A partida encerrou ou está trocando o ambiente Lua."; break;
        case STLuaScriptUnavailable: message = @"O leitor de bilhar não foi encontrado no framework."; break;
        case STLuaStackUnavailable: message = @"O estado Lua não está pronto para esta leitura."; break;
        case STLuaCompileFailed: message = @"Não foi possível preparar o leitor de bilhar."; break;
        case STLuaExecutionFailed: message = @"O leitor de bilhar retornou um erro de execução."; break;
        case STLuaUnexpectedResult: message = @"O leitor de bilhar retornou um formato inesperado."; break;
        case STLuaResultTooLarge: message = @"O resultado da leitura excedeu o limite permitido."; break;
        case STLuaInvalidJSON: message = @"O resultado do leitor de bilhar não é um objeto JSON válido."; break;
        default: message = @"Não foi possível ler o bilhar."; break;
    }
    /* Never expose Lua exception text: it may contain game/session data. */
    return [NSError errorWithDomain:@"SDKtools.BilliardsLua" code:code
                          userInfo:@{NSLocalizedDescriptionKey: message}];
}

static BOOL STLuaTextEquals(const char *a, const char *b) {
    return a && b && strcmp(a, b) == 0;
}

static BOOL STLuaClassMatches(const STBilliardsLuaAPI *api, STILClass *klass,
                             const char *namespaze, const char *name) {
    return klass && STLuaTextEquals(api->class_get_name(klass), name) &&
           STLuaTextEquals(api->class_get_namespace(klass), namespaze);
}

static STILField *STLuaCheckedField(const STBilliardsLuaAPI *api,
                                  STILClass *declaringClass, const char *name,
                                  BOOL isStatic, const char *typeNamespace,
                                  const char *typeName) {
    STILField *field = api->class_get_field_from_name(declaringClass, name);
    if (!field || api->field_get_parent(field) != declaringClass) return NULL;
    const int flags = api->field_get_flags(field);
    if (((flags & 0x10) != 0) != isStatic || (flags & 0x40)) return NULL;
    const STILType *type = api->field_get_type(field);
    STILClass *fieldClass = type ? api->class_from_type(type) : NULL;
    return STLuaClassMatches(api, fieldClass, typeNamespace, typeName) ? field : NULL;
}

static BOOL STLuaImageHasExpectedUUID(const struct mach_header *header) {
    if (!header || header->magic != MH_MAGIC_64 || header->cputype != CPU_TYPE_ARM64) return NO;
    const struct mach_header_64 *h = (const struct mach_header_64 *)header;
    if (h->ncmds > 4096 || h->sizeofcmds > 1024u * 1024u) return NO;
    const uint8_t *cursor = (const uint8_t *)(h + 1);
    const uint8_t *end = cursor + h->sizeofcmds;
    BOOL found = NO;
    for (uint32_t i = 0; i < h->ncmds; ++i) {
        if ((size_t)(end - cursor) < sizeof(struct load_command)) return NO;
        const struct load_command *command = (const struct load_command *)cursor;
        if (command->cmdsize < sizeof(*command) || command->cmdsize > (size_t)(end - cursor)) return NO;
        if (command->cmd == LC_UUID) {
            if (found || command->cmdsize != sizeof(struct uuid_command)) return NO;
            if (memcmp(((const struct uuid_command *)command)->uuid, STUnityUUID, sizeof(STUnityUUID)) != 0) return NO;
            found = YES;
        }
        cursor += command->cmdsize;
    }
    return found && cursor == end;
}

static void *STLuaOwnedSymbol(void *handle, const struct mach_header *owner, const char *name) {
    void *symbol = dlsym(handle, name);
    Dl_info info;
    memset(&info, 0, sizeof(info));
    if (!symbol || !dladdr(symbol, &info) || info.dli_fbase != (const void *)owner) return NULL;
    return symbol;
}

static BOOL STLuaResolveAPI(void *handle, const struct mach_header *owner, STBilliardsLuaAPI *api) {
    memset(api, 0, sizeof(*api));
#define ST_RESOLVE(member, symbolName) \
    do { void *symbol = STLuaOwnedSymbol(handle, owner, symbolName); \
         if (!symbol) return NO; \
         _Static_assert(sizeof(api->member) == sizeof(symbol), "Function pointer ABI mismatch"); \
         memcpy(&api->member, &symbol, sizeof(symbol)); } while (0)
#define ST_IL(member) ST_RESOLVE(member, "il2cpp_" #member)
    ST_IL(domain_get); ST_IL(domain_get_assemblies); ST_IL(assembly_get_image);
    ST_IL(image_get_name); ST_IL(class_from_name); ST_IL(class_get_parent);
    ST_IL(class_get_name); ST_IL(class_get_namespace); ST_IL(class_is_inited);
    ST_IL(class_get_field_from_name); ST_IL(field_get_flags); ST_IL(field_get_parent);
    ST_IL(field_get_type); ST_IL(class_from_type); ST_IL(field_static_get_value);
    ST_IL(field_get_value); ST_IL(object_get_class); ST_IL(thread_current);
    ST_IL(gchandle_new); ST_IL(gchandle_get_target); ST_IL(gchandle_free);
    ST_IL(monitor_try_enter); ST_IL(monitor_exit);
    ST_RESOLVE(lua_version, "lua_version");
    ST_RESOLVE(xlua_get_lib_version, "xlua_get_lib_version");
    ST_RESOLVE(lua_gettop, "lua_gettop"); ST_RESOLVE(lua_settop, "lua_settop");
    ST_RESOLVE(lua_checkstack, "lua_checkstack"); ST_RESOLVE(lua_status, "lua_status");
    ST_RESOLVE(lua_pushcclosure, "lua_pushcclosure"); ST_RESOLVE(lua_pushlstring, "lua_pushlstring");
    ST_RESOLVE(luaL_loadbufferx, "luaL_loadbufferx"); ST_RESOLVE(lua_pcall, "lua_pcall");
    ST_RESOLVE(lua_type, "lua_type"); ST_RESOLVE(lua_tolstring, "lua_tolstring");
#undef ST_IL
#undef ST_RESOLVE
    return YES;
}

@implementation STBilliardsLuaBridge
+ (NSDictionary *)executeCommand:(NSString *)command error:(NSError **)error {
    if (error) *error = nil;
    if (![command isEqualToString:@"sample"] && ![command isEqualToString:@"stop"] &&
        ![command isEqualToString:@"aim"] && ![command isEqualToString:@"autoplay"]) {
        if (error) *error = STLuaError(STLuaUnsupportedCommand);
        return nil;
    }
    if (!NSThread.isMainThread) {
        if (error) *error = STLuaError(STLuaWrongThread);
        return nil;
    }
    if (STLuaBridgeBusy) {
        if (error) *error = STLuaError(STLuaBusy);
        return nil;
    }
    NSBundle *host = NSBundle.mainBundle;
    if (![host.bundleIdentifier isEqualToString:@"com.wejoy.weplay.us"] ||
        ![[host objectForInfoDictionaryKey:@"CFBundleShortVersionString"] isEqual:@"6.6.2"] ||
        ![[host objectForInfoDictionaryKey:@"CFBundleVersion"] isEqual:@"132"]) {
        if (error) *error = STLuaError(STLuaUnsupportedHost);
        return nil;
    }
    STLuaBridgeBusy = YES;
    STBilliardsLuaFailure failure = STLuaOK;
    STBilliardsLuaAPI api = {0};
    void *handle = NULL;
    uint32_t managerHandle = 0, envHandle = 0, lockHandle = 0;
    STILObject *lockObject = NULL;
    STLuaState *state = NULL;
    BOOL lockTaken = NO, stackSaved = NO;
    int savedTop = 0;
    NSData *output = nil;

    do {
        NSBundle *bundle = [NSBundle bundleForClass:self];
        NSURL *scriptURL = [bundle URLForResource:@"billiards_probe" withExtension:@"lua"];
        if (!scriptURL) scriptURL = [bundle URLForResource:@"billiards_probe" withExtension:@"lua" subdirectory:@"Resources"];
        NSNumber *scriptSize = nil;
        if (!scriptURL || ![scriptURL getResourceValue:&scriptSize forKey:NSURLFileSizeKey error:NULL] ||
            scriptSize.unsignedLongLongValue == 0 || scriptSize.unsignedLongLongValue > STLuaScriptLimit) {
            failure = STLuaScriptUnavailable; break;
        }
        NSData *script = [NSData dataWithContentsOfURL:scriptURL options:0 error:NULL];
        if (!script.length || script.length > STLuaScriptLimit) { failure = STLuaScriptUnavailable; break; }
        if ([command isEqualToString:@"aim"] || [command isEqualToString:@"autoplay"]) {
            NSURL *strategyURL=[bundle URLForResource:@"billiards_strategy" withExtension:@"lua"];
            if (!strategyURL) strategyURL=[bundle URLForResource:@"billiards_strategy" withExtension:@"lua" subdirectory:@"Resources"];
            NSNumber *size=nil;
            if (!strategyURL || ![strategyURL getResourceValue:&size forKey:NSURLFileSizeKey error:NULL] ||
                size.unsignedLongLongValue==0 || size.unsignedLongLongValue>32768) { failure=STLuaScriptUnavailable; break; }
            NSData *strategy=[NSData dataWithContentsOfURL:strategyURL options:0 error:NULL];
            if (!strategy.length || strategy.length>32768) { failure=STLuaScriptUnavailable; break; }
            NSMutableData *combined=[NSMutableData data];
            [combined appendData:[@"local SDK321Planner=(function()\n" dataUsingEncoding:NSUTF8StringEncoding]];
            [combined appendData:strategy];
            [combined appendData:[@"\nend)()\n" dataUsingEncoding:NSUTF8StringEncoding]];
            [combined appendData:script];
            if (combined.length>STLuaScriptLimit) { failure=STLuaScriptUnavailable; break; }
            script=combined;
        }
        const struct mach_header *unityHeader = NULL;
        const char *unityPath = NULL;
        for (uint32_t i = 0, count = _dyld_image_count(); i < count; ++i) {
            const char *path = _dyld_get_image_name(i);
            if (!path) continue;
            const char *leaf = strrchr(path, '/');
            if (!leaf || strcmp(leaf + 1, "UnityFramework") != 0) continue;
            if (unityHeader) { failure = STLuaUnsupportedBinary; break; }
            unityHeader = _dyld_get_image_header(i); unityPath = path;
        }
        if (failure) break;
        if (!unityHeader || !unityPath) { failure = STLuaUnityUnavailable; break; }
        if (!STLuaImageHasExpectedUUID(unityHeader)) { failure = STLuaUnsupportedBinary; break; }
        handle = dlopen(unityPath, RTLD_LAZY | RTLD_NOLOAD);
        if (!handle || !STLuaResolveAPI(handle, unityHeader, &api)) { failure = STLuaAPIUnavailable; break; }
        const double *luaVersion = api.lua_version(NULL);
        if (!luaVersion || *luaVersion != 503.0 || api.xlua_get_lib_version() != 105) { failure = STLuaUnsupportedABI; break; }
        STILDomain *domain = api.domain_get();
        if (!domain || !api.thread_current()) { failure = STLuaRuntimeNotReady; break; }
        size_t assemblyCount = 0;
        const STILAssembly **assemblies = api.domain_get_assemblies(domain, &assemblyCount);
        if (!assemblies || assemblyCount == 0 || assemblyCount > 4096) { failure = STLuaRuntimeNotReady; break; }
        const STILImage *mainImage = NULL;
        for (size_t i = 0; i < assemblyCount; ++i) {
            const STILImage *image = assemblies[i] ? api.assembly_get_image(assemblies[i]) : NULL;
            if (image && STLuaTextEquals(api.image_get_name(image), "Main.dll")) {
                if (mainImage) { failure = STLuaMetadataMismatch; break; }
                mainImage = image;
            }
        }
        if (failure) break;
        if (!mainImage) { failure = STLuaRuntimeNotReady; break; }
        STILClass *managerClass = api.class_from_name(mainImage, "", "LuaManager");
        STILClass *envClass = api.class_from_name(mainImage, "XLua", "LuaEnv");
        if (!managerClass || !envClass || !api.class_is_inited(managerClass) || !api.class_is_inited(envClass)) {
            failure = STLuaRuntimeNotReady; break;
        }
        STILClass *parent = api.class_get_parent(managerClass);
        if (!STLuaClassMatches(&api, parent, "", "MonoSingleton`1") || !api.class_is_inited(parent)) {
            failure = STLuaMetadataMismatch; break;
        }
        STILField *instanceField = STLuaCheckedField(&api, parent, "_instance", YES, "", "LuaManager");
        STILField *envField = STLuaCheckedField(&api, managerClass, "m_luaEnv", NO, "XLua", "LuaEnv");
        STILField *readyField = STLuaCheckedField(&api, managerClass, "_ready", NO, "System", "Boolean");
        STILField *lockField = STLuaCheckedField(&api, envClass, "luaLock", NO, "System", "Object");
        STILField *disposedField = STLuaCheckedField(&api, envClass, "disposed", NO, "System", "Boolean");
        STILField *rawField = STLuaCheckedField(&api, envClass, "rawL", NO, "System", "IntPtr");
        if (!instanceField || !envField || !readyField || !lockField || !disposedField || !rawField) {
            failure = STLuaMetadataMismatch; break;
        }
        /* Validate the inflated generic argument, not merely its class name. */
        if (api.class_from_type(api.field_get_type(instanceField)) != managerClass ||
            api.class_from_type(api.field_get_type(envField)) != envClass) {
            failure = STLuaMetadataMismatch; break;
        }
        STILObject *manager = NULL;
        api.field_static_get_value(instanceField, &manager);
        if (!manager || api.object_get_class(manager) != managerClass) { failure = STLuaManagerUnavailable; break; }
        managerHandle = api.gchandle_new(manager, false);
        if (!managerHandle) { failure = STLuaManagerUnavailable; break; }
        manager = api.gchandle_get_target(managerHandle);
        if (!manager) { failure = STLuaManagerUnavailable; break; }
        STILObject *env = NULL;
        uint8_t ready = 0;
        api.field_get_value(manager, readyField, &ready);
        api.field_get_value(manager, envField, &env);
        if (!ready || !env || api.object_get_class(env) != envClass) { failure = STLuaEnvironmentUnavailable; break; }
        envHandle = api.gchandle_new(env, false);
        if (!envHandle) { failure = STLuaEnvironmentUnavailable; break; }
        env = api.gchandle_get_target(envHandle);
        if (!env) { failure = STLuaEnvironmentUnavailable; break; }
        api.field_get_value(env, lockField, &lockObject);
        if (!lockObject || !STLuaClassMatches(&api, api.object_get_class(lockObject), "System", "Object")) {
            failure = STLuaMetadataMismatch; break;
        }
        lockHandle = api.gchandle_new(lockObject, false);
        if (!lockHandle || !(lockObject = api.gchandle_get_target(lockHandle))) { failure = STLuaEnvironmentUnavailable; break; }
        lockTaken = api.monitor_try_enter(lockObject, 0);
        if (!lockTaken) { failure = STLuaEnvironmentBusy; break; }
        manager = api.gchandle_get_target(managerHandle);
        env = api.gchandle_get_target(envHandle);
        if (!manager || !env) { failure = STLuaEnvironmentDisposed; break; }
        STILObject *currentEnv = NULL, *currentLock = NULL;
        uint8_t disposed = 1;
        ready = 0;
        api.field_get_value(manager, envField, &currentEnv);
        api.field_get_value(manager, readyField, &ready);
        api.field_get_value(env, lockField, &currentLock);
        api.field_get_value(env, disposedField, &disposed);
        api.field_get_value(env, rawField, &state);
        if (!ready || currentEnv != env || currentLock != lockObject || disposed || !state) {
            failure = STLuaEnvironmentDisposed; break;
        }
        if (api.lua_status(state) != 0) { failure = STLuaStackUnavailable; break; }
        savedTop = api.lua_gettop(state);
        if (savedTop < 0 || savedTop > 65536) { failure = STLuaStackUnavailable; break; }
        stackSaved = YES;
        if (!api.lua_checkstack(state, 8)) { failure = STLuaStackUnavailable; break; }
        STBilliardsLuaExecution execution = {
            .api = &api, .script = script.bytes, .scriptLength = script.length,
            .command = command.UTF8String,
            .commandLength = [command lengthOfBytesUsingEncoding:NSUTF8StringEncoding],
            .failure = STLuaOK
        };
        STLuaCurrentExecution = &execution;
        /* Lua 5.3's zero-upvalue C function push does not allocate a closure.
         * Stack capacity was obtained with lua_checkstack's protected growth.
         */
        api.lua_pushcclosure(state, STLuaProtectedExecute, 0);
        const int status = api.lua_pcall(state, 0, 1, 0);
        STLuaCurrentExecution = NULL;
        if (status != 0) { failure = STLuaExecutionFailed; break; }
        if (execution.failure != STLuaOK) { failure = execution.failure; break; }
        if (api.lua_gettop(state) != savedTop + 1 || api.lua_type(state, -1) != 4) {
            failure = STLuaUnexpectedResult; break;
        }
        size_t outputLength = 0;
        const char *outputBytes = api.lua_tolstring(state, -1, &outputLength);
        if (!outputBytes || outputLength == 0) { failure = STLuaUnexpectedResult; break; }
        if (outputLength > STLuaResultLimit) { failure = STLuaResultTooLarge; break; }
        output = [NSData dataWithBytes:outputBytes length:outputLength];
    } while (NO);

    STLuaCurrentExecution = NULL;
    if (stackSaved) api.lua_settop(state, savedTop);
    if (lockTaken) api.monitor_exit(lockObject);
    if (lockHandle) api.gchandle_free(lockHandle);
    if (envHandle) api.gchandle_free(envHandle);
    if (managerHandle) api.gchandle_free(managerHandle);
    if (handle) dlclose(handle);
    STLuaBridgeBusy = NO;
    if (failure != STLuaOK) {
        if (error) *error = STLuaError(failure);
        return nil;
    }
    id result = output ? [NSJSONSerialization JSONObjectWithData:output options:0 error:NULL] : nil;
    if (![result isKindOfClass:NSDictionary.class]) {
        if (error) *error = STLuaError(STLuaInvalidJSON);
        return nil;
    }
    return result;
}
@end

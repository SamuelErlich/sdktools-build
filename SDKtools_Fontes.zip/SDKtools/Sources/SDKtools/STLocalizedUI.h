#import <UIKit/UIKit.h>
#import "STLocalization.h"
/// Bind the original source text on the main thread. Changing language updates
/// surviving views in place; the bindings never restart or call game modules.
void STLocalizeLabel(UILabel *label, NSString *source);
void STLocalizeButton(UIButton *button, NSString *source);
void STLocalizeAccessibilityLabel(UIView *view, NSString *source);
void STLocalizeAccessibilityHint(UIView *view, NSString *source);
void STLocalizeAccessibilityValue(UIView *view, NSString *source);

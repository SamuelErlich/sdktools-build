#import "STClientContext.h"

BOOL STClientHostViewAllowsActions(UIView *view) {
    if (!NSThread.isMainThread || !view.window || CGRectIsEmpty(view.bounds)) return NO;
    // A game can itself be presented. Only a controller above its host blocks it.
    UIViewController *top=view.window.rootViewController;
    for (NSUInteger depth=0;top;depth++) {
        if (depth>=16 || top.isBeingDismissed || top.isBeingPresented || top.transitionCoordinator) return NO;
        if (!top.presentedViewController) break;
        top=top.presentedViewController;
    }
    if (!top || !top.isViewLoaded || (top.view!=view && ![view isDescendantOfView:top.view])) return NO;
    UIView *ancestor=view;
    for (NSUInteger depth=0;ancestor;depth++,ancestor=ancestor.superview) {
        if (depth>=64 || ancestor.hidden || ancestor.alpha<0.01 || CGRectIsEmpty(ancestor.bounds)) return NO;
        if (ancestor==view.window) break;
    }
    if (ancestor!=view.window) return NO;
    UIResponder *responder=view;
    for (NSUInteger depth=0;responder;depth++,responder=responder.nextResponder) {
        if (depth>=64) return NO;
        if ([responder isKindOfClass:UIViewController.class]) {
            UIViewController *controller=(UIViewController *)responder;
            if (controller.isBeingDismissed || controller.isBeingPresented || controller.transitionCoordinator) return NO;
        }
        if (responder==view.window) break;
    }
    CGPoint center=[view convertPoint:CGPointMake(CGRectGetMidX(view.bounds),CGRectGetMidY(view.bounds)) toView:view.window];
    UIView *hit=[view.window hitTest:center withEvent:nil];
    return hit==view || [hit isDescendantOfView:view];
}

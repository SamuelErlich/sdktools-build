#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
UIColor *STBrandColor(uint32_t rgb);
UIFont *STBrandFont(NSString *name, CGFloat size, UIFontTextStyle style);
UIImage * _Nullable STBrandImage(NSString *name, BOOL templateImage);
void STRegisterBrandFonts(void);
NS_ASSUME_NONNULL_END

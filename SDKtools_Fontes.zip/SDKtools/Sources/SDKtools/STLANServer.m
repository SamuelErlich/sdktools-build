#import "STLANServer.h"
#import <Security/Security.h>
#include "STLANProtocol.inc"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <sys/socket.h>
#include <unistd.h>
#include <dispatch/dispatch.h>
#include <stdlib.h>
#include <string.h>

static NSTimeInterval STLANTime(void){return NSProcessInfo.processInfo.systemUptime;}
static BOOL STLANPrivateAddress(NSString *ip){struct in_addr a;if(inet_pton(AF_INET,ip.UTF8String,&a)!=1)return NO;
    uint32_t n=ntohl(a.s_addr);return (n>>24)==10||(n>>20)==0xac1||(n>>16)==0xc0a8||(n>>16)==0xa9fe;}
static NSString *STLANWiFiAddress(void){struct ifaddrs *all=NULL;NSString *ip=nil;if(getifaddrs(&all)!=0)return nil;
    for(struct ifaddrs *p=all;p;p=p->ifa_next){if(!p->ifa_addr||p->ifa_addr->sa_family!=AF_INET||strcmp(p->ifa_name,"en0")||!(p->ifa_flags&IFF_UP)||p->ifa_flags&IFF_LOOPBACK)continue;
        char text[INET_ADDRSTRLEN];if(inet_ntop(AF_INET,&((struct sockaddr_in *)p->ifa_addr)->sin_addr,text,sizeof(text))){NSString *s=@(text);if(STLANPrivateAddress(s)){ip=s;break;}}}
    freeifaddrs(all);return ip;}
static NSString *STLANSecret(void){unsigned char bytes[32];if(SecRandomCopyBytes(kSecRandomDefault,sizeof(bytes),bytes)!=errSecSuccess)return nil;
    NSMutableString *s=[NSMutableString stringWithCapacity:64];for(NSUInteger i=0;i<sizeof(bytes);i++)[s appendFormat:@"%02x",bytes[i]];return s;}

@interface STLANPeer : NSObject
@property int fd;
@property (atomic) BOOL alive;
@property BOOL suspended;
@property BOOL handled;
@property NSTimeInterval deadline;
@property (nonatomic,copy) NSString *address;
@property (nonatomic,strong) NSMutableData *input;
@property (nonatomic,strong) NSData *output;
@property NSUInteger offset;
@property (nonatomic,strong) dispatch_source_t reader;
@property (nonatomic,strong) dispatch_source_t writer;
@end
@implementation STLANPeer @end

@interface STLANServer ()
@property (atomic,readwrite) BOOL active;
@property (atomic,readwrite) BOOL paired;
@property (atomic,copy,readwrite) NSString *URLString;
@property (atomic,copy,readwrite) NSString *pairingCode;
@property (atomic) NSUInteger generation;
@property (nonatomic,strong) dispatch_queue_t queue;
@property (nonatomic,strong) dispatch_source_t listener;
@property (nonatomic,strong) dispatch_source_t watchdog;
@property (nonatomic,strong) NSMutableSet<STLANPeer *> *peers;
@property (nonatomic,copy) NSDictionary *(^stateProvider)(void);
@property (nonatomic,copy) NSDictionary *(^commandHandler)(NSDictionary *);
@property (nonatomic,copy) void (^stopHandler)(void);
@property (nonatomic,copy) NSDictionary<NSString *,NSData *> *assets;
@property (nonatomic,copy) NSString *authority;
@property (nonatomic,copy) NSString *secret;
@property (nonatomic,copy) NSString *controllerAddress;
@property NSUInteger sequence;
@property NSUInteger pairAttempts;
@property NSUInteger windowRequests;
@property NSTimeInterval windowStarted;
@property NSTimeInterval started;
@property NSTimeInterval lastSeen;
- (BOOL)startAtAddress:(NSString *)ip assets:(NSDictionary *)assets secret:(NSString *)secret state:(NSDictionary *(^)(void))state command:(NSDictionary *(^)(NSDictionary *))command stopped:(void (^)(void))stopped error:(NSError **)error;
- (void)acceptOn:(int)fd generation:(NSUInteger)generation;
- (void)closePeer:(STLANPeer *)peer;
- (void)readPeer:(STLANPeer *)peer generation:(NSUInteger)generation;
- (void)writePeer:(STLANPeer *)peer;
- (void)json:(NSDictionary *)value status:(NSUInteger)status peer:(STLANPeer *)peer;
- (void)reply:(NSData *)body mime:(NSString *)mime status:(NSUInteger)status peer:(STLANPeer *)peer;
@end

@implementation STLANServer
- (instancetype)init{if((self=[super init])){_queue=dispatch_queue_create("SDKtools.LAN",DISPATCH_QUEUE_SERIAL);_peers=[NSMutableSet set];_URLString=@"";_pairingCode=@"";}return self;}
- (BOOL)startWithState:(NSDictionary *(^)(void))state command:(NSDictionary *(^)(NSDictionary *))command stopped:(void (^)(void))stopped error:(NSError **)error {
    NSAssert(NSThread.isMainThread,@"Main thread");if(self.active)return YES;
    NSString *ip=STLANWiFiAddress(),*secret=STLANSecret();NSMutableDictionary *assets=[NSMutableDictionary dictionary];
    NSBundle *bundle=[NSBundle bundleForClass:self.class];
    for(NSString *name in @[@"panel.html",@"panel.js",@"panel.css"]){NSString *file=[bundle pathForResource:name ofType:nil inDirectory:@"LAN"];
        NSData *data=file?[NSData dataWithContentsOfFile:file]:nil;if(!data.length||data.length>65536)break;
        assets[[name isEqual:@"panel.html"]?@"/":[@"/" stringByAppendingString:name]]=data;}
    if(!ip||!secret||assets.count!=3||!state||!command){if(error)*error=[NSError errorWithDomain:@"SDKtools.LAN" code:1 userInfo:@{NSLocalizedDescriptionKey:@"Wi-Fi IPv4 privado ou painel indisponível."}];return NO;}
    return [self startAtAddress:ip assets:assets secret:secret state:state command:command stopped:stopped error:error];
}
// Separate deterministic seam for the Foundation socket test; no external calls.
- (BOOL)startAtAddress:(NSString *)ip assets:(NSDictionary *)assets secret:(NSString *)secret state:(NSDictionary *(^)(void))state command:(NSDictionary *(^)(NSDictionary *))command stopped:(void (^)(void))stopped error:(NSError **)error {
    NSAssert(NSThread.isMainThread,@"Main thread");if(self.active)return NO;
    __block int fd=-1;__block uint16_t port=0;
    dispatch_sync(self.queue,^{fd=socket(AF_INET,SOCK_STREAM,0);if(fd<0)return;
        int yes=1;setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));setsockopt(fd,SOL_SOCKET,SO_NOSIGPIPE,&yes,sizeof(yes));
        struct sockaddr_in a={0};a.sin_len=sizeof(a);a.sin_family=AF_INET;a.sin_port=0;
        if(inet_pton(AF_INET,ip.UTF8String,&a.sin_addr)!=1||bind(fd,(struct sockaddr *)&a,sizeof(a))||listen(fd,8)||fcntl(fd,F_SETFL,O_NONBLOCK)){close(fd);fd=-1;return;}
        socklen_t length=sizeof(a);if(getsockname(fd,(struct sockaddr *)&a,&length)){close(fd);fd=-1;return;}port=ntohs(a.sin_port);
    });
    if(fd<0){if(error)*error=[NSError errorWithDomain:@"SDKtools.LAN" code:2 userInfo:@{NSLocalizedDescriptionKey:@"Não foi possível abrir a porta LAN."}];return NO;}
    self.generation++;NSUInteger generation=self.generation;self.stateProvider=state;self.commandHandler=command;self.stopHandler=stopped;
    self.authority=[NSString stringWithFormat:@"%@:%u",ip,port];self.URLString=[@"http://" stringByAppendingString:self.authority];
    self.pairingCode=[NSString stringWithFormat:@"%08u",arc4random_uniform(100000000)];self.paired=NO;self.active=YES;
    __weak STLANServer *weakSelf=self;
    dispatch_sync(self.queue,^{self.secret=secret;self.assets=assets;self.sequence=0;self.pairAttempts=0;self.controllerAddress=nil;self.started=STLANTime();self.lastSeen=self.started;self.windowStarted=self.started;self.windowRequests=0;
        self.listener=dispatch_source_create(DISPATCH_SOURCE_TYPE_READ,fd,0,self.queue);
        dispatch_source_set_event_handler(self.listener,^{[weakSelf acceptOn:fd generation:generation];});
        dispatch_source_set_cancel_handler(self.listener,^{close(fd);});dispatch_resume(self.listener);
        self.watchdog=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,self.queue);
        dispatch_source_set_timer(self.watchdog,dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),NSEC_PER_SEC,NSEC_PER_SEC/10);
        dispatch_source_set_event_handler(self.watchdog,^{STLANServer *s=weakSelf;if(!s||s.generation!=generation)return;
            NSTimeInterval now=STLANTime();for(STLANPeer *p in [s.peers copy])if(now>p.deadline)[s closePeer:p];
            if(now-(s.paired?s.lastSeen:s.started)>(s.paired?8:120))dispatch_async(dispatch_get_main_queue(),^{if(s.generation==generation)[s stop];});
        });dispatch_resume(self.watchdog);
    });return YES;
}
- (void)stop {NSAssert(NSThread.isMainThread,@"Main thread");if(!self.active)return;
    self.active=NO;self.paired=NO;self.generation++;self.URLString=@"";self.pairingCode=@"";
    void (^callback)(void)=self.stopHandler;self.stopHandler=nil;self.stateProvider=nil;self.commandHandler=nil;
    dispatch_async(self.queue,^{if(self.listener){dispatch_source_cancel(self.listener);self.listener=nil;}if(self.watchdog){dispatch_source_cancel(self.watchdog);self.watchdog=nil;}
        for(STLANPeer *p in [self.peers copy])[self closePeer:p];self.secret=nil;self.controllerAddress=nil;self.assets=nil;});
    if(callback)callback();
}
- (void)closePeer:(STLANPeer *)p {if(!p.alive)return;p.alive=NO;
    if(p.writer){dispatch_source_cancel(p.writer);p.writer=nil;}
    if(p.suspended){p.suspended=NO;dispatch_resume(p.reader);}dispatch_source_cancel(p.reader);p.reader=nil;[self.peers removeObject:p];
}
- (void)acceptOn:(int)fd generation:(NSUInteger)generation {
    if(!self.active||self.generation!=generation)return;
    for(NSUInteger i=0;i<8;i++){struct sockaddr_in a={0};socklen_t size=sizeof(a);int client=accept(fd,(struct sockaddr *)&a,&size);if(client<0)break;
        char ip[INET_ADDRSTRLEN];const char *v=inet_ntop(AF_INET,&a.sin_addr,ip,sizeof(ip));NSString *address=v?@(ip):@"";
        if(self.peers.count>=8||(!STLANPrivateAddress(address)&&![address isEqual:@"127.0.0.1"])||fcntl(client,F_SETFL,O_NONBLOCK)){close(client);continue;}
        int yes=1;if(setsockopt(client,SOL_SOCKET,SO_NOSIGPIPE,&yes,sizeof(yes))){close(client);continue;}
        STLANPeer *p=[STLANPeer new];p.fd=client;p.alive=YES;p.address=address;p.input=[NSMutableData data];p.deadline=STLANTime()+3;
        p.reader=dispatch_source_create(DISPATCH_SOURCE_TYPE_READ,client,0,self.queue);[self.peers addObject:p];__weak STLANServer *weakSelf=self;
        dispatch_source_set_event_handler(p.reader,^{[weakSelf readPeer:p generation:generation];});dispatch_source_set_cancel_handler(p.reader,^{close(client);});dispatch_resume(p.reader);
    }
}
- (void)readPeer:(STLANPeer *)p generation:(NSUInteger)generation {
    if(!p.alive||p.handled||!self.active||self.generation!=generation)return;
    BOOL eof=NO;unsigned char bytes[2048];for(NSUInteger i=0;i<6;i++){ssize_t n=recv(p.fd,bytes,sizeof(bytes),0);
        if(n==0){eof=YES;break;}if(n<0){if(errno!=EAGAIN&&errno!=EWOULDBLOCK)[self closePeer:p];break;}
        [p.input appendBytes:bytes length:(NSUInteger)n];if(p.input.length>9216)break;
    }
    if(!p.alive)return;NSUInteger error=0;NSDictionary *request=STLANParseRequest(p.input,&error);if(!request&&!error){if(eof)[self closePeer:p];return;}
    p.handled=YES;p.suspended=YES;dispatch_suspend(p.reader);
    if(error){[self json:@{@"ok":@NO,@"reason":@"invalid_request"} status:error peer:p];return;}
    NSTimeInterval t=STLANTime();if(t-self.windowStarted>=1){self.windowStarted=t;self.windowRequests=0;}
    if(++self.windowRequests>30){[self json:@{@"ok":@NO,@"reason":@"rate_limited"} status:429 peer:p];return;}
    NSString *path=request[@"path"],*method=request[@"method"];NSDictionary *headers=request[@"headers"];
    if(![headers[@"host"] isEqual:self.authority]){[self json:@{@"ok":@NO} status:403 peer:p];return;}
    if(self.assets[path]&&[method isEqual:@"GET"]){NSString *mime=[path isEqual:@"/panel.js"]?@"application/javascript; charset=utf-8":[path isEqual:@"/panel.css"]?@"text/css; charset=utf-8":@"text/html; charset=utf-8";
        [self reply:self.assets[path] mime:mime status:200 peer:p];return;}
    BOOL post=[method isEqual:@"POST"];
    if(!STLANRequestOrigin(headers,self.authority,post)|| (post&&![headers[@"content-type"] isEqual:@"application/json"])){
        [self json:@{@"ok":@NO,@"reason":@"origin_denied"} status:403 peer:p];return;}
    id body=post?[NSJSONSerialization JSONObjectWithData:request[@"body"] options:0 error:NULL]:nil;
    if([path isEqual:@"/api/pair"]&&post){
        if(self.paired||self.pairAttempts>=5){[self json:@{@"ok":@NO,@"reason":@"pairing_closed"} status:403 peer:p];return;}
        self.pairAttempts++;
        if(![body isKindOfClass:NSDictionary.class]||[body count]!=1||!STLANConstantEqual(body[@"code"],self.pairingCode)){
            [self json:@{@"ok":@NO,@"reason":@"pairing_denied"} status:403 peer:p];
            if(self.pairAttempts>=5)dispatch_async(dispatch_get_main_queue(),^{if(self.generation==generation)[self stop];});return;}
        self.paired=YES;self.pairingCode=@"";self.controllerAddress=p.address;self.lastSeen=t;
        [self json:@{@"ok":@YES,@"key":self.secret,@"nextSequence":@1} status:200 peer:p];return;
    }
    if(!self.paired||![p.address isEqual:self.controllerAddress]||!STLANConstantEqual(headers[@"x-sdktools-key"],self.secret)){
        [self json:@{@"ok":@NO,@"reason":@"pairing_required"} status:401 peer:p];return;}
    if([path isEqual:@"/api/export"]&&[method isEqual:@"GET"]){
        NSDictionary *download=STLANDownloadRequest(headers);
        if(!download){[self json:@{@"ok":@NO,@"reason":@"invalid_download"} status:400 peer:p];return;}self.lastSeen=t;
        dispatch_async(dispatch_get_main_queue(),^{if(!self.active||self.generation!=generation||!p.alive)return;
            NSDictionary *result=nil;@try{result=self.commandHandler?self.commandHandler(download):nil;}@catch(__unused NSException *exception){}
            NSData *bytes=result[@"data"];BOOL ok=[result[@"ok"] boolValue]&&[bytes isKindOfClass:NSData.class]&&bytes.length>0&&bytes.length<=262144;
            dispatch_async(self.queue,^{if(p.alive&&self.generation==generation){
                if(ok)[self reply:bytes mime:@"application/octet-stream" status:200 peer:p];
                else [self json:@{@"ok":@NO,@"reason":@"download_unavailable"} status:409 peer:p];
            }});});return;
    }
    if([path isEqual:@"/api/state"]&&[method isEqual:@"GET"]){self.lastSeen=t;
        dispatch_async(dispatch_get_main_queue(),^{if(!self.active||self.generation!=generation||!p.alive)return;
            NSDictionary *state;@try{state=self.stateProvider?self.stateProvider():@{};}
            @catch(__unused NSException *exception){[self stop];return;}
            dispatch_async(self.queue,^{if(p.alive&&self.generation==generation)[self json:@{@"ok":@YES,@"state":state,@"nextSequence":@(self.sequence+1)} status:200 peer:p];});});return;}
    NSDictionary *command=[path isEqual:@"/api/control"]&&post?STLANCommand(body):nil;
    if(!command){[self json:@{@"ok":@NO,@"reason":@"command_denied"} status:400 peer:p];return;}
    if([command[@"sequence"] unsignedIntegerValue]!=self.sequence+1){[self json:@{@"ok":@NO,@"reason":@"sequence_conflict",@"nextSequence":@(self.sequence+1)} status:409 peer:p];return;}
    self.sequence++;self.lastSeen=t; // Consume before handing off. Never retry a possibly applied command.
    dispatch_async(dispatch_get_main_queue(),^{if(!self.active||self.generation!=generation||!p.alive)return;
        NSDictionary *result;@try{result=self.commandHandler?self.commandHandler(command):@{@"ok":@NO,@"reason":@"inactive"};}
        @catch(__unused NSException *exception){[self stop];return;}
        dispatch_async(self.queue,^{if(p.alive&&self.generation==generation)[self json:@{@"ok":result[@"ok"]?:@NO,@"reason":result[@"reason"]?:@"unavailable",@"nextSequence":@(self.sequence+1)} status:200 peer:p];});});
}
- (void)json:(NSDictionary *)value status:(NSUInteger)status peer:(STLANPeer *)p {NSData *body=nil;
    @try{body=[NSJSONSerialization dataWithJSONObject:value options:0 error:NULL];}@catch(__unused NSException *exception){}
    if(!body||body.length>32768){body=[@"{\"ok\":false}" dataUsingEncoding:NSUTF8StringEncoding];status=500;}
    [self reply:body mime:@"application/json; charset=utf-8" status:status peer:p];}
- (void)reply:(NSData *)body mime:(NSString *)mime status:(NSUInteger)status peer:(STLANPeer *)p {
    if(!p.alive)return;NSString *head=[NSString stringWithFormat:@"HTTP/1.1 %lu Response\r\nContent-Length: %lu\r\nContent-Type: %@\r\nConnection: close\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: DENY\r\nContent-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'\r\n\r\n",(unsigned long)status,(unsigned long)body.length,mime];
    NSMutableData *output=[[head dataUsingEncoding:NSUTF8StringEncoding] mutableCopy];[output appendData:body];p.output=output;p.deadline=STLANTime()+3;
    __weak STLANServer *weakSelf=self;p.writer=dispatch_source_create(DISPATCH_SOURCE_TYPE_WRITE,p.fd,0,self.queue);
    dispatch_source_set_event_handler(p.writer,^{[weakSelf writePeer:p];});dispatch_resume(p.writer);
}
- (void)writePeer:(STLANPeer *)p {if(!p.alive)return;if(!self.active){[self closePeer:p];return;}
    for(NSUInteger i=0;i<8&&p.offset<p.output.length;i++){ssize_t n=send(p.fd,(const unsigned char *)p.output.bytes+p.offset,p.output.length-p.offset,0);
        if(n<0){if(errno!=EAGAIN&&errno!=EWOULDBLOCK)[self closePeer:p];return;}if(n==0)return;p.offset+=(NSUInteger)n;}
    if(p.offset==p.output.length)[self closePeer:p];
}
@end

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// Strict detached scalar schema. Non-drawable reports preserve validated
/// identity and failure context, but never carry drawable segments.
FOUNDATION_EXPORT NSDictionary * _Nullable STBilliardsSanitizeSnapshot(id _Nullable raw, NSString * _Nullable * _Nullable failure);
FOUNDATION_EXPORT NSString *STBilliardsDiagnosticToken(id _Nullable value);
NS_ASSUME_NONNULL_END

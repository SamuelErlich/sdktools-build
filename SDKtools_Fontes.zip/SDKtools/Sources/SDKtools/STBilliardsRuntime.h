#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSNotificationName const STBilliardsRuntimeDidChangeNotification;

/// Observation by default. Aim/autoplay are explicit, independent opt-ins.
/// Never changes physics constants/transforms/inventory or starts a new match.
@interface STBilliardsRuntime : NSObject
+ (instancetype)shared;
@property(nonatomic,readonly,getter=isEnabled) BOOL enabled;
@property(nonatomic,copy,readonly) NSString *statusText;
/// 0=read-only, 1=aim only, 2=autoplay current match. Always starts at zero.
@property(nonatomic) NSUInteger automationMode;
- (void)pauseAutomationWithReason:(NSString *)reason;
@property(nonatomic,copy,readonly) NSDictionary *lastSnapshot;
/// The overlay must belong to the same foreground scene as one visible UnityView.
/// Main-thread use only. No collection runs before the user starts it.
- (BOOL)startInWindow:(UIWindow *)window error:(NSError * _Nullable * _Nullable)error;
- (void)stopWithReason:(NSString *)reason;
/// Stops sampling and writes a bounded report under Documents/SDKtools.
- (nullable NSURL *)exportReportWithError:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END

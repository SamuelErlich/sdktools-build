#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSNotificationName const STBilliardsRuntimeDidChangeNotification;

/// Explicit observation and UIKit guidance. Never submits shots or changes the
/// game's constants, transforms, auxiliary renderer, physics or inventory.
@interface STBilliardsRuntime : NSObject
+ (instancetype)shared;
@property(nonatomic,readonly,getter=isEnabled) BOOL enabled;
@property(nonatomic,copy,readonly) NSString *statusText;
@property(nonatomic,copy,readonly) NSDictionary *lastSnapshot;
/// The overlay must belong to the same foreground scene as one visible UnityView.
/// Main-thread use only. No collection runs before the user starts it.
- (BOOL)startInWindow:(UIWindow *)window error:(NSError * _Nullable * _Nullable)error;
- (void)stopWithReason:(NSString *)reason;
/// Stops sampling and writes a bounded report under Documents/SDKtools.
- (nullable NSURL *)exportReportWithError:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END

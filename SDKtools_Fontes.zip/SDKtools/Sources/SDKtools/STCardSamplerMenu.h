#import <Foundation/Foundation.h>
// Input is the native-whitelisted numeric census; no names, UID or card IDs.
static NSString *STCardSamplerMenuText(NSDictionary *diagnostic) {
    NSMutableArray<NSString *> *lines = [NSMutableArray array];
    NSString *state = diagnostic[@"samplerStatus"];
    if ([state isEqual:@"sampling"])
        [lines addObject:[NSString stringWithFormat:@"Inject: %lu/3 hooks · %lu leituras · %lu sync · %lu setup",
            (unsigned long)[diagnostic[@"samplerHooks"] unsignedIntegerValue],
            (unsigned long)[diagnostic[@"samplerSamples"] unsignedIntegerValue],
            (unsigned long)[diagnostic[@"samplerSyncs"] unsignedIntegerValue],
            (unsigned long)[diagnostic[@"samplerSetups"] unsignedIntegerValue]]];
    else if ([state isEqual:@"error"])
        [lines addObject:@"Inject indisponível. Exporte o relatório; não forçar valores."];
    else [lines addObject:@"Inject aguardando módulos/estado atual do jogo."];
    if ([diagnostic[@"handsStatus"] isEqual:@"ready"]) {
        NSUInteger selfSlot = diagnostic[@"samplerSelfSlot"] ? [diagnostic[@"samplerSelfSlot"] unsignedIntegerValue] : 8;
        for (NSDictionary *hand in diagnostic[@"handCounts"]) {
            NSUInteger slot = [hand[@"slot"] unsignedIntegerValue];
            NSString *label = slot == selfSlot ? @"Você" : [NSString stringWithFormat:@"M%lu", (unsigned long)slot + 1];
            NSArray *c = hand[@"colors"];
            [lines addObject:[NSString stringWithFormat:@"%@: %@ cartas | R%@ Az%@ Am%@ V%@ E%@ ?%@",
                label, hand[@"total"], c[1], c[2], c[3], c[4], c[0], hand[@"unknown"]]];
        }
    } else [lines addObject:@"Contagem atual indisponível; zero não é uma mão vazia confirmada."];
    [lines addObject:@"R=rosa · Az=azul · Am=amarelo · V=verde · E=especial · ?=não recebida. M=slot do estado, não assento."];
    return [lines componentsJoinedByString:@"\n"];
}

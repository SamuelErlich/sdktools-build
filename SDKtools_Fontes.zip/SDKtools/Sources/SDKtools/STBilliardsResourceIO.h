#ifndef ST_BILLIARDS_RESOURCE_IO_H
#define ST_BILLIARDS_RESOURCE_IO_H
/* Portable, observational resource IO. Does not discover paths, fetch URLs,
 * execute bundle code, initialize Unity, or identify the currently loaded game.
 * Caller supplies an evidenced root directory FD and a relative path. */
#include "STGameSourceIO.h"
#include <limits.h>
#include <math.h>
#define STBR_MAX_RECORDS 256u
#define STBR_MAX_NAME 160u
#define STBR_MAX_MANIFEST (1024u * 1024u)
#define STBR_MAX_FILE (16u * 1024u * 1024u)
#define STBR_MAX_TOTAL (32u * 1024u * 1024u)

typedef enum { STBRCategoryNone, STBRCategoryCres, STBRCategoryScene,
    STBRCategoryPrefabs, STBRCategoryPhysicMaterials, STBRCategoryModel } STBRCategory;
typedef struct {
    char name[STBR_MAX_NAME];
    char md5[33]; /* Exact manifest text, not the name suffix; no normalization. */
    uint32_t declaredSize;
    STBRCategory category;
    bool selected; /* Category selection only. Caller also enforces byte budgets. */
} STBRRecord;
typedef struct {
    uint32_t gameId, version;
    size_t recordCount, selectedCount;
    uint64_t selectedDeclaredBytes;
    STBRRecord records[STBR_MAX_RECORDS];
} STBRManifest;
typedef enum { STBRParseOK, STBRParseInvalidArgument, STBRParseTooLarge,
    STBRParseMalformed, STBRParseWrongWire, STBRParseDuplicateIdentity,
    STBRParseMissingIdentity, STBRParseWrongGame, STBRParseTooManyRecords,
    STBRParseInvalidName, STBRParseInvalidMD5, STBRParseInvalidSize } STBRParseStatus;
static inline const char *STBRParseStatusName(STBRParseStatus value) {
    static const char *const names[]={"ok","invalid_argument","manifest_size_limit","malformed_protobuf",
        "wrong_wire_type","duplicate_identity","missing_identity","wrong_resource_game_id",
        "record_count_limit","invalid_bundle_name","invalid_manifest_md5","invalid_declared_size"};
    return (unsigned)value<sizeof(names)/sizeof(names[0])?names[value]:"unknown";
}
static inline const char *STBRCategoryName(STBRCategory value) {
    static const char *const names[]={"excluded","cres","scene","prefabs","physicmaterials","model"};
    return (unsigned)value<sizeof(names)/sizeof(names[0])?names[value]:"excluded";
}
static inline bool STBRHex(unsigned char c) {
    return (c>='0'&&c<='9')||(c>='a'&&c<='f')||(c>='A'&&c<='F');
}
static inline STBRCategory STBRCategoryForName(const char *name) {
    if(!name)return STBRCategoryNone;
    static const char *const prefixes[]={"", "billiard_cres_", "billiard_scene_", "billiard_prefabs_",
        "billiard_physicmaterials_", "billiard_model_"};
    size_t length=strlen(name);
    for(unsigned i=1;i<sizeof(prefixes)/sizeof(prefixes[0]);i++) {
        size_t n=strlen(prefixes[i]);
        if(length!=n+32||strncmp(name,prefixes[i],n))continue;
        for(size_t j=n;j<length;j++)if(!STBRHex((unsigned char)name[j]))return STBRCategoryNone;
        return (STBRCategory)i;
    }
    return STBRCategoryNone;
}
typedef struct { const unsigned char *bytes; size_t size, position; } STBRProto;
static inline bool STBRVarint(STBRProto *reader,uint64_t *value) {
    uint64_t result=0;
    for(unsigned i=0;i<10;i++) {
        if(reader->position>=reader->size)return false;
        unsigned char byte=reader->bytes[reader->position++];
        if(i==9&&(byte&0xfe))return false;
        result|=(uint64_t)(byte&0x7f)<<(i*7);
        if(!(byte&0x80)){*value=result;return true;}
    }
    return false;
}
static inline bool STBRSpan(STBRProto *reader,STBRProto *child) {
    uint64_t n=0;
    if(!STBRVarint(reader,&n)||n>reader->size-reader->position)return false;
    *child=(STBRProto){reader->bytes+reader->position,(size_t)n,0};reader->position+=(size_t)n;return true;
}
static inline bool STBRKey(STBRProto *reader,uint32_t *field,unsigned *wire) {
    uint64_t key=0;
    if(!STBRVarint(reader,&key)||!(key>>3)||(key>>3)>0x1fffffff)return false;
    *field=(uint32_t)(key>>3);*wire=(unsigned)(key&7);return true;
}
static inline bool STBRSkip(STBRProto *reader,unsigned wire) {
    uint64_t ignored=0;STBRProto child;
    if(wire==0)return STBRVarint(reader,&ignored);
    if(wire==2)return STBRSpan(reader,&child);
    size_t width=wire==1?8:(wire==5?4:0);
    if(!width||width>reader->size-reader->position)return false;
    reader->position+=width;return true;
}
static inline bool STBRIdentifier(const unsigned char *bytes,size_t length) {
    if(!length||length>=STBR_MAX_NAME||bytes[0]=='.')return false;
    for(size_t i=0;i<length;i++) {
        unsigned char c=bytes[i];
        if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.'))return false;
    }
    return true;
}
static inline STBRParseStatus STBRParseRecord(STBRProto *reader,STBRRecord *record) {
    unsigned seen=0;memset(record,0,sizeof(*record));
    while(reader->position<reader->size) {
        uint32_t field=0;unsigned wire=0;uint64_t number=0;STBRProto child;
        if(!STBRKey(reader,&field,&wire))return STBRParseMalformed;
        if(field==1||field==2) {
            if(wire!=2)return STBRParseWrongWire;
            unsigned bit=field==1?1u:2u;
            if(seen&bit)return STBRParseDuplicateIdentity;
            seen|=bit;
            if(!STBRSpan(reader,&child))return STBRParseMalformed;
            if(field==1) {
                if(!STBRIdentifier(child.bytes,child.size))return STBRParseInvalidName;
                memcpy(record->name,child.bytes,child.size);
            } else {
                if(child.size!=32)return STBRParseInvalidMD5;
                for(size_t i=0;i<child.size;i++)if(!STBRHex(child.bytes[i]))return STBRParseInvalidMD5;
                memcpy(record->md5,child.bytes,child.size);
            }
        } else if(field==6) {
            if(wire!=0)return STBRParseWrongWire;
            if(seen&4u)return STBRParseDuplicateIdentity;
            seen|=4u;
            if(!STBRVarint(reader,&number))return STBRParseMalformed;
            if(!number||number>INT32_MAX)return STBRParseInvalidSize;
            record->declaredSize=(uint32_t)number;
        } else if(field==3||field==4||field==7) {
            if(wire!=0)return STBRParseWrongWire;
            if(!STBRVarint(reader,&number)||number>INT32_MAX)return STBRParseMalformed;
        } else if(field==5) {
            /* Repeated int32 dependencies may be packed or unpacked. Do not
             * confuse the baseline's one-byte varints with a byte-array ABI. */
            if(wire==0) {
                if(!STBRVarint(reader,&number)||number>INT32_MAX)return STBRParseMalformed;
            } else if(wire==2) {
                if(!STBRSpan(reader,&child))return STBRParseMalformed;
                while(child.position<child.size)
                    if(!STBRVarint(&child,&number)||number>INT32_MAX)return STBRParseMalformed;
            } else return STBRParseWrongWire;
        } else if(!STBRSkip(reader,wire))return STBRParseMalformed;
    }
    if(seen!=7u)return STBRParseMissingIdentity;
    record->category=STBRCategoryForName(record->name);record->selected=record->category!=STBRCategoryNone;
    return STBRParseOK;
}
static inline STBRParseStatus STBRParseManifestBody(const unsigned char *bytes,size_t size,STBRManifest *manifest) {
    STBRProto reader={bytes,size,0};unsigned seen=0;
    while(reader.position<reader.size) {
        uint32_t field=0;unsigned wire=0;uint64_t number=0;STBRProto child;
        if(!STBRKey(&reader,&field,&wire))return STBRParseMalformed;
        if(field==1||field==2) {
            if(wire!=0)return STBRParseWrongWire;
            unsigned bit=field==1?1u:2u;
            if(seen&bit)return STBRParseDuplicateIdentity;
            seen|=bit;
            if(!STBRVarint(&reader,&number)||number>INT32_MAX)return STBRParseMalformed;
            if(field==1)manifest->gameId=(uint32_t)number;else manifest->version=(uint32_t)number;
        } else if(field==7) {
            if(wire!=2)return STBRParseWrongWire;
            if(manifest->recordCount>=STBR_MAX_RECORDS)return STBRParseTooManyRecords;
            if(!STBRSpan(&reader,&child))return STBRParseMalformed;
            STBRRecord *record=&manifest->records[manifest->recordCount];
            STBRParseStatus status=STBRParseRecord(&child,record);
            if(status!=STBRParseOK)return status;
            for(size_t i=0;i<manifest->recordCount;i++)
                if(!strcmp(manifest->records[i].name,record->name))return STBRParseDuplicateIdentity;
            manifest->recordCount++;
            if(record->selected){manifest->selectedCount++;manifest->selectedDeclaredBytes+=record->declaredSize;}
        } else {
            /* Known metadata strings remain opaque and are not returned; they
             * include remote URLs which this exporter never uses. */
            if(field>=3&&field<=6&&wire!=2)return STBRParseWrongWire;
            if(!STBRSkip(&reader,wire))return STBRParseMalformed;
        }
    }
    if(seen!=3u||!manifest->recordCount)return STBRParseMissingIdentity;
    return manifest->gameId==20?STBRParseOK:STBRParseWrongGame;
}
/* No usable partial manifest is exposed on failure. selectedDeclaredBytes can
 * exceed limits: callers must account for the actual source bytes they retain. */
static inline STBRParseStatus STBRParseManifest(const unsigned char *bytes,size_t size,STBRManifest *manifest) {
    if(!manifest)return STBRParseInvalidArgument;
    memset(manifest,0,sizeof(*manifest));
    if(!bytes||!size)return STBRParseInvalidArgument;
    if(size>STBR_MAX_MANIFEST)return STBRParseTooLarge;
    STBRParseStatus status=STBRParseManifestBody(bytes,size,manifest);
    if(status!=STBRParseOK)memset(manifest,0,sizeof(*manifest));
    return status;
}

typedef struct { struct stat metadata; bool valid; } STBRReceipt;
typedef enum { STBRReadOK, STBRReadInvalidArgument, STBRReadUnavailable,
    STBRReadUnsafeFile, STBRReadSizeLimit, STBRReadChanged, STBRReadTimeout,
    STBRReadNoMemory, STBRReadIOError } STBRReadStatus;
static inline const char *STBRReadStatusName(STBRReadStatus value) {
    static const char *const names[]={"ok","invalid_argument","file_unavailable","unsafe_file",
        "file_size_limit","file_changed","time_budget","allocation_failed","io_error"};
    return (unsigned)value<sizeof(names)/sizeof(names[0])?names[value]:"unknown";
}
static inline bool STBRStatSafe(struct stat value,dev_t device) {
    return S_ISREG(value.st_mode)&&value.st_nlink==1&&value.st_dev==device;
}
/* Reopening detects replacement of the pathname as well as mutation of the
 * original inode. This is not an atomic multi-file snapshot guarantee. */
static inline bool STBRRevalidate(int root,const char *relative,const STBRReceipt *receipt) {
    if(root<0||!receipt||!receipt->valid||!STGSRelative(relative))return false;
    int fd=STGSOpenRelative(root,relative,false);if(fd<0)return false;
    struct stat current;bool same=!fstat(fd,&current)&&STBRStatSafe(current,receipt->metadata.st_dev)&&STGSStatSame(current,receipt->metadata);
    close(fd);return same;
}
/* Caller owns successful *bytes and must free it. maximum is additionally
 * clamped to STBR_MAX_FILE; pass remaining total budget to enforce STBR_MAX_TOTAL.
 * Use STGSNow()+budget as a finite positive deadline. All failures clear outputs.
 * No UTF-8 or compression assumption is made about the file's binary contents. */
static inline STBRReadStatus STBRRead(int root,const char *relative,dev_t device,size_t maximum,
        double deadline,unsigned char **bytes,size_t *size,STBRReceipt *receipt) {
    if(bytes)*bytes=NULL;
    if(size)*size=0;
    if(receipt)memset(receipt,0,sizeof(*receipt));
    if(root<0||!bytes||!size||!receipt||!STGSRelative(relative)||!maximum||!isfinite(deadline)||deadline<=0)return STBRReadInvalidArgument;
    double now=STGSNow();if(now<=0||now>=deadline)return STBRReadTimeout;
    if(maximum>STBR_MAX_FILE)maximum=STBR_MAX_FILE;
    int fd=STGSOpenRelative(root,relative,false);if(fd<0)return STBRReadUnavailable;
    struct stat before,after;
    if(fstat(fd,&before)){close(fd);return STBRReadIOError;}
    if(!STBRStatSafe(before,device)){close(fd);return STBRReadUnsafeFile;}
    if(before.st_size<=0||(uint64_t)before.st_size>maximum){close(fd);return STBRReadSizeLimit;}
    size_t expected=(size_t)before.st_size;
    unsigned char *data=malloc(expected);if(!data){close(fd);return STBRReadNoMemory;}
    size_t position=0;STBRReadStatus status=STBRReadOK;
    while(position<expected) {
        now=STGSNow();if(now<=0||now>=deadline){status=STBRReadTimeout;break;}
        ssize_t n=read(fd,data+position,expected-position>65536?65536:expected-position);
        if(n<0&&errno==EINTR)continue;
        if(n<0){status=STBRReadIOError;break;}
        if(!n){status=STBRReadChanged;break;}
        position+=(size_t)n;
    }
    if(status==STBRReadOK&&(fstat(fd,&after)||!STBRStatSafe(after,device)||!STGSStatSame(before,after)))status=STBRReadChanged;
    close(fd);
    if(status==STBRReadOK) {
        STBRReceipt candidate={before,true};
        if(!STBRRevalidate(root,relative,&candidate))status=STBRReadChanged;
        now=STGSNow();if(status==STBRReadOK&&(now<=0||now>=deadline))status=STBRReadTimeout;
    }
    if(status!=STBRReadOK){free(data);return status;}
    receipt->metadata=before;receipt->valid=true;*bytes=data;*size=expected;return STBRReadOK;
}
#endif

#import <UIKit/UIKit.h>
#import "STClientGamePolicy.h"
STClientGame STClientCurrentGame(UIWindow *overlay);

#import <UIKit/UIKit.h>
#import "STClientGamePolicy.h"
STClientGame STClientCurrentGame(UIWindow *overlay);

/// Strict foreground/occlusion/input gate for a new command.
STClientGame STClientActionGame(UIWindow *overlay);
/// The frontmost controller must own the game view; presentation alone is not occlusion.
BOOL STClientHostViewAllowsActions(UIView *view);
/// Main-thread passive event bookkeeping, with no input text or position reads.
BOOL STClientObserveInputEvent(UIEvent *event);
BOOL STClientInteractionBlocked(void);

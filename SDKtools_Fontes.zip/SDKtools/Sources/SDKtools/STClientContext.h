#import <UIKit/UIKit.h>
#import "STClientGamePolicy.h"
STClientGame STClientCurrentGame(UIWindow *overlay);

/// Strict foreground/occlusion/input gate for a new command.
STClientGame STClientActionGame(UIWindow *overlay);
/// Main-thread passive event bookkeeping, with no input text or position reads.
BOOL STClientObserveInputEvent(UIEvent *event);
BOOL STClientInteractionBlocked(void);

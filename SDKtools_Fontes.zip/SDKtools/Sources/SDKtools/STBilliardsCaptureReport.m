#import "STBilliardsCaptureReport.h"
#import <CoreFoundation/CoreFoundation.h>
#include <math.h>
#include <stdint.h>

static NSData *STBLCaptureCandidate(NSDictionary *report, NSArray *samples,
                                   NSDictionary *counts, NSUInteger keep,
                                   NSUInteger omitted, NSError **error) {
    NSUInteger dropped=samples.count-keep;
    NSMutableDictionary *candidate=[report mutableCopy];
    NSMutableDictionary *adjusted=[counts mutableCopy];
    adjusted[@"omittedOlderSamples"]=@(omitted+dropped);
    adjusted[@"exportTrimmedSamples"]=@(dropped);
    candidate[@"counts"]=adjusted;
    candidate[@"samples"]=[samples subarrayWithRange:NSMakeRange(dropped,keep)];
    return [NSJSONSerialization dataWithJSONObject:candidate options:NSJSONWritingPrettyPrinted error:error];
}

NSData *STBilliardsEncodeCapture(NSDictionary *report, NSUInteger maximumBytes, NSError **error) {
    if (error) *error=nil;
    NSArray *samples=[report isKindOfClass:NSDictionary.class]?report[@"samples"]:nil;
    NSDictionary *counts=[report isKindOfClass:NSDictionary.class]?report[@"counts"]:nil;
    id omitted=[counts isKindOfClass:NSDictionary.class]?counts[@"omittedOlderSamples"]:nil;
    BOOL validNumber=[omitted isKindOfClass:NSNumber.class] &&
        CFGetTypeID((__bridge CFTypeRef)omitted)!=CFBooleanGetTypeID();
    double value=validNumber?[omitted doubleValue]:-1;
    if (![samples isKindOfClass:NSArray.class] || samples.count>120 ||
        ![counts isKindOfClass:NSDictionary.class] || !validNumber || !isfinite(value) ||
        value<0 || value>INT32_MAX-120 || floor(value)!=value ||
        maximumBytes<256 || maximumBytes>4u*1024u*1024u || ![NSJSONSerialization isValidJSONObject:report]) {
        if (error) *error=[NSError errorWithDomain:@"SDKtools.BilliardsCapture" code:1
            userInfo:@{NSLocalizedDescriptionKey:@"O relatório de bilhar contém dados inválidos."}];
        return nil;
    }
    NSUInteger baseOmitted=(NSUInteger)value;
    NSData *all=STBLCaptureCandidate(report,samples,counts,samples.count,baseOmitted,error);
    if (!all || all.length<=maximumBytes) return all;
    NSData *best=STBLCaptureCandidate(report,samples,counts,0,baseOmitted,error);
    if (!best) return nil;
    if (best.length>maximumBytes) {
        if (error) *error=[NSError errorWithDomain:@"SDKtools.BilliardsCapture" code:2
            userInfo:@{NSLocalizedDescriptionKey:@"A leitura mais recente excedeu o limite de exportação."}];
        return nil;
    }
    // At most seven trials for the 120-sample ring. Prefix removal preserves
    // chronology and avoids repeatedly encoding every intermediate sample count.
    NSUInteger low=1,high=samples.count-1;
    while (low<=high) {
        NSUInteger keep=low+(high-low)/2;
        NSData *candidate=STBLCaptureCandidate(report,samples,counts,keep,baseOmitted,error);
        if (!candidate) return nil;
        if (candidate.length<=maximumBytes) { best=candidate;low=keep+1; }
        else { if (keep==0) break;high=keep-1; }
    }
    return best;
}

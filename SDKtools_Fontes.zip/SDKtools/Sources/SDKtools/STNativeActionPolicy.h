#ifndef ST_NATIVE_ACTION_POLICY_H
#define ST_NATIVE_ACTION_POLICY_H
#include <stdbool.h>
#include <math.h>
/* Production decision boundary. Keyboard/key-window ownership is not visibility:
 * the supplied v2.6 captures show the visible game in both key and non-key states.
 * An action still requires one visible foreground game without an obstruction. */
typedef struct {
    bool applicationActive, supportedApplication, scanComplete, candidateVisible;
    bool windowUsable, controllerPresenting, controllerDismissing;
    bool nativeModalVisible, webViewLoading, nativeObscured, ambiguousWebView, ambiguousWindowOverlap;
    bool hostIsKeyWindow; /* Diagnostic only; never authorizes an action. */
    double hostWindowLevel; /* Diagnostic only; actual occlusion is checked. */
} STNativeActionFacts;
typedef enum {
    STNativeActionReady, STNativeActionInactive, STNativeActionUnsupported,
    STNativeActionScanLimit, STNativeActionAmbiguous, STNativeActionUnavailable,
    STNativeActionModal, STNativeActionPresenting, STNativeActionDismissing,
    STNativeActionLoading, STNativeActionObscured, STNativeActionWindowOverlap
} STNativeActionGate;
static inline STNativeActionGate STNativeActionEvaluate(STNativeActionFacts f) {
    if (!f.applicationActive) return STNativeActionInactive;
    if (!f.supportedApplication) return STNativeActionUnsupported;
    if (!f.scanComplete) return STNativeActionScanLimit;
    if (f.ambiguousWebView) return STNativeActionAmbiguous;
    if (!f.candidateVisible || !f.windowUsable || !isfinite(f.hostWindowLevel)) return STNativeActionUnavailable;
    if (f.nativeModalVisible) return STNativeActionModal;
    if (f.controllerPresenting) return STNativeActionPresenting;
    if (f.controllerDismissing) return STNativeActionDismissing;
    if (f.webViewLoading) return STNativeActionLoading;
    if (f.ambiguousWindowOverlap) return STNativeActionWindowOverlap;
    if (f.nativeObscured) return STNativeActionObscured;
    return STNativeActionReady;
}
static inline bool STNativeActionRetryable(STNativeActionGate gate) {
    return gate != STNativeActionInactive && gate != STNativeActionUnsupported && gate != STNativeActionScanLimit;
}
/* An intermediate timeout still owns the physical lock; wait without cancelling Play intent. */
static inline bool STNativeAutoplayShouldPause(bool failed, bool physicalPending, bool evaluationTimeout) {
    return failed && !(physicalPending && evaluationTimeout);
}
/* A timeout is an intermediate notification, not a missing final batch result.
 * Preserve the provisional latch until the physical WebKit callback supplies
 * evidence; a final result with missing/wrong-document evidence still fails closed. */
typedef struct {
    bool physicalPending, refusedBeforeSubmission, wasPending, mayDispatch;
    bool contextLost, wrongDocument, hasDiagnostic, diagnosticIdle;
} STNativeBatchResultFacts;
typedef enum {
    STNativeBatchPreserve, STNativeBatchClearProvisional,
    STNativeBatchContextLost, STNativeBatchReconcile
} STNativeBatchResult;
static inline STNativeBatchResult STNativeBatchEvaluateResult(STNativeBatchResultFacts f) {
    if (f.physicalPending || f.contextLost) return STNativeBatchPreserve;
    if (f.refusedBeforeSubmission)
        return !f.wasPending && f.mayDispatch ? STNativeBatchClearProvisional : STNativeBatchPreserve;
    if (!f.wasPending && !f.mayDispatch) return STNativeBatchPreserve;
    if (f.wrongDocument || !f.hasDiagnostic || (f.wasPending && f.diagnosticIdle))
        return STNativeBatchContextLost;
    return STNativeBatchReconcile;
}
#endif

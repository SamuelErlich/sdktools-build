#ifndef ST_NATIVE_ACTION_POLICY_H
#define ST_NATIVE_ACTION_POLICY_H
#include <stdbool.h>
#include <math.h>
/* Production decision boundary. Keyboard/key-window ownership is not visibility:
 * the supplied v2.6 captures show the visible game in both key and non-key states.
 * An action still requires one visible foreground game without an obstruction. */
typedef struct {
    bool applicationActive, supportedApplication, scanComplete, candidateVisible;
    bool windowUsable, controllerPresenting, controllerDismissing;
    bool nativeModalVisible, webViewLoading, nativeObscured, ambiguousWebView, ambiguousWindowOverlap;
    bool hostIsKeyWindow; /* Diagnostic only; never authorizes an action. */
    double hostWindowLevel; /* Diagnostic only; actual occlusion is checked. */
} STNativeActionFacts;
typedef enum {
    STNativeActionReady, STNativeActionInactive, STNativeActionUnsupported,
    STNativeActionScanLimit, STNativeActionAmbiguous, STNativeActionUnavailable,
    STNativeActionModal, STNativeActionPresenting, STNativeActionDismissing,
    STNativeActionLoading, STNativeActionObscured, STNativeActionWindowOverlap
} STNativeActionGate;
static inline STNativeActionGate STNativeActionEvaluate(STNativeActionFacts f) {
    if (!f.applicationActive) return STNativeActionInactive;
    if (!f.supportedApplication) return STNativeActionUnsupported;
    if (!f.scanComplete) return STNativeActionScanLimit;
    if (f.ambiguousWebView) return STNativeActionAmbiguous;
    if (!f.candidateVisible || !f.windowUsable || !isfinite(f.hostWindowLevel)) return STNativeActionUnavailable;
    if (f.nativeModalVisible) return STNativeActionModal;
    if (f.controllerPresenting) return STNativeActionPresenting;
    if (f.controllerDismissing) return STNativeActionDismissing;
    if (f.webViewLoading) return STNativeActionLoading;
    if (f.ambiguousWindowOverlap) return STNativeActionWindowOverlap;
    if (f.nativeObscured) return STNativeActionObscured;
    return STNativeActionReady;
}
static inline bool STNativeActionRetryable(STNativeActionGate gate) {
    return gate != STNativeActionInactive && gate != STNativeActionUnsupported && gate != STNativeActionScanLimit;
}
#endif

#import "STLicenseManager.h"
#import "STKeyAuthCrypto.h"
#import <Security/Security.h>
#import <CoreFoundation/CoreFoundation.h>
#import <math.h>

NSNotificationName const STLicenseDidChangeNotification=@"SDKtools.LicenseDidChange";
static NSString *const STKAEndpoint=@"https://keyauth.win/api/1.3/";
static NSString *const STKAName=@"Weplaysdk", *const STKAOwner=@"Jdh0dfFTTT", *const STKAVersion=@"1.0";
#ifndef ST_KEYAUTH_PUBLIC_KEY
#define ST_KEYAUTH_PUBLIC_KEY "5586b4bc69c7a4b487e4563a4cd96afd39140f919bd31cea7d1c6a1e8439422b"
#endif
static const NSUInteger STKAMaxBody=65536;
static BOOL STKAString(id value,NSUInteger maximum) {
    if(![value isKindOfClass:NSString.class] || ![value length] || [value length]>maximum)return NO;
    for(NSUInteger i=0;i<[value length];i++){unichar c=[value characterAtIndex:i];if(c<33||c>126)return NO;}
    return YES;
}
static NSData *STKAHex(NSString *text,NSUInteger bytes) {
    if(![text isKindOfClass:NSString.class] || text.length!=bytes*2)return nil;
    NSMutableData *data=[NSMutableData dataWithLength:bytes];uint8_t *out=data.mutableBytes;
    for(NSUInteger i=0;i<bytes;i++){unsigned v=0;for(NSUInteger j=0;j<2;j++){unichar c=[text characterAtIndex:i*2+j];
        unsigned digit=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:16;
        if(digit>15)return nil;v=v*16+digit;}out[i]=(uint8_t)v;}
    return data;
}
static double STKADecimal(id value) {
    if([value isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)value)!=CFBooleanGetTypeID()){
        double n=[value doubleValue];return isfinite(n)&&floor(n)==n?n:NAN;}
    if(![value isKindOfClass:NSString.class] || ![value length] || [value length]>13)return NAN;
    double n=0;for(NSUInteger i=0;i<[value length];i++){unichar c=[value characterAtIndex:i];if(c<'0'||c>'9')return NAN;n=n*10+c-'0';}return n;
}
static BOOL STKATrue(id value){return value==(__bridge id)kCFBooleanTrue;}

// A separate bounded ephemeral request owns its delegate until completion/cancel.
@interface STKeyAuthRequest : NSObject <NSURLSessionDataDelegate>
@property(nonatomic,strong) NSURLSession *session;
@property(nonatomic,strong) NSURLSessionDataTask *task;
@property(nonatomic,strong) NSHTTPURLResponse *response;
@property(nonatomic,strong) NSMutableData *data;
@property(nonatomic,copy) void (^completion)(NSData *,NSHTTPURLResponse *,NSError *);
- (void)send:(NSURLRequest *)request;
- (void)cancel;
@end
@implementation STKeyAuthRequest
- (void)send:(NSURLRequest *)request {
    self.data=[NSMutableData data];NSURLSessionConfiguration *c=NSURLSessionConfiguration.ephemeralSessionConfiguration;
    c.URLCache=nil;c.HTTPCookieStorage=nil;c.URLCredentialStorage=nil;c.HTTPShouldSetCookies=NO;
    c.timeoutIntervalForRequest=10;c.timeoutIntervalForResource=15;c.HTTPMaximumConnectionsPerHost=1;
    self.session=[NSURLSession sessionWithConfiguration:c delegate:self delegateQueue:NSOperationQueue.mainQueue];
    self.task=[self.session dataTaskWithRequest:request];[self.task resume];
}
- (void)finish:(NSError *)error {
    @synchronized(self){if(!self.completion)return;
        void (^done)(NSData *,NSHTTPURLResponse *,NSError *)=self.completion;self.completion=nil;
        NSData *data=[self.data copy];NSHTTPURLResponse *response=self.response;
        [self.session invalidateAndCancel];self.task=nil;self.session=nil;self.data=nil;
        dispatch_async(dispatch_get_main_queue(),^{done(data,response,error);});}
}
- (void)cancel { [self finish:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorCancelled userInfo:nil]]; }
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task willPerformHTTPRedirection:(NSHTTPURLResponse *)response newRequest:(NSURLRequest *)request completionHandler:(void (^)(NSURLRequest *))completionHandler {
    (void)session;(void)task;(void)response;(void)request;completionHandler(nil);
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)task didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler {
    (void)session;(void)task;
    if(![response isKindOfClass:NSHTTPURLResponse.class] || ![response.URL.absoluteString isEqual:STKAEndpoint] ||
       [(NSHTTPURLResponse *)response statusCode]!=200 || response.expectedContentLength>(int64_t)STKAMaxBody){
        completionHandler(NSURLSessionResponseCancel);return;}
    self.response=(NSHTTPURLResponse *)response;completionHandler(NSURLSessionResponseAllow);
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)task didReceiveData:(NSData *)data {
    (void)session;(void)task;if(data.length>STKAMaxBody-self.data.length){[self cancel];return;}[self.data appendData:data];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
    (void)session;(void)task;[self finish:error];
}
@end

@interface STLicenseManager ()
@property(nonatomic) BOOL busy;
@property(nonatomic,copy) NSString *statusKey;
@property(nonatomic,copy) NSDate *expiry;
@property(nonatomic,copy) NSString *license;
@property(nonatomic,copy) NSString *deviceID;
@property(nonatomic,copy) NSString *sessionID;
@property(nonatomic) BOOL started;
@property(nonatomic) BOOL entitled;
@property(nonatomic) BOOL automaticRetry;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) NSTimeInterval checkedUptime;
@property(nonatomic) NSTimeInterval expiresUptime;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) STKeyAuthRequest *request;
@end
@implementation STLicenseManager
+ (instancetype)shared {static STLicenseManager *value;static dispatch_once_t once;dispatch_once(&once,^{value=[self new];});return value;}
- (instancetype)init {if((self=[super init]))_statusKey=@"Enter your license key";return self;}
- (NSTimeInterval)wallTime {return NSDate.date.timeIntervalSince1970;}
- (NSTimeInterval)uptime {return NSProcessInfo.processInfo.systemUptime;}
- (BOOL)authorized {
    NSTimeInterval now=[self uptime],elapsed=now-self.checkedUptime;
    return self.entitled && isfinite(now) && elapsed>=0 && elapsed<90 && now<self.expiresUptime && self.expiry.timeIntervalSince1970>[self wallTime];
}
- (BOOL)savedKeyAvailable {return self.license.length>0;}
- (NSMutableDictionary *)keychainQuery:(NSString *)account {
    return [@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,(__bridge id)kSecAttrService:@"SDKtools.KeyAuth.Weplaysdk.Jdh0dfFTTT",
        (__bridge id)kSecAttrAccount:account,(__bridge id)kSecAttrSynchronizable:@NO} mutableCopy];
}
- (NSData *)readSecret:(NSString *)account status:(OSStatus *)status {
    NSMutableDictionary *query=[self keychainQuery:account];query[(__bridge id)kSecReturnData]=@YES;query[(__bridge id)kSecMatchLimit]=(__bridge id)kSecMatchLimitOne;
    CFTypeRef data=NULL;*status=SecItemCopyMatching((__bridge CFDictionaryRef)query,&data);
    id value=CFBridgingRelease(data);return *status==errSecSuccess && [value isKindOfClass:NSData.class]?value:nil;
}
- (OSStatus)writeSecret:(NSData *)data account:(NSString *)account {
    NSMutableDictionary *query=[self keychainQuery:account];NSDictionary *changes=@{(__bridge id)kSecValueData:data,(__bridge id)kSecAttrAccessible:(__bridge id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly};
    OSStatus result=SecItemUpdate((__bridge CFDictionaryRef)query,(__bridge CFDictionaryRef)changes);
    if(result==errSecItemNotFound){[query addEntriesFromDictionary:changes];result=SecItemAdd((__bridge CFDictionaryRef)query,NULL);}return result;
}
- (OSStatus)deleteSecret:(NSString *)account {return SecItemDelete((__bridge CFDictionaryRef)[self keychainQuery:account]);}
- (BOOL)loadCredentials {
    OSStatus status=errSecSuccess;NSData *raw=[self readSecret:@"installation" status:&status];
    if(status==errSecItemNotFound){NSString *device=NSUUID.UUID.UUIDString;
        if([self writeSecret:[device dataUsingEncoding:NSUTF8StringEncoding] account:@"installation"]!=errSecSuccess){self.deviceID=nil;return NO;}self.deviceID=device;}
    else {NSString *device=raw.length>0&&raw.length<=64?[[NSString alloc] initWithData:raw encoding:NSUTF8StringEncoding]:nil;
        if(status!=errSecSuccess || !STKAString(device,36) || ![[NSUUID alloc] initWithUUIDString:device]){self.deviceID=nil;return NO;}self.deviceID=device;}
    raw=[self readSecret:@"license" status:&status];
    if(status==errSecItemNotFound){self.license=nil;return YES;}
    NSString *key=raw.length>0&&raw.length<=256?[[NSString alloc] initWithData:raw encoding:NSUTF8StringEncoding]:nil;
    if(status!=errSecSuccess || !STKAString(key,256))return NO;self.license=key;return YES;
}
- (void)notify {[[NSNotificationCenter defaultCenter] postNotificationName:STLicenseDidChangeNotification object:self];}
- (void)schedule {
    [self.timer invalidate];self.timer=nil;if(!self.started || !self.license || !self.automaticRetry)return;
    NSTimeInterval delay=self.authorized?MIN(30,MAX(0.1,MIN(self.expiresUptime,self.checkedUptime+90)-[self uptime])):30;
    __weak STLicenseManager *weakSelf=self;
    self.timer=[NSTimer timerWithTimeInterval:delay repeats:NO block:^(__unused NSTimer *timer){STLicenseManager *s=weakSelf;if(!s)return;
        if(s.entitled&&!s.authorized){s.entitled=NO;s.statusKey=@"License expired or unavailable";[s notify];}[s resume];}];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}
- (void)fail:(NSString *)status retry:(BOOL)retry {
    self.busy=NO;self.entitled=NO;self.statusKey=status;self.automaticRetry=retry;[self schedule];[self notify];
}
- (void)start {
    NSAssert(NSThread.isMainThread,@"Main thread");if(self.started)return;self.started=YES;
    if(![self loadCredentials]){[self fail:@"Secure storage unavailable" retry:NO];return;}
    if(self.savedKeyAvailable)[self resume];else [self notify];
}
- (void)resume {
    NSAssert(NSThread.isMainThread,@"Main thread");if(!self.started){[self start];return;}if(self.busy)return;
    if((!self.deviceID || !self.license) && ![self loadCredentials]){[self fail:@"Secure storage unavailable" retry:NO];return;}
    if(!self.savedKeyAvailable)return;
    if(self.authorized && [self uptime]-self.checkedUptime<25){[self schedule];return;}
    [self authenticate:self.license checkOnly:self.authorized&&self.sessionID.length>0];
}
- (void)activateKey:(NSString *)key {
    NSAssert(NSThread.isMainThread,@"Main thread");key=[key stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if(!STKAString(key,256)){self.generation++;[self.request cancel];self.request=nil;[self fail:@"Invalid license key" retry:NO];return;}
    if(!self.started)[self start];if(!self.deviceID && ![self loadCredentials]){[self fail:@"Secure storage unavailable" retry:NO];return;}
    [self authenticate:key checkOnly:NO];
}
- (void)forgetKey {
    NSAssert(NSThread.isMainThread,@"Main thread");self.generation++;[self.request cancel];self.request=nil;[self.timer invalidate];self.timer=nil;
    self.busy=NO;self.entitled=NO;self.automaticRetry=NO;self.sessionID=nil;self.expiry=nil;
    OSStatus result=[self deleteSecret:@"license"];
    if(result!=errSecSuccess && result!=errSecItemNotFound){self.statusKey=@"Secure storage unavailable";[self notify];return;}
    self.license=nil;self.statusKey=@"License removed";[self notify];
}
- (NSDictionary *)verifiedBody:(NSData *)data response:(NSHTTPURLResponse *)response {
    if(!data.length || data.length>STKAMaxBody || response.statusCode!=200 || ![response.URL.absoluteString isEqual:STKAEndpoint])return nil;
    NSString *timestamp=[response valueForHTTPHeaderField:@"x-signature-timestamp"];
    double seconds=STKADecimal(timestamp);if(!isfinite(seconds)||seconds<1000000000||seconds>4102444800||fabs([self wallTime]-seconds)>120)return nil;
    NSData *signature=STKAHex([response valueForHTTPHeaderField:@"x-signature-ed25519"],64),*key=STKAHex(@ST_KEYAUTH_PUBLIC_KEY,32);
    NSMutableData *message=[[timestamp dataUsingEncoding:NSUTF8StringEncoding] mutableCopy];[message appendData:data];
    if(!signature || !key || STKeyAuthVerifyEd25519(signature.bytes,signature.length,message.bytes,message.length,key.bytes,key.length)!=1)return nil;
    id value=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if(![value isKindOfClass:NSDictionary.class] || (value[@"ownerid"] && ![value[@"ownerid"] isEqual:STKAOwner]))return nil;
    return value;
}
- (void)sendFields:(NSDictionary *)fields generation:(NSUInteger)generation completion:(void (^)(NSDictionary *,NSTimeInterval,BOOL))completion {
    NSMutableDictionary *all=[fields mutableCopy];all[@"name"]=STKAName;all[@"ownerid"]=STKAOwner;
    NSURLComponents *form=[NSURLComponents new];NSMutableArray *items=[NSMutableArray array];
    for(NSString *key in [[all allKeys] sortedArrayUsingSelector:@selector(compare:)])[items addObject:[NSURLQueryItem queryItemWithName:key value:all[key]]];
    form.queryItems=items;NSString *body=[form.percentEncodedQuery stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:STKAEndpoint] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:10];
    request.HTTPMethod=@"POST";request.HTTPShouldHandleCookies=NO;request.HTTPBody=[body dataUsingEncoding:NSUTF8StringEncoding];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];[request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    STKeyAuthRequest *operation=[STKeyAuthRequest new];self.request=operation;__weak STLicenseManager *weakSelf=self;
    operation.completion=^(NSData *data,NSHTTPURLResponse *response,NSError *error){STLicenseManager *s=weakSelf;
        if(!s||s.generation!=generation)return;s.request=nil;
        NSDictionary *value=!error?[s verifiedBody:data response:response]:nil;
        completion(value,STKADecimal([response valueForHTTPHeaderField:@"x-signature-timestamp"]),error!=nil);
    };[operation send:request];
}
- (void)authenticate:(NSString *)key checkOnly:(BOOL)checkOnly {
    self.generation++;NSUInteger generation=self.generation;[self.request cancel];[self.timer invalidate];self.timer=nil;
    self.busy=YES;if(!checkOnly)self.entitled=NO;self.statusKey=@"Checking license…";[self notify];
    if(checkOnly)[self schedule]; // Expiry must still revoke while the heartbeat is in flight.
    __weak STLicenseManager *weakSelf=self;
    void (^login)(void)=^{STLicenseManager *s=weakSelf;if(!s||s.generation!=generation)return;
        NSDictionary *fields=checkOnly?@{@"type":@"check",@"sessionid":s.sessionID}:@{@"type":@"license",@"sessionid":s.sessionID,@"key":key,@"hwid":s.deviceID};
        [s sendFields:fields generation:generation completion:^(NSDictionary *value,NSTimeInterval stamp,BOOL network){STLicenseManager *m=weakSelf;if(!m)return;
            if(!value){[m fail:network?@"License service unavailable. Retry.":@"License validation failed" retry:network];return;}
            if(!STKATrue(value[@"success"])){m.sessionID=nil;[m fail:@"License expired or unavailable" retry:NO];return;}
            if(checkOnly){if(!m.authorized){[m authenticate:key checkOnly:NO];return;}m.checkedUptime=[m uptime];}
            else {
                id info=value[@"info"],subscriptions=[info isKindOfClass:NSDictionary.class]?info[@"subscriptions"]:nil;
                if(![subscriptions isKindOfClass:NSArray.class] || ![subscriptions count] || [subscriptions count]>32){[m fail:@"License validation failed" retry:NO];return;}
                double expiry=0;for(id row in subscriptions){double e=[row isKindOfClass:NSDictionary.class]?STKADecimal(row[@"expiry"]):NAN;
                    if(!isfinite(e)||e<=0||e>4102444800){[m fail:@"License validation failed" retry:NO];return;}expiry=MAX(expiry,e);}
                if(expiry<=stamp || expiry<=[m wallTime]){[m fail:@"License expired or unavailable" retry:NO];return;}
                if([m writeSecret:[key dataUsingEncoding:NSUTF8StringEncoding] account:@"license"]!=errSecSuccess){[m fail:@"Secure storage unavailable" retry:NO];return;}
                m.license=key;m.expiry=[NSDate dateWithTimeIntervalSince1970:expiry];m.checkedUptime=[m uptime];m.expiresUptime=m.checkedUptime+(expiry-stamp);m.entitled=YES;
            }
            m.busy=NO;m.automaticRetry=YES;m.statusKey=@"License active";[m schedule];[m notify];
        }];
    };
    if(self.sessionID.length){login();return;}
    [self sendFields:@{@"type":@"init",@"ver":STKAVersion,@"hash":@""} generation:generation completion:^(NSDictionary *value,NSTimeInterval stamp,BOOL network){
        (void)stamp;STLicenseManager *s=weakSelf;if(!s)return;
        if(!value){[s fail:network?@"License service unavailable. Retry.":@"License validation failed" retry:network];return;}
        if(!STKATrue(value[@"success"]) || !STKAString(value[@"sessionid"],256)){[s fail:@"License validation failed" retry:NO];return;}
        s.sessionID=value[@"sessionid"];login();
    }];
}
@end
BOOL STLicenseAllowsFeatures(void){return STLicenseManager.shared.authorized;}

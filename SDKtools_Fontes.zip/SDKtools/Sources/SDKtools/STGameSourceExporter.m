#import "STGameSourceExporter.h"
#import <CommonCrypto/CommonDigest.h>
#include "STGameSourceIO.h"

static NSError *STGSError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"SDKtools.GameSources" code:code userInfo:@{NSLocalizedDescriptionKey:message}];
}
static int STGSPriority(const char *path) {
    if(strstr(path,"project")||strstr(path,"game")||strstr(path,"Game"))return 0;
    if(strstr(path,"assets/")||strstr(path,"src/"))return 1;
    return 2;
}
static int STGSCompare(const void *a,const void *b) {
    const STGSCandidate *left=a,*right=b;int priority=STGSPriority(left->path)-STGSPriority(right->path);
    return priority?priority:strcmp(left->path,right->path);
}
static NSString *STGSHash(const unsigned char *data,size_t size) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];CC_SHA256(data,(CC_LONG)size,digest);
    char text[CC_SHA256_DIGEST_LENGTH*2+1];static const char hex[]="0123456789abcdef";
    for(unsigned i=0;i<CC_SHA256_DIGEST_LENGTH;i++){text[i*2]=hex[digest[i]>>4];text[i*2+1]=hex[digest[i]&15];}
    text[CC_SHA256_DIGEST_LENGTH*2]=0;return [NSString stringWithUTF8String:text];
}
static NSDictionary *STGSKeywords(const unsigned char *data,size_t size) {
    NSMutableDictionary *matches=[NSMutableDictionary dictionary];
    for(NSString *word in @[@"UseProp",@"onBtnUseClick",@"updatePropInfo",@"propInfo",@"warehouse",@"WareHouse",@"Warehouse",@"CommonStoreItem",@"onBtnClick",@"getIsWatcher",@"GetIsWatcher",@"Store",@"Storage",@"Withdraw",@"Refresh",@"Penetrate"]) {
        size_t offsets[16];unsigned count=STGSMatches(data,size,word.UTF8String,offsets,16);
        if(!count)continue;
        NSMutableArray *positions=[NSMutableArray array];for(unsigned i=0;i<count;i++)[positions addObject:@(offsets[i])];
        matches[word]=@{@"utf8ByteOffsets":positions,@"atLeastCount":@(count),@"offsetLimitReached":@(count==16)};
    }
    return matches;
}
static BOOL STGSWriteBytes(NSOutputStream *stream,NSData *data,NSUInteger *total) {
    const NSUInteger limit=64u*1024u*1024u;
    if(data.length>limit-*total)return NO;
    const uint8_t *bytes=data.bytes;NSUInteger position=0;
    while(position<data.length) {
        NSInteger written=[stream write:bytes+position maxLength:MIN((NSUInteger)65536,data.length-position)];
        if(written<=0)return NO;position+=(NSUInteger)written;
    }
    *total+=data.length;return YES;
}
static BOOL STGSWriteJSONObject(NSOutputStream *stream,id object,NSUInteger *total) {
    NSData *data=[NSJSONSerialization dataWithJSONObject:object options:NSJSONWritingSortedKeys error:nil];
    return data&&STGSWriteBytes(stream,data,total);
}
@implementation STGameSourceExporter
+ (NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL entryURL:(NSURL *)entryURL destinationDirectory:(NSURL *)directory error:(NSError **)error {
    if(NSThread.isMainThread){if(error)*error=STGSError(1,@"A coleta de código precisa ocorrer em segundo plano.");return nil;}
    if(!cachesURL.isFileURL||!entryURL.isFileURL||entryURL.query.length||entryURL.fragment.length||!directory.isFileURL) {
        if(error)*error=STGSError(2,@"O jogo atual não usa o pacote local verificado.");return nil;
    }
    NSURL *canonicalCaches=cachesURL.URLByStandardizingPath.URLByResolvingSymlinksInPath;
    NSString *suffix=@"littleGame/60_game/game_res/web-mobile";
    NSURL *expected=[[canonicalCaches URLByAppendingPathComponent:suffix isDirectory:YES] URLByAppendingPathComponent:@"index.html"];
    // The current document must identify this exact cache, not another game's
    // directory, a remote URL, a sibling-prefix path or an arbitrary attachment.
    NSURL *canonicalEntry=entryURL.URLByStandardizingPath.URLByResolvingSymlinksInPath;
    if(![canonicalEntry.path isEqualToString:expected.path]) {
        if(error)*error=STGSError(3,@"O caminho do jogo atual não corresponde ao Crazy Alpaca local verificado.");return nil;
    }
    int cacheFD=open(canonicalCaches.fileSystemRepresentation,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_DIRECTORY);
    int rootFD=cacheFD<0?-1:STGSOpenRelative(cacheFD,suffix.UTF8String,true);
    if(cacheFD>=0)close(cacheFD);
    int indexFD=rootFD<0?-1:STGSOpenRelative(rootFD,"index.html",false);
    struct stat rootBefore,indexBefore;
    if(rootFD<0||indexFD<0||fstat(rootFD,&rootBefore)||fstat(indexFD,&indexBefore)||!S_ISREG(indexBefore.st_mode)||indexBefore.st_nlink!=1||indexBefore.st_dev!=rootBefore.st_dev) {
        if(rootFD>=0)close(rootFD);if(indexFD>=0)close(indexFD);
        if(error)*error=STGSError(4,@"O pacote local não está disponível ou contém um caminho não permitido.");return nil;
    }
    double started=STGSNow();STGSInventory *inventory=calloc(1,sizeof(STGSInventory));
    if(!inventory){close(indexFD);close(rootFD);if(error)*error=STGSError(5,@"Não há memória disponível para coletar o código.");return nil;}
    inventory->deadline=started+10;inventory->device=rootBefore.st_dev;
    STGSWalk(rootFD,rootFD,"",0,inventory);qsort(inventory->files,inventory->count,sizeof(STGSCandidate),STGSCompare);
    NSFileManager *manager=[NSFileManager new];
    if(![manager createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:@{NSFileProtectionKey:NSFileProtectionComplete} error:nil]) {
        free(inventory);close(indexFD);close(rootFD);if(error)*error=STGSError(6,@"Não foi possível criar a pasta de exportação.");return nil;
    }
    NSString *identifier=NSUUID.UUID.UUIDString;
    NSURL *temporary=[directory URLByAppendingPathComponent:[NSString stringWithFormat:@"SDKtools-GameSources-%@.partial",identifier]];
    NSURL *destination=[directory URLByAppendingPathComponent:[NSString stringWithFormat:@"SDKtools-GameSources-%@.json",identifier]];
    // File name is generated locally; source-relative paths are never reused as
    // output paths. Only this new temporary output is written or deleted.
    NSOutputStream *stream=[NSOutputStream outputStreamWithURL:temporary append:NO];[stream open];
    [manager setAttributes:@{NSFileProtectionKey:NSFileProtectionComplete} ofItemAtPath:temporary.path error:nil];
    NSUInteger outputBytes=0,totalSource=0,included=0;BOOL written=STGSWriteBytes(stream,[@"{\"format\":\"SDKtools.GameSources\",\"schemaVersion\":1,\"files\":[" dataUsingEncoding:NSUTF8StringEncoding],&outputBytes);
    NSMutableArray *skipped=[NSMutableArray array];
    for(unsigned i=0;written&&i<inventory->count;i++) {@autoreleasepool {
        STGSCandidate candidate=inventory->files[i];NSString *path=[[NSString alloc]initWithUTF8String:candidate.path];
        if(!path){inventory->errors++;continue;}
        NSString *skip=nil;
        if(STGSNow()>inventory->deadline){skip=@"time_budget";inventory->timedOut=true;}
        else if(included>=STGS_MAX_FILES)skip=@"file_count_limit";
        else if(candidate.size>STGS_MAX_FILE)skip=@"file_size_limit";
        else if(candidate.size>STGS_MAX_TOTAL-totalSource)skip=@"total_source_limit";
        if(skip){[skipped addObject:@{@"path":path,@"bytesObserved":@(candidate.size),@"reason":skip}];continue;}
        unsigned char *bytes=NULL;size_t size=0;
        STGSReadStatus status=STGSRead(rootFD,candidate.path,rootBefore.st_dev,MIN((size_t)STGS_MAX_FILE,(size_t)STGS_MAX_TOTAL-totalSource),inventory->deadline,&bytes,&size);
        if(status!=STGSReadOK) {
            NSArray *reasons=@[@"ok",@"file_unavailable",@"file_size_limit",@"file_changed_during_read",@"not_utf8_js_text",@"time_budget"];
            [skipped addObject:@{@"path":path,@"bytesObserved":@(candidate.size),@"reason":reasons[status]}];continue;
        }
        NSString *source=[[NSString alloc]initWithBytes:bytes length:size encoding:NSUTF8StringEncoding];
        NSDictionary *record=@{@"path":path,@"bytes":@(size),@"sha256":STGSHash(bytes,size),@"encoding":@"utf-8",
            @"readMetadataStable":@YES,@"completeFile":@YES,@"keywordMatches":STGSKeywords(bytes,size),@"source":source};
        free(bytes);
        if(included)written=STGSWriteBytes(stream,[@"," dataUsingEncoding:NSUTF8StringEncoding],&outputBytes);
        if(written)written=STGSWriteJSONObject(stream,record,&outputBytes);
        if(written){included++;totalSource+=size;}
    }}
    BOOL complete=!skipped.count&&!inventory->timedOut&&!inventory->entryLimit&&!inventory->excessiveDepth&&!inventory->excessiveCandidates&&!inventory->errors&&!inventory->symlinks&&!inventory->other;
    NSDictionary *metadata=@{@"format":@"SDKtools.GameSources",@"schemaVersion":@1,@"toolVersion":@"2.8.1",
        @"gameID":@60,@"application":@{@"bundleIdentifier":@"com.wejoy.weplay.us",@"version":@"6.6.2",@"build":@"132"},
        @"rootScope":@"Caches/littleGame/60_game/game_res/web-mobile",@"entryRelativePath":@"index.html",
        @"sourceKind":@"static_on_disk_javascript",@"loadedRuntimeEquivalenceProven":@NO,@"atomicWholeBundleSnapshot":@NO,
        @"codeExecuted":@NO,@"networkAccessed":@NO,@"runtimeStateRead":@NO,
        @"scopeComplete":@(complete),@"includedFiles":@(included),@"includedSourceBytes":@(totalSource),@"skippedFiles":skipped,
        @"inventory":@{@"visitedEntries":@(inventory->visited),@"jsCandidates":@(inventory->count),@"symlinksSkipped":@(inventory->symlinks),
            @"nonJSFilesSkipped":@(inventory->nonJS),@"otherEntriesSkipped":@(inventory->other),@"depthLimitCount":@(inventory->excessiveDepth),
            @"candidateLimitCount":@(inventory->excessiveCandidates),@"readErrors":@(inventory->errors),@"entryLimitReached":@(inventory->entryLimit),@"timeLimitReached":@(inventory->timedOut)},
        @"limits":@{@"sourceBytes":@(STGS_MAX_TOTAL),@"fileBytes":@(STGS_MAX_FILE),@"files":@(STGS_MAX_FILES),@"candidateFiles":@(STGS_MAX_CANDIDATES),
            @"directoryEntries":@(STGS_MAX_ENTRIES),@"depth":@(STGS_MAX_DEPTH),@"scanSeconds":@10,@"serializedJSONBytes":@(64u*1024u*1024u),@"keywordOffsetsPerWordPerFile":@16}};
    if(written)written=STGSWriteBytes(stream,[@"],\"metadata\":" dataUsingEncoding:NSUTF8StringEncoding],&outputBytes)&&STGSWriteJSONObject(stream,metadata,&outputBytes)&&STGSWriteBytes(stream,[@"}" dataUsingEncoding:NSUTF8StringEncoding],&outputBytes);
    [stream close];
    struct stat rootAfter,indexAfter,reopenedIndex,reopenedRoot;
    int freshIndex=STGSOpenRelative(rootFD,"index.html",false);
    int freshCache=open(canonicalCaches.fileSystemRepresentation,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_DIRECTORY);
    int freshRoot=freshCache<0?-1:STGSOpenRelative(freshCache,suffix.UTF8String,true);
    BOOL stable=!fstat(rootFD,&rootAfter)&&!fstat(indexFD,&indexAfter)&&freshIndex>=0&&!fstat(freshIndex,&reopenedIndex)&&
        freshRoot>=0&&!fstat(freshRoot,&reopenedRoot)&&STGSStatSame(rootBefore,reopenedRoot)&&
        STGSStatSame(rootBefore,rootAfter)&&STGSStatSame(indexBefore,indexAfter)&&STGSStatSame(indexBefore,reopenedIndex);
    if(freshRoot>=0)close(freshRoot);
    if(freshCache>=0)close(freshCache);
    if(freshIndex>=0)close(freshIndex);
    close(indexFD);close(rootFD);free(inventory);
    if(!written||!included||!stable||![manager moveItemAtURL:temporary toURL:destination error:nil]) {
        [manager removeItemAtURL:temporary error:nil];
        if(error)*error=STGSError(7,!stable?@"O pacote do jogo mudou durante a coleta. Tente novamente com a partida aberta.":(!included?@"Nenhum arquivo JavaScript completo pôde ser coletado dentro dos limites.":@"A exportação não terminou ou atingiu o limite de 64 MiB."));return nil;
    }
    [destination setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];return destination;
}
@end

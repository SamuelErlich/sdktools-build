#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
/// Synchronous background-only read of the exact verified game-60 cache root.
/// No JavaScript is evaluated; output is static on-disk UTF-8 source evidence.
@interface STGameSourceExporter : NSObject
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                    entryURL:(NSURL *)entryURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END

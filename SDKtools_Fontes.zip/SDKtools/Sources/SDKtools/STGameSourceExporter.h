#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSString * const STGameSourcePathDiagnosticKey;
/// Synchronous background-only read of the exact verified game-60 local root.
/// No JavaScript is evaluated; output is static on-disk UTF-8 source evidence.
@interface STGameSourceExporter : NSObject
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                    entryURL:(NSURL *)entryURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
/// The caller must first verify the foreground app and gameType == 60. If used,
/// nativeResourceURL must come only from the ABI-checked original native
/// gameResDownloadPath:60 getter. It must never come from page-controlled input.
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                    entryURL:(NSURL *)entryURL
                   verifiedNativeResourceURL:(nullable NSURL *)nativeResourceURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
/// Both anchors must come from Foundation's NSCachesDirectory and
/// NSDocumentDirectory APIs for the current app. Only the current document's
/// exact littleGame package is opened; neither directory is broadly searched.
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                documentsURL:(nullable NSURL *)documentsURL
                                    entryURL:(NSURL *)entryURL
                   verifiedNativeResourceURL:(nullable NSURL *)nativeResourceURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSString * const STGameSourcePathDiagnosticKey;
/// Synchronous background-only read of the exact current local game package.
/// No JavaScript is evaluated; output is static on-disk UTF-8 source evidence.
@interface STGameSourceExporter : NSObject
/// Legacy overloads below remain restricted to independently verified game 60.
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                    entryURL:(NSURL *)entryURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
/// The caller must first verify the foreground app and gameType == 60. If used,
/// nativeResourceURL must come only from the ABI-checked original native
/// gameResDownloadPath:60 getter. It must never come from page-controlled input.
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                    entryURL:(NSURL *)entryURL
                   verifiedNativeResourceURL:(nullable NSURL *)nativeResourceURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
/// Both anchors must come from Foundation's NSCachesDirectory and
/// NSDocumentDirectory APIs for the current app. Only the current document's
/// exact littleGame package is opened; neither directory is broadly searched.
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                documentsURL:(nullable NSURL *)documentsURL
                                    entryURL:(NSURL *)entryURL
                   verifiedNativeResourceURL:(nullable NSURL *)nativeResourceURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
/// The foreground native controller must independently report game type 60 or
/// 2007, with entryURL obtained from that controller's current local WKWebView.
/// For 2007, nativeResourceURL must be nil: its native getter is unverified.
/// Only the current document's exact 2007_game/dev_2007_game package is accepted.
/// These spellings are compatibility candidates, not observed device evidence.
/// The caller must revalidate the same controller, document and game on delivery.
+ (nullable NSURL *)writeSourcesFromCachesURL:(NSURL *)cachesURL
                                documentsURL:(nullable NSURL *)documentsURL
                                    entryURL:(NSURL *)entryURL
                            observedGameType:(NSInteger)observedGameType
                   verifiedNativeResourceURL:(nullable NSURL *)nativeResourceURL
                        destinationDirectory:(NSURL *)directory
                                       error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/* Read-only export of the narrowly identified Unity billiards resource cache.
 * Call on a background queue. Anchors must be the OS-provided Documents and
 * Library URLs; destination must be Documents/SDKtools. A diagnostic JSON is
 * returned even when no eligible cached resource exists. No active-match,
 * physics, ball-location or native game-type claim is made by this exporter. */
@interface STBilliardsResourceExporter : NSObject
+ (nullable NSURL *)writePackageFromDocumentsURL:(NSURL *)documents
                                     libraryURL:(NSURL *)library
                           destinationDirectory:(NSURL *)destination
                                     diagnostic:(NSDictionary * _Nullable * _Nullable)diagnostic
                                          error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END

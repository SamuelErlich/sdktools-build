#import <Foundation/Foundation.h>

// Encode an already-sanitized capture, retaining the newest samples that fit.
// The input dictionary is never mutated. lastSnapshot and other fixed fields
// stay intact; trimming is reflected in counts, not silently hidden.
FOUNDATION_EXPORT NSData *STBilliardsEncodeCapture(NSDictionary *report,
                                                 NSUInteger maximumBytes,
                                                 NSError **error);

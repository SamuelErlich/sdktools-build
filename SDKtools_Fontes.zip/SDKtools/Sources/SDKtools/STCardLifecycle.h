#ifndef SDKTOOLS_ST_CARD_LIFECYCLE_H
#define SDKTOOLS_ST_CARD_LIFECYCLE_H
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <string.h>

// Audited WePlay US 6.6.2/132 contracts. Never erase the BOOL return ABI.
static inline const char *STCardLifecycleEncoding(SEL selector) {
    if (sel_isEqual(selector, NSSelectorFromString(@"setupWKWebView"))) return "v16@0:8";
    if (sel_isEqual(selector, NSSelectorFromString(@"loadCurrentGame"))) return "B16@0:8";
    return NULL;
}
static inline BOOL STCardLifecycleMatches(SEL selector, Method method) {
    const char *expected=STCardLifecycleEncoding(selector);
    return expected && method && method_getNumberOfArguments(method)==2 &&
        method_getTypeEncoding(method) && strcmp(method_getTypeEncoding(method),expected)==0;
}
static inline IMP STCardLifecycleWrapper(SEL selector, IMP original, void (^checkpoint)(id, BOOL)) {
    if (!original || !STCardLifecycleEncoding(selector)) return NULL;
    if (sel_isEqual(selector, NSSelectorFromString(@"loadCurrentGame"))) {
        return imp_implementationWithBlock(^BOOL(id object) {
            if (checkpoint) checkpoint(object, YES);
            return ((BOOL (*)(id,SEL))original)(object,selector);
        });
    }
    return imp_implementationWithBlock(^(id object) {
        ((void (*)(id,SEL))original)(object,selector);
        if (checkpoint) checkpoint(object, NO);
    });
}
#endif

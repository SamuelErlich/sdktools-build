#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Draw an already sanitized, fresh billiards snapshot in the current UIKit
/// graphics context. The caller owns scene/camera/lifetime validation. This
/// function reads detached values only and never accesses game objects.
FOUNDATION_EXPORT void STBilliardsDrawGuideSnapshot(NSDictionary *snapshot, CGRect gameRect);

NS_ASSUME_NONNULL_END

#ifndef ST_NEW_GAME_CAPTURE_POLICY_H
#define ST_NEW_GAME_CAPTURE_POLICY_H
#include <stdbool.h>
/* Numeric native identity is observed; the title is always confirmed by the
 * user. In particular, the known Crazy Alpaca identity cannot be relabeled. */
static inline bool STNewGameCanConfirm(long long gameType, bool identityStable) {
    return identityStable && gameType >= 0 && gameType <= 1000000 && gameType != 60;
}
static inline bool STNewGameContextMatches(long long expected, long long current,
        bool sameController, bool sameWebView, bool sameDocument) {
    return STNewGameCanConfirm(expected, true) && expected == current &&
        sameController && sameWebView && sameDocument;
}
#endif

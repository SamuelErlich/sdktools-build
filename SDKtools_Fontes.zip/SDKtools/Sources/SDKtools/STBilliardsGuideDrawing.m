#import "STBilliardsGuideDrawing.h"
#import "STBilliardsLivePolicy.h"
#include <math.h>

static const NSUInteger STBLDrawingMaxSegments=48;
static const NSUInteger STBLDrawingMaxBalls=16;

static NSInteger STBLDrawingTag(id value) {
    if (![value isKindOfClass:NSNumber.class]) return 0;
    double number=[value doubleValue];
    return isfinite(number) && number>=1 && number<=16 && floor(number)==number ? (NSInteger)number : 0;
}

static BOOL STBLDrawingPoint(id value, double width, double height, CGRect rect, CGPoint *result) {
    if (![value isKindOfClass:NSDictionary.class]) return NO;
    id xValue=value[@"x"],yValue=value[@"y"];
    if (![xValue isKindOfClass:NSNumber.class] || ![yValue isKindOfClass:NSNumber.class]) return NO;
    double x=[xValue doubleValue],y=[yValue doubleValue];
    if (!isfinite(x) || !isfinite(y) || x<0 || x>width || y<0 || y>height) return NO;
    *result=CGPointMake(rect.origin.x+x/width*rect.size.width,
        rect.origin.y+(1-y/height)*rect.size.height);
    return YES;
}

static UIColor *STBLDrawingBallColor(NSInteger tag) {
    // Identity stays with the ball across every collision and cushion rebound.
    // These are guide colors; they do not read or replace the game's textures.
    NSInteger number=tag-1;
    if (number<=0) return UIColor.whiteColor;
    if (number==8) return [UIColor colorWithRed:0.79 green:0.83 blue:0.91 alpha:1];
    switch ((number-1)%8+1) {
        case 1: return [UIColor colorWithRed:1.00 green:0.86 blue:0.20 alpha:1];
        case 2: return [UIColor colorWithRed:0.28 green:0.65 blue:1.00 alpha:1];
        case 3: return [UIColor colorWithRed:1.00 green:0.36 blue:0.32 alpha:1];
        case 4: return [UIColor colorWithRed:0.77 green:0.52 blue:1.00 alpha:1];
        case 5: return [UIColor colorWithRed:1.00 green:0.63 blue:0.20 alpha:1];
        case 6: return [UIColor colorWithRed:0.28 green:0.95 blue:0.56 alpha:1];
        case 7: return [UIColor colorWithRed:0.98 green:0.43 blue:0.68 alpha:1];
        default: return UIColor.whiteColor;
    }
}

static UIColor *STBLDrawingLegacyColor(id kind) {
    if ([kind isEqual:@"object"]) return [UIColor colorWithRed:1 green:0.65 blue:0.12 alpha:1];
    if ([kind isEqual:@"rebound"]) return [UIColor colorWithRed:0.3 green:1 blue:0.65 alpha:1];
    return [UIColor colorWithRed:0.2 green:0.85 blue:1 alpha:1];
}

static void STBLDrawingStroke(UIBezierPath *path, UIColor *color, CGFloat width, CGFloat alpha) {
    path.lineCapStyle=kCGLineCapRound;
    path.lineJoinStyle=kCGLineJoinRound;
    path.lineWidth=width+1.8;
    [[UIColor colorWithWhite:0.02 alpha:0.55*alpha] setStroke];
    [path stroke];
    path.lineWidth=width;
    [[color colorWithAlphaComponent:alpha] setStroke];
    [path stroke];
}

static CGFloat STBLDrawingRadius(NSDictionary *ball, double width, CGRect rect) {
    id value=ball[@"radiusPixels"];
    if (![value isKindOfClass:NSNumber.class]) return 0;
    double radius=[value doubleValue]/width*rect.size.width;
    return isfinite(radius) && radius>0 && radius<=MIN(rect.size.width,rect.size.height)/4 ? (CGFloat)radius : 0;
}

void STBilliardsDrawGuideSnapshot(NSDictionary *snapshot, CGRect gameRect) {
    if (![snapshot isKindOfClass:NSDictionary.class] ||
        !isfinite(gameRect.origin.x) || !isfinite(gameRect.origin.y)) return;
    NSDictionary *screen=snapshot[@"screen"];
    if (![screen isKindOfClass:NSDictionary.class] ||
        ![screen[@"width"] isKindOfClass:NSNumber.class] ||
        ![screen[@"height"] isKindOfClass:NSNumber.class]) return;
    double width=[screen[@"width"] doubleValue],height=[screen[@"height"] doubleValue];
    if (!STBLValidViewport(width,height,gameRect.size.width,gameRect.size.height)) return;
    NSArray *segments=snapshot[@"segments"],*balls=snapshot[@"balls"];
    if (![segments isKindOfClass:NSArray.class] || segments.count>STBLDrawingMaxSegments ||
        ![balls isKindOfClass:NSArray.class] || balls.count>STBLDrawingMaxBalls) return;
    CGContextRef context=UIGraphicsGetCurrentContext();
    if (!context) return;

    NSMutableDictionary<NSNumber *,NSDictionary *> *activeBalls=[NSMutableDictionary dictionary];
    NSMutableSet<NSNumber *> *affected=[NSMutableSet set];
    for (id item in balls) {
        if (![item isKindOfClass:NSDictionary.class] ||
            ![item[@"active"] boolValue] || [item[@"potted"] boolValue]) continue;
        NSInteger tag=STBLDrawingTag(item[@"tag"]);
        if (tag) activeBalls[@(tag)]=item;
    }
    for (id item in segments) {
        if (![item isKindOfClass:NSDictionary.class]) continue;
        NSInteger tag=STBLDrawingTag(item[@"ballTag"]),hitTag=STBLDrawingTag(item[@"hitBallTag"]);
        if (tag && activeBalls[@(tag)]) [affected addObject:@(tag)];
        if ([item[@"terminal"] isEqual:@"ball"] && hitTag && activeBalls[@(hitTag)]) [affected addObject:@(hitTag)];
    }

    CGContextSaveGState(context);
    CGContextClipToRect(context,gameRect);
    CGPoint contactCenters[48];
    NSUInteger contactCount=0;
    for (id item in segments) {
        if (![item isKindOfClass:NSDictionary.class]) continue;
        NSDictionary *segment=item;
        CGPoint from,to;
        if (!STBLDrawingPoint(segment[@"from"],width,height,gameRect,&from) ||
            !STBLDrawingPoint(segment[@"to"],width,height,gameRect,&to)) continue;
        CGFloat dx=to.x-from.x,dy=to.y-from.y,length=hypot(dx,dy);
        if (!isfinite(length) || length<0.25) continue;
        NSInteger tag=STBLDrawingTag(segment[@"ballTag"]);
        UIColor *color=tag ? STBLDrawingBallColor(tag) : STBLDrawingLegacyColor(segment[@"kind"]);
        // Later events stay legible while the immediate aim remains strongest.
        double eventIndex=[segment[@"eventIndex"] isKindOfClass:NSNumber.class] ? [segment[@"eventIndex"] doubleValue] : 0;
        if (!isfinite(eventIndex)) eventIndex=0;
        CGFloat alpha=0.97-0.025*MIN(8.0,MAX(0.0,eventIndex));
        UIBezierPath *path=[UIBezierPath bezierPath];
        [path moveToPoint:from]; [path addLineToPoint:to];
        STBLDrawingStroke(path,color,tag==1?2.2:2.0,alpha);

        if (length>=24) {
            CGFloat ux=dx/length,uy=dy/length;
            CGPoint tip=CGPointMake(from.x+dx*0.65,from.y+dy*0.65);
            CGFloat size=MIN(5.0,length*0.12);
            UIBezierPath *arrow=[UIBezierPath bezierPath];
            [arrow moveToPoint:CGPointMake(tip.x-ux*size-uy*size*0.55,tip.y-uy*size+ux*size*0.55)];
            [arrow addLineToPoint:tip];
            [arrow addLineToPoint:CGPointMake(tip.x-ux*size+uy*size*0.55,tip.y-uy*size-ux*size*0.55)];
            STBLDrawingStroke(arrow,color,1.6,alpha);
        }

        // 'to' is the predicted moving-ball center, never the surface contact.
        if (tag && [segment[@"terminal"] isEqual:@"ball"]) {
            CGFloat radius=STBLDrawingRadius(activeBalls[@(tag)],width,gameRect);
            BOOL duplicate=NO;
            for (NSUInteger index=0;index<contactCount;index++) {
                if (hypot(to.x-contactCenters[index].x,to.y-contactCenters[index].y)<2.0) { duplicate=YES; break; }
            }
            if (radius>0 && !duplicate && contactCount<48) {
                contactCenters[contactCount++]=to;
                UIBezierPath *ghost=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(to.x-radius,to.y-radius,2*radius,2*radius)];
                STBLDrawingStroke(ghost,color,1.1,alpha*0.78);
            }
        }
    }

    NSMutableArray<NSValue *> *labelRects=[NSMutableArray array];
    for (id item in balls) {
        if (![item isKindOfClass:NSDictionary.class]) continue;
        NSInteger tag=STBLDrawingTag(item[@"tag"]);
        NSDictionary *ball=activeBalls[@(tag)];
        if (!ball) continue;
        CGPoint center;
        if (!STBLDrawingPoint(ball[@"screen"],width,height,gameRect,&center)) continue;
        CGFloat radius=STBLDrawingRadius(ball,width,gameRect);
        if (radius<=0) continue;
        BOOL involved=[affected containsObject:@(tag)];
        UIColor *color=STBLDrawingBallColor(tag);
        UIBezierPath *circle=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(center.x-radius,center.y-radius,2*radius,2*radius)];
        if (involved) STBLDrawingStroke(circle,color,1.35,0.92);
        else {
            circle.lineWidth=0.75;
            [[UIColor colorWithWhite:1 alpha:0.28] setStroke];
            [circle stroke];
        }
        // Number only involved object balls, outside their existing texture.
        if (!involved || tag==1) continue;
        NSString *label=[NSString stringWithFormat:@"%ld",(long)(tag-1)];
        CGFloat fontSize=MAX(8.0,MIN(10.0,radius*0.95));
        NSDictionary *attributes=@{NSFontAttributeName:[UIFont boldSystemFontOfSize:fontSize],NSForegroundColorAttributeName:color};
        CGSize textSize=[label sizeWithAttributes:attributes];
        CGRect badge=CGRectMake(center.x+radius*0.55,center.y-radius-textSize.height-2,textSize.width+4,textSize.height+1);
        badge.origin.x=MAX(CGRectGetMinX(gameRect)+1,MIN(CGRectGetMaxX(gameRect)-badge.size.width-1,badge.origin.x));
        badge.origin.y=MAX(CGRectGetMinY(gameRect)+1,MIN(CGRectGetMaxY(gameRect)-badge.size.height-1,badge.origin.y));
        BOOL overlaps=NO;
        for (NSValue *value in labelRects) {
            if (CGRectIntersectsRect(CGRectInset(badge,-1,-1),value.CGRectValue)) { overlaps=YES; break; }
        }
        if (overlaps) continue;
        [labelRects addObject:[NSValue valueWithCGRect:badge]];
        [[UIColor colorWithWhite:0 alpha:0.67] setFill];
        [[UIBezierPath bezierPathWithRoundedRect:badge cornerRadius:3] fill];
        [label drawAtPoint:CGPointMake(badge.origin.x+2,badge.origin.y) withAttributes:attributes];
    }
    CGContextRestoreGState(context);
}

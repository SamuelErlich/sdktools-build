#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/** Executes SDKtools' bundled observer in the already existing, locked Lua VM.
 * Synchronous and main-thread-only. Does not create a LuaManager/LuaEnv, force
 * class initialization, attach threads, resolve fixed offsets or call getters.
 * Only `sample`, `stop`, `aim`, `autoplay` are accepted. Actions require explicit
 * native opt-in and revalidate the current local turn in the existing VM.
 */
@interface STBilliardsLuaBridge : NSObject
+ (nullable NSDictionary *)executeCommand:(NSString *)command
                                    error:(NSError * _Nullable * _Nullable)error;
@end

NS_ASSUME_NONNULL_END

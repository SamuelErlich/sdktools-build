#import "STLocalizedUI.h"
#import <objc/runtime.h>
static char STLocalizedFieldsKey;
static char STLocalizedLanguageKey;
static NSHashTable<UIView *> *STLocalizedViews;
static void STApplyLocalizedView(UIView *view) {
    NSDictionary *fields=objc_getAssociatedObject(view,&STLocalizedFieldsKey);
    if ([view isKindOfClass:UILabel.class] && fields[@"text"]) ((UILabel *)view).text=STLocalizedText(fields[@"text"]);
    if ([view isKindOfClass:UIButton.class] && fields[@"title"]) [(UIButton *)view setTitle:STLocalizedText(fields[@"title"]) forState:UIControlStateNormal];
    if (fields[@"label"]) view.accessibilityLabel=STLocalizedText(fields[@"label"]);
    if (fields[@"hint"]) view.accessibilityHint=STLocalizedText(fields[@"hint"]);
    if (fields[@"value"]) view.accessibilityValue=STLocalizedText(fields[@"value"]);
    NSString *language=STCurrentLanguage();
    view.accessibilityLanguage=[language isEqual:@"pt"]?@"pt-BR":@"en-US";
    objc_setAssociatedObject(view,&STLocalizedLanguageKey,language,OBJC_ASSOCIATION_COPY_NONATOMIC);
}
static void STBindLocalizedField(UIView *view,NSString *field,NSString *source) {
    if (!view) return;
    if (!NSThread.isMainThread) {
        NSCAssert(NO,@"Localized UIKit bindings require the main thread");
        return; // Keep UIKit and the weak registry on main even in release builds.
    }
    static dispatch_once_t once; static id observer;
    dispatch_once(&once,^{
        STLocalizedViews=[NSHashTable weakObjectsHashTable];
        observer=[NSNotificationCenter.defaultCenter addObserverForName:STLanguageDidChangeNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note){
            for (UIView *item in STLocalizedViews.allObjects) STApplyLocalizedView(item);
        }];
        (void)observer;
    });
    NSString *value=[source copy] ?: @"";
    NSMutableDictionary *fields=objc_getAssociatedObject(view,&STLocalizedFieldsKey);
    if (!fields) { fields=[NSMutableDictionary dictionary]; objc_setAssociatedObject(view,&STLocalizedFieldsKey,fields,OBJC_ASSOCIATION_RETAIN_NONATOMIC); [STLocalizedViews addObject:view]; }
    if ([fields[field] isEqual:value] && [objc_getAssociatedObject(view,&STLocalizedLanguageKey) isEqual:STCurrentLanguage()]) return;
    fields[field]=value; STApplyLocalizedView(view);
}
void STLocalizeLabel(UILabel *label,NSString *source) { STBindLocalizedField(label,@"text",source); }
void STLocalizeButton(UIButton *button,NSString *source) { STBindLocalizedField(button,@"title",source); }
void STLocalizeAccessibilityLabel(UIView *view,NSString *source) { STBindLocalizedField(view,@"label",source); }
void STLocalizeAccessibilityHint(UIView *view,NSString *source) { STBindLocalizedField(view,@"hint",source); }
void STLocalizeAccessibilityValue(UIView *view,NSString *source) { STBindLocalizedField(view,@"value",source); }
